.class public final LA/b;
.super LP1/h;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public f:I

.field public synthetic g:Ljava/lang/Object;

.field public final synthetic h:LU1/c;


# direct methods
.method public constructor <init>(LU1/c;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA/b;->h:LU1/c;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LP1/h;-><init>(LN1/c;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lq0/I;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LA/b;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LA/b;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LA/b;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LA/b;

    .line 2
    .line 3
    iget-object v1, p0, LA/b;->h:LU1/c;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LA/b;-><init>(LU1/c;LN1/c;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, LA/b;->g:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LA/b;->f:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    sget-object v3, LO1/a;->d:LO1/a;

    .line 6
    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-eq v0, v2, :cond_1

    .line 10
    .line 11
    if-ne v0, v1, :cond_0

    .line 12
    .line 13
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    goto :goto_2

    .line 17
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 18
    .line 19
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 20
    .line 21
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw p1

    .line 25
    :cond_1
    iget-object v0, p0, LA/b;->g:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v0, Lq0/I;

    .line 28
    .line 29
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object p1, p0, LA/b;->g:Ljava/lang/Object;

    .line 37
    .line 38
    move-object v0, p1

    .line 39
    check-cast v0, Lq0/I;

    .line 40
    .line 41
    iput-object v0, p0, LA/b;->g:Ljava/lang/Object;

    .line 42
    .line 43
    iput v2, p0, LA/b;->f:I

    .line 44
    .line 45
    invoke-static {v0, p0}, LX1/a;->t(Lq0/I;LP1/a;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    if-ne p1, v3, :cond_3

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_3
    :goto_0
    check-cast p1, Lq0/u;

    .line 53
    .line 54
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 55
    .line 56
    .line 57
    iget-wide v4, p1, Lq0/u;->c:J

    .line 58
    .line 59
    new-instance p1, Lc0/b;

    .line 60
    .line 61
    invoke-direct {p1, v4, v5}, Lc0/b;-><init>(J)V

    .line 62
    .line 63
    .line 64
    iget-object v2, p0, LA/b;->h:LU1/c;

    .line 65
    .line 66
    invoke-interface {v2, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    const/4 p1, 0x0

    .line 70
    iput-object p1, p0, LA/b;->g:Ljava/lang/Object;

    .line 71
    .line 72
    iput v1, p0, LA/b;->f:I

    .line 73
    .line 74
    sget-object p1, Lq0/m;->e:Lq0/m;

    .line 75
    .line 76
    invoke-static {v0, p1, p0}, Lp/p1;->e(Lq0/I;Lq0/m;LP1/a;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    if-ne p1, v3, :cond_4

    .line 81
    .line 82
    :goto_1
    return-object v3

    .line 83
    :cond_4
    :goto_2
    check-cast p1, Lq0/u;

    .line 84
    .line 85
    if-eqz p1, :cond_5

    .line 86
    .line 87
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 88
    .line 89
    .line 90
    :cond_5
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 91
    .line 92
    return-object p1
.end method
