.class public final synthetic LA1/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LC1/a;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Z

.field public final synthetic g:LU1/c;

.field public final synthetic h:LU1/a;

.field public final synthetic i:LU1/a;


# direct methods
.method public synthetic constructor <init>(LC1/a;Ljava/lang/String;ZLU1/c;LU1/a;LU1/a;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/A;->d:LC1/a;

    iput-object p2, p0, LA1/A;->e:Ljava/lang/String;

    iput-boolean p3, p0, LA1/A;->f:Z

    iput-object p4, p0, LA1/A;->g:LU1/c;

    iput-object p5, p0, LA1/A;->h:LU1/a;

    iput-object p6, p0, LA1/A;->i:LU1/a;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    move-object v6, p1

    .line 2
    check-cast v6, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/16 p1, 0x6001

    .line 10
    .line 11
    invoke-static {p1}, LI/k;->x(I)I

    .line 12
    .line 13
    .line 14
    move-result v7

    .line 15
    iget-object v0, p0, LA1/A;->d:LC1/a;

    .line 16
    .line 17
    iget-object v1, p0, LA1/A;->e:Ljava/lang/String;

    .line 18
    .line 19
    iget-boolean v2, p0, LA1/A;->f:Z

    .line 20
    .line 21
    iget-object v3, p0, LA1/A;->g:LU1/c;

    .line 22
    .line 23
    iget-object v4, p0, LA1/A;->h:LU1/a;

    .line 24
    .line 25
    iget-object v5, p0, LA1/A;->i:LU1/a;

    .line 26
    .line 27
    invoke-static/range {v0 .. v7}, LX1/a;->h(LC1/a;Ljava/lang/String;ZLU1/c;LU1/a;LU1/a;LI/r;I)V

    .line 28
    .line 29
    .line 30
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 31
    .line 32
    return-object p1
.end method
