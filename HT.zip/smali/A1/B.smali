.class public final synthetic LA1/B;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Z)V
    .locals 0

    .line 1
    iput p1, p0, LA1/B;->d:I

    iput-boolean p3, p0, LA1/B;->e:Z

    iput-object p2, p0, LA1/B;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LU1/c;Z)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, LA1/B;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/B;->f:Ljava/lang/Object;

    iput-boolean p2, p0, LA1/B;->e:Z

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LA1/B;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/B;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LF/g;

    .line 9
    .line 10
    iget-boolean v1, p0, LA1/B;->e:Z

    .line 11
    .line 12
    sget-object v2, LJ1/m;->a:LJ1/m;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    invoke-virtual {v0}, LF/g;->i()Lf2/q;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    check-cast v0, Lf2/v;

    .line 23
    .line 24
    invoke-virtual {v0, v2}, Lf2/v;->q(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    :cond_0
    return-object v2

    .line 28
    :pswitch_0
    iget-object v0, p0, LA1/B;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, LU1/a;

    .line 31
    .line 32
    iget-boolean v1, p0, LA1/B;->e:Z

    .line 33
    .line 34
    if-eqz v1, :cond_1

    .line 35
    .line 36
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    :cond_1
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 40
    .line 41
    return-object v0

    .line 42
    :pswitch_1
    iget-object v0, p0, LA1/B;->f:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, LU1/c;

    .line 45
    .line 46
    iget-boolean v1, p0, LA1/B;->e:Z

    .line 47
    .line 48
    xor-int/lit8 v1, v1, 0x1

    .line 49
    .line 50
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 58
    .line 59
    return-object v0

    .line 60
    nop

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
