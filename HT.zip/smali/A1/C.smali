.class public final synthetic LA1/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LC1/a;

.field public final synthetic e:Z

.field public final synthetic f:LU1/c;


# direct methods
.method public synthetic constructor <init>(LC1/a;ZLU1/c;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/C;->d:LC1/a;

    iput-boolean p2, p0, LA1/C;->e:Z

    iput-object p3, p0, LA1/C;->f:LU1/c;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    check-cast p1, LI/r;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const/16 p2, 0x31

    .line 9
    .line 10
    invoke-static {p2}, LI/k;->x(I)I

    .line 11
    .line 12
    .line 13
    move-result p2

    .line 14
    iget-object v0, p0, LA1/C;->d:LC1/a;

    .line 15
    .line 16
    iget-boolean v1, p0, LA1/C;->e:Z

    .line 17
    .line 18
    iget-object v2, p0, LA1/C;->f:LU1/c;

    .line 19
    .line 20
    invoke-static {v0, v1, v2, p1, p2}, LX1/a;->q(LC1/a;ZLU1/c;LI/r;I)V

    .line 21
    .line 22
    .line 23
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 24
    .line 25
    return-object p1
.end method
