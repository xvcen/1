.class public final synthetic LA1/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LC1/a;

.field public final synthetic e:Z

.field public final synthetic f:LA1/d0;

.field public final synthetic g:LU1/a;

.field public final synthetic h:LU1/a;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(LC1/a;ZLA1/d0;LU1/a;LU1/a;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/D;->d:LC1/a;

    iput-boolean p2, p0, LA1/D;->e:Z

    iput-object p3, p0, LA1/D;->f:LA1/d0;

    iput-object p4, p0, LA1/D;->g:LU1/a;

    iput-object p5, p0, LA1/D;->h:LU1/a;

    iput p6, p0, LA1/D;->i:I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 7
    .line 8
    .line 9
    iget p1, p0, LA1/D;->i:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, LI/k;->x(I)I

    .line 14
    .line 15
    .line 16
    move-result v6

    .line 17
    iget-object v0, p0, LA1/D;->d:LC1/a;

    .line 18
    .line 19
    iget-boolean v1, p0, LA1/D;->e:Z

    .line 20
    .line 21
    iget-object v2, p0, LA1/D;->f:LA1/d0;

    .line 22
    .line 23
    iget-object v3, p0, LA1/D;->g:LU1/a;

    .line 24
    .line 25
    iget-object v4, p0, LA1/D;->h:LU1/a;

    .line 26
    .line 27
    invoke-static/range {v0 .. v6}, LX1/a;->a(LC1/a;ZLA1/d0;LU1/a;LU1/a;LI/r;I)V

    .line 28
    .line 29
    .line 30
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 31
    .line 32
    return-object p1
.end method
