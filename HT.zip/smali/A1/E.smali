.class public final synthetic LA1/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LA1/E;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LA1/E;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LT/b;

    .line 7
    .line 8
    check-cast p2, LH0/Q;

    .line 9
    .line 10
    iget-object p1, p2, LH0/Q;->a:Ljava/lang/String;

    .line 11
    .line 12
    return-object p1

    .line 13
    :pswitch_0
    check-cast p1, LT/b;

    .line 14
    .line 15
    check-cast p2, LS0/g;

    .line 16
    .line 17
    iget p1, p2, LS0/g;->a:I

    .line 18
    .line 19
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :pswitch_1
    check-cast p1, LT/b;

    .line 25
    .line 26
    check-cast p2, LS0/h;

    .line 27
    .line 28
    iget p1, p2, LS0/h;->a:I

    .line 29
    .line 30
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    return-object p1

    .line 35
    :pswitch_2
    check-cast p1, LT/b;

    .line 36
    .line 37
    check-cast p2, LS0/f;

    .line 38
    .line 39
    iget p1, p2, LS0/f;->a:F

    .line 40
    .line 41
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    return-object p1

    .line 46
    :pswitch_3
    check-cast p1, LT/b;

    .line 47
    .line 48
    check-cast p2, LS0/i;

    .line 49
    .line 50
    iget v0, p2, LS0/i;->a:F

    .line 51
    .line 52
    new-instance v1, LS0/f;

    .line 53
    .line 54
    invoke-direct {v1, v0}, LS0/f;-><init>(F)V

    .line 55
    .line 56
    .line 57
    sget-object v0, LH0/E;->B:LH0/D;

    .line 58
    .line 59
    invoke-static {v1, v0, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    iget v1, p2, LS0/i;->b:I

    .line 64
    .line 65
    new-instance v2, LS0/h;

    .line 66
    .line 67
    invoke-direct {v2, v1}, LS0/h;-><init>(I)V

    .line 68
    .line 69
    .line 70
    sget-object v1, LH0/E;->C:LH0/D;

    .line 71
    .line 72
    invoke-static {v2, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iget p2, p2, LS0/i;->c:I

    .line 77
    .line 78
    new-instance v2, LS0/g;

    .line 79
    .line 80
    invoke-direct {v2, p2}, LS0/g;-><init>(I)V

    .line 81
    .line 82
    .line 83
    sget-object p2, LH0/E;->D:LH0/D;

    .line 84
    .line 85
    invoke-static {v2, p2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    filled-new-array {v0, v1, p1}, [Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    return-object p1

    .line 98
    :pswitch_4
    check-cast p1, LT/b;

    .line 99
    .line 100
    check-cast p2, LO0/a;

    .line 101
    .line 102
    iget-object p1, p2, LO0/a;->a:Ljava/util/Locale;

    .line 103
    .line 104
    invoke-virtual {p1}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    return-object p1

    .line 109
    :pswitch_5
    check-cast p1, LT/b;

    .line 110
    .line 111
    check-cast p2, LO0/b;

    .line 112
    .line 113
    iget-object p2, p2, LO0/b;->d:Ljava/util/List;

    .line 114
    .line 115
    new-instance v0, Ljava/util/ArrayList;

    .line 116
    .line 117
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 122
    .line 123
    .line 124
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    const/4 v2, 0x0

    .line 129
    :goto_0
    if-ge v2, v1, :cond_0

    .line 130
    .line 131
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    check-cast v3, LO0/a;

    .line 136
    .line 137
    sget-object v4, LH0/E;->z:LF/r;

    .line 138
    .line 139
    invoke-static {v3, v4, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    add-int/lit8 v2, v2, 0x1

    .line 147
    .line 148
    goto :goto_0

    .line 149
    :cond_0
    return-object v0

    .line 150
    :pswitch_6
    check-cast p1, LT/b;

    .line 151
    .line 152
    check-cast p2, LH0/e;

    .line 153
    .line 154
    iget-object v0, p2, LH0/e;->a:Ljava/lang/Object;

    .line 155
    .line 156
    instance-of v1, v0, LH0/v;

    .line 157
    .line 158
    if-eqz v1, :cond_1

    .line 159
    .line 160
    sget-object v1, LH0/i;->d:LH0/i;

    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_1
    instance-of v1, v0, LH0/G;

    .line 164
    .line 165
    if-eqz v1, :cond_2

    .line 166
    .line 167
    sget-object v1, LH0/i;->e:LH0/i;

    .line 168
    .line 169
    goto :goto_1

    .line 170
    :cond_2
    instance-of v1, v0, LH0/Q;

    .line 171
    .line 172
    if-eqz v1, :cond_3

    .line 173
    .line 174
    sget-object v1, LH0/i;->f:LH0/i;

    .line 175
    .line 176
    goto :goto_1

    .line 177
    :cond_3
    instance-of v1, v0, LH0/P;

    .line 178
    .line 179
    if-eqz v1, :cond_4

    .line 180
    .line 181
    sget-object v1, LH0/i;->g:LH0/i;

    .line 182
    .line 183
    goto :goto_1

    .line 184
    :cond_4
    instance-of v1, v0, LH0/l;

    .line 185
    .line 186
    if-eqz v1, :cond_5

    .line 187
    .line 188
    sget-object v1, LH0/i;->h:LH0/i;

    .line 189
    .line 190
    goto :goto_1

    .line 191
    :cond_5
    instance-of v1, v0, LH0/k;

    .line 192
    .line 193
    if-eqz v1, :cond_6

    .line 194
    .line 195
    sget-object v1, LH0/i;->i:LH0/i;

    .line 196
    .line 197
    goto :goto_1

    .line 198
    :cond_6
    instance-of v1, v0, LH0/I;

    .line 199
    .line 200
    if-eqz v1, :cond_7

    .line 201
    .line 202
    sget-object v1, LH0/i;->j:LH0/i;

    .line 203
    .line 204
    :goto_1
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    packed-switch v2, :pswitch_data_1

    .line 209
    .line 210
    .line 211
    new-instance p1, LC0/e;

    .line 212
    .line 213
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 214
    .line 215
    .line 216
    throw p1

    .line 217
    :pswitch_7
    const-string p1, "null cannot be cast to non-null type androidx.compose.ui.text.StringAnnotation"

    .line 218
    .line 219
    invoke-static {v0, p1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    check-cast v0, LH0/I;

    .line 223
    .line 224
    iget-object p1, v0, LH0/I;->a:Ljava/lang/String;

    .line 225
    .line 226
    goto :goto_2

    .line 227
    :pswitch_8
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.LinkAnnotation.Clickable"

    .line 228
    .line 229
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    check-cast v0, LH0/k;

    .line 233
    .line 234
    sget-object v2, LH0/E;->f:LF/r;

    .line 235
    .line 236
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    goto :goto_2

    .line 241
    :pswitch_9
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.LinkAnnotation.Url"

    .line 242
    .line 243
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    check-cast v0, LH0/l;

    .line 247
    .line 248
    sget-object v2, LH0/E;->e:LF/r;

    .line 249
    .line 250
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object p1

    .line 254
    goto :goto_2

    .line 255
    :pswitch_a
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.UrlAnnotation"

    .line 256
    .line 257
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    check-cast v0, LH0/P;

    .line 261
    .line 262
    sget-object v2, LH0/E;->d:LF/r;

    .line 263
    .line 264
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object p1

    .line 268
    goto :goto_2

    .line 269
    :pswitch_b
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.VerbatimTtsAnnotation"

    .line 270
    .line 271
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 272
    .line 273
    .line 274
    check-cast v0, LH0/Q;

    .line 275
    .line 276
    sget-object v2, LH0/E;->c:LF/r;

    .line 277
    .line 278
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    goto :goto_2

    .line 283
    :pswitch_c
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.SpanStyle"

    .line 284
    .line 285
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 286
    .line 287
    .line 288
    check-cast v0, LH0/G;

    .line 289
    .line 290
    sget-object v2, LH0/E;->h:LF/r;

    .line 291
    .line 292
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    goto :goto_2

    .line 297
    :pswitch_d
    const-string v2, "null cannot be cast to non-null type androidx.compose.ui.text.ParagraphStyle"

    .line 298
    .line 299
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    check-cast v0, LH0/v;

    .line 303
    .line 304
    sget-object v2, LH0/E;->g:LF/r;

    .line 305
    .line 306
    invoke-static {v0, v2, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object p1

    .line 310
    :goto_2
    iget v0, p2, LH0/e;->b:I

    .line 311
    .line 312
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    iget v2, p2, LH0/e;->c:I

    .line 317
    .line 318
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 319
    .line 320
    .line 321
    move-result-object v2

    .line 322
    iget-object p2, p2, LH0/e;->d:Ljava/lang/String;

    .line 323
    .line 324
    filled-new-array {v1, p1, v0, v2, p2}, [Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object p1

    .line 328
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 329
    .line 330
    .line 331
    move-result-object p1

    .line 332
    return-object p1

    .line 333
    :cond_7
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 334
    .line 335
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 336
    .line 337
    .line 338
    throw p1

    .line 339
    :pswitch_e
    check-cast p1, LT/b;

    .line 340
    .line 341
    check-cast p2, Lc0/b;

    .line 342
    .line 343
    if-nez p2, :cond_8

    .line 344
    .line 345
    const/4 p1, 0x0

    .line 346
    goto :goto_3

    .line 347
    :cond_8
    iget-wide v0, p2, Lc0/b;->a:J

    .line 348
    .line 349
    const-wide v2, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    invoke-static {v0, v1, v2, v3}, Lc0/b;->b(JJ)Z

    .line 355
    .line 356
    .line 357
    move-result p1

    .line 358
    :goto_3
    if-eqz p1, :cond_9

    .line 359
    .line 360
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 361
    .line 362
    goto :goto_4

    .line 363
    :cond_9
    iget-wide v0, p2, Lc0/b;->a:J

    .line 364
    .line 365
    const/16 p1, 0x20

    .line 366
    .line 367
    shr-long/2addr v0, p1

    .line 368
    long-to-int p1, v0

    .line 369
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 370
    .line 371
    .line 372
    move-result p1

    .line 373
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 374
    .line 375
    .line 376
    move-result-object p1

    .line 377
    iget-wide v0, p2, Lc0/b;->a:J

    .line 378
    .line 379
    const-wide v2, 0xffffffffL

    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    and-long/2addr v0, v2

    .line 385
    long-to-int p2, v0

    .line 386
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 387
    .line 388
    .line 389
    move-result p2

    .line 390
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 391
    .line 392
    .line 393
    move-result-object p2

    .line 394
    filled-new-array {p1, p2}, [Ljava/lang/Float;

    .line 395
    .line 396
    .line 397
    move-result-object p1

    .line 398
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 399
    .line 400
    .line 401
    move-result-object p1

    .line 402
    :goto_4
    return-object p1

    .line 403
    :pswitch_f
    check-cast p1, LT/b;

    .line 404
    .line 405
    check-cast p2, LT0/r;

    .line 406
    .line 407
    iget-wide p1, p2, LT0/r;->a:J

    .line 408
    .line 409
    const-wide v0, 0x200000000L

    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    invoke-static {p1, p2, v0, v1}, LT0/r;->a(JJ)Z

    .line 415
    .line 416
    .line 417
    move-result v0

    .line 418
    if-eqz v0, :cond_a

    .line 419
    .line 420
    const/4 p1, 0x0

    .line 421
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 422
    .line 423
    .line 424
    move-result-object p1

    .line 425
    goto :goto_5

    .line 426
    :cond_a
    const-wide v0, 0x100000000L

    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    invoke-static {p1, p2, v0, v1}, LT0/r;->a(JJ)Z

    .line 432
    .line 433
    .line 434
    move-result p1

    .line 435
    if-eqz p1, :cond_b

    .line 436
    .line 437
    const/4 p1, 0x1

    .line 438
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 439
    .line 440
    .line 441
    move-result-object p1

    .line 442
    goto :goto_5

    .line 443
    :cond_b
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 444
    .line 445
    :goto_5
    return-object p1

    .line 446
    :pswitch_10
    check-cast p1, LT/b;

    .line 447
    .line 448
    check-cast p2, LH0/k;

    .line 449
    .line 450
    iget-object v0, p2, LH0/k;->a:Ljava/lang/String;

    .line 451
    .line 452
    iget-object p2, p2, LH0/k;->b:LH0/M;

    .line 453
    .line 454
    sget-object v1, LH0/E;->i:LF/r;

    .line 455
    .line 456
    invoke-static {p2, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object p1

    .line 460
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 461
    .line 462
    .line 463
    move-result-object p1

    .line 464
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 465
    .line 466
    .line 467
    move-result-object p1

    .line 468
    return-object p1

    .line 469
    :pswitch_11
    check-cast p1, LT/b;

    .line 470
    .line 471
    check-cast p2, LT0/q;

    .line 472
    .line 473
    sget-wide v0, LT0/q;->c:J

    .line 474
    .line 475
    if-nez p2, :cond_c

    .line 476
    .line 477
    const/4 v0, 0x0

    .line 478
    goto :goto_6

    .line 479
    :cond_c
    iget-wide v2, p2, LT0/q;->a:J

    .line 480
    .line 481
    invoke-static {v2, v3, v0, v1}, LT0/q;->a(JJ)Z

    .line 482
    .line 483
    .line 484
    move-result v0

    .line 485
    :goto_6
    if-eqz v0, :cond_d

    .line 486
    .line 487
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 488
    .line 489
    goto :goto_7

    .line 490
    :cond_d
    iget-wide v0, p2, LT0/q;->a:J

    .line 491
    .line 492
    invoke-static {v0, v1}, LT0/q;->c(J)F

    .line 493
    .line 494
    .line 495
    move-result v0

    .line 496
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 497
    .line 498
    .line 499
    move-result-object v0

    .line 500
    iget-wide v1, p2, LT0/q;->a:J

    .line 501
    .line 502
    invoke-static {v1, v2}, LT0/q;->b(J)J

    .line 503
    .line 504
    .line 505
    move-result-wide v1

    .line 506
    new-instance p2, LT0/r;

    .line 507
    .line 508
    invoke-direct {p2, v1, v2}, LT0/r;-><init>(J)V

    .line 509
    .line 510
    .line 511
    sget-object v1, LH0/E;->w:LH0/D;

    .line 512
    .line 513
    invoke-static {p2, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    move-result-object p1

    .line 517
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object p1

    .line 521
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 522
    .line 523
    .line 524
    move-result-object p1

    .line 525
    :goto_7
    return-object p1

    .line 526
    :pswitch_12
    check-cast p1, LT/b;

    .line 527
    .line 528
    check-cast p2, LL0/j;

    .line 529
    .line 530
    iget p1, p2, LL0/j;->a:I

    .line 531
    .line 532
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 533
    .line 534
    .line 535
    move-result-object p1

    .line 536
    return-object p1

    .line 537
    :pswitch_13
    check-cast p1, LT/b;

    .line 538
    .line 539
    check-cast p2, LL0/i;

    .line 540
    .line 541
    iget p1, p2, LL0/i;->a:I

    .line 542
    .line 543
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 544
    .line 545
    .line 546
    move-result-object p1

    .line 547
    return-object p1

    .line 548
    :pswitch_14
    check-cast p1, LT/b;

    .line 549
    .line 550
    check-cast p2, LS0/d;

    .line 551
    .line 552
    iget p1, p2, LS0/d;->a:I

    .line 553
    .line 554
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 555
    .line 556
    .line 557
    move-result-object p1

    .line 558
    return-object p1

    .line 559
    :pswitch_15
    check-cast p1, LT/b;

    .line 560
    .line 561
    check-cast p2, LS0/m;

    .line 562
    .line 563
    iget p1, p2, LS0/m;->a:I

    .line 564
    .line 565
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 566
    .line 567
    .line 568
    move-result-object p1

    .line 569
    return-object p1

    .line 570
    :pswitch_16
    check-cast p1, LT/b;

    .line 571
    .line 572
    check-cast p2, LS0/k;

    .line 573
    .line 574
    iget p1, p2, LS0/k;->a:I

    .line 575
    .line 576
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 577
    .line 578
    .line 579
    move-result-object p1

    .line 580
    return-object p1

    .line 581
    :pswitch_17
    check-cast p1, LT/b;

    .line 582
    .line 583
    check-cast p2, Ld0/S;

    .line 584
    .line 585
    iget-wide v0, p2, Ld0/S;->a:J

    .line 586
    .line 587
    new-instance v2, Ld0/w;

    .line 588
    .line 589
    invoke-direct {v2, v0, v1}, Ld0/w;-><init>(J)V

    .line 590
    .line 591
    .line 592
    sget-object v0, LH0/E;->p:LH0/D;

    .line 593
    .line 594
    invoke-static {v2, v0, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    move-result-object v0

    .line 598
    iget-wide v1, p2, Ld0/S;->b:J

    .line 599
    .line 600
    new-instance v3, Lc0/b;

    .line 601
    .line 602
    invoke-direct {v3, v1, v2}, Lc0/b;-><init>(J)V

    .line 603
    .line 604
    .line 605
    sget-object v1, LH0/E;->x:LH0/D;

    .line 606
    .line 607
    invoke-static {v3, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 608
    .line 609
    .line 610
    move-result-object p1

    .line 611
    iget p2, p2, Ld0/S;->c:F

    .line 612
    .line 613
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 614
    .line 615
    .line 616
    move-result-object p2

    .line 617
    filled-new-array {v0, p1, p2}, [Ljava/lang/Object;

    .line 618
    .line 619
    .line 620
    move-result-object p1

    .line 621
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 622
    .line 623
    .line 624
    move-result-object p1

    .line 625
    return-object p1

    .line 626
    :pswitch_18
    check-cast p1, LT/b;

    .line 627
    .line 628
    check-cast p2, LH0/N;

    .line 629
    .line 630
    iget-wide v0, p2, LH0/N;->a:J

    .line 631
    .line 632
    const/16 p1, 0x20

    .line 633
    .line 634
    shr-long/2addr v0, p1

    .line 635
    long-to-int p1, v0

    .line 636
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 637
    .line 638
    .line 639
    move-result-object p1

    .line 640
    iget-wide v0, p2, LH0/N;->a:J

    .line 641
    .line 642
    const-wide v2, 0xffffffffL

    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    and-long/2addr v0, v2

    .line 648
    long-to-int p2, v0

    .line 649
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 650
    .line 651
    .line 652
    move-result-object p2

    .line 653
    filled-new-array {p1, p2}, [Ljava/lang/Integer;

    .line 654
    .line 655
    .line 656
    move-result-object p1

    .line 657
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 658
    .line 659
    .line 660
    move-result-object p1

    .line 661
    return-object p1

    .line 662
    :pswitch_19
    check-cast p1, LT/b;

    .line 663
    .line 664
    check-cast p2, Ljava/util/List;

    .line 665
    .line 666
    new-instance v0, Ljava/util/ArrayList;

    .line 667
    .line 668
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 669
    .line 670
    .line 671
    move-result v1

    .line 672
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 673
    .line 674
    .line 675
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 676
    .line 677
    .line 678
    move-result v1

    .line 679
    const/4 v2, 0x0

    .line 680
    :goto_8
    if-ge v2, v1, :cond_e

    .line 681
    .line 682
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 683
    .line 684
    .line 685
    move-result-object v3

    .line 686
    check-cast v3, LH0/e;

    .line 687
    .line 688
    sget-object v4, LH0/E;->b:LF/r;

    .line 689
    .line 690
    invoke-static {v3, v4, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 691
    .line 692
    .line 693
    move-result-object v3

    .line 694
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 695
    .line 696
    .line 697
    add-int/lit8 v2, v2, 0x1

    .line 698
    .line 699
    goto :goto_8

    .line 700
    :cond_e
    return-object v0

    .line 701
    :pswitch_1a
    check-cast p1, LT/b;

    .line 702
    .line 703
    check-cast p2, LS0/a;

    .line 704
    .line 705
    iget p1, p2, LS0/a;->a:F

    .line 706
    .line 707
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 708
    .line 709
    .line 710
    move-result-object p1

    .line 711
    return-object p1

    .line 712
    :pswitch_1b
    check-cast p1, LT/b;

    .line 713
    .line 714
    check-cast p2, LH0/l;

    .line 715
    .line 716
    iget-object v0, p2, LH0/l;->a:Ljava/lang/String;

    .line 717
    .line 718
    iget-object p2, p2, LH0/l;->b:LH0/M;

    .line 719
    .line 720
    sget-object v1, LH0/E;->i:LF/r;

    .line 721
    .line 722
    invoke-static {p2, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 723
    .line 724
    .line 725
    move-result-object p1

    .line 726
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 727
    .line 728
    .line 729
    move-result-object p1

    .line 730
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 731
    .line 732
    .line 733
    move-result-object p1

    .line 734
    return-object p1

    .line 735
    :pswitch_1c
    check-cast p1, LT/b;

    .line 736
    .line 737
    check-cast p2, LL0/k;

    .line 738
    .line 739
    iget p1, p2, LL0/k;->d:I

    .line 740
    .line 741
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 742
    .line 743
    .line 744
    move-result-object p1

    .line 745
    return-object p1

    .line 746
    :pswitch_1d
    check-cast p1, LT/b;

    .line 747
    .line 748
    check-cast p2, LS0/q;

    .line 749
    .line 750
    iget-wide v0, p2, LS0/q;->a:J

    .line 751
    .line 752
    new-instance v2, LT0/q;

    .line 753
    .line 754
    invoke-direct {v2, v0, v1}, LT0/q;-><init>(J)V

    .line 755
    .line 756
    .line 757
    sget-object v0, LH0/E;->v:LH0/D;

    .line 758
    .line 759
    invoke-static {v2, v0, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 760
    .line 761
    .line 762
    move-result-object v1

    .line 763
    iget-wide v2, p2, LS0/q;->b:J

    .line 764
    .line 765
    new-instance p2, LT0/q;

    .line 766
    .line 767
    invoke-direct {p2, v2, v3}, LT0/q;-><init>(J)V

    .line 768
    .line 769
    .line 770
    invoke-static {p2, v0, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 771
    .line 772
    .line 773
    move-result-object p1

    .line 774
    filled-new-array {v1, p1}, [Ljava/lang/Object;

    .line 775
    .line 776
    .line 777
    move-result-object p1

    .line 778
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 779
    .line 780
    .line 781
    move-result-object p1

    .line 782
    return-object p1

    .line 783
    :pswitch_1e
    check-cast p1, LT/b;

    .line 784
    .line 785
    check-cast p2, LS0/p;

    .line 786
    .line 787
    iget p1, p2, LS0/p;->a:F

    .line 788
    .line 789
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 790
    .line 791
    .line 792
    move-result-object p1

    .line 793
    iget p2, p2, LS0/p;->b:F

    .line 794
    .line 795
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 796
    .line 797
    .line 798
    move-result-object p2

    .line 799
    filled-new-array {p1, p2}, [Ljava/lang/Float;

    .line 800
    .line 801
    .line 802
    move-result-object p1

    .line 803
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 804
    .line 805
    .line 806
    move-result-object p1

    .line 807
    return-object p1

    .line 808
    :pswitch_1f
    check-cast p1, LT/b;

    .line 809
    .line 810
    check-cast p2, LS0/l;

    .line 811
    .line 812
    iget p1, p2, LS0/l;->a:I

    .line 813
    .line 814
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 815
    .line 816
    .line 817
    move-result-object p1

    .line 818
    return-object p1

    .line 819
    :pswitch_20
    check-cast p1, LT/b;

    .line 820
    .line 821
    check-cast p2, LH0/g;

    .line 822
    .line 823
    iget-object v0, p2, LH0/g;->e:Ljava/lang/String;

    .line 824
    .line 825
    iget-object p2, p2, LH0/g;->d:Ljava/util/List;

    .line 826
    .line 827
    sget-object v1, LH0/E;->a:LF/r;

    .line 828
    .line 829
    invoke-static {p2, v1, p1}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 830
    .line 831
    .line 832
    move-result-object p1

    .line 833
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 834
    .line 835
    .line 836
    move-result-object p1

    .line 837
    invoke-static {p1}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 838
    .line 839
    .line 840
    move-result-object p1

    .line 841
    return-object p1

    .line 842
    :pswitch_21
    check-cast p1, Lf0/d;

    .line 843
    .line 844
    check-cast p2, LU1/c;

    .line 845
    .line 846
    const-string v0, "<this>"

    .line 847
    .line 848
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 849
    .line 850
    .line 851
    const-string v0, "it"

    .line 852
    .line 853
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 854
    .line 855
    .line 856
    invoke-interface {p2, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 857
    .line 858
    .line 859
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 860
    .line 861
    return-object p1

    .line 862
    :pswitch_22
    check-cast p1, Lc0/e;

    .line 863
    .line 864
    check-cast p2, Lc0/b;

    .line 865
    .line 866
    return-object p2

    .line 867
    :pswitch_23
    check-cast p1, LB1/t;

    .line 868
    .line 869
    check-cast p2, Lc0/b;

    .line 870
    .line 871
    const-string p2, "$this$DampedDragAnimation"

    .line 872
    .line 873
    invoke-static {p1, p2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 874
    .line 875
    .line 876
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 877
    .line 878
    return-object p1

    .line 879
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
    .end packed-switch
.end method
