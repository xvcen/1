.class public final synthetic LA1/F;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LB1/t;


# direct methods
.method public synthetic constructor <init>(LB1/t;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/F;->d:I

    iput-object p1, p0, LA1/F;->e:LB1/t;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LA1/F;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/F;->e:LB1/t;

    .line 7
    .line 8
    iget-object v0, v0, LB1/t;->m:Ll/c;

    .line 9
    .line 10
    invoke-virtual {v0}, Ll/c;->c()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0

    .line 25
    :pswitch_0
    iget-object v0, p0, LA1/F;->e:LB1/t;

    .line 26
    .line 27
    iget-object v1, v0, LB1/t;->f:LA1/I;

    .line 28
    .line 29
    invoke-virtual {v1, v0}, LA1/I;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    iget-object v1, v0, LB1/t;->a:Lc2/s;

    .line 33
    .line 34
    new-instance v2, LB1/p;

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-direct {v2, v0, v3}, LB1/p;-><init>(LB1/t;LN1/c;)V

    .line 38
    .line 39
    .line 40
    const/4 v0, 0x3

    .line 41
    invoke-static {v1, v3, v2, v0}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 42
    .line 43
    .line 44
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 45
    .line 46
    return-object v0

    .line 47
    :pswitch_1
    iget-object v0, p0, LA1/F;->e:LB1/t;

    .line 48
    .line 49
    invoke-virtual {v0}, LB1/t;->a()F

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    sget-object v1, LF1/a;->f:LF1/a;

    .line 54
    .line 55
    iget v2, v1, LF1/a;->a:F

    .line 56
    .line 57
    const/high16 v3, 0x3fc00000    # 1.5f

    .line 58
    .line 59
    div-float/2addr v2, v3

    .line 60
    iget v4, v1, LF1/a;->b:F

    .line 61
    .line 62
    div-float/2addr v4, v3

    .line 63
    const/16 v3, 0x8

    .line 64
    .line 65
    invoke-static {v1, v2, v4, v0, v3}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    return-object v0

    .line 70
    :pswitch_2
    iget-object v0, p0, LA1/F;->e:LB1/t;

    .line 71
    .line 72
    invoke-virtual {v0}, LB1/t;->a()F

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    new-instance v1, LG1/a;

    .line 77
    .line 78
    const/4 v2, 0x4

    .line 79
    int-to-float v2, v2

    .line 80
    mul-float/2addr v2, v0

    .line 81
    const/16 v3, 0x16

    .line 82
    .line 83
    invoke-direct {v1, v2, v0, v3}, LG1/a;-><init>(FFI)V

    .line 84
    .line 85
    .line 86
    return-object v1

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
