.class public final synthetic LA1/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LB1/t;


# direct methods
.method public synthetic constructor <init>(LB1/t;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/G;->d:I

    iput-object p1, p0, LA1/G;->e:LB1/t;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, LA1/G;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ll/c;

    .line 7
    .line 8
    iget-object p1, p0, LA1/G;->e:LB1/t;

    .line 9
    .line 10
    iget-object v0, p1, LB1/t;->s:Lq0/w;

    .line 11
    .line 12
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 13
    .line 14
    .line 15
    move-result-wide v1

    .line 16
    iget-object v3, p1, LB1/t;->m:Ll/c;

    .line 17
    .line 18
    invoke-virtual {v3}, Ll/c;->c()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    check-cast v3, Ljava/lang/Number;

    .line 23
    .line 24
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    int-to-long v3, v3

    .line 33
    const/4 v5, 0x0

    .line 34
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 35
    .line 36
    .line 37
    move-result v6

    .line 38
    int-to-long v6, v6

    .line 39
    const/16 v8, 0x20

    .line 40
    .line 41
    shl-long/2addr v3, v8

    .line 42
    const-wide v8, 0xffffffffL

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    and-long/2addr v6, v8

    .line 48
    or-long/2addr v3, v6

    .line 49
    iget-object v6, v0, Lq0/w;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v6, Lr0/b;

    .line 52
    .line 53
    invoke-virtual {v6, v1, v2, v3, v4}, Lr0/b;->a(JJ)V

    .line 54
    .line 55
    .line 56
    const v1, 0x7f7fffff    # Float.MAX_VALUE

    .line 57
    .line 58
    .line 59
    invoke-static {v1, v1}, LT0/l;->c(FF)J

    .line 60
    .line 61
    .line 62
    move-result-wide v1

    .line 63
    invoke-virtual {v0, v1, v2}, Lq0/w;->d(J)J

    .line 64
    .line 65
    .line 66
    move-result-wide v0

    .line 67
    invoke-static {v0, v1}, LT0/s;->b(J)F

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    iget-object v1, p1, LB1/t;->b:LY1/a;

    .line 72
    .line 73
    iget v1, v1, LY1/a;->a:F

    .line 74
    .line 75
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    sub-float/2addr v1, v2

    .line 92
    div-float/2addr v0, v1

    .line 93
    iget-object v1, p1, LB1/t;->a:Lc2/s;

    .line 94
    .line 95
    new-instance v2, LB1/s;

    .line 96
    .line 97
    const/4 v3, 0x0

    .line 98
    invoke-direct {v2, p1, v0, v3}, LB1/s;-><init>(LB1/t;FLN1/c;)V

    .line 99
    .line 100
    .line 101
    const/4 p1, 0x3

    .line 102
    invoke-static {v1, v3, v2, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 103
    .line 104
    .line 105
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 106
    .line 107
    return-object p1

    .line 108
    :pswitch_0
    check-cast p1, Lq0/u;

    .line 109
    .line 110
    const-wide v0, -0x30f73377dbfaL

    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    iget-object p1, p0, LA1/G;->e:LB1/t;

    .line 123
    .line 124
    iget-object v0, p1, LB1/t;->f:LA1/I;

    .line 125
    .line 126
    invoke-virtual {v0, p1}, LA1/I;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    iget-object v0, p1, LB1/t;->a:Lc2/s;

    .line 130
    .line 131
    new-instance v1, LB1/p;

    .line 132
    .line 133
    const/4 v2, 0x0

    .line 134
    invoke-direct {v1, p1, v2}, LB1/p;-><init>(LB1/t;LN1/c;)V

    .line 135
    .line 136
    .line 137
    const/4 p1, 0x3

    .line 138
    invoke-static {v0, v2, v1, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 139
    .line 140
    .line 141
    goto :goto_0

    .line 142
    :pswitch_1
    check-cast p1, Lq0/u;

    .line 143
    .line 144
    const-wide v0, -0x30e83377dbfaL

    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    iget-object p1, p0, LA1/G;->e:LB1/t;

    .line 157
    .line 158
    iget-object v0, p1, LB1/t;->e:LA1/E;

    .line 159
    .line 160
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 161
    .line 162
    .line 163
    iget-object v0, p1, LB1/t;->s:Lq0/w;

    .line 164
    .line 165
    iget-object v0, v0, Lq0/w;->b:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v0, Lr0/b;

    .line 168
    .line 169
    iget-object v1, v0, Lr0/b;->a:Lr0/d;

    .line 170
    .line 171
    iget-object v2, v1, Lr0/d;->d:[Lr0/a;

    .line 172
    .line 173
    array-length v3, v2

    .line 174
    const/4 v4, 0x0

    .line 175
    invoke-static {v2, v4, v3}, LK1/l;->X([Ljava/lang/Object;II)V

    .line 176
    .line 177
    .line 178
    iput v4, v1, Lr0/d;->e:I

    .line 179
    .line 180
    iget-object v1, v0, Lr0/b;->b:Lr0/d;

    .line 181
    .line 182
    iget-object v2, v1, Lr0/d;->d:[Lr0/a;

    .line 183
    .line 184
    array-length v3, v2

    .line 185
    invoke-static {v2, v4, v3}, LK1/l;->X([Ljava/lang/Object;II)V

    .line 186
    .line 187
    .line 188
    iput v4, v1, Lr0/d;->e:I

    .line 189
    .line 190
    const-wide/16 v1, 0x0

    .line 191
    .line 192
    iput-wide v1, v0, Lr0/b;->c:J

    .line 193
    .line 194
    iget-object v0, p1, LB1/t;->a:Lc2/s;

    .line 195
    .line 196
    new-instance v1, LB1/i;

    .line 197
    .line 198
    const/4 v2, 0x0

    .line 199
    invoke-direct {v1, p1, v2}, LB1/i;-><init>(LB1/t;LN1/c;)V

    .line 200
    .line 201
    .line 202
    const/4 p1, 0x3

    .line 203
    invoke-static {v0, v2, v1, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 204
    .line 205
    .line 206
    goto :goto_0

    .line 207
    :pswitch_2
    check-cast p1, LC1/f;

    .line 208
    .line 209
    const-string v0, "$this$drawBackdrop"

    .line 210
    .line 211
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    iget-object v0, p0, LA1/G;->e:LB1/t;

    .line 215
    .line 216
    invoke-virtual {v0}, LB1/t;->a()F

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    const/16 v1, 0x8

    .line 221
    .line 222
    int-to-float v1, v1

    .line 223
    iget v2, p1, LC1/f;->d:F

    .line 224
    .line 225
    mul-float/2addr v2, v1

    .line 226
    const/high16 v1, 0x3f800000    # 1.0f

    .line 227
    .line 228
    sub-float/2addr v1, v0

    .line 229
    mul-float/2addr v1, v2

    .line 230
    invoke-static {p1, v1}, LX1/a;->D(LC1/f;F)V

    .line 231
    .line 232
    .line 233
    const/4 v1, 0x5

    .line 234
    int-to-float v1, v1

    .line 235
    iget v2, p1, LC1/f;->d:F

    .line 236
    .line 237
    mul-float/2addr v1, v2

    .line 238
    mul-float/2addr v1, v0

    .line 239
    const/16 v3, 0xa

    .line 240
    .line 241
    int-to-float v3, v3

    .line 242
    mul-float/2addr v2, v3

    .line 243
    mul-float/2addr v2, v0

    .line 244
    const/4 v0, 0x0

    .line 245
    invoke-static {p1, v1, v2, v0}, La/a;->D(LC1/f;FFZ)V

    .line 246
    .line 247
    .line 248
    goto/16 :goto_0

    .line 249
    .line 250
    :pswitch_3
    move-object v0, p1

    .line 251
    check-cast v0, Lf0/d;

    .line 252
    .line 253
    const-string p1, "$this$drawBackdrop"

    .line 254
    .line 255
    invoke-static {v0, p1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    iget-object p1, p0, LA1/G;->e:LB1/t;

    .line 259
    .line 260
    invoke-virtual {p1}, LB1/t;->a()F

    .line 261
    .line 262
    .line 263
    move-result p1

    .line 264
    sget-wide v1, Ld0/w;->c:J

    .line 265
    .line 266
    const/high16 v3, 0x3f800000    # 1.0f

    .line 267
    .line 268
    sub-float/2addr v3, p1

    .line 269
    invoke-static {v1, v2, v3}, Ld0/w;->b(JF)J

    .line 270
    .line 271
    .line 272
    move-result-wide v1

    .line 273
    const/4 v5, 0x0

    .line 274
    const/16 v6, 0x7e

    .line 275
    .line 276
    const-wide/16 v3, 0x0

    .line 277
    .line 278
    invoke-static/range {v0 .. v6}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 279
    .line 280
    .line 281
    goto/16 :goto_0

    .line 282
    .line 283
    :pswitch_4
    check-cast p1, Ld0/E;

    .line 284
    .line 285
    const-string v0, "$this$drawBackdrop"

    .line 286
    .line 287
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    iget-object v0, p0, LA1/G;->e:LB1/t;

    .line 291
    .line 292
    iget-object v1, v0, LB1/t;->p:Ll/c;

    .line 293
    .line 294
    invoke-virtual {v1}, Ll/c;->c()Ljava/lang/Object;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    check-cast v1, Ljava/lang/Number;

    .line 299
    .line 300
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 301
    .line 302
    .line 303
    move-result v1

    .line 304
    invoke-interface {p1, v1}, Ld0/E;->l(F)V

    .line 305
    .line 306
    .line 307
    iget-object v1, v0, LB1/t;->q:Ll/c;

    .line 308
    .line 309
    invoke-virtual {v1}, Ll/c;->c()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v1

    .line 313
    check-cast v1, Ljava/lang/Number;

    .line 314
    .line 315
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 316
    .line 317
    .line 318
    move-result v1

    .line 319
    invoke-interface {p1, v1}, Ld0/E;->r(F)V

    .line 320
    .line 321
    .line 322
    iget-object v0, v0, LB1/t;->n:Ll/c;

    .line 323
    .line 324
    invoke-virtual {v0}, Ll/c;->c()Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    check-cast v0, Ljava/lang/Number;

    .line 329
    .line 330
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    const/high16 v1, 0x42480000    # 50.0f

    .line 335
    .line 336
    div-float/2addr v0, v1

    .line 337
    invoke-interface {p1}, Ld0/E;->e()F

    .line 338
    .line 339
    .line 340
    move-result v1

    .line 341
    const/high16 v2, 0x3f400000    # 0.75f

    .line 342
    .line 343
    mul-float/2addr v2, v0

    .line 344
    const v3, -0x41b33333    # -0.2f

    .line 345
    .line 346
    .line 347
    cmpg-float v4, v2, v3

    .line 348
    .line 349
    if-gez v4, :cond_0

    .line 350
    .line 351
    move v2, v3

    .line 352
    :cond_0
    const v4, 0x3e4ccccd    # 0.2f

    .line 353
    .line 354
    .line 355
    cmpl-float v5, v2, v4

    .line 356
    .line 357
    if-lez v5, :cond_1

    .line 358
    .line 359
    move v2, v4

    .line 360
    :cond_1
    const/high16 v5, 0x3f800000    # 1.0f

    .line 361
    .line 362
    sub-float v2, v5, v2

    .line 363
    .line 364
    div-float/2addr v1, v2

    .line 365
    invoke-interface {p1, v1}, Ld0/E;->l(F)V

    .line 366
    .line 367
    .line 368
    invoke-interface {p1}, Ld0/E;->t()F

    .line 369
    .line 370
    .line 371
    move-result v1

    .line 372
    const/high16 v2, 0x3e800000    # 0.25f

    .line 373
    .line 374
    mul-float/2addr v0, v2

    .line 375
    cmpg-float v2, v0, v3

    .line 376
    .line 377
    if-gez v2, :cond_2

    .line 378
    .line 379
    goto :goto_1

    .line 380
    :cond_2
    move v3, v0

    .line 381
    :goto_1
    cmpl-float v0, v3, v4

    .line 382
    .line 383
    if-lez v0, :cond_3

    .line 384
    .line 385
    goto :goto_2

    .line 386
    :cond_3
    move v4, v3

    .line 387
    :goto_2
    sub-float/2addr v5, v4

    .line 388
    mul-float/2addr v5, v1

    .line 389
    invoke-interface {p1, v5}, Ld0/E;->r(F)V

    .line 390
    .line 391
    .line 392
    goto/16 :goto_0

    .line 393
    .line 394
    nop

    .line 395
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
