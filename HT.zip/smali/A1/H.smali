.class public final synthetic LA1/H;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LC1/a;ZLU1/c;I)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, LA1/H;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/H;->g:Ljava/lang/Object;

    iput-boolean p2, p0, LA1/H;->e:Z

    iput-object p3, p0, LA1/H;->h:Ljava/lang/Object;

    iput p4, p0, LA1/H;->f:I

    return-void
.end method

.method public synthetic constructor <init>(LW/q;LU1/a;ZI)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, LA1/H;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/H;->g:Ljava/lang/Object;

    iput-object p2, p0, LA1/H;->h:Ljava/lang/Object;

    iput-boolean p3, p0, LA1/H;->e:Z

    iput p4, p0, LA1/H;->f:I

    return-void
.end method

.method public synthetic constructor <init>(ZLS0/j;LH/m0;I)V
    .locals 1

    .line 3
    const/4 v0, 0x2

    iput v0, p0, LA1/H;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LA1/H;->e:Z

    iput-object p2, p0, LA1/H;->g:Ljava/lang/Object;

    iput-object p3, p0, LA1/H;->h:Ljava/lang/Object;

    iput p4, p0, LA1/H;->f:I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LA1/H;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/H;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LS0/j;

    .line 9
    .line 10
    iget-object v1, p0, LA1/H;->h:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LH/m0;

    .line 13
    .line 14
    check-cast p1, LI/r;

    .line 15
    .line 16
    check-cast p2, Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget p2, p0, LA1/H;->f:I

    .line 22
    .line 23
    or-int/lit8 p2, p2, 0x1

    .line 24
    .line 25
    invoke-static {p2}, LI/k;->x(I)I

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    iget-boolean v2, p0, LA1/H;->e:Z

    .line 30
    .line 31
    invoke-static {v2, v0, v1, p1, p2}, La/a;->d(ZLS0/j;LH/m0;LI/r;I)V

    .line 32
    .line 33
    .line 34
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 35
    .line 36
    return-object p1

    .line 37
    :pswitch_0
    iget-object v0, p0, LA1/H;->g:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, LW/q;

    .line 40
    .line 41
    iget-object v1, p0, LA1/H;->h:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v1, LU1/a;

    .line 44
    .line 45
    check-cast p1, LI/r;

    .line 46
    .line 47
    check-cast p2, Ljava/lang/Integer;

    .line 48
    .line 49
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    iget p2, p0, LA1/H;->f:I

    .line 53
    .line 54
    or-int/lit8 p2, p2, 0x1

    .line 55
    .line 56
    invoke-static {p2}, LI/k;->x(I)I

    .line 57
    .line 58
    .line 59
    move-result p2

    .line 60
    iget-boolean v2, p0, LA1/H;->e:Z

    .line 61
    .line 62
    invoke-static {v0, v1, v2, p1, p2}, La/a;->c(LW/q;LU1/a;ZLI/r;I)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :pswitch_1
    iget-object v0, p0, LA1/H;->g:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v0, LC1/a;

    .line 69
    .line 70
    iget-object v1, p0, LA1/H;->h:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v1, LU1/c;

    .line 73
    .line 74
    check-cast p1, LI/r;

    .line 75
    .line 76
    check-cast p2, Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    .line 80
    .line 81
    iget p2, p0, LA1/H;->f:I

    .line 82
    .line 83
    or-int/lit8 p2, p2, 0x1

    .line 84
    .line 85
    invoke-static {p2}, LI/k;->x(I)I

    .line 86
    .line 87
    .line 88
    move-result p2

    .line 89
    iget-boolean v2, p0, LA1/H;->e:Z

    .line 90
    .line 91
    invoke-static {v0, v2, v1, p1, p2}, LX1/a;->m(LC1/a;ZLU1/c;LI/r;I)V

    .line 92
    .line 93
    .line 94
    goto :goto_0

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
