.class public final synthetic LA1/I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:LJ1/c;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LU1/a;ZLd0/g;Ld0/o;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, LA1/I;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/I;->f:LJ1/c;

    iput-boolean p2, p0, LA1/I;->e:Z

    iput-object p3, p0, LA1/I;->g:Ljava/lang/Object;

    iput-object p4, p0, LA1/I;->h:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ZLU1/c;LI/b0;LI/i0;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, LA1/I;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LA1/I;->e:Z

    iput-object p2, p0, LA1/I;->f:LJ1/c;

    iput-object p3, p0, LA1/I;->g:Ljava/lang/Object;

    iput-object p4, p0, LA1/I;->h:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, LA1/I;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/I;->f:LJ1/c;

    .line 7
    .line 8
    check-cast v0, LU1/a;

    .line 9
    .line 10
    iget-object v1, p0, LA1/I;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Ld0/g;

    .line 13
    .line 14
    iget-object v2, p0, LA1/I;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Ld0/o;

    .line 17
    .line 18
    check-cast p1, Lw0/G;

    .line 19
    .line 20
    invoke-virtual {p1}, Lw0/G;->c()V

    .line 21
    .line 22
    .line 23
    iget-object p1, p1, Lw0/G;->d:Lf0/b;

    .line 24
    .line 25
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/lang/Boolean;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_0

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    iget-boolean v0, p0, LA1/I;->e:Z

    .line 39
    .line 40
    if-eqz v0, :cond_1

    .line 41
    .line 42
    invoke-interface {p1}, Lf0/d;->d0()J

    .line 43
    .line 44
    .line 45
    move-result-wide v3

    .line 46
    iget-object v0, p1, Lf0/b;->e:LI/e0;

    .line 47
    .line 48
    invoke-virtual {v0}, LI/e0;->t()J

    .line 49
    .line 50
    .line 51
    move-result-wide v5

    .line 52
    invoke-virtual {v0}, LI/e0;->m()Ld0/u;

    .line 53
    .line 54
    .line 55
    move-result-object v7

    .line 56
    invoke-interface {v7}, Ld0/u;->k()V

    .line 57
    .line 58
    .line 59
    :try_start_0
    iget-object v7, v0, LI/e0;->d:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v7, LA0/h;

    .line 62
    .line 63
    const/high16 v8, -0x40800000    # -1.0f

    .line 64
    .line 65
    const/high16 v9, 0x3f800000    # 1.0f

    .line 66
    .line 67
    invoke-virtual {v7, v8, v9, v3, v4}, LA0/h;->r(FFJ)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p1, v1, v2}, Lf0/b;->v(Ld0/g;Ld0/o;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0}, LI/e0;->m()Ld0/u;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-interface {p1}, Ld0/u;->i()V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0, v5, v6}, LI/e0;->E(J)V

    .line 81
    .line 82
    .line 83
    goto :goto_0

    .line 84
    :catchall_0
    move-exception p1

    .line 85
    invoke-virtual {v0}, LI/e0;->m()Ld0/u;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    invoke-interface {v1}, Ld0/u;->i()V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0, v5, v6}, LI/e0;->E(J)V

    .line 93
    .line 94
    .line 95
    throw p1

    .line 96
    :cond_1
    invoke-virtual {p1, v1, v2}, Lf0/b;->v(Ld0/g;Ld0/o;)V

    .line 97
    .line 98
    .line 99
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 100
    .line 101
    return-object p1

    .line 102
    :pswitch_0
    iget-object v0, p0, LA1/I;->f:LJ1/c;

    .line 103
    .line 104
    check-cast v0, LU1/c;

    .line 105
    .line 106
    iget-object v1, p0, LA1/I;->g:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v1, LI/b0;

    .line 109
    .line 110
    iget-object v2, p0, LA1/I;->h:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast v2, LI/i0;

    .line 113
    .line 114
    check-cast p1, LB1/t;

    .line 115
    .line 116
    const-string v3, "$this$DampedDragAnimation"

    .line 117
    .line 118
    invoke-static {p1, v3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-interface {v1}, LI/a1;->getValue()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    check-cast v3, Ljava/lang/Boolean;

    .line 126
    .line 127
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    const/4 v4, 0x0

    .line 132
    const/high16 v5, 0x3f800000    # 1.0f

    .line 133
    .line 134
    if-eqz v3, :cond_3

    .line 135
    .line 136
    iget-object p1, p1, LB1/t;->m:Ll/c;

    .line 137
    .line 138
    iget-object p1, p1, Ll/c;->e:LI/m0;

    .line 139
    .line 140
    invoke-virtual {p1}, LI/m0;->getValue()Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    check-cast p1, Ljava/lang/Number;

    .line 145
    .line 146
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 147
    .line 148
    .line 149
    move-result p1

    .line 150
    const/high16 v3, 0x3f000000    # 0.5f

    .line 151
    .line 152
    cmpl-float p1, p1, v3

    .line 153
    .line 154
    if-ltz p1, :cond_4

    .line 155
    .line 156
    :cond_2
    move v4, v5

    .line 157
    goto :goto_1

    .line 158
    :cond_3
    iget-boolean p1, p0, LA1/I;->e:Z

    .line 159
    .line 160
    if-eqz p1, :cond_2

    .line 161
    .line 162
    :cond_4
    :goto_1
    invoke-virtual {v2, v4}, LI/i0;->h(F)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v2}, LI/i0;->g()F

    .line 166
    .line 167
    .line 168
    move-result p1

    .line 169
    cmpg-float p1, p1, v5

    .line 170
    .line 171
    if-nez p1, :cond_5

    .line 172
    .line 173
    const/4 p1, 0x1

    .line 174
    goto :goto_2

    .line 175
    :cond_5
    const/4 p1, 0x0

    .line 176
    :goto_2
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 184
    .line 185
    invoke-interface {v1, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 189
    .line 190
    return-object p1

    .line 191
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
