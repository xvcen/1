.class public final synthetic LA1/J;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/f;


# instance fields
.field public final synthetic d:F

.field public final synthetic e:Z

.field public final synthetic f:LI/b0;

.field public final synthetic g:LI/i0;


# direct methods
.method public synthetic constructor <init>(FZLI/b0;LI/i0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LA1/J;->d:F

    iput-boolean p2, p0, LA1/J;->e:Z

    iput-object p3, p0, LA1/J;->f:LI/b0;

    iput-object p4, p0, LA1/J;->g:LI/i0;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    check-cast p1, LB1/t;

    .line 2
    .line 3
    check-cast p2, LT0/n;

    .line 4
    .line 5
    check-cast p3, Lc0/b;

    .line 6
    .line 7
    const-string p2, "$this$DampedDragAnimation"

    .line 8
    .line 9
    invoke-static {p1, p2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, LA1/J;->f:LI/b0;

    .line 13
    .line 14
    invoke-interface {p1}, LI/a1;->getValue()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    check-cast p2, Ljava/lang/Boolean;

    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    const/16 v0, 0x20

    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    if-nez p2, :cond_1

    .line 28
    .line 29
    iget-wide v2, p3, Lc0/b;->a:J

    .line 30
    .line 31
    shr-long/2addr v2, v0

    .line 32
    long-to-int p2, v2

    .line 33
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    cmpg-float p2, p2, v1

    .line 38
    .line 39
    const/4 v2, 0x1

    .line 40
    if-nez p2, :cond_0

    .line 41
    .line 42
    move p2, v2

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    const/4 p2, 0x0

    .line 45
    :goto_0
    xor-int/2addr p2, v2

    .line 46
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-interface {p1, p2}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    iget-wide p1, p3, Lc0/b;->a:J

    .line 54
    .line 55
    shr-long/2addr p1, v0

    .line 56
    long-to-int p1, p1

    .line 57
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    iget p2, p0, LA1/J;->d:F

    .line 62
    .line 63
    div-float/2addr p1, p2

    .line 64
    iget-boolean p2, p0, LA1/J;->e:Z

    .line 65
    .line 66
    iget-object p3, p0, LA1/J;->g:LI/i0;

    .line 67
    .line 68
    const/high16 v0, 0x3f800000    # 1.0f

    .line 69
    .line 70
    if-eqz p2, :cond_4

    .line 71
    .line 72
    invoke-virtual {p3}, LI/i0;->g()F

    .line 73
    .line 74
    .line 75
    move-result p2

    .line 76
    add-float/2addr p2, p1

    .line 77
    cmpg-float p1, p2, v1

    .line 78
    .line 79
    if-gez p1, :cond_2

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_2
    move v1, p2

    .line 83
    :goto_1
    cmpl-float p1, v1, v0

    .line 84
    .line 85
    if-lez p1, :cond_3

    .line 86
    .line 87
    goto :goto_3

    .line 88
    :cond_3
    move v0, v1

    .line 89
    goto :goto_3

    .line 90
    :cond_4
    invoke-virtual {p3}, LI/i0;->g()F

    .line 91
    .line 92
    .line 93
    move-result p2

    .line 94
    sub-float/2addr p2, p1

    .line 95
    cmpg-float p1, p2, v1

    .line 96
    .line 97
    if-gez p1, :cond_5

    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_5
    move v1, p2

    .line 101
    :goto_2
    cmpl-float p1, v1, v0

    .line 102
    .line 103
    if-lez p1, :cond_3

    .line 104
    .line 105
    :goto_3
    invoke-virtual {p3, v0}, LI/i0;->h(F)V

    .line 106
    .line 107
    .line 108
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 109
    .line 110
    return-object p1
.end method
