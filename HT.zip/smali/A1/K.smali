.class public final synthetic LA1/K;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:J

.field public final synthetic e:J

.field public final synthetic f:LB1/t;


# direct methods
.method public synthetic constructor <init>(JJLB1/t;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LA1/K;->d:J

    iput-wide p3, p0, LA1/K;->e:J

    iput-object p5, p0, LA1/K;->f:LB1/t;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lf0/d;

    .line 6
    .line 7
    const-string v2, "$this$drawBehind"

    .line 8
    .line 9
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object v2, v0, LA1/K;->f:LB1/t;

    .line 13
    .line 14
    iget-object v2, v2, LB1/t;->m:Ll/c;

    .line 15
    .line 16
    invoke-virtual {v2}, Ll/c;->c()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    check-cast v2, Ljava/lang/Number;

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    sget-object v3, Le0/d;->x:Le0/l;

    .line 27
    .line 28
    iget-wide v4, v0, LA1/K;->d:J

    .line 29
    .line 30
    invoke-static {v4, v5, v3}, Ld0/w;->a(JLe0/c;)J

    .line 31
    .line 32
    .line 33
    move-result-wide v4

    .line 34
    iget-wide v6, v0, LA1/K;->e:J

    .line 35
    .line 36
    invoke-static {v6, v7, v3}, Ld0/w;->a(JLe0/c;)J

    .line 37
    .line 38
    .line 39
    move-result-wide v8

    .line 40
    invoke-static {v4, v5}, Ld0/w;->d(J)F

    .line 41
    .line 42
    .line 43
    move-result v10

    .line 44
    invoke-static {v4, v5}, Ld0/w;->g(J)F

    .line 45
    .line 46
    .line 47
    move-result v11

    .line 48
    invoke-static {v4, v5}, Ld0/w;->f(J)F

    .line 49
    .line 50
    .line 51
    move-result v12

    .line 52
    invoke-static {v4, v5}, Ld0/w;->e(J)F

    .line 53
    .line 54
    .line 55
    move-result v4

    .line 56
    invoke-static {v8, v9}, Ld0/w;->d(J)F

    .line 57
    .line 58
    .line 59
    move-result v5

    .line 60
    invoke-static {v8, v9}, Ld0/w;->g(J)F

    .line 61
    .line 62
    .line 63
    move-result v13

    .line 64
    invoke-static {v8, v9}, Ld0/w;->f(J)F

    .line 65
    .line 66
    .line 67
    move-result v14

    .line 68
    invoke-static {v8, v9}, Ld0/w;->e(J)F

    .line 69
    .line 70
    .line 71
    move-result v8

    .line 72
    const/4 v9, 0x0

    .line 73
    cmpg-float v15, v2, v9

    .line 74
    .line 75
    if-gez v15, :cond_0

    .line 76
    .line 77
    move v2, v9

    .line 78
    :cond_0
    const/high16 v15, 0x3f800000    # 1.0f

    .line 79
    .line 80
    cmpl-float v16, v2, v15

    .line 81
    .line 82
    if-lez v16, :cond_1

    .line 83
    .line 84
    move v2, v15

    .line 85
    :cond_1
    invoke-static {v11, v13, v2}, LT0/g;->C(FFF)F

    .line 86
    .line 87
    .line 88
    move-result v11

    .line 89
    invoke-static {v12, v14, v2}, LT0/g;->C(FFF)F

    .line 90
    .line 91
    .line 92
    move-result v12

    .line 93
    invoke-static {v4, v8, v2}, LT0/g;->C(FFF)F

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    invoke-static {v10, v5, v2}, LT0/g;->C(FFF)F

    .line 98
    .line 99
    .line 100
    move-result v2

    .line 101
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 102
    .line 103
    .line 104
    move-result v5

    .line 105
    ushr-int/lit8 v8, v5, 0x1f

    .line 106
    .line 107
    ushr-int/lit8 v10, v5, 0x17

    .line 108
    .line 109
    const/16 v11, 0xff

    .line 110
    .line 111
    and-int/2addr v10, v11

    .line 112
    const v13, 0x7fffff

    .line 113
    .line 114
    .line 115
    and-int v14, v5, v13

    .line 116
    .line 117
    const/high16 v16, 0x800000

    .line 118
    .line 119
    move/from16 p1, v13

    .line 120
    .line 121
    const/16 v13, -0xa

    .line 122
    .line 123
    const/16 v17, 0x31

    .line 124
    .line 125
    const/16 v18, 0x200

    .line 126
    .line 127
    const/16 v19, 0x0

    .line 128
    .line 129
    const/16 v9, 0x1f

    .line 130
    .line 131
    if-ne v10, v11, :cond_3

    .line 132
    .line 133
    if-eqz v14, :cond_2

    .line 134
    .line 135
    move/from16 v5, v18

    .line 136
    .line 137
    goto :goto_0

    .line 138
    :cond_2
    move/from16 v5, v19

    .line 139
    .line 140
    :goto_0
    move v10, v9

    .line 141
    goto :goto_2

    .line 142
    :cond_3
    add-int/lit8 v10, v10, -0x70

    .line 143
    .line 144
    if-lt v10, v9, :cond_4

    .line 145
    .line 146
    move/from16 v10, v17

    .line 147
    .line 148
    move/from16 v5, v19

    .line 149
    .line 150
    goto :goto_2

    .line 151
    :cond_4
    if-gtz v10, :cond_7

    .line 152
    .line 153
    if-lt v10, v13, :cond_6

    .line 154
    .line 155
    or-int v5, v14, v16

    .line 156
    .line 157
    rsub-int/lit8 v10, v10, 0x1

    .line 158
    .line 159
    shr-int/2addr v5, v10

    .line 160
    and-int/lit16 v10, v5, 0x1000

    .line 161
    .line 162
    if-eqz v10, :cond_5

    .line 163
    .line 164
    add-int/lit16 v5, v5, 0x2000

    .line 165
    .line 166
    :cond_5
    shr-int/lit8 v5, v5, 0xd

    .line 167
    .line 168
    move/from16 v10, v19

    .line 169
    .line 170
    goto :goto_2

    .line 171
    :cond_6
    move/from16 v5, v19

    .line 172
    .line 173
    move v10, v5

    .line 174
    goto :goto_2

    .line 175
    :cond_7
    shr-int/lit8 v14, v14, 0xd

    .line 176
    .line 177
    and-int/lit16 v5, v5, 0x1000

    .line 178
    .line 179
    if-eqz v5, :cond_8

    .line 180
    .line 181
    shl-int/lit8 v5, v10, 0xa

    .line 182
    .line 183
    or-int/2addr v5, v14

    .line 184
    add-int/lit8 v5, v5, 0x1

    .line 185
    .line 186
    shl-int/lit8 v8, v8, 0xf

    .line 187
    .line 188
    or-int/2addr v5, v8

    .line 189
    :goto_1
    int-to-short v5, v5

    .line 190
    goto :goto_3

    .line 191
    :cond_8
    move v5, v14

    .line 192
    :goto_2
    shl-int/lit8 v8, v8, 0xf

    .line 193
    .line 194
    shl-int/lit8 v10, v10, 0xa

    .line 195
    .line 196
    or-int/2addr v8, v10

    .line 197
    or-int/2addr v5, v8

    .line 198
    goto :goto_1

    .line 199
    :goto_3
    invoke-static {v12}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 200
    .line 201
    .line 202
    move-result v8

    .line 203
    ushr-int/lit8 v10, v8, 0x1f

    .line 204
    .line 205
    ushr-int/lit8 v12, v8, 0x17

    .line 206
    .line 207
    and-int/2addr v12, v11

    .line 208
    and-int v14, v8, p1

    .line 209
    .line 210
    if-ne v12, v11, :cond_a

    .line 211
    .line 212
    if-eqz v14, :cond_9

    .line 213
    .line 214
    move/from16 v8, v18

    .line 215
    .line 216
    goto :goto_4

    .line 217
    :cond_9
    move/from16 v8, v19

    .line 218
    .line 219
    :goto_4
    move v12, v9

    .line 220
    goto :goto_6

    .line 221
    :cond_a
    add-int/lit8 v12, v12, -0x70

    .line 222
    .line 223
    if-lt v12, v9, :cond_b

    .line 224
    .line 225
    move/from16 v12, v17

    .line 226
    .line 227
    move/from16 v8, v19

    .line 228
    .line 229
    goto :goto_6

    .line 230
    :cond_b
    if-gtz v12, :cond_e

    .line 231
    .line 232
    if-lt v12, v13, :cond_d

    .line 233
    .line 234
    or-int v8, v14, v16

    .line 235
    .line 236
    rsub-int/lit8 v12, v12, 0x1

    .line 237
    .line 238
    shr-int/2addr v8, v12

    .line 239
    and-int/lit16 v12, v8, 0x1000

    .line 240
    .line 241
    if-eqz v12, :cond_c

    .line 242
    .line 243
    add-int/lit16 v8, v8, 0x2000

    .line 244
    .line 245
    :cond_c
    shr-int/lit8 v8, v8, 0xd

    .line 246
    .line 247
    move/from16 v12, v19

    .line 248
    .line 249
    goto :goto_6

    .line 250
    :cond_d
    move/from16 v8, v19

    .line 251
    .line 252
    move v12, v8

    .line 253
    goto :goto_6

    .line 254
    :cond_e
    shr-int/lit8 v14, v14, 0xd

    .line 255
    .line 256
    and-int/lit16 v8, v8, 0x1000

    .line 257
    .line 258
    if-eqz v8, :cond_f

    .line 259
    .line 260
    shl-int/lit8 v8, v12, 0xa

    .line 261
    .line 262
    or-int/2addr v8, v14

    .line 263
    add-int/lit8 v8, v8, 0x1

    .line 264
    .line 265
    shl-int/lit8 v10, v10, 0xf

    .line 266
    .line 267
    or-int/2addr v8, v10

    .line 268
    :goto_5
    int-to-short v8, v8

    .line 269
    goto :goto_7

    .line 270
    :cond_f
    move v8, v14

    .line 271
    :goto_6
    shl-int/lit8 v10, v10, 0xf

    .line 272
    .line 273
    shl-int/lit8 v12, v12, 0xa

    .line 274
    .line 275
    or-int/2addr v10, v12

    .line 276
    or-int/2addr v8, v10

    .line 277
    goto :goto_5

    .line 278
    :goto_7
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 279
    .line 280
    .line 281
    move-result v4

    .line 282
    ushr-int/lit8 v10, v4, 0x1f

    .line 283
    .line 284
    ushr-int/lit8 v12, v4, 0x17

    .line 285
    .line 286
    and-int/2addr v12, v11

    .line 287
    and-int v14, v4, p1

    .line 288
    .line 289
    if-ne v12, v11, :cond_11

    .line 290
    .line 291
    if-eqz v14, :cond_10

    .line 292
    .line 293
    goto :goto_8

    .line 294
    :cond_10
    move/from16 v18, v19

    .line 295
    .line 296
    :goto_8
    move/from16 v17, v9

    .line 297
    .line 298
    move/from16 v19, v18

    .line 299
    .line 300
    goto :goto_a

    .line 301
    :cond_11
    add-int/lit8 v12, v12, -0x70

    .line 302
    .line 303
    if-lt v12, v9, :cond_12

    .line 304
    .line 305
    goto :goto_a

    .line 306
    :cond_12
    if-gtz v12, :cond_15

    .line 307
    .line 308
    if-lt v12, v13, :cond_14

    .line 309
    .line 310
    or-int v4, v14, v16

    .line 311
    .line 312
    rsub-int/lit8 v9, v12, 0x1

    .line 313
    .line 314
    shr-int/2addr v4, v9

    .line 315
    and-int/lit16 v9, v4, 0x1000

    .line 316
    .line 317
    if-eqz v9, :cond_13

    .line 318
    .line 319
    add-int/lit16 v4, v4, 0x2000

    .line 320
    .line 321
    :cond_13
    shr-int/lit8 v4, v4, 0xd

    .line 322
    .line 323
    move/from16 v17, v19

    .line 324
    .line 325
    move/from16 v19, v4

    .line 326
    .line 327
    goto :goto_a

    .line 328
    :cond_14
    move/from16 v17, v19

    .line 329
    .line 330
    goto :goto_a

    .line 331
    :cond_15
    shr-int/lit8 v19, v14, 0xd

    .line 332
    .line 333
    and-int/lit16 v4, v4, 0x1000

    .line 334
    .line 335
    if-eqz v4, :cond_16

    .line 336
    .line 337
    shl-int/lit8 v4, v12, 0xa

    .line 338
    .line 339
    or-int v4, v4, v19

    .line 340
    .line 341
    add-int/lit8 v4, v4, 0x1

    .line 342
    .line 343
    shl-int/lit8 v9, v10, 0xf

    .line 344
    .line 345
    or-int/2addr v4, v9

    .line 346
    :goto_9
    int-to-short v4, v4

    .line 347
    goto :goto_b

    .line 348
    :cond_16
    move/from16 v17, v12

    .line 349
    .line 350
    :goto_a
    shl-int/lit8 v4, v10, 0xf

    .line 351
    .line 352
    shl-int/lit8 v9, v17, 0xa

    .line 353
    .line 354
    or-int/2addr v4, v9

    .line 355
    or-int v4, v4, v19

    .line 356
    .line 357
    goto :goto_9

    .line 358
    :goto_b
    invoke-static {v2, v15}, Ljava/lang/Math;->min(FF)F

    .line 359
    .line 360
    .line 361
    move-result v2

    .line 362
    const/4 v9, 0x0

    .line 363
    invoke-static {v9, v2}, Ljava/lang/Math;->max(FF)F

    .line 364
    .line 365
    .line 366
    move-result v2

    .line 367
    const v9, 0x447fc000    # 1023.0f

    .line 368
    .line 369
    .line 370
    mul-float/2addr v2, v9

    .line 371
    const/high16 v9, 0x3f000000    # 0.5f

    .line 372
    .line 373
    add-float/2addr v2, v9

    .line 374
    float-to-int v2, v2

    .line 375
    iget v3, v3, Le0/c;->c:I

    .line 376
    .line 377
    int-to-long v9, v5

    .line 378
    const-wide/32 v11, 0xffff

    .line 379
    .line 380
    .line 381
    and-long/2addr v9, v11

    .line 382
    const/16 v5, 0x30

    .line 383
    .line 384
    shl-long/2addr v9, v5

    .line 385
    int-to-long v13, v8

    .line 386
    and-long/2addr v13, v11

    .line 387
    const/16 v5, 0x20

    .line 388
    .line 389
    shl-long/2addr v13, v5

    .line 390
    or-long v8, v9, v13

    .line 391
    .line 392
    int-to-long v4, v4

    .line 393
    and-long/2addr v4, v11

    .line 394
    const/16 v10, 0x10

    .line 395
    .line 396
    shl-long/2addr v4, v10

    .line 397
    or-long/2addr v4, v8

    .line 398
    int-to-long v8, v2

    .line 399
    const-wide/16 v10, 0x3ff

    .line 400
    .line 401
    and-long/2addr v8, v10

    .line 402
    const/4 v2, 0x6

    .line 403
    shl-long/2addr v8, v2

    .line 404
    or-long/2addr v4, v8

    .line 405
    int-to-long v2, v3

    .line 406
    const-wide/16 v8, 0x3f

    .line 407
    .line 408
    and-long/2addr v2, v8

    .line 409
    or-long/2addr v2, v4

    .line 410
    and-long v4, v6, v8

    .line 411
    .line 412
    long-to-int v4, v4

    .line 413
    sget-object v5, Le0/d;->y:[Le0/c;

    .line 414
    .line 415
    aget-object v4, v5, v4

    .line 416
    .line 417
    invoke-static {v2, v3, v4}, Ld0/w;->a(JLe0/c;)J

    .line 418
    .line 419
    .line 420
    move-result-wide v2

    .line 421
    const/4 v6, 0x0

    .line 422
    const/16 v7, 0x7e

    .line 423
    .line 424
    const-wide/16 v4, 0x0

    .line 425
    .line 426
    invoke-static/range {v1 .. v7}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 427
    .line 428
    .line 429
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 430
    .line 431
    return-object v1
.end method
