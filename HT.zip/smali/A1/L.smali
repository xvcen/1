.class public final synthetic LA1/L;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:LB1/t;

.field public final synthetic e:Z

.field public final synthetic f:F


# direct methods
.method public synthetic constructor <init>(LB1/t;ZF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/L;->d:LB1/t;

    iput-boolean p2, p0, LA1/L;->e:Z

    iput p3, p0, LA1/L;->f:F

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    check-cast p1, Ld0/E;

    .line 2
    .line 3
    const-string v0, "$this$graphicsLayer"

    .line 4
    .line 5
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LA1/L;->d:LB1/t;

    .line 9
    .line 10
    iget-object v0, v0, LB1/t;->m:Ll/c;

    .line 11
    .line 12
    invoke-virtual {v0}, Ll/c;->c()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/lang/Number;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x2

    .line 23
    int-to-float v1, v1

    .line 24
    invoke-interface {p1}, LT0/c;->g()F

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    mul-float/2addr v2, v1

    .line 29
    iget-boolean v1, p0, LA1/L;->e:Z

    .line 30
    .line 31
    iget v3, p0, LA1/L;->f:F

    .line 32
    .line 33
    if-eqz v1, :cond_0

    .line 34
    .line 35
    add-float/2addr v3, v2

    .line 36
    invoke-static {v2, v3, v0}, LT0/g;->C(FFF)F

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    neg-float v1, v2

    .line 42
    add-float/2addr v2, v3

    .line 43
    neg-float v2, v2

    .line 44
    invoke-static {v1, v2, v0}, LT0/g;->C(FFF)F

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    :goto_0
    invoke-interface {p1, v0}, Ld0/E;->p(F)V

    .line 49
    .line 50
    .line 51
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 52
    .line 53
    return-object p1
.end method
