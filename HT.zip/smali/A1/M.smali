.class public final synthetic LA1/M;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 1
    iput p6, p0, LA1/M;->d:I

    iput-object p1, p0, LA1/M;->f:Ljava/lang/Object;

    iput-object p2, p0, LA1/M;->g:Ljava/lang/Object;

    iput-object p3, p0, LA1/M;->h:Ljava/lang/Object;

    iput-object p4, p0, LA1/M;->i:Ljava/lang/Object;

    iput p5, p0, LA1/M;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LA1/M;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/M;->f:Ljava/lang/Object;

    .line 7
    .line 8
    move-object v1, v0

    .line 9
    check-cast v1, LQ/f;

    .line 10
    .line 11
    iget-object v0, p0, LA1/M;->g:Ljava/lang/Object;

    .line 12
    .line 13
    move-object v2, v0

    .line 14
    check-cast v2, LD/b;

    .line 15
    .line 16
    move-object v5, p1

    .line 17
    check-cast v5, LI/r;

    .line 18
    .line 19
    check-cast p2, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    iget p1, p0, LA1/M;->e:I

    .line 25
    .line 26
    invoke-static {p1}, LI/k;->x(I)I

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    or-int/lit8 v6, p1, 0x1

    .line 31
    .line 32
    iget-object v3, p0, LA1/M;->h:Ljava/lang/Object;

    .line 33
    .line 34
    iget-object v4, p0, LA1/M;->i:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-virtual/range {v1 .. v6}, LQ/f;->d(LD/b;Ljava/lang/Object;Ljava/lang/Object;LI/r;I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 40
    .line 41
    return-object p1

    .line 42
    :pswitch_0
    iget-object v0, p0, LA1/M;->f:Ljava/lang/Object;

    .line 43
    .line 44
    move-object v1, v0

    .line 45
    check-cast v1, LC1/a;

    .line 46
    .line 47
    iget-object v0, p0, LA1/M;->g:Ljava/lang/Object;

    .line 48
    .line 49
    move-object v2, v0

    .line 50
    check-cast v2, Li0/b;

    .line 51
    .line 52
    iget-object v0, p0, LA1/M;->h:Ljava/lang/Object;

    .line 53
    .line 54
    move-object v3, v0

    .line 55
    check-cast v3, Ljava/lang/String;

    .line 56
    .line 57
    iget-object v0, p0, LA1/M;->i:Ljava/lang/Object;

    .line 58
    .line 59
    move-object v4, v0

    .line 60
    check-cast v4, LU1/a;

    .line 61
    .line 62
    move-object v5, p1

    .line 63
    check-cast v5, LI/r;

    .line 64
    .line 65
    check-cast p2, Ljava/lang/Integer;

    .line 66
    .line 67
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget p1, p0, LA1/M;->e:I

    .line 71
    .line 72
    or-int/lit8 p1, p1, 0x1

    .line 73
    .line 74
    invoke-static {p1}, LI/k;->x(I)I

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    invoke-static/range {v1 .. v6}, LX1/a;->c(LC1/a;Li0/b;Ljava/lang/String;LU1/a;LI/r;I)V

    .line 79
    .line 80
    .line 81
    goto :goto_0

    .line 82
    nop

    .line 83
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
