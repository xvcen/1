.class public final synthetic LA1/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LC1/a;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Z

.field public final synthetic g:Z

.field public final synthetic h:LU1/c;

.field public final synthetic i:LU1/c;

.field public final synthetic j:LU1/a;

.field public final synthetic k:LU1/a;

.field public final synthetic l:LU1/a;


# direct methods
.method public synthetic constructor <init>(LC1/a;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/O;->d:LC1/a;

    iput-object p2, p0, LA1/O;->e:Ljava/lang/String;

    iput-boolean p3, p0, LA1/O;->f:Z

    iput-boolean p4, p0, LA1/O;->g:Z

    iput-object p5, p0, LA1/O;->h:LU1/c;

    iput-object p6, p0, LA1/O;->i:LU1/c;

    iput-object p7, p0, LA1/O;->j:LU1/a;

    iput-object p8, p0, LA1/O;->k:LU1/a;

    iput-object p9, p0, LA1/O;->l:LU1/a;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    move-object v9, p1

    .line 2
    check-cast v9, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    invoke-static {p1}, LI/k;->x(I)I

    .line 11
    .line 12
    .line 13
    move-result v10

    .line 14
    iget-object v0, p0, LA1/O;->d:LC1/a;

    .line 15
    .line 16
    iget-object v1, p0, LA1/O;->e:Ljava/lang/String;

    .line 17
    .line 18
    iget-boolean v2, p0, LA1/O;->f:Z

    .line 19
    .line 20
    iget-boolean v3, p0, LA1/O;->g:Z

    .line 21
    .line 22
    iget-object v4, p0, LA1/O;->h:LU1/c;

    .line 23
    .line 24
    iget-object v5, p0, LA1/O;->i:LU1/c;

    .line 25
    .line 26
    iget-object v6, p0, LA1/O;->j:LU1/a;

    .line 27
    .line 28
    iget-object v7, p0, LA1/O;->k:LU1/a;

    .line 29
    .line 30
    iget-object v8, p0, LA1/O;->l:LU1/a;

    .line 31
    .line 32
    invoke-static/range {v0 .. v10}, LX1/a;->n(LC1/a;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;LI/r;I)V

    .line 33
    .line 34
    .line 35
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 36
    .line 37
    return-object p1
.end method
