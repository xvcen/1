.class public final synthetic LA1/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/P;->d:I

    iput-object p2, p0, LA1/P;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LA1/P;->d:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lp/n0;

    .line 11
    .line 12
    new-instance v2, Lw/n0;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-direct {v2, v0, v3}, Lw/n0;-><init>(Lp/n0;F)V

    .line 16
    .line 17
    .line 18
    return-object v2

    .line 19
    :pswitch_0
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Lw/S;

    .line 22
    .line 23
    invoke-virtual {v0}, Lw/S;->d()Lw/p0;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    return-object v0

    .line 28
    :pswitch_1
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, Lc0/c;

    .line 31
    .line 32
    return-object v0

    .line 33
    :pswitch_2
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, Le2/g;

    .line 36
    .line 37
    invoke-interface {v0}, Le2/q;->o()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    instance-of v2, v0, Le2/i;

    .line 42
    .line 43
    if-nez v2, :cond_0

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    const/4 v0, 0x0

    .line 47
    :goto_0
    check-cast v0, Lp/b0;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Ln/s0;

    .line 53
    .line 54
    sget-object v2, Ln/g0;->a:LI/B;

    .line 55
    .line 56
    invoke-static {v0, v2}, Lw0/j;->h(Lw0/g;LI/t0;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    check-cast v2, Ln/s;

    .line 61
    .line 62
    iput-object v2, v0, Ln/s0;->B:Ln/s;

    .line 63
    .line 64
    if-eqz v2, :cond_1

    .line 65
    .line 66
    new-instance v3, Ln/r;

    .line 67
    .line 68
    iget-object v4, v2, Ln/s;->a:Landroid/content/Context;

    .line 69
    .line 70
    iget-object v5, v2, Ln/s;->b:LT0/c;

    .line 71
    .line 72
    iget-wide v6, v2, Ln/s;->c:J

    .line 73
    .line 74
    iget-object v8, v2, Ln/s;->d:Ls/F;

    .line 75
    .line 76
    invoke-direct/range {v3 .. v8}, Ln/r;-><init>(Landroid/content/Context;LT0/c;JLs/F;)V

    .line 77
    .line 78
    .line 79
    goto :goto_1

    .line 80
    :cond_1
    const/4 v3, 0x0

    .line 81
    :goto_1
    iput-object v3, v0, Ln/s0;->C:Ln/r;

    .line 82
    .line 83
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 84
    .line 85
    return-object v0

    .line 86
    :pswitch_4
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v0, Lb/k;

    .line 89
    .line 90
    new-instance v2, Lb/j;

    .line 91
    .line 92
    invoke-direct {v2, v0}, Lb/j;-><init>(Lb/k;)V

    .line 93
    .line 94
    .line 95
    return-object v2

    .line 96
    :pswitch_5
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v0, Landroid/view/ViewParent;

    .line 99
    .line 100
    return-object v0

    .line 101
    :pswitch_6
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 102
    .line 103
    move-object v2, v0

    .line 104
    check-cast v2, LU/w;

    .line 105
    .line 106
    :cond_2
    iget-object v3, v2, LU/w;->g:Ljava/lang/Object;

    .line 107
    .line 108
    monitor-enter v3

    .line 109
    :try_start_0
    iget-boolean v0, v2, LU/w;->c:Z

    .line 110
    .line 111
    if-nez v0, :cond_9

    .line 112
    .line 113
    const/4 v0, 0x1

    .line 114
    iput-boolean v0, v2, LU/w;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 115
    .line 116
    :try_start_1
    iget-object v0, v2, LU/w;->f:LK/e;

    .line 117
    .line 118
    iget-object v5, v0, LK/e;->d:[Ljava/lang/Object;

    .line 119
    .line 120
    iget v0, v0, LK/e;->f:I

    .line 121
    .line 122
    const/4 v6, 0x0

    .line 123
    :goto_2
    if-ge v6, v0, :cond_8

    .line 124
    .line 125
    aget-object v7, v5, v6

    .line 126
    .line 127
    check-cast v7, LU/v;

    .line 128
    .line 129
    iget-object v8, v7, LU/v;->g:Li/F;

    .line 130
    .line 131
    iget-object v7, v7, LU/v;->a:LU1/c;

    .line 132
    .line 133
    iget-object v9, v8, Li/F;->b:[Ljava/lang/Object;

    .line 134
    .line 135
    iget-object v10, v8, Li/F;->a:[J

    .line 136
    .line 137
    array-length v11, v10

    .line 138
    add-int/lit8 v11, v11, -0x2

    .line 139
    .line 140
    if-ltz v11, :cond_6

    .line 141
    .line 142
    const/4 v12, 0x0

    .line 143
    :goto_3
    aget-wide v13, v10, v12

    .line 144
    .line 145
    move-object/from16 v16, v5

    .line 146
    .line 147
    not-long v4, v13

    .line 148
    const/16 v17, 0x7

    .line 149
    .line 150
    shl-long v4, v4, v17

    .line 151
    .line 152
    and-long/2addr v4, v13

    .line 153
    const-wide v17, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    and-long v4, v4, v17

    .line 159
    .line 160
    cmp-long v4, v4, v17

    .line 161
    .line 162
    if-eqz v4, :cond_5

    .line 163
    .line 164
    sub-int v4, v12, v11

    .line 165
    .line 166
    not-int v4, v4

    .line 167
    ushr-int/lit8 v4, v4, 0x1f

    .line 168
    .line 169
    const/16 v5, 0x8

    .line 170
    .line 171
    rsub-int/lit8 v4, v4, 0x8

    .line 172
    .line 173
    const/4 v15, 0x0

    .line 174
    :goto_4
    if-ge v15, v4, :cond_4

    .line 175
    .line 176
    const-wide/16 v18, 0xff

    .line 177
    .line 178
    and-long v18, v13, v18

    .line 179
    .line 180
    const-wide/16 v20, 0x80

    .line 181
    .line 182
    cmp-long v18, v18, v20

    .line 183
    .line 184
    if-gez v18, :cond_3

    .line 185
    .line 186
    shl-int/lit8 v18, v12, 0x3

    .line 187
    .line 188
    add-int v18, v18, v15

    .line 189
    .line 190
    move/from16 v19, v5

    .line 191
    .line 192
    aget-object v5, v9, v18

    .line 193
    .line 194
    invoke-interface {v7, v5}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    goto :goto_5

    .line 198
    :cond_3
    move/from16 v19, v5

    .line 199
    .line 200
    :goto_5
    shr-long v13, v13, v19

    .line 201
    .line 202
    add-int/lit8 v15, v15, 0x1

    .line 203
    .line 204
    move/from16 v5, v19

    .line 205
    .line 206
    goto :goto_4

    .line 207
    :cond_4
    if-ne v4, v5, :cond_7

    .line 208
    .line 209
    :cond_5
    if-eq v12, v11, :cond_7

    .line 210
    .line 211
    add-int/lit8 v12, v12, 0x1

    .line 212
    .line 213
    move-object/from16 v5, v16

    .line 214
    .line 215
    goto :goto_3

    .line 216
    :cond_6
    move-object/from16 v16, v5

    .line 217
    .line 218
    :cond_7
    invoke-virtual {v8}, Li/F;->b()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 219
    .line 220
    .line 221
    add-int/lit8 v6, v6, 0x1

    .line 222
    .line 223
    move-object/from16 v5, v16

    .line 224
    .line 225
    goto :goto_2

    .line 226
    :goto_6
    const/4 v15, 0x0

    .line 227
    goto :goto_7

    .line 228
    :catchall_0
    move-exception v0

    .line 229
    goto :goto_6

    .line 230
    :cond_8
    const/4 v15, 0x0

    .line 231
    :try_start_2
    iput-boolean v15, v2, LU/w;->c:Z

    .line 232
    .line 233
    goto :goto_8

    .line 234
    :catchall_1
    move-exception v0

    .line 235
    goto :goto_9

    .line 236
    :goto_7
    iput-boolean v15, v2, LU/w;->c:Z

    .line 237
    .line 238
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 239
    :cond_9
    :goto_8
    monitor-exit v3

    .line 240
    invoke-virtual {v2}, LU/w;->b()Z

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    if-nez v0, :cond_2

    .line 245
    .line 246
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 247
    .line 248
    return-object v0

    .line 249
    :goto_9
    monitor-exit v3

    .line 250
    throw v0

    .line 251
    :pswitch_7
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 252
    .line 253
    check-cast v0, LT/b;

    .line 254
    .line 255
    iget-object v2, v0, LT/b;->d:LT/f;

    .line 256
    .line 257
    iget-object v3, v0, LT/b;->g:Ljava/lang/Object;

    .line 258
    .line 259
    if-eqz v3, :cond_a

    .line 260
    .line 261
    invoke-interface {v2, v0, v3}, LT/f;->c(LT/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    return-object v0

    .line 266
    :cond_a
    const-string v0, "Value should be initialized"

    .line 267
    .line 268
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 269
    .line 270
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    throw v2

    .line 274
    :pswitch_8
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v0, LR0/b;

    .line 277
    .line 278
    iget-object v2, v0, LR0/b;->f:LI/m0;

    .line 279
    .line 280
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v3

    .line 284
    check-cast v3, Lc0/e;

    .line 285
    .line 286
    iget-wide v3, v3, Lc0/e;->a:J

    .line 287
    .line 288
    const-wide v5, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    cmp-long v3, v3, v5

    .line 294
    .line 295
    if-nez v3, :cond_b

    .line 296
    .line 297
    goto :goto_a

    .line 298
    :cond_b
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object v3

    .line 302
    check-cast v3, Lc0/e;

    .line 303
    .line 304
    iget-wide v3, v3, Lc0/e;->a:J

    .line 305
    .line 306
    invoke-static {v3, v4}, Lc0/e;->c(J)Z

    .line 307
    .line 308
    .line 309
    move-result v3

    .line 310
    if-eqz v3, :cond_c

    .line 311
    .line 312
    :goto_a
    const/4 v0, 0x0

    .line 313
    goto :goto_b

    .line 314
    :cond_c
    iget-object v0, v0, LR0/b;->d:Ld0/Q;

    .line 315
    .line 316
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v2

    .line 320
    check-cast v2, Lc0/e;

    .line 321
    .line 322
    iget-wide v2, v2, Lc0/e;->a:J

    .line 323
    .line 324
    invoke-virtual {v0, v2, v3}, Ld0/Q;->b(J)Landroid/graphics/Shader;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    :goto_b
    return-object v0

    .line 329
    :pswitch_9
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast v0, LG/i;

    .line 332
    .line 333
    const/4 v2, 0x0

    .line 334
    iput-object v2, v0, LG/i;->B:LG/h;

    .line 335
    .line 336
    invoke-static {v0}, Lw0/j;->l(Lw0/t0;)V

    .line 337
    .line 338
    .line 339
    invoke-static {v0}, Lw0/j;->k(Lw0/u;)V

    .line 340
    .line 341
    .line 342
    invoke-static {v0}, Lw0/j;->j(Lw0/l;)V

    .line 343
    .line 344
    .line 345
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 346
    .line 347
    return-object v0

    .line 348
    :pswitch_a
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 349
    .line 350
    check-cast v0, LF/z;

    .line 351
    .line 352
    new-instance v2, Landroid/view/inputmethod/BaseInputConnection;

    .line 353
    .line 354
    iget-object v0, v0, LF/z;->a:Landroid/view/View;

    .line 355
    .line 356
    const/4 v3, 0x0

    .line 357
    invoke-direct {v2, v0, v3}, Landroid/view/inputmethod/BaseInputConnection;-><init>(Landroid/view/View;Z)V

    .line 358
    .line 359
    .line 360
    return-object v2

    .line 361
    :pswitch_b
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v0, LF/r;

    .line 364
    .line 365
    iget-object v0, v0, LF/r;->e:Ljava/lang/Object;

    .line 366
    .line 367
    check-cast v0, Landroid/view/View;

    .line 368
    .line 369
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 370
    .line 371
    .line 372
    move-result-object v0

    .line 373
    const-string v2, "input_method"

    .line 374
    .line 375
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    const-string v2, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager"

    .line 380
    .line 381
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 382
    .line 383
    .line 384
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 385
    .line 386
    return-object v0

    .line 387
    :pswitch_c
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast v0, LC1/g;

    .line 390
    .line 391
    invoke-virtual {v0}, LC1/g;->U0()V

    .line 392
    .line 393
    .line 394
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 395
    .line 396
    return-object v0

    .line 397
    :pswitch_d
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 398
    .line 399
    check-cast v0, LC/m;

    .line 400
    .line 401
    iget-boolean v2, v0, LW/p;->q:Z

    .line 402
    .line 403
    if-eqz v2, :cond_d

    .line 404
    .line 405
    invoke-static {v0}, LC/j;->b(Lw0/h;)Lz/c;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    goto :goto_c

    .line 410
    :cond_d
    sget-object v0, Lz/c;->b:Lz/c;

    .line 411
    .line 412
    :goto_c
    return-object v0

    .line 413
    :pswitch_e
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 414
    .line 415
    check-cast v0, LB1/G;

    .line 416
    .line 417
    iget-object v2, v0, LB1/G;->a:Lc2/s;

    .line 418
    .line 419
    new-instance v3, LB1/E;

    .line 420
    .line 421
    const/4 v4, 0x0

    .line 422
    invoke-direct {v3, v0, v4}, LB1/E;-><init>(LB1/G;LN1/c;)V

    .line 423
    .line 424
    .line 425
    const/4 v0, 0x3

    .line 426
    invoke-static {v2, v4, v3, v0}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 427
    .line 428
    .line 429
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 430
    .line 431
    return-object v0

    .line 432
    :pswitch_f
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 433
    .line 434
    check-cast v0, Landroid/app/RemoteAction;

    .line 435
    .line 436
    invoke-static {v0}, LA0/a;->e(Landroid/app/RemoteAction;)Landroid/app/PendingIntent;

    .line 437
    .line 438
    .line 439
    move-result-object v2

    .line 440
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 441
    .line 442
    const/16 v3, 0x22

    .line 443
    .line 444
    if-lt v0, v3, :cond_e

    .line 445
    .line 446
    :try_start_3
    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    .line 447
    .line 448
    .line 449
    move-result-object v0

    .line 450
    invoke-static {v0}, LB/x;->e(Landroid/app/ActivityOptions;)Landroid/app/ActivityOptions;

    .line 451
    .line 452
    .line 453
    move-result-object v0

    .line 454
    invoke-virtual {v0}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    .line 455
    .line 456
    .line 457
    move-result-object v0

    .line 458
    invoke-static {v2, v0}, LB/x;->p(Landroid/app/PendingIntent;Landroid/os/Bundle;)V
    :try_end_3
    .catch Landroid/app/PendingIntent$CanceledException; {:try_start_3 .. :try_end_3} :catch_0

    .line 459
    .line 460
    .line 461
    goto :goto_d

    .line 462
    :catch_0
    move-exception v0

    .line 463
    const-string v3, "TextClassification"

    .line 464
    .line 465
    new-instance v4, Ljava/lang/StringBuilder;

    .line 466
    .line 467
    const-string v5, "error sending pendingIntent: "

    .line 468
    .line 469
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 473
    .line 474
    .line 475
    const-string v2, " error: "

    .line 476
    .line 477
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 478
    .line 479
    .line 480
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 481
    .line 482
    .line 483
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 484
    .line 485
    .line 486
    move-result-object v0

    .line 487
    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 488
    .line 489
    .line 490
    goto :goto_d

    .line 491
    :cond_e
    invoke-virtual {v2}, Landroid/app/PendingIntent;->send()V

    .line 492
    .line 493
    .line 494
    :goto_d
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 495
    .line 496
    return-object v0

    .line 497
    :pswitch_10
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 498
    .line 499
    check-cast v0, Lz/g;

    .line 500
    .line 501
    invoke-interface {v0}, Lz/g;->close()V

    .line 502
    .line 503
    .line 504
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 505
    .line 506
    return-object v0

    .line 507
    :pswitch_11
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 508
    .line 509
    check-cast v0, LD/e;

    .line 510
    .line 511
    invoke-interface {v0}, LD/e;->A0()Lz/c;

    .line 512
    .line 513
    .line 514
    move-result-object v0

    .line 515
    return-object v0

    .line 516
    :pswitch_12
    iget-object v0, v1, LA1/P;->e:Ljava/lang/Object;

    .line 517
    .line 518
    check-cast v0, LI/i0;

    .line 519
    .line 520
    invoke-virtual {v0}, LI/i0;->g()F

    .line 521
    .line 522
    .line 523
    move-result v0

    .line 524
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    return-object v0

    .line 529
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
