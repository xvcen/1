.class public final LA1/Q;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public synthetic h:F

.field public final synthetic i:LB1/t;


# direct methods
.method public constructor <init>(LB1/t;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA1/Q;->i:LB1/t;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Number;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    check-cast p2, LN1/c;

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p0, p2, p1}, LA1/Q;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    check-cast p1, LA1/Q;

    .line 18
    .line 19
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 20
    .line 21
    invoke-virtual {p1, p2}, LA1/Q;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    return-object p2
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LA1/Q;

    .line 2
    .line 3
    iget-object v1, p0, LA1/Q;->i:LB1/t;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LA1/Q;-><init>(LB1/t;LN1/c;)V

    .line 6
    .line 7
    .line 8
    check-cast p2, Ljava/lang/Number;

    .line 9
    .line 10
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    iput p1, v0, LA1/Q;->h:F

    .line 15
    .line 16
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LA1/Q;->h:F

    .line 2
    .line 3
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    iget-object v0, p0, LA1/Q;->i:LB1/t;

    .line 11
    .line 12
    iget-object v1, v0, LB1/t;->b:LY1/a;

    .line 13
    .line 14
    invoke-static {p1, v1}, LT0/l;->n(Ljava/lang/Float;LY1/a;)Ljava/lang/Comparable;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    check-cast p1, Ljava/lang/Number;

    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    iget-object v1, v0, LB1/t;->a:Lc2/s;

    .line 25
    .line 26
    new-instance v2, LB1/r;

    .line 27
    .line 28
    const/4 v3, 0x0

    .line 29
    invoke-direct {v2, v0, p1, v3}, LB1/r;-><init>(LB1/t;FLN1/c;)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x3

    .line 33
    invoke-static {v1, v3, v2, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 34
    .line 35
    .line 36
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 37
    .line 38
    return-object p1
.end method
