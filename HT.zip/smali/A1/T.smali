.class public final LA1/T;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public synthetic h:Z

.field public final synthetic i:LB1/t;

.field public final synthetic j:LI/i0;


# direct methods
.method public constructor <init>(LB1/t;LI/i0;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA1/T;->i:LB1/t;

    .line 2
    .line 3
    iput-object p2, p0, LA1/T;->j:LI/i0;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    check-cast p2, LN1/c;

    .line 7
    .line 8
    invoke-virtual {p0, p2, p1}, LA1/T;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, LA1/T;

    .line 13
    .line 14
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 15
    .line 16
    invoke-virtual {p1, p2}, LA1/T;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-object p2
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 3

    .line 1
    new-instance v0, LA1/T;

    .line 2
    .line 3
    iget-object v1, p0, LA1/T;->i:LB1/t;

    .line 4
    .line 5
    iget-object v2, p0, LA1/T;->j:LI/i0;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, p1}, LA1/T;-><init>(LB1/t;LI/i0;LN1/c;)V

    .line 8
    .line 9
    .line 10
    check-cast p2, Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    iput-boolean p1, v0, LA1/T;->h:Z

    .line 17
    .line 18
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-boolean v0, p0, LA1/T;->h:Z

    .line 2
    .line 3
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/high16 p1, 0x3f800000    # 1.0f

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 p1, 0x0

    .line 12
    :goto_0
    iget-object v0, p0, LA1/T;->j:LI/i0;

    .line 13
    .line 14
    invoke-virtual {v0}, LI/i0;->g()F

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    cmpg-float v1, p1, v1

    .line 19
    .line 20
    if-nez v1, :cond_1

    .line 21
    .line 22
    goto :goto_1

    .line 23
    :cond_1
    invoke-virtual {v0, p1}, LI/i0;->h(F)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, LA1/T;->i:LB1/t;

    .line 27
    .line 28
    iget-object v1, v0, LB1/t;->a:Lc2/s;

    .line 29
    .line 30
    new-instance v2, LB1/d;

    .line 31
    .line 32
    const/4 v3, 0x0

    .line 33
    invoke-direct {v2, v0, p1, v3}, LB1/d;-><init>(LB1/t;FLN1/c;)V

    .line 34
    .line 35
    .line 36
    const/4 p1, 0x3

    .line 37
    invoke-static {v1, v3, v2, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 38
    .line 39
    .line 40
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 41
    .line 42
    return-object p1
.end method
