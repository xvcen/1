.class public final LA1/U;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:Z

.field public final synthetic j:LB1/t;

.field public final synthetic k:LI/i0;


# direct methods
.method public constructor <init>(ZLB1/t;LI/i0;LN1/c;)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LA1/U;->i:Z

    .line 2
    .line 3
    iput-object p2, p0, LA1/U;->j:LB1/t;

    .line 4
    .line 5
    iput-object p3, p0, LA1/U;->k:LI/i0;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LA1/U;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LA1/U;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LA1/U;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 3

    .line 1
    new-instance p2, LA1/U;

    .line 2
    .line 3
    iget-object v0, p0, LA1/U;->j:LB1/t;

    .line 4
    .line 5
    iget-object v1, p0, LA1/U;->k:LI/i0;

    .line 6
    .line 7
    iget-boolean v2, p0, LA1/U;->i:Z

    .line 8
    .line 9
    invoke-direct {p2, v2, v0, v1, p1}, LA1/U;-><init>(ZLB1/t;LI/i0;LN1/c;)V

    .line 10
    .line 11
    .line 12
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LA1/U;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    new-instance p1, LA1/p;

    .line 24
    .line 25
    const/4 v0, 0x3

    .line 26
    iget-boolean v2, p0, LA1/U;->i:Z

    .line 27
    .line 28
    invoke-direct {p1, v0, v2}, LA1/p;-><init>(IZ)V

    .line 29
    .line 30
    .line 31
    invoke-static {p1}, LI/k;->v(LU1/a;)LA0/h;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    new-instance v0, LA1/T;

    .line 36
    .line 37
    iget-object v2, p0, LA1/U;->k:LI/i0;

    .line 38
    .line 39
    const/4 v3, 0x0

    .line 40
    iget-object v4, p0, LA1/U;->j:LB1/t;

    .line 41
    .line 42
    invoke-direct {v0, v4, v2, v3}, LA1/T;-><init>(LB1/t;LI/i0;LN1/c;)V

    .line 43
    .line 44
    .line 45
    iput v1, p0, LA1/U;->h:I

    .line 46
    .line 47
    invoke-static {p1, v0, p0}, Lf2/w;->d(Lf2/d;LU1/e;LP1/i;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    sget-object v0, LO1/a;->d:LO1/a;

    .line 52
    .line 53
    if-ne p1, v0, :cond_2

    .line 54
    .line 55
    return-object v0

    .line 56
    :cond_2
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 57
    .line 58
    return-object p1
.end method
