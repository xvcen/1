.class public final synthetic LA1/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/htcheat/external/B;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/B;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/V;->d:I

    iput-object p1, p0, LA1/V;->e:Lcom/htcheat/external/B;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 26

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LA1/V;->d:I

    .line 4
    .line 5
    const/high16 v3, 0x43a00000    # 320.0f

    .line 6
    .line 7
    const/high16 v4, 0x43fa0000    # 500.0f

    .line 8
    .line 9
    const/high16 v5, 0x43d70000    # 430.0f

    .line 10
    .line 11
    const/high16 v6, 0x442f0000    # 700.0f

    .line 12
    .line 13
    const/high16 v8, 0x41800000    # 16.0f

    .line 14
    .line 15
    const/4 v9, 0x6

    .line 16
    const/4 v10, 0x0

    .line 17
    iget-object v11, v1, LA1/V;->e:Lcom/htcheat/external/B;

    .line 18
    .line 19
    packed-switch v0, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    invoke-virtual {v11}, Landroid/app/Service;->stopSelf()V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :pswitch_0
    sget v0, Lcom/htcheat/external/B;->C:I

    .line 27
    .line 28
    new-instance v0, Lcom/htcheat/external/j;

    .line 29
    .line 30
    invoke-direct {v0, v11}, Lcom/htcheat/external/j;-><init>(Landroid/content/Context;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/htcheat/external/j;->g()V

    .line 34
    .line 35
    .line 36
    iget-object v0, v11, Lcom/htcheat/external/B;->r:Landroid/os/Handler;

    .line 37
    .line 38
    new-instance v2, LA1/V;

    .line 39
    .line 40
    invoke-direct {v2, v11, v9}, LA1/V;-><init>(Lcom/htcheat/external/B;I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_1
    sget v0, Lcom/htcheat/external/B;->C:I

    .line 48
    .line 49
    invoke-virtual {v11}, Lcom/htcheat/external/B;->d()Z

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :pswitch_2
    iget-object v0, v11, Lcom/htcheat/external/B;->e:Lcom/htcheat/external/g;

    .line 54
    .line 55
    if-eqz v0, :cond_0

    .line 56
    .line 57
    goto/16 :goto_3

    .line 58
    .line 59
    :cond_0
    new-instance v0, Lcom/htcheat/external/g;

    .line 60
    .line 61
    invoke-direct {v0, v11, v11}, Lcom/htcheat/external/g;-><init>(Lcom/htcheat/external/B;Landroid/content/Context;)V

    .line 62
    .line 63
    .line 64
    iput-object v0, v11, Lcom/htcheat/external/B;->e:Lcom/htcheat/external/g;

    .line 65
    .line 66
    new-instance v12, Landroid/view/WindowManager$LayoutParams;

    .line 67
    .line 68
    const/high16 v0, 0x42c00000    # 96.0f

    .line 69
    .line 70
    invoke-virtual {v11, v0}, Lcom/htcheat/external/B;->f(F)I

    .line 71
    .line 72
    .line 73
    move-result v13

    .line 74
    invoke-virtual {v11, v0}, Lcom/htcheat/external/B;->f(F)I

    .line 75
    .line 76
    .line 77
    move-result v14

    .line 78
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 79
    .line 80
    const/16 v18, 0x7f6

    .line 81
    .line 82
    const/16 v15, 0x1a

    .line 83
    .line 84
    if-lt v0, v15, :cond_1

    .line 85
    .line 86
    move/from16 v16, v15

    .line 87
    .line 88
    move/from16 v15, v18

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_1
    move/from16 v16, v15

    .line 92
    .line 93
    const/16 v15, 0x7d2

    .line 94
    .line 95
    :goto_0
    const v17, 0x1000328

    .line 96
    .line 97
    .line 98
    move/from16 v19, v16

    .line 99
    .line 100
    move/from16 v16, v17

    .line 101
    .line 102
    const/16 v17, -0x3

    .line 103
    .line 104
    move/from16 v9, v19

    .line 105
    .line 106
    invoke-direct/range {v12 .. v17}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 107
    .line 108
    .line 109
    iput-object v12, v11, Lcom/htcheat/external/B;->h:Landroid/view/WindowManager$LayoutParams;

    .line 110
    .line 111
    const v13, 0x800033

    .line 112
    .line 113
    .line 114
    iput v13, v12, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 115
    .line 116
    const/high16 v14, 0x42080000    # 34.0f

    .line 117
    .line 118
    invoke-virtual {v11, v14}, Lcom/htcheat/external/B;->f(F)I

    .line 119
    .line 120
    .line 121
    move-result v15

    .line 122
    iput v15, v12, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 123
    .line 124
    iget-object v12, v11, Lcom/htcheat/external/B;->h:Landroid/view/WindowManager$LayoutParams;

    .line 125
    .line 126
    const/high16 v15, 0x42580000    # 54.0f

    .line 127
    .line 128
    invoke-virtual {v11, v15}, Lcom/htcheat/external/B;->f(F)I

    .line 129
    .line 130
    .line 131
    move-result v7

    .line 132
    iput v7, v12, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 133
    .line 134
    iget-object v7, v11, Lcom/htcheat/external/B;->e:Lcom/htcheat/external/g;

    .line 135
    .line 136
    iget-object v12, v11, Lcom/htcheat/external/B;->h:Landroid/view/WindowManager$LayoutParams;

    .line 137
    .line 138
    new-instance v2, LA1/V;

    .line 139
    .line 140
    invoke-direct {v2, v11, v10}, LA1/V;-><init>(Lcom/htcheat/external/B;I)V

    .line 141
    .line 142
    .line 143
    new-instance v10, LA1/a0;

    .line 144
    .line 145
    invoke-direct {v10, v11, v12, v2}, LA1/a0;-><init>(Lcom/htcheat/external/B;Landroid/view/WindowManager$LayoutParams;Ljava/lang/Runnable;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v7, v10}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 149
    .line 150
    .line 151
    new-instance v2, LA1/c0;

    .line 152
    .line 153
    invoke-direct {v2, v11, v11}, LA1/c0;-><init>(Lcom/htcheat/external/B;Landroid/content/Context;)V

    .line 154
    .line 155
    .line 156
    iget-boolean v7, v11, Lcom/htcheat/external/B;->o:Z

    .line 157
    .line 158
    invoke-virtual {v2, v7}, LA1/c0;->a(Z)V

    .line 159
    .line 160
    .line 161
    iput-object v2, v11, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 162
    .line 163
    new-instance v20, Landroid/view/WindowManager$LayoutParams;

    .line 164
    .line 165
    const/high16 v2, 0x42b80000    # 92.0f

    .line 166
    .line 167
    invoke-virtual {v11, v2}, Lcom/htcheat/external/B;->f(F)I

    .line 168
    .line 169
    .line 170
    move-result v21

    .line 171
    invoke-virtual {v11, v2}, Lcom/htcheat/external/B;->f(F)I

    .line 172
    .line 173
    .line 174
    move-result v22

    .line 175
    if-lt v0, v9, :cond_2

    .line 176
    .line 177
    move/from16 v23, v18

    .line 178
    .line 179
    goto :goto_1

    .line 180
    :cond_2
    const/16 v23, 0x7d2

    .line 181
    .line 182
    :goto_1
    const v24, 0x1000328

    .line 183
    .line 184
    .line 185
    const/16 v25, -0x3

    .line 186
    .line 187
    invoke-direct/range {v20 .. v25}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 188
    .line 189
    .line 190
    move-object/from16 v2, v20

    .line 191
    .line 192
    iput-object v2, v11, Lcom/htcheat/external/B;->i:Landroid/view/WindowManager$LayoutParams;

    .line 193
    .line 194
    iput v13, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 195
    .line 196
    const/high16 v7, 0x41900000    # 18.0f

    .line 197
    .line 198
    invoke-virtual {v11, v7}, Lcom/htcheat/external/B;->f(F)I

    .line 199
    .line 200
    .line 201
    move-result v10

    .line 202
    iget v12, v11, Lcom/htcheat/external/B;->k:I

    .line 203
    .line 204
    iget-object v14, v11, Lcom/htcheat/external/B;->i:Landroid/view/WindowManager$LayoutParams;

    .line 205
    .line 206
    iget v14, v14, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 207
    .line 208
    sub-int/2addr v12, v14

    .line 209
    invoke-virtual {v11, v7}, Lcom/htcheat/external/B;->f(F)I

    .line 210
    .line 211
    .line 212
    move-result v14

    .line 213
    sub-int/2addr v12, v14

    .line 214
    invoke-static {v10, v12}, Ljava/lang/Math;->max(II)I

    .line 215
    .line 216
    .line 217
    move-result v10

    .line 218
    iput v10, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 219
    .line 220
    iget-object v2, v11, Lcom/htcheat/external/B;->i:Landroid/view/WindowManager$LayoutParams;

    .line 221
    .line 222
    invoke-virtual {v11, v15}, Lcom/htcheat/external/B;->f(F)I

    .line 223
    .line 224
    .line 225
    move-result v10

    .line 226
    iget v12, v11, Lcom/htcheat/external/B;->l:I

    .line 227
    .line 228
    int-to-float v12, v12

    .line 229
    const v14, 0x3f147ae1    # 0.58f

    .line 230
    .line 231
    .line 232
    mul-float/2addr v12, v14

    .line 233
    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    .line 234
    .line 235
    .line 236
    move-result v12

    .line 237
    invoke-static {v10, v12}, Ljava/lang/Math;->max(II)I

    .line 238
    .line 239
    .line 240
    move-result v10

    .line 241
    iput v10, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 242
    .line 243
    iget-object v2, v11, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 244
    .line 245
    iget-object v10, v11, Lcom/htcheat/external/B;->i:Landroid/view/WindowManager$LayoutParams;

    .line 246
    .line 247
    new-instance v12, LA1/b0;

    .line 248
    .line 249
    invoke-direct {v12, v11, v10}, LA1/b0;-><init>(Lcom/htcheat/external/B;Landroid/view/WindowManager$LayoutParams;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v2, v12}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 253
    .line 254
    .line 255
    new-instance v20, Landroid/view/WindowManager$LayoutParams;

    .line 256
    .line 257
    invoke-virtual {v11, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 258
    .line 259
    .line 260
    move-result v2

    .line 261
    iget v6, v11, Lcom/htcheat/external/B;->k:I

    .line 262
    .line 263
    invoke-virtual {v11, v8}, Lcom/htcheat/external/B;->f(F)I

    .line 264
    .line 265
    .line 266
    move-result v10

    .line 267
    sub-int/2addr v6, v10

    .line 268
    invoke-virtual {v11, v5}, Lcom/htcheat/external/B;->f(F)I

    .line 269
    .line 270
    .line 271
    move-result v5

    .line 272
    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    .line 273
    .line 274
    .line 275
    move-result v2

    .line 276
    invoke-static {v6, v2}, Ljava/lang/Math;->min(II)I

    .line 277
    .line 278
    .line 279
    move-result v21

    .line 280
    invoke-virtual {v11, v4}, Lcom/htcheat/external/B;->f(F)I

    .line 281
    .line 282
    .line 283
    move-result v2

    .line 284
    iget v4, v11, Lcom/htcheat/external/B;->l:I

    .line 285
    .line 286
    invoke-virtual {v11, v8}, Lcom/htcheat/external/B;->f(F)I

    .line 287
    .line 288
    .line 289
    move-result v5

    .line 290
    sub-int/2addr v4, v5

    .line 291
    invoke-virtual {v11, v3}, Lcom/htcheat/external/B;->f(F)I

    .line 292
    .line 293
    .line 294
    move-result v3

    .line 295
    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    .line 296
    .line 297
    .line 298
    move-result v2

    .line 299
    invoke-static {v4, v2}, Ljava/lang/Math;->min(II)I

    .line 300
    .line 301
    .line 302
    move-result v22

    .line 303
    if-lt v0, v9, :cond_3

    .line 304
    .line 305
    move/from16 v23, v18

    .line 306
    .line 307
    goto :goto_2

    .line 308
    :cond_3
    const/16 v23, 0x7d2

    .line 309
    .line 310
    :goto_2
    const v24, 0x1000328

    .line 311
    .line 312
    .line 313
    const/16 v25, -0x3

    .line 314
    .line 315
    invoke-direct/range {v20 .. v25}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 316
    .line 317
    .line 318
    move-object/from16 v0, v20

    .line 319
    .line 320
    iput-object v0, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 321
    .line 322
    iput v13, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 323
    .line 324
    invoke-virtual {v11, v7}, Lcom/htcheat/external/B;->f(F)I

    .line 325
    .line 326
    .line 327
    move-result v2

    .line 328
    iget v3, v11, Lcom/htcheat/external/B;->k:I

    .line 329
    .line 330
    iget-object v4, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 331
    .line 332
    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 333
    .line 334
    sub-int/2addr v3, v4

    .line 335
    div-int/lit8 v3, v3, 0x2

    .line 336
    .line 337
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 338
    .line 339
    .line 340
    move-result v2

    .line 341
    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 342
    .line 343
    iget-object v0, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 344
    .line 345
    const/high16 v2, 0x42080000    # 34.0f

    .line 346
    .line 347
    invoke-virtual {v11, v2}, Lcom/htcheat/external/B;->f(F)I

    .line 348
    .line 349
    .line 350
    move-result v2

    .line 351
    iget v3, v11, Lcom/htcheat/external/B;->l:I

    .line 352
    .line 353
    iget-object v4, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 354
    .line 355
    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 356
    .line 357
    sub-int/2addr v3, v4

    .line 358
    div-int/lit8 v3, v3, 0x2

    .line 359
    .line 360
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 361
    .line 362
    .line 363
    move-result v2

    .line 364
    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 365
    .line 366
    new-instance v0, Lcom/htcheat/external/m;

    .line 367
    .line 368
    new-instance v2, Lcom/htcheat/external/f;

    .line 369
    .line 370
    invoke-direct {v2, v11}, Lcom/htcheat/external/f;-><init>(Lcom/htcheat/external/B;)V

    .line 371
    .line 372
    .line 373
    new-instance v3, LA1/W;

    .line 374
    .line 375
    invoke-direct {v3, v11}, LA1/W;-><init>(Lcom/htcheat/external/B;)V

    .line 376
    .line 377
    .line 378
    new-instance v4, LA1/W;

    .line 379
    .line 380
    invoke-direct {v4, v11}, LA1/W;-><init>(Lcom/htcheat/external/B;)V

    .line 381
    .line 382
    .line 383
    invoke-direct {v0, v11, v2, v3, v4}, Lcom/htcheat/external/m;-><init>(Landroid/content/Context;Lcom/htcheat/external/f;LA1/W;LA1/W;)V

    .line 384
    .line 385
    .line 386
    iput-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 387
    .line 388
    :try_start_0
    iget-object v0, v11, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 389
    .line 390
    iget-object v2, v11, Lcom/htcheat/external/B;->e:Lcom/htcheat/external/g;

    .line 391
    .line 392
    iget-object v3, v11, Lcom/htcheat/external/B;->h:Landroid/view/WindowManager$LayoutParams;

    .line 393
    .line 394
    invoke-interface {v0, v2, v3}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 395
    .line 396
    .line 397
    iget-object v0, v11, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 398
    .line 399
    iget-object v2, v11, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 400
    .line 401
    iget-object v3, v11, Lcom/htcheat/external/B;->i:Landroid/view/WindowManager$LayoutParams;

    .line 402
    .line 403
    invoke-interface {v0, v2, v3}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 404
    .line 405
    .line 406
    iget-object v0, v11, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 407
    .line 408
    iget-object v2, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 409
    .line 410
    iget-object v3, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 411
    .line 412
    invoke-interface {v0, v2, v3}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 413
    .line 414
    .line 415
    iget-object v0, v11, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 416
    .line 417
    const/16 v2, 0x8

    .line 418
    .line 419
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 420
    .line 421
    .line 422
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 423
    .line 424
    const/4 v3, 0x0

    .line 425
    invoke-virtual {v0, v3}, Landroid/view/View;->setAlpha(F)V

    .line 426
    .line 427
    .line 428
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 429
    .line 430
    const v3, 0x3f75c28f    # 0.96f

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v3}, Landroid/view/View;->setScaleX(F)V

    .line 434
    .line 435
    .line 436
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 437
    .line 438
    invoke-virtual {v0, v3}, Landroid/view/View;->setScaleY(F)V

    .line 439
    .line 440
    .line 441
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 442
    .line 443
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 444
    .line 445
    .line 446
    const-wide v2, -0x37443377dbfaL

    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 452
    .line 453
    .line 454
    goto :goto_3

    .line 455
    :catch_0
    move-exception v0

    .line 456
    const-wide v2, -0x37643377dbfaL

    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 465
    .line 466
    .line 467
    :goto_3
    return-void

    .line 468
    :pswitch_3
    iget-object v0, v11, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 469
    .line 470
    if-eqz v0, :cond_4

    .line 471
    .line 472
    invoke-virtual {v0, v10}, LA1/c0;->a(Z)V

    .line 473
    .line 474
    .line 475
    :cond_4
    return-void

    .line 476
    :pswitch_4
    sget v0, Lcom/htcheat/external/B;->C:I

    .line 477
    .line 478
    new-instance v0, Lcom/htcheat/external/j;

    .line 479
    .line 480
    invoke-direct {v0, v11}, Lcom/htcheat/external/j;-><init>(Landroid/content/Context;)V

    .line 481
    .line 482
    .line 483
    invoke-virtual {v0}, Lcom/htcheat/external/j;->g()V

    .line 484
    .line 485
    .line 486
    iget-object v0, v11, Lcom/htcheat/external/B;->r:Landroid/os/Handler;

    .line 487
    .line 488
    new-instance v2, LA1/V;

    .line 489
    .line 490
    invoke-direct {v2, v11, v9}, LA1/V;-><init>(Lcom/htcheat/external/B;I)V

    .line 491
    .line 492
    .line 493
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 494
    .line 495
    .line 496
    return-void

    .line 497
    :pswitch_5
    sget v0, Lcom/htcheat/external/B;->C:I

    .line 498
    .line 499
    invoke-virtual {v11}, Lcom/htcheat/external/B;->e()Z

    .line 500
    .line 501
    .line 502
    move-result v0

    .line 503
    if-nez v0, :cond_5

    .line 504
    .line 505
    new-instance v0, Lcom/htcheat/external/j;

    .line 506
    .line 507
    invoke-direct {v0, v11}, Lcom/htcheat/external/j;-><init>(Landroid/content/Context;)V

    .line 508
    .line 509
    .line 510
    invoke-virtual {v0}, Lcom/htcheat/external/j;->g()V

    .line 511
    .line 512
    .line 513
    invoke-virtual {v11}, Landroid/app/Service;->stopSelf()V

    .line 514
    .line 515
    .line 516
    goto/16 :goto_6

    .line 517
    .line 518
    :cond_5
    iget-boolean v2, v11, Lcom/htcheat/external/B;->m:Z

    .line 519
    .line 520
    xor-int/lit8 v0, v2, 0x1

    .line 521
    .line 522
    iput-boolean v0, v11, Lcom/htcheat/external/B;->m:Z

    .line 523
    .line 524
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 525
    .line 526
    if-nez v0, :cond_6

    .line 527
    .line 528
    goto/16 :goto_6

    .line 529
    .line 530
    :cond_6
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 531
    .line 532
    .line 533
    move-result-object v0

    .line 534
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 535
    .line 536
    .line 537
    if-nez v2, :cond_9

    .line 538
    .line 539
    invoke-virtual {v11}, Lcom/htcheat/external/B;->g()V

    .line 540
    .line 541
    .line 542
    iget-object v0, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 543
    .line 544
    if-nez v0, :cond_7

    .line 545
    .line 546
    goto :goto_4

    .line 547
    :cond_7
    invoke-virtual {v11, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 548
    .line 549
    .line 550
    move-result v6

    .line 551
    iget v7, v11, Lcom/htcheat/external/B;->k:I

    .line 552
    .line 553
    invoke-virtual {v11, v8}, Lcom/htcheat/external/B;->f(F)I

    .line 554
    .line 555
    .line 556
    move-result v9

    .line 557
    sub-int/2addr v7, v9

    .line 558
    invoke-virtual {v11, v5}, Lcom/htcheat/external/B;->f(F)I

    .line 559
    .line 560
    .line 561
    move-result v5

    .line 562
    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    .line 563
    .line 564
    .line 565
    move-result v5

    .line 566
    invoke-static {v7, v5}, Ljava/lang/Math;->min(II)I

    .line 567
    .line 568
    .line 569
    move-result v5

    .line 570
    iput v5, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 571
    .line 572
    iget-object v0, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 573
    .line 574
    invoke-virtual {v11, v4}, Lcom/htcheat/external/B;->f(F)I

    .line 575
    .line 576
    .line 577
    move-result v4

    .line 578
    iget v5, v11, Lcom/htcheat/external/B;->l:I

    .line 579
    .line 580
    invoke-virtual {v11, v8}, Lcom/htcheat/external/B;->f(F)I

    .line 581
    .line 582
    .line 583
    move-result v6

    .line 584
    sub-int/2addr v5, v6

    .line 585
    invoke-virtual {v11, v3}, Lcom/htcheat/external/B;->f(F)I

    .line 586
    .line 587
    .line 588
    move-result v3

    .line 589
    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    .line 590
    .line 591
    .line 592
    move-result v3

    .line 593
    invoke-static {v5, v3}, Ljava/lang/Math;->min(II)I

    .line 594
    .line 595
    .line 596
    move-result v3

    .line 597
    iput v3, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 598
    .line 599
    :goto_4
    iget-boolean v0, v11, Lcom/htcheat/external/B;->n:Z

    .line 600
    .line 601
    if-nez v0, :cond_8

    .line 602
    .line 603
    invoke-virtual {v11}, Lcom/htcheat/external/B;->b()V

    .line 604
    .line 605
    .line 606
    :cond_8
    :try_start_1
    iget-object v0, v11, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 607
    .line 608
    iget-object v3, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 609
    .line 610
    iget-object v4, v11, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 611
    .line 612
    invoke-interface {v0, v3, v4}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 613
    .line 614
    .line 615
    goto :goto_5

    .line 616
    :catch_1
    move-exception v0

    .line 617
    const-wide v3, -0x377b3377dbfaL

    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 623
    .line 624
    .line 625
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 626
    .line 627
    .line 628
    :cond_9
    :goto_5
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 629
    .line 630
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 631
    .line 632
    .line 633
    move-result v3

    .line 634
    int-to-float v3, v3

    .line 635
    const/high16 v4, 0x3f000000    # 0.5f

    .line 636
    .line 637
    mul-float/2addr v3, v4

    .line 638
    invoke-virtual {v0, v3}, Landroid/view/View;->setPivotX(F)V

    .line 639
    .line 640
    .line 641
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 642
    .line 643
    const/high16 v3, 0x41e00000    # 28.0f

    .line 644
    .line 645
    invoke-virtual {v11, v3}, Lcom/htcheat/external/B;->f(F)I

    .line 646
    .line 647
    .line 648
    move-result v3

    .line 649
    int-to-float v3, v3

    .line 650
    invoke-virtual {v0, v3}, Landroid/view/View;->setPivotY(F)V

    .line 651
    .line 652
    .line 653
    if-nez v2, :cond_a

    .line 654
    .line 655
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 656
    .line 657
    invoke-virtual {v0, v10}, Landroid/view/View;->setVisibility(I)V

    .line 658
    .line 659
    .line 660
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 661
    .line 662
    const/4 v3, 0x0

    .line 663
    invoke-virtual {v0, v3}, Landroid/view/View;->setAlpha(F)V

    .line 664
    .line 665
    .line 666
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 667
    .line 668
    const v3, 0x3f75c28f    # 0.96f

    .line 669
    .line 670
    .line 671
    invoke-virtual {v0, v3}, Landroid/view/View;->setScaleX(F)V

    .line 672
    .line 673
    .line 674
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 675
    .line 676
    invoke-virtual {v0, v3}, Landroid/view/View;->setScaleY(F)V

    .line 677
    .line 678
    .line 679
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 680
    .line 681
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 682
    .line 683
    .line 684
    move-result-object v0

    .line 685
    const/high16 v2, 0x3f800000    # 1.0f

    .line 686
    .line 687
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 688
    .line 689
    .line 690
    move-result-object v0

    .line 691
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    .line 692
    .line 693
    .line 694
    move-result-object v0

    .line 695
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    .line 696
    .line 697
    .line 698
    move-result-object v0

    .line 699
    const-wide/16 v2, 0xbe

    .line 700
    .line 701
    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 702
    .line 703
    .line 704
    move-result-object v0

    .line 705
    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    .line 706
    .line 707
    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 708
    .line 709
    .line 710
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 711
    .line 712
    .line 713
    move-result-object v0

    .line 714
    const/4 v2, 0x0

    .line 715
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    .line 716
    .line 717
    .line 718
    move-result-object v0

    .line 719
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 720
    .line 721
    .line 722
    goto :goto_6

    .line 723
    :cond_a
    iget-object v0, v11, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 724
    .line 725
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 726
    .line 727
    .line 728
    move-result-object v0

    .line 729
    const/4 v3, 0x0

    .line 730
    invoke-virtual {v0, v3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 731
    .line 732
    .line 733
    move-result-object v0

    .line 734
    const v2, 0x3f7851ec    # 0.97f

    .line 735
    .line 736
    .line 737
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    .line 738
    .line 739
    .line 740
    move-result-object v0

    .line 741
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    .line 742
    .line 743
    .line 744
    move-result-object v0

    .line 745
    const-wide/16 v2, 0x8c

    .line 746
    .line 747
    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 748
    .line 749
    .line 750
    move-result-object v0

    .line 751
    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    .line 752
    .line 753
    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 754
    .line 755
    .line 756
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 757
    .line 758
    .line 759
    move-result-object v0

    .line 760
    new-instance v2, LA1/Z;

    .line 761
    .line 762
    invoke-direct {v2, v11}, LA1/Z;-><init>(Lcom/htcheat/external/B;)V

    .line 763
    .line 764
    .line 765
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 770
    .line 771
    .line 772
    :goto_6
    return-void

    .line 773
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
