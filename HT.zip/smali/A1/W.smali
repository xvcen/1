.class public final synthetic LA1/W;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/htcheat/external/B;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/B;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA1/W;->a:Lcom/htcheat/external/B;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
