.class public final synthetic LA1/X;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:Lcom/htcheat/external/B;

.field public final synthetic e:Z

.field public final synthetic f:Z


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/B;ZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/X;->d:Lcom/htcheat/external/B;

    iput-boolean p2, p0, LA1/X;->e:Z

    iput-boolean p3, p0, LA1/X;->f:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, LA1/X;->d:Lcom/htcheat/external/B;

    .line 2
    .line 3
    iget-object v1, v0, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 4
    .line 5
    if-eqz v1, :cond_1

    .line 6
    .line 7
    iget-boolean v2, p0, LA1/X;->e:Z

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/16 v2, 0x8

    .line 14
    .line 15
    :goto_0
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    :cond_1
    iget-boolean v1, p0, LA1/X;->f:Z

    .line 19
    .line 20
    iput-boolean v1, v0, Lcom/htcheat/external/B;->o:Z

    .line 21
    .line 22
    iget-object v0, v0, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 23
    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    invoke-virtual {v0, v1}, LA1/c0;->a(Z)V

    .line 27
    .line 28
    .line 29
    :cond_2
    return-void
.end method
