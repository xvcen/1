.class public final LA1/Y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/htcheat/external/B;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/B;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/Y;->d:I

    iput-object p1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 1
    iget v0, p0, LA1/Y;->d:I

    .line 2
    .line 3
    const-wide/16 v1, 0x3e8

    .line 4
    .line 5
    const/4 v3, 0x1

    .line 6
    const/4 v4, 0x0

    .line 7
    const/16 v5, 0x29

    .line 8
    .line 9
    const/16 v6, 0x1f

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    new-instance v0, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 20
    .line 21
    iget-object v7, v1, Lcom/htcheat/external/B;->v:Ljava/lang/Object;

    .line 22
    .line 23
    monitor-enter v7

    .line 24
    :try_start_0
    iget-object v1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 25
    .line 26
    iget-object v1, v1, Lcom/htcheat/external/B;->w:Ljava/util/HashMap;

    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    monitor-exit v7

    .line 35
    goto/16 :goto_2

    .line 36
    .line 37
    :catchall_0
    move-exception v0

    .line 38
    goto/16 :goto_3

    .line 39
    .line 40
    :cond_0
    iget-object v1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 41
    .line 42
    iget-object v1, v1, Lcom/htcheat/external/B;->w:Ljava/util/HashMap;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 45
    .line 46
    .line 47
    iget-object v1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 48
    .line 49
    iget-object v1, v1, Lcom/htcheat/external/B;->w:Ljava/util/HashMap;

    .line 50
    .line 51
    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    .line 52
    .line 53
    .line 54
    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 55
    iget-object v1, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 56
    .line 57
    invoke-virtual {v1}, Lcom/htcheat/external/B;->d()Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_1

    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    if-eqz v1, :cond_5

    .line 76
    .line 77
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    check-cast v1, Ljava/util/Map$Entry;

    .line 82
    .line 83
    const-wide v2, -0x36513377dbfaL

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    const-wide v2, -0x36773377dbfaL

    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    check-cast v1, Ljava/lang/String;

    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_1
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    :cond_2
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    if-eqz v1, :cond_5

    .line 126
    .line 127
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    check-cast v1, Ljava/util/Map$Entry;

    .line 132
    .line 133
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    check-cast v2, Ljava/lang/Integer;

    .line 138
    .line 139
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    check-cast v1, Ljava/lang/String;

    .line 148
    .line 149
    iget-object v7, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 150
    .line 151
    iget-object v7, v7, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 152
    .line 153
    invoke-virtual {v7, v2, v1}, Lcom/htcheat/external/i;->i(ILjava/lang/String;)Z

    .line 154
    .line 155
    .line 156
    move-result v7

    .line 157
    if-nez v7, :cond_3

    .line 158
    .line 159
    const-wide v1, -0x36713377dbfaL

    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    const-wide v1, -0x36723377dbfaL

    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    const-wide v1, -0x367c3377dbfaL

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    goto :goto_1

    .line 184
    :cond_3
    if-ne v2, v6, :cond_2

    .line 185
    .line 186
    const-wide v7, -0x37863377dbfaL

    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    invoke-static {v7, v8}, LI1/a;->a(J)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v2

    .line 195
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    move-result v1

    .line 199
    if-nez v1, :cond_4

    .line 200
    .line 201
    iget-object v2, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 202
    .line 203
    iget-object v2, v2, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 204
    .line 205
    const-wide v7, -0x37803377dbfaL

    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    invoke-static {v7, v8}, LI1/a;->a(J)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v7

    .line 214
    invoke-virtual {v2, v5, v7}, Lcom/htcheat/external/i;->i(ILjava/lang/String;)Z

    .line 215
    .line 216
    .line 217
    move-result v2

    .line 218
    if-eqz v2, :cond_4

    .line 219
    .line 220
    iget-object v2, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 221
    .line 222
    iput-boolean v4, v2, Lcom/htcheat/external/B;->o:Z

    .line 223
    .line 224
    :cond_4
    iget-object v2, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 225
    .line 226
    iget-object v2, v2, Lcom/htcheat/external/B;->r:Landroid/os/Handler;

    .line 227
    .line 228
    new-instance v7, LA1/h;

    .line 229
    .line 230
    invoke-direct {v7, v3, p0, v1}, LA1/h;-><init>(ILjava/lang/Object;Z)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v2, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 234
    .line 235
    .line 236
    goto :goto_1

    .line 237
    :cond_5
    :goto_2
    return-void

    .line 238
    :goto_3
    :try_start_1
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 239
    throw v0

    .line 240
    :pswitch_0
    iget-object v0, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 241
    .line 242
    :try_start_2
    sget v3, Lcom/htcheat/external/B;->C:I

    .line 243
    .line 244
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 245
    .line 246
    .line 247
    :catchall_1
    iget-object v0, v0, Lcom/htcheat/external/B;->t:Landroid/os/Handler;

    .line 248
    .line 249
    if-eqz v0, :cond_6

    .line 250
    .line 251
    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 252
    .line 253
    .line 254
    :cond_6
    return-void

    .line 255
    :pswitch_1
    iget-object v0, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 256
    .line 257
    :try_start_3
    sget v7, Lcom/htcheat/external/B;->C:I

    .line 258
    .line 259
    invoke-virtual {v0}, Lcom/htcheat/external/B;->d()Z

    .line 260
    .line 261
    .line 262
    move-result v7

    .line 263
    if-nez v7, :cond_7

    .line 264
    .line 265
    goto :goto_5

    .line 266
    :cond_7
    const-wide v7, -0x377f3377dbfaL

    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    invoke-static {v7, v8}, LI1/a;->a(J)Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v7

    .line 275
    iget-object v8, v0, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 276
    .line 277
    invoke-virtual {v8, v6}, Lcom/htcheat/external/i;->c(I)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object v6

    .line 281
    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 282
    .line 283
    .line 284
    move-result v6

    .line 285
    if-eqz v6, :cond_8

    .line 286
    .line 287
    const-wide v7, -0x37793377dbfaL

    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    invoke-static {v7, v8}, LI1/a;->a(J)Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v7

    .line 296
    iget-object v8, v0, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 297
    .line 298
    invoke-virtual {v8, v5}, Lcom/htcheat/external/i;->c(I)Ljava/lang/String;

    .line 299
    .line 300
    .line 301
    move-result-object v5

    .line 302
    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 303
    .line 304
    .line 305
    move-result v5

    .line 306
    if-eqz v5, :cond_8

    .line 307
    .line 308
    goto :goto_4

    .line 309
    :cond_8
    move v3, v4

    .line 310
    :goto_4
    iget-object v4, v0, Lcom/htcheat/external/B;->r:Landroid/os/Handler;

    .line 311
    .line 312
    new-instance v5, LA1/X;

    .line 313
    .line 314
    invoke-direct {v5, v0, v6, v3}, LA1/X;-><init>(Lcom/htcheat/external/B;ZZ)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 318
    .line 319
    .line 320
    :catchall_2
    :goto_5
    iget-object v0, v0, Lcom/htcheat/external/B;->t:Landroid/os/Handler;

    .line 321
    .line 322
    if-eqz v0, :cond_9

    .line 323
    .line 324
    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 325
    .line 326
    .line 327
    :cond_9
    return-void

    .line 328
    :pswitch_2
    :try_start_4
    iget-object v0, p0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 329
    .line 330
    invoke-static {v0}, Lcom/htcheat/external/B;->a(Lcom/htcheat/external/B;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 331
    .line 332
    .line 333
    :catchall_3
    return-void

    .line 334
    nop

    .line 335
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
