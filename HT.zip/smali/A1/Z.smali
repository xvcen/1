.class public final LA1/Z;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/htcheat/external/B;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/B;)V
    .locals 0

    .line 1
    iput-object p1, p0, LA1/Z;->a:Lcom/htcheat/external/B;

    .line 2
    .line 3
    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget-object p1, p0, LA1/Z;->a:Lcom/htcheat/external/B;

    .line 2
    .line 3
    iget-boolean v0, p1, Lcom/htcheat/external/B;->m:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object p1, p1, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const/16 v0, 0x8

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method
