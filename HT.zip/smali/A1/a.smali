.class public final synthetic LA1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LI/b0;


# direct methods
.method public synthetic constructor <init>(LI/b0;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/a;->d:I

    iput-object p1, p0, LA1/a;->e:LI/b0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LA1/a;->d:I

    .line 2
    .line 3
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 4
    .line 5
    iget-object v2, p0, LA1/a;->e:LI/b0;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Lc0/b;

    .line 11
    .line 12
    invoke-interface {v2}, LI/a1;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, LU1/c;

    .line 17
    .line 18
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    check-cast p1, LI/I;

    .line 23
    .line 24
    new-instance p1, LB/l;

    .line 25
    .line 26
    const/4 v0, 0x5

    .line 27
    invoke-direct {p1, v0, v2}, LB/l;-><init>(ILjava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object p1

    .line 31
    :pswitch_1
    check-cast p1, Ljava/lang/Float;

    .line 32
    .line 33
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    invoke-interface {v2}, LI/a1;->getValue()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    check-cast v0, LU1/c;

    .line 41
    .line 42
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    check-cast p1, Ljava/lang/Number;

    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    return-object p1

    .line 57
    :pswitch_2
    check-cast p1, Lu0/r;

    .line 58
    .line 59
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    return-object v1

    .line 63
    :pswitch_3
    check-cast p1, Lu0/r;

    .line 64
    .line 65
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    return-object v1

    .line 69
    :pswitch_4
    check-cast p1, Lu0/r;

    .line 70
    .line 71
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    return-object v1

    .line 75
    :pswitch_5
    check-cast p1, Ljava/lang/Boolean;

    .line 76
    .line 77
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 78
    .line 79
    .line 80
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 81
    .line 82
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    return-object v1

    .line 86
    :pswitch_6
    check-cast p1, Ljava/lang/String;

    .line 87
    .line 88
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 89
    .line 90
    const-wide v3, -0x3b763377dbfaL

    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    return-object v1

    .line 106
    :pswitch_7
    check-cast p1, Ljava/lang/Boolean;

    .line 107
    .line 108
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 109
    .line 110
    .line 111
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 112
    .line 113
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    return-object v1

    .line 117
    :pswitch_8
    check-cast p1, Ljava/lang/String;

    .line 118
    .line 119
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 120
    .line 121
    const-wide v3, -0x3b733377dbfaL

    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 134
    .line 135
    invoke-static {v0, p1}, LA1/i;->e(LA1/i;Ljava/lang/String;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    return-object v1

    .line 143
    :pswitch_9
    check-cast p1, LA1/d0;

    .line 144
    .line 145
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 146
    .line 147
    invoke-interface {v2, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    return-object v1

    .line 151
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
