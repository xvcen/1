.class public final LA1/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public a:F

.field public b:F

.field public c:I

.field public d:I

.field public e:Z

.field public final synthetic f:Landroid/view/WindowManager$LayoutParams;

.field public final synthetic g:Ljava/lang/Runnable;

.field public final synthetic h:Lcom/htcheat/external/B;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/B;Landroid/view/WindowManager$LayoutParams;Ljava/lang/Runnable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LA1/a0;->f:Landroid/view/WindowManager$LayoutParams;

    .line 5
    .line 6
    iput-object p3, p0, LA1/a0;->g:Ljava/lang/Runnable;

    .line 7
    .line 8
    iput-object p1, p0, LA1/a0;->h:Lcom/htcheat/external/B;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 8

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LA1/a0;->f:Landroid/view/WindowManager$LayoutParams;

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    goto/16 :goto_1

    .line 7
    .line 8
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v2, :cond_8

    .line 14
    .line 15
    if-eq v2, v0, :cond_6

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    if-eq v2, v4, :cond_1

    .line 19
    .line 20
    goto/16 :goto_1

    .line 21
    .line 22
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    iget v4, p0, LA1/a0;->a:F

    .line 27
    .line 28
    sub-float/2addr v2, v4

    .line 29
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    iget v4, p0, LA1/a0;->b:F

    .line 38
    .line 39
    sub-float/2addr p2, v4

    .line 40
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 41
    .line 42
    .line 43
    move-result p2

    .line 44
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    .line 45
    .line 46
    .line 47
    move-result v4

    .line 48
    sget v5, Lcom/htcheat/external/B;->C:I

    .line 49
    .line 50
    iget-object v5, p0, LA1/a0;->h:Lcom/htcheat/external/B;

    .line 51
    .line 52
    const/high16 v6, 0x40c00000    # 6.0f

    .line 53
    .line 54
    invoke-virtual {v5, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    if-gt v4, v7, :cond_2

    .line 59
    .line 60
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 61
    .line 62
    .line 63
    move-result v4

    .line 64
    invoke-virtual {v5, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    if-le v4, v6, :cond_3

    .line 69
    .line 70
    :cond_2
    iput-boolean v0, p0, LA1/a0;->e:Z

    .line 71
    .line 72
    :cond_3
    iget-boolean v4, p0, LA1/a0;->e:Z

    .line 73
    .line 74
    if-eqz v4, :cond_4

    .line 75
    .line 76
    iget-object v4, v5, Lcom/htcheat/external/B;->j:Landroid/view/WindowManager$LayoutParams;

    .line 77
    .line 78
    if-ne v1, v4, :cond_4

    .line 79
    .line 80
    iput-boolean v0, v5, Lcom/htcheat/external/B;->n:Z

    .line 81
    .line 82
    :cond_4
    iget v4, p0, LA1/a0;->c:I

    .line 83
    .line 84
    add-int/2addr v4, v2

    .line 85
    iget v2, v5, Lcom/htcheat/external/B;->k:I

    .line 86
    .line 87
    iget v6, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 88
    .line 89
    sub-int/2addr v2, v6

    .line 90
    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    .line 91
    .line 92
    .line 93
    move-result v2

    .line 94
    invoke-static {v4, v2}, Lcom/htcheat/external/B;->c(II)I

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 99
    .line 100
    iget v2, p0, LA1/a0;->d:I

    .line 101
    .line 102
    add-int/2addr v2, p2

    .line 103
    iget p2, v5, Lcom/htcheat/external/B;->l:I

    .line 104
    .line 105
    iget v4, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 106
    .line 107
    sub-int/2addr p2, v4

    .line 108
    invoke-static {v3, p2}, Ljava/lang/Math;->max(II)I

    .line 109
    .line 110
    .line 111
    move-result p2

    .line 112
    invoke-static {v2, p2}, Lcom/htcheat/external/B;->c(II)I

    .line 113
    .line 114
    .line 115
    move-result p2

    .line 116
    iput p2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 117
    .line 118
    :try_start_0
    iget-object p2, v5, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 119
    .line 120
    iget-object v2, v5, Lcom/htcheat/external/B;->e:Lcom/htcheat/external/g;

    .line 121
    .line 122
    if-ne p1, v2, :cond_5

    .line 123
    .line 124
    goto :goto_0

    .line 125
    :cond_5
    iget-object v2, v5, Lcom/htcheat/external/B;->g:Lcom/htcheat/external/m;

    .line 126
    .line 127
    :goto_0
    invoke-interface {p2, v2, v1}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 128
    .line 129
    .line 130
    return v0

    .line 131
    :catch_0
    move-exception p1

    .line 132
    const-wide v1, -0x37823377dbfaL

    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    return v0

    .line 144
    :cond_6
    iget-boolean p1, p0, LA1/a0;->e:Z

    .line 145
    .line 146
    if-nez p1, :cond_7

    .line 147
    .line 148
    iget-object p1, p0, LA1/a0;->g:Ljava/lang/Runnable;

    .line 149
    .line 150
    if-eqz p1, :cond_7

    .line 151
    .line 152
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    .line 153
    .line 154
    .line 155
    :cond_7
    :goto_1
    return v0

    .line 156
    :cond_8
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 157
    .line 158
    .line 159
    move-result p1

    .line 160
    iput p1, p0, LA1/a0;->a:F

    .line 161
    .line 162
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 163
    .line 164
    .line 165
    move-result p1

    .line 166
    iput p1, p0, LA1/a0;->b:F

    .line 167
    .line 168
    iget p1, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 169
    .line 170
    iput p1, p0, LA1/a0;->c:I

    .line 171
    .line 172
    iget p1, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 173
    .line 174
    iput p1, p0, LA1/a0;->d:I

    .line 175
    .line 176
    iput-boolean v3, p0, LA1/a0;->e:Z

    .line 177
    .line 178
    return v0
.end method
