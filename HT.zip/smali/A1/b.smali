.class public final synthetic LA1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LI/r;LJ/a;LI/L0;LI/a0;)V
    .locals 0

    .line 1
    const/4 p4, 0x1

    iput p4, p0, LA1/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/b;->e:Ljava/lang/Object;

    iput-object p2, p0, LA1/b;->f:Ljava/lang/Object;

    iput-object p3, p0, LA1/b;->g:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p4, p0, LA1/b;->d:I

    iput-object p1, p0, LA1/b;->e:Ljava/lang/Object;

    iput-object p2, p0, LA1/b;->f:Ljava/lang/Object;

    iput-object p3, p0, LA1/b;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, LA1/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lu/j;

    .line 9
    .line 10
    iget-object v1, p0, LA1/b;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lw0/b0;

    .line 13
    .line 14
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, LB0/b;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lu/j;->U0(Lu/j;Lw0/b0;LB0/b;)Lc0/c;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    if-eqz v4, :cond_1

    .line 23
    .line 24
    iget-object v3, v0, Lu/j;->r:Lp/i;

    .line 25
    .line 26
    iget-wide v0, v3, Lp/i;->x:J

    .line 27
    .line 28
    const-wide/16 v5, 0x0

    .line 29
    .line 30
    invoke-static {v0, v1, v5, v6}, LT0/n;->a(JJ)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    const-string v0, "Expected BringIntoViewRequester to not be used before parents are placed."

    .line 37
    .line 38
    invoke-static {v0}, Lr/b;->c(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    iget-wide v5, v3, Lp/i;->x:J

    .line 42
    .line 43
    const-wide/16 v7, 0x0

    .line 44
    .line 45
    invoke-virtual/range {v3 .. v8}, Lp/i;->X0(Lc0/c;JJ)J

    .line 46
    .line 47
    .line 48
    move-result-wide v0

    .line 49
    const-wide v2, -0x7fffffff80000000L    # -1.0609978955E-314

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    xor-long/2addr v0, v2

    .line 55
    invoke-virtual {v4, v0, v1}, Lc0/c;->i(J)Lc0/c;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    goto :goto_0

    .line 60
    :cond_1
    const/4 v0, 0x0

    .line 61
    :goto_0
    return-object v0

    .line 62
    :pswitch_0
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 63
    .line 64
    move-object v1, v0

    .line 65
    check-cast v1, Lp/i;

    .line 66
    .line 67
    iget-object v0, p0, LA1/b;->f:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v0, Lp/t1;

    .line 70
    .line 71
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 72
    .line 73
    move-object v8, v2

    .line 74
    check-cast v8, Lp/c;

    .line 75
    .line 76
    iget-object v9, v1, Lp/i;->v:LA0/h;

    .line 77
    .line 78
    :goto_1
    iget-object v2, v9, LA0/h;->e:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v2, LK/e;

    .line 81
    .line 82
    iget v3, v2, LK/e;->f:I

    .line 83
    .line 84
    sget-object v10, LJ1/m;->a:LJ1/m;

    .line 85
    .line 86
    const/4 v11, 0x1

    .line 87
    if-eqz v3, :cond_4

    .line 88
    .line 89
    if-eqz v3, :cond_3

    .line 90
    .line 91
    add-int/lit8 v3, v3, -0x1

    .line 92
    .line 93
    iget-object v2, v2, LK/e;->d:[Ljava/lang/Object;

    .line 94
    .line 95
    aget-object v2, v2, v3

    .line 96
    .line 97
    check-cast v2, Lp/f;

    .line 98
    .line 99
    iget-object v2, v2, Lp/f;->a:Lu/f;

    .line 100
    .line 101
    invoke-virtual {v2}, Lu/f;->a()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    check-cast v2, Lc0/c;

    .line 106
    .line 107
    if-nez v2, :cond_2

    .line 108
    .line 109
    move v2, v11

    .line 110
    goto :goto_2

    .line 111
    :cond_2
    const-wide/16 v5, 0x0

    .line 112
    .line 113
    const/4 v7, 0x3

    .line 114
    const-wide/16 v3, 0x0

    .line 115
    .line 116
    invoke-static/range {v1 .. v7}, Lp/i;->V0(Lp/i;Lc0/c;JJI)Z

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    :goto_2
    if-eqz v2, :cond_4

    .line 121
    .line 122
    iget-object v2, v9, LA0/h;->e:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v2, LK/e;

    .line 125
    .line 126
    iget v3, v2, LK/e;->f:I

    .line 127
    .line 128
    sub-int/2addr v3, v11

    .line 129
    invoke-virtual {v2, v3}, LK/e;->j(I)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    check-cast v2, Lp/f;

    .line 134
    .line 135
    iget-object v2, v2, Lp/f;->b:Lc2/g;

    .line 136
    .line 137
    invoke-virtual {v2, v10}, Lc2/g;->v(Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    goto :goto_1

    .line 141
    :cond_3
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 142
    .line 143
    const-string v1, "MutableVector is empty."

    .line 144
    .line 145
    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    throw v0

    .line 149
    :cond_4
    iget-boolean v2, v1, Lp/i;->w:Z

    .line 150
    .line 151
    if-eqz v2, :cond_6

    .line 152
    .line 153
    iget-object v2, v1, Lp/i;->u:Lp/C0;

    .line 154
    .line 155
    invoke-virtual {v2}, Lp/C0;->a()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    check-cast v2, Lc0/c;

    .line 160
    .line 161
    const/4 v9, 0x0

    .line 162
    if-eqz v2, :cond_5

    .line 163
    .line 164
    const-wide/16 v5, 0x0

    .line 165
    .line 166
    const/4 v7, 0x3

    .line 167
    const-wide/16 v3, 0x0

    .line 168
    .line 169
    invoke-static/range {v1 .. v7}, Lp/i;->V0(Lp/i;Lc0/c;JJI)Z

    .line 170
    .line 171
    .line 172
    move-result v2

    .line 173
    if-ne v2, v11, :cond_5

    .line 174
    .line 175
    goto :goto_3

    .line 176
    :cond_5
    move v11, v9

    .line 177
    :goto_3
    if-eqz v11, :cond_6

    .line 178
    .line 179
    iput-boolean v9, v1, Lp/i;->w:Z

    .line 180
    .line 181
    :cond_6
    const-wide/16 v2, 0x0

    .line 182
    .line 183
    invoke-static {v1, v8, v2, v3}, Lp/i;->U0(Lp/i;Lp/c;J)F

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    iput v1, v0, Lp/t1;->e:F

    .line 188
    .line 189
    return-object v10

    .line 190
    :pswitch_1
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast v0, LQ/b;

    .line 193
    .line 194
    iget-object v1, p0, LA1/b;->f:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast v1, LH0/r;

    .line 197
    .line 198
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v2, LV1/q;

    .line 201
    .line 202
    invoke-virtual {v0}, LQ/b;->a()V

    .line 203
    .line 204
    .line 205
    iget-object v0, v1, LH0/r;->c:Ljava/lang/Object;

    .line 206
    .line 207
    check-cast v0, LQ/a;

    .line 208
    .line 209
    iget v1, v2, LV1/q;->d:I

    .line 210
    .line 211
    :cond_7
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 212
    .line 213
    .line 214
    move-result v2

    .line 215
    ushr-int/lit8 v3, v2, 0x1b

    .line 216
    .line 217
    and-int/lit8 v3, v3, 0xf

    .line 218
    .line 219
    if-ne v3, v1, :cond_8

    .line 220
    .line 221
    add-int/lit8 v3, v2, -0x1

    .line 222
    .line 223
    goto :goto_4

    .line 224
    :cond_8
    move v3, v2

    .line 225
    :goto_4
    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    if-eqz v2, :cond_7

    .line 230
    .line 231
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 232
    .line 233
    return-object v0

    .line 234
    :pswitch_2
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v0, LI/a;

    .line 237
    .line 238
    iget-object v1, p0, LA1/b;->f:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v1, LI/P0;

    .line 241
    .line 242
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v2, LJ/I;

    .line 245
    .line 246
    if-eqz v0, :cond_9

    .line 247
    .line 248
    invoke-virtual {v1, v0}, LI/P0;->c(LI/a;)I

    .line 249
    .line 250
    .line 251
    move-result v0

    .line 252
    iget v3, v1, LI/P0;->t:I

    .line 253
    .line 254
    sub-int/2addr v0, v3

    .line 255
    invoke-virtual {v1, v0}, LI/P0;->a(I)V

    .line 256
    .line 257
    .line 258
    :cond_9
    iget v0, v1, LI/P0;->t:I

    .line 259
    .line 260
    const/4 v3, 0x0

    .line 261
    invoke-static {v1, v3, v0, v3}, LT0/l;->f(LI/P0;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    const-string v1, "<this>"

    .line 266
    .line 267
    invoke-static {v0, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 271
    .line 272
    .line 273
    move-result v1

    .line 274
    const/4 v4, 0x1

    .line 275
    if-eqz v1, :cond_a

    .line 276
    .line 277
    move-object v1, v3

    .line 278
    goto :goto_5

    .line 279
    :cond_a
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 280
    .line 281
    .line 282
    move-result v1

    .line 283
    sub-int/2addr v1, v4

    .line 284
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object v1

    .line 288
    :goto_5
    check-cast v1, LV/c;

    .line 289
    .line 290
    if-eqz v1, :cond_b

    .line 291
    .line 292
    iget-object v3, v1, LV/c;->b:Ljava/lang/Integer;

    .line 293
    .line 294
    :cond_b
    invoke-interface {v2, v3}, LJ/I;->f(Ljava/lang/Integer;)Ljava/util/List;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    if-eqz v3, :cond_11

    .line 299
    .line 300
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 301
    .line 302
    .line 303
    move-result v2

    .line 304
    if-eqz v2, :cond_c

    .line 305
    .line 306
    goto :goto_9

    .line 307
    :cond_c
    invoke-static {v1}, LK1/m;->t0(Ljava/util/List;)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object v2

    .line 311
    check-cast v2, LV/c;

    .line 312
    .line 313
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 314
    .line 315
    .line 316
    move-result v5

    .line 317
    sub-int/2addr v5, v4

    .line 318
    if-gtz v5, :cond_d

    .line 319
    .line 320
    sget-object v1, LK1/t;->d:LK1/t;

    .line 321
    .line 322
    goto :goto_8

    .line 323
    :cond_d
    if-ne v5, v4, :cond_e

    .line 324
    .line 325
    invoke-static {v1}, LK1/m;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 326
    .line 327
    .line 328
    move-result-object v1

    .line 329
    invoke-static {v1}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 330
    .line 331
    .line 332
    move-result-object v1

    .line 333
    goto :goto_8

    .line 334
    :cond_e
    new-instance v6, Ljava/util/ArrayList;

    .line 335
    .line 336
    invoke-direct {v6, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 337
    .line 338
    .line 339
    instance-of v5, v1, Ljava/util/RandomAccess;

    .line 340
    .line 341
    if-eqz v5, :cond_f

    .line 342
    .line 343
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 344
    .line 345
    .line 346
    move-result v5

    .line 347
    :goto_6
    if-ge v4, v5, :cond_10

    .line 348
    .line 349
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v7

    .line 353
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    add-int/lit8 v4, v4, 0x1

    .line 357
    .line 358
    goto :goto_6

    .line 359
    :cond_f
    invoke-interface {v1, v4}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 360
    .line 361
    .line 362
    move-result-object v1

    .line 363
    :goto_7
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 364
    .line 365
    .line 366
    move-result v4

    .line 367
    if-eqz v4, :cond_10

    .line 368
    .line 369
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v4

    .line 373
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 374
    .line 375
    .line 376
    goto :goto_7

    .line 377
    :cond_10
    move-object v1, v6

    .line 378
    :goto_8
    iget v2, v2, LV/c;->a:I

    .line 379
    .line 380
    new-instance v4, LV/c;

    .line 381
    .line 382
    const/4 v5, 0x0

    .line 383
    invoke-direct {v4, v2, v5, v3}, LV/c;-><init>(ILT0/l;Ljava/lang/Integer;)V

    .line 384
    .line 385
    .line 386
    invoke-static {v4}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 387
    .line 388
    .line 389
    move-result-object v2

    .line 390
    invoke-static {v2, v1}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 391
    .line 392
    .line 393
    move-result-object v1

    .line 394
    :cond_11
    :goto_9
    new-instance v2, LV/a;

    .line 395
    .line 396
    invoke-static {v0, v1}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    invoke-direct {v2, v0}, LV/a;-><init>(Ljava/util/List;)V

    .line 401
    .line 402
    .line 403
    return-object v2

    .line 404
    :pswitch_3
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 405
    .line 406
    move-object v1, v0

    .line 407
    check-cast v1, LI/r;

    .line 408
    .line 409
    iget-object v0, p0, LA1/b;->f:Ljava/lang/Object;

    .line 410
    .line 411
    check-cast v0, LJ/a;

    .line 412
    .line 413
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 414
    .line 415
    check-cast v2, LI/L0;

    .line 416
    .line 417
    iget-object v3, v1, LI/r;->L:LJ/b;

    .line 418
    .line 419
    iget-object v4, v3, LJ/b;->b:LJ/a;

    .line 420
    .line 421
    :try_start_0
    iput-object v0, v3, LJ/b;->b:LJ/a;

    .line 422
    .line 423
    iget-object v5, v1, LI/r;->F:LI/L0;

    .line 424
    .line 425
    iget-object v6, v1, LI/r;->n:[I

    .line 426
    .line 427
    iget-object v7, v1, LI/r;->u:Li/x;

    .line 428
    .line 429
    const/4 v0, 0x0

    .line 430
    iput-object v0, v1, LI/r;->n:[I

    .line 431
    .line 432
    iput-object v0, v1, LI/r;->u:Li/x;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 433
    .line 434
    :try_start_1
    iput-object v2, v1, LI/r;->F:LI/L0;

    .line 435
    .line 436
    iget-boolean v2, v3, LJ/b;->e:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 437
    .line 438
    const/4 v0, 0x0

    .line 439
    :try_start_2
    iput-boolean v0, v3, LJ/b;->e:Z

    .line 440
    .line 441
    const/4 v0, 0x0

    .line 442
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 443
    :catchall_0
    move-exception v0

    .line 444
    :try_start_3
    iput-boolean v2, v3, LJ/b;->e:Z

    .line 445
    .line 446
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 447
    :catchall_1
    move-exception v0

    .line 448
    :try_start_4
    iput-object v5, v1, LI/r;->F:LI/L0;

    .line 449
    .line 450
    iput-object v6, v1, LI/r;->n:[I

    .line 451
    .line 452
    iput-object v7, v1, LI/r;->u:Li/x;

    .line 453
    .line 454
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 455
    :catchall_2
    move-exception v0

    .line 456
    iput-object v4, v3, LJ/b;->b:LJ/a;

    .line 457
    .line 458
    throw v0

    .line 459
    :pswitch_4
    iget-object v0, p0, LA1/b;->e:Ljava/lang/Object;

    .line 460
    .line 461
    check-cast v0, Lcom/htcheat/external/A;

    .line 462
    .line 463
    iget-object v1, p0, LA1/b;->f:Ljava/lang/Object;

    .line 464
    .line 465
    check-cast v1, LI/b0;

    .line 466
    .line 467
    iget-object v2, p0, LA1/b;->g:Ljava/lang/Object;

    .line 468
    .line 469
    check-cast v2, LI/b0;

    .line 470
    .line 471
    sget-object v3, Lcom/htcheat/external/A;->H:LA1/i;

    .line 472
    .line 473
    invoke-interface {v1}, LI/a1;->getValue()Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    check-cast v1, Ljava/lang/String;

    .line 478
    .line 479
    invoke-static {v3, v1}, LA1/i;->e(LA1/i;Ljava/lang/String;)Ljava/lang/String;

    .line 480
    .line 481
    .line 482
    move-result-object v1

    .line 483
    invoke-virtual {v0}, Lcom/htcheat/external/A;->j()Z

    .line 484
    .line 485
    .line 486
    move-result v3

    .line 487
    if-nez v3, :cond_12

    .line 488
    .line 489
    invoke-virtual {v0}, Lcom/htcheat/external/A;->i()V

    .line 490
    .line 491
    .line 492
    goto :goto_a

    .line 493
    :cond_12
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 494
    .line 495
    .line 496
    move-result v3

    .line 497
    if-nez v3, :cond_13

    .line 498
    .line 499
    const-wide v1, -0x3b7c3377dbfaL

    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 505
    .line 506
    .line 507
    move-result-object v1

    .line 508
    invoke-virtual {v0, v1}, Lcom/htcheat/external/A;->o(Ljava/lang/String;)V

    .line 509
    .line 510
    .line 511
    goto :goto_a

    .line 512
    :cond_13
    invoke-interface {v2}, LI/a1;->getValue()Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v2

    .line 516
    check-cast v2, Ljava/lang/Boolean;

    .line 517
    .line 518
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 519
    .line 520
    .line 521
    move-result v2

    .line 522
    const/4 v3, 0x0

    .line 523
    invoke-virtual {v0, v1, v2, v3}, Lcom/htcheat/external/A;->g(Ljava/lang/String;ZZ)V

    .line 524
    .line 525
    .line 526
    :goto_a
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 527
    .line 528
    return-object v0

    .line 529
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
