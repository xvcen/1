.class public final LA1/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public a:F

.field public b:F

.field public c:I

.field public d:I

.field public e:Z

.field public final synthetic f:Landroid/view/WindowManager$LayoutParams;

.field public final synthetic g:Lcom/htcheat/external/B;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/B;Landroid/view/WindowManager$LayoutParams;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LA1/b0;->f:Landroid/view/WindowManager$LayoutParams;

    .line 5
    .line 6
    iput-object p1, p0, LA1/b0;->g:Lcom/htcheat/external/B;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 8

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LA1/b0;->f:Landroid/view/WindowManager$LayoutParams;

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    goto/16 :goto_2

    .line 7
    .line 8
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v2, :cond_8

    .line 14
    .line 15
    iget-object v4, p0, LA1/b0;->g:Lcom/htcheat/external/B;

    .line 16
    .line 17
    if-eq v2, v0, :cond_4

    .line 18
    .line 19
    const/4 v5, 0x2

    .line 20
    if-eq v2, v5, :cond_1

    .line 21
    .line 22
    goto/16 :goto_2

    .line 23
    .line 24
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    iget v5, p0, LA1/b0;->a:F

    .line 29
    .line 30
    sub-float/2addr v2, v5

    .line 31
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    iget v5, p0, LA1/b0;->b:F

    .line 40
    .line 41
    sub-float/2addr p2, v5

    .line 42
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    sget v6, Lcom/htcheat/external/B;->C:I

    .line 51
    .line 52
    const/high16 v6, 0x40400000    # 3.0f

    .line 53
    .line 54
    invoke-virtual {v4, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    if-gt v5, v7, :cond_2

    .line 59
    .line 60
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    invoke-virtual {v4, v6}, Lcom/htcheat/external/B;->f(F)I

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    if-le v5, v6, :cond_3

    .line 69
    .line 70
    :cond_2
    iput-boolean v0, p0, LA1/b0;->e:Z

    .line 71
    .line 72
    :cond_3
    iget v5, p0, LA1/b0;->c:I

    .line 73
    .line 74
    add-int/2addr v5, v2

    .line 75
    iget v2, v4, Lcom/htcheat/external/B;->k:I

    .line 76
    .line 77
    iget v6, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 78
    .line 79
    sub-int/2addr v2, v6

    .line 80
    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    invoke-static {v5, v2}, Lcom/htcheat/external/B;->c(II)I

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 89
    .line 90
    iget v2, p0, LA1/b0;->d:I

    .line 91
    .line 92
    add-int/2addr v2, p2

    .line 93
    iget p2, v4, Lcom/htcheat/external/B;->l:I

    .line 94
    .line 95
    iget v5, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 96
    .line 97
    sub-int/2addr p2, v5

    .line 98
    invoke-static {v3, p2}, Ljava/lang/Math;->max(II)I

    .line 99
    .line 100
    .line 101
    move-result p2

    .line 102
    invoke-static {v2, p2}, Lcom/htcheat/external/B;->c(II)I

    .line 103
    .line 104
    .line 105
    move-result p2

    .line 106
    iput p2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 107
    .line 108
    :try_start_0
    iget-object p2, v4, Lcom/htcheat/external/B;->d:Landroid/view/WindowManager;

    .line 109
    .line 110
    invoke-interface {p2, p1, v1}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 111
    .line 112
    .line 113
    return v0

    .line 114
    :cond_4
    iget-boolean p1, p0, LA1/b0;->e:Z

    .line 115
    .line 116
    if-nez p1, :cond_7

    .line 117
    .line 118
    iget-boolean p1, v4, Lcom/htcheat/external/B;->o:Z

    .line 119
    .line 120
    xor-int/2addr p1, v0

    .line 121
    iput-boolean p1, v4, Lcom/htcheat/external/B;->o:Z

    .line 122
    .line 123
    iget-object p2, v4, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 124
    .line 125
    if-eqz p2, :cond_5

    .line 126
    .line 127
    invoke-virtual {p2, p1}, LA1/c0;->a(Z)V

    .line 128
    .line 129
    .line 130
    :cond_5
    iget-boolean p1, v4, Lcom/htcheat/external/B;->o:Z

    .line 131
    .line 132
    if-eqz p1, :cond_6

    .line 133
    .line 134
    const-wide p1, -0x37733377dbfaL

    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    :goto_0
    invoke-static {p1, p2}, LI1/a;->a(J)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    goto :goto_1

    .line 144
    :cond_6
    const-wide p1, -0x377d3377dbfaL

    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    goto :goto_0

    .line 150
    :goto_1
    iget-object p2, v4, Lcom/htcheat/external/B;->t:Landroid/os/Handler;

    .line 151
    .line 152
    new-instance v1, LA1/d;

    .line 153
    .line 154
    invoke-direct {v1, v0, v4, p1}, LA1/d;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 158
    .line 159
    .line 160
    :catch_0
    :cond_7
    :goto_2
    return v0

    .line 161
    :cond_8
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    .line 162
    .line 163
    .line 164
    move-result p1

    .line 165
    iput p1, p0, LA1/b0;->a:F

    .line 166
    .line 167
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    .line 168
    .line 169
    .line 170
    move-result p1

    .line 171
    iput p1, p0, LA1/b0;->b:F

    .line 172
    .line 173
    iget p1, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 174
    .line 175
    iput p1, p0, LA1/b0;->c:I

    .line 176
    .line 177
    iget p1, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 178
    .line 179
    iput p1, p0, LA1/b0;->d:I

    .line 180
    .line 181
    iput-boolean v3, p0, LA1/b0;->e:Z

    .line 182
    .line 183
    return v0
.end method
