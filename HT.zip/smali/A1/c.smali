.class public final synthetic LA1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/c;->d:I

    iput-object p2, p0, LA1/c;->e:Ljava/lang/Object;

    iput-object p3, p0, LA1/c;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lc2/s;LU1/c;)V
    .locals 1

    .line 2
    const/4 v0, 0x7

    iput v0, p0, LA1/c;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/c;->e:Ljava/lang/Object;

    check-cast p2, LP1/i;

    iput-object p2, p0, LA1/c;->f:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LA1/c;->d:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    sget-object v6, LJ1/m;->a:LJ1/m;

    .line 10
    .line 11
    iget-object v7, v1, LA1/c;->f:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v8, v1, LA1/c;->e:Ljava/lang/Object;

    .line 14
    .line 15
    packed-switch v0, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    check-cast v8, LM0/x;

    .line 19
    .line 20
    check-cast v7, LI/b0;

    .line 21
    .line 22
    iget-wide v2, v8, LM0/x;->b:J

    .line 23
    .line 24
    invoke-interface {v7}, LI/a1;->getValue()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, LM0/x;

    .line 29
    .line 30
    iget-wide v4, v0, LM0/x;->b:J

    .line 31
    .line 32
    invoke-static {v2, v3, v4, v5}, LH0/N;->b(JJ)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    iget-object v0, v8, LM0/x;->c:LH0/N;

    .line 39
    .line 40
    invoke-interface {v7}, LI/a1;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    check-cast v2, LM0/x;

    .line 45
    .line 46
    iget-object v2, v2, LM0/x;->c:LH0/N;

    .line 47
    .line 48
    invoke-static {v0, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_1

    .line 53
    .line 54
    :cond_0
    invoke-interface {v7, v8}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_1
    return-object v6

    .line 58
    :pswitch_0
    check-cast v8, LV1/s;

    .line 59
    .line 60
    check-cast v7, Ln/L;

    .line 61
    .line 62
    sget-object v0, Lu0/J;->a:LI/B;

    .line 63
    .line 64
    invoke-static {v7, v0}, Lw0/j;->h(Lw0/g;LI/t0;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    iput-object v0, v8, LV1/s;->d:Ljava/lang/Object;

    .line 69
    .line 70
    return-object v6

    .line 71
    :pswitch_1
    check-cast v8, Ln/x;

    .line 72
    .line 73
    check-cast v7, Lw0/G;

    .line 74
    .line 75
    iget-object v0, v8, Ln/x;->u:Ld0/O;

    .line 76
    .line 77
    iget-object v2, v7, Lw0/G;->d:Lf0/b;

    .line 78
    .line 79
    invoke-interface {v2}, Lf0/d;->a()J

    .line 80
    .line 81
    .line 82
    move-result-wide v2

    .line 83
    invoke-virtual {v7}, Lw0/G;->getLayoutDirection()LT0/o;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    invoke-virtual {v0, v2, v3, v4, v7}, Ld0/O;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iput-object v0, v8, Ln/x;->z:Ld0/D;

    .line 92
    .line 93
    return-object v6

    .line 94
    :pswitch_2
    check-cast v8, LV/e;

    .line 95
    .line 96
    iget-object v0, v8, LV/e;->d:LI/r;

    .line 97
    .line 98
    iget-object v2, v0, LI/r;->c:LI/M0;

    .line 99
    .line 100
    invoke-virtual {v2}, LI/M0;->c()LI/L0;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    move v6, v5

    .line 105
    :goto_0
    :try_start_0
    iget v8, v2, LI/M0;->e:I

    .line 106
    .line 107
    if-ge v6, v8, :cond_b

    .line 108
    .line 109
    invoke-virtual {v4, v6}, LI/L0;->l(I)Z

    .line 110
    .line 111
    .line 112
    move-result v8

    .line 113
    if-eqz v8, :cond_5

    .line 114
    .line 115
    invoke-virtual {v4, v6}, LI/L0;->n(I)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v8

    .line 119
    if-eq v8, v7, :cond_4

    .line 120
    .line 121
    instance-of v9, v8, LI/H0;

    .line 122
    .line 123
    if-eqz v9, :cond_2

    .line 124
    .line 125
    check-cast v8, LI/H0;

    .line 126
    .line 127
    goto :goto_1

    .line 128
    :cond_2
    move-object v8, v3

    .line 129
    :goto_1
    if-eqz v8, :cond_3

    .line 130
    .line 131
    iget-object v8, v8, LI/H0;->a:LI/G0;

    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_3
    move-object v8, v3

    .line 135
    :goto_2
    if-ne v8, v7, :cond_5

    .line 136
    .line 137
    :cond_4
    new-instance v5, LV/j;

    .line 138
    .line 139
    invoke-direct {v5, v6, v3}, LV/j;-><init>(ILjava/lang/Integer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 140
    .line 141
    .line 142
    invoke-virtual {v4}, LI/L0;->c()V

    .line 143
    .line 144
    .line 145
    move-object v3, v5

    .line 146
    goto :goto_8

    .line 147
    :catchall_0
    move-exception v0

    .line 148
    goto/16 :goto_a

    .line 149
    .line 150
    :cond_5
    :try_start_1
    iget-object v8, v4, LI/L0;->b:[I

    .line 151
    .line 152
    invoke-static {v8, v6}, LI/O0;->c([II)I

    .line 153
    .line 154
    .line 155
    move-result v9

    .line 156
    add-int/lit8 v10, v6, 0x1

    .line 157
    .line 158
    iget v11, v4, LI/L0;->c:I

    .line 159
    .line 160
    if-ge v10, v11, :cond_6

    .line 161
    .line 162
    mul-int/lit8 v11, v10, 0x5

    .line 163
    .line 164
    add-int/lit8 v11, v11, 0x4

    .line 165
    .line 166
    aget v8, v8, v11

    .line 167
    .line 168
    goto :goto_3

    .line 169
    :cond_6
    iget v8, v4, LI/L0;->e:I

    .line 170
    .line 171
    :goto_3
    sub-int/2addr v8, v9

    .line 172
    move v9, v5

    .line 173
    :goto_4
    if-ge v9, v8, :cond_c

    .line 174
    .line 175
    invoke-virtual {v4, v6, v9}, LI/L0;->h(II)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v11

    .line 179
    if-eq v11, v7, :cond_a

    .line 180
    .line 181
    instance-of v12, v11, LI/H0;

    .line 182
    .line 183
    if-eqz v12, :cond_7

    .line 184
    .line 185
    check-cast v11, LI/H0;

    .line 186
    .line 187
    goto :goto_5

    .line 188
    :cond_7
    move-object v11, v3

    .line 189
    :goto_5
    if-eqz v11, :cond_8

    .line 190
    .line 191
    iget-object v11, v11, LI/H0;->a:LI/G0;

    .line 192
    .line 193
    goto :goto_6

    .line 194
    :cond_8
    move-object v11, v3

    .line 195
    :goto_6
    if-ne v11, v7, :cond_9

    .line 196
    .line 197
    goto :goto_7

    .line 198
    :cond_9
    add-int/lit8 v9, v9, 0x1

    .line 199
    .line 200
    goto :goto_4

    .line 201
    :cond_a
    :goto_7
    new-instance v3, LV/j;

    .line 202
    .line 203
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 204
    .line 205
    .line 206
    move-result-object v5

    .line 207
    invoke-direct {v3, v6, v5}, LV/j;-><init>(ILjava/lang/Integer;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 208
    .line 209
    .line 210
    :cond_b
    invoke-virtual {v4}, LI/L0;->c()V

    .line 211
    .line 212
    .line 213
    goto :goto_8

    .line 214
    :cond_c
    move v6, v10

    .line 215
    goto :goto_0

    .line 216
    :goto_8
    if-eqz v3, :cond_d

    .line 217
    .line 218
    iget v4, v3, LV/j;->a:I

    .line 219
    .line 220
    iget-object v3, v3, LV/j;->b:Ljava/lang/Integer;

    .line 221
    .line 222
    invoke-virtual {v2}, LI/M0;->c()LI/L0;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    :try_start_2
    invoke-static {v2, v4, v3}, LT0/l;->R(LI/L0;ILjava/lang/Integer;)Ljava/util/ArrayList;

    .line 227
    .line 228
    .line 229
    move-result-object v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 230
    invoke-virtual {v2}, LI/L0;->c()V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v0}, LI/r;->D()Ljava/util/List;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    invoke-static {v3, v0}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    goto :goto_9

    .line 242
    :catchall_1
    move-exception v0

    .line 243
    invoke-virtual {v2}, LI/L0;->c()V

    .line 244
    .line 245
    .line 246
    throw v0

    .line 247
    :cond_d
    sget-object v0, LK1/t;->d:LK1/t;

    .line 248
    .line 249
    :goto_9
    new-instance v2, LV/a;

    .line 250
    .line 251
    invoke-direct {v2, v0}, LV/a;-><init>(Ljava/util/List;)V

    .line 252
    .line 253
    .line 254
    return-object v2

    .line 255
    :goto_a
    invoke-virtual {v4}, LI/L0;->c()V

    .line 256
    .line 257
    .line 258
    throw v0

    .line 259
    :pswitch_3
    check-cast v8, Li/F;

    .line 260
    .line 261
    check-cast v7, LI/y;

    .line 262
    .line 263
    iget-object v0, v8, Li/F;->b:[Ljava/lang/Object;

    .line 264
    .line 265
    iget-object v3, v8, Li/F;->a:[J

    .line 266
    .line 267
    array-length v4, v3

    .line 268
    sub-int/2addr v4, v2

    .line 269
    if-ltz v4, :cond_11

    .line 270
    .line 271
    move v2, v5

    .line 272
    :goto_b
    aget-wide v8, v3, v2

    .line 273
    .line 274
    not-long v10, v8

    .line 275
    const/4 v12, 0x7

    .line 276
    shl-long/2addr v10, v12

    .line 277
    and-long/2addr v10, v8

    .line 278
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    and-long/2addr v10, v12

    .line 284
    cmp-long v10, v10, v12

    .line 285
    .line 286
    if-eqz v10, :cond_10

    .line 287
    .line 288
    sub-int v10, v2, v4

    .line 289
    .line 290
    not-int v10, v10

    .line 291
    ushr-int/lit8 v10, v10, 0x1f

    .line 292
    .line 293
    const/16 v11, 0x8

    .line 294
    .line 295
    rsub-int/lit8 v10, v10, 0x8

    .line 296
    .line 297
    move v12, v5

    .line 298
    :goto_c
    if-ge v12, v10, :cond_f

    .line 299
    .line 300
    const-wide/16 v13, 0xff

    .line 301
    .line 302
    and-long/2addr v13, v8

    .line 303
    const-wide/16 v15, 0x80

    .line 304
    .line 305
    cmp-long v13, v13, v15

    .line 306
    .line 307
    if-gez v13, :cond_e

    .line 308
    .line 309
    shl-int/lit8 v13, v2, 0x3

    .line 310
    .line 311
    add-int/2addr v13, v12

    .line 312
    aget-object v13, v0, v13

    .line 313
    .line 314
    invoke-virtual {v7, v13}, LI/y;->v(Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    :cond_e
    shr-long/2addr v8, v11

    .line 318
    add-int/lit8 v12, v12, 0x1

    .line 319
    .line 320
    goto :goto_c

    .line 321
    :cond_f
    if-ne v10, v11, :cond_11

    .line 322
    .line 323
    :cond_10
    if-eq v2, v4, :cond_11

    .line 324
    .line 325
    add-int/lit8 v2, v2, 0x1

    .line 326
    .line 327
    goto :goto_b

    .line 328
    :cond_11
    return-object v6

    .line 329
    :pswitch_4
    check-cast v8, LI/e0;

    .line 330
    .line 331
    check-cast v7, LI/x0;

    .line 332
    .line 333
    iget-object v0, v8, LI/e0;->d:Ljava/lang/Object;

    .line 334
    .line 335
    check-cast v0, LQ/a;

    .line 336
    .line 337
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 338
    .line 339
    .line 340
    move-result v0

    .line 341
    if-eqz v0, :cond_12

    .line 342
    .line 343
    goto :goto_d

    .line 344
    :cond_12
    invoke-virtual {v7}, LI/x0;->a()Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    :goto_d
    return-object v6

    .line 348
    :pswitch_5
    check-cast v8, Lc2/s;

    .line 349
    .line 350
    check-cast v7, LP1/i;

    .line 351
    .line 352
    new-instance v0, LH/r0;

    .line 353
    .line 354
    invoke-direct {v0, v7, v3}, LH/r0;-><init>(LU1/c;LN1/c;)V

    .line 355
    .line 356
    .line 357
    invoke-static {v8, v3, v0, v4}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 358
    .line 359
    .line 360
    return-object v6

    .line 361
    :pswitch_6
    check-cast v8, LH/m0;

    .line 362
    .line 363
    check-cast v7, LI/b0;

    .line 364
    .line 365
    invoke-interface {v7}, LI/a1;->getValue()Ljava/lang/Object;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    check-cast v0, LT0/n;

    .line 370
    .line 371
    iget-wide v6, v0, LT0/n;->a:J

    .line 372
    .line 373
    invoke-virtual {v8}, LH/m0;->i()Lc0/b;

    .line 374
    .line 375
    .line 376
    move-result-object v0

    .line 377
    const-wide v9, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    if-eqz v0, :cond_1a

    .line 383
    .line 384
    iget-wide v11, v0, Lc0/b;->a:J

    .line 385
    .line 386
    invoke-virtual {v8}, LH/m0;->m()LH0/g;

    .line 387
    .line 388
    .line 389
    move-result-object v0

    .line 390
    if-eqz v0, :cond_1a

    .line 391
    .line 392
    iget-object v0, v0, LH0/g;->e:Ljava/lang/String;

    .line 393
    .line 394
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 395
    .line 396
    .line 397
    move-result v0

    .line 398
    if-nez v0, :cond_13

    .line 399
    .line 400
    goto/16 :goto_11

    .line 401
    .line 402
    :cond_13
    iget-object v0, v8, LH/m0;->r:LI/m0;

    .line 403
    .line 404
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    check-cast v0, Lw/G;

    .line 409
    .line 410
    const/4 v3, -0x1

    .line 411
    if-nez v0, :cond_14

    .line 412
    .line 413
    move v0, v3

    .line 414
    goto :goto_e

    .line 415
    :cond_14
    sget-object v13, LH/o0;->a:[I

    .line 416
    .line 417
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 418
    .line 419
    .line 420
    move-result v0

    .line 421
    aget v0, v13, v0

    .line 422
    .line 423
    :goto_e
    if-eq v0, v3, :cond_1a

    .line 424
    .line 425
    const-wide v13, 0xffffffffL

    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    if-eq v0, v4, :cond_16

    .line 431
    .line 432
    if-eq v0, v2, :cond_16

    .line 433
    .line 434
    const/4 v4, 0x3

    .line 435
    if-ne v0, v4, :cond_15

    .line 436
    .line 437
    invoke-virtual {v8}, LH/m0;->n()LM0/x;

    .line 438
    .line 439
    .line 440
    move-result-object v0

    .line 441
    const/16 v15, 0x20

    .line 442
    .line 443
    iget-wide v3, v0, LM0/x;->b:J

    .line 444
    .line 445
    sget v0, LH0/N;->c:I

    .line 446
    .line 447
    and-long/2addr v3, v13

    .line 448
    :goto_f
    long-to-int v0, v3

    .line 449
    goto :goto_10

    .line 450
    :cond_15
    new-instance v0, LC0/e;

    .line 451
    .line 452
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 453
    .line 454
    .line 455
    throw v0

    .line 456
    :cond_16
    const/16 v15, 0x20

    .line 457
    .line 458
    invoke-virtual {v8}, LH/m0;->n()LM0/x;

    .line 459
    .line 460
    .line 461
    move-result-object v0

    .line 462
    iget-wide v3, v0, LM0/x;->b:J

    .line 463
    .line 464
    sget v0, LH0/N;->c:I

    .line 465
    .line 466
    shr-long/2addr v3, v15

    .line 467
    goto :goto_f

    .line 468
    :goto_10
    iget-object v3, v8, LH/m0;->d:Lw/S;

    .line 469
    .line 470
    if-eqz v3, :cond_1a

    .line 471
    .line 472
    invoke-virtual {v3}, Lw/S;->d()Lw/p0;

    .line 473
    .line 474
    .line 475
    move-result-object v3

    .line 476
    if-nez v3, :cond_17

    .line 477
    .line 478
    goto :goto_11

    .line 479
    :cond_17
    iget-object v4, v8, LH/m0;->d:Lw/S;

    .line 480
    .line 481
    if-eqz v4, :cond_1a

    .line 482
    .line 483
    iget-object v4, v4, Lw/S;->a:Lw/Z;

    .line 484
    .line 485
    iget-object v4, v4, Lw/Z;->a:LH0/g;

    .line 486
    .line 487
    if-nez v4, :cond_18

    .line 488
    .line 489
    goto :goto_11

    .line 490
    :cond_18
    iget-object v8, v8, LH/m0;->b:LM0/q;

    .line 491
    .line 492
    invoke-interface {v8, v0}, LM0/q;->n(I)I

    .line 493
    .line 494
    .line 495
    move-result v0

    .line 496
    iget-object v4, v4, LH0/g;->e:Ljava/lang/String;

    .line 497
    .line 498
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 499
    .line 500
    .line 501
    move-result v4

    .line 502
    invoke-static {v0, v5, v4}, LT0/l;->m(III)I

    .line 503
    .line 504
    .line 505
    move-result v0

    .line 506
    invoke-virtual {v3, v11, v12}, Lw/p0;->d(J)J

    .line 507
    .line 508
    .line 509
    move-result-wide v4

    .line 510
    shr-long/2addr v4, v15

    .line 511
    long-to-int v4, v4

    .line 512
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 513
    .line 514
    .line 515
    move-result v4

    .line 516
    iget-object v3, v3, Lw/p0;->a:LH0/L;

    .line 517
    .line 518
    iget-object v5, v3, LH0/L;->b:LH0/p;

    .line 519
    .line 520
    invoke-virtual {v5, v0}, LH0/p;->d(I)I

    .line 521
    .line 522
    .line 523
    move-result v0

    .line 524
    invoke-virtual {v3, v0}, LH0/L;->d(I)F

    .line 525
    .line 526
    .line 527
    move-result v8

    .line 528
    invoke-virtual {v3, v0}, LH0/L;->e(I)F

    .line 529
    .line 530
    .line 531
    move-result v3

    .line 532
    invoke-static {v8, v3}, Ljava/lang/Math;->min(FF)F

    .line 533
    .line 534
    .line 535
    move-result v11

    .line 536
    invoke-static {v8, v3}, Ljava/lang/Math;->max(FF)F

    .line 537
    .line 538
    .line 539
    move-result v3

    .line 540
    invoke-static {v4, v11, v3}, LT0/l;->l(FFF)F

    .line 541
    .line 542
    .line 543
    move-result v3

    .line 544
    const-wide/16 v11, 0x0

    .line 545
    .line 546
    invoke-static {v6, v7, v11, v12}, LT0/n;->a(JJ)Z

    .line 547
    .line 548
    .line 549
    move-result v8

    .line 550
    if-nez v8, :cond_19

    .line 551
    .line 552
    sub-float/2addr v4, v3

    .line 553
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 554
    .line 555
    .line 556
    move-result v4

    .line 557
    shr-long/2addr v6, v15

    .line 558
    long-to-int v6, v6

    .line 559
    div-int/2addr v6, v2

    .line 560
    int-to-float v6, v6

    .line 561
    cmpl-float v4, v4, v6

    .line 562
    .line 563
    if-lez v4, :cond_19

    .line 564
    .line 565
    goto :goto_11

    .line 566
    :cond_19
    invoke-virtual {v5, v0}, LH0/p;->f(I)F

    .line 567
    .line 568
    .line 569
    move-result v4

    .line 570
    invoke-virtual {v5, v0}, LH0/p;->b(I)F

    .line 571
    .line 572
    .line 573
    move-result v0

    .line 574
    sub-float/2addr v0, v4

    .line 575
    int-to-float v2, v2

    .line 576
    div-float/2addr v0, v2

    .line 577
    add-float/2addr v0, v4

    .line 578
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 579
    .line 580
    .line 581
    move-result v2

    .line 582
    int-to-long v2, v2

    .line 583
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 584
    .line 585
    .line 586
    move-result v0

    .line 587
    int-to-long v4, v0

    .line 588
    shl-long/2addr v2, v15

    .line 589
    and-long/2addr v4, v13

    .line 590
    or-long v9, v2, v4

    .line 591
    .line 592
    :cond_1a
    :goto_11
    new-instance v0, Lc0/b;

    .line 593
    .line 594
    invoke-direct {v0, v9, v10}, Lc0/b;-><init>(J)V

    .line 595
    .line 596
    .line 597
    return-object v0

    .line 598
    :pswitch_7
    check-cast v8, Landroid/content/Context;

    .line 599
    .line 600
    check-cast v7, Landroid/view/textclassifier/TextClassification;

    .line 601
    .line 602
    invoke-static {v7}, LA0/a;->s(Landroid/view/textclassifier/TextClassification;)Ljava/lang/String;

    .line 603
    .line 604
    .line 605
    move-result-object v0

    .line 606
    if-eqz v0, :cond_1b

    .line 607
    .line 608
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 609
    .line 610
    .line 611
    move-result v5

    .line 612
    :cond_1b
    invoke-static {v7}, LA0/a;->g(Landroid/view/textclassifier/TextClassification;)Landroid/content/Intent;

    .line 613
    .line 614
    .line 615
    move-result-object v0

    .line 616
    const/high16 v2, 0xc000000

    .line 617
    .line 618
    invoke-static {v8, v5, v0, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 619
    .line 620
    .line 621
    move-result-object v2

    .line 622
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 623
    .line 624
    const/16 v3, 0x22

    .line 625
    .line 626
    if-lt v0, v3, :cond_1c

    .line 627
    .line 628
    :try_start_3
    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    .line 629
    .line 630
    .line 631
    move-result-object v0

    .line 632
    invoke-static {v0}, LB/x;->e(Landroid/app/ActivityOptions;)Landroid/app/ActivityOptions;

    .line 633
    .line 634
    .line 635
    move-result-object v0

    .line 636
    invoke-virtual {v0}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    .line 637
    .line 638
    .line 639
    move-result-object v0

    .line 640
    invoke-static {v2, v0}, LB/x;->p(Landroid/app/PendingIntent;Landroid/os/Bundle;)V
    :try_end_3
    .catch Landroid/app/PendingIntent$CanceledException; {:try_start_3 .. :try_end_3} :catch_0

    .line 641
    .line 642
    .line 643
    goto :goto_12

    .line 644
    :catch_0
    move-exception v0

    .line 645
    new-instance v3, Ljava/lang/StringBuilder;

    .line 646
    .line 647
    const-string v4, "error sending pendingIntent: "

    .line 648
    .line 649
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 650
    .line 651
    .line 652
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 653
    .line 654
    .line 655
    const-string v2, " error: "

    .line 656
    .line 657
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 658
    .line 659
    .line 660
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 661
    .line 662
    .line 663
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 664
    .line 665
    .line 666
    move-result-object v0

    .line 667
    const-string v2, "TextClassification"

    .line 668
    .line 669
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 670
    .line 671
    .line 672
    goto :goto_12

    .line 673
    :cond_1c
    invoke-virtual {v2}, Landroid/app/PendingIntent;->send()V

    .line 674
    .line 675
    .line 676
    :goto_12
    return-object v6

    .line 677
    :pswitch_8
    check-cast v8, Lz/b;

    .line 678
    .line 679
    check-cast v7, Lz/g;

    .line 680
    .line 681
    check-cast v8, Lz/d;

    .line 682
    .line 683
    iget-object v0, v8, Lz/d;->d:LU1/c;

    .line 684
    .line 685
    invoke-interface {v0, v7}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 686
    .line 687
    .line 688
    return-object v6

    .line 689
    :pswitch_9
    check-cast v8, LD/e;

    .line 690
    .line 691
    check-cast v7, LU1/a;

    .line 692
    .line 693
    invoke-interface {v7}, LU1/a;->a()Ljava/lang/Object;

    .line 694
    .line 695
    .line 696
    move-result-object v0

    .line 697
    check-cast v0, Lu0/r;

    .line 698
    .line 699
    invoke-interface {v8, v0}, LD/e;->J(Lu0/r;)J

    .line 700
    .line 701
    .line 702
    move-result-wide v2

    .line 703
    invoke-static {v2, v3}, LT0/l;->K(J)J

    .line 704
    .line 705
    .line 706
    move-result-wide v2

    .line 707
    new-instance v0, LT0/k;

    .line 708
    .line 709
    invoke-direct {v0, v2, v3}, LT0/k;-><init>(J)V

    .line 710
    .line 711
    .line 712
    return-object v0

    .line 713
    :pswitch_a
    check-cast v8, LV1/s;

    .line 714
    .line 715
    check-cast v7, LU1/a;

    .line 716
    .line 717
    invoke-interface {v7}, LU1/a;->a()Ljava/lang/Object;

    .line 718
    .line 719
    .line 720
    move-result-object v0

    .line 721
    iput-object v0, v8, LV1/s;->d:Ljava/lang/Object;

    .line 722
    .line 723
    return-object v6

    .line 724
    :pswitch_b
    check-cast v8, Lcom/htcheat/external/A;

    .line 725
    .line 726
    check-cast v7, LA1/d0;

    .line 727
    .line 728
    iget-object v0, v8, Lcom/htcheat/external/A;->C:LU1/c;

    .line 729
    .line 730
    if-eqz v0, :cond_1d

    .line 731
    .line 732
    invoke-interface {v0, v7}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 733
    .line 734
    .line 735
    :cond_1d
    return-object v6

    .line 736
    :pswitch_c
    check-cast v8, Lcom/htcheat/external/A;

    .line 737
    .line 738
    check-cast v7, LI/b0;

    .line 739
    .line 740
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 741
    .line 742
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 743
    .line 744
    .line 745
    const-wide v9, -0x3a513377dbfaL

    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    invoke-static {v9, v10}, LI1/a;->a(J)Ljava/lang/String;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    invoke-virtual {v8, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 755
    .line 756
    .line 757
    move-result-object v0

    .line 758
    instance-of v2, v0, Landroid/content/ClipboardManager;

    .line 759
    .line 760
    if-eqz v2, :cond_1e

    .line 761
    .line 762
    check-cast v0, Landroid/content/ClipboardManager;

    .line 763
    .line 764
    goto :goto_13

    .line 765
    :cond_1e
    move-object v0, v3

    .line 766
    :goto_13
    if-eqz v0, :cond_1f

    .line 767
    .line 768
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    .line 769
    .line 770
    .line 771
    move-result-object v0

    .line 772
    goto :goto_14

    .line 773
    :cond_1f
    move-object v0, v3

    .line 774
    :goto_14
    if-eqz v0, :cond_23

    .line 775
    .line 776
    invoke-virtual {v0}, Landroid/content/ClipData;->getItemCount()I

    .line 777
    .line 778
    .line 779
    move-result v2

    .line 780
    if-nez v2, :cond_20

    .line 781
    .line 782
    goto :goto_15

    .line 783
    :cond_20
    sget-object v2, Lcom/htcheat/external/A;->H:LA1/i;

    .line 784
    .line 785
    invoke-virtual {v0, v5}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    .line 786
    .line 787
    .line 788
    move-result-object v0

    .line 789
    invoke-virtual {v0, v8}, Landroid/content/ClipData$Item;->coerceToText(Landroid/content/Context;)Ljava/lang/CharSequence;

    .line 790
    .line 791
    .line 792
    move-result-object v0

    .line 793
    if-eqz v0, :cond_21

    .line 794
    .line 795
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 796
    .line 797
    .line 798
    move-result-object v3

    .line 799
    :cond_21
    if-nez v3, :cond_22

    .line 800
    .line 801
    const-wide v3, -0x3a773377dbfaL

    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 807
    .line 808
    .line 809
    move-result-object v3

    .line 810
    :cond_22
    invoke-static {v2, v3}, LA1/i;->e(LA1/i;Ljava/lang/String;)Ljava/lang/String;

    .line 811
    .line 812
    .line 813
    move-result-object v0

    .line 814
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 815
    .line 816
    .line 817
    move-result v2

    .line 818
    if-nez v2, :cond_24

    .line 819
    .line 820
    const-wide v2, -0x3a763377dbfaL

    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 826
    .line 827
    .line 828
    move-result-object v2

    .line 829
    invoke-virtual {v8, v2}, Lcom/htcheat/external/A;->o(Ljava/lang/String;)V

    .line 830
    .line 831
    .line 832
    goto :goto_16

    .line 833
    :cond_23
    :goto_15
    const-wide v2, -0x3a5b3377dbfaL

    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 839
    .line 840
    .line 841
    move-result-object v0

    .line 842
    invoke-virtual {v8, v0}, Lcom/htcheat/external/A;->o(Ljava/lang/String;)V

    .line 843
    .line 844
    .line 845
    const-wide v2, -0x3a743377dbfaL

    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 851
    .line 852
    .line 853
    move-result-object v0

    .line 854
    :cond_24
    :goto_16
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 855
    .line 856
    .line 857
    move-result v2

    .line 858
    if-lez v2, :cond_25

    .line 859
    .line 860
    invoke-interface {v7, v0}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 861
    .line 862
    .line 863
    :cond_25
    return-object v6

    .line 864
    nop

    .line 865
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
