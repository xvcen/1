.class public final LA1/c0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final d:Landroid/graphics/Paint;

.field public final e:Landroid/graphics/Paint;

.field public final f:Landroid/graphics/Paint;

.field public g:Z

.field public final synthetic h:Lcom/htcheat/external/B;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/B;Landroid/content/Context;)V
    .locals 2

    .line 1
    iput-object p1, p0, LA1/c0;->h:Lcom/htcheat/external/B;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Landroid/graphics/Paint;

    .line 7
    .line 8
    const/4 p2, 0x1

    .line 9
    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, LA1/c0;->d:Landroid/graphics/Paint;

    .line 13
    .line 14
    new-instance p1, Landroid/graphics/Paint;

    .line 15
    .line 16
    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, LA1/c0;->e:Landroid/graphics/Paint;

    .line 20
    .line 21
    new-instance v0, Landroid/graphics/Paint;

    .line 22
    .line 23
    invoke-direct {v0, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, LA1/c0;->f:Landroid/graphics/Paint;

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-virtual {p0, p2, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 30
    .line 31
    .line 32
    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 33
    .line 34
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 35
    .line 36
    .line 37
    const/4 p1, -0x1

    .line 38
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 39
    .line 40
    .line 41
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 44
    .line 45
    .line 46
    sget-object p1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 47
    .line 48
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 49
    .line 50
    .line 51
    const/4 p1, 0x0

    .line 52
    invoke-virtual {p0, p1}, LA1/c0;->a(Z)V

    .line 53
    .line 54
    .line 55
    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LA1/c0;->g:Z

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 10

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    int-to-float v0, v0

    .line 17
    const v1, 0x3ed70a3d    # 0.42f

    .line 18
    .line 19
    .line 20
    mul-float/2addr v0, v1

    .line 21
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    int-to-float v1, v1

    .line 26
    const/high16 v2, 0x3f000000    # 0.5f

    .line 27
    .line 28
    mul-float/2addr v1, v2

    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    int-to-float v3, v3

    .line 34
    mul-float/2addr v3, v2

    .line 35
    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 36
    .line 37
    iget-object v5, p0, LA1/c0;->d:Landroid/graphics/Paint;

    .line 38
    .line 39
    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 40
    .line 41
    .line 42
    iget-boolean v4, p0, LA1/c0;->g:Z

    .line 43
    .line 44
    const v6, -0x23c8c8c9

    .line 45
    .line 46
    .line 47
    const/high16 v7, -0x14420000

    .line 48
    .line 49
    if-eqz v4, :cond_0

    .line 50
    .line 51
    move v4, v7

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move v4, v6

    .line 54
    :goto_0
    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 55
    .line 56
    .line 57
    iget-boolean v4, p0, LA1/c0;->g:Z

    .line 58
    .line 59
    if-eqz v4, :cond_1

    .line 60
    .line 61
    const v4, -0xa5a6

    .line 62
    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_1
    const v4, -0x3c3c3d

    .line 66
    .line 67
    .line 68
    :goto_1
    iget-object v8, p0, LA1/c0;->e:Landroid/graphics/Paint;

    .line 69
    .line 70
    invoke-virtual {v8, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 71
    .line 72
    .line 73
    sget v4, Lcom/htcheat/external/B;->C:I

    .line 74
    .line 75
    iget-object v4, p0, LA1/c0;->h:Lcom/htcheat/external/B;

    .line 76
    .line 77
    const v9, 0x3fa66666    # 1.3f

    .line 78
    .line 79
    .line 80
    invoke-virtual {v4, v9}, Lcom/htcheat/external/B;->f(F)I

    .line 81
    .line 82
    .line 83
    move-result v9

    .line 84
    int-to-float v9, v9

    .line 85
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 86
    .line 87
    .line 88
    const/high16 v9, 0x3fc00000    # 1.5f

    .line 89
    .line 90
    invoke-virtual {v4, v9}, Lcom/htcheat/external/B;->f(F)I

    .line 91
    .line 92
    .line 93
    move-result v9

    .line 94
    int-to-float v9, v9

    .line 95
    add-float/2addr v9, v0

    .line 96
    invoke-virtual {p1, v1, v3, v9, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 97
    .line 98
    .line 99
    iget-boolean v9, p0, LA1/c0;->g:Z

    .line 100
    .line 101
    if-eqz v9, :cond_2

    .line 102
    .line 103
    move v6, v7

    .line 104
    :cond_2
    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {p1, v1, v3, v0, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p1, v1, v3, v0, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 111
    .line 112
    .line 113
    const/high16 v0, 0x41600000    # 14.0f

    .line 114
    .line 115
    invoke-virtual {v4, v0}, Lcom/htcheat/external/B;->f(F)I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    int-to-float v0, v0

    .line 120
    iget-object v4, p0, LA1/c0;->f:Landroid/graphics/Paint;

    .line 121
    .line 122
    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v4}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    const-wide v5, -0x37993377dbfaL

    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v5

    .line 138
    iget v6, v0, Landroid/graphics/Paint$FontMetrics;->ascent:F

    .line 139
    .line 140
    iget v0, v0, Landroid/graphics/Paint$FontMetrics;->descent:F

    .line 141
    .line 142
    add-float/2addr v6, v0

    .line 143
    mul-float/2addr v6, v2

    .line 144
    sub-float/2addr v3, v6

    .line 145
    invoke-virtual {p1, v5, v1, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 146
    .line 147
    .line 148
    return-void
.end method
