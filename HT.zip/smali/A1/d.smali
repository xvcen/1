.class public final synthetic LA1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/d;->d:I

    iput-object p2, p0, LA1/d;->f:Ljava/lang/Object;

    iput-object p3, p0, LA1/d;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, LA1/d;->d:I

    .line 2
    .line 3
    iget-object v1, p0, LA1/d;->e:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, LA1/d;->f:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v2, Lcom/htcheat/external/A;

    .line 11
    .line 12
    check-cast v1, Lb/k;

    .line 13
    .line 14
    iget-object v0, v2, LZ0/a;->d:Landroidx/lifecycle/w;

    .line 15
    .line 16
    new-instance v3, Lb/a;

    .line 17
    .line 18
    invoke-direct {v3, v1, v2}, Lb/a;-><init>(Lb/k;Lb/h;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, v3}, Landroidx/lifecycle/w;->a(Landroidx/lifecycle/t;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_0
    check-cast v2, LY/e;

    .line 26
    .line 27
    check-cast v1, Landroid/util/LongSparseArray;

    .line 28
    .line 29
    invoke-static {v2, v1}, LT0/g;->q(LY/e;Landroid/util/LongSparseArray;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_1
    check-cast v2, Lcom/htcheat/external/m;

    .line 34
    .line 35
    check-cast v1, Landroid/widget/LinearLayout;

    .line 36
    .line 37
    iget-object v0, v2, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v2, v0}, Lcom/htcheat/external/m;->f(Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    if-eq v1, v0, :cond_0

    .line 44
    .line 45
    const/16 v0, 0x8

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 48
    .line 49
    .line 50
    :cond_0
    const/high16 v0, 0x3f800000    # 1.0f

    .line 51
    .line 52
    invoke-virtual {v1, v0}, Landroid/view/View;->setAlpha(F)V

    .line 53
    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-virtual {v1, v0}, Landroid/view/View;->setTranslationX(F)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :pswitch_2
    check-cast v2, Lcom/htcheat/external/B;

    .line 61
    .line 62
    check-cast v1, Ljava/lang/String;

    .line 63
    .line 64
    sget v0, Lcom/htcheat/external/B;->C:I

    .line 65
    .line 66
    invoke-virtual {v2}, Lcom/htcheat/external/B;->d()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_1

    .line 71
    .line 72
    const-wide v0, -0x298f3377dbfaL

    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_1
    iget-object v0, v2, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 82
    .line 83
    const/16 v3, 0x1f

    .line 84
    .line 85
    invoke-virtual {v0, v3}, Lcom/htcheat/external/i;->c(I)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    const-wide v3, -0x29b43377dbfaL

    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-nez v0, :cond_2

    .line 103
    .line 104
    const-wide v0, -0x29b63377dbfaL

    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    const/4 v0, 0x0

    .line 113
    iput-boolean v0, v2, Lcom/htcheat/external/B;->o:Z

    .line 114
    .line 115
    iget-object v0, v2, Lcom/htcheat/external/B;->r:Landroid/os/Handler;

    .line 116
    .line 117
    new-instance v1, LA1/V;

    .line 118
    .line 119
    const/4 v3, 0x2

    .line 120
    invoke-direct {v1, v2, v3}, LA1/V;-><init>(Lcom/htcheat/external/B;I)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 124
    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_2
    iget-object v0, v2, Lcom/htcheat/external/B;->u:Lcom/htcheat/external/i;

    .line 128
    .line 129
    const/16 v2, 0x29

    .line 130
    .line 131
    invoke-virtual {v0, v2, v1}, Lcom/htcheat/external/i;->i(ILjava/lang/String;)Z

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    if-nez v0, :cond_3

    .line 136
    .line 137
    const-wide v0, -0x29d23377dbfaL

    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    :cond_3
    :goto_0
    return-void

    .line 146
    :pswitch_3
    check-cast v2, Lcom/htcheat/external/A;

    .line 147
    .line 148
    check-cast v1, Ljava/lang/String;

    .line 149
    .line 150
    iget-object v0, v2, Lcom/htcheat/external/A;->A:LU1/c;

    .line 151
    .line 152
    if-eqz v0, :cond_4

    .line 153
    .line 154
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    :cond_4
    return-void

    .line 158
    nop

    .line 159
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
