.class public final synthetic LA1/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LA1/e;->d:I

    iput-object p3, p0, LA1/e;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LA1/e;->d:I

    iput-object p2, p0, LA1/e;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 37

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    iget v3, v1, LA1/e;->d:I

    const/16 v8, 0x8

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x3

    const/4 v15, 0x0

    const-wide/16 v16, 0x80

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v3, :pswitch_data_0

    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, Lw/a0;

    check-cast v0, Lq0/u;

    move-object v0, v2

    check-cast v0, Lc0/b;

    .line 1
    iget-wide v4, v0, Lc0/b;->a:J

    .line 2
    invoke-interface {v3, v4, v5}, Lw/a0;->e(J)V

    .line 3
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_0
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LH/m0;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-static {v4}, LI/k;->x(I)I

    move-result v2

    invoke-static {v3, v0, v2}, Lw/O;->g(LH/m0;LI/r;I)V

    .line 5
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_1
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LW/q;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-static {v4}, LI/k;->x(I)I

    move-result v2

    invoke-static {v3, v0, v2}, Ls/j;->a(LW/q;LI/r;I)V

    .line 7
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_2
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, Lp/K0;

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    check-cast v2, Ljava/lang/Float;

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    .line 8
    invoke-virtual {v3}, LW/p;->I0()Lc2/s;

    move-result-object v4

    new-instance v5, Lp/I0;

    invoke-direct {v5, v3, v0, v2, v15}, Lp/I0;-><init>(Lp/K0;FFLN1/c;)V

    invoke-static {v4, v15, v5, v14}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 9
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object v0

    :pswitch_3
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, Lg2/t;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v6

    move-object v0, v2

    check-cast v0, LN1/f;

    .line 10
    invoke-interface {v0}, LN1/f;->getKey()LN1/g;

    move-result-object v2

    .line 11
    iget-object v3, v3, Lg2/t;->h:LN1/h;

    invoke-interface {v3, v2}, LN1/h;->r(LN1/g;)LN1/f;

    move-result-object v3

    .line 12
    sget-object v4, Lc2/p;->e:Lc2/p;

    if-eq v2, v4, :cond_1

    if-eq v0, v3, :cond_0

    const/high16 v6, -0x80000000

    goto :goto_3

    :cond_0
    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    .line 13
    :cond_1
    check-cast v3, Lc2/Q;

    .line 14
    check-cast v0, Lc2/Q;

    :goto_0
    if-nez v0, :cond_2

    goto :goto_2

    :cond_2
    if-ne v0, v3, :cond_3

    goto :goto_1

    .line 15
    :cond_3
    instance-of v2, v0, Lh2/q;

    if-nez v2, :cond_5

    :goto_1
    move-object v15, v0

    :goto_2
    if-ne v15, v3, :cond_4

    if-nez v3, :cond_0

    .line 16
    :goto_3
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 17
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 18
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 19
    const-string v4, ", expected child of "

    .line 20
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    const-string v3, ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use \'channelFlow\' builder instead of \'flow\'"

    .line 22
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 23
    :cond_5
    check-cast v0, Lh2/q;

    .line 24
    sget-object v2, Lc2/X;->e:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 25
    invoke-virtual {v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc2/j;

    if-eqz v0, :cond_6

    .line 26
    invoke-interface {v0}, Lc2/j;->getParent()Lc2/Q;

    move-result-object v0

    goto :goto_0

    :cond_6
    move-object v0, v15

    goto :goto_0

    .line 27
    :pswitch_4
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, [C

    check-cast v0, Ljava/lang/CharSequence;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    .line 28
    const-string v6, "$this$DelimitedRangesSequence"

    invoke-static {v0, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-static {v0, v3, v2, v5}, Lb2/i;->V(Ljava/lang/CharSequence;[CIZ)I

    move-result v0

    if-gez v0, :cond_7

    goto :goto_4

    :cond_7
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 30
    new-instance v15, LJ1/g;

    invoke-direct {v15, v0, v2}, LJ1/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_4
    return-object v15

    .line 31
    :pswitch_5
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LU/w;

    check-cast v0, Ljava/util/Set;

    check-cast v2, LU/g;

    .line 32
    iget-object v2, v3, LU/w;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 33
    :goto_5
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_8

    .line 34
    move-object v7, v0

    check-cast v7, Ljava/util/Collection;

    goto :goto_6

    .line 35
    :cond_8
    instance-of v7, v6, Ljava/util/Set;

    if-eqz v7, :cond_9

    new-array v7, v13, [Ljava/util/Set;

    aput-object v6, v7, v5

    aput-object v0, v7, v4

    invoke-static {v7}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    goto :goto_6

    .line 36
    :cond_9
    instance-of v7, v6, Ljava/util/List;

    if-eqz v7, :cond_d

    move-object v7, v6

    check-cast v7, Ljava/util/Collection;

    invoke-static {v0}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-static {v7, v8}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object v7

    .line 37
    :cond_a
    :goto_6
    invoke-virtual {v2, v6, v7}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_c

    .line 38
    invoke-virtual {v3}, LU/w;->b()Z

    move-result v0

    if-eqz v0, :cond_b

    .line 39
    iget-object v0, v3, LU/w;->a:LU1/c;

    new-instance v2, LA1/P;

    const/16 v4, 0xc

    invoke-direct {v2, v4, v3}, LA1/P;-><init>(ILjava/lang/Object;)V

    invoke-interface {v0, v2}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    :cond_b
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    .line 41
    :cond_c
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v8

    if-eq v8, v6, :cond_a

    goto :goto_5

    .line 42
    :cond_d
    const-string v0, "Unexpected notification"

    invoke-static {v0}, LI/t;->b(Ljava/lang/String;)Ljava/lang/Void;

    new-instance v0, LC0/e;

    .line 43
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 44
    throw v0

    .line 45
    :pswitch_6
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LH0/A;

    check-cast v0, LT/b;

    .line 46
    invoke-virtual {v3, v0, v2}, LH0/A;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    .line 47
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v3

    :goto_7
    if-ge v5, v3, :cond_10

    .line 48
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_f

    .line 49
    iget-object v6, v0, LT/b;->e:LT/c;

    if-eqz v6, :cond_f

    .line 50
    invoke-interface {v6, v4}, LT/c;->a(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_e

    goto :goto_8

    .line 51
    :cond_e
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "item at index "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " can\'t be saved: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_f
    :goto_8
    add-int/lit8 v5, v5, 0x1

    goto :goto_7

    .line 52
    :cond_10
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_11

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    :cond_11
    return-object v15

    .line 53
    :pswitch_7
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LU1/c;

    check-cast v2, LJ1/m;

    .line 54
    invoke-interface {v3, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_8
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, Le2/c;

    check-cast v0, Ljava/util/Set;

    check-cast v2, LU/g;

    .line 56
    instance-of v2, v0, LK/h;

    if-eqz v2, :cond_16

    .line 57
    move-object v2, v0

    check-cast v2, LK/h;

    .line 58
    iget-object v2, v2, LK/h;->d:Li/F;

    .line 59
    iget-object v4, v2, Li/F;->b:[Ljava/lang/Object;

    .line 60
    iget-object v2, v2, Li/F;->a:[J

    .line 61
    array-length v14, v2

    sub-int/2addr v14, v13

    if-ltz v14, :cond_1a

    move v13, v5

    const-wide/16 v18, 0xff

    .line 62
    :goto_9
    aget-wide v6, v2, v13

    const-wide v20, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    not-long v9, v6

    shl-long/2addr v9, v12

    and-long/2addr v9, v6

    and-long v9, v9, v20

    cmp-long v9, v9, v20

    if-eqz v9, :cond_15

    sub-int v9, v13, v14

    not-int v9, v9

    ushr-int/lit8 v9, v9, 0x1f

    rsub-int/lit8 v9, v9, 0x8

    move v10, v5

    :goto_a
    if-ge v10, v9, :cond_14

    and-long v22, v6, v18

    cmp-long v15, v22, v16

    if-gez v15, :cond_12

    shl-int/lit8 v15, v13, 0x3

    add-int/2addr v15, v10

    .line 63
    aget-object v15, v4, v15

    move/from16 v22, v12

    .line 64
    instance-of v12, v15, LU/z;

    if-eqz v12, :cond_19

    check-cast v15, LU/z;

    invoke-virtual {v15, v11}, LU/z;->e(I)Z

    move-result v12

    if-eqz v12, :cond_13

    goto :goto_c

    :cond_12
    move/from16 v22, v12

    :cond_13
    shr-long/2addr v6, v8

    add-int/lit8 v10, v10, 0x1

    move/from16 v12, v22

    goto :goto_a

    :cond_14
    move/from16 v22, v12

    if-ne v9, v8, :cond_1a

    goto :goto_b

    :cond_15
    move/from16 v22, v12

    :goto_b
    if-eq v13, v14, :cond_1a

    add-int/lit8 v13, v13, 0x1

    move/from16 v12, v22

    goto :goto_9

    .line 65
    :cond_16
    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .line 66
    instance-of v4, v2, Ljava/util/Collection;

    if-eqz v4, :cond_17

    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_17

    goto :goto_d

    .line 67
    :cond_17
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_18
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 68
    instance-of v5, v4, LU/z;

    if-eqz v5, :cond_19

    check-cast v4, LU/z;

    invoke-virtual {v4, v11}, LU/z;->e(I)Z

    move-result v4

    if-eqz v4, :cond_18

    .line 69
    :cond_19
    :goto_c
    invoke-interface {v3, v0}, Le2/r;->q(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    :cond_1a
    :goto_d
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_9
    move/from16 v22, v12

    const-wide/16 v18, 0xff

    const-wide v20, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LI/E0;

    check-cast v0, Ljava/util/Set;

    check-cast v2, LU/g;

    .line 71
    iget-object v2, v3, LI/E0;->c:Ljava/lang/Object;

    .line 72
    monitor-enter v2

    .line 73
    :try_start_0
    iget-object v6, v3, LI/E0;->u:Lf2/G;

    .line 74
    invoke-virtual {v6}, Lf2/G;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, LI/y0;

    sget-object v7, LI/y0;->h:LI/y0;

    invoke-virtual {v6, v7}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v6

    if-ltz v6, :cond_22

    .line 75
    iget-object v6, v3, LI/E0;->h:Li/F;

    .line 76
    instance-of v7, v0, LK/h;

    if-eqz v7, :cond_1f

    .line 77
    check-cast v0, LK/h;

    .line 78
    iget-object v0, v0, LK/h;->d:Li/F;

    .line 79
    iget-object v7, v0, Li/F;->b:[Ljava/lang/Object;

    .line 80
    iget-object v0, v0, Li/F;->a:[J

    .line 81
    array-length v9, v0

    sub-int/2addr v9, v13

    if-ltz v9, :cond_21

    move v10, v5

    .line 82
    :goto_e
    aget-wide v11, v0, v10

    not-long v13, v11

    shl-long v13, v13, v22

    and-long/2addr v13, v11

    and-long v13, v13, v20

    cmp-long v13, v13, v20

    if-eqz v13, :cond_1e

    sub-int v13, v10, v9

    not-int v13, v13

    ushr-int/lit8 v13, v13, 0x1f

    rsub-int/lit8 v13, v13, 0x8

    move v14, v5

    :goto_f
    if-ge v14, v13, :cond_1d

    and-long v23, v11, v18

    cmp-long v15, v23, v16

    if-gez v15, :cond_1c

    shl-int/lit8 v15, v10, 0x3

    add-int/2addr v15, v14

    .line 83
    aget-object v15, v7, v15

    .line 84
    instance-of v5, v15, LU/z;

    if-eqz v5, :cond_1b

    .line 85
    move-object v5, v15

    check-cast v5, LU/z;

    invoke-virtual {v5, v4}, LU/z;->e(I)Z

    move-result v5

    if-nez v5, :cond_1b

    goto :goto_10

    :catchall_0
    move-exception v0

    goto :goto_12

    .line 86
    :cond_1b
    invoke-virtual {v6, v15}, Li/F;->a(Ljava/lang/Object;)Z

    :cond_1c
    :goto_10
    shr-long/2addr v11, v8

    add-int/lit8 v14, v14, 0x1

    const/4 v5, 0x0

    goto :goto_f

    :cond_1d
    if-ne v13, v8, :cond_21

    :cond_1e
    if-eq v10, v9, :cond_21

    add-int/lit8 v10, v10, 0x1

    const/4 v5, 0x0

    goto :goto_e

    .line 87
    :cond_1f
    check-cast v0, Ljava/lang/Iterable;

    .line 88
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_21

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .line 89
    instance-of v7, v5, LU/z;

    if-eqz v7, :cond_20

    .line 90
    move-object v7, v5

    check-cast v7, LU/z;

    invoke-virtual {v7, v4}, LU/z;->e(I)Z

    move-result v7

    if-nez v7, :cond_20

    goto :goto_11

    .line 91
    :cond_20
    invoke-virtual {v6, v5}, Li/F;->a(Ljava/lang/Object;)Z

    goto :goto_11

    .line 92
    :cond_21
    invoke-virtual {v3}, LI/E0;->x()Lc2/f;

    move-result-object v15
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 93
    :cond_22
    monitor-exit v2

    if-eqz v15, :cond_23

    .line 94
    sget-object v0, LJ1/m;->a:LJ1/m;

    check-cast v15, Lc2/g;

    invoke-virtual {v15, v0}, Lc2/g;->v(Ljava/lang/Object;)V

    .line 95
    :cond_23
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    .line 96
    :goto_12
    monitor-exit v2

    throw v0

    .line 97
    :pswitch_a
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LQ/m;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    instance-of v0, v2, Lw0/E;

    if-eqz v0, :cond_25

    .line 99
    move-object v0, v2

    check-cast v0, Lw0/E;

    .line 100
    iget-object v4, v3, LQ/m;->i:Ljava/lang/Object;

    check-cast v4, Li/F;

    if-nez v4, :cond_24

    .line 101
    sget v4, Li/L;->a:I

    .line 102
    new-instance v4, Li/F;

    invoke-direct {v4}, Li/F;-><init>()V

    .line 103
    iput-object v4, v3, LQ/m;->i:Ljava/lang/Object;

    .line 104
    :cond_24
    invoke-virtual {v4, v0}, Li/F;->j(Ljava/lang/Object;)V

    .line 105
    iget-object v4, v3, LQ/m;->d:LK/e;

    invoke-virtual {v4, v0}, LK/e;->b(Ljava/lang/Object;)V

    .line 106
    :cond_25
    instance-of v0, v2, LI/H0;

    if-eqz v0, :cond_26

    .line 107
    move-object v0, v2

    check-cast v0, LI/H0;

    invoke-virtual {v3, v0}, LQ/m;->g(LI/H0;)V

    .line 108
    :cond_26
    instance-of v0, v2, LI/w0;

    if-eqz v0, :cond_27

    .line 109
    move-object v0, v2

    check-cast v0, LI/w0;

    invoke-virtual {v0}, LI/w0;->d()V

    .line 110
    :cond_27
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_b
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LH/z;

    check-cast v0, Landroid/graphics/RectF;

    check-cast v2, Landroid/graphics/RectF;

    .line 111
    invoke-static {v0}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    move-result-object v0

    .line 112
    invoke-static {v2}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    move-result-object v2

    .line 113
    iget v3, v3, LH/z;->d:I

    packed-switch v3, :pswitch_data_1

    .line 114
    invoke-virtual {v0}, Lc0/c;->b()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lc0/c;->a(J)Z

    move-result v0

    goto :goto_13

    .line 115
    :pswitch_c
    invoke-virtual {v0, v2}, Lc0/c;->g(Lc0/c;)Z

    move-result v0

    .line 116
    :goto_13
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :pswitch_d
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LV1/r;

    check-cast v0, Lq0/u;

    check-cast v2, Lc0/b;

    .line 117
    invoke-virtual {v0}, Lq0/u;->a()V

    .line 118
    iget-wide v4, v2, Lc0/b;->a:J

    .line 119
    iput-wide v4, v3, LV1/r;->d:J

    .line 120
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_e
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LB1/G;

    check-cast v0, Lq0/u;

    check-cast v2, Lc0/b;

    const-wide v4, -0x34623377dbfaL

    .line 121
    invoke-static {v4, v5}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    iget-object v2, v3, LB1/G;->a:Lc2/s;

    .line 123
    new-instance v4, LB1/F;

    invoke-direct {v4, v3, v0, v15}, LB1/F;-><init>(LB1/G;Lq0/u;LN1/c;)V

    invoke-static {v2, v15, v4, v14}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 124
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_f
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, Landroid/app/RemoteAction;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v2, -0x520d2714

    .line 125
    invoke-virtual {v0, v2}, LI/r;->U(I)V

    .line 126
    invoke-static {v3}, LA0/a;->p(Landroid/app/RemoteAction;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    .line 127
    invoke-virtual {v0, v3}, LI/r;->p(Z)V

    return-object v2

    :pswitch_10
    move v3, v5

    .line 128
    iget-object v4, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v4, Landroid/view/textclassifier/TextClassification;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v2, 0x38a0c7d5

    .line 129
    invoke-virtual {v0, v2}, LI/r;->U(I)V

    .line 130
    invoke-static {v4}, LA0/a;->q(Landroid/view/textclassifier/TextClassification;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 131
    invoke-virtual {v0, v3}, LI/r;->p(Z)V

    return-object v2

    :pswitch_11
    move v3, v5

    .line 132
    iget-object v4, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v4, Lz/b;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    const v2, 0x27b3a34e

    .line 133
    invoke-virtual {v0, v2}, LI/r;->U(I)V

    .line 134
    check-cast v4, Lz/d;

    .line 135
    iget-object v2, v4, Lz/d;->b:Ljava/lang/String;

    .line 136
    invoke-virtual {v0, v3}, LI/r;->p(Z)V

    return-object v2

    :pswitch_12
    move/from16 v22, v12

    .line 137
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LD1/d;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    invoke-static/range {v22 .. v22}, LI/k;->x(I)I

    move-result v2

    invoke-static {v3, v0, v2}, LX1/a;->d(LD1/d;LI/r;I)V

    .line 139
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_13
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    check-cast v3, LB1/t;

    check-cast v0, Lf0/d;

    check-cast v2, LU1/c;

    .line 140
    const-string v4, "$this$rememberBackdrop"

    invoke-static {v0, v4}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "drawBackdrop"

    invoke-static {v2, v4}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 141
    invoke-virtual {v3}, LB1/t;->a()F

    move-result v3

    const v4, 0x3f2aaaab

    const/high16 v5, 0x3f400000    # 0.75f

    .line 142
    invoke-static {v4, v5, v3}, LT0/g;->C(FFF)F

    move-result v4

    const/4 v6, 0x0

    .line 143
    invoke-static {v6, v5, v3}, LT0/g;->C(FFF)F

    move-result v3

    .line 144
    invoke-interface {v0}, Lf0/d;->d0()J

    move-result-wide v5

    .line 145
    invoke-interface {v0}, Lf0/d;->Q()LI/e0;

    move-result-object v7

    .line 146
    invoke-virtual {v7}, LI/e0;->t()J

    move-result-wide v8

    .line 147
    invoke-virtual {v7}, LI/e0;->m()Ld0/u;

    move-result-object v10

    invoke-interface {v10}, Ld0/u;->k()V

    .line 148
    :try_start_1
    iget-object v10, v7, LI/e0;->d:Ljava/lang/Object;

    check-cast v10, LA0/h;

    .line 149
    invoke-virtual {v10, v4, v3, v5, v6}, LA0/h;->r(FFJ)V

    .line 150
    invoke-interface {v2, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 151
    invoke-virtual {v7}, LI/e0;->m()Ld0/u;

    move-result-object v0

    invoke-interface {v0}, Ld0/u;->i()V

    .line 152
    invoke-virtual {v7, v8, v9}, LI/e0;->E(J)V

    .line 153
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :catchall_1
    move-exception v0

    .line 154
    invoke-virtual {v7}, LI/e0;->m()Ld0/u;

    move-result-object v2

    invoke-interface {v2}, Ld0/u;->i()V

    .line 155
    invoke-virtual {v7, v8, v9}, LI/e0;->E(J)V

    throw v0

    .line 156
    :pswitch_14
    iget-object v3, v1, LA1/e;->e:Ljava/lang/Object;

    move-object v7, v3

    check-cast v7, Lcom/htcheat/external/A;

    check-cast v0, LI/r;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    sget-object v3, Lcom/htcheat/external/A;->H:LA1/i;

    const-wide v5, -0x3c913377dbfaL

    .line 157
    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    and-int/lit8 v3, v2, 0x3

    if-eq v3, v13, :cond_28

    move v3, v4

    goto :goto_14

    :cond_28
    const/4 v3, 0x0

    :goto_14
    and-int/2addr v2, v4

    invoke-virtual {v0, v2, v3}, LI/r;->N(IZ)Z

    move-result v2

    if-eqz v2, :cond_44

    .line 158
    iget-object v2, v7, Lcom/htcheat/external/A;->w:Landroid/content/SharedPreferences;

    if-eqz v2, :cond_43

    const-wide v5, -0x3dc53377dbfaL

    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_2b

    .line 159
    sget-object v2, Lcom/htcheat/external/A;->H:LA1/i;

    iget-object v3, v7, Lcom/htcheat/external/A;->w:Landroid/content/SharedPreferences;

    if-eqz v3, :cond_2a

    const-wide v8, -0x3dca3377dbfaL

    invoke-static {v8, v9}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v5

    const-wide v8, -0x3dd23377dbfaL

    invoke-static {v8, v9}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v3, v5, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_29

    const-wide v8, -0x3ddd3377dbfaL

    invoke-static {v8, v9}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v3

    :cond_29
    invoke-static {v2, v3}, LA1/i;->e(LA1/i;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_15
    move-object v8, v2

    goto :goto_16

    :cond_2a
    const-wide v2, -0x3dcc3377dbfaL

    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LV1/i;->k(Ljava/lang/String;)V

    throw v15

    :cond_2b
    const-wide v2, -0x3ddc3377dbfaL

    .line 160
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v2

    goto :goto_15

    :goto_16
    const-wide v2, -0x3ddf3377dbfaL

    .line 161
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 162
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v2

    .line 163
    sget-object v3, LI/m;->a:LI/h;

    if-ne v2, v3, :cond_2c

    .line 164
    invoke-static {v15}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v2

    .line 165
    invoke-virtual {v0, v2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 166
    :cond_2c
    move-object v9, v2

    check-cast v9, LI/b0;

    const-wide v15, -0x3df63377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    .line 167
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v3, :cond_2d

    .line 168
    invoke-static {v8}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v2

    .line 169
    invoke-virtual {v0, v2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 170
    :cond_2d
    check-cast v2, LI/b0;

    const-wide v15, -0x3d093377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    .line 171
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v3, :cond_2e

    .line 172
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-static {v5}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v5

    .line 173
    invoke-virtual {v0, v5}, LI/r;->d0(Ljava/lang/Object;)V

    .line 174
    :cond_2e
    move-object v12, v5

    check-cast v12, LI/b0;

    const-wide v15, -0x3d203377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    .line 175
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v3, :cond_30

    .line 176
    iget-boolean v5, v7, Lcom/htcheat/external/A;->G:Z

    if-eqz v5, :cond_2f

    const v5, 0x7f080021

    invoke-virtual {v7, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    goto :goto_17

    :cond_2f
    const-wide v15, -0x3d3b3377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v5

    :goto_17
    invoke-static {v5}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v5

    .line 177
    invoke-virtual {v0, v5}, LI/r;->d0(Ljava/lang/Object;)V

    .line 178
    :cond_30
    check-cast v5, LI/b0;

    const-wide v15, -0x3d513377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    .line 179
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v3, :cond_31

    .line 180
    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {v10}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v10

    .line 181
    invoke-virtual {v0, v10}, LI/r;->d0(Ljava/lang/Object;)V

    .line 182
    :cond_31
    move-object v15, v10

    check-cast v15, LI/b0;

    const-wide v16, -0x3d683377dbfaL

    .line 183
    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    .line 184
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v3, :cond_32

    .line 185
    new-instance v10, LA1/a;

    invoke-direct {v10, v5, v14}, LA1/a;-><init>(LI/b0;I)V

    .line 186
    invoke-virtual {v0, v10}, LI/r;->d0(Ljava/lang/Object;)V

    .line 187
    :cond_32
    check-cast v10, LU1/c;

    iput-object v10, v7, Lcom/htcheat/external/A;->A:LU1/c;

    const-wide v16, -0x3e833377dbfaL

    .line 188
    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    .line 189
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v3, :cond_33

    .line 190
    new-instance v5, LA1/a;

    invoke-direct {v5, v15, v11}, LA1/a;-><init>(LI/b0;I)V

    .line 191
    invoke-virtual {v0, v5}, LI/r;->d0(Ljava/lang/Object;)V

    .line 192
    :cond_33
    check-cast v5, LU1/c;

    iput-object v5, v7, Lcom/htcheat/external/A;->B:LU1/c;

    const-wide v10, -0x3e9a3377dbfaL

    .line 193
    invoke-static {v10, v11}, LI1/a;->a(J)Ljava/lang/String;

    .line 194
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v3, :cond_34

    .line 195
    new-instance v5, LA1/a;

    const/4 v10, 0x0

    invoke-direct {v5, v9, v10}, LA1/a;-><init>(LI/b0;I)V

    .line 196
    invoke-virtual {v0, v5}, LI/r;->d0(Ljava/lang/Object;)V

    .line 197
    :cond_34
    check-cast v5, LU1/c;

    iput-object v5, v7, Lcom/htcheat/external/A;->C:LU1/c;

    .line 198
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    const-wide v16, -0x3ebd3377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    invoke-virtual {v0, v6}, LI/r;->f(Z)Z

    move-result v5

    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v10

    or-int/2addr v5, v10

    invoke-virtual {v0, v8}, LI/r;->e(Ljava/lang/Object;)Z

    move-result v10

    or-int/2addr v5, v10

    .line 199
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v10

    if-nez v5, :cond_35

    if-ne v10, v3, :cond_36

    .line 200
    :cond_35
    new-instance v5, LA1/l;

    const/4 v10, 0x0

    invoke-direct/range {v5 .. v10}, LA1/l;-><init>(ZLcom/htcheat/external/A;Ljava/lang/String;LI/b0;LN1/c;)V

    .line 201
    invoke-virtual {v0, v5}, LI/r;->d0(Ljava/lang/Object;)V

    move-object v10, v5

    .line 202
    :cond_36
    check-cast v10, LU1/e;

    invoke-static {v0, v10, v11}, LI/k;->d(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 203
    invoke-interface {v9}, LI/a1;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LA1/d0;

    .line 204
    invoke-interface {v2}, LI/a1;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 205
    invoke-interface {v12}, LI/a1;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Boolean;

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    .line 206
    invoke-interface {v15}, LI/a1;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Boolean;

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    const-wide v14, -0x3ed43377dbfaL

    .line 207
    invoke-static {v14, v15}, LI1/a;->a(J)Ljava/lang/String;

    .line 208
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v11

    if-ne v11, v3, :cond_37

    .line 209
    new-instance v11, LA1/a;

    invoke-direct {v11, v2, v4}, LA1/a;-><init>(LI/b0;I)V

    .line 210
    invoke-virtual {v0, v11}, LI/r;->d0(Ljava/lang/Object;)V

    .line 211
    :cond_37
    check-cast v11, LU1/c;

    const-wide v14, -0x3eef3377dbfaL

    invoke-static {v14, v15}, LI1/a;->a(J)Ljava/lang/String;

    .line 212
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v3, :cond_38

    .line 213
    new-instance v14, LA1/a;

    invoke-direct {v14, v12, v13}, LA1/a;-><init>(LI/b0;I)V

    .line 214
    invoke-virtual {v0, v14}, LI/r;->d0(Ljava/lang/Object;)V

    .line 215
    :cond_38
    check-cast v14, LU1/c;

    const-wide v15, -0x3e063377dbfaL

    invoke-static/range {v15 .. v16}, LI1/a;->a(J)Ljava/lang/String;

    .line 216
    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v13

    .line 217
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v15

    if-nez v13, :cond_39

    if-ne v15, v3, :cond_3a

    .line 218
    :cond_39
    new-instance v15, LA1/b;

    const/4 v13, 0x0

    invoke-direct {v15, v7, v2, v12, v13}, LA1/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 219
    invoke-virtual {v0, v15}, LI/r;->d0(Ljava/lang/Object;)V

    .line 220
    :cond_3a
    check-cast v15, LU1/a;

    const-wide v12, -0x3e193377dbfaL

    invoke-static {v12, v13}, LI1/a;->a(J)Ljava/lang/String;

    .line 221
    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v12

    .line 222
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v13

    if-nez v12, :cond_3b

    if-ne v13, v3, :cond_3c

    .line 223
    :cond_3b
    new-instance v13, LA1/c;

    const/4 v12, 0x0

    invoke-direct {v13, v12, v7, v2}, LA1/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 224
    invoke-virtual {v0, v13}, LI/r;->d0(Ljava/lang/Object;)V

    .line 225
    :cond_3c
    check-cast v13, LU1/a;

    const-wide v16, -0x3e303377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    .line 226
    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v2

    .line 227
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v2, :cond_3d

    if-ne v12, v3, :cond_3e

    .line 228
    :cond_3d
    new-instance v24, LA1/m;

    .line 229
    const-class v27, Lcom/htcheat/external/A;

    const-wide v16, -0x38ff3377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v28

    const-wide v16, -0x38003377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v29

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v25, 0x0

    const/16 v30, 0x0

    move-object/from16 v26, v7

    .line 230
    invoke-direct/range {v24 .. v32}, LA1/m;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    move-object/from16 v12, v24

    .line 231
    invoke-virtual {v0, v12}, LI/r;->d0(Ljava/lang/Object;)V

    .line 232
    :cond_3e
    check-cast v12, LV1/g;

    move-object/from16 v32, v12

    check-cast v32, LU1/a;

    const-wide v16, -0x3e4b3377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    .line 233
    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v2

    .line 234
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v2, :cond_3f

    if-ne v12, v3, :cond_40

    .line 235
    :cond_3f
    new-instance v12, Lcom/htcheat/external/a;

    const/4 v2, 0x0

    invoke-direct {v12, v7, v9, v2}, Lcom/htcheat/external/a;-><init>(Lcom/htcheat/external/A;LI/b0;I)V

    .line 236
    invoke-virtual {v0, v12}, LI/r;->d0(Ljava/lang/Object;)V

    .line 237
    :cond_40
    move-object/from16 v33, v12

    check-cast v33, LU1/a;

    const-wide v16, -0x3e623377dbfaL

    invoke-static/range {v16 .. v17}, LI1/a;->a(J)Ljava/lang/String;

    .line 238
    invoke-virtual {v0, v7}, LI/r;->g(Ljava/lang/Object;)Z

    move-result v2

    .line 239
    invoke-virtual {v0}, LI/r;->K()Ljava/lang/Object;

    move-result-object v12

    if-nez v2, :cond_41

    if-ne v12, v3, :cond_42

    .line 240
    :cond_41
    new-instance v12, Lcom/htcheat/external/a;

    invoke-direct {v12, v7, v9, v4}, Lcom/htcheat/external/a;-><init>(Lcom/htcheat/external/A;LI/b0;I)V

    .line 241
    invoke-virtual {v0, v12}, LI/r;->d0(Ljava/lang/Object;)V

    .line 242
    :cond_42
    move-object/from16 v34, v12

    check-cast v34, LU1/a;

    const v36, 0x36000

    move-object/from16 v35, v0

    move-object/from16 v24, v5

    move-object/from16 v25, v6

    move/from16 v26, v8

    move/from16 v27, v10

    move-object/from16 v28, v11

    move-object/from16 v31, v13

    move-object/from16 v29, v14

    move-object/from16 v30, v15

    .line 243
    invoke-static/range {v24 .. v36}, LX1/a;->i(LA1/d0;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;LU1/a;LU1/a;LI/r;I)V

    goto :goto_18

    :cond_43
    const-wide v2, -0x3dbf3377dbfaL

    .line 244
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LV1/i;->k(Ljava/lang/String;)V

    throw v15

    :cond_44
    move-object/from16 v35, v0

    .line 245
    invoke-virtual/range {v35 .. v35}, LI/r;->Q()V

    .line 246
    :goto_18
    sget-object v0, LJ1/m;->a:LJ1/m;

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x4
        :pswitch_c
    .end packed-switch
.end method
