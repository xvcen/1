.class public final synthetic LA1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/htcheat/external/A;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/A;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/f;->d:I

    iput-object p1, p0, LA1/f;->e:Lcom/htcheat/external/A;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget v0, p0, LA1/f;->d:I

    .line 2
    .line 3
    iget-object v1, p0, LA1/f;->e:Lcom/htcheat/external/A;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    invoke-static {v1}, Lb/h;->b(Lcom/htcheat/external/A;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 13
    .line 14
    :try_start_0
    iget-object v0, v1, Lcom/htcheat/external/A;->v:Lcom/htcheat/external/j;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/htcheat/external/j;->g()V

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const-wide v0, -0x3fa93377dbfaL

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, LV1/i;->k(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    :catchall_0
    :goto_0
    return-void

    .line 37
    :pswitch_1
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    invoke-virtual {v1, v0}, Lcom/htcheat/external/A;->k(Z)Z

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, v0}, Lcom/htcheat/external/A;->l(Z)V

    .line 44
    .line 45
    .line 46
    const-wide v2, -0x3f853377dbfaL

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v1, v0}, Lcom/htcheat/external/A;->m(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1}, Lcom/htcheat/external/A;->e()V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v1}, Lcom/htcheat/external/A;->n()V

    .line 62
    .line 63
    .line 64
    const-wide v2, -0x3f933377dbfaL

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v1, v0}, Lcom/htcheat/external/A;->o(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
