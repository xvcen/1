.class public final synthetic LA1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/g;->d:I

    iput-object p2, p0, LA1/g;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LA1/g;->d:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lx0/x;

    .line 15
    .line 16
    const-string v2, "measureAndLayout"

    .line 17
    .line 18
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :try_start_0
    iget-object v2, v0, Lx0/x;->g:Lx0/s;

    .line 22
    .line 23
    invoke-virtual {v2, v4}, Lx0/s;->u(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 24
    .line 25
    .line 26
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 27
    .line 28
    .line 29
    const-string v2, "checkForSemanticsChanges"

    .line 30
    .line 31
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :try_start_1
    invoke-virtual {v0}, Lx0/x;->f()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 35
    .line 36
    .line 37
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 38
    .line 39
    .line 40
    iput-boolean v5, v0, Lx0/x;->M:Z

    .line 41
    .line 42
    return-void

    .line 43
    :catchall_0
    move-exception v0

    .line 44
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 45
    .line 46
    .line 47
    throw v0

    .line 48
    :catchall_1
    move-exception v0

    .line 49
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 50
    .line 51
    .line 52
    throw v0

    .line 53
    :pswitch_0
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, Lx0/s;

    .line 56
    .line 57
    iput-boolean v5, v0, Lx0/s;->D0:Z

    .line 58
    .line 59
    iget-object v2, v0, Lx0/s;->v0:Landroid/view/MotionEvent;

    .line 60
    .line 61
    invoke-static {v2}, LV1/i;->b(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    const/16 v4, 0xa

    .line 69
    .line 70
    if-ne v3, v4, :cond_0

    .line 71
    .line 72
    invoke-virtual {v0, v2}, Lx0/s;->G(Landroid/view/MotionEvent;)I

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :cond_0
    const-string v0, "The ACTION_HOVER_EXIT event was not cleared."

    .line 77
    .line 78
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 79
    .line 80
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    throw v2

    .line 84
    :pswitch_1
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 85
    .line 86
    move-object v2, v0

    .line 87
    check-cast v2, Ll1/r;

    .line 88
    .line 89
    const-string v0, "fetchFonts result is not OK. ("

    .line 90
    .line 91
    iget-object v4, v2, Ll1/r;->g:Ljava/lang/Object;

    .line 92
    .line 93
    monitor-enter v4

    .line 94
    :try_start_2
    iget-object v5, v2, Ll1/r;->k:LT0/l;

    .line 95
    .line 96
    if-nez v5, :cond_1

    .line 97
    .line 98
    monitor-exit v4

    .line 99
    goto/16 :goto_6

    .line 100
    .line 101
    :catchall_2
    move-exception v0

    .line 102
    goto/16 :goto_8

    .line 103
    .line 104
    :cond_1
    monitor-exit v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 105
    :try_start_3
    invoke-virtual {v2}, Ll1/r;->b()Le1/d;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    iget v5, v4, Le1/d;->e:I

    .line 110
    .line 111
    if-ne v5, v3, :cond_2

    .line 112
    .line 113
    iget-object v3, v2, Ll1/r;->g:Ljava/lang/Object;

    .line 114
    .line 115
    monitor-enter v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    .line 116
    :try_start_4
    monitor-exit v3

    .line 117
    goto :goto_0

    .line 118
    :catchall_3
    move-exception v0

    .line 119
    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 120
    :try_start_5
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 121
    :catchall_4
    move-exception v0

    .line 122
    goto/16 :goto_4

    .line 123
    .line 124
    :cond_2
    :goto_0
    if-nez v5, :cond_5

    .line 125
    .line 126
    :try_start_6
    const-string v0, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    .line 127
    .line 128
    sget v3, Ld1/a;->a:I

    .line 129
    .line 130
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    iget-object v0, v2, Ll1/r;->f:LA1/i;

    .line 134
    .line 135
    iget-object v3, v2, Ll1/r;->d:Landroid/content/Context;

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    filled-new-array {v4}, [Le1/d;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    sget-object v5, Lb1/d;->a:LT0/l;

    .line 145
    .line 146
    const-string v5, "TypefaceCompat.createFromFontInfo"

    .line 147
    .line 148
    invoke-static {v5}, LT0/l;->e(Ljava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_7

    .line 149
    .line 150
    .line 151
    :try_start_7
    sget-object v5, Lb1/d;->a:LT0/l;

    .line 152
    .line 153
    invoke-virtual {v5, v3, v0}, LT0/l;->p(Landroid/content/Context;[Le1/d;)Landroid/graphics/Typeface;

    .line 154
    .line 155
    .line 156
    move-result-object v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_8

    .line 157
    :try_start_8
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 158
    .line 159
    .line 160
    iget-object v3, v2, Ll1/r;->d:Landroid/content/Context;

    .line 161
    .line 162
    iget-object v4, v4, Le1/d;->a:Landroid/net/Uri;

    .line 163
    .line 164
    invoke-static {v3, v4}, LT0/g;->D(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 165
    .line 166
    .line 167
    move-result-object v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_7

    .line 168
    if-eqz v3, :cond_4

    .line 169
    .line 170
    if-eqz v0, :cond_4

    .line 171
    .line 172
    :try_start_9
    const-string v4, "EmojiCompat.MetadataRepo.create"

    .line 173
    .line 174
    invoke-static {v4}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    new-instance v4, LX/a;

    .line 178
    .line 179
    invoke-static {v3}, LT0/l;->J(Ljava/nio/MappedByteBuffer;)Lm1/b;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    invoke-direct {v4, v0, v3}, LX/a;-><init>(Landroid/graphics/Typeface;Lm1/b;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    .line 184
    .line 185
    .line 186
    :try_start_a
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    .line 187
    .line 188
    .line 189
    :try_start_b
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 190
    .line 191
    .line 192
    iget-object v3, v2, Ll1/r;->g:Ljava/lang/Object;

    .line 193
    .line 194
    monitor-enter v3
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 195
    :try_start_c
    iget-object v0, v2, Ll1/r;->k:LT0/l;

    .line 196
    .line 197
    if-eqz v0, :cond_3

    .line 198
    .line 199
    invoke-virtual {v0, v4}, LT0/l;->E(LX/a;)V

    .line 200
    .line 201
    .line 202
    goto :goto_1

    .line 203
    :catchall_5
    move-exception v0

    .line 204
    goto :goto_2

    .line 205
    :cond_3
    :goto_1
    monitor-exit v3
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    .line 206
    :try_start_d
    invoke-virtual {v2}, Ll1/r;->a()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 207
    .line 208
    .line 209
    goto :goto_6

    .line 210
    :goto_2
    :try_start_e
    monitor-exit v3
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    .line 211
    :try_start_f
    throw v0
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    .line 212
    :catchall_6
    move-exception v0

    .line 213
    :try_start_10
    sget v3, Ld1/a;->a:I

    .line 214
    .line 215
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 216
    .line 217
    .line 218
    throw v0

    .line 219
    :cond_4
    new-instance v0, Ljava/lang/RuntimeException;

    .line 220
    .line 221
    const-string v3, "Unable to open file."

    .line 222
    .line 223
    invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    throw v0

    .line 227
    :catchall_7
    move-exception v0

    .line 228
    goto :goto_3

    .line 229
    :catchall_8
    move-exception v0

    .line 230
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 231
    .line 232
    .line 233
    throw v0
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_7

    .line 234
    :goto_3
    :try_start_11
    sget v3, Ld1/a;->a:I

    .line 235
    .line 236
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 237
    .line 238
    .line 239
    throw v0

    .line 240
    :cond_5
    new-instance v3, Ljava/lang/RuntimeException;

    .line 241
    .line 242
    new-instance v4, Ljava/lang/StringBuilder;

    .line 243
    .line 244
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    const-string v0, ")"

    .line 251
    .line 252
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 253
    .line 254
    .line 255
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    invoke-direct {v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    throw v3
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    .line 263
    :goto_4
    iget-object v3, v2, Ll1/r;->g:Ljava/lang/Object;

    .line 264
    .line 265
    monitor-enter v3

    .line 266
    :try_start_12
    iget-object v4, v2, Ll1/r;->k:LT0/l;

    .line 267
    .line 268
    if-eqz v4, :cond_6

    .line 269
    .line 270
    invoke-virtual {v4, v0}, LT0/l;->D(Ljava/lang/Throwable;)V

    .line 271
    .line 272
    .line 273
    goto :goto_5

    .line 274
    :catchall_9
    move-exception v0

    .line 275
    goto :goto_7

    .line 276
    :cond_6
    :goto_5
    monitor-exit v3
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_9

    .line 277
    invoke-virtual {v2}, Ll1/r;->a()V

    .line 278
    .line 279
    .line 280
    :goto_6
    return-void

    .line 281
    :goto_7
    :try_start_13
    monitor-exit v3
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_9

    .line 282
    throw v0

    .line 283
    :goto_8
    :try_start_14
    monitor-exit v4
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_2

    .line 284
    throw v0

    .line 285
    :pswitch_2
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 286
    .line 287
    check-cast v0, Landroid/view/View;

    .line 288
    .line 289
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 290
    .line 291
    .line 292
    move-result-object v2

    .line 293
    const-string v3, "input_method"

    .line 294
    .line 295
    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object v2

    .line 299
    check-cast v2, Landroid/view/inputmethod/InputMethodManager;

    .line 300
    .line 301
    invoke-virtual {v2, v0, v5}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :pswitch_3
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast v0, Lb/f;

    .line 308
    .line 309
    iget-object v3, v0, Lb/f;->e:Ljava/lang/Runnable;

    .line 310
    .line 311
    if-eqz v3, :cond_7

    .line 312
    .line 313
    invoke-interface {v3}, Ljava/lang/Runnable;->run()V

    .line 314
    .line 315
    .line 316
    iput-object v2, v0, Lb/f;->e:Ljava/lang/Runnable;

    .line 317
    .line 318
    :cond_7
    return-void

    .line 319
    :pswitch_4
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast v0, Landroidx/lifecycle/B;

    .line 322
    .line 323
    iget-object v2, v0, Landroidx/lifecycle/B;->i:Landroidx/lifecycle/w;

    .line 324
    .line 325
    iget v3, v0, Landroidx/lifecycle/B;->e:I

    .line 326
    .line 327
    if-nez v3, :cond_8

    .line 328
    .line 329
    iput-boolean v4, v0, Landroidx/lifecycle/B;->f:Z

    .line 330
    .line 331
    sget-object v3, Landroidx/lifecycle/o;->ON_PAUSE:Landroidx/lifecycle/o;

    .line 332
    .line 333
    invoke-virtual {v2, v3}, Landroidx/lifecycle/w;->d(Landroidx/lifecycle/o;)V

    .line 334
    .line 335
    .line 336
    :cond_8
    iget v3, v0, Landroidx/lifecycle/B;->d:I

    .line 337
    .line 338
    if-nez v3, :cond_9

    .line 339
    .line 340
    iget-boolean v3, v0, Landroidx/lifecycle/B;->f:Z

    .line 341
    .line 342
    if-eqz v3, :cond_9

    .line 343
    .line 344
    sget-object v3, Landroidx/lifecycle/o;->ON_STOP:Landroidx/lifecycle/o;

    .line 345
    .line 346
    invoke-virtual {v2, v3}, Landroidx/lifecycle/w;->d(Landroidx/lifecycle/o;)V

    .line 347
    .line 348
    .line 349
    iput-boolean v4, v0, Landroidx/lifecycle/B;->g:Z

    .line 350
    .line 351
    :cond_9
    return-void

    .line 352
    :pswitch_5
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 353
    .line 354
    check-cast v0, LY/e;

    .line 355
    .line 356
    invoke-virtual {v0}, LY/e;->h()Z

    .line 357
    .line 358
    .line 359
    move-result v2

    .line 360
    iget-object v6, v0, LY/e;->d:Lx0/s;

    .line 361
    .line 362
    if-nez v2, :cond_a

    .line 363
    .line 364
    goto/16 :goto_d

    .line 365
    .line 366
    :cond_a
    const-string v2, "ContentCapture:changeChecker"

    .line 367
    .line 368
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    :try_start_15
    invoke-virtual {v6, v4}, Lx0/s;->u(Z)V

    .line 372
    .line 373
    .line 374
    iget-object v2, v0, LY/e;->o:Li/x;

    .line 375
    .line 376
    iget-object v4, v2, Li/l;->b:[I

    .line 377
    .line 378
    iget-object v2, v2, Li/l;->a:[J

    .line 379
    .line 380
    array-length v7, v2

    .line 381
    sub-int/2addr v7, v3

    .line 382
    if-ltz v7, :cond_e

    .line 383
    .line 384
    move v3, v5

    .line 385
    :goto_9
    aget-wide v8, v2, v3

    .line 386
    .line 387
    not-long v10, v8

    .line 388
    const/4 v12, 0x7

    .line 389
    shl-long/2addr v10, v12

    .line 390
    and-long/2addr v10, v8

    .line 391
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    and-long/2addr v10, v12

    .line 397
    cmp-long v10, v10, v12

    .line 398
    .line 399
    if-eqz v10, :cond_d

    .line 400
    .line 401
    sub-int v10, v3, v7

    .line 402
    .line 403
    not-int v10, v10

    .line 404
    ushr-int/lit8 v10, v10, 0x1f

    .line 405
    .line 406
    const/16 v11, 0x8

    .line 407
    .line 408
    rsub-int/lit8 v10, v10, 0x8

    .line 409
    .line 410
    move v12, v5

    .line 411
    :goto_a
    if-ge v12, v10, :cond_c

    .line 412
    .line 413
    const-wide/16 v13, 0xff

    .line 414
    .line 415
    and-long/2addr v13, v8

    .line 416
    const-wide/16 v15, 0x80

    .line 417
    .line 418
    cmp-long v13, v13, v15

    .line 419
    .line 420
    if-gez v13, :cond_b

    .line 421
    .line 422
    shl-int/lit8 v13, v3, 0x3

    .line 423
    .line 424
    add-int/2addr v13, v12

    .line 425
    aget v15, v4, v13

    .line 426
    .line 427
    invoke-virtual {v0}, LY/e;->g()Li/l;

    .line 428
    .line 429
    .line 430
    move-result-object v13

    .line 431
    invoke-virtual {v13, v15}, Li/l;->a(I)Z

    .line 432
    .line 433
    .line 434
    move-result v13

    .line 435
    if-nez v13, :cond_b

    .line 436
    .line 437
    iget-object v13, v0, LY/e;->g:Ljava/util/ArrayList;

    .line 438
    .line 439
    new-instance v14, LY/f;

    .line 440
    .line 441
    move-object/from16 v20, v6

    .line 442
    .line 443
    iget-wide v5, v0, LY/e;->n:J

    .line 444
    .line 445
    sget-object v18, LY/g;->e:LY/g;

    .line 446
    .line 447
    const/16 v19, 0x0

    .line 448
    .line 449
    move-wide/from16 v16, v5

    .line 450
    .line 451
    invoke-direct/range {v14 .. v19}, LY/f;-><init>(IJLY/g;LA0/h;)V

    .line 452
    .line 453
    .line 454
    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 455
    .line 456
    .line 457
    iget-object v5, v0, LY/e;->k:Le2/c;

    .line 458
    .line 459
    sget-object v6, LJ1/m;->a:LJ1/m;

    .line 460
    .line 461
    invoke-interface {v5, v6}, Le2/r;->q(Ljava/lang/Object;)Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    goto :goto_b

    .line 465
    :cond_b
    move-object/from16 v20, v6

    .line 466
    .line 467
    :goto_b
    shr-long/2addr v8, v11

    .line 468
    add-int/lit8 v12, v12, 0x1

    .line 469
    .line 470
    move-object/from16 v6, v20

    .line 471
    .line 472
    const/4 v5, 0x0

    .line 473
    goto :goto_a

    .line 474
    :cond_c
    move-object/from16 v20, v6

    .line 475
    .line 476
    if-ne v10, v11, :cond_f

    .line 477
    .line 478
    goto :goto_c

    .line 479
    :cond_d
    move-object/from16 v20, v6

    .line 480
    .line 481
    :goto_c
    if-eq v3, v7, :cond_f

    .line 482
    .line 483
    add-int/lit8 v3, v3, 0x1

    .line 484
    .line 485
    move-object/from16 v6, v20

    .line 486
    .line 487
    const/4 v5, 0x0

    .line 488
    goto :goto_9

    .line 489
    :cond_e
    move-object/from16 v20, v6

    .line 490
    .line 491
    :cond_f
    const-string v2, "ContentCapture:sendAppearEvents"

    .line 492
    .line 493
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_a

    .line 494
    .line 495
    .line 496
    :try_start_16
    invoke-virtual/range {v20 .. v20}, Lx0/s;->getSemanticsOwner()LE0/p;

    .line 497
    .line 498
    .line 499
    move-result-object v2

    .line 500
    invoke-virtual {v2}, LE0/p;->a()LE0/n;

    .line 501
    .line 502
    .line 503
    move-result-object v2

    .line 504
    iget-object v3, v0, LY/e;->p:Lx0/E0;

    .line 505
    .line 506
    invoke-virtual {v0, v2, v3}, LY/e;->j(LE0/n;Lx0/E0;)V
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_b

    .line 507
    .line 508
    .line 509
    :try_start_17
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 510
    .line 511
    .line 512
    invoke-virtual {v0}, LY/e;->g()Li/l;

    .line 513
    .line 514
    .line 515
    move-result-object v2

    .line 516
    invoke-virtual {v0, v2}, LY/e;->f(Li/l;)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v0}, LY/e;->n()V

    .line 520
    .line 521
    .line 522
    const/4 v5, 0x0

    .line 523
    iput-boolean v5, v0, LY/e;->q:Z
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_a

    .line 524
    .line 525
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 526
    .line 527
    .line 528
    :goto_d
    return-void

    .line 529
    :catchall_a
    move-exception v0

    .line 530
    goto :goto_e

    .line 531
    :catchall_b
    move-exception v0

    .line 532
    :try_start_18
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 533
    .line 534
    .line 535
    throw v0
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_a

    .line 536
    :goto_e
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 537
    .line 538
    .line 539
    throw v0

    .line 540
    :pswitch_6
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 541
    .line 542
    check-cast v0, LM0/A;

    .line 543
    .line 544
    iget-object v6, v0, LM0/A;->b:LI/e0;

    .line 545
    .line 546
    iput-object v2, v0, LM0/A;->n:LA1/g;

    .line 547
    .line 548
    iget-object v7, v0, LM0/A;->m:LK/e;

    .line 549
    .line 550
    iget-object v0, v0, LM0/A;->a:Landroid/view/View;

    .line 551
    .line 552
    invoke-virtual {v0}, Landroid/view/View;->isFocused()Z

    .line 553
    .line 554
    .line 555
    move-result v8

    .line 556
    if-nez v8, :cond_10

    .line 557
    .line 558
    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 559
    .line 560
    .line 561
    move-result-object v0

    .line 562
    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 563
    .line 564
    .line 565
    move-result-object v0

    .line 566
    if-eqz v0, :cond_10

    .line 567
    .line 568
    invoke-virtual {v0}, Landroid/view/View;->onCheckIsTextEditor()Z

    .line 569
    .line 570
    .line 571
    move-result v0

    .line 572
    if-ne v0, v4, :cond_10

    .line 573
    .line 574
    invoke-virtual {v7}, LK/e;->g()V

    .line 575
    .line 576
    .line 577
    goto/16 :goto_15

    .line 578
    .line 579
    :cond_10
    iget-object v0, v7, LK/e;->d:[Ljava/lang/Object;

    .line 580
    .line 581
    iget v8, v7, LK/e;->f:I

    .line 582
    .line 583
    move-object v9, v2

    .line 584
    move v10, v5

    .line 585
    :goto_f
    if-ge v10, v8, :cond_17

    .line 586
    .line 587
    aget-object v11, v0, v10

    .line 588
    .line 589
    check-cast v11, LM0/z;

    .line 590
    .line 591
    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    .line 592
    .line 593
    .line 594
    move-result v12

    .line 595
    if-eqz v12, :cond_15

    .line 596
    .line 597
    if-eq v12, v4, :cond_14

    .line 598
    .line 599
    if-eq v12, v3, :cond_12

    .line 600
    .line 601
    const/4 v13, 0x3

    .line 602
    if-ne v12, v13, :cond_11

    .line 603
    .line 604
    goto :goto_10

    .line 605
    :cond_11
    new-instance v0, LC0/e;

    .line 606
    .line 607
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 608
    .line 609
    .line 610
    throw v0

    .line 611
    :cond_12
    :goto_10
    sget-object v12, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 612
    .line 613
    invoke-static {v2, v12}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 614
    .line 615
    .line 616
    move-result v12

    .line 617
    if-nez v12, :cond_16

    .line 618
    .line 619
    sget-object v9, LM0/z;->f:LM0/z;

    .line 620
    .line 621
    if-ne v11, v9, :cond_13

    .line 622
    .line 623
    move v9, v4

    .line 624
    goto :goto_11

    .line 625
    :cond_13
    move v9, v5

    .line 626
    :goto_11
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 627
    .line 628
    .line 629
    move-result-object v9

    .line 630
    goto :goto_13

    .line 631
    :cond_14
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 632
    .line 633
    :goto_12
    move-object v9, v2

    .line 634
    goto :goto_13

    .line 635
    :cond_15
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 636
    .line 637
    goto :goto_12

    .line 638
    :cond_16
    :goto_13
    add-int/lit8 v10, v10, 0x1

    .line 639
    .line 640
    goto :goto_f

    .line 641
    :cond_17
    invoke-virtual {v7}, LK/e;->g()V

    .line 642
    .line 643
    .line 644
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 645
    .line 646
    invoke-static {v2, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 647
    .line 648
    .line 649
    move-result v0

    .line 650
    if-eqz v0, :cond_18

    .line 651
    .line 652
    iget-object v0, v6, LI/e0;->e:Ljava/lang/Object;

    .line 653
    .line 654
    invoke-interface {v0}, LJ1/d;->getValue()Ljava/lang/Object;

    .line 655
    .line 656
    .line 657
    move-result-object v0

    .line 658
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 659
    .line 660
    iget-object v3, v6, LI/e0;->d:Ljava/lang/Object;

    .line 661
    .line 662
    check-cast v3, Landroid/view/View;

    .line 663
    .line 664
    invoke-virtual {v0, v3}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    .line 665
    .line 666
    .line 667
    :cond_18
    if-eqz v9, :cond_1a

    .line 668
    .line 669
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 670
    .line 671
    .line 672
    move-result v0

    .line 673
    if-eqz v0, :cond_19

    .line 674
    .line 675
    iget-object v0, v6, LI/e0;->f:Ljava/lang/Object;

    .line 676
    .line 677
    check-cast v0, LA0/h;

    .line 678
    .line 679
    iget-object v0, v0, LA0/h;->e:Ljava/lang/Object;

    .line 680
    .line 681
    check-cast v0, LA0/h;

    .line 682
    .line 683
    invoke-virtual {v0}, LA0/h;->s()V

    .line 684
    .line 685
    .line 686
    goto :goto_14

    .line 687
    :cond_19
    iget-object v0, v6, LI/e0;->f:Ljava/lang/Object;

    .line 688
    .line 689
    check-cast v0, LA0/h;

    .line 690
    .line 691
    iget-object v0, v0, LA0/h;->e:Ljava/lang/Object;

    .line 692
    .line 693
    check-cast v0, LA0/h;

    .line 694
    .line 695
    invoke-virtual {v0}, LA0/h;->m()V

    .line 696
    .line 697
    .line 698
    :cond_1a
    :goto_14
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 699
    .line 700
    invoke-static {v2, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 701
    .line 702
    .line 703
    move-result v0

    .line 704
    if-eqz v0, :cond_1b

    .line 705
    .line 706
    iget-object v0, v6, LI/e0;->e:Ljava/lang/Object;

    .line 707
    .line 708
    invoke-interface {v0}, LJ1/d;->getValue()Ljava/lang/Object;

    .line 709
    .line 710
    .line 711
    move-result-object v0

    .line 712
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 713
    .line 714
    iget-object v2, v6, LI/e0;->d:Ljava/lang/Object;

    .line 715
    .line 716
    check-cast v2, Landroid/view/View;

    .line 717
    .line 718
    invoke-virtual {v0, v2}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    .line 719
    .line 720
    .line 721
    :cond_1b
    :goto_15
    return-void

    .line 722
    :pswitch_7
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 723
    .line 724
    check-cast v0, LB/i;

    .line 725
    .line 726
    iget-object v0, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 727
    .line 728
    if-eqz v0, :cond_1c

    .line 729
    .line 730
    invoke-virtual {v0}, Landroid/view/ActionMode;->finish()V

    .line 731
    .line 732
    .line 733
    :cond_1c
    return-void

    .line 734
    :pswitch_8
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 735
    .line 736
    check-cast v0, LA1/n0;

    .line 737
    .line 738
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    const/high16 v2, 0x3f800000    # 1.0f

    .line 743
    .line 744
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    .line 745
    .line 746
    .line 747
    move-result-object v0

    .line 748
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    .line 749
    .line 750
    .line 751
    move-result-object v0

    .line 752
    const-wide/16 v2, 0x8c

    .line 753
    .line 754
    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 755
    .line 756
    .line 757
    move-result-object v0

    .line 758
    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    .line 759
    .line 760
    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 761
    .line 762
    .line 763
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 764
    .line 765
    .line 766
    move-result-object v0

    .line 767
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 768
    .line 769
    .line 770
    return-void

    .line 771
    :pswitch_9
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 772
    .line 773
    check-cast v0, Lcom/htcheat/external/i;

    .line 774
    .line 775
    invoke-virtual {v0}, Lcom/htcheat/external/i;->b()V

    .line 776
    .line 777
    .line 778
    return-void

    .line 779
    :pswitch_a
    iget-object v0, v1, LA1/g;->e:Ljava/lang/Object;

    .line 780
    .line 781
    check-cast v0, LA1/c;

    .line 782
    .line 783
    sget-object v2, Lcom/htcheat/external/A;->H:LA1/i;

    .line 784
    .line 785
    invoke-virtual {v0}, LA1/c;->a()Ljava/lang/Object;

    .line 786
    .line 787
    .line 788
    return-void

    .line 789
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
