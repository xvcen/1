.class public final synthetic LA1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Z)V
    .locals 0

    .line 1
    iput p1, p0, LA1/h;->d:I

    iput-object p2, p0, LA1/h;->f:Ljava/lang/Object;

    iput-boolean p3, p0, LA1/h;->e:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, LA1/h;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/h;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LA1/Y;

    .line 9
    .line 10
    iget-object v0, v0, LA1/Y;->e:Lcom/htcheat/external/B;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 13
    .line 14
    iget-boolean v2, p0, LA1/h;->e:Z

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    move v4, v3

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/16 v4, 0x8

    .line 24
    .line 25
    :goto_0
    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 26
    .line 27
    .line 28
    :cond_1
    if-nez v2, :cond_2

    .line 29
    .line 30
    iget-object v0, v0, Lcom/htcheat/external/B;->f:LA1/c0;

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-virtual {v0, v3}, LA1/c0;->a(Z)V

    .line 35
    .line 36
    .line 37
    :cond_2
    return-void

    .line 38
    :pswitch_0
    iget-object v0, p0, LA1/h;->f:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v0, Lcom/htcheat/external/A;

    .line 41
    .line 42
    iget-object v0, v0, Lcom/htcheat/external/A;->B:LU1/c;

    .line 43
    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    iget-boolean v1, p0, LA1/h;->e:Z

    .line 47
    .line 48
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    :cond_3
    return-void

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
