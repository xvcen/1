.class public final synthetic LA1/h0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:LA1/W;


# direct methods
.method public synthetic constructor <init>(LA1/W;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/h0;->a:LA1/W;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, LA1/h0;->a:LA1/W;

    .line 2
    .line 3
    iget-object p1, p1, LA1/W;->a:Lcom/htcheat/external/B;

    .line 4
    .line 5
    iget-object v0, p1, Lcom/htcheat/external/B;->t:Landroid/os/Handler;

    .line 6
    .line 7
    new-instance v1, LA1/V;

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    invoke-direct {v1, p1, v2}, LA1/V;-><init>(Lcom/htcheat/external/B;I)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 14
    .line 15
    .line 16
    return-void
.end method
