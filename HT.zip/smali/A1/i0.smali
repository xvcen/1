.class public final synthetic LA1/i0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/htcheat/external/m;

.field public final synthetic b:Landroid/widget/TextView;

.field public final synthetic c:[LA1/e0;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/m;Landroid/widget/TextView;[LA1/e0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/i0;->a:Lcom/htcheat/external/m;

    iput-object p2, p0, LA1/i0;->b:Landroid/widget/TextView;

    iput-object p3, p0, LA1/i0;->c:[LA1/e0;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Landroid/widget/LinearLayout;

    .line 4
    .line 5
    iget-object v2, v0, LA1/i0;->a:Lcom/htcheat/external/m;

    .line 6
    .line 7
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    invoke-direct {v1, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 16
    .line 17
    .line 18
    const/high16 v4, 0x41400000    # 12.0f

    .line 19
    .line 20
    invoke-virtual {v2, v4}, Lcom/htcheat/external/m;->d(F)I

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    invoke-virtual {v2, v4}, Lcom/htcheat/external/m;->d(F)I

    .line 25
    .line 26
    .line 27
    move-result v6

    .line 28
    invoke-virtual {v2, v4}, Lcom/htcheat/external/m;->d(F)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    const/high16 v7, 0x41200000    # 10.0f

    .line 33
    .line 34
    invoke-virtual {v2, v7}, Lcom/htcheat/external/m;->d(F)I

    .line 35
    .line 36
    .line 37
    move-result v8

    .line 38
    invoke-virtual {v1, v5, v6, v4, v8}, Landroid/view/View;->setPadding(IIII)V

    .line 39
    .line 40
    .line 41
    const/high16 v4, 0x41000000    # 8.0f

    .line 42
    .line 43
    invoke-virtual {v2, v4}, Lcom/htcheat/external/m;->d(F)I

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    const v6, 0x55ffffff    # 3.518437E13f

    .line 48
    .line 49
    .line 50
    const v8, -0xeee8de

    .line 51
    .line 52
    .line 53
    invoke-virtual {v2, v8, v5, v6}, Lcom/htcheat/external/m;->g(III)Landroid/graphics/drawable/GradientDrawable;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    invoke-virtual {v1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 58
    .line 59
    .line 60
    new-instance v5, Landroid/widget/LinearLayout;

    .line 61
    .line 62
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    invoke-direct {v5, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 67
    .line 68
    .line 69
    const/4 v6, 0x0

    .line 70
    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 71
    .line 72
    .line 73
    const-wide v8, -0x25b43377dbfaL

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-static {v8, v9}, LI1/a;->a(J)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v8

    .line 82
    const v9, -0xcbc6bb

    .line 83
    .line 84
    .line 85
    invoke-virtual {v2, v9, v8}, Lcom/htcheat/external/m;->a(ILjava/lang/String;)Landroid/widget/TextView;

    .line 86
    .line 87
    .line 88
    move-result-object v8

    .line 89
    const-wide v10, -0x25b03377dbfaL

    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    invoke-static {v10, v11}, LI1/a;->a(J)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v10

    .line 98
    invoke-virtual {v2, v9, v10}, Lcom/htcheat/external/m;->a(ILjava/lang/String;)Landroid/widget/TextView;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    new-instance v10, LA1/l0;

    .line 103
    .line 104
    const/4 v11, 0x0

    .line 105
    iget-object v12, v0, LA1/i0;->c:[LA1/e0;

    .line 106
    .line 107
    invoke-direct {v10, v2, v12, v11}, LA1/l0;-><init>(Lcom/htcheat/external/m;[LA1/e0;I)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v8, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 111
    .line 112
    .line 113
    new-instance v10, LA1/l0;

    .line 114
    .line 115
    const/4 v11, 0x1

    .line 116
    invoke-direct {v10, v2, v12, v11}, LA1/l0;-><init>(Lcom/htcheat/external/m;[LA1/e0;I)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v9, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 120
    .line 121
    .line 122
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 123
    .line 124
    const/high16 v11, 0x42080000    # 34.0f

    .line 125
    .line 126
    invoke-virtual {v2, v11}, Lcom/htcheat/external/m;->d(F)I

    .line 127
    .line 128
    .line 129
    move-result v13

    .line 130
    const/high16 v14, 0x3f800000    # 1.0f

    .line 131
    .line 132
    invoke-direct {v10, v6, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v5, v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v2, v7}, Lcom/htcheat/external/m;->d(F)I

    .line 139
    .line 140
    .line 141
    move-result v7

    .line 142
    invoke-virtual {v2, v7}, Lcom/htcheat/external/m;->m(I)Landroid/view/View;

    .line 143
    .line 144
    .line 145
    move-result-object v7

    .line 146
    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 147
    .line 148
    .line 149
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 150
    .line 151
    invoke-virtual {v2, v11}, Lcom/htcheat/external/m;->d(F)I

    .line 152
    .line 153
    .line 154
    move-result v8

    .line 155
    invoke-direct {v7, v6, v8, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v5, v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 159
    .line 160
    .line 161
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 162
    .line 163
    invoke-virtual {v2, v11}, Lcom/htcheat/external/m;->d(F)I

    .line 164
    .line 165
    .line 166
    move-result v8

    .line 167
    const/4 v9, -0x1

    .line 168
    invoke-direct {v7, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v2, v4}, Lcom/htcheat/external/m;->d(F)I

    .line 172
    .line 173
    .line 174
    move-result v4

    .line 175
    invoke-virtual {v7, v6, v6, v6, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {v1, v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 179
    .line 180
    .line 181
    array-length v4, v12

    .line 182
    move v5, v6

    .line 183
    :goto_0
    if-ge v5, v4, :cond_1

    .line 184
    .line 185
    aget-object v7, v12, v5

    .line 186
    .line 187
    iget-object v8, v2, Lcom/htcheat/external/m;->h:Ljava/util/HashMap;

    .line 188
    .line 189
    iget v10, v7, LA1/e0;->b:I

    .line 190
    .line 191
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 192
    .line 193
    .line 194
    move-result-object v11

    .line 195
    invoke-virtual {v8, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    move-result v11

    .line 199
    if-nez v11, :cond_0

    .line 200
    .line 201
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 202
    .line 203
    .line 204
    move-result-object v11

    .line 205
    sget-object v13, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 206
    .line 207
    invoke-virtual {v8, v11, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    :cond_0
    invoke-virtual {v2}, Lcom/htcheat/external/m;->c()Landroid/widget/LinearLayout;

    .line 211
    .line 212
    .line 213
    move-result-object v11

    .line 214
    iget-object v13, v7, LA1/e0;->a:Ljava/lang/String;

    .line 215
    .line 216
    const/16 v15, 0xe

    .line 217
    .line 218
    const v9, -0x28251f

    .line 219
    .line 220
    .line 221
    invoke-virtual {v2, v13, v15, v9, v6}, Lcom/htcheat/external/m;->o(Ljava/lang/String;III)Landroid/widget/TextView;

    .line 222
    .line 223
    .line 224
    move-result-object v9

    .line 225
    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 226
    .line 227
    .line 228
    sget-object v13, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 229
    .line 230
    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 231
    .line 232
    .line 233
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    .line 234
    .line 235
    const/4 v15, -0x1

    .line 236
    invoke-direct {v13, v6, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v11, v9, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 240
    .line 241
    .line 242
    new-instance v9, LA1/n0;

    .line 243
    .line 244
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 245
    .line 246
    .line 247
    move-result-object v13

    .line 248
    invoke-direct {v9, v2, v13}, LA1/n0;-><init>(Lcom/htcheat/external/m;Landroid/content/Context;)V

    .line 249
    .line 250
    .line 251
    iget-object v13, v2, Lcom/htcheat/external/m;->f:Ljava/util/HashMap;

    .line 252
    .line 253
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 254
    .line 255
    .line 256
    move-result-object v15

    .line 257
    invoke-virtual {v13, v15, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    sget-object v13, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 261
    .line 262
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 263
    .line 264
    .line 265
    move-result-object v15

    .line 266
    invoke-virtual {v8, v15}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v8

    .line 270
    invoke-virtual {v13, v8}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 271
    .line 272
    .line 273
    move-result v8

    .line 274
    invoke-virtual {v2, v10, v9, v8}, Lcom/htcheat/external/m;->j(ILA1/n0;Z)V

    .line 275
    .line 276
    .line 277
    new-instance v8, LA1/k0;

    .line 278
    .line 279
    const/4 v10, 0x1

    .line 280
    invoke-direct {v8, v2, v7, v10}, LA1/k0;-><init>(Lcom/htcheat/external/m;Ljava/lang/Object;I)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v9, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 284
    .line 285
    .line 286
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 287
    .line 288
    const/high16 v8, 0x42800000    # 64.0f

    .line 289
    .line 290
    invoke-virtual {v2, v8}, Lcom/htcheat/external/m;->d(F)I

    .line 291
    .line 292
    .line 293
    move-result v8

    .line 294
    const/high16 v10, 0x41d00000    # 26.0f

    .line 295
    .line 296
    invoke-virtual {v2, v10}, Lcom/htcheat/external/m;->d(F)I

    .line 297
    .line 298
    .line 299
    move-result v10

    .line 300
    invoke-direct {v7, v8, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 301
    .line 302
    .line 303
    invoke-virtual {v11, v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 304
    .line 305
    .line 306
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 307
    .line 308
    const/high16 v8, 0x42180000    # 38.0f

    .line 309
    .line 310
    invoke-virtual {v2, v8}, Lcom/htcheat/external/m;->d(F)I

    .line 311
    .line 312
    .line 313
    move-result v8

    .line 314
    const/4 v15, -0x1

    .line 315
    invoke-direct {v7, v15, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 316
    .line 317
    .line 318
    invoke-virtual {v1, v11, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 319
    .line 320
    .line 321
    add-int/lit8 v5, v5, 0x1

    .line 322
    .line 323
    move v9, v15

    .line 324
    goto/16 :goto_0

    .line 325
    .line 326
    :cond_1
    new-instance v4, Landroid/widget/PopupWindow;

    .line 327
    .line 328
    const/high16 v5, 0x43820000    # 260.0f

    .line 329
    .line 330
    invoke-virtual {v2, v5}, Lcom/htcheat/external/m;->d(F)I

    .line 331
    .line 332
    .line 333
    move-result v5

    .line 334
    const/4 v7, -0x2

    .line 335
    invoke-direct {v4, v1, v5, v7, v3}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {v4, v3}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    .line 339
    .line 340
    .line 341
    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    .line 342
    .line 343
    invoke-direct {v1, v6}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {v4, v1}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 347
    .line 348
    .line 349
    const/high16 v1, 0x43140000    # 148.0f

    .line 350
    .line 351
    invoke-virtual {v2, v1}, Lcom/htcheat/external/m;->d(F)I

    .line 352
    .line 353
    .line 354
    move-result v1

    .line 355
    neg-int v1, v1

    .line 356
    const/high16 v3, 0x40c00000    # 6.0f

    .line 357
    .line 358
    invoke-virtual {v2, v3}, Lcom/htcheat/external/m;->d(F)I

    .line 359
    .line 360
    .line 361
    move-result v2

    .line 362
    iget-object v3, v0, LA1/i0;->b:Landroid/widget/TextView;

    .line 363
    .line 364
    invoke-virtual {v4, v3, v1, v2}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;II)V

    .line 365
    .line 366
    .line 367
    return-void
.end method
