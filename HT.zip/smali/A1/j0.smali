.class public final synthetic LA1/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/htcheat/external/m;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/m;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/j0;->a:Lcom/htcheat/external/m;

    iput p2, p0, LA1/j0;->b:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2
    .line 3
    iget-object v0, p0, LA1/j0;->a:Lcom/htcheat/external/m;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/htcheat/external/m;->h:Ljava/util/HashMap;

    .line 6
    .line 7
    iget v2, p0, LA1/j0;->b:I

    .line 8
    .line 9
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    invoke-virtual {v1, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {p1, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    xor-int/lit8 p1, p1, 0x1

    .line 22
    .line 23
    invoke-virtual {v0, v2, p1}, Lcom/htcheat/external/m;->i(IZ)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
