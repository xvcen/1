.class public final synthetic LA1/k0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/htcheat/external/m;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/m;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p3, p0, LA1/k0;->a:I

    iput-object p1, p0, LA1/k0;->b:Lcom/htcheat/external/m;

    iput-object p2, p0, LA1/k0;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 10

    .line 1
    iget p1, p0, LA1/k0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LA1/k0;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, LA1/e0;

    .line 9
    .line 10
    iget p1, p1, LA1/e0;->b:I

    .line 11
    .line 12
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 13
    .line 14
    iget-object v1, p0, LA1/k0;->b:Lcom/htcheat/external/m;

    .line 15
    .line 16
    iget-object v2, v1, Lcom/htcheat/external/m;->h:Ljava/util/HashMap;

    .line 17
    .line 18
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-virtual {v0, v2}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    xor-int/lit8 v0, v0, 0x1

    .line 31
    .line 32
    invoke-virtual {v1, p1, v0}, Lcom/htcheat/external/m;->i(IZ)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_0
    iget-object p1, p0, LA1/k0;->c:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Ljava/lang/String;

    .line 39
    .line 40
    iget-object v0, p0, LA1/k0;->b:Lcom/htcheat/external/m;

    .line 41
    .line 42
    iget-object v1, v0, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_0

    .line 49
    .line 50
    iget-boolean v1, v0, Lcom/htcheat/external/m;->p:Z

    .line 51
    .line 52
    if-eqz v1, :cond_0

    .line 53
    .line 54
    goto/16 :goto_8

    .line 55
    .line 56
    :cond_0
    iget-object v1, v0, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Lcom/htcheat/external/m;->f(Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-virtual {v0, p1}, Lcom/htcheat/external/m;->f(Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    iput-object p1, v0, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 67
    .line 68
    iget-boolean v3, v0, Lcom/htcheat/external/m;->p:Z

    .line 69
    .line 70
    const/4 v4, 0x0

    .line 71
    const/high16 v5, 0x3f800000    # 1.0f

    .line 72
    .line 73
    if-eqz v3, :cond_4

    .line 74
    .line 75
    if-eqz v1, :cond_4

    .line 76
    .line 77
    if-eqz v2, :cond_4

    .line 78
    .line 79
    if-ne v1, v2, :cond_1

    .line 80
    .line 81
    goto/16 :goto_1

    .line 82
    .line 83
    :cond_1
    const-wide v6, -0x259b3377dbfaL

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    invoke-static {v6, v7}, LI1/a;->a(J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    iget-object v3, v0, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    const/high16 v3, 0x41900000    # 18.0f

    .line 99
    .line 100
    invoke-virtual {v0, v3}, Lcom/htcheat/external/m;->d(F)I

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    int-to-float v3, v3

    .line 105
    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    invoke-virtual {v6}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v2}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 113
    .line 114
    .line 115
    move-result-object v6

    .line 116
    invoke-virtual {v6}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 117
    .line 118
    .line 119
    const/4 v6, 0x0

    .line 120
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v2, v4}, Landroid/view/View;->setAlpha(F)V

    .line 124
    .line 125
    .line 126
    if-nez p1, :cond_2

    .line 127
    .line 128
    move v6, v3

    .line 129
    goto :goto_0

    .line 130
    :cond_2
    neg-float v6, v3

    .line 131
    :goto_0
    invoke-virtual {v2, v6}, Landroid/view/View;->setTranslationX(F)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 135
    .line 136
    .line 137
    move-result-object v6

    .line 138
    invoke-virtual {v6, v4}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    if-nez p1, :cond_3

    .line 143
    .line 144
    neg-float v3, v3

    .line 145
    :cond_3
    invoke-virtual {v6, v3}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    const-wide/16 v6, 0x82

    .line 150
    .line 151
    invoke-virtual {p1, v6, v7}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    new-instance v3, Landroid/view/animation/DecelerateInterpolator;

    .line 156
    .line 157
    invoke-direct {v3}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 158
    .line 159
    .line 160
    invoke-virtual {p1, v3}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    new-instance v3, LA1/d;

    .line 165
    .line 166
    const/4 v6, 0x2

    .line 167
    invoke-direct {v3, v6, v0, v1}, LA1/d;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1, v3}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v2}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    invoke-virtual {p1, v5}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    invoke-virtual {p1, v4}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    const-wide/16 v1, 0xb4

    .line 190
    .line 191
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    const-wide/16 v1, 0x23

    .line 196
    .line 197
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewPropertyAnimator;->setStartDelay(J)Landroid/view/ViewPropertyAnimator;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    .line 202
    .line 203
    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 204
    .line 205
    .line 206
    invoke-virtual {p1, v1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 211
    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_4
    :goto_1
    invoke-virtual {v0, p1}, Lcom/htcheat/external/m;->k(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    :goto_2
    iget-object p1, v0, Lcom/htcheat/external/m;->j:Ljava/util/HashMap;

    .line 218
    .line 219
    invoke-virtual {p1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    if-eqz v1, :cond_9

    .line 232
    .line 233
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    check-cast v1, Ljava/util/Map$Entry;

    .line 238
    .line 239
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v2

    .line 243
    check-cast v2, Ljava/lang/String;

    .line 244
    .line 245
    iget-object v3, v0, Lcom/htcheat/external/m;->q:Ljava/lang/String;

    .line 246
    .line 247
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v2

    .line 251
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    check-cast v3, Landroid/widget/TextView;

    .line 256
    .line 257
    if-eqz v2, :cond_5

    .line 258
    .line 259
    const v6, -0xceb8

    .line 260
    .line 261
    .line 262
    goto :goto_4

    .line 263
    :cond_5
    const v6, -0x3a3731

    .line 264
    .line 265
    .line 266
    :goto_4
    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 267
    .line 268
    .line 269
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v3

    .line 273
    check-cast v3, Landroid/widget/TextView;

    .line 274
    .line 275
    sget-object v6, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 276
    .line 277
    invoke-virtual {v3, v6, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 278
    .line 279
    .line 280
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v3

    .line 284
    check-cast v3, Landroid/widget/TextView;

    .line 285
    .line 286
    if-eqz v2, :cond_6

    .line 287
    .line 288
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    .line 289
    .line 290
    sget-object v7, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 291
    .line 292
    const v8, 0x552b0008

    .line 293
    .line 294
    .line 295
    const v9, -0x7700d9c4

    .line 296
    .line 297
    .line 298
    filled-new-array {v8, v9}, [I

    .line 299
    .line 300
    .line 301
    move-result-object v8

    .line 302
    invoke-direct {v6, v7, v8}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v6, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 306
    .line 307
    .line 308
    goto :goto_5

    .line 309
    :cond_6
    const/4 v6, 0x0

    .line 310
    :goto_5
    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 311
    .line 312
    .line 313
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    check-cast v1, Landroid/widget/TextView;

    .line 318
    .line 319
    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 320
    .line 321
    .line 322
    move-result-object v1

    .line 323
    const v3, 0x3f851eb8    # 1.04f

    .line 324
    .line 325
    .line 326
    if-eqz v2, :cond_7

    .line 327
    .line 328
    move v6, v3

    .line 329
    goto :goto_6

    .line 330
    :cond_7
    move v6, v5

    .line 331
    :goto_6
    invoke-virtual {v1, v6}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    .line 332
    .line 333
    .line 334
    move-result-object v1

    .line 335
    if-eqz v2, :cond_8

    .line 336
    .line 337
    goto :goto_7

    .line 338
    :cond_8
    move v3, v5

    .line 339
    :goto_7
    invoke-virtual {v1, v3}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    .line 340
    .line 341
    .line 342
    move-result-object v1

    .line 343
    const-wide/16 v2, 0x8c

    .line 344
    .line 345
    invoke-virtual {v1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 346
    .line 347
    .line 348
    move-result-object v1

    .line 349
    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    .line 350
    .line 351
    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 352
    .line 353
    .line 354
    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    .line 355
    .line 356
    .line 357
    move-result-object v1

    .line 358
    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 359
    .line 360
    .line 361
    goto/16 :goto_3

    .line 362
    .line 363
    :cond_9
    :goto_8
    return-void

    .line 364
    nop

    .line 365
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
