.class public final LA1/l;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic h:Z

.field public final synthetic i:Lcom/htcheat/external/A;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:LI/b0;


# direct methods
.method public constructor <init>(ZLcom/htcheat/external/A;Ljava/lang/String;LI/b0;LN1/c;)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LA1/l;->h:Z

    .line 2
    .line 3
    iput-object p2, p0, LA1/l;->i:Lcom/htcheat/external/A;

    .line 4
    .line 5
    iput-object p3, p0, LA1/l;->j:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p4, p0, LA1/l;->k:LI/b0;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p5}, LP1/i;-><init>(ILN1/c;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LA1/l;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LA1/l;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LA1/l;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 6

    .line 1
    new-instance v0, LA1/l;

    .line 2
    .line 3
    iget-object v3, p0, LA1/l;->j:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v4, p0, LA1/l;->k:LI/b0;

    .line 6
    .line 7
    iget-boolean v1, p0, LA1/l;->h:Z

    .line 8
    .line 9
    iget-object v2, p0, LA1/l;->i:Lcom/htcheat/external/A;

    .line 10
    .line 11
    move-object v5, p1

    .line 12
    invoke-direct/range {v0 .. v5}, LA1/l;-><init>(ZLcom/htcheat/external/A;Ljava/lang/String;LI/b0;LN1/c;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, LA1/l;->h:Z

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    sget-object p1, Lcom/htcheat/external/A;->H:LA1/i;

    .line 9
    .line 10
    iget-object p1, p0, LA1/l;->k:LI/b0;

    .line 11
    .line 12
    invoke-interface {p1}, LI/a1;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, LA1/d0;

    .line 17
    .line 18
    if-nez p1, :cond_0

    .line 19
    .line 20
    iget-object p1, p0, LA1/l;->i:Lcom/htcheat/external/A;

    .line 21
    .line 22
    invoke-virtual {p1}, Lcom/htcheat/external/A;->j()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    iget-object v0, p0, LA1/l;->j:Ljava/lang/String;

    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    invoke-virtual {p1, v0, v1, v1}, Lcom/htcheat/external/A;->g(Ljava/lang/String;ZZ)V

    .line 32
    .line 33
    .line 34
    :cond_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 35
    .line 36
    return-object p1
.end method
