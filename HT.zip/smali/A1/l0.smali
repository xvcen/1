.class public final synthetic LA1/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/htcheat/external/m;

.field public final synthetic c:[LA1/e0;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/m;[LA1/e0;I)V
    .locals 0

    .line 1
    iput p3, p0, LA1/l0;->a:I

    iput-object p1, p0, LA1/l0;->b:Lcom/htcheat/external/m;

    iput-object p2, p0, LA1/l0;->c:[LA1/e0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    .line 1
    iget p1, p0, LA1/l0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LA1/l0;->c:[LA1/e0;

    .line 7
    .line 8
    array-length v0, p1

    .line 9
    const/4 v1, 0x0

    .line 10
    move v2, v1

    .line 11
    :goto_0
    if-ge v2, v0, :cond_0

    .line 12
    .line 13
    aget-object v3, p1, v2

    .line 14
    .line 15
    iget v3, v3, LA1/e0;->b:I

    .line 16
    .line 17
    iget-object v4, p0, LA1/l0;->b:Lcom/htcheat/external/m;

    .line 18
    .line 19
    invoke-virtual {v4, v3, v1}, Lcom/htcheat/external/m;->i(IZ)V

    .line 20
    .line 21
    .line 22
    add-int/lit8 v2, v2, 0x1

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    return-void

    .line 26
    :pswitch_0
    iget-object p1, p0, LA1/l0;->c:[LA1/e0;

    .line 27
    .line 28
    array-length v0, p1

    .line 29
    const/4 v1, 0x0

    .line 30
    :goto_1
    if-ge v1, v0, :cond_1

    .line 31
    .line 32
    aget-object v2, p1, v1

    .line 33
    .line 34
    iget v2, v2, LA1/e0;->b:I

    .line 35
    .line 36
    iget-object v3, p0, LA1/l0;->b:Lcom/htcheat/external/m;

    .line 37
    .line 38
    const/4 v4, 0x1

    .line 39
    invoke-virtual {v3, v2, v4}, Lcom/htcheat/external/m;->i(IZ)V

    .line 40
    .line 41
    .line 42
    add-int/lit8 v1, v1, 0x1

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
