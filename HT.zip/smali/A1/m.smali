.class public final synthetic LA1/m;
.super LV1/g;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V
    .locals 0

    .line 1
    iput p8, p0, LA1/m;->k:I

    invoke-direct/range {p0 .. p7}, LV1/g;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LA1/m;->k:I

    .line 4
    .line 5
    sget-object v2, LJ1/m;->a:LJ1/m;

    .line 6
    .line 7
    iget-object v4, v0, LV1/c;->e:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast v4, Landroid/view/View;

    .line 13
    .line 14
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    .line 16
    const/16 v2, 0x1e

    .line 17
    .line 18
    if-lt v1, v2, :cond_0

    .line 19
    .line 20
    invoke-static {v4}, LA0/g;->c(Landroid/view/View;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    const/16 v2, 0x1d

    .line 24
    .line 25
    if-lt v1, v2, :cond_2

    .line 26
    .line 27
    invoke-static {v4}, LA0/d;->a(Landroid/view/View;)Landroid/view/contentcapture/ContentCaptureSession;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-nez v1, :cond_1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    new-instance v3, LA0/e;

    .line 35
    .line 36
    invoke-direct {v3, v1, v4}, LA0/e;-><init>(Landroid/view/contentcapture/ContentCaptureSession;Landroid/view/View;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_2
    :goto_0
    const/4 v3, 0x0

    .line 41
    :goto_1
    return-object v3

    .line 42
    :pswitch_0
    check-cast v4, Ln/L;

    .line 43
    .line 44
    iget-object v1, v4, Ln/L;->x:Lb0/y;

    .line 45
    .line 46
    invoke-static {v1}, Lb0/y;->c1(Lb0/y;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    return-object v1

    .line 55
    :pswitch_1
    check-cast v4, Lb0/i;

    .line 56
    .line 57
    iget-object v1, v4, Lb0/i;->c:Li/F;

    .line 58
    .line 59
    iget-object v5, v4, Lb0/i;->d:Li/F;

    .line 60
    .line 61
    iget-object v6, v4, Lb0/i;->a:Lb0/p;

    .line 62
    .line 63
    invoke-virtual {v6}, Lb0/p;->f()Lb0/y;

    .line 64
    .line 65
    .line 66
    move-result-object v7

    .line 67
    sget-object v8, Lb0/x;->f:Lb0/x;

    .line 68
    .line 69
    const/16 v3, 0x8

    .line 70
    .line 71
    const-wide/16 v17, 0x80

    .line 72
    .line 73
    if-nez v7, :cond_6

    .line 74
    .line 75
    iget-object v7, v5, Li/F;->b:[Ljava/lang/Object;

    .line 76
    .line 77
    iget-object v10, v5, Li/F;->a:[J

    .line 78
    .line 79
    const-wide/16 v19, 0xff

    .line 80
    .line 81
    array-length v11, v10

    .line 82
    add-int/lit8 v11, v11, -0x2

    .line 83
    .line 84
    if-ltz v11, :cond_13

    .line 85
    .line 86
    const/4 v12, 0x0

    .line 87
    const/16 v21, 0x7

    .line 88
    .line 89
    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    :goto_2
    aget-wide v13, v10, v12

    .line 95
    .line 96
    move-object/from16 v16, v10

    .line 97
    .line 98
    not-long v9, v13

    .line 99
    shl-long v9, v9, v21

    .line 100
    .line 101
    and-long/2addr v9, v13

    .line 102
    and-long v9, v9, v22

    .line 103
    .line 104
    cmp-long v9, v9, v22

    .line 105
    .line 106
    if-eqz v9, :cond_5

    .line 107
    .line 108
    sub-int v9, v12, v11

    .line 109
    .line 110
    not-int v9, v9

    .line 111
    ushr-int/lit8 v9, v9, 0x1f

    .line 112
    .line 113
    rsub-int/lit8 v9, v9, 0x8

    .line 114
    .line 115
    const/4 v10, 0x0

    .line 116
    :goto_3
    if-ge v10, v9, :cond_4

    .line 117
    .line 118
    and-long v24, v13, v19

    .line 119
    .line 120
    cmp-long v24, v24, v17

    .line 121
    .line 122
    if-gez v24, :cond_3

    .line 123
    .line 124
    shl-int/lit8 v24, v12, 0x3

    .line 125
    .line 126
    add-int v24, v24, v10

    .line 127
    .line 128
    aget-object v24, v7, v24

    .line 129
    .line 130
    move-object/from16 v15, v24

    .line 131
    .line 132
    check-cast v15, Lb0/g;

    .line 133
    .line 134
    invoke-interface {v15, v8}, Lb0/g;->i0(Lb0/x;)V

    .line 135
    .line 136
    .line 137
    :cond_3
    shr-long/2addr v13, v3

    .line 138
    add-int/lit8 v10, v10, 0x1

    .line 139
    .line 140
    goto :goto_3

    .line 141
    :cond_4
    if-ne v9, v3, :cond_13

    .line 142
    .line 143
    :cond_5
    if-eq v12, v11, :cond_13

    .line 144
    .line 145
    add-int/lit8 v12, v12, 0x1

    .line 146
    .line 147
    move-object/from16 v10, v16

    .line 148
    .line 149
    goto :goto_2

    .line 150
    :cond_6
    const-wide/16 v19, 0xff

    .line 151
    .line 152
    const/16 v21, 0x7

    .line 153
    .line 154
    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    iget-boolean v9, v7, LW/p;->q:Z

    .line 160
    .line 161
    if-eqz v9, :cond_13

    .line 162
    .line 163
    invoke-virtual {v1, v7}, Li/F;->c(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result v9

    .line 167
    if-eqz v9, :cond_7

    .line 168
    .line 169
    invoke-virtual {v7}, Lb0/y;->a1()V

    .line 170
    .line 171
    .line 172
    :cond_7
    invoke-virtual {v7}, Lb0/y;->Z0()Lb0/x;

    .line 173
    .line 174
    .line 175
    move-result-object v9

    .line 176
    iget-object v10, v7, LW/p;->d:LW/p;

    .line 177
    .line 178
    iget-boolean v10, v10, LW/p;->q:Z

    .line 179
    .line 180
    if-nez v10, :cond_8

    .line 181
    .line 182
    const-string v10, "visitAncestors called on an unattached node"

    .line 183
    .line 184
    invoke-static {v10}, Lt0/a;->b(Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    :cond_8
    iget-object v10, v7, LW/p;->d:LW/p;

    .line 188
    .line 189
    invoke-static {v7}, Lw0/j;->u(Lw0/h;)Lw0/E;

    .line 190
    .line 191
    .line 192
    move-result-object v7

    .line 193
    const/4 v11, 0x0

    .line 194
    :goto_4
    if-eqz v7, :cond_f

    .line 195
    .line 196
    iget-object v12, v7, Lw0/E;->I:LQ/m;

    .line 197
    .line 198
    iget-object v12, v12, LQ/m;->j:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v12, LW/p;

    .line 201
    .line 202
    iget v12, v12, LW/p;->g:I

    .line 203
    .line 204
    and-int/lit16 v12, v12, 0x1400

    .line 205
    .line 206
    if-eqz v12, :cond_d

    .line 207
    .line 208
    :goto_5
    if-eqz v10, :cond_d

    .line 209
    .line 210
    iget v12, v10, LW/p;->f:I

    .line 211
    .line 212
    and-int/lit16 v13, v12, 0x1400

    .line 213
    .line 214
    if-eqz v13, :cond_c

    .line 215
    .line 216
    and-int/lit16 v12, v12, 0x400

    .line 217
    .line 218
    if-eqz v12, :cond_9

    .line 219
    .line 220
    add-int/lit8 v11, v11, 0x1

    .line 221
    .line 222
    :cond_9
    instance-of v12, v10, Lb0/g;

    .line 223
    .line 224
    if-eqz v12, :cond_c

    .line 225
    .line 226
    invoke-virtual {v5, v10}, Li/F;->c(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v12

    .line 230
    if-nez v12, :cond_a

    .line 231
    .line 232
    goto :goto_7

    .line 233
    :cond_a
    const/4 v12, 0x1

    .line 234
    if-gt v11, v12, :cond_b

    .line 235
    .line 236
    move-object v12, v10

    .line 237
    check-cast v12, Lb0/g;

    .line 238
    .line 239
    invoke-interface {v12, v9}, Lb0/g;->i0(Lb0/x;)V

    .line 240
    .line 241
    .line 242
    goto :goto_6

    .line 243
    :cond_b
    move-object v12, v10

    .line 244
    check-cast v12, Lb0/g;

    .line 245
    .line 246
    sget-object v13, Lb0/x;->e:Lb0/x;

    .line 247
    .line 248
    invoke-interface {v12, v13}, Lb0/g;->i0(Lb0/x;)V

    .line 249
    .line 250
    .line 251
    :goto_6
    invoke-virtual {v5, v10}, Li/F;->k(Ljava/lang/Object;)Z

    .line 252
    .line 253
    .line 254
    :cond_c
    :goto_7
    iget-object v10, v10, LW/p;->h:LW/p;

    .line 255
    .line 256
    goto :goto_5

    .line 257
    :cond_d
    invoke-virtual {v7}, Lw0/E;->q()Lw0/E;

    .line 258
    .line 259
    .line 260
    move-result-object v7

    .line 261
    if-eqz v7, :cond_e

    .line 262
    .line 263
    iget-object v10, v7, Lw0/E;->I:LQ/m;

    .line 264
    .line 265
    if-eqz v10, :cond_e

    .line 266
    .line 267
    iget-object v10, v10, LQ/m;->i:Ljava/lang/Object;

    .line 268
    .line 269
    check-cast v10, Lw0/v0;

    .line 270
    .line 271
    goto :goto_4

    .line 272
    :cond_e
    const/4 v10, 0x0

    .line 273
    goto :goto_4

    .line 274
    :cond_f
    iget-object v7, v5, Li/F;->b:[Ljava/lang/Object;

    .line 275
    .line 276
    iget-object v9, v5, Li/F;->a:[J

    .line 277
    .line 278
    array-length v10, v9

    .line 279
    add-int/lit8 v10, v10, -0x2

    .line 280
    .line 281
    if-ltz v10, :cond_13

    .line 282
    .line 283
    const/4 v11, 0x0

    .line 284
    :goto_8
    aget-wide v12, v9, v11

    .line 285
    .line 286
    not-long v14, v12

    .line 287
    shl-long v14, v14, v21

    .line 288
    .line 289
    and-long/2addr v14, v12

    .line 290
    and-long v14, v14, v22

    .line 291
    .line 292
    cmp-long v14, v14, v22

    .line 293
    .line 294
    if-eqz v14, :cond_12

    .line 295
    .line 296
    sub-int v14, v11, v10

    .line 297
    .line 298
    not-int v14, v14

    .line 299
    ushr-int/lit8 v14, v14, 0x1f

    .line 300
    .line 301
    rsub-int/lit8 v14, v14, 0x8

    .line 302
    .line 303
    const/4 v15, 0x0

    .line 304
    :goto_9
    if-ge v15, v14, :cond_11

    .line 305
    .line 306
    and-long v26, v12, v19

    .line 307
    .line 308
    cmp-long v16, v26, v17

    .line 309
    .line 310
    if-gez v16, :cond_10

    .line 311
    .line 312
    shl-int/lit8 v16, v11, 0x3

    .line 313
    .line 314
    add-int v16, v16, v15

    .line 315
    .line 316
    aget-object v16, v7, v16

    .line 317
    .line 318
    move/from16 v24, v3

    .line 319
    .line 320
    move-object/from16 v3, v16

    .line 321
    .line 322
    check-cast v3, Lb0/g;

    .line 323
    .line 324
    invoke-interface {v3, v8}, Lb0/g;->i0(Lb0/x;)V

    .line 325
    .line 326
    .line 327
    goto :goto_a

    .line 328
    :cond_10
    move/from16 v24, v3

    .line 329
    .line 330
    :goto_a
    shr-long v12, v12, v24

    .line 331
    .line 332
    add-int/lit8 v15, v15, 0x1

    .line 333
    .line 334
    move/from16 v3, v24

    .line 335
    .line 336
    goto :goto_9

    .line 337
    :cond_11
    if-ne v14, v3, :cond_13

    .line 338
    .line 339
    :cond_12
    if-eq v11, v10, :cond_13

    .line 340
    .line 341
    add-int/lit8 v11, v11, 0x1

    .line 342
    .line 343
    goto :goto_8

    .line 344
    :cond_13
    invoke-virtual {v6}, Lb0/p;->f()Lb0/y;

    .line 345
    .line 346
    .line 347
    move-result-object v3

    .line 348
    if-eqz v3, :cond_14

    .line 349
    .line 350
    iget-object v3, v6, Lb0/p;->c:Lb0/y;

    .line 351
    .line 352
    invoke-virtual {v3}, Lb0/y;->Z0()Lb0/x;

    .line 353
    .line 354
    .line 355
    move-result-object v3

    .line 356
    if-ne v3, v8, :cond_15

    .line 357
    .line 358
    :cond_14
    invoke-virtual {v6}, Lb0/p;->c()V

    .line 359
    .line 360
    .line 361
    :cond_15
    invoke-virtual {v1}, Li/F;->b()V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v5}, Li/F;->b()V

    .line 365
    .line 366
    .line 367
    const/4 v15, 0x0

    .line 368
    iput-boolean v15, v4, Lb0/i;->e:Z

    .line 369
    .line 370
    return-object v2

    .line 371
    :pswitch_2
    check-cast v4, LD/e;

    .line 372
    .line 373
    invoke-interface {v4}, LD/e;->A0()Lz/c;

    .line 374
    .line 375
    .line 376
    move-result-object v1

    .line 377
    return-object v1

    .line 378
    :pswitch_3
    check-cast v4, Lcom/htcheat/external/A;

    .line 379
    .line 380
    sget-object v1, Lcom/htcheat/external/A;->H:LA1/i;

    .line 381
    .line 382
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 383
    .line 384
    .line 385
    new-instance v1, Landroid/content/Intent;

    .line 386
    .line 387
    const-wide v5, -0x3b833377dbfaL

    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    .line 393
    .line 394
    .line 395
    move-result-object v3

    .line 396
    const-wide v5, -0x3ba43377dbfaL

    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v5

    .line 405
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 406
    .line 407
    .line 408
    move-result-object v5

    .line 409
    invoke-direct {v1, v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 410
    .line 411
    .line 412
    invoke-virtual {v4, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 413
    .line 414
    .line 415
    return-object v2

    .line 416
    nop

    .line 417
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
