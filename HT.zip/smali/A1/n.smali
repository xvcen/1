.class public final LA1/n;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/htcheat/external/A;


# direct methods
.method public synthetic constructor <init>(Lcom/htcheat/external/A;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/n;->a:I

    iput-object p1, p0, LA1/n;->b:Lcom/htcheat/external/A;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method


# virtual methods
.method public final doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LA1/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, [Ljava/lang/Void;

    .line 7
    .line 8
    const-wide v0, -0x3a863377dbfaL

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, LA1/n;->b:Lcom/htcheat/external/A;

    .line 21
    .line 22
    iget-object p1, p1, Lcom/htcheat/external/A;->v:Lcom/htcheat/external/j;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/htcheat/external/j;->g()V

    .line 28
    .line 29
    .line 30
    return-object v0

    .line 31
    :cond_0
    const-wide v1, -0x3a8f3377dbfaL

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    invoke-static {p1}, LV1/i;->k(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw v0

    .line 44
    :pswitch_0
    check-cast p1, [Ljava/lang/Void;

    .line 45
    .line 46
    const-wide v0, -0x38163377dbfaL

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    iget-object p1, p0, LA1/n;->b:Lcom/htcheat/external/A;

    .line 59
    .line 60
    iget-object p1, p1, Lcom/htcheat/external/A;->v:Lcom/htcheat/external/j;

    .line 61
    .line 62
    if-eqz p1, :cond_4

    .line 63
    .line 64
    iget-object p1, p1, Lcom/htcheat/external/j;->a:Landroid/content/Context;

    .line 65
    .line 66
    invoke-static {p1}, Lcom/htcheat/external/j;->d(Landroid/content/Context;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    const/4 v1, 0x0

    .line 71
    if-nez v0, :cond_1

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_1
    new-instance v0, Lcom/htcheat/external/i;

    .line 75
    .line 76
    invoke-direct {v0, p1}, Lcom/htcheat/external/i;-><init>(Landroid/content/Context;)V

    .line 77
    .line 78
    .line 79
    :try_start_0
    invoke-virtual {v0}, Lcom/htcheat/external/i;->a()Z

    .line 80
    .line 81
    .line 82
    move-result p1

    .line 83
    if-eqz p1, :cond_3

    .line 84
    .line 85
    invoke-virtual {v0}, Lcom/htcheat/external/i;->f()Z

    .line 86
    .line 87
    .line 88
    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 89
    if-nez p1, :cond_2

    .line 90
    .line 91
    :catch_0
    move p1, v1

    .line 92
    goto :goto_0

    .line 93
    :cond_2
    const-wide v2, -0x2a6b3377dbfaL

    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    :try_start_1
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    const-wide v2, -0x2a753377dbfaL

    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    invoke-virtual {v0, v2}, Lcom/htcheat/external/i;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result p1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 119
    :goto_0
    if-eqz p1, :cond_3

    .line 120
    .line 121
    const/4 v1, 0x1

    .line 122
    :cond_3
    invoke-virtual {v0}, Lcom/htcheat/external/i;->b()V

    .line 123
    .line 124
    .line 125
    :goto_1
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    return-object p1

    .line 130
    :catchall_0
    move-exception p1

    .line 131
    invoke-virtual {v0}, Lcom/htcheat/external/i;->b()V

    .line 132
    .line 133
    .line 134
    throw p1

    .line 135
    :cond_4
    const-wide v0, -0x381f3377dbfaL

    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-static {p1}, LV1/i;->k(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    const/4 p1, 0x0

    .line 148
    throw p1

    .line 149
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onPostExecute(Ljava/lang/Object;)V
    .locals 4

    .line 1
    iget v0, p0, LA1/n;->a:I

    .line 2
    .line 3
    iget-object v1, p0, LA1/n;->b:Lcom/htcheat/external/A;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/lang/Void;

    .line 9
    .line 10
    sget-object p1, Lcom/htcheat/external/A;->H:LA1/i;

    .line 11
    .line 12
    const/4 p1, 0x0

    .line 13
    invoke-virtual {v1, p1}, Lcom/htcheat/external/A;->l(Z)V

    .line 14
    .line 15
    .line 16
    const-wide v2, -0x3a903377dbfaL

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {v1, p1}, Lcom/htcheat/external/A;->m(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const/4 p1, 0x1

    .line 29
    invoke-virtual {v1, p1}, Lcom/htcheat/external/A;->k(Z)Z

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 34
    .line 35
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 36
    .line 37
    invoke-static {p1, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_0

    .line 42
    .line 43
    const-wide v2, -0x38203377dbfaL

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    :goto_0
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    goto :goto_1

    .line 53
    :cond_0
    const-wide v2, -0x38313377dbfaL

    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    goto :goto_0

    .line 59
    :goto_1
    sget-object v0, Lcom/htcheat/external/A;->H:LA1/i;

    .line 60
    .line 61
    invoke-virtual {v1, p1}, Lcom/htcheat/external/A;->m(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
