.class public final LA1/n0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final d:Landroid/graphics/Paint;

.field public final e:Landroid/graphics/Paint;

.field public final f:Landroid/graphics/Paint;

.field public final g:Landroid/graphics/RectF;

.field public h:Landroid/animation/ValueAnimator;

.field public i:F

.field public j:Z

.field public final synthetic k:Lcom/htcheat/external/m;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/m;Landroid/content/Context;)V
    .locals 2

    .line 1
    iput-object p1, p0, LA1/n0;->k:Lcom/htcheat/external/m;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Landroid/graphics/Paint;

    .line 7
    .line 8
    const/4 p2, 0x1

    .line 9
    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, LA1/n0;->d:Landroid/graphics/Paint;

    .line 13
    .line 14
    new-instance p1, Landroid/graphics/Paint;

    .line 15
    .line 16
    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, LA1/n0;->e:Landroid/graphics/Paint;

    .line 20
    .line 21
    new-instance v0, Landroid/graphics/Paint;

    .line 22
    .line 23
    invoke-direct {v0, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, LA1/n0;->f:Landroid/graphics/Paint;

    .line 27
    .line 28
    new-instance v1, Landroid/graphics/RectF;

    .line 29
    .line 30
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, LA1/n0;->g:Landroid/graphics/RectF;

    .line 34
    .line 35
    invoke-virtual {p0, p2}, Landroid/view/View;->setClickable(Z)V

    .line 36
    .line 37
    .line 38
    const p2, -0xd0c0a

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 42
    .line 43
    .line 44
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    .line 45
    .line 46
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 47
    .line 48
    .line 49
    sget-object p1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 50
    .line 51
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public static a(FII)I
    .locals 6

    .line 1
    ushr-int/lit8 v0, p1, 0x18

    .line 2
    .line 3
    and-int/lit16 v0, v0, 0xff

    .line 4
    .line 5
    ushr-int/lit8 v1, p1, 0x10

    .line 6
    .line 7
    and-int/lit16 v1, v1, 0xff

    .line 8
    .line 9
    ushr-int/lit8 v2, p1, 0x8

    .line 10
    .line 11
    and-int/lit16 v2, v2, 0xff

    .line 12
    .line 13
    and-int/lit16 p1, p1, 0xff

    .line 14
    .line 15
    ushr-int/lit8 v3, p2, 0x18

    .line 16
    .line 17
    and-int/lit16 v3, v3, 0xff

    .line 18
    .line 19
    ushr-int/lit8 v4, p2, 0x8

    .line 20
    .line 21
    and-int/lit16 v4, v4, 0xff

    .line 22
    .line 23
    and-int/lit16 p2, p2, 0xff

    .line 24
    .line 25
    int-to-float v5, v0

    .line 26
    sub-int/2addr v3, v0

    .line 27
    int-to-float v0, v3

    .line 28
    mul-float/2addr v0, p0

    .line 29
    add-float/2addr v0, v5

    .line 30
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    int-to-float v3, v1

    .line 35
    rsub-int v1, v1, 0xff

    .line 36
    .line 37
    int-to-float v1, v1

    .line 38
    mul-float/2addr v1, p0

    .line 39
    add-float/2addr v1, v3

    .line 40
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    int-to-float v3, v2

    .line 45
    sub-int/2addr v4, v2

    .line 46
    int-to-float v2, v4

    .line 47
    mul-float/2addr v2, p0

    .line 48
    add-float/2addr v2, v3

    .line 49
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    int-to-float v3, p1

    .line 54
    sub-int/2addr p2, p1

    .line 55
    int-to-float p1, p2

    .line 56
    mul-float/2addr p1, p0

    .line 57
    add-float/2addr p1, v3

    .line 58
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 59
    .line 60
    .line 61
    move-result p0

    .line 62
    shl-int/lit8 p1, v0, 0x18

    .line 63
    .line 64
    shl-int/lit8 p2, v1, 0x10

    .line 65
    .line 66
    or-int/2addr p1, p2

    .line 67
    shl-int/lit8 p2, v2, 0x8

    .line 68
    .line 69
    or-int/2addr p1, p2

    .line 70
    or-int/2addr p0, p1

    .line 71
    return p0
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 11

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    int-to-float v0, v0

    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    int-to-float v1, v1

    .line 14
    const/high16 v2, 0x40400000    # 3.0f

    .line 15
    .line 16
    iget-object v3, p0, LA1/n0;->k:Lcom/htcheat/external/m;

    .line 17
    .line 18
    invoke-virtual {v3, v2}, Lcom/htcheat/external/m;->d(F)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    int-to-float v2, v2

    .line 23
    const/4 v4, 0x0

    .line 24
    iget-object v5, p0, LA1/n0;->g:Landroid/graphics/RectF;

    .line 25
    .line 26
    invoke-virtual {v5, v4, v4, v0, v1}, Landroid/graphics/RectF;->set(FFFF)V

    .line 27
    .line 28
    .line 29
    iget v4, p0, LA1/n0;->i:F

    .line 30
    .line 31
    const v6, -0xcbc6bb

    .line 32
    .line 33
    .line 34
    const v7, -0xd9c4

    .line 35
    .line 36
    .line 37
    invoke-static {v4, v6, v7}, LA1/n0;->a(FII)I

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    iget-object v6, p0, LA1/n0;->d:Landroid/graphics/Paint;

    .line 42
    .line 43
    invoke-virtual {v6, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 44
    .line 45
    .line 46
    const/high16 v4, 0x3f000000    # 0.5f

    .line 47
    .line 48
    mul-float v7, v1, v4

    .line 49
    .line 50
    invoke-virtual {p1, v5, v7, v7, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 51
    .line 52
    .line 53
    sget-object v8, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 54
    .line 55
    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 56
    .line 57
    .line 58
    const/high16 v8, 0x3f800000    # 1.0f

    .line 59
    .line 60
    invoke-virtual {v3, v8}, Lcom/htcheat/external/m;->d(F)I

    .line 61
    .line 62
    .line 63
    move-result v8

    .line 64
    int-to-float v8, v8

    .line 65
    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 66
    .line 67
    .line 68
    const v8, 0x77ffffff

    .line 69
    .line 70
    .line 71
    iget v9, p0, LA1/n0;->i:F

    .line 72
    .line 73
    const v10, 0x44ffffff    # 2047.9999f

    .line 74
    .line 75
    .line 76
    invoke-static {v9, v10, v8}, LA1/n0;->a(FII)I

    .line 77
    .line 78
    .line 79
    move-result v8

    .line 80
    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p1, v5, v7, v7, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 84
    .line 85
    .line 86
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 87
    .line 88
    invoke-virtual {v6, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 89
    .line 90
    .line 91
    const/high16 v5, 0x40000000    # 2.0f

    .line 92
    .line 93
    mul-float/2addr v5, v2

    .line 94
    sub-float v6, v1, v5

    .line 95
    .line 96
    sub-float v8, v0, v6

    .line 97
    .line 98
    sub-float/2addr v8, v5

    .line 99
    iget v5, p0, LA1/n0;->i:F

    .line 100
    .line 101
    mul-float/2addr v8, v5

    .line 102
    add-float/2addr v8, v2

    .line 103
    mul-float/2addr v6, v4

    .line 104
    add-float/2addr v8, v6

    .line 105
    iget-object v2, p0, LA1/n0;->e:Landroid/graphics/Paint;

    .line 106
    .line 107
    invoke-virtual {p1, v8, v7, v6, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 108
    .line 109
    .line 110
    const/high16 v2, 0x41200000    # 10.0f

    .line 111
    .line 112
    invoke-virtual {v3, v2}, Lcom/htcheat/external/m;->d(F)I

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    int-to-float v2, v2

    .line 117
    iget-object v3, p0, LA1/n0;->f:Landroid/graphics/Paint;

    .line 118
    .line 119
    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 120
    .line 121
    .line 122
    const/4 v2, -0x1

    .line 123
    iget v5, p0, LA1/n0;->i:F

    .line 124
    .line 125
    const v6, -0x28251f

    .line 126
    .line 127
    .line 128
    invoke-static {v5, v6, v2}, LA1/n0;->a(FII)I

    .line 129
    .line 130
    .line 131
    move-result v2

    .line 132
    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 133
    .line 134
    .line 135
    iget v2, p0, LA1/n0;->i:F

    .line 136
    .line 137
    cmpl-float v2, v2, v4

    .line 138
    .line 139
    if-lez v2, :cond_0

    .line 140
    .line 141
    const-wide v5, -0x20463377dbfaL

    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    :goto_0
    invoke-static {v5, v6}, LI1/a;->a(J)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    goto :goto_1

    .line 151
    :cond_0
    const-wide v5, -0x20433377dbfaL

    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    goto :goto_0

    .line 157
    :goto_1
    iget v5, p0, LA1/n0;->i:F

    .line 158
    .line 159
    cmpl-float v5, v5, v4

    .line 160
    .line 161
    if-lez v5, :cond_1

    .line 162
    .line 163
    const v5, 0x3ea8f5c3    # 0.33f

    .line 164
    .line 165
    .line 166
    :goto_2
    mul-float/2addr v0, v5

    .line 167
    goto :goto_3

    .line 168
    :cond_1
    const v5, 0x3f2b851f    # 0.67f

    .line 169
    .line 170
    .line 171
    goto :goto_2

    .line 172
    :goto_3
    invoke-virtual {v3}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    iget v6, v5, Landroid/graphics/Paint$FontMetrics;->ascent:F

    .line 177
    .line 178
    sub-float/2addr v1, v6

    .line 179
    iget v5, v5, Landroid/graphics/Paint$FontMetrics;->descent:F

    .line 180
    .line 181
    sub-float/2addr v1, v5

    .line 182
    mul-float/2addr v1, v4

    .line 183
    invoke-virtual {p1, v2, v0, v1, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 184
    .line 185
    .line 186
    return-void
.end method
