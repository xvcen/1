.class public final synthetic LA1/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/g;


# instance fields
.field public final synthetic d:LD1/d;

.field public final synthetic e:Z

.field public final synthetic f:LU1/a;

.field public final synthetic g:LU1/a;

.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:Z

.field public final synthetic j:LU1/c;

.field public final synthetic k:LU1/c;

.field public final synthetic l:LU1/a;

.field public final synthetic m:LU1/a;

.field public final synthetic n:LU1/a;


# direct methods
.method public synthetic constructor <init>(LD1/d;ZLU1/a;LU1/a;Ljava/lang/String;ZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/o;->d:LD1/d;

    iput-boolean p2, p0, LA1/o;->e:Z

    iput-object p3, p0, LA1/o;->f:LU1/a;

    iput-object p4, p0, LA1/o;->g:LU1/a;

    iput-object p5, p0, LA1/o;->h:Ljava/lang/String;

    iput-boolean p6, p0, LA1/o;->i:Z

    iput-object p7, p0, LA1/o;->j:LU1/c;

    iput-object p8, p0, LA1/o;->k:LU1/c;

    iput-object p9, p0, LA1/o;->l:LU1/a;

    iput-object p10, p0, LA1/o;->m:LU1/a;

    iput-object p11, p0, LA1/o;->n:LU1/a;

    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lk/n;

    .line 6
    .line 7
    move-object/from16 v4, p2

    .line 8
    .line 9
    check-cast v4, LA1/d0;

    .line 10
    .line 11
    move-object/from16 v14, p3

    .line 12
    .line 13
    check-cast v14, LI/r;

    .line 14
    .line 15
    move-object/from16 v2, p4

    .line 16
    .line 17
    check-cast v2, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    const-string v3, "$this$AnimatedContent"

    .line 24
    .line 25
    invoke-static {v1, v3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object v5, v0, LA1/o;->d:LD1/d;

    .line 29
    .line 30
    iget-boolean v3, v0, LA1/o;->e:Z

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    if-eqz v4, :cond_0

    .line 34
    .line 35
    const v6, -0x1e2efa1b

    .line 36
    .line 37
    .line 38
    invoke-virtual {v14, v6}, LI/r;->U(I)V

    .line 39
    .line 40
    .line 41
    shl-int/lit8 v2, v2, 0x3

    .line 42
    .line 43
    and-int/lit16 v8, v2, 0x380

    .line 44
    .line 45
    move-object v2, v5

    .line 46
    iget-object v5, v0, LA1/o;->f:LU1/a;

    .line 47
    .line 48
    iget-object v6, v0, LA1/o;->g:LU1/a;

    .line 49
    .line 50
    move-object v7, v14

    .line 51
    invoke-static/range {v2 .. v8}, LX1/a;->a(LC1/a;ZLA1/d0;LU1/a;LU1/a;LI/r;I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v14, v1}, LI/r;->p(Z)V

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_0
    move-object v2, v5

    .line 59
    const v4, -0x1e2a8d65

    .line 60
    .line 61
    .line 62
    invoke-virtual {v14, v4}, LI/r;->U(I)V

    .line 63
    .line 64
    .line 65
    const/4 v15, 0x0

    .line 66
    iget-object v6, v0, LA1/o;->h:Ljava/lang/String;

    .line 67
    .line 68
    iget-boolean v7, v0, LA1/o;->i:Z

    .line 69
    .line 70
    iget-object v9, v0, LA1/o;->j:LU1/c;

    .line 71
    .line 72
    iget-object v10, v0, LA1/o;->k:LU1/c;

    .line 73
    .line 74
    iget-object v11, v0, LA1/o;->l:LU1/a;

    .line 75
    .line 76
    iget-object v12, v0, LA1/o;->m:LU1/a;

    .line 77
    .line 78
    iget-object v13, v0, LA1/o;->n:LU1/a;

    .line 79
    .line 80
    move v8, v3

    .line 81
    invoke-static/range {v5 .. v15}, LX1/a;->n(LC1/a;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;LI/r;I)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v14, v1}, LI/r;->p(Z)V

    .line 85
    .line 86
    .line 87
    :goto_0
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 88
    .line 89
    return-object v1
.end method
