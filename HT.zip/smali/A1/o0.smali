.class public final LA1/o0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final d:Landroid/graphics/Paint;

.field public final e:Landroid/graphics/Paint;

.field public final synthetic f:Lcom/htcheat/external/m;


# direct methods
.method public constructor <init>(Lcom/htcheat/external/m;Landroid/content/Context;)V
    .locals 3

    .line 1
    iput-object p1, p0, LA1/o0;->f:Lcom/htcheat/external/m;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Landroid/graphics/Paint;

    .line 7
    .line 8
    const/4 p2, 0x1

    .line 9
    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, LA1/o0;->d:Landroid/graphics/Paint;

    .line 13
    .line 14
    new-instance v0, Landroid/graphics/Paint;

    .line 15
    .line 16
    invoke-direct {v0, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, LA1/o0;->e:Landroid/graphics/Paint;

    .line 20
    .line 21
    const-wide v1, -0x204f3377dbfaL

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    const/4 v1, -0x1

    .line 30
    invoke-virtual {p1, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 34
    .line 35
    .line 36
    const v1, 0x3f8a3d71    # 1.08f

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, v1}, Landroid/graphics/Paint;->setTextScaleX(F)V

    .line 40
    .line 41
    .line 42
    const-wide v1, -0x20573377dbfaL

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-static {v1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 52
    .line 53
    .line 54
    move-result-object p2

    .line 55
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 56
    .line 57
    .line 58
    const p1, -0x2addd9d0

    .line 59
    .line 60
    .line 61
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 62
    .line 63
    .line 64
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;FFFF)V
    .locals 2

    .line 1
    new-instance v0, Landroid/graphics/RectF;

    .line 2
    .line 3
    add-float v1, p4, p5

    .line 4
    .line 5
    invoke-direct {v0, p2, p4, p3, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 6
    .line 7
    .line 8
    const/high16 p2, 0x3f000000    # 0.5f

    .line 9
    .line 10
    mul-float/2addr p5, p2

    .line 11
    iget-object p2, p0, LA1/o0;->e:Landroid/graphics/Paint;

    .line 12
    .line 13
    invoke-virtual {p1, v0, p5, p5, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 14

    .line 1
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 2
    .line 3
    .line 4
    const/high16 v1, 0x41b80000    # 23.0f

    .line 5
    .line 6
    iget-object v6, p0, LA1/o0;->f:Lcom/htcheat/external/m;

    .line 7
    .line 8
    invoke-virtual {v6, v1}, Lcom/htcheat/external/m;->d(F)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    int-to-float v7, v1

    .line 13
    iget-object v1, p0, LA1/o0;->d:Landroid/graphics/Paint;

    .line 14
    .line 15
    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 16
    .line 17
    .line 18
    const v2, 0x3fd9999a    # 1.7f

    .line 19
    .line 20
    .line 21
    invoke-virtual {v6, v2}, Lcom/htcheat/external/m;->d(F)I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    int-to-float v2, v2

    .line 26
    const/4 v3, 0x0

    .line 27
    const/4 v4, 0x0

    .line 28
    move v8, v3

    .line 29
    move v5, v4

    .line 30
    :goto_0
    const-wide v9, -0x20623377dbfaL

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    invoke-static {v9, v10}, LI1/a;->a(J)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v9

    .line 39
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 40
    .line 41
    .line 42
    move-result v9

    .line 43
    if-ge v5, v9, :cond_1

    .line 44
    .line 45
    const-wide v9, -0x206a3377dbfaL

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    invoke-static {v9, v10}, LI1/a;->a(J)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v9

    .line 54
    add-int/lit8 v10, v5, 0x1

    .line 55
    .line 56
    invoke-virtual {v1, v9, v5, v10}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;II)F

    .line 57
    .line 58
    .line 59
    move-result v9

    .line 60
    add-float/2addr v9, v8

    .line 61
    const-wide v11, -0x20723377dbfaL

    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    invoke-static {v11, v12}, LI1/a;->a(J)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 71
    .line 72
    .line 73
    move-result v8

    .line 74
    add-int/lit8 v8, v8, -0x1

    .line 75
    .line 76
    if-ge v5, v8, :cond_0

    .line 77
    .line 78
    add-float/2addr v9, v2

    .line 79
    :cond_0
    move v8, v9

    .line 80
    move v5, v10

    .line 81
    goto :goto_0

    .line 82
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 83
    .line 84
    .line 85
    move-result v5

    .line 86
    int-to-float v5, v5

    .line 87
    sub-float/2addr v5, v8

    .line 88
    const/high16 v9, 0x3f000000    # 0.5f

    .line 89
    .line 90
    mul-float/2addr v5, v9

    .line 91
    invoke-static {v3, v5}, Ljava/lang/Math;->max(FF)F

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    .line 96
    .line 97
    .line 98
    move-result-object v10

    .line 99
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 100
    .line 101
    .line 102
    move-result v11

    .line 103
    int-to-float v11, v11

    .line 104
    iget v12, v10, Landroid/graphics/Paint$FontMetrics;->ascent:F

    .line 105
    .line 106
    sub-float/2addr v11, v12

    .line 107
    iget v10, v10, Landroid/graphics/Paint$FontMetrics;->descent:F

    .line 108
    .line 109
    sub-float/2addr v11, v10

    .line 110
    mul-float/2addr v11, v9

    .line 111
    const/high16 v10, 0x3f800000    # 1.0f

    .line 112
    .line 113
    invoke-virtual {v6, v10}, Lcom/htcheat/external/m;->d(F)I

    .line 114
    .line 115
    .line 116
    move-result v10

    .line 117
    int-to-float v10, v10

    .line 118
    add-float/2addr v11, v10

    .line 119
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 120
    .line 121
    .line 122
    :goto_1
    const-wide v12, -0x207a3377dbfaL

    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    invoke-static {v12, v13}, LI1/a;->a(J)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v10

    .line 131
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 132
    .line 133
    .line 134
    move-result v10

    .line 135
    if-ge v4, v10, :cond_2

    .line 136
    .line 137
    const-wide v12, -0x21823377dbfaL

    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    invoke-static {v12, v13}, LI1/a;->a(J)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v10

    .line 146
    add-int/lit8 v12, v4, 0x1

    .line 147
    .line 148
    invoke-virtual {v10, v4, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v4

    .line 152
    invoke-virtual {p1, v4, v5, v11, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    .line 156
    .line 157
    .line 158
    move-result v4

    .line 159
    add-float/2addr v4, v2

    .line 160
    add-float/2addr v5, v4

    .line 161
    move v4, v12

    .line 162
    goto :goto_1

    .line 163
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    int-to-float v1, v1

    .line 168
    sub-float/2addr v1, v8

    .line 169
    mul-float/2addr v1, v9

    .line 170
    const/high16 v2, 0x40000000    # 2.0f

    .line 171
    .line 172
    invoke-virtual {v6, v2}, Lcom/htcheat/external/m;->d(F)I

    .line 173
    .line 174
    .line 175
    move-result v2

    .line 176
    int-to-float v2, v2

    .line 177
    sub-float/2addr v1, v2

    .line 178
    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    .line 179
    .line 180
    .line 181
    move-result v9

    .line 182
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 183
    .line 184
    .line 185
    move-result v1

    .line 186
    int-to-float v1, v1

    .line 187
    add-float/2addr v8, v9

    .line 188
    const/high16 v2, 0x40800000    # 4.0f

    .line 189
    .line 190
    invoke-virtual {v6, v2}, Lcom/htcheat/external/m;->d(F)I

    .line 191
    .line 192
    .line 193
    move-result v2

    .line 194
    int-to-float v2, v2

    .line 195
    add-float/2addr v8, v2

    .line 196
    invoke-static {v1, v8}, Ljava/lang/Math;->min(FF)F

    .line 197
    .line 198
    .line 199
    move-result v8

    .line 200
    const/high16 v1, 0x41000000    # 8.0f

    .line 201
    .line 202
    invoke-virtual {v6, v1}, Lcom/htcheat/external/m;->d(F)I

    .line 203
    .line 204
    .line 205
    move-result v1

    .line 206
    int-to-float v1, v1

    .line 207
    add-float v2, v9, v1

    .line 208
    .line 209
    const/high16 v1, 0x40c00000    # 6.0f

    .line 210
    .line 211
    invoke-virtual {v6, v1}, Lcom/htcheat/external/m;->d(F)I

    .line 212
    .line 213
    .line 214
    move-result v1

    .line 215
    int-to-float v1, v1

    .line 216
    sub-float v3, v8, v1

    .line 217
    .line 218
    const v1, 0x3eb33333    # 0.35f

    .line 219
    .line 220
    .line 221
    mul-float/2addr v1, v7

    .line 222
    sub-float v4, v11, v1

    .line 223
    .line 224
    const/high16 v12, 0x40400000    # 3.0f

    .line 225
    .line 226
    invoke-virtual {v6, v12}, Lcom/htcheat/external/m;->d(F)I

    .line 227
    .line 228
    .line 229
    move-result v1

    .line 230
    int-to-float v5, v1

    .line 231
    move-object v0, p0

    .line 232
    move-object v1, p1

    .line 233
    invoke-virtual/range {v0 .. v5}, LA1/o0;->a(Landroid/graphics/Canvas;FFFF)V

    .line 234
    .line 235
    .line 236
    const/high16 v0, 0x41900000    # 18.0f

    .line 237
    .line 238
    invoke-virtual {v6, v0}, Lcom/htcheat/external/m;->d(F)I

    .line 239
    .line 240
    .line 241
    move-result v0

    .line 242
    int-to-float v0, v0

    .line 243
    sub-float v3, v8, v0

    .line 244
    .line 245
    const v0, 0x3ca3d70a    # 0.02f

    .line 246
    .line 247
    .line 248
    mul-float/2addr v0, v7

    .line 249
    add-float v4, v0, v11

    .line 250
    .line 251
    invoke-virtual {v6, v12}, Lcom/htcheat/external/m;->d(F)I

    .line 252
    .line 253
    .line 254
    move-result v0

    .line 255
    int-to-float v5, v0

    .line 256
    move-object v0, p0

    .line 257
    move v2, v9

    .line 258
    invoke-virtual/range {v0 .. v5}, LA1/o0;->a(Landroid/graphics/Canvas;FFFF)V

    .line 259
    .line 260
    .line 261
    const/high16 v0, 0x41c00000    # 24.0f

    .line 262
    .line 263
    invoke-virtual {v6, v0}, Lcom/htcheat/external/m;->d(F)I

    .line 264
    .line 265
    .line 266
    move-result v0

    .line 267
    int-to-float v0, v0

    .line 268
    add-float/2addr v2, v0

    .line 269
    const v0, 0x3eb851ec    # 0.36f

    .line 270
    .line 271
    .line 272
    mul-float/2addr v7, v0

    .line 273
    add-float v4, v7, v11

    .line 274
    .line 275
    invoke-virtual {v6, v12}, Lcom/htcheat/external/m;->d(F)I

    .line 276
    .line 277
    .line 278
    move-result v0

    .line 279
    int-to-float v5, v0

    .line 280
    move-object v0, p0

    .line 281
    move v3, v8

    .line 282
    invoke-virtual/range {v0 .. v5}, LA1/o0;->a(Landroid/graphics/Canvas;FFFF)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 286
    .line 287
    .line 288
    return-void
.end method
