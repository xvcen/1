.class public final synthetic LA1/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z


# direct methods
.method public synthetic constructor <init>(IZ)V
    .locals 0

    .line 1
    iput p1, p0, LA1/p;->d:I

    iput-boolean p2, p0, LA1/p;->e:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LA1/p;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-boolean v0, p0, LA1/p;->e:Z

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :pswitch_0
    new-instance v0, LG1/a;

    .line 14
    .line 15
    iget-boolean v1, p0, LA1/p;->e:Z

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    const/16 v2, 0x8

    .line 20
    .line 21
    :goto_0
    int-to-float v2, v2

    .line 22
    goto :goto_1

    .line 23
    :cond_0
    const/4 v2, 0x4

    .line 24
    goto :goto_0

    .line 25
    :goto_1
    if-eqz v1, :cond_1

    .line 26
    .line 27
    const v1, 0x3eb33333    # 0.35f

    .line 28
    .line 29
    .line 30
    goto :goto_2

    .line 31
    :cond_1
    const v1, 0x3e4ccccd    # 0.2f

    .line 32
    .line 33
    .line 34
    :goto_2
    const/16 v3, 0x16

    .line 35
    .line 36
    invoke-direct {v0, v2, v1, v3}, LG1/a;-><init>(FFI)V

    .line 37
    .line 38
    .line 39
    return-object v0

    .line 40
    :pswitch_1
    new-instance v0, LG1/f;

    .line 41
    .line 42
    iget-boolean v1, p0, LA1/p;->e:Z

    .line 43
    .line 44
    if-eqz v1, :cond_2

    .line 45
    .line 46
    const/16 v2, 0xc

    .line 47
    .line 48
    :goto_3
    int-to-float v2, v2

    .line 49
    goto :goto_4

    .line 50
    :cond_2
    const/4 v2, 0x7

    .line 51
    goto :goto_3

    .line 52
    :goto_4
    sget-wide v3, Ld0/w;->b:J

    .line 53
    .line 54
    if-eqz v1, :cond_3

    .line 55
    .line 56
    const v1, 0x3e6147ae    # 0.22f

    .line 57
    .line 58
    .line 59
    goto :goto_5

    .line 60
    :cond_3
    const v1, 0x3df5c28f    # 0.12f

    .line 61
    .line 62
    .line 63
    :goto_5
    invoke-static {v3, v4, v1}, Ld0/w;->b(JF)J

    .line 64
    .line 65
    .line 66
    move-result-wide v3

    .line 67
    const/16 v1, 0x1a

    .line 68
    .line 69
    invoke-direct {v0, v2, v1, v3, v4}, LG1/f;-><init>(FIJ)V

    .line 70
    .line 71
    .line 72
    return-object v0

    .line 73
    :pswitch_2
    sget-object v0, LF1/a;->f:LF1/a;

    .line 74
    .line 75
    iget-boolean v1, p0, LA1/p;->e:Z

    .line 76
    .line 77
    if-eqz v1, :cond_4

    .line 78
    .line 79
    const v1, 0x3f051eb8    # 0.52f

    .line 80
    .line 81
    .line 82
    goto :goto_6

    .line 83
    :cond_4
    const v1, 0x3e8f5c29    # 0.28f

    .line 84
    .line 85
    .line 86
    :goto_6
    const/16 v2, 0xb

    .line 87
    .line 88
    const/4 v3, 0x0

    .line 89
    invoke-static {v0, v3, v3, v1, v2}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    return-object v0

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
