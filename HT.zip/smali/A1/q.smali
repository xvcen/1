.class public final synthetic LA1/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LB1/G;


# direct methods
.method public synthetic constructor <init>(LB1/G;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/q;->d:I

    iput-object p1, p0, LA1/q;->e:LB1/G;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LA1/q;->d:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p1

    .line 9
    .line 10
    check-cast v1, Lq0/u;

    .line 11
    .line 12
    const-wide v2, -0x34613377dbfaL

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v1, v0, LA1/q;->e:LB1/G;

    .line 25
    .line 26
    iget-object v2, v1, LB1/G;->a:Lc2/s;

    .line 27
    .line 28
    new-instance v3, LB1/B;

    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    invoke-direct {v3, v1, v4}, LB1/B;-><init>(LB1/G;LN1/c;)V

    .line 32
    .line 33
    .line 34
    const/4 v1, 0x3

    .line 35
    invoke-static {v2, v4, v3, v1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 36
    .line 37
    .line 38
    :goto_0
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 39
    .line 40
    return-object v1

    .line 41
    :pswitch_0
    move-object/from16 v1, p1

    .line 42
    .line 43
    check-cast v1, Lq0/u;

    .line 44
    .line 45
    const-wide v2, -0x345a3377dbfaL

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    iget-wide v1, v1, Lq0/u;->c:J

    .line 58
    .line 59
    iget-object v3, v0, LA1/q;->e:LB1/G;

    .line 60
    .line 61
    iput-wide v1, v3, LB1/G;->g:J

    .line 62
    .line 63
    iget-object v1, v3, LB1/G;->a:Lc2/s;

    .line 64
    .line 65
    new-instance v2, LB1/y;

    .line 66
    .line 67
    const/4 v4, 0x0

    .line 68
    invoke-direct {v2, v3, v4}, LB1/y;-><init>(LB1/G;LN1/c;)V

    .line 69
    .line 70
    .line 71
    const/4 v3, 0x3

    .line 72
    invoke-static {v1, v4, v2, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :pswitch_1
    move-object/from16 v2, p1

    .line 77
    .line 78
    check-cast v2, Lw0/G;

    .line 79
    .line 80
    const-wide v3, -0x36913377dbfaL

    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    invoke-static {v2, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    iget-object v1, v0, LA1/q;->e:LB1/G;

    .line 93
    .line 94
    iget-object v3, v1, LB1/G;->e:Ll/c;

    .line 95
    .line 96
    invoke-virtual {v3}, Ll/c;->c()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    check-cast v3, Ljava/lang/Number;

    .line 101
    .line 102
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 103
    .line 104
    .line 105
    move-result v9

    .line 106
    const/4 v10, 0x0

    .line 107
    cmpl-float v3, v9, v10

    .line 108
    .line 109
    if-lez v3, :cond_5

    .line 110
    .line 111
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 112
    .line 113
    const/16 v4, 0x21

    .line 114
    .line 115
    if-lt v3, v4, :cond_4

    .line 116
    .line 117
    iget-object v3, v1, LB1/G;->h:Landroid/graphics/RuntimeShader;

    .line 118
    .line 119
    if-eqz v3, :cond_4

    .line 120
    .line 121
    sget-wide v11, Ld0/w;->c:J

    .line 122
    .line 123
    const v3, 0x3da3d70a    # 0.08f

    .line 124
    .line 125
    .line 126
    mul-float/2addr v3, v9

    .line 127
    invoke-static {v11, v12, v3}, Ld0/w;->b(JF)J

    .line 128
    .line 129
    .line 130
    move-result-wide v3

    .line 131
    const/16 v7, 0xc

    .line 132
    .line 133
    const/16 v8, 0x3e

    .line 134
    .line 135
    const-wide/16 v5, 0x0

    .line 136
    .line 137
    invoke-static/range {v2 .. v8}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 138
    .line 139
    .line 140
    iget-object v3, v1, LB1/G;->h:Landroid/graphics/RuntimeShader;

    .line 141
    .line 142
    iget-object v4, v1, LB1/G;->b:LU1/e;

    .line 143
    .line 144
    iget-object v5, v2, Lw0/G;->d:Lf0/b;

    .line 145
    .line 146
    invoke-interface {v5}, Lf0/d;->a()J

    .line 147
    .line 148
    .line 149
    move-result-wide v6

    .line 150
    new-instance v8, Lc0/e;

    .line 151
    .line 152
    invoke-direct {v8, v6, v7}, Lc0/e;-><init>(J)V

    .line 153
    .line 154
    .line 155
    iget-object v6, v1, LB1/G;->f:Ll/c;

    .line 156
    .line 157
    invoke-virtual {v6}, Ll/c;->c()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v6

    .line 161
    invoke-interface {v4, v8, v6}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v4

    .line 165
    check-cast v4, Lc0/b;

    .line 166
    .line 167
    iget-wide v6, v4, Lc0/b;->a:J

    .line 168
    .line 169
    const-wide v13, -0x36af3377dbfaL

    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    invoke-static {v13, v14}, LI1/a;->a(J)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v4

    .line 178
    invoke-interface {v5}, Lf0/d;->a()J

    .line 179
    .line 180
    .line 181
    move-result-wide v13

    .line 182
    const/16 v8, 0x20

    .line 183
    .line 184
    shr-long/2addr v13, v8

    .line 185
    long-to-int v13, v13

    .line 186
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 187
    .line 188
    .line 189
    move-result v13

    .line 190
    invoke-interface {v5}, Lf0/d;->a()J

    .line 191
    .line 192
    .line 193
    move-result-wide v14

    .line 194
    const-wide v16, 0xffffffffL

    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    and-long v14, v14, v16

    .line 200
    .line 201
    long-to-int v14, v14

    .line 202
    invoke-static {v14}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 203
    .line 204
    .line 205
    move-result v14

    .line 206
    invoke-static {v3, v4, v13, v14}, LB1/v;->q(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 207
    .line 208
    .line 209
    const-wide v13, -0x36aa3377dbfaL

    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    invoke-static {v13, v14}, LI1/a;->a(J)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v4

    .line 218
    const v13, 0x3e19999a    # 0.15f

    .line 219
    .line 220
    .line 221
    mul-float/2addr v9, v13

    .line 222
    invoke-static {v11, v12, v9}, Ld0/w;->b(JF)J

    .line 223
    .line 224
    .line 225
    move-result-wide v11

    .line 226
    invoke-static {v11, v12}, Ld0/D;->w(J)I

    .line 227
    .line 228
    .line 229
    move-result v9

    .line 230
    invoke-static {v3, v4, v9}, LB1/v;->r(Landroid/graphics/RuntimeShader;Ljava/lang/String;I)V

    .line 231
    .line 232
    .line 233
    const-wide v11, -0x36b03377dbfaL

    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    invoke-static {v11, v12}, LI1/a;->a(J)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v4

    .line 242
    invoke-interface {v5}, Lf0/d;->a()J

    .line 243
    .line 244
    .line 245
    move-result-wide v11

    .line 246
    invoke-static {v11, v12}, Lc0/e;->b(J)F

    .line 247
    .line 248
    .line 249
    move-result v9

    .line 250
    const/high16 v11, 0x3fc00000    # 1.5f

    .line 251
    .line 252
    mul-float/2addr v9, v11

    .line 253
    invoke-static {v3, v4, v9}, LB1/v;->p(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 254
    .line 255
    .line 256
    const-wide v11, -0x36b93377dbfaL

    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    invoke-static {v11, v12}, LI1/a;->a(J)Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v4

    .line 265
    shr-long v11, v6, v8

    .line 266
    .line 267
    long-to-int v9, v11

    .line 268
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 269
    .line 270
    .line 271
    move-result v9

    .line 272
    invoke-interface {v5}, Lf0/d;->a()J

    .line 273
    .line 274
    .line 275
    move-result-wide v11

    .line 276
    shr-long/2addr v11, v8

    .line 277
    long-to-int v8, v11

    .line 278
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 279
    .line 280
    .line 281
    move-result v8

    .line 282
    cmpg-float v11, v9, v10

    .line 283
    .line 284
    if-gez v11, :cond_0

    .line 285
    .line 286
    move v9, v10

    .line 287
    :cond_0
    cmpl-float v11, v9, v8

    .line 288
    .line 289
    if-lez v11, :cond_1

    .line 290
    .line 291
    goto :goto_1

    .line 292
    :cond_1
    move v8, v9

    .line 293
    :goto_1
    and-long v6, v6, v16

    .line 294
    .line 295
    long-to-int v6, v6

    .line 296
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 297
    .line 298
    .line 299
    move-result v6

    .line 300
    invoke-interface {v5}, Lf0/d;->a()J

    .line 301
    .line 302
    .line 303
    move-result-wide v11

    .line 304
    and-long v11, v11, v16

    .line 305
    .line 306
    long-to-int v5, v11

    .line 307
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 308
    .line 309
    .line 310
    move-result v5

    .line 311
    cmpg-float v7, v6, v10

    .line 312
    .line 313
    if-gez v7, :cond_2

    .line 314
    .line 315
    move v6, v10

    .line 316
    :cond_2
    cmpl-float v7, v6, v5

    .line 317
    .line 318
    if-lez v7, :cond_3

    .line 319
    .line 320
    goto :goto_2

    .line 321
    :cond_3
    move v5, v6

    .line 322
    :goto_2
    invoke-static {v3, v4, v8, v5}, LB1/v;->q(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 323
    .line 324
    .line 325
    iget-object v1, v1, LB1/G;->h:Landroid/graphics/RuntimeShader;

    .line 326
    .line 327
    new-instance v3, Ld0/t;

    .line 328
    .line 329
    invoke-direct {v3, v1}, Ld0/t;-><init>(Landroid/graphics/Shader;)V

    .line 330
    .line 331
    .line 332
    const/16 v1, 0x3e

    .line 333
    .line 334
    invoke-static {v2, v3, v10, v1}, Lf0/d;->W(Lw0/G;Ld0/s;FI)V

    .line 335
    .line 336
    .line 337
    goto :goto_3

    .line 338
    :cond_4
    sget-wide v3, Ld0/w;->c:J

    .line 339
    .line 340
    const/high16 v1, 0x3e800000    # 0.25f

    .line 341
    .line 342
    mul-float/2addr v9, v1

    .line 343
    invoke-static {v3, v4, v9}, Ld0/w;->b(JF)J

    .line 344
    .line 345
    .line 346
    move-result-wide v3

    .line 347
    const/16 v7, 0xc

    .line 348
    .line 349
    const/16 v8, 0x3e

    .line 350
    .line 351
    const-wide/16 v5, 0x0

    .line 352
    .line 353
    invoke-static/range {v2 .. v8}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 354
    .line 355
    .line 356
    :cond_5
    :goto_3
    invoke-virtual {v2}, Lw0/G;->c()V

    .line 357
    .line 358
    .line 359
    goto/16 :goto_0

    .line 360
    .line 361
    :pswitch_2
    move-object/from16 v1, p1

    .line 362
    .line 363
    check-cast v1, Ld0/E;

    .line 364
    .line 365
    const-string v2, "$this$drawBackdrop"

    .line 366
    .line 367
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 368
    .line 369
    .line 370
    invoke-interface {v1}, Ld0/E;->a()J

    .line 371
    .line 372
    .line 373
    move-result-wide v2

    .line 374
    const/16 v4, 0x20

    .line 375
    .line 376
    shr-long/2addr v2, v4

    .line 377
    long-to-int v2, v2

    .line 378
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 379
    .line 380
    .line 381
    move-result v2

    .line 382
    invoke-interface {v1}, Ld0/E;->a()J

    .line 383
    .line 384
    .line 385
    move-result-wide v5

    .line 386
    const-wide v7, 0xffffffffL

    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    and-long/2addr v5, v7

    .line 392
    long-to-int v3, v5

    .line 393
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 394
    .line 395
    .line 396
    move-result v3

    .line 397
    iget-object v5, v0, LA1/q;->e:LB1/G;

    .line 398
    .line 399
    iget-object v6, v5, LB1/G;->e:Ll/c;

    .line 400
    .line 401
    invoke-virtual {v6}, Ll/c;->c()Ljava/lang/Object;

    .line 402
    .line 403
    .line 404
    move-result-object v6

    .line 405
    check-cast v6, Ljava/lang/Number;

    .line 406
    .line 407
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 408
    .line 409
    .line 410
    move-result v6

    .line 411
    const/4 v9, 0x4

    .line 412
    int-to-float v9, v9

    .line 413
    invoke-interface {v1}, LT0/c;->g()F

    .line 414
    .line 415
    .line 416
    move-result v10

    .line 417
    mul-float/2addr v10, v9

    .line 418
    invoke-interface {v1}, Ld0/E;->a()J

    .line 419
    .line 420
    .line 421
    move-result-wide v11

    .line 422
    and-long/2addr v11, v7

    .line 423
    long-to-int v11, v11

    .line 424
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 425
    .line 426
    .line 427
    move-result v11

    .line 428
    div-float/2addr v10, v11

    .line 429
    const/high16 v11, 0x3f800000    # 1.0f

    .line 430
    .line 431
    add-float/2addr v10, v11

    .line 432
    invoke-static {v11, v10, v6}, LT0/g;->C(FFF)F

    .line 433
    .line 434
    .line 435
    move-result v6

    .line 436
    invoke-interface {v1}, Ld0/E;->a()J

    .line 437
    .line 438
    .line 439
    move-result-wide v12

    .line 440
    invoke-static {v12, v13}, Lc0/e;->b(J)F

    .line 441
    .line 442
    .line 443
    move-result v10

    .line 444
    iget-object v12, v5, LB1/G;->f:Ll/c;

    .line 445
    .line 446
    invoke-virtual {v12}, Ll/c;->c()Ljava/lang/Object;

    .line 447
    .line 448
    .line 449
    move-result-object v12

    .line 450
    check-cast v12, Lc0/b;

    .line 451
    .line 452
    iget-wide v12, v12, Lc0/b;->a:J

    .line 453
    .line 454
    iget-wide v14, v5, LB1/G;->g:J

    .line 455
    .line 456
    invoke-static {v12, v13, v14, v15}, Lc0/b;->d(JJ)J

    .line 457
    .line 458
    .line 459
    move-result-wide v12

    .line 460
    shr-long v14, v12, v4

    .line 461
    .line 462
    long-to-int v5, v14

    .line 463
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 464
    .line 465
    .line 466
    move-result v14

    .line 467
    const v15, 0x3d4ccccd    # 0.05f

    .line 468
    .line 469
    .line 470
    mul-float/2addr v14, v15

    .line 471
    div-float/2addr v14, v10

    .line 472
    move/from16 p1, v4

    .line 473
    .line 474
    move/from16 v16, v5

    .line 475
    .line 476
    float-to-double v4, v14

    .line 477
    invoke-static {v4, v5}, Ljava/lang/Math;->tanh(D)D

    .line 478
    .line 479
    .line 480
    move-result-wide v4

    .line 481
    double-to-float v4, v4

    .line 482
    mul-float/2addr v4, v10

    .line 483
    invoke-interface {v1, v4}, Ld0/E;->p(F)V

    .line 484
    .line 485
    .line 486
    and-long v4, v12, v7

    .line 487
    .line 488
    long-to-int v4, v4

    .line 489
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 490
    .line 491
    .line 492
    move-result v5

    .line 493
    mul-float/2addr v5, v15

    .line 494
    div-float/2addr v5, v10

    .line 495
    float-to-double v12, v5

    .line 496
    invoke-static {v12, v13}, Ljava/lang/Math;->tanh(D)D

    .line 497
    .line 498
    .line 499
    move-result-wide v12

    .line 500
    double-to-float v5, v12

    .line 501
    mul-float/2addr v10, v5

    .line 502
    invoke-interface {v1, v10}, Ld0/E;->h(F)V

    .line 503
    .line 504
    .line 505
    invoke-interface {v1}, LT0/c;->g()F

    .line 506
    .line 507
    .line 508
    move-result v5

    .line 509
    mul-float/2addr v5, v9

    .line 510
    invoke-interface {v1}, Ld0/E;->a()J

    .line 511
    .line 512
    .line 513
    move-result-wide v9

    .line 514
    and-long/2addr v7, v9

    .line 515
    long-to-int v7, v7

    .line 516
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 517
    .line 518
    .line 519
    move-result v7

    .line 520
    div-float/2addr v5, v7

    .line 521
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 522
    .line 523
    .line 524
    move-result v7

    .line 525
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 526
    .line 527
    .line 528
    move-result v8

    .line 529
    float-to-double v9, v7

    .line 530
    float-to-double v7, v8

    .line 531
    invoke-static {v9, v10, v7, v8}, Ljava/lang/Math;->atan2(DD)D

    .line 532
    .line 533
    .line 534
    move-result-wide v7

    .line 535
    double-to-float v7, v7

    .line 536
    float-to-double v7, v7

    .line 537
    invoke-static {v7, v8}, Ljava/lang/Math;->cos(D)D

    .line 538
    .line 539
    .line 540
    move-result-wide v9

    .line 541
    double-to-float v9, v9

    .line 542
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 543
    .line 544
    .line 545
    move-result v10

    .line 546
    mul-float/2addr v10, v9

    .line 547
    invoke-interface {v1}, Ld0/E;->a()J

    .line 548
    .line 549
    .line 550
    move-result-wide v12

    .line 551
    shr-long v14, v12, p1

    .line 552
    .line 553
    const-wide/32 v16, 0x7fffffff

    .line 554
    .line 555
    .line 556
    and-long v14, v14, v16

    .line 557
    .line 558
    long-to-int v9, v14

    .line 559
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 560
    .line 561
    .line 562
    move-result v9

    .line 563
    and-long v12, v12, v16

    .line 564
    .line 565
    long-to-int v12, v12

    .line 566
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 567
    .line 568
    .line 569
    move-result v12

    .line 570
    invoke-static {v9, v12}, Ljava/lang/Math;->max(FF)F

    .line 571
    .line 572
    .line 573
    move-result v9

    .line 574
    div-float/2addr v10, v9

    .line 575
    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    .line 576
    .line 577
    .line 578
    move-result v9

    .line 579
    mul-float/2addr v9, v5

    .line 580
    div-float v10, v2, v3

    .line 581
    .line 582
    cmpl-float v12, v10, v11

    .line 583
    .line 584
    if-lez v12, :cond_6

    .line 585
    .line 586
    move v10, v11

    .line 587
    :cond_6
    mul-float/2addr v9, v10

    .line 588
    add-float/2addr v9, v6

    .line 589
    invoke-interface {v1, v9}, Ld0/E;->l(F)V

    .line 590
    .line 591
    .line 592
    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    .line 593
    .line 594
    .line 595
    move-result-wide v7

    .line 596
    double-to-float v7, v7

    .line 597
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 598
    .line 599
    .line 600
    move-result v4

    .line 601
    mul-float/2addr v4, v7

    .line 602
    invoke-interface {v1}, Ld0/E;->a()J

    .line 603
    .line 604
    .line 605
    move-result-wide v7

    .line 606
    shr-long v9, v7, p1

    .line 607
    .line 608
    and-long v9, v9, v16

    .line 609
    .line 610
    long-to-int v9, v9

    .line 611
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 612
    .line 613
    .line 614
    move-result v9

    .line 615
    and-long v7, v7, v16

    .line 616
    .line 617
    long-to-int v7, v7

    .line 618
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 619
    .line 620
    .line 621
    move-result v7

    .line 622
    invoke-static {v9, v7}, Ljava/lang/Math;->max(FF)F

    .line 623
    .line 624
    .line 625
    move-result v7

    .line 626
    div-float/2addr v4, v7

    .line 627
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 628
    .line 629
    .line 630
    move-result v4

    .line 631
    mul-float/2addr v4, v5

    .line 632
    div-float/2addr v3, v2

    .line 633
    cmpl-float v2, v3, v11

    .line 634
    .line 635
    if-lez v2, :cond_7

    .line 636
    .line 637
    goto :goto_4

    .line 638
    :cond_7
    move v11, v3

    .line 639
    :goto_4
    mul-float/2addr v4, v11

    .line 640
    add-float/2addr v4, v6

    .line 641
    invoke-interface {v1, v4}, Ld0/E;->r(F)V

    .line 642
    .line 643
    .line 644
    goto/16 :goto_0

    .line 645
    .line 646
    nop

    .line 647
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
