.class public final synthetic LA1/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:Z


# direct methods
.method public synthetic constructor <init>(Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, LA1/r;->d:Z

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Lf0/d;

    .line 3
    .line 4
    const-string p1, "$this$drawBackdrop"

    .line 5
    .line 6
    invoke-static {v0, p1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sget-wide v1, Ld0/w;->c:J

    .line 10
    .line 11
    iget-boolean p1, p0, LA1/r;->d:Z

    .line 12
    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    const v3, 0x3e4ccccd    # 0.2f

    .line 16
    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const v3, 0x3d99999a    # 0.075f

    .line 20
    .line 21
    .line 22
    :goto_0
    invoke-static {v1, v2, v3}, Ld0/w;->b(JF)J

    .line 23
    .line 24
    .line 25
    move-result-wide v1

    .line 26
    const/4 v5, 0x0

    .line 27
    const/16 v6, 0x7e

    .line 28
    .line 29
    const-wide/16 v3, 0x0

    .line 30
    .line 31
    invoke-static/range {v0 .. v6}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 32
    .line 33
    .line 34
    sget-wide v1, Ld0/w;->b:J

    .line 35
    .line 36
    if-eqz p1, :cond_1

    .line 37
    .line 38
    const p1, 0x3da3d70a    # 0.08f

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_1
    const p1, 0x3d23d70a    # 0.04f

    .line 43
    .line 44
    .line 45
    :goto_1
    invoke-static {v1, v2, p1}, Ld0/w;->b(JF)J

    .line 46
    .line 47
    .line 48
    move-result-wide v1

    .line 49
    const/4 v5, 0x0

    .line 50
    const/16 v6, 0x7e

    .line 51
    .line 52
    const-wide/16 v3, 0x0

    .line 53
    .line 54
    invoke-static/range {v0 .. v6}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 55
    .line 56
    .line 57
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 58
    .line 59
    return-object p1
.end method
