.class public final synthetic LA1/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LC1/a;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Z

.field public final synthetic g:Z

.field public final synthetic h:LU1/a;

.field public final synthetic i:I

.field public final synthetic j:I


# direct methods
.method public synthetic constructor <init>(LC1/a;Ljava/lang/String;ZZLU1/a;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/s;->d:LC1/a;

    iput-object p2, p0, LA1/s;->e:Ljava/lang/String;

    iput-boolean p3, p0, LA1/s;->f:Z

    iput-boolean p4, p0, LA1/s;->g:Z

    iput-object p5, p0, LA1/s;->h:LU1/a;

    iput p6, p0, LA1/s;->i:I

    iput p7, p0, LA1/s;->j:I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, LA1/s;->i:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, LI/k;->x(I)I

    .line 14
    .line 15
    .line 16
    move-result v6

    .line 17
    iget-object v0, p0, LA1/s;->d:LC1/a;

    .line 18
    .line 19
    iget-object v1, p0, LA1/s;->e:Ljava/lang/String;

    .line 20
    .line 21
    iget-boolean v2, p0, LA1/s;->f:Z

    .line 22
    .line 23
    iget-boolean v3, p0, LA1/s;->g:Z

    .line 24
    .line 25
    iget-object v4, p0, LA1/s;->h:LU1/a;

    .line 26
    .line 27
    iget v7, p0, LA1/s;->j:I

    .line 28
    .line 29
    invoke-static/range {v0 .. v7}, LX1/a;->f(LC1/a;Ljava/lang/String;ZZLU1/a;LI/r;II)V

    .line 30
    .line 31
    .line 32
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 33
    .line 34
    return-object p1
.end method
