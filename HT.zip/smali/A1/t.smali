.class public final synthetic LA1/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LI/b0;


# direct methods
.method public synthetic constructor <init>(LI/b0;I)V
    .locals 0

    .line 1
    iput p2, p0, LA1/t;->d:I

    iput-object p1, p0, LA1/t;->e:LI/b0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LA1/t;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/t;->e:LI/b0;

    .line 7
    .line 8
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 15
    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_0
    iget-object v0, p0, LA1/t;->e:LI/b0;

    .line 19
    .line 20
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lu0/r;

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    return-object v0

    .line 29
    :cond_0
    const-string v0, "Required value was null."

    .line 30
    .line 31
    invoke-static {v0}, Lr/b;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 32
    .line 33
    .line 34
    new-instance v0, LC0/e;

    .line 35
    .line 36
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 37
    .line 38
    .line 39
    throw v0

    .line 40
    :pswitch_1
    iget-object v0, p0, LA1/t;->e:LI/b0;

    .line 41
    .line 42
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Lu0/r;

    .line 47
    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    return-object v0

    .line 51
    :cond_1
    const-string v0, "Required value was null."

    .line 52
    .line 53
    invoke-static {v0}, Lr/b;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 54
    .line 55
    .line 56
    new-instance v0, LC0/e;

    .line 57
    .line 58
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 59
    .line 60
    .line 61
    throw v0

    .line 62
    :pswitch_2
    iget-object v0, p0, LA1/t;->e:LI/b0;

    .line 63
    .line 64
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    check-cast v0, Lu0/r;

    .line 69
    .line 70
    if-eqz v0, :cond_2

    .line 71
    .line 72
    return-object v0

    .line 73
    :cond_2
    const-string v0, "Required value was null."

    .line 74
    .line 75
    invoke-static {v0}, Lr/b;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 76
    .line 77
    .line 78
    new-instance v0, LC0/e;

    .line 79
    .line 80
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 81
    .line 82
    .line 83
    throw v0

    .line 84
    :pswitch_3
    iget-object v0, p0, LA1/t;->e:LI/b0;

    .line 85
    .line 86
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    check-cast v1, Ljava/lang/Boolean;

    .line 91
    .line 92
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    xor-int/lit8 v1, v1, 0x1

    .line 97
    .line 98
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-interface {v0, v1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 106
    .line 107
    return-object v0

    .line 108
    nop

    .line 109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
