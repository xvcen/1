.class public final synthetic LA1/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LA1/u;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LA1/u;->d:I

    .line 2
    .line 3
    const/high16 v1, 0x3e800000    # 0.25f

    .line 4
    .line 5
    const/4 v2, 0x5

    .line 6
    const/16 v3, 0x1a

    .line 7
    .line 8
    const/16 v4, 0xb

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    const/16 v6, 0x16

    .line 12
    .line 13
    const/4 v7, 0x0

    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    new-instance v0, Ln/e0;

    .line 18
    .line 19
    invoke-direct {v0}, Ln/e0;-><init>()V

    .line 20
    .line 21
    .line 22
    return-object v0

    .line 23
    :pswitch_0
    sget-object v0, Ln/S;->a:LI/B;

    .line 24
    .line 25
    sget-object v0, Ln/E;->a:Ln/E;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    new-instance v0, LU/w;

    .line 29
    .line 30
    new-instance v1, Ll/V;

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-direct {v1, v2}, Ll/V;-><init>(I)V

    .line 34
    .line 35
    .line 36
    invoke-direct {v0, v1}, LU/w;-><init>(LU1/c;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, LU/w;->d()V

    .line 40
    .line 41
    .line 42
    return-object v0

    .line 43
    :pswitch_2
    sget-object v0, LV/h;->a:LI/b1;

    .line 44
    .line 45
    return-object v7

    .line 46
    :pswitch_3
    sget-object v0, LV/f;->a:LI/b1;

    .line 47
    .line 48
    return-object v7

    .line 49
    :pswitch_4
    sget-object v0, LT/e;->a:LI/b1;

    .line 50
    .line 51
    return-object v7

    .line 52
    :pswitch_5
    sget-object v0, LR/b;->a:LI/b1;

    .line 53
    .line 54
    sget-object v0, LR/a;->a:LR/a;

    .line 55
    .line 56
    return-object v0

    .line 57
    :pswitch_6
    const-string v0, "Unexpected call to default provider"

    .line 58
    .line 59
    invoke-static {v0}, LI/t;->b(Ljava/lang/String;)Ljava/lang/Void;

    .line 60
    .line 61
    .line 62
    new-instance v0, LC0/e;

    .line 63
    .line 64
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 65
    .line 66
    .line 67
    throw v0

    .line 68
    :pswitch_7
    sget-object v0, LH/u0;->b:LH/t0;

    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_8
    sget-object v0, LH/V;->a:LI/B;

    .line 72
    .line 73
    return-object v7

    .line 74
    :pswitch_9
    sget-object v0, Lc2/B;->a:Lj2/e;

    .line 75
    .line 76
    sget-object v0, Lj2/d;->f:Lj2/d;

    .line 77
    .line 78
    return-object v0

    .line 79
    :pswitch_a
    sget-object v0, LD/g;->a:LI/B;

    .line 80
    .line 81
    return-object v7

    .line 82
    :pswitch_b
    sget-object v0, LG1/f;->f:LG1/f;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_c
    sget-object v0, LF1/a;->e:LF1/a;

    .line 86
    .line 87
    return-object v0

    .line 88
    :pswitch_d
    new-instance v0, LH1/a;

    .line 89
    .line 90
    invoke-direct {v0}, LH1/a;-><init>()V

    .line 91
    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_e
    new-instance v0, LG1/a;

    .line 95
    .line 96
    const/4 v1, 0x3

    .line 97
    int-to-float v1, v1

    .line 98
    const v2, 0x3e3851ec    # 0.18f

    .line 99
    .line 100
    .line 101
    invoke-direct {v0, v1, v2, v6}, LG1/a;-><init>(FFI)V

    .line 102
    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_f
    sget-object v0, LF1/a;->f:LF1/a;

    .line 106
    .line 107
    const v1, 0x3e75c28f    # 0.24f

    .line 108
    .line 109
    .line 110
    invoke-static {v0, v5, v5, v1, v4}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    return-object v0

    .line 115
    :pswitch_10
    new-instance v0, LH1/a;

    .line 116
    .line 117
    invoke-direct {v0}, LH1/a;-><init>()V

    .line 118
    .line 119
    .line 120
    return-object v0

    .line 121
    :pswitch_11
    new-instance v0, LH1/a;

    .line 122
    .line 123
    invoke-direct {v0}, LH1/a;-><init>()V

    .line 124
    .line 125
    .line 126
    return-object v0

    .line 127
    :pswitch_12
    new-instance v0, LG1/f;

    .line 128
    .line 129
    const/4 v1, 0x4

    .line 130
    int-to-float v1, v1

    .line 131
    sget-wide v4, Ld0/w;->b:J

    .line 132
    .line 133
    const v2, 0x3d4ccccd    # 0.05f

    .line 134
    .line 135
    .line 136
    invoke-static {v4, v5, v2}, Ld0/w;->b(JF)J

    .line 137
    .line 138
    .line 139
    move-result-wide v4

    .line 140
    invoke-direct {v0, v1, v3, v4, v5}, LG1/f;-><init>(FIJ)V

    .line 141
    .line 142
    .line 143
    return-object v0

    .line 144
    :pswitch_13
    new-instance v0, LG1/a;

    .line 145
    .line 146
    int-to-float v1, v2

    .line 147
    const v2, 0x3e4ccccd    # 0.2f

    .line 148
    .line 149
    .line 150
    invoke-direct {v0, v1, v2, v6}, LG1/a;-><init>(FFI)V

    .line 151
    .line 152
    .line 153
    return-object v0

    .line 154
    :pswitch_14
    sget-object v0, LF1/a;->f:LF1/a;

    .line 155
    .line 156
    invoke-static {v0, v5, v5, v1, v4}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    return-object v0

    .line 161
    :pswitch_15
    new-instance v0, LH1/a;

    .line 162
    .line 163
    invoke-direct {v0}, LH1/a;-><init>()V

    .line 164
    .line 165
    .line 166
    return-object v0

    .line 167
    :pswitch_16
    new-instance v0, LG1/a;

    .line 168
    .line 169
    int-to-float v2, v2

    .line 170
    invoke-direct {v0, v2, v1, v6}, LG1/a;-><init>(FFI)V

    .line 171
    .line 172
    .line 173
    return-object v0

    .line 174
    :pswitch_17
    sget-object v0, LF1/a;->f:LF1/a;

    .line 175
    .line 176
    const v1, 0x3eb851ec    # 0.36f

    .line 177
    .line 178
    .line 179
    invoke-static {v0, v5, v5, v1, v4}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    return-object v0

    .line 184
    :pswitch_18
    new-instance v0, LH1/a;

    .line 185
    .line 186
    invoke-direct {v0}, LH1/a;-><init>()V

    .line 187
    .line 188
    .line 189
    return-object v0

    .line 190
    :pswitch_19
    new-instance v0, LG1/a;

    .line 191
    .line 192
    const/16 v1, 0xc

    .line 193
    .line 194
    int-to-float v1, v1

    .line 195
    const v2, 0x3ee66666    # 0.45f

    .line 196
    .line 197
    .line 198
    invoke-direct {v0, v1, v2, v6}, LG1/a;-><init>(FFI)V

    .line 199
    .line 200
    .line 201
    return-object v0

    .line 202
    :pswitch_1a
    new-instance v0, LG1/f;

    .line 203
    .line 204
    int-to-float v1, v6

    .line 205
    sget-wide v4, Ld0/w;->b:J

    .line 206
    .line 207
    const v2, 0x3ea3d70a    # 0.32f

    .line 208
    .line 209
    .line 210
    invoke-static {v4, v5, v2}, Ld0/w;->b(JF)J

    .line 211
    .line 212
    .line 213
    move-result-wide v4

    .line 214
    invoke-direct {v0, v1, v3, v4, v5}, LG1/f;-><init>(FIJ)V

    .line 215
    .line 216
    .line 217
    return-object v0

    .line 218
    :pswitch_1b
    sget-object v0, LF1/a;->f:LF1/a;

    .line 219
    .line 220
    const v1, 0x3f266666    # 0.65f

    .line 221
    .line 222
    .line 223
    invoke-static {v0, v5, v5, v1, v4}, LF1/a;->a(LF1/a;FFFI)LF1/a;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    return-object v0

    .line 228
    :pswitch_1c
    new-instance v0, LH1/d;

    .line 229
    .line 230
    const/16 v1, 0x1c

    .line 231
    .line 232
    int-to-float v1, v1

    .line 233
    invoke-direct {v0, v1}, LH1/d;-><init>(F)V

    .line 234
    .line 235
    .line 236
    return-object v0

    .line 237
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
