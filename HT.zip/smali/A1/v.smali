.class public final synthetic LA1/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LA1/v;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, LA1/v;->d:I

    .line 6
    .line 7
    const v3, 0x3df5c28f    # 0.12f

    .line 8
    .line 9
    .line 10
    const/16 v4, 0x16

    .line 11
    .line 12
    const/4 v5, 0x7

    .line 13
    const v6, 0x3da3d70a    # 0.08f

    .line 14
    .line 15
    .line 16
    const/4 v9, 0x2

    .line 17
    const-string v10, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any>"

    .line 18
    .line 19
    const-string v11, "null cannot be cast to non-null type kotlin.Int"

    .line 20
    .line 21
    const-string v12, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>"

    .line 22
    .line 23
    const/16 v13, 0x20

    .line 24
    .line 25
    const/4 v14, 0x0

    .line 26
    const/4 v15, 0x0

    .line 27
    const-wide v16, 0xffffffffL

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    const-string v7, "$this$drawBackdrop"

    .line 33
    .line 34
    const/4 v8, 0x1

    .line 35
    sget-object v18, LJ1/m;->a:LJ1/m;

    .line 36
    .line 37
    packed-switch v2, :pswitch_data_0

    .line 38
    .line 39
    .line 40
    invoke-static {v1, v12}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    check-cast v1, Ljava/util/List;

    .line 44
    .line 45
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    if-eqz v2, :cond_0

    .line 50
    .line 51
    check-cast v2, Ljava/lang/String;

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_0
    move-object v2, v14

    .line 55
    :goto_0
    invoke-static {v2}, LV1/i;->b(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    sget-object v3, LH0/E;->i:LF/r;

    .line 63
    .line 64
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 65
    .line 66
    invoke-static {v1, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    if-eqz v4, :cond_1

    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_1
    if-eqz v1, :cond_2

    .line 74
    .line 75
    iget-object v3, v3, LF/r;->f:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v3, LU1/c;

    .line 78
    .line 79
    invoke-interface {v3, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    move-object v14, v1

    .line 84
    check-cast v14, LH0/M;

    .line 85
    .line 86
    :cond_2
    :goto_1
    new-instance v1, LH0/l;

    .line 87
    .line 88
    invoke-direct {v1, v2, v14}, LH0/l;-><init>(Ljava/lang/String;LH0/M;)V

    .line 89
    .line 90
    .line 91
    return-object v1

    .line 92
    :pswitch_0
    invoke-static {v1, v11}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    check-cast v1, Ljava/lang/Integer;

    .line 96
    .line 97
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    new-instance v2, LS0/k;

    .line 102
    .line 103
    invoke-direct {v2, v1}, LS0/k;-><init>(I)V

    .line 104
    .line 105
    .line 106
    return-object v2

    .line 107
    :pswitch_1
    invoke-static {v1, v10}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    check-cast v1, Ljava/util/List;

    .line 111
    .line 112
    new-instance v2, Ld0/S;

    .line 113
    .line 114
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    sget v4, Ld0/w;->h:I

    .line 119
    .line 120
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 121
    .line 122
    invoke-static {v3, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    if-eqz v3, :cond_4

    .line 126
    .line 127
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 128
    .line 129
    invoke-static {v3, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v5

    .line 133
    if-eqz v5, :cond_3

    .line 134
    .line 135
    sget-wide v5, Ld0/w;->g:J

    .line 136
    .line 137
    new-instance v3, Ld0/w;

    .line 138
    .line 139
    invoke-direct {v3, v5, v6}, Ld0/w;-><init>(J)V

    .line 140
    .line 141
    .line 142
    goto :goto_2

    .line 143
    :cond_3
    check-cast v3, Ljava/lang/Integer;

    .line 144
    .line 145
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 146
    .line 147
    .line 148
    move-result v3

    .line 149
    invoke-static {v3}, Ld0/D;->b(I)J

    .line 150
    .line 151
    .line 152
    move-result-wide v5

    .line 153
    new-instance v3, Ld0/w;

    .line 154
    .line 155
    invoke-direct {v3, v5, v6}, Ld0/w;-><init>(J)V

    .line 156
    .line 157
    .line 158
    goto :goto_2

    .line 159
    :cond_4
    move-object v3, v14

    .line 160
    :goto_2
    invoke-static {v3}, LV1/i;->b(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    iget-wide v5, v3, Ld0/w;->a:J

    .line 164
    .line 165
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    sget-object v7, LH0/E;->x:LH0/D;

    .line 170
    .line 171
    invoke-static {v3, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    if-eqz v3, :cond_5

    .line 175
    .line 176
    iget-object v4, v7, LH0/D;->e:LU1/c;

    .line 177
    .line 178
    invoke-interface {v4, v3}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    check-cast v3, Lc0/b;

    .line 183
    .line 184
    goto :goto_3

    .line 185
    :cond_5
    move-object v3, v14

    .line 186
    :goto_3
    invoke-static {v3}, LV1/i;->b(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    iget-wide v3, v3, Lc0/b;->a:J

    .line 190
    .line 191
    invoke-interface {v1, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    if-eqz v1, :cond_6

    .line 196
    .line 197
    move-object v14, v1

    .line 198
    check-cast v14, Ljava/lang/Float;

    .line 199
    .line 200
    :cond_6
    invoke-static {v14}, LV1/i;->b(Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v14}, Ljava/lang/Number;->floatValue()F

    .line 204
    .line 205
    .line 206
    move-result v7

    .line 207
    move-wide/from16 v27, v5

    .line 208
    .line 209
    move-wide v5, v3

    .line 210
    move-wide/from16 v3, v27

    .line 211
    .line 212
    invoke-direct/range {v2 .. v7}, Ld0/S;-><init>(JJF)V

    .line 213
    .line 214
    .line 215
    return-object v2

    .line 216
    :pswitch_2
    invoke-static {v1, v10}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    check-cast v1, Ljava/util/List;

    .line 220
    .line 221
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    if-eqz v2, :cond_7

    .line 226
    .line 227
    check-cast v2, Ljava/lang/Integer;

    .line 228
    .line 229
    goto :goto_4

    .line 230
    :cond_7
    move-object v2, v14

    .line 231
    :goto_4
    invoke-static {v2}, LV1/i;->b(Ljava/lang/Object;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 235
    .line 236
    .line 237
    move-result v2

    .line 238
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    if-eqz v1, :cond_8

    .line 243
    .line 244
    move-object v14, v1

    .line 245
    check-cast v14, Ljava/lang/Integer;

    .line 246
    .line 247
    :cond_8
    invoke-static {v14}, LV1/i;->b(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    invoke-static {v2, v1}, LH0/F;->b(II)J

    .line 255
    .line 256
    .line 257
    move-result-wide v1

    .line 258
    new-instance v3, LH0/N;

    .line 259
    .line 260
    invoke-direct {v3, v1, v2}, LH0/N;-><init>(J)V

    .line 261
    .line 262
    .line 263
    return-object v3

    .line 264
    :pswitch_3
    const-string v2, "null cannot be cast to non-null type kotlin.Float"

    .line 265
    .line 266
    invoke-static {v1, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    check-cast v1, Ljava/lang/Float;

    .line 270
    .line 271
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 272
    .line 273
    .line 274
    move-result v1

    .line 275
    new-instance v2, LS0/a;

    .line 276
    .line 277
    invoke-direct {v2, v1}, LS0/a;-><init>(F)V

    .line 278
    .line 279
    .line 280
    return-object v2

    .line 281
    :pswitch_4
    new-instance v2, LL0/k;

    .line 282
    .line 283
    invoke-static {v1, v11}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    check-cast v1, Ljava/lang/Integer;

    .line 287
    .line 288
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 289
    .line 290
    .line 291
    move-result v1

    .line 292
    invoke-direct {v2, v1}, LL0/k;-><init>(I)V

    .line 293
    .line 294
    .line 295
    return-object v2

    .line 296
    :pswitch_5
    invoke-static {v1, v10}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    check-cast v1, Ljava/util/List;

    .line 300
    .line 301
    new-instance v2, LS0/q;

    .line 302
    .line 303
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v3

    .line 307
    sget-object v4, LT0/q;->b:[LT0/r;

    .line 308
    .line 309
    sget-object v4, LH0/E;->v:LH0/D;

    .line 310
    .line 311
    iget-object v4, v4, LH0/D;->e:LU1/c;

    .line 312
    .line 313
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 314
    .line 315
    invoke-static {v3, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    if-eqz v3, :cond_9

    .line 319
    .line 320
    invoke-interface {v4, v3}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v3

    .line 324
    check-cast v3, LT0/q;

    .line 325
    .line 326
    goto :goto_5

    .line 327
    :cond_9
    move-object v3, v14

    .line 328
    :goto_5
    invoke-static {v3}, LV1/i;->b(Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    iget-wide v6, v3, LT0/q;->a:J

    .line 332
    .line 333
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 334
    .line 335
    .line 336
    move-result-object v1

    .line 337
    invoke-static {v1, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 338
    .line 339
    .line 340
    if-eqz v1, :cond_a

    .line 341
    .line 342
    invoke-interface {v4, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    move-object v14, v1

    .line 347
    check-cast v14, LT0/q;

    .line 348
    .line 349
    :cond_a
    invoke-static {v14}, LV1/i;->b(Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    iget-wide v3, v14, LT0/q;->a:J

    .line 353
    .line 354
    invoke-direct {v2, v6, v7, v3, v4}, LS0/q;-><init>(JJ)V

    .line 355
    .line 356
    .line 357
    return-object v2

    .line 358
    :pswitch_6
    const-string v2, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Float>"

    .line 359
    .line 360
    invoke-static {v1, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    check-cast v1, Ljava/util/List;

    .line 364
    .line 365
    new-instance v2, LS0/p;

    .line 366
    .line 367
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v3

    .line 371
    check-cast v3, Ljava/lang/Number;

    .line 372
    .line 373
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 374
    .line 375
    .line 376
    move-result v3

    .line 377
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    check-cast v1, Ljava/lang/Number;

    .line 382
    .line 383
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 384
    .line 385
    .line 386
    move-result v1

    .line 387
    invoke-direct {v2, v3, v1}, LS0/p;-><init>(FF)V

    .line 388
    .line 389
    .line 390
    return-object v2

    .line 391
    :pswitch_7
    new-instance v2, LS0/l;

    .line 392
    .line 393
    invoke-static {v1, v11}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 394
    .line 395
    .line 396
    check-cast v1, Ljava/lang/Integer;

    .line 397
    .line 398
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 399
    .line 400
    .line 401
    move-result v1

    .line 402
    invoke-direct {v2, v1}, LS0/l;-><init>(I)V

    .line 403
    .line 404
    .line 405
    return-object v2

    .line 406
    :pswitch_8
    invoke-static {v1, v12}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    .line 408
    .line 409
    check-cast v1, Ljava/util/List;

    .line 410
    .line 411
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    move-result-object v2

    .line 415
    sget-object v3, LH0/E;->a:LF/r;

    .line 416
    .line 417
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 418
    .line 419
    invoke-static {v2, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 420
    .line 421
    .line 422
    move-result v4

    .line 423
    if-eqz v4, :cond_c

    .line 424
    .line 425
    :cond_b
    move-object v2, v14

    .line 426
    goto :goto_6

    .line 427
    :cond_c
    if-eqz v2, :cond_b

    .line 428
    .line 429
    iget-object v3, v3, LF/r;->f:Ljava/lang/Object;

    .line 430
    .line 431
    check-cast v3, LU1/c;

    .line 432
    .line 433
    invoke-interface {v3, v2}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object v2

    .line 437
    check-cast v2, Ljava/util/List;

    .line 438
    .line 439
    :goto_6
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 440
    .line 441
    .line 442
    move-result-object v1

    .line 443
    if-eqz v1, :cond_d

    .line 444
    .line 445
    move-object v14, v1

    .line 446
    check-cast v14, Ljava/lang/String;

    .line 447
    .line 448
    :cond_d
    invoke-static {v14}, LV1/i;->b(Ljava/lang/Object;)V

    .line 449
    .line 450
    .line 451
    new-instance v1, LH0/g;

    .line 452
    .line 453
    invoke-direct {v1, v2, v14}, LH0/g;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    return-object v1

    .line 457
    :pswitch_9
    invoke-static {v1, v12}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 458
    .line 459
    .line 460
    check-cast v1, Ljava/util/List;

    .line 461
    .line 462
    invoke-interface {v1, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 463
    .line 464
    .line 465
    move-result-object v2

    .line 466
    sget-object v3, LH0/E;->h:LF/r;

    .line 467
    .line 468
    iget-object v3, v3, LF/r;->f:Ljava/lang/Object;

    .line 469
    .line 470
    check-cast v3, LU1/c;

    .line 471
    .line 472
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 473
    .line 474
    invoke-static {v2, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 475
    .line 476
    .line 477
    move-result v5

    .line 478
    if-eqz v5, :cond_f

    .line 479
    .line 480
    :cond_e
    move-object v2, v14

    .line 481
    goto :goto_7

    .line 482
    :cond_f
    if-eqz v2, :cond_e

    .line 483
    .line 484
    invoke-interface {v3, v2}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 485
    .line 486
    .line 487
    move-result-object v2

    .line 488
    check-cast v2, LH0/G;

    .line 489
    .line 490
    :goto_7
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v5

    .line 494
    invoke-static {v5, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 495
    .line 496
    .line 497
    move-result v6

    .line 498
    if-eqz v6, :cond_11

    .line 499
    .line 500
    :cond_10
    move-object v5, v14

    .line 501
    goto :goto_8

    .line 502
    :cond_11
    if-eqz v5, :cond_10

    .line 503
    .line 504
    invoke-interface {v3, v5}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    move-result-object v5

    .line 508
    check-cast v5, LH0/G;

    .line 509
    .line 510
    :goto_8
    invoke-interface {v1, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 511
    .line 512
    .line 513
    move-result-object v6

    .line 514
    invoke-static {v6, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 515
    .line 516
    .line 517
    move-result v7

    .line 518
    if-eqz v7, :cond_13

    .line 519
    .line 520
    :cond_12
    move-object v6, v14

    .line 521
    goto :goto_9

    .line 522
    :cond_13
    if-eqz v6, :cond_12

    .line 523
    .line 524
    invoke-interface {v3, v6}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v6

    .line 528
    check-cast v6, LH0/G;

    .line 529
    .line 530
    :goto_9
    const/4 v7, 0x3

    .line 531
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 532
    .line 533
    .line 534
    move-result-object v1

    .line 535
    invoke-static {v1, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 536
    .line 537
    .line 538
    move-result v4

    .line 539
    if-eqz v4, :cond_14

    .line 540
    .line 541
    goto :goto_a

    .line 542
    :cond_14
    if-eqz v1, :cond_15

    .line 543
    .line 544
    invoke-interface {v3, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 545
    .line 546
    .line 547
    move-result-object v1

    .line 548
    move-object v14, v1

    .line 549
    check-cast v14, LH0/G;

    .line 550
    .line 551
    :cond_15
    :goto_a
    new-instance v1, LH0/M;

    .line 552
    .line 553
    invoke-direct {v1, v2, v5, v6, v14}, LH0/M;-><init>(LH0/G;LH0/G;LH0/G;LH0/G;)V

    .line 554
    .line 555
    .line 556
    return-object v1

    .line 557
    :pswitch_a
    check-cast v1, LH0/s;

    .line 558
    .line 559
    new-instance v2, Ljava/lang/StringBuilder;

    .line 560
    .line 561
    const-string v3, "["

    .line 562
    .line 563
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 564
    .line 565
    .line 566
    iget v3, v1, LH0/s;->b:I

    .line 567
    .line 568
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    const-string v3, ", "

    .line 572
    .line 573
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 574
    .line 575
    .line 576
    iget v1, v1, LH0/s;->c:I

    .line 577
    .line 578
    const/16 v3, 0x29

    .line 579
    .line 580
    invoke-static {v2, v1, v3}, LM0/m;->h(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    .line 581
    .line 582
    .line 583
    move-result-object v1

    .line 584
    return-object v1

    .line 585
    :pswitch_b
    check-cast v1, LH0/b;

    .line 586
    .line 587
    instance-of v1, v1, LH0/v;

    .line 588
    .line 589
    xor-int/2addr v1, v8

    .line 590
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 591
    .line 592
    .line 593
    move-result-object v1

    .line 594
    return-object v1

    .line 595
    :pswitch_c
    check-cast v1, Ll/k;

    .line 596
    .line 597
    iget v2, v1, Ll/k;->a:F

    .line 598
    .line 599
    iget v1, v1, Ll/k;->b:F

    .line 600
    .line 601
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 602
    .line 603
    .line 604
    move-result v2

    .line 605
    int-to-long v2, v2

    .line 606
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 607
    .line 608
    .line 609
    move-result v1

    .line 610
    int-to-long v4, v1

    .line 611
    shl-long v1, v2, v13

    .line 612
    .line 613
    and-long v3, v4, v16

    .line 614
    .line 615
    or-long/2addr v1, v3

    .line 616
    new-instance v3, Lc0/b;

    .line 617
    .line 618
    invoke-direct {v3, v1, v2}, Lc0/b;-><init>(J)V

    .line 619
    .line 620
    .line 621
    return-object v3

    .line 622
    :pswitch_d
    check-cast v1, Lc0/b;

    .line 623
    .line 624
    iget-wide v2, v1, Lc0/b;->a:J

    .line 625
    .line 626
    const-wide v4, 0x7fffffff7fffffffL

    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    and-long/2addr v4, v2

    .line 632
    const-wide v6, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    cmp-long v4, v4, v6

    .line 638
    .line 639
    if-eqz v4, :cond_16

    .line 640
    .line 641
    new-instance v4, Ll/k;

    .line 642
    .line 643
    shr-long/2addr v2, v13

    .line 644
    long-to-int v2, v2

    .line 645
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 646
    .line 647
    .line 648
    move-result v2

    .line 649
    iget-wide v5, v1, Lc0/b;->a:J

    .line 650
    .line 651
    and-long v5, v5, v16

    .line 652
    .line 653
    long-to-int v1, v5

    .line 654
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 655
    .line 656
    .line 657
    move-result v1

    .line 658
    invoke-direct {v4, v2, v1}, Ll/k;-><init>(FF)V

    .line 659
    .line 660
    .line 661
    goto :goto_b

    .line 662
    :cond_16
    sget-object v4, LH/U;->a:Ll/k;

    .line 663
    .line 664
    :goto_b
    return-object v4

    .line 665
    :pswitch_e
    check-cast v1, LM0/j;

    .line 666
    .line 667
    return-object v18

    .line 668
    :pswitch_f
    check-cast v1, Ljava/util/List;

    .line 669
    .line 670
    return-object v18

    .line 671
    :pswitch_10
    check-cast v1, Lw0/G;

    .line 672
    .line 673
    const-string v2, "<this>"

    .line 674
    .line 675
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 676
    .line 677
    .line 678
    invoke-virtual {v1}, Lw0/G;->c()V

    .line 679
    .line 680
    .line 681
    return-object v18

    .line 682
    :pswitch_11
    check-cast v1, LC1/f;

    .line 683
    .line 684
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 685
    .line 686
    .line 687
    invoke-static {v1}, LE1/a;->a(LC1/f;)V

    .line 688
    .line 689
    .line 690
    int-to-float v2, v5

    .line 691
    iget v3, v1, LC1/f;->d:F

    .line 692
    .line 693
    mul-float/2addr v3, v2

    .line 694
    invoke-static {v1, v3}, LX1/a;->D(LC1/f;F)V

    .line 695
    .line 696
    .line 697
    int-to-float v2, v4

    .line 698
    iget v3, v1, LC1/f;->d:F

    .line 699
    .line 700
    mul-float/2addr v2, v3

    .line 701
    const/16 v4, 0x2a

    .line 702
    .line 703
    int-to-float v4, v4

    .line 704
    mul-float/2addr v3, v4

    .line 705
    invoke-static {v1, v2, v3, v8}, La/a;->D(LC1/f;FFZ)V

    .line 706
    .line 707
    .line 708
    return-object v18

    .line 709
    :pswitch_12
    move-object v9, v1

    .line 710
    check-cast v9, Lf0/d;

    .line 711
    .line 712
    invoke-static {v9, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 713
    .line 714
    .line 715
    sget-wide v1, Ld0/w;->c:J

    .line 716
    .line 717
    invoke-static {v1, v2, v6}, Ld0/w;->b(JF)J

    .line 718
    .line 719
    .line 720
    move-result-wide v10

    .line 721
    const/4 v14, 0x0

    .line 722
    const/16 v15, 0x7e

    .line 723
    .line 724
    const-wide/16 v12, 0x0

    .line 725
    .line 726
    invoke-static/range {v9 .. v15}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 727
    .line 728
    .line 729
    return-object v18

    .line 730
    :pswitch_13
    check-cast v1, LC1/f;

    .line 731
    .line 732
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 733
    .line 734
    .line 735
    invoke-static {v1}, LE1/a;->a(LC1/f;)V

    .line 736
    .line 737
    .line 738
    const/4 v2, 0x4

    .line 739
    int-to-float v2, v2

    .line 740
    iget v3, v1, LC1/f;->d:F

    .line 741
    .line 742
    mul-float/2addr v3, v2

    .line 743
    invoke-static {v1, v3}, LX1/a;->D(LC1/f;F)V

    .line 744
    .line 745
    .line 746
    const/16 v2, 0xb

    .line 747
    .line 748
    int-to-float v2, v2

    .line 749
    iget v3, v1, LC1/f;->d:F

    .line 750
    .line 751
    mul-float/2addr v2, v3

    .line 752
    int-to-float v4, v4

    .line 753
    mul-float/2addr v3, v4

    .line 754
    invoke-static {v1, v2, v3, v15}, La/a;->D(LC1/f;FFZ)V

    .line 755
    .line 756
    .line 757
    return-object v18

    .line 758
    :pswitch_14
    check-cast v1, LE0/v;

    .line 759
    .line 760
    const-string v2, "$this$semantics"

    .line 761
    .line 762
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 763
    .line 764
    .line 765
    invoke-static {v1, v9}, LE0/t;->b(LE0/v;I)V

    .line 766
    .line 767
    .line 768
    return-object v18

    .line 769
    :pswitch_15
    check-cast v1, Lf0/d;

    .line 770
    .line 771
    const-string v2, "$this$Canvas"

    .line 772
    .line 773
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 774
    .line 775
    .line 776
    sget-wide v4, Ld0/w;->c:J

    .line 777
    .line 778
    const v2, 0x3d6147ae    # 0.055f

    .line 779
    .line 780
    .line 781
    invoke-static {v4, v5, v2}, Ld0/w;->b(JF)J

    .line 782
    .line 783
    .line 784
    move-result-wide v20

    .line 785
    const/16 v2, 0x48

    .line 786
    .line 787
    int-to-float v2, v2

    .line 788
    invoke-interface {v1, v2}, LT0/c;->K(F)F

    .line 789
    .line 790
    .line 791
    move-result v2

    .line 792
    neg-float v4, v2

    .line 793
    :goto_c
    invoke-interface {v1}, Lf0/d;->a()J

    .line 794
    .line 795
    .line 796
    move-result-wide v5

    .line 797
    shr-long/2addr v5, v13

    .line 798
    long-to-int v5, v5

    .line 799
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 800
    .line 801
    .line 802
    move-result v5

    .line 803
    add-float/2addr v5, v2

    .line 804
    cmpg-float v5, v4, v5

    .line 805
    .line 806
    const/4 v6, 0x0

    .line 807
    if-gez v5, :cond_17

    .line 808
    .line 809
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 810
    .line 811
    .line 812
    move-result v5

    .line 813
    int-to-long v9, v5

    .line 814
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 815
    .line 816
    .line 817
    move-result v5

    .line 818
    int-to-long v5, v5

    .line 819
    shl-long/2addr v9, v13

    .line 820
    and-long v5, v5, v16

    .line 821
    .line 822
    or-long v22, v9, v5

    .line 823
    .line 824
    invoke-interface {v1}, Lf0/d;->a()J

    .line 825
    .line 826
    .line 827
    move-result-wide v5

    .line 828
    and-long v5, v5, v16

    .line 829
    .line 830
    long-to-int v5, v5

    .line 831
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 832
    .line 833
    .line 834
    move-result v5

    .line 835
    const v6, 0x3eb851ec    # 0.36f

    .line 836
    .line 837
    .line 838
    mul-float/2addr v5, v6

    .line 839
    add-float/2addr v5, v4

    .line 840
    invoke-interface {v1}, Lf0/d;->a()J

    .line 841
    .line 842
    .line 843
    move-result-wide v6

    .line 844
    and-long v6, v6, v16

    .line 845
    .line 846
    long-to-int v6, v6

    .line 847
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 848
    .line 849
    .line 850
    move-result v6

    .line 851
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 852
    .line 853
    .line 854
    move-result v5

    .line 855
    int-to-long v9, v5

    .line 856
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 857
    .line 858
    .line 859
    move-result v5

    .line 860
    int-to-long v5, v5

    .line 861
    shl-long/2addr v9, v13

    .line 862
    and-long v5, v5, v16

    .line 863
    .line 864
    or-long v24, v9, v5

    .line 865
    .line 866
    int-to-float v5, v8

    .line 867
    invoke-interface {v1, v5}, LT0/c;->K(F)F

    .line 868
    .line 869
    .line 870
    move-result v26

    .line 871
    move-object/from16 v19, v1

    .line 872
    .line 873
    invoke-interface/range {v19 .. v26}, Lf0/d;->n0(JJJF)V

    .line 874
    .line 875
    .line 876
    add-float/2addr v4, v2

    .line 877
    goto :goto_c

    .line 878
    :cond_17
    move v4, v6

    .line 879
    :goto_d
    invoke-interface {v1}, Lf0/d;->a()J

    .line 880
    .line 881
    .line 882
    move-result-wide v9

    .line 883
    and-long v9, v9, v16

    .line 884
    .line 885
    long-to-int v5, v9

    .line 886
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 887
    .line 888
    .line 889
    move-result v5

    .line 890
    cmpg-float v5, v4, v5

    .line 891
    .line 892
    if-gez v5, :cond_18

    .line 893
    .line 894
    sget-wide v9, Ld0/w;->c:J

    .line 895
    .line 896
    const v5, 0x3d0f5c29    # 0.035f

    .line 897
    .line 898
    .line 899
    invoke-static {v9, v10, v5}, Ld0/w;->b(JF)J

    .line 900
    .line 901
    .line 902
    move-result-wide v20

    .line 903
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 904
    .line 905
    .line 906
    move-result v5

    .line 907
    int-to-long v9, v5

    .line 908
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 909
    .line 910
    .line 911
    move-result v5

    .line 912
    int-to-long v11, v5

    .line 913
    shl-long/2addr v9, v13

    .line 914
    and-long v11, v11, v16

    .line 915
    .line 916
    or-long v22, v9, v11

    .line 917
    .line 918
    invoke-interface {v1}, Lf0/d;->a()J

    .line 919
    .line 920
    .line 921
    move-result-wide v9

    .line 922
    shr-long/2addr v9, v13

    .line 923
    long-to-int v5, v9

    .line 924
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 925
    .line 926
    .line 927
    move-result v5

    .line 928
    invoke-interface {v1}, Lf0/d;->a()J

    .line 929
    .line 930
    .line 931
    move-result-wide v9

    .line 932
    shr-long/2addr v9, v13

    .line 933
    long-to-int v7, v9

    .line 934
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 935
    .line 936
    .line 937
    move-result v7

    .line 938
    mul-float/2addr v7, v3

    .line 939
    add-float/2addr v7, v4

    .line 940
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 941
    .line 942
    .line 943
    move-result v5

    .line 944
    int-to-long v9, v5

    .line 945
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 946
    .line 947
    .line 948
    move-result v5

    .line 949
    int-to-long v11, v5

    .line 950
    shl-long/2addr v9, v13

    .line 951
    and-long v11, v11, v16

    .line 952
    .line 953
    or-long v24, v9, v11

    .line 954
    .line 955
    int-to-float v5, v8

    .line 956
    invoke-interface {v1, v5}, LT0/c;->K(F)F

    .line 957
    .line 958
    .line 959
    move-result v26

    .line 960
    move-object/from16 v19, v1

    .line 961
    .line 962
    invoke-interface/range {v19 .. v26}, Lf0/d;->n0(JJJF)V

    .line 963
    .line 964
    .line 965
    const v5, 0x3fb9999a    # 1.45f

    .line 966
    .line 967
    .line 968
    mul-float/2addr v5, v2

    .line 969
    add-float/2addr v4, v5

    .line 970
    goto :goto_d

    .line 971
    :cond_18
    sget-wide v2, Ld0/w;->c:J

    .line 972
    .line 973
    const v4, 0x3e6147ae    # 0.22f

    .line 974
    .line 975
    .line 976
    invoke-static {v2, v3, v4}, Ld0/w;->b(JF)J

    .line 977
    .line 978
    .line 979
    move-result-wide v4

    .line 980
    new-instance v6, Ld0/w;

    .line 981
    .line 982
    invoke-direct {v6, v4, v5}, Ld0/w;-><init>(J)V

    .line 983
    .line 984
    .line 985
    sget-wide v4, Ld0/w;->f:J

    .line 986
    .line 987
    new-instance v7, Ld0/w;

    .line 988
    .line 989
    invoke-direct {v7, v4, v5}, Ld0/w;-><init>(J)V

    .line 990
    .line 991
    .line 992
    filled-new-array {v6, v7}, [Ld0/w;

    .line 993
    .line 994
    .line 995
    move-result-object v6

    .line 996
    invoke-static {v6}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 997
    .line 998
    .line 999
    move-result-object v6

    .line 1000
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1001
    .line 1002
    .line 1003
    move-result-wide v7

    .line 1004
    shr-long/2addr v7, v13

    .line 1005
    long-to-int v7, v7

    .line 1006
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1007
    .line 1008
    .line 1009
    move-result v7

    .line 1010
    const v8, 0x3e3851ec    # 0.18f

    .line 1011
    .line 1012
    .line 1013
    mul-float/2addr v7, v8

    .line 1014
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1015
    .line 1016
    .line 1017
    move-result-wide v9

    .line 1018
    and-long v9, v9, v16

    .line 1019
    .line 1020
    long-to-int v9, v9

    .line 1021
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1022
    .line 1023
    .line 1024
    move-result v9

    .line 1025
    const v10, 0x3e23d70a    # 0.16f

    .line 1026
    .line 1027
    .line 1028
    mul-float/2addr v9, v10

    .line 1029
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1030
    .line 1031
    .line 1032
    move-result v7

    .line 1033
    int-to-long v11, v7

    .line 1034
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1035
    .line 1036
    .line 1037
    move-result v7

    .line 1038
    int-to-long v14, v7

    .line 1039
    shl-long/2addr v11, v13

    .line 1040
    and-long v14, v14, v16

    .line 1041
    .line 1042
    or-long/2addr v11, v14

    .line 1043
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1044
    .line 1045
    .line 1046
    move-result-wide v14

    .line 1047
    invoke-static {v14, v15}, Lc0/e;->b(J)F

    .line 1048
    .line 1049
    .line 1050
    move-result v7

    .line 1051
    const v9, 0x3f051eb8    # 0.52f

    .line 1052
    .line 1053
    .line 1054
    mul-float/2addr v7, v9

    .line 1055
    new-instance v14, Ld0/N;

    .line 1056
    .line 1057
    invoke-direct {v14, v6, v11, v12, v7}, Ld0/N;-><init>(Ljava/util/List;JF)V

    .line 1058
    .line 1059
    .line 1060
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1061
    .line 1062
    .line 1063
    move-result-wide v6

    .line 1064
    invoke-static {v6, v7}, Lc0/e;->b(J)F

    .line 1065
    .line 1066
    .line 1067
    move-result v6

    .line 1068
    mul-float/2addr v6, v9

    .line 1069
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1070
    .line 1071
    .line 1072
    move-result-wide v11

    .line 1073
    shr-long/2addr v11, v13

    .line 1074
    long-to-int v7, v11

    .line 1075
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1076
    .line 1077
    .line 1078
    move-result v7

    .line 1079
    mul-float/2addr v7, v8

    .line 1080
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1081
    .line 1082
    .line 1083
    move-result-wide v8

    .line 1084
    and-long v8, v8, v16

    .line 1085
    .line 1086
    long-to-int v8, v8

    .line 1087
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1088
    .line 1089
    .line 1090
    move-result v8

    .line 1091
    mul-float/2addr v8, v10

    .line 1092
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1093
    .line 1094
    .line 1095
    move-result v7

    .line 1096
    int-to-long v9, v7

    .line 1097
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1098
    .line 1099
    .line 1100
    move-result v7

    .line 1101
    int-to-long v7, v7

    .line 1102
    shl-long/2addr v9, v13

    .line 1103
    and-long v7, v7, v16

    .line 1104
    .line 1105
    or-long/2addr v7, v9

    .line 1106
    invoke-interface {v1, v14, v6, v7, v8}, Lf0/d;->F(Ld0/N;FJ)V

    .line 1107
    .line 1108
    .line 1109
    const v6, 0x3e0f5c29    # 0.14f

    .line 1110
    .line 1111
    .line 1112
    invoke-static {v2, v3, v6}, Ld0/w;->b(JF)J

    .line 1113
    .line 1114
    .line 1115
    move-result-wide v2

    .line 1116
    new-instance v6, Ld0/w;

    .line 1117
    .line 1118
    invoke-direct {v6, v2, v3}, Ld0/w;-><init>(J)V

    .line 1119
    .line 1120
    .line 1121
    new-instance v2, Ld0/w;

    .line 1122
    .line 1123
    invoke-direct {v2, v4, v5}, Ld0/w;-><init>(J)V

    .line 1124
    .line 1125
    .line 1126
    filled-new-array {v6, v2}, [Ld0/w;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v2

    .line 1130
    invoke-static {v2}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 1131
    .line 1132
    .line 1133
    move-result-object v2

    .line 1134
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1135
    .line 1136
    .line 1137
    move-result-wide v3

    .line 1138
    shr-long/2addr v3, v13

    .line 1139
    long-to-int v3, v3

    .line 1140
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1141
    .line 1142
    .line 1143
    move-result v3

    .line 1144
    const v4, 0x3f5c28f6    # 0.86f

    .line 1145
    .line 1146
    .line 1147
    mul-float/2addr v3, v4

    .line 1148
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1149
    .line 1150
    .line 1151
    move-result-wide v5

    .line 1152
    and-long v5, v5, v16

    .line 1153
    .line 1154
    long-to-int v5, v5

    .line 1155
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1156
    .line 1157
    .line 1158
    move-result v5

    .line 1159
    const v6, 0x3f0a3d71    # 0.54f

    .line 1160
    .line 1161
    .line 1162
    mul-float/2addr v5, v6

    .line 1163
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1164
    .line 1165
    .line 1166
    move-result v3

    .line 1167
    int-to-long v7, v3

    .line 1168
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1169
    .line 1170
    .line 1171
    move-result v3

    .line 1172
    int-to-long v9, v3

    .line 1173
    shl-long/2addr v7, v13

    .line 1174
    and-long v9, v9, v16

    .line 1175
    .line 1176
    or-long/2addr v7, v9

    .line 1177
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1178
    .line 1179
    .line 1180
    move-result-wide v9

    .line 1181
    invoke-static {v9, v10}, Lc0/e;->b(J)F

    .line 1182
    .line 1183
    .line 1184
    move-result v3

    .line 1185
    const v5, 0x3ef5c28f    # 0.48f

    .line 1186
    .line 1187
    .line 1188
    mul-float/2addr v3, v5

    .line 1189
    new-instance v9, Ld0/N;

    .line 1190
    .line 1191
    invoke-direct {v9, v2, v7, v8, v3}, Ld0/N;-><init>(Ljava/util/List;JF)V

    .line 1192
    .line 1193
    .line 1194
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1195
    .line 1196
    .line 1197
    move-result-wide v2

    .line 1198
    invoke-static {v2, v3}, Lc0/e;->b(J)F

    .line 1199
    .line 1200
    .line 1201
    move-result v2

    .line 1202
    mul-float/2addr v2, v5

    .line 1203
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1204
    .line 1205
    .line 1206
    move-result-wide v7

    .line 1207
    shr-long/2addr v7, v13

    .line 1208
    long-to-int v3, v7

    .line 1209
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1210
    .line 1211
    .line 1212
    move-result v3

    .line 1213
    mul-float/2addr v3, v4

    .line 1214
    invoke-interface {v1}, Lf0/d;->a()J

    .line 1215
    .line 1216
    .line 1217
    move-result-wide v4

    .line 1218
    and-long v4, v4, v16

    .line 1219
    .line 1220
    long-to-int v4, v4

    .line 1221
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1222
    .line 1223
    .line 1224
    move-result v4

    .line 1225
    mul-float/2addr v4, v6

    .line 1226
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1227
    .line 1228
    .line 1229
    move-result v3

    .line 1230
    int-to-long v5, v3

    .line 1231
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1232
    .line 1233
    .line 1234
    move-result v3

    .line 1235
    int-to-long v3, v3

    .line 1236
    shl-long/2addr v5, v13

    .line 1237
    and-long v3, v3, v16

    .line 1238
    .line 1239
    or-long/2addr v3, v5

    .line 1240
    invoke-interface {v1, v9, v2, v3, v4}, Lf0/d;->F(Ld0/N;FJ)V

    .line 1241
    .line 1242
    .line 1243
    return-object v18

    .line 1244
    :pswitch_16
    move-object v10, v1

    .line 1245
    check-cast v10, Lf0/d;

    .line 1246
    .line 1247
    invoke-static {v10, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1248
    .line 1249
    .line 1250
    sget-wide v1, Ld0/w;->c:J

    .line 1251
    .line 1252
    invoke-static {v1, v2, v6}, Ld0/w;->b(JF)J

    .line 1253
    .line 1254
    .line 1255
    move-result-wide v11

    .line 1256
    const/4 v15, 0x0

    .line 1257
    const/16 v16, 0x7e

    .line 1258
    .line 1259
    const-wide/16 v13, 0x0

    .line 1260
    .line 1261
    invoke-static/range {v10 .. v16}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 1262
    .line 1263
    .line 1264
    return-object v18

    .line 1265
    :pswitch_17
    check-cast v1, LC1/f;

    .line 1266
    .line 1267
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1268
    .line 1269
    .line 1270
    invoke-static {v1}, LE1/a;->a(LC1/f;)V

    .line 1271
    .line 1272
    .line 1273
    const/4 v2, 0x6

    .line 1274
    int-to-float v2, v2

    .line 1275
    iget v3, v1, LC1/f;->d:F

    .line 1276
    .line 1277
    mul-float/2addr v3, v2

    .line 1278
    invoke-static {v1, v3}, LX1/a;->D(LC1/f;F)V

    .line 1279
    .line 1280
    .line 1281
    const/16 v2, 0x10

    .line 1282
    .line 1283
    int-to-float v2, v2

    .line 1284
    iget v3, v1, LC1/f;->d:F

    .line 1285
    .line 1286
    mul-float/2addr v2, v3

    .line 1287
    int-to-float v4, v13

    .line 1288
    mul-float/2addr v3, v4

    .line 1289
    invoke-static {v1, v2, v3, v8}, La/a;->D(LC1/f;FFZ)V

    .line 1290
    .line 1291
    .line 1292
    return-object v18

    .line 1293
    :pswitch_18
    move-object v9, v1

    .line 1294
    check-cast v9, Lf0/d;

    .line 1295
    .line 1296
    invoke-static {v9, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1297
    .line 1298
    .line 1299
    sget-wide v1, Ld0/w;->c:J

    .line 1300
    .line 1301
    invoke-static {v1, v2, v6}, Ld0/w;->b(JF)J

    .line 1302
    .line 1303
    .line 1304
    move-result-wide v10

    .line 1305
    const/4 v14, 0x0

    .line 1306
    const/16 v15, 0x7e

    .line 1307
    .line 1308
    const-wide/16 v12, 0x0

    .line 1309
    .line 1310
    invoke-static/range {v9 .. v15}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 1311
    .line 1312
    .line 1313
    return-object v18

    .line 1314
    :pswitch_19
    check-cast v1, LC1/f;

    .line 1315
    .line 1316
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1317
    .line 1318
    .line 1319
    invoke-static {v1}, LE1/a;->a(LC1/f;)V

    .line 1320
    .line 1321
    .line 1322
    int-to-float v2, v5

    .line 1323
    iget v3, v1, LC1/f;->d:F

    .line 1324
    .line 1325
    mul-float/2addr v3, v2

    .line 1326
    invoke-static {v1, v3}, LX1/a;->D(LC1/f;F)V

    .line 1327
    .line 1328
    .line 1329
    const/16 v2, 0x12

    .line 1330
    .line 1331
    int-to-float v2, v2

    .line 1332
    iget v3, v1, LC1/f;->d:F

    .line 1333
    .line 1334
    mul-float/2addr v2, v3

    .line 1335
    const/16 v4, 0x22

    .line 1336
    .line 1337
    int-to-float v4, v4

    .line 1338
    mul-float/2addr v3, v4

    .line 1339
    invoke-static {v1, v2, v3, v8}, La/a;->D(LC1/f;FFZ)V

    .line 1340
    .line 1341
    .line 1342
    return-object v18

    .line 1343
    :pswitch_1a
    move-object v9, v1

    .line 1344
    check-cast v9, Lf0/d;

    .line 1345
    .line 1346
    invoke-static {v9, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1347
    .line 1348
    .line 1349
    sget-wide v1, Ld0/w;->c:J

    .line 1350
    .line 1351
    const v4, 0x3dae147b    # 0.085f

    .line 1352
    .line 1353
    .line 1354
    invoke-static {v1, v2, v4}, Ld0/w;->b(JF)J

    .line 1355
    .line 1356
    .line 1357
    move-result-wide v10

    .line 1358
    const/4 v14, 0x0

    .line 1359
    const/16 v15, 0x7e

    .line 1360
    .line 1361
    const-wide/16 v12, 0x0

    .line 1362
    .line 1363
    invoke-static/range {v9 .. v15}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 1364
    .line 1365
    .line 1366
    sget-wide v1, Ld0/w;->b:J

    .line 1367
    .line 1368
    invoke-static {v1, v2, v3}, Ld0/w;->b(JF)J

    .line 1369
    .line 1370
    .line 1371
    move-result-wide v10

    .line 1372
    invoke-static/range {v9 .. v15}, Lf0/d;->h0(Lf0/d;JJII)V

    .line 1373
    .line 1374
    .line 1375
    return-object v18

    .line 1376
    :pswitch_1b
    check-cast v1, Ld0/E;

    .line 1377
    .line 1378
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1379
    .line 1380
    .line 1381
    const v2, 0x3ecccccd    # 0.4f

    .line 1382
    .line 1383
    .line 1384
    invoke-interface {v1, v2}, Ld0/E;->u(F)V

    .line 1385
    .line 1386
    .line 1387
    const v2, -0x414ccccd    # -0.35f

    .line 1388
    .line 1389
    .line 1390
    invoke-interface {v1, v2}, Ld0/E;->b(F)V

    .line 1391
    .line 1392
    .line 1393
    return-object v18

    .line 1394
    :pswitch_1c
    check-cast v1, LC1/f;

    .line 1395
    .line 1396
    invoke-static {v1, v7}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1397
    .line 1398
    .line 1399
    invoke-static {v1}, LE1/a;->a(LC1/f;)V

    .line 1400
    .line 1401
    .line 1402
    const/16 v2, 0xc

    .line 1403
    .line 1404
    int-to-float v2, v2

    .line 1405
    iget v3, v1, LC1/f;->d:F

    .line 1406
    .line 1407
    mul-float/2addr v3, v2

    .line 1408
    invoke-static {v1, v3}, LX1/a;->D(LC1/f;F)V

    .line 1409
    .line 1410
    .line 1411
    const/16 v2, 0x1e

    .line 1412
    .line 1413
    int-to-float v2, v2

    .line 1414
    iget v3, v1, LC1/f;->d:F

    .line 1415
    .line 1416
    mul-float/2addr v2, v3

    .line 1417
    const/16 v4, 0x38

    .line 1418
    .line 1419
    int-to-float v4, v4

    .line 1420
    mul-float/2addr v3, v4

    .line 1421
    invoke-static {v1, v2, v3, v8}, La/a;->D(LC1/f;FFZ)V

    .line 1422
    .line 1423
    .line 1424
    return-object v18

    .line 1425
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
