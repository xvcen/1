.class public final synthetic LA1/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LA1/d0;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Z

.field public final synthetic g:Z

.field public final synthetic h:LU1/c;

.field public final synthetic i:LU1/c;

.field public final synthetic j:LU1/a;

.field public final synthetic k:LU1/a;

.field public final synthetic l:LU1/a;

.field public final synthetic m:LU1/a;

.field public final synthetic n:LU1/a;


# direct methods
.method public synthetic constructor <init>(LA1/d0;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;LU1/a;LU1/a;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/w;->d:LA1/d0;

    iput-object p2, p0, LA1/w;->e:Ljava/lang/String;

    iput-boolean p3, p0, LA1/w;->f:Z

    iput-boolean p4, p0, LA1/w;->g:Z

    iput-object p5, p0, LA1/w;->h:LU1/c;

    iput-object p6, p0, LA1/w;->i:LU1/c;

    iput-object p7, p0, LA1/w;->j:LU1/a;

    iput-object p8, p0, LA1/w;->k:LU1/a;

    iput-object p9, p0, LA1/w;->l:LU1/a;

    iput-object p10, p0, LA1/w;->m:LU1/a;

    iput-object p11, p0, LA1/w;->n:LU1/a;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    move-object v11, p1

    .line 2
    check-cast v11, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const p1, 0x36001

    .line 10
    .line 11
    .line 12
    invoke-static {p1}, LI/k;->x(I)I

    .line 13
    .line 14
    .line 15
    move-result v12

    .line 16
    iget-object v0, p0, LA1/w;->d:LA1/d0;

    .line 17
    .line 18
    iget-object v1, p0, LA1/w;->e:Ljava/lang/String;

    .line 19
    .line 20
    iget-boolean v2, p0, LA1/w;->f:Z

    .line 21
    .line 22
    iget-boolean v3, p0, LA1/w;->g:Z

    .line 23
    .line 24
    iget-object v4, p0, LA1/w;->h:LU1/c;

    .line 25
    .line 26
    iget-object v5, p0, LA1/w;->i:LU1/c;

    .line 27
    .line 28
    iget-object v6, p0, LA1/w;->j:LU1/a;

    .line 29
    .line 30
    iget-object v7, p0, LA1/w;->k:LU1/a;

    .line 31
    .line 32
    iget-object v8, p0, LA1/w;->l:LU1/a;

    .line 33
    .line 34
    iget-object v9, p0, LA1/w;->m:LU1/a;

    .line 35
    .line 36
    iget-object v10, p0, LA1/w;->n:LU1/a;

    .line 37
    .line 38
    invoke-static/range {v0 .. v12}, LX1/a;->i(LA1/d0;Ljava/lang/String;ZZLU1/c;LU1/c;LU1/a;LU1/a;LU1/a;LU1/a;LU1/a;LI/r;I)V

    .line 39
    .line 40
    .line 41
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 42
    .line 43
    return-object p1
.end method
