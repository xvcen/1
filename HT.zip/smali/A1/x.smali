.class public final synthetic LA1/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LA1/x;->d:I

    iput-object p3, p0, LA1/x;->f:Ljava/lang/Object;

    iput-object p4, p0, LA1/x;->g:Ljava/lang/Object;

    iput p1, p0, LA1/x;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LQ/f;Ljava/lang/Object;I)V
    .locals 1

    .line 2
    const/4 v0, 0x3

    iput v0, p0, LA1/x;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/x;->g:Ljava/lang/Object;

    iput-object p2, p0, LA1/x;->f:Ljava/lang/Object;

    iput p3, p0, LA1/x;->e:I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LA1/x;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA1/x;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ll/U;

    .line 9
    .line 10
    check-cast p1, LI/r;

    .line 11
    .line 12
    check-cast p2, Ljava/lang/Integer;

    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget p2, p0, LA1/x;->e:I

    .line 18
    .line 19
    or-int/lit8 p2, p2, 0x1

    .line 20
    .line 21
    invoke-static {p2}, LI/k;->x(I)I

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    iget-object v1, p0, LA1/x;->g:Ljava/lang/Object;

    .line 26
    .line 27
    invoke-virtual {v0, v1, p1, p2}, Ll/U;->a(Ljava/lang/Object;LI/r;I)V

    .line 28
    .line 29
    .line 30
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 31
    .line 32
    return-object p1

    .line 33
    :pswitch_0
    iget-object v0, p0, LA1/x;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, LQ/f;

    .line 36
    .line 37
    check-cast p1, LI/r;

    .line 38
    .line 39
    check-cast p2, Ljava/lang/Integer;

    .line 40
    .line 41
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 42
    .line 43
    .line 44
    iget p2, p0, LA1/x;->e:I

    .line 45
    .line 46
    invoke-static {p2}, LI/k;->x(I)I

    .line 47
    .line 48
    .line 49
    move-result p2

    .line 50
    or-int/lit8 p2, p2, 0x1

    .line 51
    .line 52
    iget-object v1, p0, LA1/x;->f:Ljava/lang/Object;

    .line 53
    .line 54
    invoke-virtual {v0, v1, p1, p2}, LQ/f;->e(Ljava/lang/Object;LI/r;I)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :pswitch_1
    iget-object v0, p0, LA1/x;->f:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, [LI/u0;

    .line 61
    .line 62
    iget-object v1, p0, LA1/x;->g:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v1, LU1/e;

    .line 65
    .line 66
    check-cast p1, LI/r;

    .line 67
    .line 68
    check-cast p2, Ljava/lang/Integer;

    .line 69
    .line 70
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 71
    .line 72
    .line 73
    iget p2, p0, LA1/x;->e:I

    .line 74
    .line 75
    or-int/lit8 p2, p2, 0x1

    .line 76
    .line 77
    invoke-static {p2}, LI/k;->x(I)I

    .line 78
    .line 79
    .line 80
    move-result p2

    .line 81
    invoke-static {v0, v1, p1, p2}, LI/k;->b([LI/u0;LU1/e;LI/r;I)V

    .line 82
    .line 83
    .line 84
    goto :goto_0

    .line 85
    :pswitch_2
    iget-object v0, p0, LA1/x;->f:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v0, Ljava/lang/String;

    .line 88
    .line 89
    iget-object v1, p0, LA1/x;->g:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v1, Ljava/lang/String;

    .line 92
    .line 93
    check-cast p1, LI/r;

    .line 94
    .line 95
    check-cast p2, Ljava/lang/Integer;

    .line 96
    .line 97
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    iget p2, p0, LA1/x;->e:I

    .line 101
    .line 102
    or-int/lit8 p2, p2, 0x1

    .line 103
    .line 104
    invoke-static {p2}, LI/k;->x(I)I

    .line 105
    .line 106
    .line 107
    move-result p2

    .line 108
    invoke-static {v0, v1, p1, p2}, LX1/a;->o(Ljava/lang/String;Ljava/lang/String;LI/r;I)V

    .line 109
    .line 110
    .line 111
    goto :goto_0

    .line 112
    :pswitch_3
    iget-object v0, p0, LA1/x;->f:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v0, LC1/a;

    .line 115
    .line 116
    iget-object v1, p0, LA1/x;->g:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast v1, LQ/f;

    .line 119
    .line 120
    check-cast p1, LI/r;

    .line 121
    .line 122
    check-cast p2, Ljava/lang/Integer;

    .line 123
    .line 124
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    .line 126
    .line 127
    iget p2, p0, LA1/x;->e:I

    .line 128
    .line 129
    or-int/lit8 p2, p2, 0x1

    .line 130
    .line 131
    invoke-static {p2}, LI/k;->x(I)I

    .line 132
    .line 133
    .line 134
    move-result p2

    .line 135
    invoke-static {v0, v1, p1, p2}, LX1/a;->l(LC1/a;LQ/f;LI/r;I)V

    .line 136
    .line 137
    .line 138
    goto :goto_0

    .line 139
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
