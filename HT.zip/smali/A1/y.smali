.class public final synthetic LA1/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/f;


# instance fields
.field public final synthetic d:LA1/d0;

.field public final synthetic e:LC1/a;

.field public final synthetic f:Z

.field public final synthetic g:LU1/a;

.field public final synthetic h:LU1/a;


# direct methods
.method public synthetic constructor <init>(LA1/d0;LC1/a;ZLU1/a;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/y;->d:LA1/d0;

    iput-object p2, p0, LA1/y;->e:LC1/a;

    iput-boolean p3, p0, LA1/y;->f:Z

    iput-object p4, p0, LA1/y;->g:LU1/a;

    iput-object p5, p0, LA1/y;->h:LU1/a;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    check-cast p1, Ls/r;

    .line 2
    .line 3
    move-object v5, p2

    .line 4
    check-cast v5, LI/r;

    .line 5
    .line 6
    check-cast p3, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    const-string p3, "$this$LiquidPanel"

    .line 13
    .line 14
    invoke-static {p1, p3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    and-int/lit8 p1, p2, 0x11

    .line 18
    .line 19
    const/16 p3, 0x10

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    const/4 v1, 0x1

    .line 23
    if-eq p1, p3, :cond_0

    .line 24
    .line 25
    move p1, v1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    move p1, v0

    .line 28
    :goto_0
    and-int/2addr p2, v1

    .line 29
    invoke-virtual {v5, p2, p1}, LI/r;->N(IZ)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_2

    .line 34
    .line 35
    iget-object p1, p0, LA1/y;->d:LA1/d0;

    .line 36
    .line 37
    iget-object p2, p1, LA1/d0;->a:Ljava/lang/String;

    .line 38
    .line 39
    iget-object p3, p1, LA1/d0;->b:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {p2, p3, v5, v0}, LX1/a;->o(Ljava/lang/String;Ljava/lang/String;LI/r;I)V

    .line 42
    .line 43
    .line 44
    const/16 p2, 0x12

    .line 45
    .line 46
    int-to-float p2, p2

    .line 47
    sget-object p3, LW/n;->a:LW/n;

    .line 48
    .line 49
    invoke-static {p3, p2}, Ls/b;->d(LW/q;F)LW/q;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    invoke-static {v5, p2}, Ls/b;->a(LI/r;LW/q;)V

    .line 54
    .line 55
    .line 56
    iget-boolean p2, p0, LA1/y;->f:Z

    .line 57
    .line 58
    if-eqz p2, :cond_1

    .line 59
    .line 60
    iget-object v0, p1, LA1/d0;->d:Ljava/lang/String;

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_1
    iget-object v0, p1, LA1/d0;->c:Ljava/lang/String;

    .line 64
    .line 65
    :goto_1
    xor-int/lit8 v3, p2, 0x1

    .line 66
    .line 67
    const/16 v6, 0x180

    .line 68
    .line 69
    const/4 v7, 0x0

    .line 70
    move-object v1, v0

    .line 71
    iget-object v0, p0, LA1/y;->e:LC1/a;

    .line 72
    .line 73
    const/4 v2, 0x1

    .line 74
    iget-object v4, p0, LA1/y;->g:LU1/a;

    .line 75
    .line 76
    invoke-static/range {v0 .. v7}, LX1/a;->f(LC1/a;Ljava/lang/String;ZZLU1/a;LI/r;II)V

    .line 77
    .line 78
    .line 79
    const/16 p2, 0xa

    .line 80
    .line 81
    int-to-float p2, p2

    .line 82
    invoke-static {p3, p2}, Ls/b;->d(LW/q;F)LW/q;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    invoke-static {v5, p2}, Ls/b;->a(LI/r;LW/q;)V

    .line 87
    .line 88
    .line 89
    iget-object v1, p1, LA1/d0;->e:Ljava/lang/String;

    .line 90
    .line 91
    const/4 v2, 0x0

    .line 92
    iget-object v4, p0, LA1/y;->h:LU1/a;

    .line 93
    .line 94
    invoke-static/range {v0 .. v7}, LX1/a;->f(LC1/a;Ljava/lang/String;ZZLU1/a;LI/r;II)V

    .line 95
    .line 96
    .line 97
    goto :goto_2

    .line 98
    :cond_2
    invoke-virtual {v5}, LI/r;->Q()V

    .line 99
    .line 100
    .line 101
    :goto_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 102
    .line 103
    return-object p1
.end method
