.class public final synthetic LA1/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/f;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA1/z;->d:I

    iput-object p2, p0, LA1/z;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lk2/c;Lk2/b;)V
    .locals 0

    .line 2
    const/4 p2, 0x4

    iput p2, p0, LA1/z;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA1/z;->e:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LA1/z;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/16 v3, 0x9

    .line 7
    .line 8
    const/4 v4, 0x4

    .line 9
    const-wide v5, 0xffffffffL

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    const/16 v7, 0x20

    .line 15
    .line 16
    const/4 v8, 0x0

    .line 17
    sget-object v9, LI/m;->a:LI/h;

    .line 18
    .line 19
    sget-object v10, LJ1/m;->a:LJ1/m;

    .line 20
    .line 21
    const/4 v11, 0x0

    .line 22
    iget-object v12, v0, LA1/z;->e:Ljava/lang/Object;

    .line 23
    .line 24
    packed-switch v1, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    check-cast v12, Lw/o0;

    .line 28
    .line 29
    move-object/from16 v1, p1

    .line 30
    .line 31
    check-cast v1, Lu0/B;

    .line 32
    .line 33
    move-object/from16 v2, p2

    .line 34
    .line 35
    check-cast v2, Lu0/y;

    .line 36
    .line 37
    move-object/from16 v3, p3

    .line 38
    .line 39
    check-cast v3, LT0/a;

    .line 40
    .line 41
    iget-wide v8, v12, Lw/o0;->f:J

    .line 42
    .line 43
    iget-wide v10, v3, LT0/a;->a:J

    .line 44
    .line 45
    shr-long v12, v8, v7

    .line 46
    .line 47
    long-to-int v7, v12

    .line 48
    invoke-static {v10, v11}, LT0/a;->j(J)I

    .line 49
    .line 50
    .line 51
    move-result v12

    .line 52
    iget-wide v13, v3, LT0/a;->a:J

    .line 53
    .line 54
    invoke-static {v13, v14}, LT0/a;->h(J)I

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    invoke-static {v7, v12, v3}, LT0/l;->m(III)I

    .line 59
    .line 60
    .line 61
    move-result v12

    .line 62
    and-long/2addr v5, v8

    .line 63
    long-to-int v3, v5

    .line 64
    invoke-static {v13, v14}, LT0/a;->i(J)I

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    invoke-static {v13, v14}, LT0/a;->g(J)I

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    invoke-static {v3, v5, v6}, LT0/l;->m(III)I

    .line 73
    .line 74
    .line 75
    move-result v14

    .line 76
    const/4 v15, 0x0

    .line 77
    const/16 v16, 0xa

    .line 78
    .line 79
    const/4 v13, 0x0

    .line 80
    invoke-static/range {v10 .. v16}, LT0/a;->a(JIIIII)J

    .line 81
    .line 82
    .line 83
    move-result-wide v5

    .line 84
    invoke-interface {v2, v5, v6}, Lu0/y;->v(J)Lu0/L;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    iget v3, v2, Lu0/L;->d:I

    .line 89
    .line 90
    iget v5, v2, Lu0/L;->e:I

    .line 91
    .line 92
    new-instance v6, LG/g;

    .line 93
    .line 94
    invoke-direct {v6, v2, v4}, LG/g;-><init>(Lu0/L;I)V

    .line 95
    .line 96
    .line 97
    sget-object v2, LK1/u;->d:LK1/u;

    .line 98
    .line 99
    invoke-interface {v1, v3, v5, v2, v6}, Lu0/B;->D0(IILjava/util/Map;LU1/c;)Lu0/A;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    return-object v1

    .line 104
    :pswitch_0
    check-cast v12, LH0/O;

    .line 105
    .line 106
    move-object/from16 v1, p1

    .line 107
    .line 108
    check-cast v1, LW/q;

    .line 109
    .line 110
    move-object/from16 v1, p2

    .line 111
    .line 112
    check-cast v1, LI/r;

    .line 113
    .line 114
    move-object/from16 v2, p3

    .line 115
    .line 116
    check-cast v2, Ljava/lang/Integer;

    .line 117
    .line 118
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 119
    .line 120
    .line 121
    const v2, 0x5e56a525

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1, v2}, LI/r;->U(I)V

    .line 125
    .line 126
    .line 127
    sget-object v2, Lx0/i0;->h:LI/b1;

    .line 128
    .line 129
    invoke-virtual {v1, v2}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    check-cast v2, LT0/c;

    .line 134
    .line 135
    sget-object v4, Lx0/i0;->k:LI/b1;

    .line 136
    .line 137
    invoke-virtual {v1, v4}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    check-cast v4, LL0/d;

    .line 142
    .line 143
    sget-object v5, Lx0/i0;->n:LI/b1;

    .line 144
    .line 145
    invoke-virtual {v1, v5}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v5

    .line 149
    check-cast v5, LT0/o;

    .line 150
    .line 151
    invoke-virtual {v1, v12}, LI/r;->e(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v6

    .line 155
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 156
    .line 157
    .line 158
    move-result v7

    .line 159
    invoke-virtual {v1, v7}, LI/r;->c(I)Z

    .line 160
    .line 161
    .line 162
    move-result v7

    .line 163
    or-int/2addr v6, v7

    .line 164
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v7

    .line 168
    if-nez v6, :cond_0

    .line 169
    .line 170
    if-ne v7, v9, :cond_1

    .line 171
    .line 172
    :cond_0
    invoke-static {v12, v5}, LH0/F;->h(LH0/O;LT0/o;)LH0/O;

    .line 173
    .line 174
    .line 175
    move-result-object v7

    .line 176
    invoke-virtual {v1, v7}, LI/r;->d0(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_1
    check-cast v7, LH0/O;

    .line 180
    .line 181
    invoke-virtual {v1, v4}, LI/r;->e(Ljava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result v6

    .line 185
    invoke-virtual {v1, v7}, LI/r;->e(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v8

    .line 189
    or-int/2addr v6, v8

    .line 190
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v8

    .line 194
    if-nez v6, :cond_2

    .line 195
    .line 196
    if-ne v8, v9, :cond_6

    .line 197
    .line 198
    :cond_2
    iget-object v6, v7, LH0/O;->a:LH0/G;

    .line 199
    .line 200
    iget-object v8, v6, LH0/G;->f:LL0/b;

    .line 201
    .line 202
    iget-object v10, v6, LH0/G;->c:LL0/k;

    .line 203
    .line 204
    if-nez v10, :cond_3

    .line 205
    .line 206
    sget-object v10, LL0/k;->f:LL0/k;

    .line 207
    .line 208
    :cond_3
    iget-object v13, v6, LH0/G;->d:LL0/i;

    .line 209
    .line 210
    if-eqz v13, :cond_4

    .line 211
    .line 212
    iget v13, v13, LL0/i;->a:I

    .line 213
    .line 214
    goto :goto_0

    .line 215
    :cond_4
    move v13, v11

    .line 216
    :goto_0
    iget-object v6, v6, LH0/G;->e:LL0/j;

    .line 217
    .line 218
    if-eqz v6, :cond_5

    .line 219
    .line 220
    iget v6, v6, LL0/j;->a:I

    .line 221
    .line 222
    goto :goto_1

    .line 223
    :cond_5
    const v6, 0xffff

    .line 224
    .line 225
    .line 226
    :goto_1
    move-object v14, v4

    .line 227
    check-cast v14, LL0/e;

    .line 228
    .line 229
    invoke-virtual {v14, v8, v10, v13, v6}, LL0/e;->b(LL0/b;LL0/k;II)LL0/p;

    .line 230
    .line 231
    .line 232
    move-result-object v8

    .line 233
    invoke-virtual {v1, v8}, LI/r;->d0(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    :cond_6
    check-cast v8, LI/a1;

    .line 237
    .line 238
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v6

    .line 242
    if-ne v6, v9, :cond_7

    .line 243
    .line 244
    new-instance v6, Lw/o0;

    .line 245
    .line 246
    invoke-interface {v8}, LI/a1;->getValue()Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v10

    .line 250
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 251
    .line 252
    .line 253
    iput-object v5, v6, Lw/o0;->a:LT0/o;

    .line 254
    .line 255
    iput-object v2, v6, Lw/o0;->b:LT0/c;

    .line 256
    .line 257
    iput-object v4, v6, Lw/o0;->c:LL0/d;

    .line 258
    .line 259
    iput-object v12, v6, Lw/o0;->d:LH0/O;

    .line 260
    .line 261
    iput-object v10, v6, Lw/o0;->e:Ljava/lang/Object;

    .line 262
    .line 263
    invoke-static {v12, v2, v4}, Lw/d0;->b(LH0/O;LT0/c;LL0/d;)J

    .line 264
    .line 265
    .line 266
    move-result-wide v12

    .line 267
    iput-wide v12, v6, Lw/o0;->f:J

    .line 268
    .line 269
    invoke-virtual {v1, v6}, LI/r;->d0(Ljava/lang/Object;)V

    .line 270
    .line 271
    .line 272
    :cond_7
    check-cast v6, Lw/o0;

    .line 273
    .line 274
    invoke-interface {v8}, LI/a1;->getValue()Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object v8

    .line 278
    iget-object v10, v6, Lw/o0;->a:LT0/o;

    .line 279
    .line 280
    if-ne v5, v10, :cond_8

    .line 281
    .line 282
    iget-object v10, v6, Lw/o0;->b:LT0/c;

    .line 283
    .line 284
    invoke-static {v2, v10}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v10

    .line 288
    if-eqz v10, :cond_8

    .line 289
    .line 290
    iget-object v10, v6, Lw/o0;->c:LL0/d;

    .line 291
    .line 292
    invoke-static {v4, v10}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    move-result v10

    .line 296
    if-eqz v10, :cond_8

    .line 297
    .line 298
    iget-object v10, v6, Lw/o0;->d:LH0/O;

    .line 299
    .line 300
    invoke-static {v7, v10}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    move-result v10

    .line 304
    if-eqz v10, :cond_8

    .line 305
    .line 306
    iget-object v10, v6, Lw/o0;->e:Ljava/lang/Object;

    .line 307
    .line 308
    invoke-static {v8, v10}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v10

    .line 312
    if-nez v10, :cond_9

    .line 313
    .line 314
    :cond_8
    iput-object v5, v6, Lw/o0;->a:LT0/o;

    .line 315
    .line 316
    iput-object v2, v6, Lw/o0;->b:LT0/c;

    .line 317
    .line 318
    iput-object v4, v6, Lw/o0;->c:LL0/d;

    .line 319
    .line 320
    iput-object v7, v6, Lw/o0;->d:LH0/O;

    .line 321
    .line 322
    iput-object v8, v6, Lw/o0;->e:Ljava/lang/Object;

    .line 323
    .line 324
    invoke-static {v7, v2, v4}, Lw/d0;->b(LH0/O;LT0/c;LL0/d;)J

    .line 325
    .line 326
    .line 327
    move-result-wide v4

    .line 328
    iput-wide v4, v6, Lw/o0;->f:J

    .line 329
    .line 330
    :cond_9
    invoke-virtual {v1, v6}, LI/r;->g(Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move-result v2

    .line 334
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v4

    .line 338
    if-nez v2, :cond_a

    .line 339
    .line 340
    if-ne v4, v9, :cond_b

    .line 341
    .line 342
    :cond_a
    new-instance v4, LA1/z;

    .line 343
    .line 344
    invoke-direct {v4, v3, v6}, LA1/z;-><init>(ILjava/lang/Object;)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v1, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    :cond_b
    check-cast v4, LU1/f;

    .line 351
    .line 352
    invoke-static {v4}, Lu0/v;->g(LU1/f;)LW/q;

    .line 353
    .line 354
    .line 355
    move-result-object v2

    .line 356
    invoke-virtual {v1, v11}, LI/r;->p(Z)V

    .line 357
    .line 358
    .line 359
    return-object v2

    .line 360
    :pswitch_1
    check-cast v12, LU1/c;

    .line 361
    .line 362
    move-object/from16 v1, p1

    .line 363
    .line 364
    check-cast v1, LW/q;

    .line 365
    .line 366
    move-object/from16 v1, p2

    .line 367
    .line 368
    check-cast v1, LI/r;

    .line 369
    .line 370
    move-object/from16 v2, p3

    .line 371
    .line 372
    check-cast v2, Ljava/lang/Integer;

    .line 373
    .line 374
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 375
    .line 376
    .line 377
    const v2, -0x620472b

    .line 378
    .line 379
    .line 380
    invoke-virtual {v1, v2}, LI/r;->U(I)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 384
    .line 385
    .line 386
    move-result-object v2

    .line 387
    if-ne v2, v9, :cond_c

    .line 388
    .line 389
    invoke-static {v1}, LI/k;->j(LI/r;)Lc2/s;

    .line 390
    .line 391
    .line 392
    move-result-object v2

    .line 393
    invoke-virtual {v1, v2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 394
    .line 395
    .line 396
    :cond_c
    check-cast v2, Lc2/s;

    .line 397
    .line 398
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object v4

    .line 402
    if-ne v4, v9, :cond_d

    .line 403
    .line 404
    invoke-static {v8}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    .line 405
    .line 406
    .line 407
    move-result-object v4

    .line 408
    invoke-virtual {v1, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 409
    .line 410
    .line 411
    :cond_d
    check-cast v4, LI/b0;

    .line 412
    .line 413
    invoke-static {v12, v1}, LI/k;->t(Ljava/lang/Object;LI/r;)LI/b0;

    .line 414
    .line 415
    .line 416
    move-result-object v5

    .line 417
    invoke-virtual {v1, v8}, LI/r;->e(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v6

    .line 421
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 422
    .line 423
    .line 424
    move-result-object v7

    .line 425
    if-nez v6, :cond_e

    .line 426
    .line 427
    if-ne v7, v9, :cond_f

    .line 428
    .line 429
    :cond_e
    new-instance v7, LA1/a;

    .line 430
    .line 431
    invoke-direct {v7, v4, v3}, LA1/a;-><init>(LI/b0;I)V

    .line 432
    .line 433
    .line 434
    invoke-virtual {v1, v7}, LI/r;->d0(Ljava/lang/Object;)V

    .line 435
    .line 436
    .line 437
    :cond_f
    check-cast v7, LU1/c;

    .line 438
    .line 439
    invoke-static {v8, v7, v1}, LI/k;->c(Ljava/lang/Object;LU1/c;LI/r;)V

    .line 440
    .line 441
    .line 442
    invoke-virtual {v1, v2}, LI/r;->g(Ljava/lang/Object;)Z

    .line 443
    .line 444
    .line 445
    move-result v3

    .line 446
    invoke-virtual {v1, v8}, LI/r;->e(Ljava/lang/Object;)Z

    .line 447
    .line 448
    .line 449
    move-result v6

    .line 450
    or-int/2addr v3, v6

    .line 451
    invoke-virtual {v1, v5}, LI/r;->e(Ljava/lang/Object;)Z

    .line 452
    .line 453
    .line 454
    move-result v6

    .line 455
    or-int/2addr v3, v6

    .line 456
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v6

    .line 460
    if-nez v3, :cond_10

    .line 461
    .line 462
    if-ne v6, v9, :cond_11

    .line 463
    .line 464
    :cond_10
    new-instance v6, Lw/k0;

    .line 465
    .line 466
    invoke-direct {v6, v2, v4, v5}, Lw/k0;-><init>(Lc2/s;LI/b0;LI/b0;)V

    .line 467
    .line 468
    .line 469
    invoke-virtual {v1, v6}, LI/r;->d0(Ljava/lang/Object;)V

    .line 470
    .line 471
    .line 472
    :cond_11
    check-cast v6, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 473
    .line 474
    sget-object v2, LW/n;->a:LW/n;

    .line 475
    .line 476
    invoke-static {v2, v8, v6}, Lq0/E;->a(LW/q;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)LW/q;

    .line 477
    .line 478
    .line 479
    move-result-object v2

    .line 480
    invoke-virtual {v1, v11}, LI/r;->p(Z)V

    .line 481
    .line 482
    .line 483
    return-object v2

    .line 484
    :pswitch_2
    check-cast v12, LH/D;

    .line 485
    .line 486
    move-object/from16 v1, p1

    .line 487
    .line 488
    check-cast v1, Lq0/u;

    .line 489
    .line 490
    move-object/from16 v1, p2

    .line 491
    .line 492
    check-cast v1, Lq0/u;

    .line 493
    .line 494
    move-object/from16 v2, p3

    .line 495
    .line 496
    check-cast v2, Lc0/b;

    .line 497
    .line 498
    iget-wide v1, v1, Lq0/u;->c:J

    .line 499
    .line 500
    iget-object v3, v12, LH/D;->e:Lw/a0;

    .line 501
    .line 502
    sget-object v4, LH/A;->d:LH/z;

    .line 503
    .line 504
    invoke-interface {v3, v1, v2, v4}, Lw/a0;->a(JLH/z;)V

    .line 505
    .line 506
    .line 507
    return-object v10

    .line 508
    :pswitch_3
    check-cast v12, Lk2/g;

    .line 509
    .line 510
    move-object/from16 v1, p1

    .line 511
    .line 512
    check-cast v1, Ljava/lang/Throwable;

    .line 513
    .line 514
    move-object/from16 v1, p2

    .line 515
    .line 516
    check-cast v1, LJ1/m;

    .line 517
    .line 518
    move-object/from16 v1, p3

    .line 519
    .line 520
    check-cast v1, LN1/h;

    .line 521
    .line 522
    invoke-virtual {v12}, Lk2/g;->b()V

    .line 523
    .line 524
    .line 525
    return-object v10

    .line 526
    :pswitch_4
    check-cast v12, Lk2/c;

    .line 527
    .line 528
    move-object/from16 v1, p1

    .line 529
    .line 530
    check-cast v1, Ljava/lang/Throwable;

    .line 531
    .line 532
    move-object/from16 v1, p2

    .line 533
    .line 534
    check-cast v1, LJ1/m;

    .line 535
    .line 536
    move-object/from16 v1, p3

    .line 537
    .line 538
    check-cast v1, LN1/h;

    .line 539
    .line 540
    sget-object v1, Lk2/c;->g:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 541
    .line 542
    invoke-virtual {v1, v12, v8}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v12, v8}, Lk2/c;->f(Ljava/lang/Object;)V

    .line 546
    .line 547
    .line 548
    return-object v10

    .line 549
    :pswitch_5
    check-cast v12, LB/y;

    .line 550
    .line 551
    move-object/from16 v1, p1

    .line 552
    .line 553
    check-cast v1, Ljava/lang/Throwable;

    .line 554
    .line 555
    move-object/from16 v2, p3

    .line 556
    .line 557
    check-cast v2, LN1/h;

    .line 558
    .line 559
    invoke-virtual {v12, v1}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 560
    .line 561
    .line 562
    return-object v10

    .line 563
    :pswitch_6
    check-cast v12, LH/m0;

    .line 564
    .line 565
    move-object/from16 v1, p1

    .line 566
    .line 567
    check-cast v1, LW/q;

    .line 568
    .line 569
    move-object/from16 v2, p2

    .line 570
    .line 571
    check-cast v2, LI/r;

    .line 572
    .line 573
    move-object/from16 v3, p3

    .line 574
    .line 575
    check-cast v3, Ljava/lang/Integer;

    .line 576
    .line 577
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 578
    .line 579
    .line 580
    const v3, 0x760d4197

    .line 581
    .line 582
    .line 583
    invoke-virtual {v2, v3}, LI/r;->U(I)V

    .line 584
    .line 585
    .line 586
    sget-object v3, Lx0/i0;->h:LI/b1;

    .line 587
    .line 588
    invoke-virtual {v2, v3}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 589
    .line 590
    .line 591
    move-result-object v3

    .line 592
    check-cast v3, LT0/c;

    .line 593
    .line 594
    invoke-virtual {v2}, LI/r;->K()Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    move-result-object v4

    .line 598
    if-ne v4, v9, :cond_12

    .line 599
    .line 600
    new-instance v4, LT0/n;

    .line 601
    .line 602
    const-wide/16 v5, 0x0

    .line 603
    .line 604
    invoke-direct {v4, v5, v6}, LT0/n;-><init>(J)V

    .line 605
    .line 606
    .line 607
    invoke-static {v4}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    .line 608
    .line 609
    .line 610
    move-result-object v4

    .line 611
    invoke-virtual {v2, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 612
    .line 613
    .line 614
    :cond_12
    check-cast v4, LI/b0;

    .line 615
    .line 616
    invoke-virtual {v2, v12}, LI/r;->g(Ljava/lang/Object;)Z

    .line 617
    .line 618
    .line 619
    move-result v5

    .line 620
    invoke-virtual {v2}, LI/r;->K()Ljava/lang/Object;

    .line 621
    .line 622
    .line 623
    move-result-object v6

    .line 624
    if-nez v5, :cond_13

    .line 625
    .line 626
    if-ne v6, v9, :cond_14

    .line 627
    .line 628
    :cond_13
    new-instance v6, LA1/c;

    .line 629
    .line 630
    const/4 v5, 0x6

    .line 631
    invoke-direct {v6, v5, v12, v4}, LA1/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 632
    .line 633
    .line 634
    invoke-virtual {v2, v6}, LI/r;->d0(Ljava/lang/Object;)V

    .line 635
    .line 636
    .line 637
    :cond_14
    check-cast v6, LU1/a;

    .line 638
    .line 639
    invoke-virtual {v2, v3}, LI/r;->e(Ljava/lang/Object;)Z

    .line 640
    .line 641
    .line 642
    move-result v5

    .line 643
    invoke-virtual {v2}, LI/r;->K()Ljava/lang/Object;

    .line 644
    .line 645
    .line 646
    move-result-object v7

    .line 647
    if-nez v5, :cond_15

    .line 648
    .line 649
    if-ne v7, v9, :cond_16

    .line 650
    .line 651
    :cond_15
    new-instance v7, LH/p0;

    .line 652
    .line 653
    invoke-direct {v7, v3, v4, v11}, LH/p0;-><init>(LT0/c;LI/b0;I)V

    .line 654
    .line 655
    .line 656
    invoke-virtual {v2, v7}, LI/r;->d0(Ljava/lang/Object;)V

    .line 657
    .line 658
    .line 659
    :cond_16
    check-cast v7, LU1/c;

    .line 660
    .line 661
    sget-object v3, LH/U;->a:Ll/k;

    .line 662
    .line 663
    new-instance v3, LH/O;

    .line 664
    .line 665
    invoke-direct {v3, v6, v7, v11}, LH/O;-><init>(Ljava/lang/Object;LJ1/c;I)V

    .line 666
    .line 667
    .line 668
    invoke-static {v1, v3}, LW/a;->a(LW/q;LU1/f;)LW/q;

    .line 669
    .line 670
    .line 671
    move-result-object v1

    .line 672
    invoke-virtual {v2, v11}, LI/r;->p(Z)V

    .line 673
    .line 674
    .line 675
    return-object v1

    .line 676
    :pswitch_7
    check-cast v12, LF/l;

    .line 677
    .line 678
    move-object/from16 v1, p1

    .line 679
    .line 680
    check-cast v1, Ljava/lang/Integer;

    .line 681
    .line 682
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 683
    .line 684
    .line 685
    move-result v1

    .line 686
    move-object/from16 v3, p2

    .line 687
    .line 688
    check-cast v3, Ljava/lang/Integer;

    .line 689
    .line 690
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 691
    .line 692
    .line 693
    move-result v3

    .line 694
    move-object/from16 v4, p3

    .line 695
    .line 696
    check-cast v4, Ljava/lang/Boolean;

    .line 697
    .line 698
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 699
    .line 700
    .line 701
    move-result v4

    .line 702
    if-eqz v4, :cond_17

    .line 703
    .line 704
    goto :goto_2

    .line 705
    :cond_17
    iget-object v9, v12, LF/l;->y:LM0/q;

    .line 706
    .line 707
    invoke-interface {v9, v1}, LM0/q;->m(I)I

    .line 708
    .line 709
    .line 710
    move-result v1

    .line 711
    :goto_2
    if-eqz v4, :cond_18

    .line 712
    .line 713
    goto :goto_3

    .line 714
    :cond_18
    iget-object v9, v12, LF/l;->y:LM0/q;

    .line 715
    .line 716
    invoke-interface {v9, v3}, LM0/q;->m(I)I

    .line 717
    .line 718
    .line 719
    move-result v3

    .line 720
    :goto_3
    iget-boolean v9, v12, LF/l;->w:Z

    .line 721
    .line 722
    if-nez v9, :cond_19

    .line 723
    .line 724
    goto :goto_4

    .line 725
    :cond_19
    iget-object v9, v12, LF/l;->u:LM0/x;

    .line 726
    .line 727
    iget-wide v9, v9, LM0/x;->b:J

    .line 728
    .line 729
    sget v13, LH0/N;->c:I

    .line 730
    .line 731
    shr-long v13, v9, v7

    .line 732
    .line 733
    long-to-int v7, v13

    .line 734
    if-ne v1, v7, :cond_1a

    .line 735
    .line 736
    and-long/2addr v5, v9

    .line 737
    long-to-int v5, v5

    .line 738
    if-ne v3, v5, :cond_1a

    .line 739
    .line 740
    :goto_4
    move v2, v11

    .line 741
    goto :goto_7

    .line 742
    :cond_1a
    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    .line 743
    .line 744
    .line 745
    move-result v5

    .line 746
    sget-object v6, Lw/H;->d:Lw/H;

    .line 747
    .line 748
    if-ltz v5, :cond_1d

    .line 749
    .line 750
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 751
    .line 752
    .line 753
    move-result v5

    .line 754
    iget-object v7, v12, LF/l;->u:LM0/x;

    .line 755
    .line 756
    iget-object v7, v7, LM0/x;->a:LH0/g;

    .line 757
    .line 758
    iget-object v7, v7, LH0/g;->e:Ljava/lang/String;

    .line 759
    .line 760
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 761
    .line 762
    .line 763
    move-result v7

    .line 764
    if-gt v5, v7, :cond_1d

    .line 765
    .line 766
    if-nez v4, :cond_1c

    .line 767
    .line 768
    if-ne v1, v3, :cond_1b

    .line 769
    .line 770
    goto :goto_5

    .line 771
    :cond_1b
    iget-object v4, v12, LF/l;->z:LH/m0;

    .line 772
    .line 773
    invoke-virtual {v4, v2}, LH/m0;->h(Z)V

    .line 774
    .line 775
    .line 776
    goto :goto_6

    .line 777
    :cond_1c
    :goto_5
    iget-object v4, v12, LF/l;->z:LH/m0;

    .line 778
    .line 779
    invoke-virtual {v4, v11}, LH/m0;->t(Z)V

    .line 780
    .line 781
    .line 782
    invoke-virtual {v4, v6}, LH/m0;->q(Lw/H;)V

    .line 783
    .line 784
    .line 785
    :goto_6
    iget-object v4, v12, LF/l;->v:Lw/S;

    .line 786
    .line 787
    iget-object v4, v4, Lw/S;->v:Lw/p;

    .line 788
    .line 789
    new-instance v5, LM0/x;

    .line 790
    .line 791
    iget-object v6, v12, LF/l;->u:LM0/x;

    .line 792
    .line 793
    iget-object v6, v6, LM0/x;->a:LH0/g;

    .line 794
    .line 795
    invoke-static {v1, v3}, LH0/F;->b(II)J

    .line 796
    .line 797
    .line 798
    move-result-wide v9

    .line 799
    invoke-direct {v5, v6, v9, v10, v8}, LM0/x;-><init>(LH0/g;JLH0/N;)V

    .line 800
    .line 801
    .line 802
    invoke-virtual {v4, v5}, Lw/p;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 803
    .line 804
    .line 805
    goto :goto_7

    .line 806
    :cond_1d
    iget-object v1, v12, LF/l;->z:LH/m0;

    .line 807
    .line 808
    invoke-virtual {v1, v11}, LH/m0;->t(Z)V

    .line 809
    .line 810
    .line 811
    invoke-virtual {v1, v6}, LH/m0;->q(Lw/H;)V

    .line 812
    .line 813
    .line 814
    goto :goto_4

    .line 815
    :goto_7
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 816
    .line 817
    .line 818
    move-result-object v1

    .line 819
    return-object v1

    .line 820
    :pswitch_8
    check-cast v12, Ljava/lang/String;

    .line 821
    .line 822
    move-object/from16 v1, p1

    .line 823
    .line 824
    check-cast v1, LU1/e;

    .line 825
    .line 826
    move-object/from16 v3, p2

    .line 827
    .line 828
    check-cast v3, LI/r;

    .line 829
    .line 830
    move-object/from16 v5, p3

    .line 831
    .line 832
    check-cast v5, Ljava/lang/Integer;

    .line 833
    .line 834
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 835
    .line 836
    .line 837
    move-result v5

    .line 838
    const-string v6, "inner"

    .line 839
    .line 840
    invoke-static {v1, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 841
    .line 842
    .line 843
    and-int/lit8 v6, v5, 0x6

    .line 844
    .line 845
    if-nez v6, :cond_1f

    .line 846
    .line 847
    invoke-virtual {v3, v1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 848
    .line 849
    .line 850
    move-result v6

    .line 851
    if-eqz v6, :cond_1e

    .line 852
    .line 853
    goto :goto_8

    .line 854
    :cond_1e
    const/4 v4, 0x2

    .line 855
    :goto_8
    or-int/2addr v5, v4

    .line 856
    :cond_1f
    and-int/lit8 v4, v5, 0x13

    .line 857
    .line 858
    const/16 v6, 0x12

    .line 859
    .line 860
    if-eq v4, v6, :cond_20

    .line 861
    .line 862
    goto :goto_9

    .line 863
    :cond_20
    move v2, v11

    .line 864
    :goto_9
    and-int/lit8 v4, v5, 0x1

    .line 865
    .line 866
    invoke-virtual {v3, v4, v2}, LI/r;->N(IZ)Z

    .line 867
    .line 868
    .line 869
    move-result v2

    .line 870
    if-eqz v2, :cond_22

    .line 871
    .line 872
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 873
    .line 874
    .line 875
    move-result v2

    .line 876
    if-nez v2, :cond_21

    .line 877
    .line 878
    const v2, 0x12dcdf45

    .line 879
    .line 880
    .line 881
    invoke-virtual {v3, v2}, LI/r;->U(I)V

    .line 882
    .line 883
    .line 884
    new-instance v12, LH0/O;

    .line 885
    .line 886
    sget-wide v6, Ld0/w;->c:J

    .line 887
    .line 888
    const v2, 0x3eb33333    # 0.35f

    .line 889
    .line 890
    .line 891
    invoke-static {v6, v7, v2}, Ld0/w;->b(JF)J

    .line 892
    .line 893
    .line 894
    move-result-wide v13

    .line 895
    const/16 v2, 0xf

    .line 896
    .line 897
    invoke-static {v2}, LT0/g;->z(I)J

    .line 898
    .line 899
    .line 900
    move-result-wide v15

    .line 901
    const-wide/16 v21, 0x0

    .line 902
    .line 903
    const v23, 0xfffffc

    .line 904
    .line 905
    .line 906
    const/16 v17, 0x0

    .line 907
    .line 908
    const-wide/16 v18, 0x0

    .line 909
    .line 910
    const/16 v20, 0x0

    .line 911
    .line 912
    invoke-direct/range {v12 .. v23}, LH0/O;-><init>(JJLL0/k;JIJI)V

    .line 913
    .line 914
    .line 915
    const/16 v21, 0x186

    .line 916
    .line 917
    const/16 v22, 0x3fa

    .line 918
    .line 919
    const-string v13, "Enter your license key"

    .line 920
    .line 921
    const/4 v14, 0x0

    .line 922
    const/16 v16, 0x0

    .line 923
    .line 924
    const/16 v17, 0x0

    .line 925
    .line 926
    const/16 v18, 0x0

    .line 927
    .line 928
    const/16 v19, 0x0

    .line 929
    .line 930
    move-object/from16 v20, v3

    .line 931
    .line 932
    move-object v15, v12

    .line 933
    invoke-static/range {v13 .. v22}, Lw/O;->a(Ljava/lang/String;LW/q;LH0/O;IZIILI/r;II)V

    .line 934
    .line 935
    .line 936
    move-object/from16 v2, v20

    .line 937
    .line 938
    invoke-virtual {v2, v11}, LI/r;->p(Z)V

    .line 939
    .line 940
    .line 941
    goto :goto_a

    .line 942
    :cond_21
    move-object v2, v3

    .line 943
    const v3, 0x12e02464

    .line 944
    .line 945
    .line 946
    invoke-virtual {v2, v3}, LI/r;->U(I)V

    .line 947
    .line 948
    .line 949
    invoke-virtual {v2, v11}, LI/r;->p(Z)V

    .line 950
    .line 951
    .line 952
    :goto_a
    and-int/lit8 v3, v5, 0xe

    .line 953
    .line 954
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 955
    .line 956
    .line 957
    move-result-object v3

    .line 958
    invoke-interface {v1, v2, v3}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 959
    .line 960
    .line 961
    goto :goto_b

    .line 962
    :cond_22
    move-object v2, v3

    .line 963
    invoke-virtual {v2}, LI/r;->Q()V

    .line 964
    .line 965
    .line 966
    :goto_b
    return-object v10

    .line 967
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
