.class public final LB/h;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic h:I

.field public i:I

.field public final synthetic j:LD/f;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LD/f;Ljava/lang/Object;LN1/c;I)V
    .locals 0

    .line 1
    iput p4, p0, LB/h;->h:I

    iput-object p1, p0, LB/h;->j:LD/f;

    iput-object p2, p0, LB/h;->k:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LB/h;->h:I

    .line 2
    .line 3
    check-cast p1, LN1/c;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v0, LB/h;

    .line 9
    .line 10
    iget-object v1, p0, LB/h;->j:LD/f;

    .line 11
    .line 12
    check-cast v1, LD/c;

    .line 13
    .line 14
    iget-object v2, p0, LB/h;->k:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, LD/b;

    .line 17
    .line 18
    const/4 v3, 0x1

    .line 19
    invoke-direct {v0, v1, v2, p1, v3}, LB/h;-><init>(LD/f;Ljava/lang/Object;LN1/c;I)V

    .line 20
    .line 21
    .line 22
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, LB/h;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1

    .line 29
    :pswitch_0
    new-instance v0, LB/h;

    .line 30
    .line 31
    iget-object v1, p0, LB/h;->j:LD/f;

    .line 32
    .line 33
    check-cast v1, LB/i;

    .line 34
    .line 35
    iget-object v2, p0, LB/h;->k:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v2, LD/e;

    .line 38
    .line 39
    const/4 v3, 0x0

    .line 40
    invoke-direct {v0, v1, v2, p1, v3}, LB/h;-><init>(LD/f;Ljava/lang/Object;LN1/c;I)V

    .line 41
    .line 42
    .line 43
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 44
    .line 45
    invoke-virtual {v0, p1}, LB/h;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    return-object p1

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, LB/h;->h:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB/h;->k:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LD/b;

    .line 9
    .line 10
    iget-object v1, p0, LB/h;->j:LD/f;

    .line 11
    .line 12
    check-cast v1, LD/c;

    .line 13
    .line 14
    iget-object v1, v1, LD/c;->c:LI/m0;

    .line 15
    .line 16
    iget v2, p0, LB/h;->i:I

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    sget-object v4, LJ1/m;->a:LJ1/m;

    .line 20
    .line 21
    const/4 v5, 0x1

    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    if-ne v2, v5, :cond_0

    .line 25
    .line 26
    :try_start_0
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    .line 28
    .line 29
    goto :goto_1

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_3

    .line 32
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 33
    .line 34
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 35
    .line 36
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw p1

    .line 40
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :try_start_1
    invoke-virtual {v1, v0}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput v5, p0, LB/h;->i:I

    .line 47
    .line 48
    iget-object p1, v0, LD/b;->b:Le2/c;

    .line 49
    .line 50
    invoke-virtual {p1, p0}, Le2/c;->p(LN1/c;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 54
    sget-object v0, LO1/a;->d:LO1/a;

    .line 55
    .line 56
    if-ne p1, v0, :cond_2

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_2
    move-object p1, v4

    .line 60
    :goto_0
    if-ne p1, v0, :cond_3

    .line 61
    .line 62
    move-object v4, v0

    .line 63
    goto :goto_2

    .line 64
    :cond_3
    :goto_1
    invoke-virtual {v1, v3}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :goto_2
    return-object v4

    .line 68
    :goto_3
    invoke-virtual {v1, v3}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    throw p1

    .line 72
    :pswitch_0
    iget-object v0, p0, LB/h;->j:LD/f;

    .line 73
    .line 74
    check-cast v0, LB/i;

    .line 75
    .line 76
    iget-object v1, v0, LB/i;->e:LU/w;

    .line 77
    .line 78
    iget-object v2, v0, LB/i;->a:Landroid/view/View;

    .line 79
    .line 80
    iget v3, p0, LB/h;->i:I

    .line 81
    .line 82
    sget-object v4, LJ1/m;->a:LJ1/m;

    .line 83
    .line 84
    const/4 v5, 0x1

    .line 85
    const/4 v6, 0x0

    .line 86
    if-eqz v3, :cond_5

    .line 87
    .line 88
    if-ne v3, v5, :cond_4

    .line 89
    .line 90
    :try_start_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 91
    .line 92
    .line 93
    goto/16 :goto_8

    .line 94
    .line 95
    :catchall_1
    move-exception p1

    .line 96
    goto/16 :goto_c

    .line 97
    .line 98
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 99
    .line 100
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 101
    .line 102
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    throw p1

    .line 106
    :cond_5
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    new-instance p1, LB/f;

    .line 110
    .line 111
    invoke-direct {p1}, LB/f;-><init>()V

    .line 112
    .line 113
    .line 114
    iget-object v3, p0, LB/h;->k:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v3, LD/e;

    .line 117
    .line 118
    new-instance v7, LB/e;

    .line 119
    .line 120
    new-instance v8, LB/b;

    .line 121
    .line 122
    const/4 v9, 0x0

    .line 123
    invoke-direct {v8, v0, v3, v9}, LB/b;-><init>(LB/i;LD/e;I)V

    .line 124
    .line 125
    .line 126
    new-instance v9, LB/b;

    .line 127
    .line 128
    const/4 v10, 0x1

    .line 129
    invoke-direct {v9, v0, v3, v10}, LB/b;-><init>(LB/i;LD/e;I)V

    .line 130
    .line 131
    .line 132
    invoke-direct {v7, p1, v8, v9, v2}, LB/e;-><init>(LB/f;LB/b;LB/b;Landroid/view/View;)V

    .line 133
    .line 134
    .line 135
    iget-object v3, v0, LB/i;->b:LU1/c;

    .line 136
    .line 137
    if-eqz v3, :cond_7

    .line 138
    .line 139
    invoke-interface {v3, v7}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    check-cast v3, LB/e;

    .line 144
    .line 145
    if-nez v3, :cond_6

    .line 146
    .line 147
    goto :goto_4

    .line 148
    :cond_6
    move-object v7, v3

    .line 149
    :cond_7
    :goto_4
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 154
    .line 155
    .line 156
    move-result-object v8

    .line 157
    if-eqz v8, :cond_8

    .line 158
    .line 159
    invoke-virtual {v8}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 160
    .line 161
    .line 162
    move-result-object v8

    .line 163
    goto :goto_5

    .line 164
    :cond_8
    move-object v8, v6

    .line 165
    :goto_5
    if-eq v3, v8, :cond_a

    .line 166
    .line 167
    iget-object v3, v0, LB/i;->i:LB/g;

    .line 168
    .line 169
    if-nez v3, :cond_9

    .line 170
    .line 171
    new-instance v3, LB/g;

    .line 172
    .line 173
    const/4 v8, 0x0

    .line 174
    invoke-direct {v3, v0, v7, p1, v8}, LB/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 175
    .line 176
    .line 177
    iput-object v3, v0, LB/i;->i:LB/g;

    .line 178
    .line 179
    :cond_9
    invoke-virtual {v2, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 180
    .line 181
    .line 182
    goto :goto_6

    .line 183
    :cond_a
    new-instance v3, LB/u;

    .line 184
    .line 185
    invoke-direct {v3, v7}, LB/u;-><init>(LB/e;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v2, v3, v5}, Landroid/view/View;->startActionMode(Landroid/view/ActionMode$Callback;I)Landroid/view/ActionMode;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    if-nez v3, :cond_b

    .line 193
    .line 194
    goto :goto_b

    .line 195
    :cond_b
    iput-object v3, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 196
    .line 197
    :goto_6
    :try_start_3
    iput v5, p0, LB/h;->i:I

    .line 198
    .line 199
    iget-object p1, p1, LB/f;->a:Le2/c;

    .line 200
    .line 201
    invoke-virtual {p1, p0}, Le2/c;->p(LN1/c;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 205
    sget-object v3, LO1/a;->d:LO1/a;

    .line 206
    .line 207
    if-ne p1, v3, :cond_c

    .line 208
    .line 209
    goto :goto_7

    .line 210
    :cond_c
    move-object p1, v4

    .line 211
    :goto_7
    if-ne p1, v3, :cond_d

    .line 212
    .line 213
    move-object v4, v3

    .line 214
    goto :goto_b

    .line 215
    :cond_d
    :goto_8
    invoke-virtual {v1}, LU/w;->a()V

    .line 216
    .line 217
    .line 218
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    if-eqz v1, :cond_e

    .line 227
    .line 228
    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    goto :goto_9

    .line 233
    :cond_e
    move-object v1, v6

    .line 234
    :goto_9
    if-eq p1, v1, :cond_10

    .line 235
    .line 236
    iget-object p1, v0, LB/i;->j:Ljava/lang/Runnable;

    .line 237
    .line 238
    if-nez p1, :cond_f

    .line 239
    .line 240
    new-instance p1, LA1/g;

    .line 241
    .line 242
    const/4 v1, 0x3

    .line 243
    invoke-direct {p1, v1, v0}, LA1/g;-><init>(ILjava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    iput-object p1, v0, LB/i;->j:Ljava/lang/Runnable;

    .line 247
    .line 248
    :cond_f
    invoke-virtual {v2, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 249
    .line 250
    .line 251
    goto :goto_a

    .line 252
    :cond_10
    iget-object p1, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 253
    .line 254
    if-eqz p1, :cond_11

    .line 255
    .line 256
    invoke-virtual {p1}, Landroid/view/ActionMode;->finish()V

    .line 257
    .line 258
    .line 259
    :cond_11
    :goto_a
    iget-object p1, v0, LB/i;->i:LB/g;

    .line 260
    .line 261
    if-eqz p1, :cond_12

    .line 262
    .line 263
    invoke-virtual {v2, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 264
    .line 265
    .line 266
    :cond_12
    iput-object v6, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 267
    .line 268
    :goto_b
    return-object v4

    .line 269
    :goto_c
    invoke-virtual {v1}, LU/w;->a()V

    .line 270
    .line 271
    .line 272
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 277
    .line 278
    .line 279
    move-result-object v3

    .line 280
    if-eqz v3, :cond_13

    .line 281
    .line 282
    invoke-virtual {v3}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 283
    .line 284
    .line 285
    move-result-object v3

    .line 286
    goto :goto_d

    .line 287
    :cond_13
    move-object v3, v6

    .line 288
    :goto_d
    if-eq v1, v3, :cond_15

    .line 289
    .line 290
    iget-object v1, v0, LB/i;->j:Ljava/lang/Runnable;

    .line 291
    .line 292
    if-nez v1, :cond_14

    .line 293
    .line 294
    new-instance v1, LA1/g;

    .line 295
    .line 296
    const/4 v3, 0x3

    .line 297
    invoke-direct {v1, v3, v0}, LA1/g;-><init>(ILjava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    iput-object v1, v0, LB/i;->j:Ljava/lang/Runnable;

    .line 301
    .line 302
    :cond_14
    invoke-virtual {v2, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 303
    .line 304
    .line 305
    goto :goto_e

    .line 306
    :cond_15
    iget-object v1, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 307
    .line 308
    if-eqz v1, :cond_16

    .line 309
    .line 310
    invoke-virtual {v1}, Landroid/view/ActionMode;->finish()V

    .line 311
    .line 312
    .line 313
    :cond_16
    :goto_e
    iget-object v1, v0, LB/i;->i:LB/g;

    .line 314
    .line 315
    if-eqz v1, :cond_17

    .line 316
    .line 317
    invoke-virtual {v2, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 318
    .line 319
    .line 320
    :cond_17
    iput-object v6, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 321
    .line 322
    throw p1

    .line 323
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
