.class public final LB/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/f;


# instance fields
.field public final a:Landroid/view/View;

.field public final b:LU1/c;

.field public final c:LU1/a;

.field public final d:Ln/d0;

.field public final e:LU/w;

.field public final f:LB/a;

.field public final g:LB/a;

.field public h:Landroid/view/ActionMode;

.field public i:LB/g;

.field public j:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/view/View;LU1/c;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB/i;->a:Landroid/view/View;

    .line 5
    .line 6
    iput-object p2, p0, LB/i;->b:LU1/c;

    .line 7
    .line 8
    iput-object p3, p0, LB/i;->c:LU1/a;

    .line 9
    .line 10
    new-instance p1, Ln/d0;

    .line 11
    .line 12
    invoke-direct {p1}, Ln/d0;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, LB/i;->d:Ln/d0;

    .line 16
    .line 17
    new-instance p1, LU/w;

    .line 18
    .line 19
    new-instance p2, LB/a;

    .line 20
    .line 21
    const/4 p3, 0x0

    .line 22
    invoke-direct {p2, p0, p3}, LB/a;-><init>(LB/i;I)V

    .line 23
    .line 24
    .line 25
    invoke-direct {p1, p2}, LU/w;-><init>(LU1/c;)V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, LB/i;->e:LU/w;

    .line 29
    .line 30
    new-instance p1, LB/a;

    .line 31
    .line 32
    const/4 p2, 0x1

    .line 33
    invoke-direct {p1, p0, p2}, LB/a;-><init>(LB/i;I)V

    .line 34
    .line 35
    .line 36
    iput-object p1, p0, LB/i;->f:LB/a;

    .line 37
    .line 38
    new-instance p1, LB/a;

    .line 39
    .line 40
    const/4 p2, 0x2

    .line 41
    invoke-direct {p1, p0, p2}, LB/a;-><init>(LB/i;I)V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, LB/i;->g:LB/a;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final a(LD/e;LP1/i;)Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, LB/h;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    invoke-direct {v0, p0, p1, v1, v2}, LB/h;-><init>(LD/f;Ljava/lang/Object;LN1/c;I)V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, LB/i;->d:Ln/d0;

    .line 9
    .line 10
    invoke-static {p1, v0, p2}, Ln/d0;->b(Ln/d0;LU1/c;LP1/i;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object p2, LO1/a;->d:LO1/a;

    .line 15
    .line 16
    if-ne p1, p2, :cond_0

    .line 17
    .line 18
    return-object p1

    .line 19
    :cond_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 20
    .line 21
    return-object p1
.end method
