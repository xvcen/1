.class public final synthetic LB/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LW/q;LH/m0;LQ/f;I)V
    .locals 0

    .line 1
    const/4 p4, 0x2

    iput p4, p0, LB/k;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB/k;->e:Ljava/lang/Object;

    iput-object p2, p0, LB/k;->f:Ljava/lang/Object;

    iput-object p3, p0, LB/k;->g:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p4, p0, LB/k;->d:I

    iput-object p1, p0, LB/k;->e:Ljava/lang/Object;

    iput-object p2, p0, LB/k;->f:Ljava/lang/Object;

    iput-object p3, p0, LB/k;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LB/k;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB/k;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LW/q;

    .line 9
    .line 10
    iget-object v1, p0, LB/k;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LH/m0;

    .line 13
    .line 14
    iget-object v2, p0, LB/k;->g:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, LQ/f;

    .line 17
    .line 18
    check-cast p1, LI/r;

    .line 19
    .line 20
    check-cast p2, Ljava/lang/Integer;

    .line 21
    .line 22
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    const/16 p2, 0x181

    .line 26
    .line 27
    invoke-static {p2}, LI/k;->x(I)I

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    invoke-static {v0, v1, v2, p1, p2}, Lw/O;->e(LW/q;LH/m0;LQ/f;LI/r;I)V

    .line 32
    .line 33
    .line 34
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 35
    .line 36
    return-object p1

    .line 37
    :pswitch_0
    iget-object v0, p0, LB/k;->e:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, LV1/p;

    .line 40
    .line 41
    iget-object v1, p0, LB/k;->f:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v1, Lp/S0;

    .line 44
    .line 45
    iget-object v2, p0, LB/k;->g:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v2, Lp/P0;

    .line 48
    .line 49
    check-cast p1, Ljava/lang/Float;

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    check-cast p2, Ljava/lang/Float;

    .line 56
    .line 57
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    iget p2, v0, LV1/p;->d:F

    .line 61
    .line 62
    sub-float/2addr p1, p2

    .line 63
    invoke-virtual {v1, p1}, Lp/S0;->d(F)F

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    invoke-virtual {v1, p1}, Lp/S0;->h(F)J

    .line 68
    .line 69
    .line 70
    move-result-wide p1

    .line 71
    iget-object v2, v2, Lp/P0;->a:Lp/S0;

    .line 72
    .line 73
    iget-object v3, v2, Lp/S0;->k:Lp/r0;

    .line 74
    .line 75
    const/4 v4, 0x1

    .line 76
    invoke-virtual {v2, v3, p1, p2, v4}, Lp/S0;->c(Lp/r0;JI)J

    .line 77
    .line 78
    .line 79
    move-result-wide p1

    .line 80
    invoke-virtual {v1, p1, p2}, Lp/S0;->g(J)F

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    invoke-virtual {v1, p1}, Lp/S0;->d(F)F

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    iget p2, v0, LV1/p;->d:F

    .line 89
    .line 90
    add-float/2addr p2, p1

    .line 91
    iput p2, v0, LV1/p;->d:F

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :pswitch_1
    iget-object v0, p0, LB/k;->e:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v0, LW/q;

    .line 97
    .line 98
    iget-object v1, p0, LB/k;->f:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v1, LI/b0;

    .line 101
    .line 102
    iget-object v2, p0, LB/k;->g:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v2, LQ/f;

    .line 105
    .line 106
    check-cast p1, LI/r;

    .line 107
    .line 108
    check-cast p2, Ljava/lang/Integer;

    .line 109
    .line 110
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 111
    .line 112
    .line 113
    move-result p2

    .line 114
    and-int/lit8 v3, p2, 0x3

    .line 115
    .line 116
    const/4 v4, 0x2

    .line 117
    const/4 v5, 0x0

    .line 118
    const/4 v6, 0x1

    .line 119
    if-eq v3, v4, :cond_0

    .line 120
    .line 121
    move v3, v6

    .line 122
    goto :goto_1

    .line 123
    :cond_0
    move v3, v5

    .line 124
    :goto_1
    and-int/2addr p2, v6

    .line 125
    invoke-virtual {p1, p2, v3}, LI/r;->N(IZ)Z

    .line 126
    .line 127
    .line 128
    move-result p2

    .line 129
    if-eqz p2, :cond_3

    .line 130
    .line 131
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object p2

    .line 135
    sget-object v3, LI/m;->a:LI/h;

    .line 136
    .line 137
    if-ne p2, v3, :cond_1

    .line 138
    .line 139
    new-instance p2, LA1/a;

    .line 140
    .line 141
    const/4 v3, 0x5

    .line 142
    invoke-direct {p2, v1, v3}, LA1/a;-><init>(LI/b0;I)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {p1, p2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_1
    check-cast p2, LU1/c;

    .line 149
    .line 150
    invoke-static {v0, p2}, Lu0/v;->h(LW/q;LU1/c;)LW/q;

    .line 151
    .line 152
    .line 153
    move-result-object p2

    .line 154
    sget-object v0, LW/c;->d:LW/h;

    .line 155
    .line 156
    invoke-static {v0, v6}, Ls/j;->d(LW/h;Z)Lu0/z;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    iget-wide v3, p1, LI/r;->R:J

    .line 161
    .line 162
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    invoke-virtual {p1}, LI/r;->k()LI/q0;

    .line 167
    .line 168
    .line 169
    move-result-object v3

    .line 170
    invoke-static {p1, p2}, LW/a;->c(LI/r;LW/q;)LW/q;

    .line 171
    .line 172
    .line 173
    move-result-object p2

    .line 174
    sget-object v4, Lw0/f;->c:Lw0/e;

    .line 175
    .line 176
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    .line 178
    .line 179
    sget-object v4, Lw0/e;->b:Lw0/x;

    .line 180
    .line 181
    invoke-virtual {p1}, LI/r;->W()V

    .line 182
    .line 183
    .line 184
    iget-boolean v7, p1, LI/r;->Q:Z

    .line 185
    .line 186
    if-eqz v7, :cond_2

    .line 187
    .line 188
    invoke-virtual {p1, v4}, LI/r;->j(LU1/a;)V

    .line 189
    .line 190
    .line 191
    goto :goto_2

    .line 192
    :cond_2
    invoke-virtual {p1}, LI/r;->g0()V

    .line 193
    .line 194
    .line 195
    :goto_2
    sget-object v4, Lw0/e;->e:Lw0/d;

    .line 196
    .line 197
    invoke-static {p1, v4, v0}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    sget-object v0, Lw0/e;->d:Lw0/d;

    .line 201
    .line 202
    invoke-static {p1, v0, v3}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 203
    .line 204
    .line 205
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    sget-object v1, Lw0/e;->f:Lw0/d;

    .line 210
    .line 211
    invoke-static {p1, v0, v1}, LI/k;->o(LI/r;Ljava/lang/Integer;LU1/e;)V

    .line 212
    .line 213
    .line 214
    sget-object v0, Lw0/e;->g:Lw0/c;

    .line 215
    .line 216
    invoke-static {p1, v0}, LI/k;->s(LI/r;LU1/c;)V

    .line 217
    .line 218
    .line 219
    sget-object v0, Lw0/e;->c:Lw0/d;

    .line 220
    .line 221
    invoke-static {p1, v0, p2}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 225
    .line 226
    .line 227
    move-result-object p2

    .line 228
    invoke-virtual {v2, p1, p2}, LQ/f;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    invoke-virtual {p1, v6}, LI/r;->p(Z)V

    .line 232
    .line 233
    .line 234
    goto :goto_3

    .line 235
    :cond_3
    invoke-virtual {p1}, LI/r;->Q()V

    .line 236
    .line 237
    .line 238
    :goto_3
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 239
    .line 240
    return-object p1

    .line 241
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
