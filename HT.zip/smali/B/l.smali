.class public final LB/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI/H;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LB/l;->a:I

    iput-object p2, p0, LB/l;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    iget v0, p0, LB/l;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lx0/k0;

    .line 9
    .line 10
    iget-object v0, v0, Lx0/k0;->b:Lx0/l0;

    .line 11
    .line 12
    invoke-virtual {v0}, Lx0/l0;->a()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, LI/b0;

    .line 19
    .line 20
    invoke-interface {v0}, LI/a1;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Lq/i;

    .line 25
    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-interface {v0, v1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :cond_0
    return-void

    .line 33
    :pswitch_1
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, LH/m0;

    .line 36
    .line 37
    invoke-virtual {v0}, LH/m0;->o()V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_2
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Ll/U;

    .line 44
    .line 45
    invoke-virtual {v0}, Ll/U;->i()V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_3
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v0, LW0/v;

    .line 52
    .line 53
    iget-object v1, v0, Lx0/a;->f:Lx0/b1;

    .line 54
    .line 55
    if-eqz v1, :cond_1

    .line 56
    .line 57
    invoke-virtual {v1}, Lx0/b1;->c()V

    .line 58
    .line 59
    .line 60
    :cond_1
    const/4 v1, 0x0

    .line 61
    iput-object v1, v0, Lx0/a;->f:Lx0/b1;

    .line 62
    .line 63
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 64
    .line 65
    .line 66
    const v2, 0x7f050074

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0, v2, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    iget-object v1, v0, LW0/v;->r:Landroid/view/WindowManager;

    .line 73
    .line 74
    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :pswitch_4
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, LD/c;

    .line 81
    .line 82
    iget-object v0, v0, LD/c;->c:LI/m0;

    .line 83
    .line 84
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    check-cast v0, LD/b;

    .line 89
    .line 90
    if-eqz v0, :cond_2

    .line 91
    .line 92
    invoke-virtual {v0}, LD/b;->close()V

    .line 93
    .line 94
    .line 95
    :cond_2
    return-void

    .line 96
    :pswitch_5
    iget-object v0, p0, LB/l;->b:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v0, LB/i;

    .line 99
    .line 100
    iget-object v1, v0, LB/i;->e:LU/w;

    .line 101
    .line 102
    iget-object v2, v1, LU/w;->h:LU/f;

    .line 103
    .line 104
    if-eqz v2, :cond_3

    .line 105
    .line 106
    invoke-virtual {v2}, LU/f;->a()V

    .line 107
    .line 108
    .line 109
    :cond_3
    invoke-virtual {v1}, LU/w;->a()V

    .line 110
    .line 111
    .line 112
    iget-object v1, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 113
    .line 114
    if-eqz v1, :cond_4

    .line 115
    .line 116
    invoke-virtual {v1}, Landroid/view/ActionMode;->finish()V

    .line 117
    .line 118
    .line 119
    :cond_4
    const/4 v1, 0x0

    .line 120
    iput-object v1, v0, LB/i;->h:Landroid/view/ActionMode;

    .line 121
    .line 122
    return-void

    .line 123
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
