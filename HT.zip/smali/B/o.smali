.class public final synthetic LB/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:J

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(IJII)V
    .locals 0

    .line 1
    iput p5, p0, LB/o;->d:I

    iput p1, p0, LB/o;->e:I

    iput-wide p2, p0, LB/o;->f:J

    iput p4, p0, LB/o;->g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LB/o;->d:I

    .line 2
    .line 3
    check-cast p1, LI/r;

    .line 4
    .line 5
    check-cast p2, Ljava/lang/Integer;

    .line 6
    .line 7
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    iget p2, p0, LB/o;->g:I

    .line 14
    .line 15
    or-int/lit8 p2, p2, 0x1

    .line 16
    .line 17
    invoke-static {p2}, LI/k;->x(I)I

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    iget v0, p0, LB/o;->e:I

    .line 22
    .line 23
    iget-wide v1, p0, LB/o;->f:J

    .line 24
    .line 25
    invoke-static {v0, v1, v2, p1, p2}, LB/t;->b(IJLI/r;I)V

    .line 26
    .line 27
    .line 28
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 29
    .line 30
    return-object p1

    .line 31
    :pswitch_0
    iget p2, p0, LB/o;->g:I

    .line 32
    .line 33
    or-int/lit8 p2, p2, 0x1

    .line 34
    .line 35
    invoke-static {p2}, LI/k;->x(I)I

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    iget v0, p0, LB/o;->e:I

    .line 40
    .line 41
    iget-wide v1, p0, LB/o;->f:J

    .line 42
    .line 43
    invoke-static {v0, v1, v2, p1, p2}, LB/t;->b(IJLI/r;I)V

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
