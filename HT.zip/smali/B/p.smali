.class public final synthetic LB/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LB/p;->d:I

    iput-object p3, p0, LB/p;->f:Ljava/lang/Object;

    iput-object p4, p0, LB/p;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LB/p;->d:I

    iput-object p2, p0, LB/p;->f:Ljava/lang/Object;

    iput-object p3, p0, LB/p;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lz/g;Lz/c;I)V
    .locals 0

    .line 3
    const/4 p3, 0x1

    iput p3, p0, LB/p;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB/p;->e:Ljava/lang/Object;

    iput-object p2, p0, LB/p;->f:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LB/p;->d:I

    .line 4
    .line 5
    const/16 v2, 0x31

    .line 6
    .line 7
    const/4 v4, 0x1

    .line 8
    sget-object v5, LJ1/m;->a:LJ1/m;

    .line 9
    .line 10
    iget-object v6, v0, LB/p;->e:Ljava/lang/Object;

    .line 11
    .line 12
    iget-object v7, v0, LB/p;->f:Ljava/lang/Object;

    .line 13
    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast v7, Lo/f;

    .line 18
    .line 19
    check-cast v6, Lo/d;

    .line 20
    .line 21
    move-object/from16 v1, p1

    .line 22
    .line 23
    check-cast v1, LI/r;

    .line 24
    .line 25
    move-object/from16 v2, p2

    .line 26
    .line 27
    check-cast v2, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-static {v4}, LI/k;->x(I)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    invoke-virtual {v7, v6, v1, v2}, Lo/f;->a(Lo/d;LI/r;I)V

    .line 37
    .line 38
    .line 39
    return-object v5

    .line 40
    :pswitch_0
    check-cast v7, LW/q;

    .line 41
    .line 42
    check-cast v6, LU1/c;

    .line 43
    .line 44
    move-object/from16 v1, p1

    .line 45
    .line 46
    check-cast v1, LI/r;

    .line 47
    .line 48
    move-object/from16 v2, p2

    .line 49
    .line 50
    check-cast v2, Ljava/lang/Integer;

    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    const/16 v2, 0x37

    .line 56
    .line 57
    invoke-static {v2}, LI/k;->x(I)I

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    invoke-static {v7, v6, v1, v2}, Ln/w;->a(LW/q;LU1/c;LI/r;I)V

    .line 62
    .line 63
    .line 64
    return-object v5

    .line 65
    :pswitch_1
    check-cast v7, LI/u0;

    .line 66
    .line 67
    check-cast v6, LQ/f;

    .line 68
    .line 69
    move-object/from16 v1, p1

    .line 70
    .line 71
    check-cast v1, LI/r;

    .line 72
    .line 73
    move-object/from16 v2, p2

    .line 74
    .line 75
    check-cast v2, Ljava/lang/Integer;

    .line 76
    .line 77
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 78
    .line 79
    .line 80
    const/16 v2, 0x39

    .line 81
    .line 82
    invoke-static {v2}, LI/k;->x(I)I

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    invoke-static {v7, v6, v1, v2}, LI/k;->a(LI/u0;LQ/f;LI/r;I)V

    .line 87
    .line 88
    .line 89
    return-object v5

    .line 90
    :pswitch_2
    check-cast v7, LH/m0;

    .line 91
    .line 92
    check-cast v6, Lc2/s;

    .line 93
    .line 94
    move-object/from16 v8, p1

    .line 95
    .line 96
    check-cast v8, Ly/a;

    .line 97
    .line 98
    move-object/from16 v9, p2

    .line 99
    .line 100
    check-cast v9, Landroid/content/Context;

    .line 101
    .line 102
    invoke-virtual {v7}, LH/m0;->j()Z

    .line 103
    .line 104
    .line 105
    move-result v10

    .line 106
    invoke-virtual {v7}, LH/m0;->m()LH0/g;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    if-eqz v1, :cond_0

    .line 111
    .line 112
    iget-object v1, v1, LH0/g;->e:Ljava/lang/String;

    .line 113
    .line 114
    move-object v11, v1

    .line 115
    goto :goto_0

    .line 116
    :cond_0
    const/4 v11, 0x0

    .line 117
    :goto_0
    iget-object v1, v7, LH/m0;->w:LH0/N;

    .line 118
    .line 119
    if-eqz v1, :cond_1

    .line 120
    .line 121
    iget-wide v12, v1, LH0/N;->a:J

    .line 122
    .line 123
    iget-object v1, v7, LH/m0;->b:LM0/q;

    .line 124
    .line 125
    const/16 v4, 0x20

    .line 126
    .line 127
    shr-long v14, v12, v4

    .line 128
    .line 129
    long-to-int v4, v14

    .line 130
    invoke-interface {v1, v4}, LM0/q;->n(I)I

    .line 131
    .line 132
    .line 133
    move-result v4

    .line 134
    const-wide v14, 0xffffffffL

    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    and-long/2addr v12, v14

    .line 140
    long-to-int v12, v12

    .line 141
    invoke-interface {v1, v12}, LM0/q;->n(I)I

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    invoke-static {v4, v1}, LH0/F;->b(II)J

    .line 146
    .line 147
    .line 148
    move-result-wide v12

    .line 149
    new-instance v1, LH0/N;

    .line 150
    .line 151
    invoke-direct {v1, v12, v13}, LH0/N;-><init>(J)V

    .line 152
    .line 153
    .line 154
    goto :goto_1

    .line 155
    :cond_1
    const/4 v1, 0x0

    .line 156
    :goto_1
    iget-object v4, v7, LH/m0;->j:LH/s;

    .line 157
    .line 158
    new-instance v12, LB/r;

    .line 159
    .line 160
    invoke-direct {v12, v7, v6, v9}, LB/r;-><init>(LH/m0;Lc2/s;Landroid/content/Context;)V

    .line 161
    .line 162
    .line 163
    sget-object v6, LH/u;->a:LI/b1;

    .line 164
    .line 165
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 166
    .line 167
    const/16 v7, 0x1c

    .line 168
    .line 169
    if-lt v6, v7, :cond_c

    .line 170
    .line 171
    if-eqz v11, :cond_c

    .line 172
    .line 173
    if-eqz v1, :cond_c

    .line 174
    .line 175
    if-eqz v4, :cond_c

    .line 176
    .line 177
    instance-of v6, v4, LH/s;

    .line 178
    .line 179
    if-nez v6, :cond_2

    .line 180
    .line 181
    goto/16 :goto_8

    .line 182
    .line 183
    :cond_2
    iget-wide v6, v1, LH0/N;->a:J

    .line 184
    .line 185
    iget-object v13, v4, LH/s;->h:Ljava/lang/Object;

    .line 186
    .line 187
    iget-object v14, v4, LH/s;->e:Lk2/c;

    .line 188
    .line 189
    invoke-virtual {v14}, Lk2/c;->e()Z

    .line 190
    .line 191
    .line 192
    move-result v15

    .line 193
    if-nez v15, :cond_3

    .line 194
    .line 195
    const/4 v2, 0x0

    .line 196
    goto :goto_4

    .line 197
    :cond_3
    iget-object v4, v4, LH/s;->g:LI/m0;

    .line 198
    .line 199
    invoke-virtual {v4}, LI/m0;->getValue()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v4

    .line 203
    check-cast v4, LH/Y;

    .line 204
    .line 205
    if-eqz v4, :cond_4

    .line 206
    .line 207
    iget-wide v2, v4, LH/Y;->b:J

    .line 208
    .line 209
    invoke-static {v6, v7, v2, v3}, LH0/N;->b(JJ)Z

    .line 210
    .line 211
    .line 212
    move-result v2

    .line 213
    if-eqz v2, :cond_4

    .line 214
    .line 215
    iget-object v2, v4, LH/Y;->a:Ljava/lang/CharSequence;

    .line 216
    .line 217
    invoke-static {v11, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    move-result v2

    .line 221
    if-eqz v2, :cond_4

    .line 222
    .line 223
    iget-object v2, v4, LH/Y;->c:Landroid/view/textclassifier/TextClassification;

    .line 224
    .line 225
    :goto_2
    const/4 v3, 0x0

    .line 226
    goto :goto_3

    .line 227
    :cond_4
    const/4 v2, 0x0

    .line 228
    goto :goto_2

    .line 229
    :goto_3
    invoke-virtual {v14, v3}, Lk2/c;->f(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    :goto_4
    if-nez v2, :cond_5

    .line 233
    .line 234
    invoke-virtual {v12, v8}, LB/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    goto :goto_7

    .line 238
    :cond_5
    invoke-static {v2}, LA1/g0;->q(Landroid/view/textclassifier/TextClassification;)Ljava/util/List;

    .line 239
    .line 240
    .line 241
    move-result-object v3

    .line 242
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 243
    .line 244
    .line 245
    move-result v3

    .line 246
    if-nez v3, :cond_6

    .line 247
    .line 248
    new-instance v3, Lz/h;

    .line 249
    .line 250
    const/4 v15, 0x0

    .line 251
    invoke-direct {v3, v13, v2, v15}, Lz/h;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 252
    .line 253
    .line 254
    iget-object v4, v8, Ly/a;->a:Li/D;

    .line 255
    .line 256
    invoke-virtual {v4, v3}, Li/D;->a(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    goto :goto_5

    .line 260
    :cond_6
    invoke-static {v2}, LA0/a;->h(Landroid/view/textclassifier/TextClassification;)Landroid/graphics/drawable/Drawable;

    .line 261
    .line 262
    .line 263
    move-result-object v3

    .line 264
    if-nez v3, :cond_7

    .line 265
    .line 266
    invoke-static {v2}, LA0/a;->q(Landroid/view/textclassifier/TextClassification;)Ljava/lang/CharSequence;

    .line 267
    .line 268
    .line 269
    move-result-object v3

    .line 270
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 271
    .line 272
    .line 273
    move-result v3

    .line 274
    if-nez v3, :cond_9

    .line 275
    .line 276
    :cond_7
    invoke-static {v2}, LA0/a;->g(Landroid/view/textclassifier/TextClassification;)Landroid/content/Intent;

    .line 277
    .line 278
    .line 279
    move-result-object v3

    .line 280
    if-nez v3, :cond_8

    .line 281
    .line 282
    invoke-static {v2}, LA0/a;->j(Landroid/view/textclassifier/TextClassification;)Landroid/view/View$OnClickListener;

    .line 283
    .line 284
    .line 285
    move-result-object v3

    .line 286
    if-eqz v3, :cond_9

    .line 287
    .line 288
    :cond_8
    new-instance v3, Lz/h;

    .line 289
    .line 290
    const/4 v4, -0x1

    .line 291
    invoke-direct {v3, v13, v2, v4}, Lz/h;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 292
    .line 293
    .line 294
    iget-object v4, v8, Ly/a;->a:Li/D;

    .line 295
    .line 296
    invoke-virtual {v4, v3}, Li/D;->a(Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    :cond_9
    :goto_5
    invoke-virtual {v12, v8}, LB/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    invoke-static {v2}, LA1/g0;->q(Landroid/view/textclassifier/TextClassification;)Ljava/util/List;

    .line 303
    .line 304
    .line 305
    move-result-object v3

    .line 306
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 307
    .line 308
    .line 309
    move-result v4

    .line 310
    const/4 v15, 0x0

    .line 311
    :goto_6
    if-ge v15, v4, :cond_b

    .line 312
    .line 313
    invoke-interface {v3, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v6

    .line 317
    invoke-static {v6}, LA0/a;->x(Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    if-lez v15, :cond_a

    .line 321
    .line 322
    new-instance v6, Lz/h;

    .line 323
    .line 324
    invoke-direct {v6, v13, v2, v15}, Lz/h;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 325
    .line 326
    .line 327
    iget-object v7, v8, Ly/a;->a:Li/D;

    .line 328
    .line 329
    invoke-virtual {v7, v6}, Li/D;->a(Ljava/lang/Object;)V

    .line 330
    .line 331
    .line 332
    :cond_a
    add-int/lit8 v15, v15, 0x1

    .line 333
    .line 334
    goto :goto_6

    .line 335
    :cond_b
    :goto_7
    iget-wide v12, v1, LH0/N;->a:J

    .line 336
    .line 337
    invoke-static/range {v8 .. v13}, Lx/a;->a(Ly/a;Landroid/content/Context;ZLjava/lang/String;J)V

    .line 338
    .line 339
    .line 340
    goto :goto_9

    .line 341
    :cond_c
    :goto_8
    invoke-virtual {v12, v8}, LB/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    if-eqz v11, :cond_d

    .line 345
    .line 346
    if-eqz v1, :cond_d

    .line 347
    .line 348
    iget-wide v12, v1, LH0/N;->a:J

    .line 349
    .line 350
    invoke-static/range {v8 .. v13}, Lx/a;->a(Ly/a;Landroid/content/Context;ZLjava/lang/String;J)V

    .line 351
    .line 352
    .line 353
    :cond_d
    :goto_9
    return-object v5

    .line 354
    :pswitch_3
    check-cast v7, LW/q;

    .line 355
    .line 356
    check-cast v6, LQ/f;

    .line 357
    .line 358
    move-object/from16 v1, p1

    .line 359
    .line 360
    check-cast v1, LI/r;

    .line 361
    .line 362
    move-object/from16 v3, p2

    .line 363
    .line 364
    check-cast v3, Ljava/lang/Integer;

    .line 365
    .line 366
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 367
    .line 368
    .line 369
    invoke-static {v2}, LI/k;->x(I)I

    .line 370
    .line 371
    .line 372
    move-result v2

    .line 373
    invoke-static {v7, v6, v1, v2}, LX1/a;->r(LW/q;LQ/f;LI/r;I)V

    .line 374
    .line 375
    .line 376
    return-object v5

    .line 377
    :pswitch_4
    check-cast v7, LB1/t;

    .line 378
    .line 379
    check-cast v6, Lq0/y;

    .line 380
    .line 381
    move-object/from16 v1, p1

    .line 382
    .line 383
    check-cast v1, Lq0/u;

    .line 384
    .line 385
    move-object/from16 v2, p2

    .line 386
    .line 387
    check-cast v2, Lc0/b;

    .line 388
    .line 389
    const-wide v3, -0x30f03377dbfaL

    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    invoke-static {v3, v4}, LI1/a;->a(J)Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v3

    .line 398
    invoke-static {v1, v3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 399
    .line 400
    .line 401
    iget-object v1, v7, LB1/t;->g:LA1/J;

    .line 402
    .line 403
    check-cast v6, Lq0/K;

    .line 404
    .line 405
    iget-wide v3, v6, Lq0/K;->A:J

    .line 406
    .line 407
    new-instance v6, LT0/n;

    .line 408
    .line 409
    invoke-direct {v6, v3, v4}, LT0/n;-><init>(J)V

    .line 410
    .line 411
    .line 412
    invoke-virtual {v1, v7, v6, v2}, LA1/J;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    return-object v5

    .line 416
    :pswitch_5
    check-cast v7, LB/A;

    .line 417
    .line 418
    check-cast v6, Landroid/graphics/drawable/Drawable;

    .line 419
    .line 420
    move-object/from16 v1, p1

    .line 421
    .line 422
    check-cast v1, LI/r;

    .line 423
    .line 424
    move-object/from16 v3, p2

    .line 425
    .line 426
    check-cast v3, Ljava/lang/Integer;

    .line 427
    .line 428
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 429
    .line 430
    .line 431
    invoke-static {v2}, LI/k;->x(I)I

    .line 432
    .line 433
    .line 434
    move-result v2

    .line 435
    invoke-virtual {v7, v6, v1, v2}, LB/A;->a(Landroid/graphics/drawable/Drawable;LI/r;I)V

    .line 436
    .line 437
    .line 438
    return-object v5

    .line 439
    :pswitch_6
    check-cast v6, Lz/g;

    .line 440
    .line 441
    check-cast v7, Lz/c;

    .line 442
    .line 443
    move-object/from16 v1, p1

    .line 444
    .line 445
    check-cast v1, LI/r;

    .line 446
    .line 447
    move-object/from16 v2, p2

    .line 448
    .line 449
    check-cast v2, Ljava/lang/Integer;

    .line 450
    .line 451
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 452
    .line 453
    .line 454
    invoke-static {v4}, LI/k;->x(I)I

    .line 455
    .line 456
    .line 457
    move-result v2

    .line 458
    invoke-static {v6, v7, v1, v2}, LB/t;->a(Lz/g;Lz/c;LI/r;I)V

    .line 459
    .line 460
    .line 461
    return-object v5

    .line 462
    :pswitch_7
    check-cast v7, LD/e;

    .line 463
    .line 464
    check-cast v6, Lz/g;

    .line 465
    .line 466
    move-object/from16 v1, p1

    .line 467
    .line 468
    check-cast v1, LI/r;

    .line 469
    .line 470
    move-object/from16 v2, p2

    .line 471
    .line 472
    check-cast v2, Ljava/lang/Integer;

    .line 473
    .line 474
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 475
    .line 476
    .line 477
    move-result v2

    .line 478
    and-int/lit8 v3, v2, 0x3

    .line 479
    .line 480
    const/4 v8, 0x2

    .line 481
    if-eq v3, v8, :cond_e

    .line 482
    .line 483
    move v3, v4

    .line 484
    goto :goto_a

    .line 485
    :cond_e
    const/4 v3, 0x0

    .line 486
    :goto_a
    and-int/2addr v2, v4

    .line 487
    invoke-virtual {v1, v2, v3}, LI/r;->N(IZ)Z

    .line 488
    .line 489
    .line 490
    move-result v2

    .line 491
    if-eqz v2, :cond_11

    .line 492
    .line 493
    invoke-virtual {v1, v7}, LI/r;->e(Ljava/lang/Object;)Z

    .line 494
    .line 495
    .line 496
    move-result v2

    .line 497
    invoke-virtual {v1}, LI/r;->K()Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v3

    .line 501
    if-nez v2, :cond_f

    .line 502
    .line 503
    sget-object v2, LI/m;->a:LI/h;

    .line 504
    .line 505
    if-ne v3, v2, :cond_10

    .line 506
    .line 507
    :cond_f
    new-instance v16, LA1/m;

    .line 508
    .line 509
    const/16 v23, 0x0

    .line 510
    .line 511
    const/16 v24, 0x1

    .line 512
    .line 513
    const/16 v17, 0x0

    .line 514
    .line 515
    const-class v19, LD/e;

    .line 516
    .line 517
    const-string v20, "data"

    .line 518
    .line 519
    const-string v21, "data()Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;"

    .line 520
    .line 521
    const/16 v22, 0x0

    .line 522
    .line 523
    move-object/from16 v18, v7

    .line 524
    .line 525
    invoke-direct/range {v16 .. v24}, LA1/m;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 526
    .line 527
    .line 528
    invoke-static/range {v16 .. v16}, LI/k;->l(LU1/a;)LI/F;

    .line 529
    .line 530
    .line 531
    move-result-object v3

    .line 532
    invoke-virtual {v1, v3}, LI/r;->d0(Ljava/lang/Object;)V

    .line 533
    .line 534
    .line 535
    :cond_10
    check-cast v3, LI/a1;

    .line 536
    .line 537
    invoke-interface {v3}, LI/a1;->getValue()Ljava/lang/Object;

    .line 538
    .line 539
    .line 540
    move-result-object v2

    .line 541
    check-cast v2, Lz/c;

    .line 542
    .line 543
    const/4 v15, 0x0

    .line 544
    invoke-static {v6, v2, v1, v15}, LB/t;->a(Lz/g;Lz/c;LI/r;I)V

    .line 545
    .line 546
    .line 547
    goto :goto_b

    .line 548
    :cond_11
    invoke-virtual {v1}, LI/r;->Q()V

    .line 549
    .line 550
    .line 551
    :goto_b
    return-object v5

    .line 552
    nop

    .line 553
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
