.class public final synthetic LB/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LW/q;Lo/d;LU1/c;II)V
    .locals 0

    .line 1
    const/4 p4, 0x4

    iput p4, p0, LB/q;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB/q;->f:Ljava/lang/Object;

    iput-object p2, p0, LB/q;->g:Ljava/lang/Object;

    iput-object p3, p0, LB/q;->h:Ljava/lang/Object;

    iput p5, p0, LB/q;->e:I

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 2
    iput p5, p0, LB/q;->d:I

    iput-object p1, p0, LB/q;->f:Ljava/lang/Object;

    iput-object p2, p0, LB/q;->g:Ljava/lang/Object;

    iput-object p3, p0, LB/q;->h:Ljava/lang/Object;

    iput p4, p0, LB/q;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LB/q;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lo/d;

    .line 9
    .line 10
    iget-object v1, p0, LB/q;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LW/q;

    .line 13
    .line 14
    iget-object v2, p0, LB/q;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, LQ/f;

    .line 17
    .line 18
    check-cast p1, LI/r;

    .line 19
    .line 20
    check-cast p2, Ljava/lang/Integer;

    .line 21
    .line 22
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget p2, p0, LB/q;->e:I

    .line 26
    .line 27
    or-int/lit8 p2, p2, 0x1

    .line 28
    .line 29
    invoke-static {p2}, LI/k;->x(I)I

    .line 30
    .line 31
    .line 32
    move-result p2

    .line 33
    invoke-static {v0, v1, v2, p1, p2}, Lo/i;->a(Lo/d;LW/q;LQ/f;LI/r;I)V

    .line 34
    .line 35
    .line 36
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 37
    .line 38
    return-object p1

    .line 39
    :pswitch_0
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 40
    .line 41
    move-object v1, v0

    .line 42
    check-cast v1, LW/q;

    .line 43
    .line 44
    iget-object v0, p0, LB/q;->g:Ljava/lang/Object;

    .line 45
    .line 46
    move-object v2, v0

    .line 47
    check-cast v2, Lo/d;

    .line 48
    .line 49
    iget-object v0, p0, LB/q;->h:Ljava/lang/Object;

    .line 50
    .line 51
    move-object v3, v0

    .line 52
    check-cast v3, LU1/c;

    .line 53
    .line 54
    move-object v4, p1

    .line 55
    check-cast v4, LI/r;

    .line 56
    .line 57
    check-cast p2, Ljava/lang/Integer;

    .line 58
    .line 59
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    const/4 p1, 0x1

    .line 63
    invoke-static {p1}, LI/k;->x(I)I

    .line 64
    .line 65
    .line 66
    move-result v5

    .line 67
    iget v6, p0, LB/q;->e:I

    .line 68
    .line 69
    invoke-static/range {v1 .. v6}, Lo/i;->b(LW/q;Lo/d;LU1/c;LI/r;II)V

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :pswitch_1
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 74
    .line 75
    check-cast v0, LQ/f;

    .line 76
    .line 77
    check-cast p1, LI/r;

    .line 78
    .line 79
    check-cast p2, Ljava/lang/Integer;

    .line 80
    .line 81
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 82
    .line 83
    .line 84
    iget p2, p0, LB/q;->e:I

    .line 85
    .line 86
    invoke-static {p2}, LI/k;->x(I)I

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    or-int/lit8 p2, p2, 0x1

    .line 91
    .line 92
    iget-object v1, p0, LB/q;->g:Ljava/lang/Object;

    .line 93
    .line 94
    iget-object v2, p0, LB/q;->h:Ljava/lang/Object;

    .line 95
    .line 96
    invoke-virtual {v0, v1, v2, p1, p2}, LQ/f;->m(Ljava/lang/Object;Ljava/lang/Object;LI/r;I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    goto :goto_0

    .line 100
    :pswitch_2
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v0, LH/l;

    .line 103
    .line 104
    iget-object v1, p0, LB/q;->g:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v1, LW/d;

    .line 107
    .line 108
    iget-object v2, p0, LB/q;->h:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v2, LQ/f;

    .line 111
    .line 112
    check-cast p1, LI/r;

    .line 113
    .line 114
    check-cast p2, Ljava/lang/Integer;

    .line 115
    .line 116
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    iget p2, p0, LB/q;->e:I

    .line 120
    .line 121
    or-int/lit8 p2, p2, 0x1

    .line 122
    .line 123
    invoke-static {p2}, LI/k;->x(I)I

    .line 124
    .line 125
    .line 126
    move-result p2

    .line 127
    invoke-static {v0, v1, v2, p1, p2}, La/a;->a(LH/l;LW/d;LQ/f;LI/r;I)V

    .line 128
    .line 129
    .line 130
    goto :goto_0

    .line 131
    :pswitch_3
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v0, LW/q;

    .line 134
    .line 135
    iget-object v1, p0, LB/q;->g:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v1, LI/t0;

    .line 138
    .line 139
    iget-object v2, p0, LB/q;->h:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v2, LQ/f;

    .line 142
    .line 143
    check-cast p1, LI/r;

    .line 144
    .line 145
    check-cast p2, Ljava/lang/Integer;

    .line 146
    .line 147
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 148
    .line 149
    .line 150
    iget p2, p0, LB/q;->e:I

    .line 151
    .line 152
    or-int/lit8 p2, p2, 0x1

    .line 153
    .line 154
    invoke-static {p2}, LI/k;->x(I)I

    .line 155
    .line 156
    .line 157
    move-result p2

    .line 158
    invoke-static {v0, v1, v2, p1, p2}, LX1/a;->p(LW/q;LI/t0;LQ/f;LI/r;I)V

    .line 159
    .line 160
    .line 161
    goto :goto_0

    .line 162
    :pswitch_4
    iget-object v0, p0, LB/q;->f:Ljava/lang/Object;

    .line 163
    .line 164
    check-cast v0, Lz/g;

    .line 165
    .line 166
    iget-object v1, p0, LB/q;->g:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v1, LD/e;

    .line 169
    .line 170
    iget-object v2, p0, LB/q;->h:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v2, LU1/a;

    .line 173
    .line 174
    check-cast p1, LI/r;

    .line 175
    .line 176
    check-cast p2, Ljava/lang/Integer;

    .line 177
    .line 178
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 179
    .line 180
    .line 181
    iget p2, p0, LB/q;->e:I

    .line 182
    .line 183
    or-int/lit8 p2, p2, 0x1

    .line 184
    .line 185
    invoke-static {p2}, LI/k;->x(I)I

    .line 186
    .line 187
    .line 188
    move-result p2

    .line 189
    invoke-static {v0, v1, v2, p1, p2}, LB/t;->c(Lz/g;LD/e;LU1/a;LI/r;I)V

    .line 190
    .line 191
    .line 192
    goto/16 :goto_0

    .line 193
    .line 194
    nop

    .line 195
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
