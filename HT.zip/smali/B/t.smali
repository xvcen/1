.class public abstract LB/t;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LW0/z;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LW0/z;

    .line 2
    .line 3
    const/16 v1, 0xe

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    and-int/2addr v1, v2

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    move v1, v2

    .line 12
    :goto_0
    sget-object v3, LW0/A;->d:LW0/A;

    .line 13
    .line 14
    invoke-direct {v0, v1, v3, v2}, LW0/z;-><init>(ZLW0/A;Z)V

    .line 15
    .line 16
    .line 17
    sput-object v0, LB/t;->a:LW0/z;

    .line 18
    .line 19
    return-void
.end method

.method public static final a(Lz/g;Lz/c;LI/r;I)V
    .locals 8

    .line 1
    const v0, 0x71816bae

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, LI/r;->V(I)LI/r;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2, p0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x4

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    move v0, v1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x2

    .line 17
    :goto_0
    or-int/2addr v0, p3

    .line 18
    invoke-virtual {p2, p1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    const/16 v2, 0x20

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :cond_1
    const/16 v2, 0x10

    .line 28
    .line 29
    :goto_1
    or-int/2addr v0, v2

    .line 30
    and-int/lit8 v2, v0, 0x13

    .line 31
    .line 32
    const/16 v3, 0x12

    .line 33
    .line 34
    const/4 v4, 0x1

    .line 35
    const/4 v5, 0x0

    .line 36
    if-eq v2, v3, :cond_2

    .line 37
    .line 38
    move v2, v4

    .line 39
    goto :goto_2

    .line 40
    :cond_2
    move v2, v5

    .line 41
    :goto_2
    and-int/lit8 v3, v0, 0x1

    .line 42
    .line 43
    invoke-virtual {p2, v3, v2}, LI/r;->N(IZ)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_7

    .line 48
    .line 49
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 50
    .line 51
    const/16 v3, 0x1c

    .line 52
    .line 53
    if-lt v2, v3, :cond_3

    .line 54
    .line 55
    const v2, -0x3c2b7b58

    .line 56
    .line 57
    .line 58
    invoke-virtual {p2, v2}, LI/r;->U(I)V

    .line 59
    .line 60
    .line 61
    sget-object v2, Lx0/J;->b:LI/b1;

    .line 62
    .line 63
    invoke-virtual {p2, v2}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    check-cast v2, Landroid/content/Context;

    .line 68
    .line 69
    invoke-virtual {p2, v5}, LI/r;->p(Z)V

    .line 70
    .line 71
    .line 72
    goto :goto_3

    .line 73
    :cond_3
    const v2, -0x3c2abb88

    .line 74
    .line 75
    .line 76
    invoke-virtual {p2, v2}, LI/r;->U(I)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p2, v5}, LI/r;->p(Z)V

    .line 80
    .line 81
    .line 82
    const/4 v2, 0x0

    .line 83
    :goto_3
    invoke-virtual {p2, p1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v3

    .line 87
    and-int/lit8 v0, v0, 0xe

    .line 88
    .line 89
    if-eq v0, v1, :cond_4

    .line 90
    .line 91
    move v4, v5

    .line 92
    :cond_4
    or-int v0, v3, v4

    .line 93
    .line 94
    invoke-virtual {p2, v2}, LI/r;->g(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    or-int/2addr v0, v1

    .line 99
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    if-nez v0, :cond_5

    .line 104
    .line 105
    sget-object v0, LI/m;->a:LI/h;

    .line 106
    .line 107
    if-ne v1, v0, :cond_6

    .line 108
    .line 109
    :cond_5
    new-instance v1, LB/r;

    .line 110
    .line 111
    const/4 v0, 0x0

    .line 112
    invoke-direct {v1, p1, v2, p0, v0}, LB/r;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {p2, v1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :cond_6
    move-object v4, v1

    .line 119
    check-cast v4, LU1/c;

    .line 120
    .line 121
    const/4 v6, 0x0

    .line 122
    const/4 v7, 0x3

    .line 123
    const/4 v2, 0x0

    .line 124
    const/4 v3, 0x0

    .line 125
    move-object v5, p2

    .line 126
    invoke-static/range {v2 .. v7}, Lo/i;->b(LW/q;Lo/d;LU1/c;LI/r;II)V

    .line 127
    .line 128
    .line 129
    goto :goto_4

    .line 130
    :cond_7
    move-object v5, p2

    .line 131
    invoke-virtual {v5}, LI/r;->Q()V

    .line 132
    .line 133
    .line 134
    :goto_4
    invoke-virtual {v5}, LI/r;->r()LI/w0;

    .line 135
    .line 136
    .line 137
    move-result-object p2

    .line 138
    if-eqz p2, :cond_8

    .line 139
    .line 140
    new-instance v0, LB/p;

    .line 141
    .line 142
    invoke-direct {v0, p0, p1, p3}, LB/p;-><init>(Lz/g;Lz/c;I)V

    .line 143
    .line 144
    .line 145
    iput-object v0, p2, LI/w0;->d:LU1/e;

    .line 146
    .line 147
    :cond_8
    return-void
.end method

.method public static final b(IJLI/r;I)V
    .locals 9

    .line 1
    const v0, -0x49eca00d

    .line 2
    .line 3
    .line 4
    invoke-virtual {p3, v0}, LI/r;->V(I)LI/r;

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p4, 0x6

    .line 8
    .line 9
    const/4 v1, 0x4

    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {p3, p0}, LI/r;->c(I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    move v0, v1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v0, 0x2

    .line 21
    :goto_0
    or-int/2addr v0, p4

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    move v0, p4

    .line 24
    :goto_1
    and-int/lit8 v2, p4, 0x30

    .line 25
    .line 26
    const/16 v3, 0x20

    .line 27
    .line 28
    if-nez v2, :cond_3

    .line 29
    .line 30
    invoke-virtual {p3, p1, p2}, LI/r;->d(J)Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_2

    .line 35
    .line 36
    move v2, v3

    .line 37
    goto :goto_2

    .line 38
    :cond_2
    const/16 v2, 0x10

    .line 39
    .line 40
    :goto_2
    or-int/2addr v0, v2

    .line 41
    :cond_3
    and-int/lit8 v2, v0, 0x13

    .line 42
    .line 43
    const/16 v4, 0x12

    .line 44
    .line 45
    const/4 v5, 0x1

    .line 46
    const/4 v6, 0x0

    .line 47
    if-eq v2, v4, :cond_4

    .line 48
    .line 49
    move v2, v5

    .line 50
    goto :goto_3

    .line 51
    :cond_4
    move v2, v6

    .line 52
    :goto_3
    and-int/lit8 v4, v0, 0x1

    .line 53
    .line 54
    invoke-virtual {p3, v4, v2}, LI/r;->N(IZ)Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-eqz v2, :cond_d

    .line 59
    .line 60
    sget-object v2, Lx0/J;->b:LI/b1;

    .line 61
    .line 62
    invoke-virtual {p3, v2}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    check-cast v2, Landroid/content/Context;

    .line 67
    .line 68
    invoke-virtual {p3, v2}, LI/r;->e(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v4

    .line 72
    and-int/lit8 v7, v0, 0xe

    .line 73
    .line 74
    if-ne v7, v1, :cond_5

    .line 75
    .line 76
    move v1, v5

    .line 77
    goto :goto_4

    .line 78
    :cond_5
    move v1, v6

    .line 79
    :goto_4
    or-int/2addr v1, v4

    .line 80
    invoke-virtual {p3}, LI/r;->K()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    const/4 v7, -0x1

    .line 85
    sget-object v8, LI/m;->a:LI/h;

    .line 86
    .line 87
    if-nez v1, :cond_6

    .line 88
    .line 89
    if-ne v4, v8, :cond_7

    .line 90
    .line 91
    :cond_6
    filled-new-array {p0}, [I

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-virtual {v2, v1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-virtual {v1, v6, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object v4

    .line 107
    invoke-virtual {p3, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    :cond_7
    check-cast v4, Ljava/lang/Number;

    .line 111
    .line 112
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result v1

    .line 116
    if-ne v1, v7, :cond_8

    .line 117
    .line 118
    invoke-virtual {p3}, LI/r;->r()LI/w0;

    .line 119
    .line 120
    .line 121
    move-result-object p3

    .line 122
    if-eqz p3, :cond_e

    .line 123
    .line 124
    new-instance v0, LB/o;

    .line 125
    .line 126
    const/4 v5, 0x1

    .line 127
    move v1, p0

    .line 128
    move-wide v2, p1

    .line 129
    move v4, p4

    .line 130
    invoke-direct/range {v0 .. v5}, LB/o;-><init>(IJII)V

    .line 131
    .line 132
    .line 133
    iput-object v0, p3, LI/w0;->d:LU1/e;

    .line 134
    .line 135
    return-void

    .line 136
    :cond_8
    move v2, p0

    .line 137
    move p0, v3

    .line 138
    move-wide v3, p1

    .line 139
    move p1, v5

    .line 140
    move v5, p4

    .line 141
    invoke-static {v1, p3}, La/a;->G(ILI/r;)Li0/b;

    .line 142
    .line 143
    .line 144
    move-result-object p2

    .line 145
    and-int/lit8 p4, v0, 0x70

    .line 146
    .line 147
    if-ne p4, p0, :cond_9

    .line 148
    .line 149
    goto :goto_5

    .line 150
    :cond_9
    move p1, v6

    .line 151
    :goto_5
    invoke-virtual {p3}, LI/r;->K()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object p0

    .line 155
    if-nez p1, :cond_a

    .line 156
    .line 157
    if-ne p0, v8, :cond_c

    .line 158
    .line 159
    :cond_a
    const-wide/16 p0, 0x10

    .line 160
    .line 161
    cmp-long p0, v3, p0

    .line 162
    .line 163
    if-nez p0, :cond_b

    .line 164
    .line 165
    const/4 p0, 0x0

    .line 166
    goto :goto_6

    .line 167
    :cond_b
    new-instance p0, Ld0/o;

    .line 168
    .line 169
    const/4 p1, 0x5

    .line 170
    invoke-direct {p0, v3, v4, p1}, Ld0/o;-><init>(JI)V

    .line 171
    .line 172
    .line 173
    :goto_6
    invoke-virtual {p3, p0}, LI/r;->d0(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    :cond_c
    check-cast p0, Ld0/o;

    .line 177
    .line 178
    sget p1, Lo/g;->j:F

    .line 179
    .line 180
    invoke-static {p1}, Ls/b;->l(F)LW/q;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    const/4 p4, 0x0

    .line 185
    const/16 v0, 0x16

    .line 186
    .line 187
    invoke-static {p1, p2, p4, p0, v0}, La0/g;->f(LW/q;Li0/b;FLd0/o;I)LW/q;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    invoke-static {p0, p3, v6}, Ls/j;->a(LW/q;LI/r;I)V

    .line 192
    .line 193
    .line 194
    goto :goto_7

    .line 195
    :cond_d
    move v2, p0

    .line 196
    move-wide v3, p1

    .line 197
    move v5, p4

    .line 198
    invoke-virtual {p3}, LI/r;->Q()V

    .line 199
    .line 200
    .line 201
    :goto_7
    invoke-virtual {p3}, LI/r;->r()LI/w0;

    .line 202
    .line 203
    .line 204
    move-result-object p0

    .line 205
    if-eqz p0, :cond_e

    .line 206
    .line 207
    new-instance v1, LB/o;

    .line 208
    .line 209
    const/4 v6, 0x0

    .line 210
    invoke-direct/range {v1 .. v6}, LB/o;-><init>(IJII)V

    .line 211
    .line 212
    .line 213
    iput-object v1, p0, LI/w0;->d:LU1/e;

    .line 214
    .line 215
    :cond_e
    return-void
.end method

.method public static final c(Lz/g;LD/e;LU1/a;LI/r;I)V
    .locals 13

    .line 1
    move-object/from16 v8, p3

    .line 2
    .line 3
    move/from16 v0, p4

    .line 4
    .line 5
    const v1, -0x799dedcc

    .line 6
    .line 7
    .line 8
    invoke-virtual {v8, v1}, LI/r;->V(I)LI/r;

    .line 9
    .line 10
    .line 11
    and-int/lit8 v1, v0, 0x6

    .line 12
    .line 13
    const/4 v4, 0x4

    .line 14
    if-nez v1, :cond_2

    .line 15
    .line 16
    and-int/lit8 v1, v0, 0x8

    .line 17
    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    invoke-virtual {v8, p0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    invoke-virtual {v8, p0}, LI/r;->g(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    :goto_0
    if-eqz v1, :cond_1

    .line 30
    .line 31
    move v1, v4

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    const/4 v1, 0x2

    .line 34
    :goto_1
    or-int/2addr v1, v0

    .line 35
    goto :goto_2

    .line 36
    :cond_2
    move v1, v0

    .line 37
    :goto_2
    and-int/lit8 v5, v0, 0x30

    .line 38
    .line 39
    const/16 v6, 0x20

    .line 40
    .line 41
    if-nez v5, :cond_5

    .line 42
    .line 43
    and-int/lit8 v5, v0, 0x40

    .line 44
    .line 45
    if-nez v5, :cond_3

    .line 46
    .line 47
    invoke-virtual {v8, p1}, LI/r;->e(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v5

    .line 51
    goto :goto_3

    .line 52
    :cond_3
    invoke-virtual {v8, p1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    :goto_3
    if-eqz v5, :cond_4

    .line 57
    .line 58
    move v5, v6

    .line 59
    goto :goto_4

    .line 60
    :cond_4
    const/16 v5, 0x10

    .line 61
    .line 62
    :goto_4
    or-int/2addr v1, v5

    .line 63
    :cond_5
    and-int/lit16 v5, v0, 0x180

    .line 64
    .line 65
    if-nez v5, :cond_7

    .line 66
    .line 67
    invoke-virtual {v8, p2}, LI/r;->g(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    if-eqz v5, :cond_6

    .line 72
    .line 73
    const/16 v5, 0x100

    .line 74
    .line 75
    goto :goto_5

    .line 76
    :cond_6
    const/16 v5, 0x80

    .line 77
    .line 78
    :goto_5
    or-int/2addr v1, v5

    .line 79
    :cond_7
    and-int/lit16 v5, v1, 0x93

    .line 80
    .line 81
    const/16 v7, 0x92

    .line 82
    .line 83
    const/4 v9, 0x0

    .line 84
    const/4 v10, 0x1

    .line 85
    if-eq v5, v7, :cond_8

    .line 86
    .line 87
    move v5, v10

    .line 88
    goto :goto_6

    .line 89
    :cond_8
    move v5, v9

    .line 90
    :goto_6
    and-int/lit8 v7, v1, 0x1

    .line 91
    .line 92
    invoke-virtual {v8, v7, v5}, LI/r;->N(IZ)Z

    .line 93
    .line 94
    .line 95
    move-result v5

    .line 96
    if-eqz v5, :cond_11

    .line 97
    .line 98
    and-int/lit8 v5, v1, 0x70

    .line 99
    .line 100
    if-eq v5, v6, :cond_a

    .line 101
    .line 102
    and-int/lit8 v5, v1, 0x40

    .line 103
    .line 104
    if-eqz v5, :cond_9

    .line 105
    .line 106
    invoke-virtual {v8, p1}, LI/r;->e(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v5

    .line 110
    if-eqz v5, :cond_9

    .line 111
    .line 112
    goto :goto_7

    .line 113
    :cond_9
    move v5, v9

    .line 114
    goto :goto_8

    .line 115
    :cond_a
    :goto_7
    move v5, v10

    .line 116
    :goto_8
    invoke-virtual {v8}, LI/r;->K()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v6

    .line 120
    sget-object v7, LI/m;->a:LI/h;

    .line 121
    .line 122
    if-nez v5, :cond_b

    .line 123
    .line 124
    if-ne v6, v7, :cond_c

    .line 125
    .line 126
    :cond_b
    new-instance v6, LB/v;

    .line 127
    .line 128
    new-instance v5, LA0/h;

    .line 129
    .line 130
    new-instance v11, LA1/c;

    .line 131
    .line 132
    const/4 v12, 0x3

    .line 133
    invoke-direct {v11, v12, p1, p2}, LA1/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    const/16 v12, 0x1b

    .line 137
    .line 138
    invoke-direct {v5, v12, v11}, LA0/h;-><init>(ILjava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    invoke-direct {v6, v5}, LB/v;-><init>(LA0/h;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v8, v6}, LI/r;->d0(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :cond_c
    check-cast v6, LB/v;

    .line 148
    .line 149
    and-int/lit8 v5, v1, 0xe

    .line 150
    .line 151
    if-eq v5, v4, :cond_d

    .line 152
    .line 153
    and-int/lit8 v1, v1, 0x8

    .line 154
    .line 155
    if-eqz v1, :cond_e

    .line 156
    .line 157
    invoke-virtual {v8, p0}, LI/r;->g(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-eqz v1, :cond_e

    .line 162
    .line 163
    :cond_d
    move v9, v10

    .line 164
    :cond_e
    invoke-virtual {v8}, LI/r;->K()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    if-nez v9, :cond_f

    .line 169
    .line 170
    if-ne v1, v7, :cond_10

    .line 171
    .line 172
    :cond_f
    new-instance v1, LA1/P;

    .line 173
    .line 174
    const/4 v4, 0x2

    .line 175
    invoke-direct {v1, v4, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {v8, v1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    :cond_10
    move-object v5, v1

    .line 182
    check-cast v5, LU1/a;

    .line 183
    .line 184
    new-instance v1, LB/p;

    .line 185
    .line 186
    const/4 v4, 0x0

    .line 187
    invoke-direct {v1, v4, p1, p0}, LB/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    const v4, 0x4e63add6    # 9.5495514E8f

    .line 191
    .line 192
    .line 193
    invoke-static {v4, v1, v8}, LQ/l;->c(ILJ1/c;LI/r;)LQ/f;

    .line 194
    .line 195
    .line 196
    move-result-object v7

    .line 197
    const/16 v9, 0xd80

    .line 198
    .line 199
    const/4 v10, 0x0

    .line 200
    move-object v4, v6

    .line 201
    sget-object v6, LB/t;->a:LW0/z;

    .line 202
    .line 203
    invoke-static/range {v4 .. v10}, LW0/o;->a(LW0/y;LU1/a;LW0/z;LQ/f;LI/r;II)V

    .line 204
    .line 205
    .line 206
    goto :goto_9

    .line 207
    :cond_11
    invoke-virtual/range {p3 .. p3}, LI/r;->Q()V

    .line 208
    .line 209
    .line 210
    :goto_9
    invoke-virtual/range {p3 .. p3}, LI/r;->r()LI/w0;

    .line 211
    .line 212
    .line 213
    move-result-object v6

    .line 214
    if-eqz v6, :cond_12

    .line 215
    .line 216
    new-instance v0, LB/q;

    .line 217
    .line 218
    const/4 v5, 0x0

    .line 219
    move-object v1, p0

    .line 220
    move-object v2, p1

    .line 221
    move-object v3, p2

    .line 222
    move/from16 v4, p4

    .line 223
    .line 224
    invoke-direct/range {v0 .. v5}, LB/q;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    .line 225
    .line 226
    .line 227
    iput-object v0, v6, LI/w0;->d:LU1/e;

    .line 228
    .line 229
    :cond_12
    return-void
.end method

.method public static final d(LW/q;LQ/f;LI/r;I)V
    .locals 3

    .line 1
    const v0, 0x52f9d6eb

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, LI/r;->V(I)LI/r;

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 8
    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    invoke-virtual {p2, p0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x2

    .line 20
    :goto_0
    or-int/2addr v0, p3

    .line 21
    goto :goto_1

    .line 22
    :cond_1
    move v0, p3

    .line 23
    :goto_1
    and-int/lit8 v1, p3, 0x30

    .line 24
    .line 25
    if-nez v1, :cond_3

    .line 26
    .line 27
    invoke-virtual {p2, p1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    const/16 v1, 0x20

    .line 34
    .line 35
    goto :goto_2

    .line 36
    :cond_2
    const/16 v1, 0x10

    .line 37
    .line 38
    :goto_2
    or-int/2addr v0, v1

    .line 39
    :cond_3
    and-int/lit8 v1, v0, 0x13

    .line 40
    .line 41
    const/16 v2, 0x12

    .line 42
    .line 43
    if-eq v1, v2, :cond_4

    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    goto :goto_3

    .line 47
    :cond_4
    const/4 v1, 0x0

    .line 48
    :goto_3
    and-int/lit8 v2, v0, 0x1

    .line 49
    .line 50
    invoke-virtual {p2, v2, v1}, LI/r;->N(IZ)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_5

    .line 55
    .line 56
    sget-object v1, LD/g;->a:LI/B;

    .line 57
    .line 58
    and-int/lit8 v2, v0, 0xe

    .line 59
    .line 60
    or-int/lit16 v2, v2, 0x1b0

    .line 61
    .line 62
    shl-int/lit8 v0, v0, 0x6

    .line 63
    .line 64
    and-int/lit16 v0, v0, 0x1c00

    .line 65
    .line 66
    or-int/2addr v0, v2

    .line 67
    invoke-static {p0, v1, p1, p2, v0}, LX1/a;->p(LW/q;LI/t0;LQ/f;LI/r;I)V

    .line 68
    .line 69
    .line 70
    goto :goto_4

    .line 71
    :cond_5
    invoke-virtual {p2}, LI/r;->Q()V

    .line 72
    .line 73
    .line 74
    :goto_4
    invoke-virtual {p2}, LI/r;->r()LI/w0;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    if-eqz p2, :cond_6

    .line 79
    .line 80
    new-instance v0, LB/j;

    .line 81
    .line 82
    const/4 v1, 0x2

    .line 83
    invoke-direct {v0, p0, p1, p3, v1}, LB/j;-><init>(LW/q;LQ/f;II)V

    .line 84
    .line 85
    .line 86
    iput-object v0, p2, LI/w0;->d:LU1/e;

    .line 87
    .line 88
    :cond_6
    return-void
.end method
