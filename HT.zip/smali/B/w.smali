.class public final synthetic LB/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LW/q;

.field public final synthetic e:LI/b0;

.field public final synthetic f:LQ/f;

.field public final synthetic g:LD/c;

.field public final synthetic h:LU1/a;


# direct methods
.method public synthetic constructor <init>(LW/q;LI/b0;LQ/f;LD/c;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB/w;->d:LW/q;

    iput-object p2, p0, LB/w;->e:LI/b0;

    iput-object p3, p0, LB/w;->f:LQ/f;

    iput-object p4, p0, LB/w;->g:LD/c;

    iput-object p5, p0, LB/w;->h:LU1/a;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    check-cast p1, LI/r;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x1

    .line 14
    if-eq v0, v1, :cond_0

    .line 15
    .line 16
    move v0, v3

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move v0, v2

    .line 19
    :goto_0
    and-int/2addr p2, v3

    .line 20
    invoke-virtual {p1, p2, v0}, LI/r;->N(IZ)Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    if-eqz p2, :cond_3

    .line 25
    .line 26
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    sget-object v0, LI/m;->a:LI/h;

    .line 31
    .line 32
    if-ne p2, v0, :cond_1

    .line 33
    .line 34
    new-instance p2, LA1/a;

    .line 35
    .line 36
    const/4 v0, 0x6

    .line 37
    iget-object v1, p0, LB/w;->e:LI/b0;

    .line 38
    .line 39
    invoke-direct {p2, v1, v0}, LA1/a;-><init>(LI/b0;I)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1, p2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_1
    check-cast p2, LU1/c;

    .line 46
    .line 47
    iget-object v0, p0, LB/w;->d:LW/q;

    .line 48
    .line 49
    invoke-static {v0, p2}, Lu0/v;->h(LW/q;LU1/c;)LW/q;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    sget-object v0, LW/c;->d:LW/h;

    .line 54
    .line 55
    invoke-static {v0, v3}, Ls/j;->d(LW/h;Z)Lu0/z;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iget-wide v4, p1, LI/r;->R:J

    .line 60
    .line 61
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    invoke-virtual {p1}, LI/r;->k()LI/q0;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-static {p1, p2}, LW/a;->c(LI/r;LW/q;)LW/q;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    sget-object v5, Lw0/f;->c:Lw0/e;

    .line 74
    .line 75
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 76
    .line 77
    .line 78
    sget-object v5, Lw0/e;->b:Lw0/x;

    .line 79
    .line 80
    invoke-virtual {p1}, LI/r;->W()V

    .line 81
    .line 82
    .line 83
    iget-boolean v6, p1, LI/r;->Q:Z

    .line 84
    .line 85
    if-eqz v6, :cond_2

    .line 86
    .line 87
    invoke-virtual {p1, v5}, LI/r;->j(LU1/a;)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_2
    invoke-virtual {p1}, LI/r;->g0()V

    .line 92
    .line 93
    .line 94
    :goto_1
    sget-object v5, Lw0/e;->e:Lw0/d;

    .line 95
    .line 96
    invoke-static {p1, v5, v0}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    sget-object v0, Lw0/e;->d:Lw0/d;

    .line 100
    .line 101
    invoke-static {p1, v0, v4}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    sget-object v1, Lw0/e;->f:Lw0/d;

    .line 109
    .line 110
    invoke-static {p1, v0, v1}, LI/k;->o(LI/r;Ljava/lang/Integer;LU1/e;)V

    .line 111
    .line 112
    .line 113
    sget-object v0, Lw0/e;->g:Lw0/c;

    .line 114
    .line 115
    invoke-static {p1, v0}, LI/k;->s(LI/r;LU1/c;)V

    .line 116
    .line 117
    .line 118
    sget-object v0, Lw0/e;->c:Lw0/d;

    .line 119
    .line 120
    invoke-static {p1, v0, p2}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 124
    .line 125
    .line 126
    move-result-object p2

    .line 127
    iget-object v0, p0, LB/w;->f:LQ/f;

    .line 128
    .line 129
    invoke-virtual {v0, p1, p2}, LQ/f;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    const/4 p2, 0x6

    .line 133
    iget-object v0, p0, LB/w;->g:LD/c;

    .line 134
    .line 135
    iget-object v1, p0, LB/w;->h:LU1/a;

    .line 136
    .line 137
    invoke-virtual {v0, v1, p1, p2}, LD/c;->b(LU1/a;LI/r;I)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {p1, v3}, LI/r;->p(Z)V

    .line 141
    .line 142
    .line 143
    goto :goto_2

    .line 144
    :cond_3
    invoke-virtual {p1}, LI/r;->Q()V

    .line 145
    .line 146
    .line 147
    :goto_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 148
    .line 149
    return-object p1
.end method
