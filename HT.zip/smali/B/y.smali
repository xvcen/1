.class public final synthetic LB/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LB/y;->d:I

    iput-object p2, p0, LB/y;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LB/y;->d:I

    iput-object p2, p0, LB/y;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, LB/y;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x5

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x0

    .line 7
    const/4 v5, 0x1

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lw/n0;

    .line 14
    .line 15
    check-cast p1, Ljava/lang/Float;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    iget-object v1, v0, Lw/n0;->a:LI/i0;

    .line 22
    .line 23
    invoke-virtual {v1}, LI/i0;->g()F

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    add-float/2addr v2, p1

    .line 28
    iget-object v0, v0, Lw/n0;->b:LI/i0;

    .line 29
    .line 30
    invoke-virtual {v0}, LI/i0;->g()F

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    cmpl-float v4, v2, v4

    .line 35
    .line 36
    if-lez v4, :cond_0

    .line 37
    .line 38
    invoke-virtual {v0}, LI/i0;->g()F

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    invoke-virtual {v1}, LI/i0;->g()F

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    sub-float/2addr p1, v0

    .line 47
    goto :goto_0

    .line 48
    :cond_0
    cmpg-float v0, v2, v3

    .line 49
    .line 50
    if-gez v0, :cond_1

    .line 51
    .line 52
    invoke-virtual {v1}, LI/i0;->g()F

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    neg-float p1, p1

    .line 57
    :cond_1
    :goto_0
    invoke-virtual {v1}, LI/i0;->g()F

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    add-float/2addr v0, p1

    .line 62
    invoke-virtual {v1, v0}, LI/i0;->h(F)V

    .line 63
    .line 64
    .line 65
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    return-object p1

    .line 70
    :pswitch_0
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v0, LH/l;

    .line 73
    .line 74
    check-cast p1, LE0/v;

    .line 75
    .line 76
    sget-object v1, LH/N;->c:LE0/u;

    .line 77
    .line 78
    new-instance v2, LH/M;

    .line 79
    .line 80
    sget-object v3, Lw/G;->d:Lw/G;

    .line 81
    .line 82
    invoke-interface {v0}, LH/l;->a()J

    .line 83
    .line 84
    .line 85
    move-result-wide v4

    .line 86
    sget-object v6, LH/L;->e:LH/L;

    .line 87
    .line 88
    const/4 v7, 0x1

    .line 89
    invoke-direct/range {v2 .. v7}, LH/M;-><init>(Lw/G;JLH/L;Z)V

    .line 90
    .line 91
    .line 92
    invoke-interface {p1, v1, v2}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 96
    .line 97
    return-object p1

    .line 98
    :pswitch_1
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Ls/N;

    .line 101
    .line 102
    check-cast p1, Lw0/y0;

    .line 103
    .line 104
    const-string v1, "null cannot be cast to non-null type androidx.compose.foundation.layout.InsetsConsumingModifierNode"

    .line 105
    .line 106
    invoke-static {p1, v1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    check-cast p1, Ls/N;

    .line 110
    .line 111
    iget-object p1, p1, Ls/N;->s:Ls/Q;

    .line 112
    .line 113
    iput-object p1, v0, Ls/N;->r:Ls/Q;

    .line 114
    .line 115
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 116
    .line 117
    return-object p1

    .line 118
    :pswitch_2
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v0, Lp/S0;

    .line 121
    .line 122
    check-cast p1, Lc0/b;

    .line 123
    .line 124
    iget-object v1, v0, Lp/S0;->k:Lp/r0;

    .line 125
    .line 126
    iget-wide v2, p1, Lc0/b;->a:J

    .line 127
    .line 128
    iget p1, v0, Lp/S0;->j:I

    .line 129
    .line 130
    invoke-virtual {v0, v1, v2, v3, p1}, Lp/S0;->c(Lp/r0;JI)J

    .line 131
    .line 132
    .line 133
    move-result-wide v0

    .line 134
    new-instance p1, Lc0/b;

    .line 135
    .line 136
    invoke-direct {p1, v0, v1}, Lc0/b;-><init>(J)V

    .line 137
    .line 138
    .line 139
    return-object p1

    .line 140
    :pswitch_3
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v0, Lw/T;

    .line 143
    .line 144
    check-cast p1, Lq0/u;

    .line 145
    .line 146
    invoke-virtual {v0}, Lw/T;->a()Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 150
    .line 151
    return-object p1

    .line 152
    :pswitch_4
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 153
    .line 154
    check-cast v0, Ln/q0;

    .line 155
    .line 156
    check-cast p1, Ljava/lang/Float;

    .line 157
    .line 158
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 159
    .line 160
    .line 161
    move-result p1

    .line 162
    iget-object v1, v0, Ln/q0;->a:LI/j0;

    .line 163
    .line 164
    invoke-virtual {v1}, LI/j0;->g()I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    int-to-float v2, v2

    .line 169
    add-float/2addr v2, p1

    .line 170
    iget v6, v0, Ln/q0;->f:F

    .line 171
    .line 172
    add-float/2addr v2, v6

    .line 173
    iget-object v6, v0, Ln/q0;->e:LI/j0;

    .line 174
    .line 175
    invoke-virtual {v6}, LI/j0;->g()I

    .line 176
    .line 177
    .line 178
    move-result v6

    .line 179
    int-to-float v6, v6

    .line 180
    invoke-static {v2, v3, v6}, LT0/l;->l(FFF)F

    .line 181
    .line 182
    .line 183
    move-result v3

    .line 184
    cmpg-float v2, v2, v3

    .line 185
    .line 186
    if-nez v2, :cond_2

    .line 187
    .line 188
    move v4, v5

    .line 189
    :cond_2
    invoke-virtual {v1}, LI/j0;->g()I

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    int-to-float v2, v2

    .line 194
    sub-float/2addr v3, v2

    .line 195
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    .line 196
    .line 197
    .line 198
    move-result v2

    .line 199
    invoke-virtual {v1}, LI/j0;->g()I

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    add-int/2addr v5, v2

    .line 204
    invoke-virtual {v1, v5}, LI/j0;->h(I)V

    .line 205
    .line 206
    .line 207
    int-to-float v1, v2

    .line 208
    sub-float v1, v3, v1

    .line 209
    .line 210
    iput v1, v0, Ln/q0;->f:F

    .line 211
    .line 212
    if-nez v4, :cond_3

    .line 213
    .line 214
    move p1, v3

    .line 215
    :cond_3
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    return-object p1

    .line 220
    :pswitch_5
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast v0, Ljava/lang/String;

    .line 223
    .line 224
    check-cast p1, LE0/v;

    .line 225
    .line 226
    sget-object v1, LE0/t;->a:[LZ1/c;

    .line 227
    .line 228
    sget-object v1, LE0/r;->a:LE0/u;

    .line 229
    .line 230
    invoke-static {v0}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-interface {p1, v1, v0}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    invoke-static {p1, v2}, LE0/t;->b(LE0/v;I)V

    .line 238
    .line 239
    .line 240
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 241
    .line 242
    return-object p1

    .line 243
    :pswitch_6
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast v0, LV1/o;

    .line 246
    .line 247
    check-cast p1, Lw0/y0;

    .line 248
    .line 249
    iget-boolean v1, v0, LV1/o;->d:Z

    .line 250
    .line 251
    if-nez v1, :cond_4

    .line 252
    .line 253
    const-string v1, "null cannot be cast to non-null type androidx.compose.foundation.gestures.ScrollableContainerNode"

    .line 254
    .line 255
    invoke-static {p1, v1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    check-cast p1, Lp/s0;

    .line 259
    .line 260
    iget-boolean p1, p1, Lp/s0;->r:Z

    .line 261
    .line 262
    if-eqz p1, :cond_5

    .line 263
    .line 264
    :cond_4
    move v4, v5

    .line 265
    :cond_5
    iput-boolean v4, v0, LV1/o;->d:Z

    .line 266
    .line 267
    xor-int/lit8 p1, v4, 0x1

    .line 268
    .line 269
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 270
    .line 271
    .line 272
    move-result-object p1

    .line 273
    return-object p1

    .line 274
    :pswitch_7
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v0, Ll/U;

    .line 277
    .line 278
    check-cast p1, LI/I;

    .line 279
    .line 280
    new-instance p1, LB/l;

    .line 281
    .line 282
    const/4 v1, 0x3

    .line 283
    invoke-direct {p1, v1, v0}, LB/l;-><init>(ILjava/lang/Object;)V

    .line 284
    .line 285
    .line 286
    return-object p1

    .line 287
    :pswitch_8
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 288
    .line 289
    check-cast v0, LB/k;

    .line 290
    .line 291
    sget-object v1, Ll/d;->j:LF/r;

    .line 292
    .line 293
    check-cast p1, Ll/g;

    .line 294
    .line 295
    iget-object v2, p1, Ll/g;->e:LI/m0;

    .line 296
    .line 297
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v2

    .line 301
    iget-object v1, v1, LF/r;->f:Ljava/lang/Object;

    .line 302
    .line 303
    check-cast v1, LU1/c;

    .line 304
    .line 305
    iget-object p1, p1, Ll/g;->f:Ll/n;

    .line 306
    .line 307
    invoke-interface {v1, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object p1

    .line 311
    invoke-virtual {v0, v2, p1}, LB/k;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 315
    .line 316
    return-object p1

    .line 317
    :pswitch_9
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 318
    .line 319
    check-cast v0, Lk2/c;

    .line 320
    .line 321
    check-cast p1, Ljava/lang/Throwable;

    .line 322
    .line 323
    invoke-virtual {v0, v1}, Lk2/c;->f(Ljava/lang/Object;)V

    .line 324
    .line 325
    .line 326
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 327
    .line 328
    return-object p1

    .line 329
    :pswitch_a
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast v0, LU/w;

    .line 332
    .line 333
    iget-object v1, v0, LU/w;->g:Ljava/lang/Object;

    .line 334
    .line 335
    monitor-enter v1

    .line 336
    :try_start_0
    iget-object v0, v0, LU/w;->i:LU/v;

    .line 337
    .line 338
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 339
    .line 340
    .line 341
    iget-object v2, v0, LU/v;->b:Ljava/lang/Object;

    .line 342
    .line 343
    invoke-static {v2}, LV1/i;->b(Ljava/lang/Object;)V

    .line 344
    .line 345
    .line 346
    iget v3, v0, LU/v;->d:I

    .line 347
    .line 348
    iget-object v4, v0, LU/v;->c:Li/C;

    .line 349
    .line 350
    if-nez v4, :cond_6

    .line 351
    .line 352
    new-instance v4, Li/C;

    .line 353
    .line 354
    invoke-direct {v4}, Li/C;-><init>()V

    .line 355
    .line 356
    .line 357
    iput-object v4, v0, LU/v;->c:Li/C;

    .line 358
    .line 359
    iget-object v5, v0, LU/v;->f:Li/E;

    .line 360
    .line 361
    invoke-virtual {v5, v2, v4}, Li/E;->l(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 362
    .line 363
    .line 364
    :cond_6
    invoke-virtual {v0, p1, v3, v2, v4}, LU/v;->b(Ljava/lang/Object;ILjava/lang/Object;Li/C;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 365
    .line 366
    .line 367
    monitor-exit v1

    .line 368
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 369
    .line 370
    return-object p1

    .line 371
    :catchall_0
    move-exception v0

    .line 372
    move-object p1, v0

    .line 373
    monitor-exit v1

    .line 374
    throw p1

    .line 375
    :pswitch_b
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v0, LM0/g;

    .line 378
    .line 379
    check-cast p1, LM0/g;

    .line 380
    .line 381
    if-ne v0, p1, :cond_7

    .line 382
    .line 383
    const-string v0, " > "

    .line 384
    .line 385
    goto :goto_1

    .line 386
    :cond_7
    const-string v0, "   "

    .line 387
    .line 388
    :goto_1
    new-instance v1, Ljava/lang/StringBuilder;

    .line 389
    .line 390
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 391
    .line 392
    .line 393
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 394
    .line 395
    .line 396
    const-string v0, ", newCursorPosition="

    .line 397
    .line 398
    instance-of v2, p1, LM0/a;

    .line 399
    .line 400
    const/16 v3, 0x29

    .line 401
    .line 402
    if-eqz v2, :cond_8

    .line 403
    .line 404
    new-instance v2, Ljava/lang/StringBuilder;

    .line 405
    .line 406
    const-string v4, "CommitTextCommand(text.length="

    .line 407
    .line 408
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 409
    .line 410
    .line 411
    check-cast p1, LM0/a;

    .line 412
    .line 413
    iget-object v4, p1, LM0/a;->a:LH0/g;

    .line 414
    .line 415
    iget-object v4, v4, LH0/g;->e:Ljava/lang/String;

    .line 416
    .line 417
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 418
    .line 419
    .line 420
    move-result v4

    .line 421
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 422
    .line 423
    .line 424
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 425
    .line 426
    .line 427
    iget p1, p1, LM0/a;->b:I

    .line 428
    .line 429
    :goto_2
    invoke-static {v2, p1, v3}, LM0/m;->h(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    .line 430
    .line 431
    .line 432
    move-result-object p1

    .line 433
    goto/16 :goto_3

    .line 434
    .line 435
    :cond_8
    instance-of v2, p1, LM0/v;

    .line 436
    .line 437
    if-eqz v2, :cond_9

    .line 438
    .line 439
    new-instance v2, Ljava/lang/StringBuilder;

    .line 440
    .line 441
    const-string v4, "SetComposingTextCommand(text.length="

    .line 442
    .line 443
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    check-cast p1, LM0/v;

    .line 447
    .line 448
    iget-object v4, p1, LM0/v;->a:LH0/g;

    .line 449
    .line 450
    iget-object v4, v4, LH0/g;->e:Ljava/lang/String;

    .line 451
    .line 452
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 453
    .line 454
    .line 455
    move-result v4

    .line 456
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 457
    .line 458
    .line 459
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 460
    .line 461
    .line 462
    iget p1, p1, LM0/v;->b:I

    .line 463
    .line 464
    goto :goto_2

    .line 465
    :cond_9
    instance-of v0, p1, LM0/u;

    .line 466
    .line 467
    if-eqz v0, :cond_a

    .line 468
    .line 469
    check-cast p1, LM0/u;

    .line 470
    .line 471
    invoke-virtual {p1}, LM0/u;->toString()Ljava/lang/String;

    .line 472
    .line 473
    .line 474
    move-result-object p1

    .line 475
    goto :goto_3

    .line 476
    :cond_a
    instance-of v0, p1, LM0/e;

    .line 477
    .line 478
    if-eqz v0, :cond_b

    .line 479
    .line 480
    check-cast p1, LM0/e;

    .line 481
    .line 482
    invoke-virtual {p1}, LM0/e;->toString()Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object p1

    .line 486
    goto :goto_3

    .line 487
    :cond_b
    instance-of v0, p1, LM0/f;

    .line 488
    .line 489
    if-eqz v0, :cond_c

    .line 490
    .line 491
    check-cast p1, LM0/f;

    .line 492
    .line 493
    invoke-virtual {p1}, LM0/f;->toString()Ljava/lang/String;

    .line 494
    .line 495
    .line 496
    move-result-object p1

    .line 497
    goto :goto_3

    .line 498
    :cond_c
    instance-of v0, p1, LM0/w;

    .line 499
    .line 500
    if-eqz v0, :cond_d

    .line 501
    .line 502
    check-cast p1, LM0/w;

    .line 503
    .line 504
    invoke-virtual {p1}, LM0/w;->toString()Ljava/lang/String;

    .line 505
    .line 506
    .line 507
    move-result-object p1

    .line 508
    goto :goto_3

    .line 509
    :cond_d
    instance-of v0, p1, LM0/i;

    .line 510
    .line 511
    if-eqz v0, :cond_e

    .line 512
    .line 513
    check-cast p1, LM0/i;

    .line 514
    .line 515
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 516
    .line 517
    .line 518
    const-string p1, "FinishComposingTextCommand()"

    .line 519
    .line 520
    goto :goto_3

    .line 521
    :cond_e
    instance-of v0, p1, LM0/d;

    .line 522
    .line 523
    if-eqz v0, :cond_f

    .line 524
    .line 525
    check-cast p1, LM0/d;

    .line 526
    .line 527
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 528
    .line 529
    .line 530
    const-string p1, "DeleteAllCommand()"

    .line 531
    .line 532
    goto :goto_3

    .line 533
    :cond_f
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    invoke-static {p1}, LV1/t;->a(Ljava/lang/Class;)LV1/e;

    .line 538
    .line 539
    .line 540
    move-result-object p1

    .line 541
    invoke-virtual {p1}, LV1/e;->b()Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object p1

    .line 545
    if-nez p1, :cond_10

    .line 546
    .line 547
    const-string p1, "{anonymous EditCommand}"

    .line 548
    .line 549
    :cond_10
    const-string v0, "Unknown EditCommand: "

    .line 550
    .line 551
    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 552
    .line 553
    .line 554
    move-result-object p1

    .line 555
    :goto_3
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 556
    .line 557
    .line 558
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object p1

    .line 562
    return-object p1

    .line 563
    :pswitch_c
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 564
    .line 565
    check-cast v0, LL0/e;

    .line 566
    .line 567
    check-cast p1, LL0/o;

    .line 568
    .line 569
    iget-object v3, p1, LL0/o;->b:LL0/k;

    .line 570
    .line 571
    iget v4, p1, LL0/o;->c:I

    .line 572
    .line 573
    iget v5, p1, LL0/o;->d:I

    .line 574
    .line 575
    iget-object v6, p1, LL0/o;->e:Ljava/lang/Object;

    .line 576
    .line 577
    new-instance v1, LL0/o;

    .line 578
    .line 579
    const/4 v2, 0x0

    .line 580
    invoke-direct/range {v1 .. v6}, LL0/o;-><init>(LL0/b;LL0/k;IILjava/lang/Object;)V

    .line 581
    .line 582
    .line 583
    invoke-virtual {v0, v1}, LL0/e;->a(LL0/o;)LL0/p;

    .line 584
    .line 585
    .line 586
    move-result-object p1

    .line 587
    iget-object p1, p1, LL0/p;->d:Ljava/lang/Object;

    .line 588
    .line 589
    return-object p1

    .line 590
    :pswitch_d
    const-string v0, "(this Map)"

    .line 591
    .line 592
    iget-object v1, p0, LB/y;->e:Ljava/lang/Object;

    .line 593
    .line 594
    check-cast v1, LK1/f;

    .line 595
    .line 596
    check-cast p1, Ljava/util/Map$Entry;

    .line 597
    .line 598
    const-string v2, "it"

    .line 599
    .line 600
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 601
    .line 602
    .line 603
    new-instance v2, Ljava/lang/StringBuilder;

    .line 604
    .line 605
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 606
    .line 607
    .line 608
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 609
    .line 610
    .line 611
    move-result-object v3

    .line 612
    if-ne v3, v1, :cond_11

    .line 613
    .line 614
    move-object v3, v0

    .line 615
    goto :goto_4

    .line 616
    :cond_11
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 617
    .line 618
    .line 619
    move-result-object v3

    .line 620
    :goto_4
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 621
    .line 622
    .line 623
    const/16 v3, 0x3d

    .line 624
    .line 625
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 626
    .line 627
    .line 628
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    move-result-object p1

    .line 632
    if-ne p1, v1, :cond_12

    .line 633
    .line 634
    goto :goto_5

    .line 635
    :cond_12
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    :goto_5
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 640
    .line 641
    .line 642
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object p1

    .line 646
    return-object p1

    .line 647
    :pswitch_e
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 648
    .line 649
    check-cast v0, LK1/a;

    .line 650
    .line 651
    if-ne p1, v0, :cond_13

    .line 652
    .line 653
    const-string p1, "(this Collection)"

    .line 654
    .line 655
    goto :goto_6

    .line 656
    :cond_13
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 657
    .line 658
    .line 659
    move-result-object p1

    .line 660
    :goto_6
    return-object p1

    .line 661
    :pswitch_f
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 662
    .line 663
    check-cast v0, Li/F;

    .line 664
    .line 665
    instance-of v1, p1, LU/z;

    .line 666
    .line 667
    if-eqz v1, :cond_14

    .line 668
    .line 669
    move-object v1, p1

    .line 670
    check-cast v1, LU/z;

    .line 671
    .line 672
    const/4 v2, 0x4

    .line 673
    invoke-virtual {v1, v2}, LU/z;->f(I)V

    .line 674
    .line 675
    .line 676
    :cond_14
    invoke-virtual {v0, p1}, Li/F;->a(Ljava/lang/Object;)Z

    .line 677
    .line 678
    .line 679
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 680
    .line 681
    return-object p1

    .line 682
    :pswitch_10
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 683
    .line 684
    check-cast v0, LI/E0;

    .line 685
    .line 686
    check-cast p1, Ljava/lang/Throwable;

    .line 687
    .line 688
    const-string v3, "Recomposer effect job completed"

    .line 689
    .line 690
    new-instance v4, Ljava/util/concurrent/CancellationException;

    .line 691
    .line 692
    invoke-direct {v4, v3}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 693
    .line 694
    .line 695
    invoke-virtual {v4, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 696
    .line 697
    .line 698
    iget-object v3, v0, LI/E0;->c:Ljava/lang/Object;

    .line 699
    .line 700
    monitor-enter v3

    .line 701
    :try_start_1
    iget-object v5, v0, LI/E0;->d:Lc2/Q;

    .line 702
    .line 703
    if-eqz v5, :cond_15

    .line 704
    .line 705
    iget-object v6, v0, LI/E0;->u:Lf2/G;

    .line 706
    .line 707
    sget-object v7, LI/y0;->e:LI/y0;

    .line 708
    .line 709
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 710
    .line 711
    .line 712
    invoke-virtual {v6, v1, v7}, Lf2/G;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 713
    .line 714
    .line 715
    invoke-interface {v5, v4}, Lc2/Q;->a(Ljava/util/concurrent/CancellationException;)V

    .line 716
    .line 717
    .line 718
    iput-object v1, v0, LI/E0;->r:Lc2/g;

    .line 719
    .line 720
    new-instance v1, LC1/e;

    .line 721
    .line 722
    invoke-direct {v1, v2, v0, p1}, LC1/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 723
    .line 724
    .line 725
    invoke-interface {v5, v1}, Lc2/Q;->m(LU1/c;)Lc2/C;

    .line 726
    .line 727
    .line 728
    goto :goto_7

    .line 729
    :catchall_1
    move-exception v0

    .line 730
    move-object p1, v0

    .line 731
    goto :goto_8

    .line 732
    :cond_15
    iput-object v4, v0, LI/E0;->e:Ljava/lang/Throwable;

    .line 733
    .line 734
    iget-object p1, v0, LI/E0;->u:Lf2/G;

    .line 735
    .line 736
    sget-object v0, LI/y0;->d:LI/y0;

    .line 737
    .line 738
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 739
    .line 740
    .line 741
    invoke-virtual {p1, v1, v0}, Lf2/G;->h(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 742
    .line 743
    .line 744
    :goto_7
    monitor-exit v3

    .line 745
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 746
    .line 747
    return-object p1

    .line 748
    :goto_8
    monitor-exit v3

    .line 749
    throw p1

    .line 750
    :pswitch_11
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 751
    .line 752
    check-cast v0, LI/y;

    .line 753
    .line 754
    invoke-virtual {v0, p1}, LI/y;->u(Ljava/lang/Object;)V

    .line 755
    .line 756
    .line 757
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 758
    .line 759
    return-object p1

    .line 760
    :pswitch_12
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 761
    .line 762
    check-cast v0, LU1/a;

    .line 763
    .line 764
    check-cast p1, LT0/c;

    .line 765
    .line 766
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 767
    .line 768
    .line 769
    move-result-object p1

    .line 770
    check-cast p1, Lc0/b;

    .line 771
    .line 772
    return-object p1

    .line 773
    :pswitch_13
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 774
    .line 775
    check-cast v0, Ljava/util/ArrayList;

    .line 776
    .line 777
    check-cast p1, Lu0/K;

    .line 778
    .line 779
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 780
    .line 781
    .line 782
    move-result v1

    .line 783
    move v2, v4

    .line 784
    :goto_9
    if-ge v2, v1, :cond_16

    .line 785
    .line 786
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v3

    .line 790
    check-cast v3, Lu0/L;

    .line 791
    .line 792
    invoke-static {p1, v3, v4, v4}, Lu0/K;->x(Lu0/K;Lu0/L;II)V

    .line 793
    .line 794
    .line 795
    add-int/lit8 v2, v2, 0x1

    .line 796
    .line 797
    goto :goto_9

    .line 798
    :cond_16
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 799
    .line 800
    return-object p1

    .line 801
    :pswitch_14
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 802
    .line 803
    move-object v6, v0

    .line 804
    check-cast v6, LH/X;

    .line 805
    .line 806
    check-cast p1, Lq0/u;

    .line 807
    .line 808
    iget-wide v8, p1, Lq0/u;->c:J

    .line 809
    .line 810
    iget-object v0, v6, LH/X;->d:Ljava/lang/Object;

    .line 811
    .line 812
    check-cast v0, LH/m0;

    .line 813
    .line 814
    invoke-virtual {v0}, LH/m0;->k()Z

    .line 815
    .line 816
    .line 817
    move-result v1

    .line 818
    if-eqz v1, :cond_19

    .line 819
    .line 820
    invoke-virtual {v0}, LH/m0;->n()LM0/x;

    .line 821
    .line 822
    .line 823
    move-result-object v1

    .line 824
    iget-object v1, v1, LM0/x;->a:LH0/g;

    .line 825
    .line 826
    iget-object v1, v1, LH0/g;->e:Ljava/lang/String;

    .line 827
    .line 828
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 829
    .line 830
    .line 831
    move-result v1

    .line 832
    if-nez v1, :cond_17

    .line 833
    .line 834
    goto :goto_a

    .line 835
    :cond_17
    iget-object v1, v0, LH/m0;->d:Lw/S;

    .line 836
    .line 837
    if-eqz v1, :cond_19

    .line 838
    .line 839
    invoke-virtual {v1}, Lw/S;->d()Lw/p0;

    .line 840
    .line 841
    .line 842
    move-result-object v1

    .line 843
    if-nez v1, :cond_18

    .line 844
    .line 845
    goto :goto_a

    .line 846
    :cond_18
    invoke-virtual {v0}, LH/m0;->n()LM0/x;

    .line 847
    .line 848
    .line 849
    move-result-object v7

    .line 850
    const/4 v10, 0x0

    .line 851
    sget-object v11, LH/A;->d:LH/z;

    .line 852
    .line 853
    invoke-virtual/range {v6 .. v11}, LH/X;->c(LM0/x;JZLH/z;)J

    .line 854
    .line 855
    .line 856
    move v4, v5

    .line 857
    :cond_19
    :goto_a
    if-eqz v4, :cond_1a

    .line 858
    .line 859
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 860
    .line 861
    .line 862
    :cond_1a
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 863
    .line 864
    return-object p1

    .line 865
    :pswitch_15
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 866
    .line 867
    check-cast v0, LF/A;

    .line 868
    .line 869
    check-cast p1, LM0/g;

    .line 870
    .line 871
    invoke-virtual {v0, p1}, LF/A;->a(LM0/g;)V

    .line 872
    .line 873
    .line 874
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 875
    .line 876
    return-object p1

    .line 877
    :pswitch_16
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 878
    .line 879
    check-cast v0, LD/c;

    .line 880
    .line 881
    check-cast p1, LI/I;

    .line 882
    .line 883
    new-instance p1, LB/l;

    .line 884
    .line 885
    invoke-direct {p1, v5, v0}, LB/l;-><init>(ILjava/lang/Object;)V

    .line 886
    .line 887
    .line 888
    return-object p1

    .line 889
    :pswitch_17
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 890
    .line 891
    check-cast v0, LB/y;

    .line 892
    .line 893
    check-cast p1, Lw0/y0;

    .line 894
    .line 895
    instance-of v1, p1, LC/a;

    .line 896
    .line 897
    if-eqz v1, :cond_1b

    .line 898
    .line 899
    check-cast p1, LC/a;

    .line 900
    .line 901
    iget-object p1, p1, LC/a;->r:LB/y;

    .line 902
    .line 903
    invoke-virtual {v0, p1}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 904
    .line 905
    .line 906
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 907
    .line 908
    return-object p1

    .line 909
    :cond_1b
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 910
    .line 911
    const-string v0, "TextContextMenuDataNode.TraverseKey key must only be attached to instances of TextContextMenuDataNode."

    .line 912
    .line 913
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 914
    .line 915
    .line 916
    throw p1

    .line 917
    :pswitch_18
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 918
    .line 919
    check-cast v0, Ly/a;

    .line 920
    .line 921
    check-cast p1, LU1/c;

    .line 922
    .line 923
    invoke-interface {p1, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 924
    .line 925
    .line 926
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 927
    .line 928
    return-object p1

    .line 929
    :pswitch_19
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 930
    .line 931
    check-cast v0, LC/c;

    .line 932
    .line 933
    check-cast p1, Ly/a;

    .line 934
    .line 935
    iget-object v1, v0, LC/c;->t:LB/p;

    .line 936
    .line 937
    sget-object v2, Lx0/J;->b:LI/b1;

    .line 938
    .line 939
    invoke-static {v0, v2}, Lw0/j;->h(Lw0/g;LI/t0;)Ljava/lang/Object;

    .line 940
    .line 941
    .line 942
    move-result-object v0

    .line 943
    invoke-virtual {v1, p1, v0}, LB/p;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 944
    .line 945
    .line 946
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 947
    .line 948
    return-object p1

    .line 949
    :pswitch_1a
    iget-object v0, p0, LB/y;->e:Ljava/lang/Object;

    .line 950
    .line 951
    check-cast v0, Landroid/graphics/drawable/Drawable;

    .line 952
    .line 953
    check-cast p1, Lf0/d;

    .line 954
    .line 955
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 956
    .line 957
    .line 958
    move-result-object v1

    .line 959
    invoke-virtual {v1}, LI/e0;->m()Ld0/u;

    .line 960
    .line 961
    .line 962
    move-result-object v1

    .line 963
    invoke-interface {p1}, Lf0/d;->a()J

    .line 964
    .line 965
    .line 966
    move-result-wide v2

    .line 967
    const/16 v5, 0x20

    .line 968
    .line 969
    shr-long/2addr v2, v5

    .line 970
    long-to-int v2, v2

    .line 971
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 972
    .line 973
    .line 974
    move-result v2

    .line 975
    float-to-int v2, v2

    .line 976
    invoke-interface {p1}, Lf0/d;->a()J

    .line 977
    .line 978
    .line 979
    move-result-wide v5

    .line 980
    const-wide v7, 0xffffffffL

    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    and-long/2addr v5, v7

    .line 986
    long-to-int p1, v5

    .line 987
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 988
    .line 989
    .line 990
    move-result p1

    .line 991
    float-to-int p1, p1

    .line 992
    invoke-virtual {v0, v4, v4, v2, p1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 993
    .line 994
    .line 995
    invoke-static {v1}, Ld0/c;->a(Ld0/u;)Landroid/graphics/Canvas;

    .line 996
    .line 997
    .line 998
    move-result-object p1

    .line 999
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 1000
    .line 1001
    .line 1002
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 1003
    .line 1004
    return-object p1

    .line 1005
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
