.class public interface abstract LB0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lw0/h;


# virtual methods
.method public abstract E0(Lw0/b0;LB0/b;LP1/c;)Ljava/lang/Object;
.end method
