.class public final LB0/b;
.super LV1/j;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LB0/b;->e:I

    iput-object p2, p0, LB0/b;->f:Ljava/lang/Object;

    iput-object p3, p0, LB0/b;->g:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, LV1/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LB0/b;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB0/b;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lx0/x;

    .line 9
    .line 10
    iget-object v1, p0, LB0/b;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lx0/D0;

    .line 13
    .line 14
    iget-object v2, v1, Lx0/D0;->h:LE0/h;

    .line 15
    .line 16
    iget-object v3, v1, Lx0/D0;->i:LE0/h;

    .line 17
    .line 18
    iget-object v4, v1, Lx0/D0;->f:Ljava/lang/Float;

    .line 19
    .line 20
    iget-object v5, v1, Lx0/D0;->g:Ljava/lang/Float;

    .line 21
    .line 22
    const/4 v6, 0x0

    .line 23
    if-eqz v2, :cond_0

    .line 24
    .line 25
    if-eqz v4, :cond_0

    .line 26
    .line 27
    iget-object v7, v2, LE0/h;->a:Ln/n0;

    .line 28
    .line 29
    invoke-virtual {v7}, Ln/n0;->a()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v7

    .line 33
    check-cast v7, Ljava/lang/Number;

    .line 34
    .line 35
    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    .line 36
    .line 37
    .line 38
    move-result v7

    .line 39
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    sub-float/2addr v7, v4

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v7, v6

    .line 46
    :goto_0
    if-eqz v3, :cond_1

    .line 47
    .line 48
    if-eqz v5, :cond_1

    .line 49
    .line 50
    iget-object v4, v3, LE0/h;->a:Ln/n0;

    .line 51
    .line 52
    invoke-virtual {v4}, Ln/n0;->a()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    check-cast v4, Ljava/lang/Number;

    .line 57
    .line 58
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    sub-float/2addr v4, v5

    .line 67
    goto :goto_1

    .line 68
    :cond_1
    move v4, v6

    .line 69
    :goto_1
    cmpg-float v5, v7, v6

    .line 70
    .line 71
    if-nez v5, :cond_2

    .line 72
    .line 73
    cmpg-float v4, v4, v6

    .line 74
    .line 75
    if-nez v4, :cond_2

    .line 76
    .line 77
    goto :goto_2

    .line 78
    :cond_2
    iget v4, v1, Lx0/D0;->d:I

    .line 79
    .line 80
    invoke-virtual {v0, v4}, Lx0/x;->s(I)I

    .line 81
    .line 82
    .line 83
    move-result v4

    .line 84
    invoke-virtual {v0}, Lx0/x;->k()Li/l;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    iget v6, v0, Lx0/x;->o:I

    .line 89
    .line 90
    invoke-virtual {v5, v6}, Li/l;->b(I)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    check-cast v5, LE0/o;

    .line 95
    .line 96
    if-eqz v5, :cond_3

    .line 97
    .line 98
    :try_start_0
    iget-object v6, v0, Lx0/x;->q:Lh1/g;

    .line 99
    .line 100
    if-eqz v6, :cond_3

    .line 101
    .line 102
    invoke-virtual {v0, v5}, Lx0/x;->c(LE0/o;)Landroid/graphics/Rect;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    iget-object v6, v6, Lh1/g;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 107
    .line 108
    invoke-virtual {v6, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInScreen(Landroid/graphics/Rect;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 109
    .line 110
    .line 111
    :catch_0
    :cond_3
    invoke-virtual {v0}, Lx0/x;->k()Li/l;

    .line 112
    .line 113
    .line 114
    move-result-object v5

    .line 115
    iget v6, v0, Lx0/x;->p:I

    .line 116
    .line 117
    invoke-virtual {v5, v6}, Li/l;->b(I)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    check-cast v5, LE0/o;

    .line 122
    .line 123
    if-eqz v5, :cond_4

    .line 124
    .line 125
    :try_start_1
    iget-object v6, v0, Lx0/x;->r:Lh1/g;

    .line 126
    .line 127
    if-eqz v6, :cond_4

    .line 128
    .line 129
    invoke-virtual {v0, v5}, Lx0/x;->c(LE0/o;)Landroid/graphics/Rect;

    .line 130
    .line 131
    .line 132
    move-result-object v5

    .line 133
    iget-object v6, v6, Lh1/g;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 134
    .line 135
    invoke-virtual {v6, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInScreen(Landroid/graphics/Rect;)V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1

    .line 136
    .line 137
    .line 138
    :catch_1
    :cond_4
    iget-object v5, v0, Lx0/x;->g:Lx0/s;

    .line 139
    .line 140
    invoke-virtual {v5}, Landroid/view/View;->invalidate()V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v0}, Lx0/x;->k()Li/l;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    invoke-virtual {v5, v4}, Li/l;->b(I)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v5

    .line 151
    check-cast v5, LE0/o;

    .line 152
    .line 153
    if-eqz v5, :cond_7

    .line 154
    .line 155
    iget-object v5, v5, LE0/o;->a:LE0/n;

    .line 156
    .line 157
    if-eqz v5, :cond_7

    .line 158
    .line 159
    iget-object v5, v5, LE0/n;->c:Lw0/E;

    .line 160
    .line 161
    if-eqz v5, :cond_7

    .line 162
    .line 163
    if-eqz v2, :cond_5

    .line 164
    .line 165
    iget-object v6, v0, Lx0/x;->t:Li/x;

    .line 166
    .line 167
    invoke-virtual {v6, v4, v2}, Li/x;->h(ILjava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    :cond_5
    if-eqz v3, :cond_6

    .line 171
    .line 172
    iget-object v6, v0, Lx0/x;->u:Li/x;

    .line 173
    .line 174
    invoke-virtual {v6, v4, v3}, Li/x;->h(ILjava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_6
    invoke-virtual {v0, v5}, Lx0/x;->o(Lw0/E;)V

    .line 178
    .line 179
    .line 180
    :cond_7
    :goto_2
    if-eqz v2, :cond_8

    .line 181
    .line 182
    iget-object v0, v2, LE0/h;->a:Ln/n0;

    .line 183
    .line 184
    invoke-virtual {v0}, Ln/n0;->a()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    check-cast v0, Ljava/lang/Float;

    .line 189
    .line 190
    iput-object v0, v1, Lx0/D0;->f:Ljava/lang/Float;

    .line 191
    .line 192
    :cond_8
    if-eqz v3, :cond_9

    .line 193
    .line 194
    iget-object v0, v3, LE0/h;->a:Ln/n0;

    .line 195
    .line 196
    invoke-virtual {v0}, Ln/n0;->a()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    check-cast v0, Ljava/lang/Float;

    .line 201
    .line 202
    iput-object v0, v1, Lx0/D0;->g:Ljava/lang/Float;

    .line 203
    .line 204
    :cond_9
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 205
    .line 206
    return-object v0

    .line 207
    :pswitch_0
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, Lx0/s;

    .line 210
    .line 211
    iget-object v1, p0, LB0/b;->g:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v1, Landroid/view/KeyEvent;

    .line 214
    .line 215
    invoke-static {v0, v1}, Lx0/s;->f(Lx0/s;Landroid/view/KeyEvent;)Z

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    return-object v0

    .line 224
    :pswitch_1
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 225
    .line 226
    check-cast v0, LU1/c;

    .line 227
    .line 228
    sget-object v1, Lw0/b0;->P:Ld0/P;

    .line 229
    .line 230
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    iget-object v0, p0, LB0/b;->g:Ljava/lang/Object;

    .line 234
    .line 235
    check-cast v0, Lw0/b0;

    .line 236
    .line 237
    iget-object v2, v0, Lw0/b0;->G:Ld0/T;

    .line 238
    .line 239
    iget-object v3, v1, Ld0/P;->q:Ld0/T;

    .line 240
    .line 241
    const/4 v4, 0x0

    .line 242
    const/4 v5, 0x1

    .line 243
    if-eq v2, v3, :cond_a

    .line 244
    .line 245
    move v2, v5

    .line 246
    goto :goto_3

    .line 247
    :cond_a
    move v2, v4

    .line 248
    :goto_3
    iget-boolean v6, v0, Lw0/b0;->H:Z

    .line 249
    .line 250
    iget-boolean v7, v1, Ld0/P;->r:Z

    .line 251
    .line 252
    if-eq v6, v7, :cond_b

    .line 253
    .line 254
    move v4, v5

    .line 255
    :cond_b
    if-nez v2, :cond_c

    .line 256
    .line 257
    if-eqz v4, :cond_e

    .line 258
    .line 259
    :cond_c
    iput-object v3, v0, Lw0/b0;->G:Ld0/T;

    .line 260
    .line 261
    iput-boolean v7, v0, Lw0/b0;->H:Z

    .line 262
    .line 263
    iget-boolean v3, v0, Lw0/b0;->I:Z

    .line 264
    .line 265
    if-eqz v3, :cond_e

    .line 266
    .line 267
    if-nez v4, :cond_d

    .line 268
    .line 269
    if-eqz v7, :cond_e

    .line 270
    .line 271
    if-eqz v2, :cond_e

    .line 272
    .line 273
    :cond_d
    iget-object v2, v0, Lw0/b0;->r:Lw0/E;

    .line 274
    .line 275
    invoke-virtual {v2}, Lw0/E;->A()V

    .line 276
    .line 277
    .line 278
    :cond_e
    iput-boolean v5, v0, Lw0/b0;->I:Z

    .line 279
    .line 280
    iget-object v0, v1, Ld0/P;->q:Ld0/T;

    .line 281
    .line 282
    iget-wide v2, v1, Ld0/P;->t:J

    .line 283
    .line 284
    iget-object v4, v1, Ld0/P;->v:LT0/o;

    .line 285
    .line 286
    iget-object v5, v1, Ld0/P;->u:LT0/c;

    .line 287
    .line 288
    invoke-interface {v0, v2, v3, v4, v5}, Ld0/T;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    iput-object v0, v1, Ld0/P;->x:Ld0/D;

    .line 293
    .line 294
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 295
    .line 296
    return-object v0

    .line 297
    :pswitch_2
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast v0, Lw0/E;

    .line 300
    .line 301
    iget-object v0, v0, Lw0/E;->I:LQ/m;

    .line 302
    .line 303
    iget-object v1, p0, LB0/b;->g:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v1, LV1/s;

    .line 306
    .line 307
    iget-object v2, v0, LQ/m;->j:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v2, LW/p;

    .line 310
    .line 311
    iget v2, v2, LW/p;->g:I

    .line 312
    .line 313
    and-int/lit8 v2, v2, 0x8

    .line 314
    .line 315
    if-eqz v2, :cond_19

    .line 316
    .line 317
    iget-object v0, v0, LQ/m;->i:Ljava/lang/Object;

    .line 318
    .line 319
    check-cast v0, Lw0/v0;

    .line 320
    .line 321
    :goto_4
    if-eqz v0, :cond_19

    .line 322
    .line 323
    iget v2, v0, LW/p;->f:I

    .line 324
    .line 325
    and-int/lit8 v2, v2, 0x8

    .line 326
    .line 327
    if-eqz v2, :cond_18

    .line 328
    .line 329
    const/4 v2, 0x0

    .line 330
    move-object v3, v0

    .line 331
    move-object v4, v2

    .line 332
    :goto_5
    if-eqz v3, :cond_18

    .line 333
    .line 334
    instance-of v5, v3, Lw0/t0;

    .line 335
    .line 336
    const/4 v6, 0x1

    .line 337
    if-eqz v5, :cond_11

    .line 338
    .line 339
    check-cast v3, Lw0/t0;

    .line 340
    .line 341
    invoke-interface {v3}, Lw0/t0;->q0()Z

    .line 342
    .line 343
    .line 344
    move-result v5

    .line 345
    if-eqz v5, :cond_f

    .line 346
    .line 347
    new-instance v5, LE0/k;

    .line 348
    .line 349
    invoke-direct {v5}, LE0/k;-><init>()V

    .line 350
    .line 351
    .line 352
    iput-object v5, v1, LV1/s;->d:Ljava/lang/Object;

    .line 353
    .line 354
    iput-boolean v6, v5, LE0/k;->g:Z

    .line 355
    .line 356
    :cond_f
    invoke-interface {v3}, Lw0/t0;->r0()Z

    .line 357
    .line 358
    .line 359
    move-result v5

    .line 360
    if-eqz v5, :cond_10

    .line 361
    .line 362
    iget-object v5, v1, LV1/s;->d:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v5, LE0/k;

    .line 365
    .line 366
    iput-boolean v6, v5, LE0/k;->f:Z

    .line 367
    .line 368
    :cond_10
    iget-object v5, v1, LV1/s;->d:Ljava/lang/Object;

    .line 369
    .line 370
    check-cast v5, LE0/v;

    .line 371
    .line 372
    invoke-interface {v3, v5}, Lw0/t0;->C(LE0/v;)V

    .line 373
    .line 374
    .line 375
    goto :goto_8

    .line 376
    :cond_11
    iget v5, v3, LW/p;->f:I

    .line 377
    .line 378
    and-int/lit8 v5, v5, 0x8

    .line 379
    .line 380
    if-eqz v5, :cond_17

    .line 381
    .line 382
    instance-of v5, v3, Lw0/i;

    .line 383
    .line 384
    if-eqz v5, :cond_17

    .line 385
    .line 386
    move-object v5, v3

    .line 387
    check-cast v5, Lw0/i;

    .line 388
    .line 389
    iget-object v5, v5, Lw0/i;->s:LW/p;

    .line 390
    .line 391
    const/4 v7, 0x0

    .line 392
    :goto_6
    if-eqz v5, :cond_16

    .line 393
    .line 394
    iget v8, v5, LW/p;->f:I

    .line 395
    .line 396
    and-int/lit8 v8, v8, 0x8

    .line 397
    .line 398
    if-eqz v8, :cond_15

    .line 399
    .line 400
    add-int/lit8 v7, v7, 0x1

    .line 401
    .line 402
    if-ne v7, v6, :cond_12

    .line 403
    .line 404
    move-object v3, v5

    .line 405
    goto :goto_7

    .line 406
    :cond_12
    if-nez v4, :cond_13

    .line 407
    .line 408
    new-instance v4, LK/e;

    .line 409
    .line 410
    const/16 v8, 0x10

    .line 411
    .line 412
    new-array v8, v8, [LW/p;

    .line 413
    .line 414
    invoke-direct {v4, v8}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 415
    .line 416
    .line 417
    :cond_13
    if-eqz v3, :cond_14

    .line 418
    .line 419
    invoke-virtual {v4, v3}, LK/e;->b(Ljava/lang/Object;)V

    .line 420
    .line 421
    .line 422
    move-object v3, v2

    .line 423
    :cond_14
    invoke-virtual {v4, v5}, LK/e;->b(Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    :cond_15
    :goto_7
    iget-object v5, v5, LW/p;->i:LW/p;

    .line 427
    .line 428
    goto :goto_6

    .line 429
    :cond_16
    if-ne v7, v6, :cond_17

    .line 430
    .line 431
    goto :goto_5

    .line 432
    :cond_17
    :goto_8
    invoke-static {v4}, Lw0/j;->e(LK/e;)LW/p;

    .line 433
    .line 434
    .line 435
    move-result-object v3

    .line 436
    goto :goto_5

    .line 437
    :cond_18
    iget-object v0, v0, LW/p;->h:LW/p;

    .line 438
    .line 439
    goto :goto_4

    .line 440
    :cond_19
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 441
    .line 442
    return-object v0

    .line 443
    :pswitch_3
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast v0, Lq0/d;

    .line 446
    .line 447
    iget-object v1, p0, LB0/b;->g:Ljava/lang/Object;

    .line 448
    .line 449
    check-cast v1, LW/p;

    .line 450
    .line 451
    invoke-virtual {v0, v1}, Lq0/d;->d(LW/p;)V

    .line 452
    .line 453
    .line 454
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 455
    .line 456
    return-object v0

    .line 457
    :pswitch_4
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v0, LV1/s;

    .line 460
    .line 461
    iget-object v1, p0, LB0/b;->g:Ljava/lang/Object;

    .line 462
    .line 463
    check-cast v1, Lb0/y;

    .line 464
    .line 465
    invoke-virtual {v1}, Lb0/y;->W0()Lb0/s;

    .line 466
    .line 467
    .line 468
    move-result-object v1

    .line 469
    iput-object v1, v0, LV1/s;->d:Ljava/lang/Object;

    .line 470
    .line 471
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 472
    .line 473
    return-object v0

    .line 474
    :pswitch_5
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 475
    .line 476
    check-cast v0, La0/b;

    .line 477
    .line 478
    iget-object v0, v0, La0/b;->t:LU1/c;

    .line 479
    .line 480
    iget-object v1, p0, LB0/b;->g:Ljava/lang/Object;

    .line 481
    .line 482
    check-cast v1, La0/c;

    .line 483
    .line 484
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 485
    .line 486
    .line 487
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 488
    .line 489
    return-object v0

    .line 490
    :pswitch_6
    iget-object v0, p0, LB0/b;->f:Ljava/lang/Object;

    .line 491
    .line 492
    check-cast v0, LU1/a;

    .line 493
    .line 494
    if-eqz v0, :cond_1a

    .line 495
    .line 496
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 497
    .line 498
    .line 499
    move-result-object v0

    .line 500
    check-cast v0, Lc0/c;

    .line 501
    .line 502
    if-nez v0, :cond_1d

    .line 503
    .line 504
    :cond_1a
    iget-object v0, p0, LB0/b;->g:Ljava/lang/Object;

    .line 505
    .line 506
    check-cast v0, Lw0/b0;

    .line 507
    .line 508
    invoke-virtual {v0}, Lw0/b0;->h1()LW/p;

    .line 509
    .line 510
    .line 511
    move-result-object v1

    .line 512
    iget-boolean v1, v1, LW/p;->q:Z

    .line 513
    .line 514
    const/4 v2, 0x0

    .line 515
    if-eqz v1, :cond_1b

    .line 516
    .line 517
    goto :goto_9

    .line 518
    :cond_1b
    move-object v0, v2

    .line 519
    :goto_9
    if-eqz v0, :cond_1c

    .line 520
    .line 521
    iget-wide v0, v0, Lu0/L;->f:J

    .line 522
    .line 523
    invoke-static {v0, v1}, LT0/l;->O(J)J

    .line 524
    .line 525
    .line 526
    move-result-wide v0

    .line 527
    const-wide/16 v2, 0x0

    .line 528
    .line 529
    invoke-static {v2, v3, v0, v1}, LT0/l;->b(JJ)Lc0/c;

    .line 530
    .line 531
    .line 532
    move-result-object v0

    .line 533
    goto :goto_a

    .line 534
    :cond_1c
    move-object v0, v2

    .line 535
    :cond_1d
    :goto_a
    return-object v0

    .line 536
    nop

    .line 537
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
