.class public final LB1/C;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LB1/G;


# direct methods
.method public constructor <init>(LB1/G;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/C;->i:LB1/G;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/C;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/C;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/C;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 1

    .line 1
    new-instance p2, LB1/C;

    .line 2
    .line 3
    iget-object v0, p0, LB1/C;->i:LB1/G;

    .line 4
    .line 5
    invoke-direct {p2, v0, p1}, LB1/C;-><init>(LB1/G;LN1/c;)V

    .line 6
    .line 7
    .line 8
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LB1/C;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-wide v0, -0x349a3377dbfaL

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, LB1/C;->i:LB1/G;

    .line 31
    .line 32
    iget-object v2, p1, LB1/G;->e:Ll/c;

    .line 33
    .line 34
    new-instance v3, Ljava/lang/Float;

    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-direct {v3, v0}, Ljava/lang/Float;-><init>(F)V

    .line 38
    .line 39
    .line 40
    iget-object v4, p1, LB1/G;->c:Ll/C;

    .line 41
    .line 42
    iput v1, p0, LB1/C;->h:I

    .line 43
    .line 44
    const/4 v5, 0x0

    .line 45
    const/16 v7, 0xc

    .line 46
    .line 47
    move-object v6, p0

    .line 48
    invoke-static/range {v2 .. v7}, Ll/c;->b(Ll/c;Ljava/lang/Object;Ll/h;LA1/G;LN1/c;I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    sget-object v0, LO1/a;->d:LO1/a;

    .line 53
    .line 54
    if-ne p1, v0, :cond_2

    .line 55
    .line 56
    return-object v0

    .line 57
    :cond_2
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 58
    .line 59
    return-object p1
.end method
