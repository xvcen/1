.class public final LB1/E;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:LB1/G;


# direct methods
.method public constructor <init>(LB1/G;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/E;->i:LB1/G;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/E;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/E;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/E;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LB1/E;

    .line 2
    .line 3
    iget-object v1, p0, LB1/E;->i:LB1/G;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LB1/E;-><init>(LB1/G;LN1/c;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, LB1/E;->h:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LB1/E;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lc2/s;

    .line 4
    .line 5
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, LB1/C;

    .line 9
    .line 10
    iget-object v1, p0, LB1/E;->i:LB1/G;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {p1, v1, v2}, LB1/C;-><init>(LB1/G;LN1/c;)V

    .line 14
    .line 15
    .line 16
    const/4 v3, 0x3

    .line 17
    invoke-static {v0, v2, p1, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 18
    .line 19
    .line 20
    new-instance p1, LB1/D;

    .line 21
    .line 22
    invoke-direct {p1, v1, v2}, LB1/D;-><init>(LB1/G;LN1/c;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v0, v2, p1, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 26
    .line 27
    .line 28
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 29
    .line 30
    return-object p1
.end method
