.class public final LB1/G;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc2/s;

.field public final b:LU1/e;

.field public final c:Ll/C;

.field public final d:Ll/C;

.field public final e:Ll/c;

.field public final f:Ll/c;

.field public g:J

.field public final h:Landroid/graphics/RuntimeShader;

.field public final i:LW/q;

.field public final j:LW/q;


# direct methods
.method public constructor <init>(Lc2/s;)V
    .locals 13

    .line 1
    new-instance v0, LA1/E;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, LA1/E;-><init>(I)V

    .line 5
    .line 6
    .line 7
    const-wide v1, -0x346b3377dbfaL

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-static {p1, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-wide v1, -0x34783377dbfaL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    invoke-static {v1, v2}, LI1/a;->a(J)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, LB1/G;->a:Lc2/s;

    .line 31
    .line 32
    iput-object v0, p0, LB1/G;->b:LU1/e;

    .line 33
    .line 34
    const v0, 0x3a83126f    # 0.001f

    .line 35
    .line 36
    .line 37
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    new-instance v2, Ll/C;

    .line 42
    .line 43
    const/high16 v3, 0x3f000000    # 0.5f

    .line 44
    .line 45
    const/high16 v4, 0x43960000    # 300.0f

    .line 46
    .line 47
    invoke-direct {v2, v3, v4, v1}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iput-object v2, p0, LB1/G;->c:Ll/C;

    .line 51
    .line 52
    const/high16 v1, 0x3f800000    # 1.0f

    .line 53
    .line 54
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    int-to-long v5, v2

    .line 59
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    int-to-long v7, v2

    .line 64
    const/16 v2, 0x20

    .line 65
    .line 66
    shl-long/2addr v5, v2

    .line 67
    const-wide v9, 0xffffffffL

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    and-long/2addr v7, v9

    .line 73
    or-long/2addr v5, v7

    .line 74
    new-instance v7, Lc0/b;

    .line 75
    .line 76
    invoke-direct {v7, v5, v6}, Lc0/b;-><init>(J)V

    .line 77
    .line 78
    .line 79
    new-instance v5, Ll/C;

    .line 80
    .line 81
    invoke-direct {v5, v3, v4, v7}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iput-object v5, p0, LB1/G;->d:Ll/C;

    .line 85
    .line 86
    const/4 v3, 0x0

    .line 87
    invoke-static {v3, v0}, Ll/d;->a(FF)Ll/c;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iput-object v0, p0, LB1/G;->e:Ll/c;

    .line 92
    .line 93
    new-instance v0, Ll/c;

    .line 94
    .line 95
    new-instance v3, Lc0/b;

    .line 96
    .line 97
    const-wide/16 v4, 0x0

    .line 98
    .line 99
    invoke-direct {v3, v4, v5}, Lc0/b;-><init>(J)V

    .line 100
    .line 101
    .line 102
    sget-object v6, Ll/d;->o:LF/r;

    .line 103
    .line 104
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 105
    .line 106
    .line 107
    move-result v7

    .line 108
    int-to-long v7, v7

    .line 109
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    int-to-long v11, v1

    .line 114
    shl-long v1, v7, v2

    .line 115
    .line 116
    and-long v7, v11, v9

    .line 117
    .line 118
    or-long/2addr v1, v7

    .line 119
    new-instance v7, Lc0/b;

    .line 120
    .line 121
    invoke-direct {v7, v1, v2}, Lc0/b;-><init>(J)V

    .line 122
    .line 123
    .line 124
    invoke-direct {v0, v3, v6, v7}, Ll/c;-><init>(Ljava/lang/Object;LF/r;Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    iput-object v0, p0, LB1/G;->f:Ll/c;

    .line 128
    .line 129
    iput-wide v4, p0, LB1/G;->g:J

    .line 130
    .line 131
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 132
    .line 133
    const/16 v1, 0x21

    .line 134
    .line 135
    if-lt v0, v1, :cond_0

    .line 136
    .line 137
    invoke-static {}, LB1/v;->k()V

    .line 138
    .line 139
    .line 140
    const-wide v0, -0x35833377dbfaL

    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-static {v0}, LB1/v;->c(Ljava/lang/String;)Landroid/graphics/RuntimeShader;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    goto :goto_0

    .line 154
    :cond_0
    const/4 v0, 0x0

    .line 155
    :goto_0
    iput-object v0, p0, LB1/G;->h:Landroid/graphics/RuntimeShader;

    .line 156
    .line 157
    new-instance v0, LA1/q;

    .line 158
    .line 159
    const/4 v1, 0x1

    .line 160
    invoke-direct {v0, p0, v1}, LA1/q;-><init>(LB1/G;I)V

    .line 161
    .line 162
    .line 163
    sget-object v1, LW/n;->a:LW/n;

    .line 164
    .line 165
    invoke-static {v1, v0}, La0/g;->e(LW/q;LU1/c;)LW/q;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    iput-object v0, p0, LB1/G;->i:LW/q;

    .line 170
    .line 171
    new-instance v0, LB1/e;

    .line 172
    .line 173
    const/4 v2, 0x1

    .line 174
    invoke-direct {v0, v2, p0}, LB1/e;-><init>(ILjava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v1, p1, v0}, Lq0/E;->a(LW/q;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)LW/q;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    iput-object p1, p0, LB1/G;->j:LW/q;

    .line 182
    .line 183
    return-void
.end method
