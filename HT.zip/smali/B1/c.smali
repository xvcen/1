.class public final LB1/c;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic h:LB1/t;

.field public final synthetic i:F

.field public final synthetic j:Lc2/s;


# direct methods
.method public constructor <init>(LB1/t;FLc2/s;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/c;->h:LB1/t;

    .line 2
    .line 3
    iput p2, p0, LB1/c;->i:F

    .line 4
    .line 5
    iput-object p3, p0, LB1/c;->j:Lc2/s;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1, p4}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    check-cast p1, LN1/c;

    .line 2
    .line 3
    new-instance v0, LB1/c;

    .line 4
    .line 5
    iget v1, p0, LB1/c;->i:F

    .line 6
    .line 7
    iget-object v2, p0, LB1/c;->j:Lc2/s;

    .line 8
    .line 9
    iget-object v3, p0, LB1/c;->h:LB1/t;

    .line 10
    .line 11
    invoke-direct {v0, v3, v1, v2, p1}, LB1/c;-><init>(LB1/t;FLc2/s;LN1/c;)V

    .line 12
    .line 13
    .line 14
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 15
    .line 16
    invoke-virtual {v0, p1}, LB1/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-object p1
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, LB1/c;->h:LB1/t;

    .line 5
    .line 6
    iget-object v0, p1, LB1/t;->s:Lq0/w;

    .line 7
    .line 8
    iget-object v0, v0, Lq0/w;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lr0/b;

    .line 11
    .line 12
    iget-object v1, v0, Lr0/b;->a:Lr0/d;

    .line 13
    .line 14
    iget-object v2, v1, Lr0/d;->d:[Lr0/a;

    .line 15
    .line 16
    array-length v3, v2

    .line 17
    const/4 v4, 0x0

    .line 18
    invoke-static {v2, v4, v3}, LK1/l;->X([Ljava/lang/Object;II)V

    .line 19
    .line 20
    .line 21
    iput v4, v1, Lr0/d;->e:I

    .line 22
    .line 23
    iget-object v1, v0, Lr0/b;->b:Lr0/d;

    .line 24
    .line 25
    iget-object v2, v1, Lr0/d;->d:[Lr0/a;

    .line 26
    .line 27
    array-length v3, v2

    .line 28
    invoke-static {v2, v4, v3}, LK1/l;->X([Ljava/lang/Object;II)V

    .line 29
    .line 30
    .line 31
    iput v4, v1, Lr0/d;->e:I

    .line 32
    .line 33
    const-wide/16 v1, 0x0

    .line 34
    .line 35
    iput-wide v1, v0, Lr0/b;->c:J

    .line 36
    .line 37
    iget-object v0, p1, LB1/t;->a:Lc2/s;

    .line 38
    .line 39
    new-instance v1, LB1/i;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-direct {v1, p1, v2}, LB1/i;-><init>(LB1/t;LN1/c;)V

    .line 43
    .line 44
    .line 45
    const/4 v3, 0x3

    .line 46
    invoke-static {v0, v2, v1, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 47
    .line 48
    .line 49
    new-instance v1, Ljava/lang/Float;

    .line 50
    .line 51
    iget v4, p0, LB1/c;->i:F

    .line 52
    .line 53
    invoke-direct {v1, v4}, Ljava/lang/Float;-><init>(F)V

    .line 54
    .line 55
    .line 56
    iget-object v4, p1, LB1/t;->b:LY1/a;

    .line 57
    .line 58
    invoke-static {v1, v4}, LT0/l;->n(Ljava/lang/Float;LY1/a;)Ljava/lang/Comparable;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Ljava/lang/Number;

    .line 63
    .line 64
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    new-instance v4, LB1/a;

    .line 69
    .line 70
    invoke-direct {v4, p1, v1, v2}, LB1/a;-><init>(LB1/t;FLN1/c;)V

    .line 71
    .line 72
    .line 73
    iget-object v1, p0, LB1/c;->j:Lc2/s;

    .line 74
    .line 75
    invoke-static {v1, v2, v4, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 76
    .line 77
    .line 78
    iget-object v4, p1, LB1/t;->n:Ll/c;

    .line 79
    .line 80
    invoke-virtual {v4}, Ll/c;->c()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    check-cast v4, Ljava/lang/Number;

    .line 85
    .line 86
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    const/4 v5, 0x0

    .line 91
    cmpg-float v4, v4, v5

    .line 92
    .line 93
    if-nez v4, :cond_0

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_0
    new-instance v4, LB1/b;

    .line 97
    .line 98
    invoke-direct {v4, p1, v2}, LB1/b;-><init>(LB1/t;LN1/c;)V

    .line 99
    .line 100
    .line 101
    invoke-static {v1, v2, v4, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 102
    .line 103
    .line 104
    :goto_0
    new-instance v1, LB1/p;

    .line 105
    .line 106
    invoke-direct {v1, p1, v2}, LB1/p;-><init>(LB1/t;LN1/c;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0, v2, v1, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 110
    .line 111
    .line 112
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 113
    .line 114
    return-object p1
.end method
