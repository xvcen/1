.class public final LB1/d;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LB1/t;

.field public final synthetic k:F


# direct methods
.method public constructor <init>(LB1/t;FLN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/d;->j:LB1/t;

    .line 2
    .line 3
    iput p2, p0, LB1/d;->k:F

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/d;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/d;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 3

    .line 1
    new-instance v0, LB1/d;

    .line 2
    .line 3
    iget-object v1, p0, LB1/d;->j:LB1/t;

    .line 4
    .line 5
    iget v2, p0, LB1/d;->k:F

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, p1}, LB1/d;-><init>(LB1/t;FLN1/c;)V

    .line 8
    .line 9
    .line 10
    iput-object p2, v0, LB1/d;->i:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-object v0, p0, LB1/d;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lc2/s;

    .line 4
    .line 5
    iget v1, p0, LB1/d;->h:I

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v2, :cond_0

    .line 11
    .line 12
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-wide v0, -0x30b83377dbfaL

    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw p1

    .line 31
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget-object p1, p0, LB1/d;->j:LB1/t;

    .line 35
    .line 36
    iget-object v1, p1, LB1/t;->r:Ln/d0;

    .line 37
    .line 38
    new-instance v3, LB1/c;

    .line 39
    .line 40
    iget v4, p0, LB1/d;->k:F

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    invoke-direct {v3, p1, v4, v0, v5}, LB1/c;-><init>(LB1/t;FLc2/s;LN1/c;)V

    .line 44
    .line 45
    .line 46
    iput-object v5, p0, LB1/d;->i:Ljava/lang/Object;

    .line 47
    .line 48
    iput v2, p0, LB1/d;->h:I

    .line 49
    .line 50
    invoke-static {v1, v3, p0}, Ln/d0;->b(Ln/d0;LU1/c;LP1/i;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    sget-object v0, LO1/a;->d:LO1/a;

    .line 55
    .line 56
    if-ne p1, v0, :cond_2

    .line 57
    .line 58
    return-object v0

    .line 59
    :cond_2
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 60
    .line 61
    return-object p1
.end method
