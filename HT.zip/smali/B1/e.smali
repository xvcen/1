.class public final LB1/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LB1/e;->a:I

    iput-object p2, p0, LB1/e;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Lq0/y;LN1/c;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LB1/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB1/e;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LH/m0;

    .line 9
    .line 10
    iget-object v1, v0, LH/m0;->A:LH/X;

    .line 11
    .line 12
    iget-object v0, v0, LH/m0;->z:LH/k0;

    .line 13
    .line 14
    new-instance v2, LA1/f0;

    .line 15
    .line 16
    move-object v3, p1

    .line 17
    check-cast v3, Lq0/K;

    .line 18
    .line 19
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {v3}, Lw0/j;->u(Lw0/h;)Lw0/E;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    iget-object v3, v3, Lw0/E;->D:Lx0/J0;

    .line 27
    .line 28
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object v3, v2, LA1/f0;->b:Ljava/lang/Object;

    .line 32
    .line 33
    new-instance v3, LH/F;

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    invoke-direct {v3, v2, v1, v0, v4}, LH/F;-><init>(LA1/f0;LH/X;Lw/a0;LN1/c;)V

    .line 37
    .line 38
    .line 39
    invoke-static {p1, v3, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    sget-object p2, LO1/a;->d:LO1/a;

    .line 44
    .line 45
    if-ne p1, p2, :cond_0

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 49
    .line 50
    :goto_0
    sget-object p2, LO1/a;->d:LO1/a;

    .line 51
    .line 52
    if-ne p1, p2, :cond_1

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 56
    .line 57
    :goto_1
    return-object p1

    .line 58
    :pswitch_0
    new-instance v0, Ln/q;

    .line 59
    .line 60
    iget-object v1, p0, LB1/e;->b:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v1, Ln/r;

    .line 63
    .line 64
    const/4 v2, 0x0

    .line 65
    invoke-direct {v0, v1, v2}, Ln/q;-><init>(Ln/r;LN1/c;)V

    .line 66
    .line 67
    .line 68
    invoke-static {p1, v0, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    sget-object p2, LO1/a;->d:LO1/a;

    .line 73
    .line 74
    if-ne p1, p2, :cond_2

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 78
    .line 79
    :goto_2
    return-object p1

    .line 80
    :pswitch_1
    iget-object v0, p0, LB1/e;->b:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, Lw/a0;

    .line 83
    .line 84
    new-instance v1, Lw/W;

    .line 85
    .line 86
    const/4 v2, 0x0

    .line 87
    invoke-direct {v1, p1, v0, v2}, Lw/W;-><init>(Lq0/y;Lw/a0;LN1/c;)V

    .line 88
    .line 89
    .line 90
    invoke-static {v1, p2}, Lc2/u;->d(LU1/e;LN1/c;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 95
    .line 96
    sget-object v0, LO1/a;->d:LO1/a;

    .line 97
    .line 98
    if-ne p1, v0, :cond_3

    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_3
    move-object p1, p2

    .line 102
    :goto_3
    if-ne p1, v0, :cond_4

    .line 103
    .line 104
    move-object p2, p1

    .line 105
    :cond_4
    return-object p2

    .line 106
    :pswitch_2
    new-instance v0, LH/K;

    .line 107
    .line 108
    iget-object v1, p0, LB1/e;->b:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, LU1/c;

    .line 111
    .line 112
    const/4 v2, 0x0

    .line 113
    invoke-direct {v0, v1, v2}, LH/K;-><init>(LU1/c;LN1/c;)V

    .line 114
    .line 115
    .line 116
    check-cast p1, Lq0/K;

    .line 117
    .line 118
    invoke-virtual {p1, v0, p2}, Lq0/K;->U0(LU1/e;LN1/c;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    sget-object p2, LO1/a;->d:LO1/a;

    .line 123
    .line 124
    if-ne p1, p2, :cond_5

    .line 125
    .line 126
    goto :goto_4

    .line 127
    :cond_5
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 128
    .line 129
    :goto_4
    return-object p1

    .line 130
    :pswitch_3
    new-instance v0, LE/c;

    .line 131
    .line 132
    iget-object v1, p0, LB1/e;->b:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v1, LE/d;

    .line 135
    .line 136
    const/4 v2, 0x0

    .line 137
    invoke-direct {v0, v1, v2}, LE/c;-><init>(LE/d;LN1/c;)V

    .line 138
    .line 139
    .line 140
    invoke-static {p1, v0, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    sget-object p2, LO1/a;->d:LO1/a;

    .line 145
    .line 146
    if-ne p1, p2, :cond_6

    .line 147
    .line 148
    goto :goto_5

    .line 149
    :cond_6
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 150
    .line 151
    :goto_5
    return-object p1

    .line 152
    :pswitch_4
    new-instance v0, LC/f;

    .line 153
    .line 154
    iget-object v1, p0, LB1/e;->b:Ljava/lang/Object;

    .line 155
    .line 156
    move-object v2, v1

    .line 157
    check-cast v2, LC/i;

    .line 158
    .line 159
    const/4 v7, 0x0

    .line 160
    const/4 v8, 0x0

    .line 161
    const/4 v1, 0x1

    .line 162
    const-class v3, LC/i;

    .line 163
    .line 164
    const-string v4, "tryShowContextMenu"

    .line 165
    .line 166
    const-string v5, "tryShowContextMenu-k-4lQ0M(J)V"

    .line 167
    .line 168
    const/4 v6, 0x0

    .line 169
    invoke-direct/range {v0 .. v8}, LC/f;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 170
    .line 171
    .line 172
    new-instance v1, LA/b;

    .line 173
    .line 174
    const/4 v2, 0x0

    .line 175
    invoke-direct {v1, v0, v2}, LA/b;-><init>(LU1/c;LN1/c;)V

    .line 176
    .line 177
    .line 178
    invoke-static {p1, v1, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 183
    .line 184
    sget-object v0, LO1/a;->d:LO1/a;

    .line 185
    .line 186
    if-ne p1, v0, :cond_7

    .line 187
    .line 188
    goto :goto_6

    .line 189
    :cond_7
    move-object p1, p2

    .line 190
    :goto_6
    if-ne p1, v0, :cond_8

    .line 191
    .line 192
    move-object p2, p1

    .line 193
    :cond_8
    return-object p2

    .line 194
    :pswitch_5
    iget-object v0, p0, LB1/e;->b:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast v0, LB1/G;

    .line 197
    .line 198
    new-instance v2, LA1/q;

    .line 199
    .line 200
    const/4 v1, 0x2

    .line 201
    invoke-direct {v2, v0, v1}, LA1/q;-><init>(LB1/G;I)V

    .line 202
    .line 203
    .line 204
    new-instance v5, LA1/q;

    .line 205
    .line 206
    const/4 v1, 0x3

    .line 207
    invoke-direct {v5, v0, v1}, LA1/q;-><init>(LB1/G;I)V

    .line 208
    .line 209
    .line 210
    new-instance v4, LA1/P;

    .line 211
    .line 212
    const/4 v1, 0x4

    .line 213
    invoke-direct {v4, v1, v0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    new-instance v3, LA1/e;

    .line 217
    .line 218
    const/4 v1, 0x6

    .line 219
    invoke-direct {v3, v1, v0}, LA1/e;-><init>(ILjava/lang/Object;)V

    .line 220
    .line 221
    .line 222
    new-instance v1, LB1/u;

    .line 223
    .line 224
    const/4 v6, 0x0

    .line 225
    invoke-direct/range {v1 .. v6}, LB1/u;-><init>(LU1/c;LU1/e;LU1/a;LU1/c;LN1/c;)V

    .line 226
    .line 227
    .line 228
    invoke-static {p1, v1, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 233
    .line 234
    sget-object v0, LO1/a;->d:LO1/a;

    .line 235
    .line 236
    if-ne p1, v0, :cond_9

    .line 237
    .line 238
    goto :goto_7

    .line 239
    :cond_9
    move-object p1, p2

    .line 240
    :goto_7
    if-ne p1, v0, :cond_a

    .line 241
    .line 242
    move-object p2, p1

    .line 243
    :cond_a
    return-object p2

    .line 244
    :pswitch_6
    iget-object v0, p0, LB1/e;->b:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v0, LB1/t;

    .line 247
    .line 248
    new-instance v2, LA1/G;

    .line 249
    .line 250
    const/4 v1, 0x3

    .line 251
    invoke-direct {v2, v0, v1}, LA1/G;-><init>(LB1/t;I)V

    .line 252
    .line 253
    .line 254
    new-instance v5, LA1/G;

    .line 255
    .line 256
    const/4 v1, 0x4

    .line 257
    invoke-direct {v5, v0, v1}, LA1/G;-><init>(LB1/t;I)V

    .line 258
    .line 259
    .line 260
    new-instance v4, LA1/F;

    .line 261
    .line 262
    const/4 v1, 0x2

    .line 263
    invoke-direct {v4, v0, v1}, LA1/F;-><init>(LB1/t;I)V

    .line 264
    .line 265
    .line 266
    new-instance v3, LB/p;

    .line 267
    .line 268
    const/4 v1, 0x3

    .line 269
    invoke-direct {v3, v1, v0, p1}, LB/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 270
    .line 271
    .line 272
    new-instance v1, LB1/u;

    .line 273
    .line 274
    const/4 v6, 0x0

    .line 275
    invoke-direct/range {v1 .. v6}, LB1/u;-><init>(LU1/c;LU1/e;LU1/a;LU1/c;LN1/c;)V

    .line 276
    .line 277
    .line 278
    invoke-static {p1, v1, p2}, LT0/g;->i(Lq0/y;LU1/e;LN1/c;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 283
    .line 284
    sget-object v0, LO1/a;->d:LO1/a;

    .line 285
    .line 286
    if-ne p1, v0, :cond_b

    .line 287
    .line 288
    goto :goto_8

    .line 289
    :cond_b
    move-object p1, p2

    .line 290
    :goto_8
    if-ne p1, v0, :cond_c

    .line 291
    .line 292
    move-object p2, p1

    .line 293
    :cond_c
    return-object p2

    .line 294
    nop

    .line 295
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
