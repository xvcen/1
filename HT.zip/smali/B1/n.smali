.class public final LB1/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf2/e;


# instance fields
.field public final synthetic d:Lf2/e;

.field public final synthetic e:LB1/t;

.field public final synthetic f:F


# direct methods
.method public constructor <init>(Lf2/e;LB1/t;F)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB1/n;->d:Lf2/e;

    .line 5
    .line 6
    iput-object p2, p0, LB1/n;->e:LB1/t;

    .line 7
    .line 8
    iput p3, p0, LB1/n;->f:F

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, LB1/m;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, LB1/m;

    .line 7
    .line 8
    iget v1, v0, LB1/m;->h:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LB1/m;->h:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LB1/m;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, LB1/m;-><init>(LB1/n;LN1/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, LB1/m;->g:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LB1/m;->h:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-wide v0, -0x31573377dbfaL

    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p1

    .line 53
    :cond_2
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    move-object p2, p1

    .line 57
    check-cast p2, Ljava/lang/Number;

    .line 58
    .line 59
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 60
    .line 61
    .line 62
    move-result p2

    .line 63
    iget-object v1, p0, LB1/n;->e:LB1/t;

    .line 64
    .line 65
    iget-object v1, v1, LB1/t;->m:Ll/c;

    .line 66
    .line 67
    iget-object v1, v1, Ll/c;->e:LI/m0;

    .line 68
    .line 69
    invoke-virtual {v1}, LI/m0;->getValue()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    check-cast v1, Ljava/lang/Number;

    .line 74
    .line 75
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    sub-float/2addr p2, v1

    .line 80
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 81
    .line 82
    .line 83
    move-result p2

    .line 84
    iget v1, p0, LB1/n;->f:F

    .line 85
    .line 86
    cmpg-float p2, p2, v1

    .line 87
    .line 88
    if-gez p2, :cond_3

    .line 89
    .line 90
    iput v2, v0, LB1/m;->h:I

    .line 91
    .line 92
    iget-object p2, p0, LB1/n;->d:Lf2/e;

    .line 93
    .line 94
    invoke-interface {p2, p1, v0}, Lf2/e;->e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    sget-object p2, LO1/a;->d:LO1/a;

    .line 99
    .line 100
    if-ne p1, p2, :cond_3

    .line 101
    .line 102
    return-object p2

    .line 103
    :cond_3
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 104
    .line 105
    return-object p1
.end method
