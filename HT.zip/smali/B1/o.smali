.class public final LB1/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf2/d;


# instance fields
.field public final synthetic d:LA0/h;

.field public final synthetic e:LB1/t;

.field public final synthetic f:F


# direct methods
.method public constructor <init>(LA0/h;LB1/t;F)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB1/o;->d:LA0/h;

    .line 5
    .line 6
    iput-object p2, p0, LB1/o;->e:LB1/t;

    .line 7
    .line 8
    iput p3, p0, LB1/o;->f:F

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final d(Lf2/e;LN1/c;)Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, LB1/n;

    .line 2
    .line 3
    iget-object v1, p0, LB1/o;->e:LB1/t;

    .line 4
    .line 5
    iget v2, p0, LB1/o;->f:F

    .line 6
    .line 7
    invoke-direct {v0, p1, v1, v2}, LB1/n;-><init>(Lf2/e;LB1/t;F)V

    .line 8
    .line 9
    .line 10
    iget-object p1, p0, LB1/o;->d:LA0/h;

    .line 11
    .line 12
    invoke-virtual {p1, v0, p2}, LA0/h;->d(Lf2/e;LN1/c;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    sget-object p2, LO1/a;->d:LO1/a;

    .line 17
    .line 18
    if-ne p1, p2, :cond_0

    .line 19
    .line 20
    return-object p1

    .line 21
    :cond_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 22
    .line 23
    return-object p1
.end method
