.class public final LB1/p;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LB1/t;


# direct methods
.method public constructor <init>(LB1/t;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/p;->j:LB1/t;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/p;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/p;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/p;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LB1/p;

    .line 2
    .line 3
    iget-object v1, p0, LB1/p;->j:LB1/t;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LB1/p;-><init>(LB1/t;LN1/c;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, LB1/p;->i:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v0, p0, LB1/p;->j:LB1/t;

    .line 2
    .line 3
    iget-object v1, v0, LB1/t;->b:LY1/a;

    .line 4
    .line 5
    iget-object v2, v0, LB1/t;->m:Ll/c;

    .line 6
    .line 7
    iget-object v3, p0, LB1/p;->i:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Lc2/s;

    .line 10
    .line 11
    iget v4, p0, LB1/p;->h:I

    .line 12
    .line 13
    const/4 v5, 0x2

    .line 14
    const/4 v6, 0x1

    .line 15
    sget-object v7, LO1/a;->d:LO1/a;

    .line 16
    .line 17
    if-eqz v4, :cond_2

    .line 18
    .line 19
    if-eq v4, v6, :cond_1

    .line 20
    .line 21
    if-ne v4, v5, :cond_0

    .line 22
    .line 23
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    goto :goto_2

    .line 27
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 28
    .line 29
    const-wide v0, -0x32873377dbfaL

    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    invoke-static {v0, v1}, LI1/a;->a(J)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1

    .line 42
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iput-object v3, p0, LB1/p;->i:Ljava/lang/Object;

    .line 50
    .line 51
    iput v6, p0, LB1/p;->h:I

    .line 52
    .line 53
    invoke-static {p0}, Ld2/g;->c(LB1/p;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-ne p1, v7, :cond_3

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_3
    :goto_0
    invoke-virtual {v2}, Ll/c;->c()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    check-cast p1, Ljava/lang/Number;

    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    iget-object v2, v2, Ll/c;->e:LI/m0;

    .line 71
    .line 72
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    check-cast v2, Ljava/lang/Number;

    .line 77
    .line 78
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    cmpg-float p1, p1, v2

    .line 83
    .line 84
    if-nez p1, :cond_4

    .line 85
    .line 86
    goto :goto_2

    .line 87
    :cond_4
    iget p1, v1, LY1/a;->a:F

    .line 88
    .line 89
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    const/4 v1, 0x0

    .line 101
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    sub-float/2addr p1, v1

    .line 110
    const v1, 0x3ccccccd    # 0.025f

    .line 111
    .line 112
    .line 113
    mul-float/2addr p1, v1

    .line 114
    new-instance v1, LA1/F;

    .line 115
    .line 116
    const/4 v2, 0x3

    .line 117
    invoke-direct {v1, v0, v2}, LA1/F;-><init>(LB1/t;I)V

    .line 118
    .line 119
    .line 120
    invoke-static {v1}, LI/k;->v(LU1/a;)LA0/h;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    new-instance v2, LB1/o;

    .line 125
    .line 126
    invoke-direct {v2, v1, v0, p1}, LB1/o;-><init>(LA0/h;LB1/t;F)V

    .line 127
    .line 128
    .line 129
    iput-object v3, p0, LB1/p;->i:Ljava/lang/Object;

    .line 130
    .line 131
    iput v5, p0, LB1/p;->h:I

    .line 132
    .line 133
    invoke-static {v2, p0}, Lf2/w;->g(LB1/o;LP1/c;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-ne p1, v7, :cond_5

    .line 138
    .line 139
    :goto_1
    return-object v7

    .line 140
    :cond_5
    :goto_2
    new-instance p1, LB1/j;

    .line 141
    .line 142
    const/4 v1, 0x0

    .line 143
    invoke-direct {p1, v0, v1}, LB1/j;-><init>(LB1/t;LN1/c;)V

    .line 144
    .line 145
    .line 146
    const/4 v2, 0x3

    .line 147
    invoke-static {v3, v1, p1, v2}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 148
    .line 149
    .line 150
    new-instance p1, LB1/k;

    .line 151
    .line 152
    invoke-direct {p1, v0, v1}, LB1/k;-><init>(LB1/t;LN1/c;)V

    .line 153
    .line 154
    .line 155
    invoke-static {v3, v1, p1, v2}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 156
    .line 157
    .line 158
    new-instance p1, LB1/l;

    .line 159
    .line 160
    invoke-direct {p1, v0, v1}, LB1/l;-><init>(LB1/t;LN1/c;)V

    .line 161
    .line 162
    .line 163
    invoke-static {v3, v1, p1, v2}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 164
    .line 165
    .line 166
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 167
    .line 168
    return-object p1
.end method
