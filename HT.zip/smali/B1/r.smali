.class public final LB1/r;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:LB1/t;

.field public final synthetic j:F


# direct methods
.method public constructor <init>(LB1/t;FLN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/r;->i:LB1/t;

    .line 2
    .line 3
    iput p2, p0, LB1/r;->j:F

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/r;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/r;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/r;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 3

    .line 1
    new-instance v0, LB1/r;

    .line 2
    .line 3
    iget-object v1, p0, LB1/r;->i:LB1/t;

    .line 4
    .line 5
    iget v2, p0, LB1/r;->j:F

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, p1}, LB1/r;-><init>(LB1/t;FLN1/c;)V

    .line 8
    .line 9
    .line 10
    iput-object p2, v0, LB1/r;->h:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LB1/r;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lc2/s;

    .line 4
    .line 5
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, LB1/q;

    .line 9
    .line 10
    iget-object v1, p0, LB1/r;->i:LB1/t;

    .line 11
    .line 12
    iget v2, p0, LB1/r;->j:F

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-direct {p1, v1, v2, v3}, LB1/q;-><init>(LB1/t;FLN1/c;)V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x3

    .line 19
    invoke-static {v0, v3, p1, v1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 20
    .line 21
    .line 22
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 23
    .line 24
    return-object p1
.end method
