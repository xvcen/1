.class public final LB1/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc2/s;

.field public final b:LY1/a;

.field public final c:F

.field public final d:F

.field public final e:LA1/E;

.field public final f:LA1/I;

.field public final g:LA1/J;

.field public final h:Ll/C;

.field public final i:Ll/C;

.field public final j:Ll/C;

.field public final k:Ll/C;

.field public final l:Ll/C;

.field public final m:Ll/c;

.field public final n:Ll/c;

.field public final o:Ll/c;

.field public final p:Ll/c;

.field public final q:Ll/c;

.field public final r:Ln/d0;

.field public final s:Lq0/w;

.field public final t:LW/q;


# direct methods
.method public constructor <init>(Lc2/s;FLY1/a;LA1/E;LA1/I;LA1/J;)V
    .locals 4

    .line 1
    const v0, 0x3a83126f    # 0.001f

    .line 2
    .line 3
    .line 4
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-wide v2, -0x32473377dbfaL

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const-wide v2, -0x32543377dbfaL

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    const-wide v2, -0x32593377dbfaL

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    const-wide v2, -0x326f3377dbfaL

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    const-wide v2, -0x327d3377dbfaL

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v2, v3}, LI1/a;->a(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object p1, p0, LB1/t;->a:Lc2/s;

    .line 56
    .line 57
    iput-object p3, p0, LB1/t;->b:LY1/a;

    .line 58
    .line 59
    const/high16 p1, 0x3f800000    # 1.0f

    .line 60
    .line 61
    iput p1, p0, LB1/t;->c:F

    .line 62
    .line 63
    const/high16 p3, 0x3fc00000    # 1.5f

    .line 64
    .line 65
    iput p3, p0, LB1/t;->d:F

    .line 66
    .line 67
    iput-object p4, p0, LB1/t;->e:LA1/E;

    .line 68
    .line 69
    iput-object p5, p0, LB1/t;->f:LA1/I;

    .line 70
    .line 71
    iput-object p6, p0, LB1/t;->g:LA1/J;

    .line 72
    .line 73
    new-instance p3, Ll/C;

    .line 74
    .line 75
    const/high16 p4, 0x447a0000    # 1000.0f

    .line 76
    .line 77
    invoke-direct {p3, p1, p4, v1}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    iput-object p3, p0, LB1/t;->h:Ll/C;

    .line 81
    .line 82
    const p3, 0x3c23d70b    # 0.010000001f

    .line 83
    .line 84
    .line 85
    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 86
    .line 87
    .line 88
    move-result-object p3

    .line 89
    new-instance p5, Ll/C;

    .line 90
    .line 91
    const/high16 p6, 0x3f000000    # 0.5f

    .line 92
    .line 93
    const/high16 v2, 0x43960000    # 300.0f

    .line 94
    .line 95
    invoke-direct {p5, p6, v2, p3}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    iput-object p5, p0, LB1/t;->i:Ll/C;

    .line 99
    .line 100
    new-instance p3, Ll/C;

    .line 101
    .line 102
    invoke-direct {p3, p1, p4, v1}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    iput-object p3, p0, LB1/t;->j:Ll/C;

    .line 106
    .line 107
    new-instance p3, Ll/C;

    .line 108
    .line 109
    const p4, 0x3f19999a    # 0.6f

    .line 110
    .line 111
    .line 112
    const/high16 p5, 0x437a0000    # 250.0f

    .line 113
    .line 114
    invoke-direct {p3, p4, p5, v1}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    iput-object p3, p0, LB1/t;->k:Ll/C;

    .line 118
    .line 119
    new-instance p3, Ll/C;

    .line 120
    .line 121
    const p4, 0x3f333333    # 0.7f

    .line 122
    .line 123
    .line 124
    invoke-direct {p3, p4, p5, v1}, Ll/C;-><init>(FFLjava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    iput-object p3, p0, LB1/t;->l:Ll/C;

    .line 128
    .line 129
    invoke-static {p2, v0}, Ll/d;->a(FF)Ll/c;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    iput-object p2, p0, LB1/t;->m:Ll/c;

    .line 134
    .line 135
    const/high16 p2, 0x40a00000    # 5.0f

    .line 136
    .line 137
    const/4 p3, 0x0

    .line 138
    invoke-static {p3, p2}, Ll/d;->a(FF)Ll/c;

    .line 139
    .line 140
    .line 141
    move-result-object p2

    .line 142
    iput-object p2, p0, LB1/t;->n:Ll/c;

    .line 143
    .line 144
    invoke-static {p3, v0}, Ll/d;->a(FF)Ll/c;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    iput-object p2, p0, LB1/t;->o:Ll/c;

    .line 149
    .line 150
    invoke-static {p1, v0}, Ll/d;->a(FF)Ll/c;

    .line 151
    .line 152
    .line 153
    move-result-object p2

    .line 154
    iput-object p2, p0, LB1/t;->p:Ll/c;

    .line 155
    .line 156
    invoke-static {p1, v0}, Ll/d;->a(FF)Ll/c;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    iput-object p1, p0, LB1/t;->q:Ll/c;

    .line 161
    .line 162
    new-instance p1, Ln/d0;

    .line 163
    .line 164
    invoke-direct {p1}, Ln/d0;-><init>()V

    .line 165
    .line 166
    .line 167
    iput-object p1, p0, LB1/t;->r:Ln/d0;

    .line 168
    .line 169
    new-instance p1, Lq0/w;

    .line 170
    .line 171
    const/4 p2, 0x1

    .line 172
    invoke-direct {p1, p2}, Lq0/w;-><init>(I)V

    .line 173
    .line 174
    .line 175
    iput-object p1, p0, LB1/t;->s:Lq0/w;

    .line 176
    .line 177
    new-instance p1, LB1/e;

    .line 178
    .line 179
    const/4 p2, 0x0

    .line 180
    invoke-direct {p1, p2, p0}, LB1/e;-><init>(ILjava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    sget-object p2, LW/n;->a:LW/n;

    .line 184
    .line 185
    sget-object p3, LJ1/m;->a:LJ1/m;

    .line 186
    .line 187
    invoke-static {p2, p3, p1}, Lq0/E;->a(LW/q;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)LW/q;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    iput-object p1, p0, LB1/t;->t:LW/q;

    .line 192
    .line 193
    return-void
.end method


# virtual methods
.method public final a()F
    .locals 1

    .line 1
    iget-object v0, p0, LB1/t;->o:Ll/c;

    .line 2
    .line 3
    invoke-virtual {v0}, Ll/c;->c()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Number;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    return v0
.end method
