.class public final LB1/u;
.super LP1/h;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public f:Lq0/u;

.field public g:Lq0/I;

.field public h:LU1/e;

.field public i:Lq0/I;

.field public j:LV1/r;

.field public k:J

.field public l:J

.field public m:J

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:LU1/c;

.field public final synthetic t:LU1/e;

.field public final synthetic u:LU1/a;

.field public final synthetic v:LU1/c;


# direct methods
.method public constructor <init>(LU1/c;LU1/e;LU1/a;LU1/c;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LB1/u;->s:LU1/c;

    .line 2
    .line 3
    iput-object p2, p0, LB1/u;->t:LU1/e;

    .line 4
    .line 5
    iput-object p3, p0, LB1/u;->u:LU1/a;

    .line 6
    .line 7
    iput-object p4, p0, LB1/u;->v:LU1/c;

    .line 8
    .line 9
    invoke-direct {p0, p5}, LP1/h;-><init>(LN1/c;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lq0/I;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LB1/u;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LB1/u;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LB1/u;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 6

    .line 1
    new-instance v0, LB1/u;

    .line 2
    .line 3
    iget-object v3, p0, LB1/u;->u:LU1/a;

    .line 4
    .line 5
    iget-object v4, p0, LB1/u;->v:LU1/c;

    .line 6
    .line 7
    iget-object v1, p0, LB1/u;->s:LU1/c;

    .line 8
    .line 9
    iget-object v2, p0, LB1/u;->t:LU1/e;

    .line 10
    .line 11
    move-object v5, p1

    .line 12
    invoke-direct/range {v0 .. v5}, LB1/u;-><init>(LU1/c;LU1/e;LU1/a;LU1/c;LN1/c;)V

    .line 13
    .line 14
    .line 15
    iput-object p2, v0, LB1/u;->r:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LB1/u;->r:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lq0/I;

    .line 6
    .line 7
    iget v2, v0, LB1/u;->q:I

    .line 8
    .line 9
    const/4 v3, 0x3

    .line 10
    const/4 v4, 0x2

    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x1

    .line 13
    sget-object v8, LO1/a;->d:LO1/a;

    .line 14
    .line 15
    if-eqz v2, :cond_3

    .line 16
    .line 17
    if-eq v2, v6, :cond_2

    .line 18
    .line 19
    if-eq v2, v4, :cond_1

    .line 20
    .line 21
    if-ne v2, v3, :cond_0

    .line 22
    .line 23
    iget-wide v1, v0, LB1/u;->m:J

    .line 24
    .line 25
    iget-wide v9, v0, LB1/u;->l:J

    .line 26
    .line 27
    iget v4, v0, LB1/u;->p:I

    .line 28
    .line 29
    iget v6, v0, LB1/u;->o:I

    .line 30
    .line 31
    iget v11, v0, LB1/u;->n:I

    .line 32
    .line 33
    iget-wide v12, v0, LB1/u;->k:J

    .line 34
    .line 35
    iget-object v14, v0, LB1/u;->j:LV1/r;

    .line 36
    .line 37
    iget-object v15, v0, LB1/u;->i:Lq0/I;

    .line 38
    .line 39
    iget-object v3, v0, LB1/u;->h:LU1/e;

    .line 40
    .line 41
    iget-object v7, v0, LB1/u;->g:Lq0/I;

    .line 42
    .line 43
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    move v5, v4

    .line 47
    move-object v4, v3

    .line 48
    move-wide v2, v1

    .line 49
    move-object v1, v7

    .line 50
    move v7, v11

    .line 51
    move-wide v10, v9

    .line 52
    move v9, v5

    .line 53
    move-object/from16 v5, p1

    .line 54
    .line 55
    goto/16 :goto_9

    .line 56
    .line 57
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 58
    .line 59
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 60
    .line 61
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw v1

    .line 65
    :cond_1
    iget-object v2, v0, LB1/u;->f:Lq0/u;

    .line 66
    .line 67
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    move-object/from16 v3, p1

    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_2
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    move-object/from16 v2, p1

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_3
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    iput-object v1, v0, LB1/u;->r:Ljava/lang/Object;

    .line 83
    .line 84
    iput v6, v0, LB1/u;->q:I

    .line 85
    .line 86
    sget-object v2, Lq0/m;->d:Lq0/m;

    .line 87
    .line 88
    invoke-static {v1, v5, v2, v0}, Lp/p1;->a(Lq0/I;ZLq0/m;LP1/a;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    if-ne v2, v8, :cond_4

    .line 93
    .line 94
    goto/16 :goto_8

    .line 95
    .line 96
    :cond_4
    :goto_0
    check-cast v2, Lq0/u;

    .line 97
    .line 98
    iput-object v1, v0, LB1/u;->r:Ljava/lang/Object;

    .line 99
    .line 100
    iput-object v2, v0, LB1/u;->f:Lq0/u;

    .line 101
    .line 102
    iput v4, v0, LB1/u;->q:I

    .line 103
    .line 104
    invoke-static {v1, v0, v4}, Lp/p1;->b(Lq0/I;LP1/h;I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    if-ne v3, v8, :cond_5

    .line 109
    .line 110
    goto/16 :goto_8

    .line 111
    .line 112
    :cond_5
    :goto_1
    check-cast v3, Lq0/u;

    .line 113
    .line 114
    iget-object v4, v0, LB1/u;->s:LU1/c;

    .line 115
    .line 116
    invoke-interface {v4, v3}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    new-instance v3, Lc0/b;

    .line 120
    .line 121
    const-wide/16 v9, 0x0

    .line 122
    .line 123
    invoke-direct {v3, v9, v10}, Lc0/b;-><init>(J)V

    .line 124
    .line 125
    .line 126
    iget-object v4, v0, LB1/u;->t:LU1/e;

    .line 127
    .line 128
    invoke-interface {v4, v2, v3}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    iget-wide v2, v2, Lq0/u;->a:J

    .line 132
    .line 133
    iget-object v7, v1, Lq0/I;->i:Lq0/K;

    .line 134
    .line 135
    iget-object v7, v7, Lq0/K;->v:Lq0/l;

    .line 136
    .line 137
    iget-object v7, v7, Lq0/l;->a:Ljava/lang/Object;

    .line 138
    .line 139
    invoke-interface {v7}, Ljava/util/Collection;->size()I

    .line 140
    .line 141
    .line 142
    move-result v9

    .line 143
    move v10, v5

    .line 144
    :goto_2
    if-ge v10, v9, :cond_7

    .line 145
    .line 146
    invoke-interface {v7, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v11

    .line 150
    move-object v12, v11

    .line 151
    check-cast v12, Lq0/u;

    .line 152
    .line 153
    iget-wide v12, v12, Lq0/u;->a:J

    .line 154
    .line 155
    invoke-static {v12, v13, v2, v3}, Lq0/t;->e(JJ)Z

    .line 156
    .line 157
    .line 158
    move-result v12

    .line 159
    if-eqz v12, :cond_6

    .line 160
    .line 161
    goto :goto_3

    .line 162
    :cond_6
    add-int/lit8 v10, v10, 0x1

    .line 163
    .line 164
    goto :goto_2

    .line 165
    :cond_7
    const/4 v11, 0x0

    .line 166
    :goto_3
    check-cast v11, Lq0/u;

    .line 167
    .line 168
    if-eqz v11, :cond_8

    .line 169
    .line 170
    iget-boolean v7, v11, Lq0/u;->d:Z

    .line 171
    .line 172
    if-ne v7, v6, :cond_8

    .line 173
    .line 174
    goto :goto_4

    .line 175
    :cond_8
    move v6, v5

    .line 176
    :goto_4
    xor-int/lit8 v7, v6, 0x1

    .line 177
    .line 178
    if-nez v6, :cond_9

    .line 179
    .line 180
    :goto_5
    const/4 v7, 0x0

    .line 181
    goto/16 :goto_f

    .line 182
    .line 183
    :cond_9
    move v10, v5

    .line 184
    move v9, v7

    .line 185
    move-wide v6, v2

    .line 186
    :goto_6
    new-instance v11, LV1/r;

    .line 187
    .line 188
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 189
    .line 190
    .line 191
    iput-wide v2, v11, LV1/r;->d:J

    .line 192
    .line 193
    move-object v15, v1

    .line 194
    move-wide v12, v6

    .line 195
    move v7, v10

    .line 196
    move-object v14, v11

    .line 197
    move-wide v10, v2

    .line 198
    move v6, v5

    .line 199
    :goto_7
    const/4 v5, 0x0

    .line 200
    iput-object v5, v0, LB1/u;->r:Ljava/lang/Object;

    .line 201
    .line 202
    iput-object v5, v0, LB1/u;->f:Lq0/u;

    .line 203
    .line 204
    iput-object v1, v0, LB1/u;->g:Lq0/I;

    .line 205
    .line 206
    iput-object v4, v0, LB1/u;->h:LU1/e;

    .line 207
    .line 208
    iput-object v15, v0, LB1/u;->i:Lq0/I;

    .line 209
    .line 210
    iput-object v14, v0, LB1/u;->j:LV1/r;

    .line 211
    .line 212
    iput-wide v12, v0, LB1/u;->k:J

    .line 213
    .line 214
    iput v7, v0, LB1/u;->n:I

    .line 215
    .line 216
    iput v6, v0, LB1/u;->o:I

    .line 217
    .line 218
    iput v9, v0, LB1/u;->p:I

    .line 219
    .line 220
    iput-wide v10, v0, LB1/u;->l:J

    .line 221
    .line 222
    iput-wide v2, v0, LB1/u;->m:J

    .line 223
    .line 224
    const/4 v5, 0x3

    .line 225
    iput v5, v0, LB1/u;->q:I

    .line 226
    .line 227
    sget-object v5, Lq0/m;->e:Lq0/m;

    .line 228
    .line 229
    invoke-virtual {v15, v5, v0}, Lq0/I;->y(Lq0/m;LP1/a;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v5

    .line 233
    if-ne v5, v8, :cond_a

    .line 234
    .line 235
    :goto_8
    return-object v8

    .line 236
    :cond_a
    :goto_9
    check-cast v5, Lq0/l;

    .line 237
    .line 238
    move-object/from16 v16, v1

    .line 239
    .line 240
    iget-object v1, v5, Lq0/l;->a:Ljava/lang/Object;

    .line 241
    .line 242
    move-wide/from16 v17, v2

    .line 243
    .line 244
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 245
    .line 246
    .line 247
    move-result v2

    .line 248
    const/4 v3, 0x0

    .line 249
    :goto_a
    if-ge v3, v2, :cond_c

    .line 250
    .line 251
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v19

    .line 255
    move-object/from16 v20, v1

    .line 256
    .line 257
    move-object/from16 v1, v19

    .line 258
    .line 259
    check-cast v1, Lq0/u;

    .line 260
    .line 261
    move/from16 v21, v2

    .line 262
    .line 263
    iget-wide v1, v1, Lq0/u;->a:J

    .line 264
    .line 265
    move/from16 v22, v6

    .line 266
    .line 267
    move/from16 v23, v7

    .line 268
    .line 269
    iget-wide v6, v14, LV1/r;->d:J

    .line 270
    .line 271
    invoke-static {v1, v2, v6, v7}, Lq0/t;->e(JJ)Z

    .line 272
    .line 273
    .line 274
    move-result v1

    .line 275
    if-eqz v1, :cond_b

    .line 276
    .line 277
    goto :goto_b

    .line 278
    :cond_b
    add-int/lit8 v3, v3, 0x1

    .line 279
    .line 280
    move-object/from16 v1, v20

    .line 281
    .line 282
    move/from16 v2, v21

    .line 283
    .line 284
    move/from16 v6, v22

    .line 285
    .line 286
    move/from16 v7, v23

    .line 287
    .line 288
    goto :goto_a

    .line 289
    :cond_c
    move/from16 v22, v6

    .line 290
    .line 291
    move/from16 v23, v7

    .line 292
    .line 293
    const/16 v19, 0x0

    .line 294
    .line 295
    :goto_b
    move-object/from16 v1, v19

    .line 296
    .line 297
    check-cast v1, Lq0/u;

    .line 298
    .line 299
    if-nez v1, :cond_d

    .line 300
    .line 301
    const/4 v1, 0x0

    .line 302
    goto :goto_e

    .line 303
    :cond_d
    invoke-static {v1}, Lq0/t;->d(Lq0/u;)Z

    .line 304
    .line 305
    .line 306
    move-result v2

    .line 307
    if-eqz v2, :cond_12

    .line 308
    .line 309
    iget-object v2, v5, Lq0/l;->a:Ljava/lang/Object;

    .line 310
    .line 311
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 312
    .line 313
    .line 314
    move-result v3

    .line 315
    const/4 v5, 0x0

    .line 316
    :goto_c
    if-ge v5, v3, :cond_f

    .line 317
    .line 318
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    move-result-object v6

    .line 322
    move-object v7, v6

    .line 323
    check-cast v7, Lq0/u;

    .line 324
    .line 325
    iget-boolean v7, v7, Lq0/u;->d:Z

    .line 326
    .line 327
    if-eqz v7, :cond_e

    .line 328
    .line 329
    goto :goto_d

    .line 330
    :cond_e
    add-int/lit8 v5, v5, 0x1

    .line 331
    .line 332
    goto :goto_c

    .line 333
    :cond_f
    const/4 v6, 0x0

    .line 334
    :goto_d
    check-cast v6, Lq0/u;

    .line 335
    .line 336
    if-nez v6, :cond_10

    .line 337
    .line 338
    goto :goto_e

    .line 339
    :cond_10
    iget-wide v1, v6, Lq0/u;->a:J

    .line 340
    .line 341
    iput-wide v1, v14, LV1/r;->d:J

    .line 342
    .line 343
    :cond_11
    const/4 v2, 0x0

    .line 344
    goto :goto_11

    .line 345
    :cond_12
    iget-wide v2, v1, Lq0/u;->g:J

    .line 346
    .line 347
    iget-wide v5, v1, Lq0/u;->c:J

    .line 348
    .line 349
    invoke-static {v2, v3, v5, v6}, Lc0/b;->b(JJ)Z

    .line 350
    .line 351
    .line 352
    move-result v2

    .line 353
    if-nez v2, :cond_11

    .line 354
    .line 355
    :goto_e
    if-nez v1, :cond_13

    .line 356
    .line 357
    goto/16 :goto_5

    .line 358
    .line 359
    :cond_13
    invoke-virtual {v1}, Lq0/u;->b()Z

    .line 360
    .line 361
    .line 362
    move-result v2

    .line 363
    if-eqz v2, :cond_14

    .line 364
    .line 365
    goto/16 :goto_5

    .line 366
    .line 367
    :cond_14
    invoke-static {v1}, Lq0/t;->d(Lq0/u;)Z

    .line 368
    .line 369
    .line 370
    move-result v2

    .line 371
    if-eqz v2, :cond_16

    .line 372
    .line 373
    move-object v7, v1

    .line 374
    :goto_f
    if-nez v7, :cond_15

    .line 375
    .line 376
    iget-object v1, v0, LB1/u;->u:LU1/a;

    .line 377
    .line 378
    invoke-interface {v1}, LU1/a;->a()Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    goto :goto_10

    .line 382
    :cond_15
    iget-object v1, v0, LB1/u;->v:LU1/c;

    .line 383
    .line 384
    invoke-interface {v1, v7}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    :goto_10
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 388
    .line 389
    return-object v1

    .line 390
    :cond_16
    const/4 v2, 0x0

    .line 391
    invoke-static {v1, v2}, Lq0/t;->g(Lq0/u;Z)J

    .line 392
    .line 393
    .line 394
    move-result-wide v5

    .line 395
    new-instance v3, Lc0/b;

    .line 396
    .line 397
    invoke-direct {v3, v5, v6}, Lc0/b;-><init>(J)V

    .line 398
    .line 399
    .line 400
    invoke-interface {v4, v1, v3}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 401
    .line 402
    .line 403
    iget-wide v5, v1, Lq0/u;->a:J

    .line 404
    .line 405
    move-wide/from16 v24, v5

    .line 406
    .line 407
    move v5, v2

    .line 408
    move-wide/from16 v2, v24

    .line 409
    .line 410
    move-wide v6, v12

    .line 411
    move-object/from16 v1, v16

    .line 412
    .line 413
    move/from16 v10, v23

    .line 414
    .line 415
    goto/16 :goto_6

    .line 416
    .line 417
    :goto_11
    move-object/from16 v1, v16

    .line 418
    .line 419
    move-wide/from16 v2, v17

    .line 420
    .line 421
    move/from16 v6, v22

    .line 422
    .line 423
    move/from16 v7, v23

    .line 424
    .line 425
    goto/16 :goto_7
.end method
