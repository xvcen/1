.class public final LC/a;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/y0;


# instance fields
.field public r:LB/y;


# virtual methods
.method public final y()Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, LC/d;->a:LC/d;

    .line 2
    .line 3
    return-object v0
.end method
