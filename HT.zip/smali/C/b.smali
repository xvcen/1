.class final LC/b;
.super Lw0/V;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;"
    }
.end annotation


# instance fields
.field public final a:LB/p;


# direct methods
.method public constructor <init>(LB/p;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC/b;->a:LB/p;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 4

    .line 1
    new-instance v0, LC/c;

    .line 2
    .line 3
    invoke-direct {v0}, Lw0/i;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LC/b;->a:LB/p;

    .line 7
    .line 8
    iput-object v1, v0, LC/c;->t:LB/p;

    .line 9
    .line 10
    new-instance v1, LC/a;

    .line 11
    .line 12
    new-instance v2, LB/y;

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    invoke-direct {v2, v3, v0}, LB/y;-><init>(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-direct {v1}, LW/p;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v2, v1, LC/a;->r:LB/y;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lw0/i;->U0(Lw0/h;)Lw0/h;

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 1

    .line 1
    check-cast p1, LC/c;

    .line 2
    .line 3
    iget-object v0, p0, LC/b;->a:LB/p;

    .line 4
    .line 5
    iput-object v0, p1, LC/c;->t:LB/p;

    .line 6
    .line 7
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_1

    .line 4
    :cond_0
    instance-of v0, p1, LC/b;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_1
    check-cast p1, LC/b;

    .line 10
    .line 11
    iget-object p1, p1, LC/b;->a:LB/p;

    .line 12
    .line 13
    iget-object v0, p0, LC/b;->a:LB/p;

    .line 14
    .line 15
    if-eq v0, p1, :cond_2

    .line 16
    .line 17
    :goto_0
    const/4 p1, 0x0

    .line 18
    return p1

    .line 19
    :cond_2
    :goto_1
    const/4 p1, 0x1

    .line 20
    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, LC/b;->a:LB/p;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
