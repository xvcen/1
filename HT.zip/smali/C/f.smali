.class public final synthetic LC/f;
.super LV1/g;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V
    .locals 0

    .line 1
    iput p8, p0, LC/f;->k:I

    invoke-direct/range {p0 .. p7}, LV1/g;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LC/f;->k:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p1

    .line 9
    .line 10
    check-cast v1, Lo0/b;

    .line 11
    .line 12
    iget-object v1, v1, Lo0/b;->a:Landroid/view/KeyEvent;

    .line 13
    .line 14
    iget-object v2, v0, LV1/c;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Lw/f0;

    .line 17
    .line 18
    iget-object v3, v2, Lw/f0;->f:LH/s0;

    .line 19
    .line 20
    iget-boolean v4, v2, Lw/f0;->d:Z

    .line 21
    .line 22
    invoke-virtual {v1}, Landroid/view/KeyEvent;->getAction()I

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    const/4 v6, 0x1

    .line 27
    const/4 v7, 0x0

    .line 28
    if-nez v5, :cond_4

    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/view/KeyEvent;->getUnicodeChar()I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    invoke-static {v5}, Ljava/lang/Character;->isISOControl(I)Z

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    if-nez v5, :cond_4

    .line 39
    .line 40
    iget-object v5, v2, Lw/f0;->i:Lw/E;

    .line 41
    .line 42
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Landroid/view/KeyEvent;->getUnicodeChar()I

    .line 46
    .line 47
    .line 48
    move-result v8

    .line 49
    const/high16 v9, -0x80000000

    .line 50
    .line 51
    and-int/2addr v9, v8

    .line 52
    if-eqz v9, :cond_0

    .line 53
    .line 54
    const v9, 0x7fffffff

    .line 55
    .line 56
    .line 57
    and-int/2addr v8, v9

    .line 58
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 59
    .line 60
    .line 61
    move-result-object v8

    .line 62
    iput-object v8, v5, Lw/E;->a:Ljava/lang/Integer;

    .line 63
    .line 64
    move-object v5, v7

    .line 65
    goto :goto_0

    .line 66
    :cond_0
    iget-object v9, v5, Lw/E;->a:Ljava/lang/Integer;

    .line 67
    .line 68
    if-eqz v9, :cond_3

    .line 69
    .line 70
    iput-object v7, v5, Lw/E;->a:Ljava/lang/Integer;

    .line 71
    .line 72
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 73
    .line 74
    .line 75
    move-result v5

    .line 76
    invoke-static {v5, v8}, Landroid/view/KeyCharacterMap;->getDeadChar(II)I

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    if-nez v5, :cond_1

    .line 85
    .line 86
    move-object v9, v7

    .line 87
    :cond_1
    if-eqz v9, :cond_2

    .line 88
    .line 89
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 90
    .line 91
    .line 92
    move-result v8

    .line 93
    :cond_2
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v5

    .line 97
    goto :goto_0

    .line 98
    :cond_3
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 99
    .line 100
    .line 101
    move-result-object v5

    .line 102
    :goto_0
    if-eqz v5, :cond_4

    .line 103
    .line 104
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 105
    .line 106
    .line 107
    move-result v5

    .line 108
    new-instance v8, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->appendCodePoint(I)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    move-result-object v5

    .line 117
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    new-instance v8, LM0/a;

    .line 122
    .line 123
    invoke-direct {v8, v5, v6}, LM0/a;-><init>(Ljava/lang/String;I)V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_4
    move-object v8, v7

    .line 128
    :goto_1
    const/4 v5, 0x0

    .line 129
    if-eqz v8, :cond_6

    .line 130
    .line 131
    if-eqz v4, :cond_5

    .line 132
    .line 133
    invoke-static {v8}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-virtual {v2, v1}, Lw/f0;->a(Ljava/util/List;)V

    .line 138
    .line 139
    .line 140
    iput-object v7, v3, LH/s0;->a:Ljava/lang/Float;

    .line 141
    .line 142
    goto :goto_3

    .line 143
    :cond_5
    :goto_2
    move v6, v5

    .line 144
    goto :goto_3

    .line 145
    :cond_6
    invoke-static {v1}, Lo0/c;->c(Landroid/view/KeyEvent;)I

    .line 146
    .line 147
    .line 148
    move-result v7

    .line 149
    const/4 v8, 0x2

    .line 150
    if-ne v7, v8, :cond_5

    .line 151
    .line 152
    iget-object v7, v2, Lw/f0;->j:Lw/L;

    .line 153
    .line 154
    invoke-virtual {v7, v1}, Lw/L;->a(Landroid/view/KeyEvent;)Lw/K;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    if-eqz v1, :cond_5

    .line 159
    .line 160
    iget-boolean v7, v1, Lw/K;->d:Z

    .line 161
    .line 162
    if-eqz v7, :cond_7

    .line 163
    .line 164
    if-nez v4, :cond_7

    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_7
    new-instance v4, LV1/o;

    .line 168
    .line 169
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 170
    .line 171
    .line 172
    iput-boolean v6, v4, LV1/o;->d:Z

    .line 173
    .line 174
    new-instance v5, LB/r;

    .line 175
    .line 176
    const/16 v7, 0x8

    .line 177
    .line 178
    invoke-direct {v5, v1, v2, v4, v7}, LB/r;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 179
    .line 180
    .line 181
    new-instance v1, LH/Z;

    .line 182
    .line 183
    iget-object v7, v2, Lw/f0;->c:LM0/x;

    .line 184
    .line 185
    iget-object v8, v2, Lw/f0;->g:LM0/q;

    .line 186
    .line 187
    iget-object v9, v2, Lw/f0;->a:Lw/S;

    .line 188
    .line 189
    invoke-virtual {v9}, Lw/S;->d()Lw/p0;

    .line 190
    .line 191
    .line 192
    move-result-object v9

    .line 193
    invoke-direct {v1, v7, v8, v9, v3}, LH/Z;-><init>(LM0/x;LM0/q;Lw/p0;LH/s0;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v5, v1}, LB/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    iget-wide v8, v1, LH/Z;->f:J

    .line 200
    .line 201
    iget-wide v10, v7, LM0/x;->b:J

    .line 202
    .line 203
    invoke-static {v8, v9, v10, v11}, LH0/N;->b(JJ)Z

    .line 204
    .line 205
    .line 206
    move-result v3

    .line 207
    if-eqz v3, :cond_8

    .line 208
    .line 209
    iget-object v3, v1, LH/Z;->g:LH0/g;

    .line 210
    .line 211
    iget-object v5, v7, LM0/x;->a:LH0/g;

    .line 212
    .line 213
    invoke-static {v3, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v3

    .line 217
    if-nez v3, :cond_9

    .line 218
    .line 219
    :cond_8
    iget-object v3, v2, Lw/f0;->k:LU1/c;

    .line 220
    .line 221
    iget-wide v8, v1, LH/Z;->f:J

    .line 222
    .line 223
    const/4 v5, 0x4

    .line 224
    iget-object v1, v1, LH/Z;->g:LH0/g;

    .line 225
    .line 226
    invoke-static {v7, v1, v8, v9, v5}, LM0/x;->a(LM0/x;LH0/g;JI)LM0/x;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    invoke-interface {v3, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    :cond_9
    iget-object v1, v2, Lw/f0;->h:Lw/q0;

    .line 234
    .line 235
    if-eqz v1, :cond_a

    .line 236
    .line 237
    iput-boolean v6, v1, Lw/q0;->e:Z

    .line 238
    .line 239
    :cond_a
    iget-boolean v6, v4, LV1/o;->d:Z

    .line 240
    .line 241
    :goto_3
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    return-object v1

    .line 246
    :pswitch_0
    move-object/from16 v1, p1

    .line 247
    .line 248
    check-cast v1, Ljava/lang/Boolean;

    .line 249
    .line 250
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    iget-object v2, v0, LV1/c;->e:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v2, Ln/z;

    .line 257
    .line 258
    iget-object v3, v2, Ln/z;->D:Li/A;

    .line 259
    .line 260
    if-eqz v1, :cond_b

    .line 261
    .line 262
    invoke-virtual {v2}, Ln/z;->b1()V

    .line 263
    .line 264
    .line 265
    goto/16 :goto_7

    .line 266
    .line 267
    :cond_b
    iget-object v1, v2, Ln/z;->t:Lq/g;

    .line 268
    .line 269
    const/4 v4, 0x0

    .line 270
    if-eqz v1, :cond_10

    .line 271
    .line 272
    iget-object v1, v3, Li/A;->c:[Ljava/lang/Object;

    .line 273
    .line 274
    iget-object v5, v3, Li/A;->a:[J

    .line 275
    .line 276
    array-length v6, v5

    .line 277
    add-int/lit8 v6, v6, -0x2

    .line 278
    .line 279
    const/4 v7, 0x3

    .line 280
    if-ltz v6, :cond_f

    .line 281
    .line 282
    const/4 v9, 0x0

    .line 283
    :goto_4
    aget-wide v10, v5, v9

    .line 284
    .line 285
    not-long v12, v10

    .line 286
    const/4 v14, 0x7

    .line 287
    shl-long/2addr v12, v14

    .line 288
    and-long/2addr v12, v10

    .line 289
    const-wide v14, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    and-long/2addr v12, v14

    .line 295
    cmp-long v12, v12, v14

    .line 296
    .line 297
    if-eqz v12, :cond_e

    .line 298
    .line 299
    sub-int v12, v9, v6

    .line 300
    .line 301
    not-int v12, v12

    .line 302
    ushr-int/lit8 v12, v12, 0x1f

    .line 303
    .line 304
    const/16 v13, 0x8

    .line 305
    .line 306
    rsub-int/lit8 v12, v12, 0x8

    .line 307
    .line 308
    const/4 v14, 0x0

    .line 309
    :goto_5
    if-ge v14, v12, :cond_d

    .line 310
    .line 311
    const-wide/16 v15, 0xff

    .line 312
    .line 313
    and-long/2addr v15, v10

    .line 314
    const-wide/16 v17, 0x80

    .line 315
    .line 316
    cmp-long v15, v15, v17

    .line 317
    .line 318
    if-gez v15, :cond_c

    .line 319
    .line 320
    shl-int/lit8 v15, v9, 0x3

    .line 321
    .line 322
    add-int/2addr v15, v14

    .line 323
    aget-object v15, v1, v15

    .line 324
    .line 325
    check-cast v15, Lq/i;

    .line 326
    .line 327
    invoke-virtual {v2}, LW/p;->I0()Lc2/s;

    .line 328
    .line 329
    .line 330
    move-result-object v8

    .line 331
    move/from16 v16, v13

    .line 332
    .line 333
    new-instance v13, Ln/j;

    .line 334
    .line 335
    invoke-direct {v13, v2, v15, v4}, Ln/j;-><init>(Ln/z;Lq/i;LN1/c;)V

    .line 336
    .line 337
    .line 338
    invoke-static {v8, v4, v13, v7}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 339
    .line 340
    .line 341
    goto :goto_6

    .line 342
    :cond_c
    move/from16 v16, v13

    .line 343
    .line 344
    :goto_6
    shr-long v10, v10, v16

    .line 345
    .line 346
    add-int/lit8 v14, v14, 0x1

    .line 347
    .line 348
    move/from16 v13, v16

    .line 349
    .line 350
    goto :goto_5

    .line 351
    :cond_d
    move v8, v13

    .line 352
    if-ne v12, v8, :cond_f

    .line 353
    .line 354
    :cond_e
    if-eq v9, v6, :cond_f

    .line 355
    .line 356
    add-int/lit8 v9, v9, 0x1

    .line 357
    .line 358
    goto :goto_4

    .line 359
    :cond_f
    iget-object v1, v2, Ln/z;->E:Lq/i;

    .line 360
    .line 361
    if-eqz v1, :cond_10

    .line 362
    .line 363
    invoke-virtual {v2}, LW/p;->I0()Lc2/s;

    .line 364
    .line 365
    .line 366
    move-result-object v5

    .line 367
    new-instance v6, Ln/k;

    .line 368
    .line 369
    invoke-direct {v6, v2, v1, v4}, Ln/k;-><init>(Ln/z;Lq/i;LN1/c;)V

    .line 370
    .line 371
    .line 372
    invoke-static {v5, v4, v6, v7}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 373
    .line 374
    .line 375
    :cond_10
    invoke-virtual {v3}, Li/A;->a()V

    .line 376
    .line 377
    .line 378
    iput-object v4, v2, Ln/z;->E:Lq/i;

    .line 379
    .line 380
    :goto_7
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 381
    .line 382
    return-object v1

    .line 383
    :pswitch_1
    move-object/from16 v1, p1

    .line 384
    .line 385
    check-cast v1, Ljava/lang/Throwable;

    .line 386
    .line 387
    iget-object v2, v0, LV1/c;->e:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast v2, Lc2/U;

    .line 390
    .line 391
    invoke-virtual {v2, v1}, Lc2/U;->l(Ljava/lang/Throwable;)V

    .line 392
    .line 393
    .line 394
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 395
    .line 396
    return-object v1

    .line 397
    :pswitch_2
    move-object/from16 v1, p1

    .line 398
    .line 399
    check-cast v1, LU1/c;

    .line 400
    .line 401
    iget-object v2, v0, LV1/c;->e:Ljava/lang/Object;

    .line 402
    .line 403
    check-cast v2, Ly/a;

    .line 404
    .line 405
    iget-object v2, v2, Ly/a;->b:Li/D;

    .line 406
    .line 407
    invoke-virtual {v2, v1}, Li/D;->a(Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 411
    .line 412
    return-object v1

    .line 413
    :pswitch_3
    move-object/from16 v1, p1

    .line 414
    .line 415
    check-cast v1, Lc0/b;

    .line 416
    .line 417
    iget-wide v4, v1, Lc0/b;->a:J

    .line 418
    .line 419
    iget-object v1, v0, LV1/c;->e:Ljava/lang/Object;

    .line 420
    .line 421
    move-object v3, v1

    .line 422
    check-cast v3, LC/i;

    .line 423
    .line 424
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 425
    .line 426
    .line 427
    sget-object v1, LD/g;->a:LI/B;

    .line 428
    .line 429
    invoke-static {v3, v1}, Lw0/j;->h(Lw0/g;LI/t0;)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v1

    .line 433
    move-object v6, v1

    .line 434
    check-cast v6, LD/f;

    .line 435
    .line 436
    if-nez v6, :cond_11

    .line 437
    .line 438
    goto :goto_8

    .line 439
    :cond_11
    new-instance v7, LC/g;

    .line 440
    .line 441
    invoke-direct {v7, v3, v4, v5}, LC/g;-><init>(LC/i;J)V

    .line 442
    .line 443
    .line 444
    invoke-virtual {v3}, LW/p;->I0()Lc2/s;

    .line 445
    .line 446
    .line 447
    move-result-object v1

    .line 448
    new-instance v2, LC/h;

    .line 449
    .line 450
    const/4 v8, 0x0

    .line 451
    invoke-direct/range {v2 .. v8}, LC/h;-><init>(LC/i;JLD/f;LC/g;LN1/c;)V

    .line 452
    .line 453
    .line 454
    const/4 v3, 0x3

    .line 455
    const/4 v4, 0x0

    .line 456
    invoke-static {v1, v4, v2, v3}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 457
    .line 458
    .line 459
    :goto_8
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 460
    .line 461
    return-object v1

    .line 462
    nop

    .line 463
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
