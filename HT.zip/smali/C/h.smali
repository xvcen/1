.class public final LC/h;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LC/i;

.field public final synthetic j:J

.field public final synthetic k:LD/f;

.field public final synthetic l:LC/g;


# direct methods
.method public constructor <init>(LC/i;JLD/f;LC/g;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC/h;->i:LC/i;

    .line 2
    .line 3
    iput-wide p2, p0, LC/h;->j:J

    .line 4
    .line 5
    iput-object p4, p0, LC/h;->k:LD/f;

    .line 6
    .line 7
    iput-object p5, p0, LC/h;->l:LC/g;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p6}, LP1/i;-><init>(ILN1/c;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LC/h;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC/h;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC/h;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 7

    .line 1
    new-instance v0, LC/h;

    .line 2
    .line 3
    iget-object v4, p0, LC/h;->k:LD/f;

    .line 4
    .line 5
    iget-object v5, p0, LC/h;->l:LC/g;

    .line 6
    .line 7
    iget-object v1, p0, LC/h;->i:LC/i;

    .line 8
    .line 9
    iget-wide v2, p0, LC/h;->j:J

    .line 10
    .line 11
    move-object v6, p1

    .line 12
    invoke-direct/range {v0 .. v6}, LC/h;-><init>(LC/i;JLD/f;LC/g;LN1/c;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LC/h;->h:I

    .line 2
    .line 3
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    sget-object v4, LO1/a;->d:LO1/a;

    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    if-eq v0, v3, :cond_1

    .line 12
    .line 13
    if-ne v0, v2, :cond_0

    .line 14
    .line 15
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    goto :goto_2

    .line 19
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iget-object p1, p0, LC/h;->i:LC/i;

    .line 35
    .line 36
    iget-object p1, p1, LC/i;->t:LH/b0;

    .line 37
    .line 38
    if-eqz p1, :cond_3

    .line 39
    .line 40
    iput v3, p0, LC/h;->h:I

    .line 41
    .line 42
    new-instance v0, LH/b0;

    .line 43
    .line 44
    iget-object p1, p1, LH/b0;->i:LH/m0;

    .line 45
    .line 46
    invoke-direct {v0, p1, p0}, LH/b0;-><init>(LH/m0;LN1/c;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0, v1}, LH/b0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-ne p1, v4, :cond_3

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_3
    :goto_0
    iput v2, p0, LC/h;->h:I

    .line 57
    .line 58
    iget-object p1, p0, LC/h;->k:LD/f;

    .line 59
    .line 60
    iget-object v0, p0, LC/h;->l:LC/g;

    .line 61
    .line 62
    invoke-interface {p1, v0, p0}, LD/f;->a(LD/e;LP1/i;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    if-ne p1, v4, :cond_4

    .line 67
    .line 68
    :goto_1
    return-object v4

    .line 69
    :cond_4
    :goto_2
    return-object v1
.end method
