.class public final LC/i;
.super Lw0/i;
.source "SourceFile"

# interfaces
.implements Lw0/g;
.implements Lw0/m;


# instance fields
.field public t:LH/b0;

.field public final u:LI/m0;


# direct methods
.method public constructor <init>(LH/b0;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Lw0/i;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC/i;->t:LH/b0;

    .line 5
    .line 6
    sget-object p1, LI/h;->g:LI/h;

    .line 7
    .line 8
    new-instance v0, LI/m0;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-direct {v0, v1, p1}, LI/m0;-><init>(Ljava/lang/Object;LI/U0;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, LC/i;->u:LI/m0;

    .line 15
    .line 16
    new-instance p1, LB1/e;

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    invoke-direct {p1, v0, p0}, LB1/e;-><init>(ILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    sget-object v0, Lq0/E;->a:Lq0/l;

    .line 23
    .line 24
    new-instance v0, Lq0/K;

    .line 25
    .line 26
    invoke-direct {v0, v1, v1, p1}, Lq0/K;-><init>(Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v0}, Lw0/i;->U0(Lw0/h;)Lw0/h;

    .line 30
    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final O(Lw0/b0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LC/i;->u:LI/m0;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
