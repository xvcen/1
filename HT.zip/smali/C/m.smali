.class public final LC/m;
.super Lw0/i;
.source "SourceFile"

# interfaces
.implements Lw0/g;
.implements LD/e;


# instance fields
.field public t:LF/r;

.field public u:LH/c0;

.field public v:LH/d0;

.field public w:LH/a0;

.field public x:Lc2/e0;

.field public final y:LI/F;

.field public z:Lc0/c;


# direct methods
.method public constructor <init>(LF/r;LH/c0;LH/d0;LH/a0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lw0/i;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC/m;->t:LF/r;

    .line 5
    .line 6
    iput-object p2, p0, LC/m;->u:LH/c0;

    .line 7
    .line 8
    iput-object p3, p0, LC/m;->v:LH/d0;

    .line 9
    .line 10
    iput-object p4, p0, LC/m;->w:LH/a0;

    .line 11
    .line 12
    new-instance p1, LA1/P;

    .line 13
    .line 14
    const/4 p2, 0x5

    .line 15
    invoke-direct {p1, p2, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-static {p1}, LI/k;->l(LU1/a;)LI/F;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, LC/m;->y:LI/F;

    .line 23
    .line 24
    sget-object p1, Lc0/c;->e:Lc0/c;

    .line 25
    .line 26
    iput-object p1, p0, LC/m;->z:Lc0/c;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final A0()Lz/c;
    .locals 1

    .line 1
    iget-object v0, p0, LC/m;->y:LI/F;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/F;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lz/c;

    .line 8
    .line 9
    return-object v0
.end method

.method public final J(Lu0/r;)J
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, LC/m;->p0(Lu0/r;)Lc0/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lc0/c;->d()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    return-wide v0
.end method

.method public final M0()V
    .locals 2

    .line 1
    iget-object v0, p0, LC/m;->t:LF/r;

    .line 2
    .line 3
    sget-object v1, LC/n;->f:LC/n;

    .line 4
    .line 5
    iput-object v1, v0, LF/r;->f:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p0, v0, LF/r;->e:Ljava/lang/Object;

    .line 8
    .line 9
    return-void
.end method

.method public final N0()V
    .locals 2

    .line 1
    iget-object v0, p0, LC/m;->t:LF/r;

    .line 2
    .line 3
    sget-object v1, LC/n;->e:LC/n;

    .line 4
    .line 5
    iput-object v1, v0, LF/r;->f:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    iput-object v1, v0, LF/r;->e:Ljava/lang/Object;

    .line 9
    .line 10
    return-void
.end method

.method public final p0(Lu0/r;)Lc0/c;
    .locals 1

    .line 1
    iget-boolean v0, p0, LW/p;->q:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, LC/m;->z:Lc0/c;

    .line 6
    .line 7
    return-object p1

    .line 8
    :cond_0
    iget-object v0, p0, LC/m;->w:LH/a0;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LH/a0;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lc0/c;

    .line 15
    .line 16
    if-nez p1, :cond_1

    .line 17
    .line 18
    iget-object p1, p0, LC/m;->z:Lc0/c;

    .line 19
    .line 20
    return-object p1

    .line 21
    :cond_1
    iput-object p1, p0, LC/m;->z:Lc0/c;

    .line 22
    .line 23
    return-object p1
.end method
