.class public interface abstract LC1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V
.end method
