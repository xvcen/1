.class final LC1/b;
.super Lw0/V;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;"
    }
.end annotation


# instance fields
.field public final a:LC1/a;

.field public final b:LC1/l;

.field public final c:LU1/c;

.field public final d:LU1/c;

.field public final e:LU1/e;

.field public final f:LU1/c;


# direct methods
.method public constructor <init>(LC1/a;LC1/l;LU1/c;LU1/c;LU1/e;LU1/c;)V
    .locals 1

    .line 1
    const-string v0, "backdrop"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "effects"

    .line 7
    .line 8
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, LC1/b;->a:LC1/a;

    .line 15
    .line 16
    iput-object p2, p0, LC1/b;->b:LC1/l;

    .line 17
    .line 18
    iput-object p3, p0, LC1/b;->c:LU1/c;

    .line 19
    .line 20
    iput-object p4, p0, LC1/b;->d:LU1/c;

    .line 21
    .line 22
    iput-object p5, p0, LC1/b;->e:LU1/e;

    .line 23
    .line 24
    iput-object p6, p0, LC1/b;->f:LU1/c;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 7

    .line 1
    new-instance v0, LC1/g;

    .line 2
    .line 3
    iget-object v5, p0, LC1/b;->e:LU1/e;

    .line 4
    .line 5
    iget-object v6, p0, LC1/b;->f:LU1/c;

    .line 6
    .line 7
    iget-object v1, p0, LC1/b;->a:LC1/a;

    .line 8
    .line 9
    iget-object v2, p0, LC1/b;->b:LC1/l;

    .line 10
    .line 11
    iget-object v3, p0, LC1/b;->c:LU1/c;

    .line 12
    .line 13
    iget-object v4, p0, LC1/b;->d:LU1/c;

    .line 14
    .line 15
    invoke-direct/range {v0 .. v6}, LC1/g;-><init>(LC1/a;LC1/l;LU1/c;LU1/c;LU1/e;LU1/c;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 2

    .line 1
    check-cast p1, LC1/g;

    .line 2
    .line 3
    const-string v0, "node"

    .line 4
    .line 5
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LC1/b;->a:LC1/a;

    .line 9
    .line 10
    const-string v1, "<set-?>"

    .line 11
    .line 12
    invoke-static {v0, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p1, LC1/g;->r:LC1/a;

    .line 16
    .line 17
    iget-object v0, p0, LC1/b;->b:LC1/l;

    .line 18
    .line 19
    iput-object v0, p1, LC1/g;->s:LC1/l;

    .line 20
    .line 21
    iget-object v0, p0, LC1/b;->c:LU1/c;

    .line 22
    .line 23
    invoke-static {v0, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p1, LC1/g;->t:LU1/c;

    .line 27
    .line 28
    iget-object v0, p0, LC1/b;->d:LU1/c;

    .line 29
    .line 30
    iput-object v0, p1, LC1/g;->u:LU1/c;

    .line 31
    .line 32
    iget-object v0, p0, LC1/b;->e:LU1/e;

    .line 33
    .line 34
    iput-object v0, p1, LC1/g;->v:LU1/e;

    .line 35
    .line 36
    iget-object v0, p0, LC1/b;->f:LU1/c;

    .line 37
    .line 38
    iput-object v0, p1, LC1/g;->w:LU1/c;

    .line 39
    .line 40
    new-instance v0, LA1/P;

    .line 41
    .line 42
    const/4 v1, 0x6

    .line 43
    invoke-direct {v0, v1, p1}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v0}, Lw0/j;->p(LW/p;LU1/a;)V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_1

    .line 4
    :cond_0
    instance-of v0, p1, LC1/b;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_1
    check-cast p1, LC1/b;

    .line 10
    .line 11
    iget-object v0, p1, LC1/b;->a:LC1/a;

    .line 12
    .line 13
    iget-object v1, p0, LC1/b;->a:LC1/a;

    .line 14
    .line 15
    invoke-static {v1, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_2

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    iget-object v0, p0, LC1/b;->b:LC1/l;

    .line 23
    .line 24
    iget-object v1, p1, LC1/b;->b:LC1/l;

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_3

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_3
    iget-object v0, p0, LC1/b;->c:LU1/c;

    .line 34
    .line 35
    iget-object v1, p1, LC1/b;->c:LU1/c;

    .line 36
    .line 37
    invoke-static {v0, v1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_4

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_4
    iget-object v0, p0, LC1/b;->d:LU1/c;

    .line 45
    .line 46
    iget-object v1, p1, LC1/b;->d:LU1/c;

    .line 47
    .line 48
    invoke-static {v0, v1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_5

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_5
    iget-object v0, p0, LC1/b;->e:LU1/e;

    .line 56
    .line 57
    iget-object v1, p1, LC1/b;->e:LU1/e;

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_6

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_6
    iget-object v0, p0, LC1/b;->f:LU1/c;

    .line 67
    .line 68
    iget-object p1, p1, LC1/b;->f:LU1/c;

    .line 69
    .line 70
    invoke-static {v0, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-nez p1, :cond_7

    .line 75
    .line 76
    :goto_0
    const/4 p1, 0x0

    .line 77
    return p1

    .line 78
    :cond_7
    :goto_1
    const/4 p1, 0x1

    .line 79
    return p1
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, LC1/b;->a:LC1/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, LC1/b;->b:LC1/l;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, LC1/b;->c:LU1/c;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    iget-object v2, p0, LC1/b;->d:LU1/c;

    .line 29
    .line 30
    if-eqz v2, :cond_0

    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v2, v1

    .line 38
    :goto_0
    add-int/2addr v0, v2

    .line 39
    mul-int/lit16 v0, v0, 0x745f

    .line 40
    .line 41
    iget-object v2, p0, LC1/b;->e:LU1/e;

    .line 42
    .line 43
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    add-int/2addr v2, v0

    .line 48
    mul-int/lit8 v2, v2, 0x1f

    .line 49
    .line 50
    iget-object v0, p0, LC1/b;->f:LU1/c;

    .line 51
    .line 52
    if-eqz v0, :cond_1

    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    :cond_1
    add-int/2addr v2, v1

    .line 59
    mul-int/lit8 v2, v2, 0x1f

    .line 60
    .line 61
    return v2
.end method
