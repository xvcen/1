.class public abstract LC1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA1/u;

.field public static final b:LA1/E;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LA1/u;

    .line 2
    .line 3
    const/16 v1, 0x11

    .line 4
    .line 5
    invoke-direct {v0, v1}, LA1/u;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LC1/c;->a:LA1/u;

    .line 9
    .line 10
    new-instance v0, LA1/E;

    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    invoke-direct {v0, v1}, LA1/E;-><init>(I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, LC1/c;->b:LA1/E;

    .line 17
    .line 18
    return-void
.end method

.method public static final a(Ld0/u;Ld0/D;Ld0/j;)V
    .locals 1

    .line 1
    const-string v0, "outline"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    instance-of v0, p1, Ld0/K;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast p1, Ld0/K;

    .line 11
    .line 12
    iget-object p1, p1, Ld0/K;->f:Lc0/c;

    .line 13
    .line 14
    invoke-static {p0, p1}, Ld0/u;->s(Ld0/u;Lc0/c;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    instance-of v0, p1, Ld0/L;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    invoke-static {p2}, LV1/i;->b(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p2, Ld0/j;->a:Landroid/graphics/Path;

    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/graphics/Path;->rewind()V

    .line 28
    .line 29
    .line 30
    check-cast p1, Ld0/L;

    .line 31
    .line 32
    iget-object p1, p1, Ld0/L;->f:Lc0/d;

    .line 33
    .line 34
    invoke-static {p2, p1}, Ld0/j;->b(Ld0/j;Lc0/d;)V

    .line 35
    .line 36
    .line 37
    invoke-interface {p0, p2}, Ld0/u;->d(Ld0/j;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_1
    instance-of p2, p1, Ld0/J;

    .line 42
    .line 43
    if-eqz p2, :cond_2

    .line 44
    .line 45
    check-cast p1, Ld0/J;

    .line 46
    .line 47
    iget-object p1, p1, Ld0/J;->f:Ld0/j;

    .line 48
    .line 49
    invoke-interface {p0, p1}, Ld0/u;->d(Ld0/j;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_2
    new-instance p0, LC0/e;

    .line 54
    .line 55
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 56
    .line 57
    .line 58
    throw p0
.end method

.method public static b(LW/q;LC1/a;LU1/a;LU1/c;LU1/a;LU1/a;LU1/a;LU1/c;LU1/c;I)LW/q;
    .locals 10

    .line 1
    move-object/from16 v0, p6

    .line 2
    .line 3
    and-int/lit8 v1, p9, 0x10

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    sget-object v1, LC1/c;->a:LA1/u;

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object v1, p5

    .line 11
    :goto_0
    and-int/lit8 v2, p9, 0x40

    .line 12
    .line 13
    if-eqz v2, :cond_1

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    move-object v7, v2

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    move-object/from16 v7, p7

    .line 19
    .line 20
    :goto_1
    const-string v2, "<this>"

    .line 21
    .line 22
    invoke-static {p0, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const-string v2, "backdrop"

    .line 26
    .line 27
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string v2, "shape"

    .line 31
    .line 32
    invoke-static {p2, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const-string v2, "effects"

    .line 36
    .line 37
    invoke-static {p3, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    new-instance v5, LC1/l;

    .line 41
    .line 42
    invoke-direct {v5, p2}, LC1/l;-><init>(LU1/a;)V

    .line 43
    .line 44
    .line 45
    sget-object p2, LW/n;->a:LW/n;

    .line 46
    .line 47
    if-eqz v7, :cond_2

    .line 48
    .line 49
    invoke-static {v7}, Ld0/D;->k(LU1/c;)LW/q;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    goto :goto_2

    .line 54
    :cond_2
    move-object v2, p2

    .line 55
    :goto_2
    invoke-interface {p0, v2}, LW/q;->c(LW/q;)LW/q;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    new-instance v2, LG1/b;

    .line 62
    .line 63
    invoke-direct {v2, v5, v0}, LG1/b;-><init>(LC1/l;LU1/a;)V

    .line 64
    .line 65
    .line 66
    goto :goto_3

    .line 67
    :cond_3
    move-object v2, p2

    .line 68
    :goto_3
    invoke-interface {p0, v2}, LW/q;->c(LW/q;)LW/q;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    if-eqz v1, :cond_4

    .line 73
    .line 74
    new-instance v0, LG1/g;

    .line 75
    .line 76
    invoke-direct {v0, v5, v1}, LG1/g;-><init>(LC1/l;LU1/a;)V

    .line 77
    .line 78
    .line 79
    goto :goto_4

    .line 80
    :cond_4
    move-object v0, p2

    .line 81
    :goto_4
    invoke-interface {p0, v0}, LW/q;->c(LW/q;)LW/q;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    if-eqz p4, :cond_5

    .line 86
    .line 87
    new-instance p2, LF1/b;

    .line 88
    .line 89
    invoke-direct {p2, v5, p4}, LF1/b;-><init>(LC1/l;LU1/a;)V

    .line 90
    .line 91
    .line 92
    :cond_5
    invoke-interface {p0, p2}, LW/q;->c(LW/q;)LW/q;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    new-instance v3, LC1/b;

    .line 97
    .line 98
    sget-object v8, LC1/c;->b:LA1/E;

    .line 99
    .line 100
    move-object v4, p1

    .line 101
    move-object v6, p3

    .line 102
    move-object/from16 v9, p8

    .line 103
    .line 104
    invoke-direct/range {v3 .. v9}, LC1/b;-><init>(LC1/a;LC1/l;LU1/c;LU1/c;LU1/e;LU1/c;)V

    .line 105
    .line 106
    .line 107
    invoke-interface {p0, v3}, LW/q;->c(LW/q;)LW/q;

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    return-object p0
.end method

.method public static final c(Lw0/h;Lf0/d;Lg0/c;JLU1/c;)V
    .locals 2

    .line 1
    const-string v0, "$this$recordLayer"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "layer"

    .line 7
    .line 8
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "block"

    .line 12
    .line 13
    invoke-static {p5, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {p0}, Lw0/j;->u(Lw0/h;)Lw0/E;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    iget-object p0, p0, Lw0/E;->B:LT0/c;

    .line 21
    .line 22
    new-instance v0, LC1/e;

    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    invoke-direct {v0, v1, p0, p5}, LC1/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-interface {p1, p2, p3, p4, v0}, Lf0/d;->M(Lg0/c;JLU1/c;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
