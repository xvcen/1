.class public final synthetic LC1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LC1/g;


# direct methods
.method public synthetic constructor <init>(LC1/g;I)V
    .locals 0

    .line 1
    iput p2, p0, LC1/d;->d:I

    iput-object p1, p0, LC1/d;->e:LC1/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, LC1/d;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lf0/d;

    .line 7
    .line 8
    const-string v0, "$this$onDrawBackdrop"

    .line 9
    .line 10
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LC1/d;->e:LC1/g;

    .line 14
    .line 15
    iget-object v1, v0, LC1/g;->r:LC1/a;

    .line 16
    .line 17
    iget-object v2, v0, LC1/g;->x:LC1/f;

    .line 18
    .line 19
    iget-object v3, v0, LC1/g;->A:LI/m0;

    .line 20
    .line 21
    invoke-virtual {v3}, LI/m0;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Lu0/r;

    .line 26
    .line 27
    iget-object v0, v0, LC1/g;->u:LU1/c;

    .line 28
    .line 29
    invoke-interface {v1, p1, v2, v3, v0}, LC1/a;->b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V

    .line 30
    .line 31
    .line 32
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 33
    .line 34
    return-object p1

    .line 35
    :pswitch_0
    move-object v1, p1

    .line 36
    check-cast v1, Lf0/d;

    .line 37
    .line 38
    const-string p1, "<this>"

    .line 39
    .line 40
    invoke-static {v1, p1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    iget-object v0, p0, LC1/d;->e:LC1/g;

    .line 44
    .line 45
    iget-object v2, v0, LC1/g;->y:Lg0/c;

    .line 46
    .line 47
    if-eqz v2, :cond_2

    .line 48
    .line 49
    iget-object p1, v0, LC1/g;->B:LI/i0;

    .line 50
    .line 51
    invoke-virtual {p1}, LI/i0;->g()F

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    invoke-interface {v1}, Lf0/d;->a()J

    .line 56
    .line 57
    .line 58
    move-result-wide v3

    .line 59
    const/16 v6, 0x20

    .line 60
    .line 61
    shr-long/2addr v3, v6

    .line 62
    long-to-int v3, v3

    .line 63
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    float-to-int v3, v3

    .line 68
    float-to-int v7, p1

    .line 69
    mul-int/lit8 v4, v7, 0x2

    .line 70
    .line 71
    add-int/2addr v3, v4

    .line 72
    invoke-interface {v1}, Lf0/d;->a()J

    .line 73
    .line 74
    .line 75
    move-result-wide v8

    .line 76
    const-wide v10, 0xffffffffL

    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    and-long/2addr v8, v10

    .line 82
    long-to-int v5, v8

    .line 83
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 84
    .line 85
    .line 86
    move-result v5

    .line 87
    float-to-int v5, v5

    .line 88
    add-int/2addr v5, v4

    .line 89
    int-to-long v3, v3

    .line 90
    shl-long/2addr v3, v6

    .line 91
    int-to-long v8, v5

    .line 92
    and-long/2addr v8, v10

    .line 93
    or-long/2addr v3, v8

    .line 94
    iget-object v5, v0, LC1/g;->C:LC1/d;

    .line 95
    .line 96
    invoke-static/range {v0 .. v5}, LC1/c;->c(Lw0/h;Lf0/d;Lg0/c;JLU1/c;)V

    .line 97
    .line 98
    .line 99
    const/4 v0, 0x0

    .line 100
    cmpg-float p1, p1, v0

    .line 101
    .line 102
    if-nez p1, :cond_0

    .line 103
    .line 104
    const-wide/16 v3, 0x0

    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_0
    neg-int p1, v7

    .line 108
    int-to-long v3, p1

    .line 109
    shl-long v7, v3, v6

    .line 110
    .line 111
    and-long/2addr v3, v10

    .line 112
    or-long/2addr v3, v7

    .line 113
    :goto_1
    iget-wide v7, v2, Lg0/c;->t:J

    .line 114
    .line 115
    invoke-static {v7, v8, v3, v4}, LT0/k;->a(JJ)Z

    .line 116
    .line 117
    .line 118
    move-result p1

    .line 119
    if-nez p1, :cond_1

    .line 120
    .line 121
    iput-wide v3, v2, Lg0/c;->t:J

    .line 122
    .line 123
    iget-wide v7, v2, Lg0/c;->u:J

    .line 124
    .line 125
    iget-object p1, v2, Lg0/c;->a:Lg0/e;

    .line 126
    .line 127
    shr-long v5, v3, v6

    .line 128
    .line 129
    long-to-int v0, v5

    .line 130
    and-long/2addr v3, v10

    .line 131
    long-to-int v3, v3

    .line 132
    invoke-interface {p1, v0, v3, v7, v8}, Lg0/e;->G(IIJ)V

    .line 133
    .line 134
    .line 135
    :cond_1
    invoke-static {v1, v2}, LT0/g;->r(Lf0/d;Lg0/c;)V

    .line 136
    .line 137
    .line 138
    :cond_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 139
    .line 140
    return-object p1

    .line 141
    :pswitch_1
    check-cast p1, Lf0/d;

    .line 142
    .line 143
    const-string v0, "<this>"

    .line 144
    .line 145
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    invoke-virtual {v0}, LI/e0;->m()Ld0/u;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    iget-object v1, p0, LC1/d;->e:LC1/g;

    .line 157
    .line 158
    iget-object v2, v1, LC1/g;->B:LI/i0;

    .line 159
    .line 160
    invoke-virtual {v2}, LI/i0;->g()F

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    const/4 v3, 0x0

    .line 165
    cmpg-float v3, v2, v3

    .line 166
    .line 167
    if-nez v3, :cond_3

    .line 168
    .line 169
    goto :goto_2

    .line 170
    :cond_3
    invoke-interface {v0, v2, v2}, Ld0/u;->f(FF)V

    .line 171
    .line 172
    .line 173
    :goto_2
    iget-object v4, v1, LC1/g;->v:LU1/e;

    .line 174
    .line 175
    new-instance v5, LC1/d;

    .line 176
    .line 177
    const/4 v6, 0x3

    .line 178
    invoke-direct {v5, v1, v6}, LC1/d;-><init>(LC1/g;I)V

    .line 179
    .line 180
    .line 181
    invoke-interface {v4, p1, v5}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    if-nez v3, :cond_4

    .line 185
    .line 186
    goto :goto_3

    .line 187
    :cond_4
    neg-float p1, v2

    .line 188
    invoke-interface {v0, p1, p1}, Ld0/u;->f(FF)V

    .line 189
    .line 190
    .line 191
    :goto_3
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 192
    .line 193
    return-object p1

    .line 194
    :pswitch_2
    check-cast p1, Ld0/E;

    .line 195
    .line 196
    const-string v0, "<this>"

    .line 197
    .line 198
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    const/4 v0, 0x1

    .line 202
    invoke-interface {p1, v0}, Ld0/E;->n(Z)V

    .line 203
    .line 204
    .line 205
    iget-object v1, p0, LC1/d;->e:LC1/g;

    .line 206
    .line 207
    iget-object v1, v1, LC1/g;->s:LC1/l;

    .line 208
    .line 209
    iget-object v1, v1, LC1/l;->g:LC1/k;

    .line 210
    .line 211
    invoke-interface {p1, v1}, Ld0/E;->a0(Ld0/T;)V

    .line 212
    .line 213
    .line 214
    invoke-interface {p1, v0}, Ld0/E;->k0(I)V

    .line 215
    .line 216
    .line 217
    goto/16 :goto_0

    .line 218
    .line 219
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
