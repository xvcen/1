.class public final synthetic LC1/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LC1/e;->d:I

    iput-object p2, p0, LC1/e;->e:Ljava/lang/Object;

    iput-object p3, p0, LC1/e;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ls/E;Lu0/L;)V
    .locals 1

    .line 2
    const/16 v0, 0xf

    iput v0, p0, LC1/e;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC1/e;->f:Ljava/lang/Object;

    iput-object p2, p0, LC1/e;->e:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LC1/e;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw/S;

    .line 9
    .line 10
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Ld0/s;

    .line 13
    .line 14
    check-cast p1, Lw0/G;

    .line 15
    .line 16
    invoke-virtual {p1}, Lw0/G;->c()V

    .line 17
    .line 18
    .line 19
    iget-object v2, v0, Lw/S;->s:LI/m0;

    .line 20
    .line 21
    invoke-virtual {v2}, LI/m0;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_0

    .line 32
    .line 33
    iget-object v0, v0, Lw/S;->t:LI/m0;

    .line 34
    .line 35
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    check-cast v0, Ljava/lang/Boolean;

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    :cond_0
    const/4 v0, 0x0

    .line 48
    const/16 v2, 0x7e

    .line 49
    .line 50
    invoke-static {p1, v1, v0, v2}, Lf0/d;->W(Lw0/G;Ld0/s;FI)V

    .line 51
    .line 52
    .line 53
    :cond_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 54
    .line 55
    return-object p1

    .line 56
    :pswitch_0
    iget-object v0, p0, LC1/e;->f:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, Ls/E;

    .line 59
    .line 60
    iget-object v1, p0, LC1/e;->e:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v1, Lu0/L;

    .line 63
    .line 64
    check-cast p1, Lu0/K;

    .line 65
    .line 66
    iget-boolean v2, v0, Ls/E;->v:Z

    .line 67
    .line 68
    if-eqz v2, :cond_2

    .line 69
    .line 70
    iget v2, v0, Ls/E;->r:F

    .line 71
    .line 72
    invoke-interface {p1, v2}, LT0/c;->Y(F)I

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    iget v0, v0, Ls/E;->s:F

    .line 77
    .line 78
    invoke-interface {p1, v0}, LT0/c;->Y(F)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    invoke-static {p1, v1, v2, v0}, Lu0/K;->A(Lu0/K;Lu0/L;II)V

    .line 83
    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_2
    iget v2, v0, Ls/E;->r:F

    .line 87
    .line 88
    invoke-interface {p1, v2}, LT0/c;->Y(F)I

    .line 89
    .line 90
    .line 91
    move-result v2

    .line 92
    iget v0, v0, Ls/E;->s:F

    .line 93
    .line 94
    invoke-interface {p1, v0}, LT0/c;->Y(F)I

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    invoke-static {p1, v1, v2, v0}, Lu0/K;->x(Lu0/K;Lu0/L;II)V

    .line 99
    .line 100
    .line 101
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 102
    .line 103
    return-object p1

    .line 104
    :pswitch_1
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v0, Lp/t1;

    .line 107
    .line 108
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, LU1/c;

    .line 111
    .line 112
    check-cast p1, Ljava/lang/Long;

    .line 113
    .line 114
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 115
    .line 116
    .line 117
    iget p1, v0, Lp/t1;->e:F

    .line 118
    .line 119
    const/4 v2, 0x0

    .line 120
    iput v2, v0, Lp/t1;->e:F

    .line 121
    .line 122
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-interface {v1, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 130
    .line 131
    return-object p1

    .line 132
    :pswitch_2
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Lp/P0;

    .line 135
    .line 136
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v1, Lp/S0;

    .line 139
    .line 140
    check-cast p1, Lp/u;

    .line 141
    .line 142
    iget-boolean v2, p1, Lp/u;->b:Z

    .line 143
    .line 144
    if-eqz v2, :cond_3

    .line 145
    .line 146
    const/high16 v2, -0x40800000    # -1.0f

    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_3
    const/high16 v2, 0x3f800000    # 1.0f

    .line 150
    .line 151
    :goto_1
    iget-wide v3, p1, Lp/u;->a:J

    .line 152
    .line 153
    iget-object p1, v1, Lp/S0;->d:Lp/n0;

    .line 154
    .line 155
    sget-object v1, Lp/n0;->e:Lp/n0;

    .line 156
    .line 157
    const/4 v5, 0x1

    .line 158
    const/4 v6, 0x0

    .line 159
    if-ne p1, v1, :cond_4

    .line 160
    .line 161
    invoke-static {v6, v5, v3, v4}, Lc0/b;->a(FIJ)J

    .line 162
    .line 163
    .line 164
    move-result-wide v3

    .line 165
    goto :goto_2

    .line 166
    :cond_4
    const/4 p1, 0x2

    .line 167
    invoke-static {v6, p1, v3, v4}, Lc0/b;->a(FIJ)J

    .line 168
    .line 169
    .line 170
    move-result-wide v3

    .line 171
    :goto_2
    invoke-static {v3, v4, v2}, Lc0/b;->f(JF)J

    .line 172
    .line 173
    .line 174
    move-result-wide v1

    .line 175
    invoke-virtual {v0, v1, v2, v5}, Lp/P0;->a(JI)J

    .line 176
    .line 177
    .line 178
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 179
    .line 180
    return-object p1

    .line 181
    :pswitch_3
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 182
    .line 183
    check-cast v0, LA0/h;

    .line 184
    .line 185
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 186
    .line 187
    check-cast v1, Lp/f;

    .line 188
    .line 189
    check-cast p1, Ljava/lang/Throwable;

    .line 190
    .line 191
    iget-object p1, v0, LA0/h;->e:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast p1, LK/e;

    .line 194
    .line 195
    invoke-virtual {p1, v1}, LK/e;->i(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 199
    .line 200
    return-object p1

    .line 201
    :pswitch_4
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast v0, Lq/g;

    .line 204
    .line 205
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 206
    .line 207
    check-cast v1, Lq/f;

    .line 208
    .line 209
    check-cast p1, Ljava/lang/Throwable;

    .line 210
    .line 211
    invoke-virtual {v0, v1}, Lq/g;->b(Lq/f;)V

    .line 212
    .line 213
    .line 214
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 215
    .line 216
    return-object p1

    .line 217
    :pswitch_5
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast v0, Lq/g;

    .line 220
    .line 221
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 222
    .line 223
    check-cast v1, Lq/h;

    .line 224
    .line 225
    check-cast p1, Ljava/lang/Throwable;

    .line 226
    .line 227
    invoke-virtual {v0, v1}, Lq/g;->b(Lq/f;)V

    .line 228
    .line 229
    .line 230
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 231
    .line 232
    return-object p1

    .line 233
    :pswitch_6
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 234
    .line 235
    check-cast v0, Ll/U;

    .line 236
    .line 237
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 238
    .line 239
    check-cast v1, Ll/M;

    .line 240
    .line 241
    check-cast p1, LI/I;

    .line 242
    .line 243
    new-instance p1, Ll/W;

    .line 244
    .line 245
    const/4 v2, 0x1

    .line 246
    invoke-direct {p1, v2, v0, v1}, Ll/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    return-object p1

    .line 250
    :pswitch_7
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v0, Ll/U;

    .line 253
    .line 254
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v1, Ll/U;

    .line 257
    .line 258
    check-cast p1, LI/I;

    .line 259
    .line 260
    iget-object p1, v0, Ll/U;->j:LU/t;

    .line 261
    .line 262
    invoke-virtual {p1, v1}, LU/t;->add(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    new-instance p1, Ll/W;

    .line 266
    .line 267
    const/4 v2, 0x0

    .line 268
    invoke-direct {p1, v2, v0, v1}, Ll/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    return-object p1

    .line 272
    :pswitch_8
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast v0, Lc2/s;

    .line 275
    .line 276
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast v1, Ll/U;

    .line 279
    .line 280
    check-cast p1, LI/I;

    .line 281
    .line 282
    new-instance p1, Ll/S;

    .line 283
    .line 284
    const/4 v2, 0x0

    .line 285
    invoke-direct {p1, v1, v2}, Ll/S;-><init>(Ll/U;LN1/c;)V

    .line 286
    .line 287
    .line 288
    const/4 v1, 0x1

    .line 289
    invoke-static {v0, v2, p1, v1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 290
    .line 291
    .line 292
    new-instance p1, Ll/T;

    .line 293
    .line 294
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 295
    .line 296
    .line 297
    return-object p1

    .line 298
    :pswitch_9
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 299
    .line 300
    check-cast v0, Ld2/e;

    .line 301
    .line 302
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v1, Ld2/d;

    .line 305
    .line 306
    check-cast p1, Ljava/lang/Throwable;

    .line 307
    .line 308
    iget-object p1, v0, Ld2/e;->f:Landroid/os/Handler;

    .line 309
    .line 310
    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 311
    .line 312
    .line 313
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 314
    .line 315
    return-object p1

    .line 316
    :pswitch_a
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 317
    .line 318
    check-cast v0, LI/E0;

    .line 319
    .line 320
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 321
    .line 322
    check-cast v1, Ljava/lang/Throwable;

    .line 323
    .line 324
    check-cast p1, Ljava/lang/Throwable;

    .line 325
    .line 326
    iget-object v2, v0, LI/E0;->c:Ljava/lang/Object;

    .line 327
    .line 328
    monitor-enter v2

    .line 329
    const/4 v3, 0x0

    .line 330
    if-eqz v1, :cond_6

    .line 331
    .line 332
    if-eqz p1, :cond_7

    .line 333
    .line 334
    :try_start_0
    instance-of v4, p1, Ljava/util/concurrent/CancellationException;

    .line 335
    .line 336
    if-nez v4, :cond_5

    .line 337
    .line 338
    goto :goto_3

    .line 339
    :cond_5
    move-object p1, v3

    .line 340
    :goto_3
    if-eqz p1, :cond_7

    .line 341
    .line 342
    invoke-static {v1, p1}, LX1/a;->A(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 343
    .line 344
    .line 345
    goto :goto_4

    .line 346
    :catchall_0
    move-exception p1

    .line 347
    goto :goto_5

    .line 348
    :cond_6
    move-object v1, v3

    .line 349
    :cond_7
    :goto_4
    iput-object v1, v0, LI/E0;->e:Ljava/lang/Throwable;

    .line 350
    .line 351
    iget-object p1, v0, LI/E0;->u:Lf2/G;

    .line 352
    .line 353
    sget-object v0, LI/y0;->d:LI/y0;

    .line 354
    .line 355
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 356
    .line 357
    .line 358
    invoke-virtual {p1, v3, v0}, Lf2/G;->h(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 359
    .line 360
    .line 361
    monitor-exit v2

    .line 362
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 363
    .line 364
    return-object p1

    .line 365
    :goto_5
    monitor-exit v2

    .line 366
    throw p1

    .line 367
    :pswitch_b
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 368
    .line 369
    check-cast v0, LI/y;

    .line 370
    .line 371
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast v1, Li/F;

    .line 374
    .line 375
    invoke-virtual {v0, p1}, LI/y;->v(Ljava/lang/Object;)V

    .line 376
    .line 377
    .line 378
    if-eqz v1, :cond_8

    .line 379
    .line 380
    invoke-virtual {v1, p1}, Li/F;->a(Ljava/lang/Object;)Z

    .line 381
    .line 382
    .line 383
    :cond_8
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 384
    .line 385
    return-object p1

    .line 386
    :pswitch_c
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 387
    .line 388
    check-cast v0, LU1/a;

    .line 389
    .line 390
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 391
    .line 392
    check-cast v1, LU1/a;

    .line 393
    .line 394
    check-cast p1, Lz/g;

    .line 395
    .line 396
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    if-eqz v1, :cond_9

    .line 400
    .line 401
    invoke-interface {v1}, LU1/a;->a()Ljava/lang/Object;

    .line 402
    .line 403
    .line 404
    move-result-object v0

    .line 405
    check-cast v0, Ljava/lang/Boolean;

    .line 406
    .line 407
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    goto :goto_6

    .line 412
    :cond_9
    const/4 v0, 0x1

    .line 413
    :goto_6
    if-eqz v0, :cond_a

    .line 414
    .line 415
    invoke-interface {p1}, Lz/g;->close()V

    .line 416
    .line 417
    .line 418
    :cond_a
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 419
    .line 420
    return-object p1

    .line 421
    :pswitch_d
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v0, LD1/g;

    .line 424
    .line 425
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 426
    .line 427
    check-cast v1, Lw0/G;

    .line 428
    .line 429
    check-cast p1, Lf0/d;

    .line 430
    .line 431
    const-string v2, "$this$recordLayer"

    .line 432
    .line 433
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    iget-object p1, v0, LD1/g;->r:LD1/d;

    .line 437
    .line 438
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 439
    .line 440
    .line 441
    invoke-virtual {v1}, Lw0/G;->c()V

    .line 442
    .line 443
    .line 444
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 445
    .line 446
    return-object p1

    .line 447
    :pswitch_e
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 448
    .line 449
    check-cast v0, LT0/c;

    .line 450
    .line 451
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 452
    .line 453
    check-cast v1, LU1/c;

    .line 454
    .line 455
    check-cast p1, Lf0/d;

    .line 456
    .line 457
    const-string v2, "$this$record"

    .line 458
    .line 459
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 460
    .line 461
    .line 462
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 463
    .line 464
    .line 465
    move-result-object v2

    .line 466
    invoke-virtual {v2}, LI/e0;->q()LT0/c;

    .line 467
    .line 468
    .line 469
    move-result-object v2

    .line 470
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 471
    .line 472
    .line 473
    move-result-object v3

    .line 474
    invoke-virtual {v3, v0}, LI/e0;->C(LT0/c;)V

    .line 475
    .line 476
    .line 477
    :try_start_1
    invoke-interface {v1, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 478
    .line 479
    .line 480
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 481
    .line 482
    .line 483
    move-result-object p1

    .line 484
    invoke-virtual {p1, v2}, LI/e0;->C(LT0/c;)V

    .line 485
    .line 486
    .line 487
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 488
    .line 489
    return-object p1

    .line 490
    :catchall_1
    move-exception v0

    .line 491
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 492
    .line 493
    .line 494
    move-result-object p1

    .line 495
    invoke-virtual {p1, v2}, LI/e0;->C(LT0/c;)V

    .line 496
    .line 497
    .line 498
    throw v0

    .line 499
    :pswitch_f
    iget-object v0, p0, LC1/e;->e:Ljava/lang/Object;

    .line 500
    .line 501
    check-cast v0, Lu0/L;

    .line 502
    .line 503
    iget-object v1, p0, LC1/e;->f:Ljava/lang/Object;

    .line 504
    .line 505
    check-cast v1, LC1/g;

    .line 506
    .line 507
    check-cast p1, Lu0/K;

    .line 508
    .line 509
    const-string v2, "$this$layout"

    .line 510
    .line 511
    invoke-static {p1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 512
    .line 513
    .line 514
    iget-object v1, v1, LC1/g;->z:LC1/d;

    .line 515
    .line 516
    invoke-static {p1, v0}, Lu0/K;->c(Lu0/K;Lu0/L;)V

    .line 517
    .line 518
    .line 519
    iget-wide v2, v0, Lu0/L;->h:J

    .line 520
    .line 521
    const-wide/16 v4, 0x0

    .line 522
    .line 523
    invoke-static {v4, v5, v2, v3}, LT0/k;->c(JJ)J

    .line 524
    .line 525
    .line 526
    move-result-wide v2

    .line 527
    const/4 p1, 0x0

    .line 528
    invoke-virtual {v0, v2, v3, p1, v1}, Lu0/L;->y0(JFLU1/c;)V

    .line 529
    .line 530
    .line 531
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 532
    .line 533
    return-object p1

    .line 534
    nop

    .line 535
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
