.class public final LC1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/i;
.implements LT0/c;


# instance fields
.field public d:F

.field public e:F

.field public f:J

.field public g:LT0/o;

.field public h:F

.field public i:Landroid/graphics/RenderEffect;

.field public final j:LC1/j;

.field public final synthetic k:LC1/g;


# direct methods
.method public constructor <init>(LC1/g;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC1/f;->k:LC1/g;

    .line 5
    .line 6
    const/high16 p1, 0x3f800000    # 1.0f

    .line 7
    .line 8
    iput p1, p0, LC1/f;->d:F

    .line 9
    .line 10
    iput p1, p0, LC1/f;->e:F

    .line 11
    .line 12
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    iput-wide v0, p0, LC1/f;->f:J

    .line 18
    .line 19
    sget-object p1, LT0/o;->d:LT0/o;

    .line 20
    .line 21
    iput-object p1, p0, LC1/f;->g:LT0/o;

    .line 22
    .line 23
    new-instance p1, LC1/j;

    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    invoke-direct {p1, v0}, LC1/j;-><init>(I)V

    .line 27
    .line 28
    .line 29
    iput-object p1, p0, LC1/f;->j:LC1/j;

    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/RuntimeShader;
    .locals 1

    .line 1
    iget-object v0, p0, LC1/f;->j:LC1/j;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LC1/j;->c(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/RuntimeShader;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final g()F
    .locals 1

    .line 1
    iget v0, p0, LC1/f;->d:F

    .line 2
    .line 3
    return v0
.end method

.method public final z()F
    .locals 1

    .line 1
    iget v0, p0, LC1/f;->e:F

    .line 2
    .line 3
    return v0
.end method
