.class public final LC1/g;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/u;
.implements Lw0/l;
.implements Lw0/m;
.implements Lw0/f0;


# instance fields
.field public final A:LI/m0;

.field public final B:LI/i0;

.field public final C:LC1/d;

.field public final D:LC1/d;

.field public r:LC1/a;

.field public s:LC1/l;

.field public t:LU1/c;

.field public u:LU1/c;

.field public v:LU1/e;

.field public w:LU1/c;

.field public final x:LC1/f;

.field public y:Lg0/c;

.field public final z:LC1/d;


# direct methods
.method public constructor <init>(LC1/a;LC1/l;LU1/c;LU1/c;LU1/e;LU1/c;)V
    .locals 1

    .line 1
    const-string v0, "backdrop"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "effects"

    .line 7
    .line 8
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, LW/p;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, LC1/g;->r:LC1/a;

    .line 15
    .line 16
    iput-object p2, p0, LC1/g;->s:LC1/l;

    .line 17
    .line 18
    iput-object p3, p0, LC1/g;->t:LU1/c;

    .line 19
    .line 20
    iput-object p4, p0, LC1/g;->u:LU1/c;

    .line 21
    .line 22
    iput-object p5, p0, LC1/g;->v:LU1/e;

    .line 23
    .line 24
    iput-object p6, p0, LC1/g;->w:LU1/c;

    .line 25
    .line 26
    new-instance p1, LC1/f;

    .line 27
    .line 28
    invoke-direct {p1, p0}, LC1/f;-><init>(LC1/g;)V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, LC1/g;->x:LC1/f;

    .line 32
    .line 33
    new-instance p1, LC1/d;

    .line 34
    .line 35
    const/4 p2, 0x0

    .line 36
    invoke-direct {p1, p0, p2}, LC1/d;-><init>(LC1/g;I)V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, LC1/g;->z:LC1/d;

    .line 40
    .line 41
    sget-object p1, LI/h;->g:LI/h;

    .line 42
    .line 43
    new-instance p2, LI/m0;

    .line 44
    .line 45
    const/4 p3, 0x0

    .line 46
    invoke-direct {p2, p3, p1}, LI/m0;-><init>(Ljava/lang/Object;LI/U0;)V

    .line 47
    .line 48
    .line 49
    iput-object p2, p0, LC1/g;->A:LI/m0;

    .line 50
    .line 51
    new-instance p1, LI/i0;

    .line 52
    .line 53
    const/4 p2, 0x0

    .line 54
    invoke-direct {p1, p2}, LI/i0;-><init>(F)V

    .line 55
    .line 56
    .line 57
    iput-object p1, p0, LC1/g;->B:LI/i0;

    .line 58
    .line 59
    new-instance p1, LC1/d;

    .line 60
    .line 61
    const/4 p2, 0x1

    .line 62
    invoke-direct {p1, p0, p2}, LC1/d;-><init>(LC1/g;I)V

    .line 63
    .line 64
    .line 65
    iput-object p1, p0, LC1/g;->C:LC1/d;

    .line 66
    .line 67
    new-instance p1, LC1/d;

    .line 68
    .line 69
    const/4 p2, 0x2

    .line 70
    invoke-direct {p1, p0, p2}, LC1/d;-><init>(LC1/g;I)V

    .line 71
    .line 72
    .line 73
    iput-object p1, p0, LC1/g;->D:LC1/d;

    .line 74
    .line 75
    return-void
.end method


# virtual methods
.method public final M0()V
    .locals 2

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ld0/A;->b()Lg0/c;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, LC1/g;->y:Lg0/c;

    .line 10
    .line 11
    new-instance v0, LA1/P;

    .line 12
    .line 13
    const/4 v1, 0x6

    .line 14
    invoke-direct {v0, v1, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-static {p0, v0}, Lw0/j;->p(LW/p;LU1/a;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final N0()V
    .locals 5

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LC1/g;->y:Lg0/c;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-interface {v0, v1}, Ld0/A;->a(Lg0/c;)V

    .line 11
    .line 12
    .line 13
    iput-object v2, p0, LC1/g;->y:Lg0/c;

    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, LC1/g;->x:LC1/f;

    .line 16
    .line 17
    const/high16 v1, 0x3f800000    # 1.0f

    .line 18
    .line 19
    iput v1, v0, LC1/f;->d:F

    .line 20
    .line 21
    iput v1, v0, LC1/f;->e:F

    .line 22
    .line 23
    const-wide v3, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    iput-wide v3, v0, LC1/f;->f:J

    .line 29
    .line 30
    sget-object v1, LT0/o;->d:LT0/o;

    .line 31
    .line 32
    iput-object v1, v0, LC1/f;->g:LT0/o;

    .line 33
    .line 34
    const/4 v1, 0x0

    .line 35
    iput v1, v0, LC1/f;->h:F

    .line 36
    .line 37
    iput-object v2, v0, LC1/f;->i:Landroid/graphics/RenderEffect;

    .line 38
    .line 39
    iget-object v0, v0, LC1/f;->j:LC1/j;

    .line 40
    .line 41
    iget-object v0, v0, LC1/j;->d:Ljava/util/LinkedHashMap;

    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, LC1/g;->A:LI/m0;

    .line 47
    .line 48
    invoke-virtual {v0, v2}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

.method public final O(Lw0/b0;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Lw0/b0;->h1()LW/p;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v0, v0, LW/p;->q:Z

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, LC1/g;->r:LC1/a;

    .line 10
    .line 11
    invoke-interface {v0}, LC1/a;->a()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    iget-object v1, p0, LC1/g;->A:LI/m0;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v1, p1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v1}, LI/m0;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lu0/r;

    .line 28
    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    const/4 p1, 0x0

    .line 32
    invoke-virtual {v1, p1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    :goto_0
    return-void
.end method

.method public final U(Lw0/G;)V
    .locals 8

    .line 1
    iget-object v0, p0, LC1/g;->x:LC1/f;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v1, p1, Lw0/G;->d:Lf0/b;

    .line 7
    .line 8
    invoke-virtual {v1}, Lf0/b;->g()F

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    invoke-virtual {v1}, Lf0/b;->z()F

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    invoke-interface {v1}, Lf0/d;->a()J

    .line 17
    .line 18
    .line 19
    move-result-wide v4

    .line 20
    invoke-virtual {p1}, Lw0/G;->getLayoutDirection()LT0/o;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget v6, v0, LC1/f;->d:F

    .line 25
    .line 26
    cmpg-float v6, v2, v6

    .line 27
    .line 28
    if-nez v6, :cond_1

    .line 29
    .line 30
    iget v6, v0, LC1/f;->e:F

    .line 31
    .line 32
    cmpg-float v6, v3, v6

    .line 33
    .line 34
    if-nez v6, :cond_1

    .line 35
    .line 36
    iget-wide v6, v0, LC1/f;->f:J

    .line 37
    .line 38
    invoke-static {v4, v5, v6, v7}, Lc0/e;->a(JJ)Z

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    if-eqz v6, :cond_1

    .line 43
    .line 44
    iget-object v6, v0, LC1/f;->g:LT0/o;

    .line 45
    .line 46
    if-eq v1, v6, :cond_0

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    const/4 v6, 0x0

    .line 50
    goto :goto_1

    .line 51
    :cond_1
    :goto_0
    const/4 v6, 0x1

    .line 52
    :goto_1
    if-eqz v6, :cond_2

    .line 53
    .line 54
    iput v2, v0, LC1/f;->d:F

    .line 55
    .line 56
    iput v3, v0, LC1/f;->e:F

    .line 57
    .line 58
    iput-wide v4, v0, LC1/f;->f:J

    .line 59
    .line 60
    const-string v2, "<set-?>"

    .line 61
    .line 62
    invoke-static {v1, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    iput-object v1, v0, LC1/f;->g:LT0/o;

    .line 66
    .line 67
    :cond_2
    if-eqz v6, :cond_3

    .line 68
    .line 69
    invoke-virtual {p0}, LC1/g;->U0()V

    .line 70
    .line 71
    .line 72
    :cond_3
    iget-object v0, p0, LC1/g;->D:LC1/d;

    .line 73
    .line 74
    invoke-virtual {v0, p1}, LC1/d;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    iget-object v0, p0, LC1/g;->w:LU1/c;

    .line 78
    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    :cond_4
    invoke-virtual {p1}, Lw0/G;->c()V

    .line 85
    .line 86
    .line 87
    return-void
.end method

.method public final U0()V
    .locals 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1f

    .line 4
    .line 5
    if-lt v0, v1, :cond_2

    .line 6
    .line 7
    iget-object v0, p0, LC1/g;->t:LU1/c;

    .line 8
    .line 9
    iget-object v1, p0, LC1/g;->x:LC1/f;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const-string v2, "effects"

    .line 15
    .line 16
    invoke-static {v0, v2}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    iput v2, v1, LC1/f;->h:F

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    iput-object v2, v1, LC1/f;->i:Landroid/graphics/RenderEffect;

    .line 24
    .line 25
    invoke-interface {v0, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    iget-object v0, p0, LC1/g;->y:Lg0/c;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    iget-object v3, v1, LC1/f;->i:Landroid/graphics/RenderEffect;

    .line 33
    .line 34
    if-eqz v3, :cond_0

    .line 35
    .line 36
    new-instance v2, Ld0/m;

    .line 37
    .line 38
    invoke-direct {v2, v3}, Ld0/m;-><init>(Landroid/graphics/RenderEffect;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    iget-object v0, v0, Lg0/c;->a:Lg0/e;

    .line 42
    .line 43
    invoke-interface {v0}, Lg0/e;->j()LV/b;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-static {v3, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    if-nez v3, :cond_1

    .line 52
    .line 53
    invoke-interface {v0, v2}, Lg0/e;->I(LV/b;)V

    .line 54
    .line 55
    .line 56
    :cond_1
    iget v0, v1, LC1/f;->h:F

    .line 57
    .line 58
    iget-object v1, p0, LC1/g;->B:LI/i0;

    .line 59
    .line 60
    invoke-virtual {v1, v0}, LI/i0;->h(F)V

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void
.end method

.method public final X()V
    .locals 2

    .line 1
    new-instance v0, LA1/P;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0}, Lw0/j;->p(LW/p;LU1/a;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final j(Lu0/B;Lu0/y;J)Lu0/A;
    .locals 2

    .line 1
    const-string v0, "measurable"

    .line 2
    .line 3
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p2, p3, p4}, Lu0/y;->v(J)Lu0/L;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    iget p3, p2, Lu0/L;->d:I

    .line 11
    .line 12
    iget p4, p2, Lu0/L;->e:I

    .line 13
    .line 14
    new-instance v0, LC1/e;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-direct {v0, v1, p2, p0}, LC1/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    sget-object p2, LK1/u;->d:LK1/u;

    .line 21
    .line 22
    invoke-interface {p1, p3, p4, p2, v0}, Lu0/B;->D0(IILjava/util/Map;LU1/c;)Lu0/A;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    return-object p1
.end method
