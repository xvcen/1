.class public final LC1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld0/E;


# instance fields
.field public d:J

.field public e:F

.field public f:F

.field public g:F

.field public h:F


# virtual methods
.method public final G()V
    .locals 0

    .line 1
    return-void
.end method

.method public final Z(J)V
    .locals 0

    .line 1
    return-void
.end method

.method public final a()J
    .locals 2

    .line 1
    iget-wide v0, p0, LC1/h;->d:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final a0(Ld0/T;)V
    .locals 1

    .line 1
    const-string v0, "<set-?>"

    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final b(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final c(LA0/h;LT0/c;LU1/c;)V
    .locals 3

    .line 1
    const-string v0, "density"

    .line 2
    .line 3
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "layerBlock"

    .line 7
    .line 8
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p1, LA0/h;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, LI/e0;

    .line 14
    .line 15
    invoke-virtual {v0}, LI/e0;->t()J

    .line 16
    .line 17
    .line 18
    move-result-wide v0

    .line 19
    iput-wide v0, p0, LC1/h;->d:J

    .line 20
    .line 21
    invoke-interface {p2}, LT0/c;->g()F

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    iput v0, p0, LC1/h;->e:F

    .line 26
    .line 27
    invoke-interface {p2}, LT0/c;->z()F

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    iput p2, p0, LC1/h;->f:F

    .line 32
    .line 33
    invoke-interface {p3, p0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    iget p2, p0, LC1/h;->g:F

    .line 37
    .line 38
    iget p3, p0, LC1/h;->h:F

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    cmpg-float v1, p2, v0

    .line 42
    .line 43
    if-nez v1, :cond_0

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    cmpg-float v0, p3, v0

    .line 47
    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    :goto_0
    return-void

    .line 51
    :cond_1
    const/high16 v0, 0x3f800000    # 1.0f

    .line 52
    .line 53
    div-float p2, v0, p2

    .line 54
    .line 55
    div-float/2addr v0, p3

    .line 56
    const-wide/16 v1, 0x0

    .line 57
    .line 58
    invoke-virtual {p1, p2, v0, v1, v2}, LA0/h;->r(FFJ)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method public final d(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final e()F
    .locals 1

    .line 1
    iget v0, p0, LC1/h;->g:F

    .line 2
    .line 3
    return v0
.end method

.method public final f(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final g()F
    .locals 1

    .line 1
    iget v0, p0, LC1/h;->e:F

    .line 2
    .line 3
    return v0
.end method

.method public final h(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final i(J)V
    .locals 0

    .line 1
    return-void
.end method

.method public final k()V
    .locals 0

    .line 1
    return-void
.end method

.method public final k0(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final l(F)V
    .locals 0

    .line 1
    iput p1, p0, LC1/h;->g:F

    .line 2
    .line 3
    return-void
.end method

.method public final m(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final n(Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public final o()V
    .locals 0

    .line 1
    return-void
.end method

.method public final p(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final q(J)V
    .locals 0

    .line 1
    return-void
.end method

.method public final r(F)V
    .locals 0

    .line 1
    iput p1, p0, LC1/h;->h:F

    .line 2
    .line 3
    return-void
.end method

.method public final s(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final t()F
    .locals 1

    .line 1
    iget v0, p0, LC1/h;->h:F

    .line 2
    .line 3
    return v0
.end method

.method public final u(F)V
    .locals 0

    .line 1
    return-void
.end method

.method public final z()F
    .locals 1

    .line 1
    iget v0, p0, LC1/h;->f:F

    .line 2
    .line 3
    return v0
.end method
