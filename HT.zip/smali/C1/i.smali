.class public interface abstract LC1/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/RuntimeShader;
.end method
