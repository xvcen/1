.class public final LC1/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld0/T;


# instance fields
.field public final synthetic a:LC1/l;


# direct methods
.method public constructor <init>(LC1/l;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC1/k;->a:LC1/l;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(JLT0/o;LT0/c;)Ld0/D;
    .locals 4

    .line 1
    const-string v0, "layoutDirection"

    .line 2
    .line 3
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "density"

    .line 7
    .line 8
    invoke-static {p4, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LC1/k;->a:LC1/l;

    .line 12
    .line 13
    iget-object v1, v0, LC1/l;->a:LU1/a;

    .line 14
    .line 15
    invoke-interface {v1}, LU1/a;->a()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ld0/T;

    .line 20
    .line 21
    iget-object v2, v0, LC1/l;->b:Ld0/T;

    .line 22
    .line 23
    invoke-static {v2, v1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-nez v2, :cond_0

    .line 28
    .line 29
    iput-object v1, v0, LC1/l;->b:Ld0/T;

    .line 30
    .line 31
    const/4 v2, 0x0

    .line 32
    iput-object v2, v0, LC1/l;->c:Ld0/D;

    .line 33
    .line 34
    :cond_0
    iget-object v2, v0, LC1/l;->c:Ld0/D;

    .line 35
    .line 36
    if-eqz v2, :cond_1

    .line 37
    .line 38
    iget-wide v2, v0, LC1/l;->d:J

    .line 39
    .line 40
    invoke-static {v2, v3, p1, p2}, Lc0/e;->a(JJ)Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    iget-object v2, v0, LC1/l;->e:LT0/o;

    .line 47
    .line 48
    if-ne v2, p3, :cond_1

    .line 49
    .line 50
    iget-object v2, v0, LC1/l;->f:Ljava/lang/Float;

    .line 51
    .line 52
    invoke-interface {p4}, LT0/c;->g()F

    .line 53
    .line 54
    .line 55
    move-result v3

    .line 56
    if-eqz v2, :cond_1

    .line 57
    .line 58
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    cmpl-float v2, v2, v3

    .line 63
    .line 64
    if-nez v2, :cond_1

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_1
    iput-wide p1, v0, LC1/l;->d:J

    .line 68
    .line 69
    iput-object p3, v0, LC1/l;->e:LT0/o;

    .line 70
    .line 71
    invoke-interface {p4}, LT0/c;->g()F

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    iput-object v2, v0, LC1/l;->f:Ljava/lang/Float;

    .line 80
    .line 81
    invoke-interface {v1, p1, p2, p3, p4}, Ld0/T;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    iput-object p1, v0, LC1/l;->c:Ld0/D;

    .line 86
    .line 87
    :goto_0
    iget-object p1, v0, LC1/l;->c:Ld0/D;

    .line 88
    .line 89
    invoke-static {p1}, LV1/i;->b(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    return-object p1
.end method
