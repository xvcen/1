.class public final LC1/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LU1/a;

.field public b:Ld0/T;

.field public c:Ld0/D;

.field public d:J

.field public e:LT0/o;

.field public f:Ljava/lang/Float;

.field public final g:LC1/k;


# direct methods
.method public constructor <init>(LU1/a;)V
    .locals 2

    .line 1
    const-string v0, "shapeBlock"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LC1/l;->a:LU1/a;

    .line 10
    .line 11
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    iput-wide v0, p0, LC1/l;->d:J

    .line 17
    .line 18
    new-instance p1, LC1/k;

    .line 19
    .line 20
    invoke-direct {p1, p0}, LC1/k;-><init>(LC1/l;)V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, LC1/l;->g:LC1/k;

    .line 24
    .line 25
    return-void
.end method
