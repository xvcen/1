.class public final synthetic LD/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LW/q;

.field public final synthetic e:LI/b0;

.field public final synthetic f:LQ/f;

.field public final synthetic g:LD/c;


# direct methods
.method public synthetic constructor <init>(LW/q;LI/b0;LQ/f;LD/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/d;->d:LW/q;

    iput-object p2, p0, LD/d;->e:LI/b0;

    iput-object p3, p0, LD/d;->f:LQ/f;

    iput-object p4, p0, LD/d;->g:LD/c;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    check-cast p1, LI/r;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x1

    .line 14
    if-eq v0, v1, :cond_0

    .line 15
    .line 16
    move v0, v3

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move v0, v2

    .line 19
    :goto_0
    and-int/2addr p2, v3

    .line 20
    invoke-virtual {p1, p2, v0}, LI/r;->N(IZ)Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    if-eqz p2, :cond_4

    .line 25
    .line 26
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    iget-object v0, p0, LD/d;->e:LI/b0;

    .line 31
    .line 32
    sget-object v1, LI/m;->a:LI/h;

    .line 33
    .line 34
    if-ne p2, v1, :cond_1

    .line 35
    .line 36
    new-instance p2, LA1/a;

    .line 37
    .line 38
    const/4 v4, 0x7

    .line 39
    invoke-direct {p2, v0, v4}, LA1/a;-><init>(LI/b0;I)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1, p2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_1
    check-cast p2, LU1/c;

    .line 46
    .line 47
    iget-object v4, p0, LD/d;->d:LW/q;

    .line 48
    .line 49
    invoke-static {v4, p2}, Lu0/v;->h(LW/q;LU1/c;)LW/q;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    sget-object v4, LW/c;->d:LW/h;

    .line 54
    .line 55
    invoke-static {v4, v3}, Ls/j;->d(LW/h;Z)Lu0/z;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    iget-wide v5, p1, LI/r;->R:J

    .line 60
    .line 61
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    invoke-virtual {p1}, LI/r;->k()LI/q0;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    invoke-static {p1, p2}, LW/a;->c(LI/r;LW/q;)LW/q;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    sget-object v7, Lw0/f;->c:Lw0/e;

    .line 74
    .line 75
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 76
    .line 77
    .line 78
    sget-object v7, Lw0/e;->b:Lw0/x;

    .line 79
    .line 80
    invoke-virtual {p1}, LI/r;->W()V

    .line 81
    .line 82
    .line 83
    iget-boolean v8, p1, LI/r;->Q:Z

    .line 84
    .line 85
    if-eqz v8, :cond_2

    .line 86
    .line 87
    invoke-virtual {p1, v7}, LI/r;->j(LU1/a;)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_2
    invoke-virtual {p1}, LI/r;->g0()V

    .line 92
    .line 93
    .line 94
    :goto_1
    sget-object v7, Lw0/e;->e:Lw0/d;

    .line 95
    .line 96
    invoke-static {p1, v7, v4}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    sget-object v4, Lw0/e;->d:Lw0/d;

    .line 100
    .line 101
    invoke-static {p1, v4, v6}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    sget-object v5, Lw0/e;->f:Lw0/d;

    .line 109
    .line 110
    invoke-static {p1, v4, v5}, LI/k;->o(LI/r;Ljava/lang/Integer;LU1/e;)V

    .line 111
    .line 112
    .line 113
    sget-object v4, Lw0/e;->g:Lw0/c;

    .line 114
    .line 115
    invoke-static {p1, v4}, LI/k;->s(LI/r;LU1/c;)V

    .line 116
    .line 117
    .line 118
    sget-object v4, Lw0/e;->c:Lw0/d;

    .line 119
    .line 120
    invoke-static {p1, v4, p2}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 124
    .line 125
    .line 126
    move-result-object p2

    .line 127
    iget-object v2, p0, LD/d;->f:LQ/f;

    .line 128
    .line 129
    invoke-virtual {v2, p1, p2}, LQ/f;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p2

    .line 136
    if-ne p2, v1, :cond_3

    .line 137
    .line 138
    new-instance p2, LA1/t;

    .line 139
    .line 140
    const/4 v1, 0x3

    .line 141
    invoke-direct {p2, v0, v1}, LA1/t;-><init>(LI/b0;I)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p1, p2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :cond_3
    check-cast p2, LU1/a;

    .line 148
    .line 149
    const/4 v0, 0x6

    .line 150
    iget-object v1, p0, LD/d;->g:LD/c;

    .line 151
    .line 152
    invoke-virtual {v1, p2, p1, v0}, LD/c;->b(LU1/a;LI/r;I)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {p1, v3}, LI/r;->p(Z)V

    .line 156
    .line 157
    .line 158
    goto :goto_2

    .line 159
    :cond_4
    invoke-virtual {p1}, LI/r;->Q()V

    .line 160
    .line 161
    .line 162
    :goto_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 163
    .line 164
    return-object p1
.end method
