.class public interface abstract LD/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LD/e;LP1/i;)Ljava/lang/Object;
.end method
