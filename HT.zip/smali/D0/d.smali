.class public final LD0/d;
.super LP1/c;
.source "SourceFile"


# instance fields
.field public g:Ljava/lang/Object;

.field public h:LT0/m;

.field public i:I

.field public j:I

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:LD0/g;

.field public m:I


# direct methods
.method public constructor <init>(LD0/g;LP1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LD0/d;->l:LD0/g;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LP1/c;-><init>(LN1/c;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LD0/d;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LD0/d;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LD0/d;->m:I

    .line 9
    .line 10
    iget-object p1, p0, LD0/d;->l:LD0/g;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0, v0, p0}, LD0/g;->a(LD0/g;Landroid/view/ScrollCaptureSession;LT0/m;LP1/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
