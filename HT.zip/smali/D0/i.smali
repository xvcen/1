.class public final LD0/i;
.super LV1/j;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LD0/i;->e:I

    iput-object p2, p0, LD0/i;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, LV1/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget v2, v1, LD0/i;->e:I

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x0

    .line 9
    const/4 v5, 0x0

    .line 10
    sget-object v6, LJ1/m;->a:LJ1/m;

    .line 11
    .line 12
    iget-object v7, v1, LD0/i;->f:Ljava/lang/Object;

    .line 13
    .line 14
    packed-switch v2, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast v0, LM0/l;

    .line 18
    .line 19
    iget-object v2, v0, LM0/l;->b:LF/A;

    .line 20
    .line 21
    if-eqz v2, :cond_0

    .line 22
    .line 23
    invoke-virtual {v0, v2}, LM0/l;->a(LF/A;)V

    .line 24
    .line 25
    .line 26
    iput-object v4, v0, LM0/l;->b:LF/A;

    .line 27
    .line 28
    :cond_0
    check-cast v7, Lx0/s0;

    .line 29
    .line 30
    iget-object v2, v7, Lx0/s0;->d:LK/e;

    .line 31
    .line 32
    iget-object v3, v2, LK/e;->d:[Ljava/lang/Object;

    .line 33
    .line 34
    iget v4, v2, LK/e;->f:I

    .line 35
    .line 36
    :goto_0
    if-ge v5, v4, :cond_2

    .line 37
    .line 38
    aget-object v8, v3, v5

    .line 39
    .line 40
    check-cast v8, Lw0/z0;

    .line 41
    .line 42
    invoke-static {v8, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v8

    .line 46
    if-eqz v8, :cond_1

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_1
    add-int/lit8 v5, v5, 0x1

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_2
    const/4 v5, -0x1

    .line 53
    :goto_1
    if-ltz v5, :cond_3

    .line 54
    .line 55
    invoke-virtual {v2, v5}, LK/e;->j(I)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    :cond_3
    iget v0, v2, LK/e;->f:I

    .line 59
    .line 60
    if-nez v0, :cond_4

    .line 61
    .line 62
    iget-object v0, v7, Lx0/s0;->b:LF0/b;

    .line 63
    .line 64
    invoke-virtual {v0}, LF0/b;->a()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    :cond_4
    return-object v6

    .line 68
    :pswitch_0
    check-cast v0, Lf0/d;

    .line 69
    .line 70
    check-cast v7, Lx0/o0;

    .line 71
    .line 72
    invoke-interface {v0}, Lf0/d;->Q()LI/e0;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    invoke-virtual {v2}, LI/e0;->m()Ld0/u;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    iget-object v3, v7, Lx0/o0;->g:LU1/e;

    .line 81
    .line 82
    if-eqz v3, :cond_5

    .line 83
    .line 84
    invoke-interface {v0}, Lf0/d;->Q()LI/e0;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    iget-object v0, v0, LI/e0;->e:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, Lg0/c;

    .line 91
    .line 92
    invoke-interface {v3, v2, v0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    :cond_5
    return-object v6

    .line 96
    :pswitch_1
    sget-object v0, Lx0/n0;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 97
    .line 98
    invoke-virtual {v0, v5, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    if-eqz v0, :cond_6

    .line 103
    .line 104
    check-cast v7, Le2/c;

    .line 105
    .line 106
    invoke-interface {v7, v6}, Le2/r;->q(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    :cond_6
    return-object v6

    .line 110
    :pswitch_2
    check-cast v0, LI/I;

    .line 111
    .line 112
    check-cast v7, Lx0/k0;

    .line 113
    .line 114
    new-instance v0, LB/l;

    .line 115
    .line 116
    const/4 v2, 0x6

    .line 117
    invoke-direct {v0, v2, v7}, LB/l;-><init>(ILjava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    return-object v0

    .line 121
    :pswitch_3
    check-cast v0, LE0/n;

    .line 122
    .line 123
    check-cast v7, Landroid/content/res/Resources;

    .line 124
    .line 125
    invoke-static {v0, v7}, Lx0/E;->b(LE0/n;Landroid/content/res/Resources;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    return-object v0

    .line 134
    :pswitch_4
    check-cast v0, LE0/n;

    .line 135
    .line 136
    check-cast v7, Li/l;

    .line 137
    .line 138
    iget v0, v0, LE0/n;->g:I

    .line 139
    .line 140
    invoke-virtual {v7, v0}, Li/l;->a(I)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    return-object v0

    .line 149
    :pswitch_5
    move-object v2, v7

    .line 150
    move-object v7, v0

    .line 151
    check-cast v7, Lw0/I;

    .line 152
    .line 153
    move-object v0, v2

    .line 154
    check-cast v0, Lx0/k;

    .line 155
    .line 156
    iget-object v0, v0, Lx0/k;->s:Lx0/s;

    .line 157
    .line 158
    invoke-virtual {v0}, Lx0/s;->getInsetsListener()Lu0/l;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    iget-object v2, v2, Lu0/l;->j:LI/j0;

    .line 163
    .line 164
    invoke-virtual {v2}, LI/j0;->g()I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    if-lez v2, :cond_a

    .line 169
    .line 170
    sget-object v2, Lu0/V;->a:Li/x;

    .line 171
    .line 172
    iput-boolean v3, v7, Lw0/I;->d:Z

    .line 173
    .line 174
    iget-object v2, v7, Lw0/I;->g:Lw0/L;

    .line 175
    .line 176
    invoke-virtual {v2}, Lw0/L;->M0()Lu0/r;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    iget-wide v8, v7, Lw0/I;->e:J

    .line 181
    .line 182
    const-wide v10, 0x7fffffff7fffffffL

    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    invoke-static {v8, v9, v10, v11}, LT0/k;->a(JJ)Z

    .line 188
    .line 189
    .line 190
    move-result v4

    .line 191
    if-eqz v4, :cond_7

    .line 192
    .line 193
    const-wide/16 v8, 0x0

    .line 194
    .line 195
    invoke-interface {v3, v8, v9}, Lu0/r;->j(J)J

    .line 196
    .line 197
    .line 198
    move-result-wide v8

    .line 199
    invoke-static {v8, v9}, LT0/l;->K(J)J

    .line 200
    .line 201
    .line 202
    move-result-wide v8

    .line 203
    iput-wide v8, v7, Lw0/I;->e:J

    .line 204
    .line 205
    invoke-interface {v3}, Lu0/r;->e0()J

    .line 206
    .line 207
    .line 208
    move-result-wide v8

    .line 209
    iput-wide v8, v7, Lw0/I;->f:J

    .line 210
    .line 211
    :cond_7
    invoke-virtual {v2}, Lw0/L;->O0()Lw0/E;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    iget-object v2, v2, Lw0/E;->J:Lw0/H;

    .line 216
    .line 217
    invoke-virtual {v2}, Lw0/H;->b()V

    .line 218
    .line 219
    .line 220
    invoke-interface {v3}, Lu0/r;->e0()J

    .line 221
    .line 222
    .line 223
    move-result-wide v2

    .line 224
    invoke-virtual {v0}, Lx0/s;->getInsetsListener()Lu0/l;

    .line 225
    .line 226
    .line 227
    move-result-object v4

    .line 228
    iget-object v4, v4, Lu0/l;->i:Li/E;

    .line 229
    .line 230
    const/16 v8, 0x20

    .line 231
    .line 232
    shr-long v8, v2, v8

    .line 233
    .line 234
    long-to-int v11, v8

    .line 235
    const-wide v8, 0xffffffffL

    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    and-long/2addr v2, v8

    .line 241
    long-to-int v12, v2

    .line 242
    sget-object v2, Lu0/V;->b:[Lu0/T;

    .line 243
    .line 244
    array-length v3, v2

    .line 245
    move v13, v5

    .line 246
    :goto_2
    if-ge v13, v3, :cond_9

    .line 247
    .line 248
    aget-object v8, v2, v13

    .line 249
    .line 250
    invoke-virtual {v4, v8}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v9

    .line 254
    invoke-static {v9}, LV1/i;->b(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    move-object v14, v9

    .line 258
    check-cast v14, Lu0/W;

    .line 259
    .line 260
    move-object v15, v8

    .line 261
    check-cast v15, Lu0/U;

    .line 262
    .line 263
    iget-object v8, v15, Lu0/U;->c:Lu0/k;

    .line 264
    .line 265
    iget-wide v9, v14, Lu0/W;->h:J

    .line 266
    .line 267
    invoke-static/range {v7 .. v12}, Lu0/V;->a(Lw0/I;Lu0/k;JII)V

    .line 268
    .line 269
    .line 270
    iget-object v8, v14, Lu0/W;->b:LI/m0;

    .line 271
    .line 272
    invoke-virtual {v8}, LI/m0;->getValue()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v8

    .line 276
    check-cast v8, Ljava/lang/Boolean;

    .line 277
    .line 278
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 279
    .line 280
    .line 281
    move-result v8

    .line 282
    if-eqz v8, :cond_8

    .line 283
    .line 284
    iget-object v8, v14, Lu0/W;->f:Lu0/k;

    .line 285
    .line 286
    iget-wide v9, v14, Lu0/W;->j:J

    .line 287
    .line 288
    invoke-static/range {v7 .. v12}, Lu0/V;->a(Lw0/I;Lu0/k;JII)V

    .line 289
    .line 290
    .line 291
    iget-object v8, v14, Lu0/W;->g:Lu0/k;

    .line 292
    .line 293
    iget-wide v9, v14, Lu0/W;->k:J

    .line 294
    .line 295
    invoke-static/range {v7 .. v12}, Lu0/V;->a(Lw0/I;Lu0/k;JII)V

    .line 296
    .line 297
    .line 298
    :cond_8
    iget-object v8, v15, Lu0/U;->d:Lu0/k;

    .line 299
    .line 300
    iget-wide v9, v14, Lu0/W;->i:J

    .line 301
    .line 302
    invoke-static/range {v7 .. v12}, Lu0/V;->a(Lw0/I;Lu0/k;JII)V

    .line 303
    .line 304
    .line 305
    add-int/lit8 v13, v13, 0x1

    .line 306
    .line 307
    goto :goto_2

    .line 308
    :cond_9
    invoke-virtual {v0}, Lx0/s;->getInsetsListener()Lu0/l;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    iget-object v2, v2, Lu0/l;->k:Li/D;

    .line 313
    .line 314
    invoke-virtual {v2}, Li/D;->i()Z

    .line 315
    .line 316
    .line 317
    move-result v3

    .line 318
    if-eqz v3, :cond_a

    .line 319
    .line 320
    invoke-virtual {v0}, Lx0/s;->getInsetsListener()Lu0/l;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    iget-object v0, v0, Lu0/l;->l:LU/t;

    .line 325
    .line 326
    iget-object v3, v2, Li/D;->a:[Ljava/lang/Object;

    .line 327
    .line 328
    iget v2, v2, Li/D;->b:I

    .line 329
    .line 330
    :goto_3
    if-ge v5, v2, :cond_a

    .line 331
    .line 332
    aget-object v4, v3, v5

    .line 333
    .line 334
    check-cast v4, LI/b0;

    .line 335
    .line 336
    invoke-virtual {v0, v5}, LU/t;->get(I)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v8

    .line 340
    check-cast v8, Lu0/k;

    .line 341
    .line 342
    invoke-interface {v4}, LI/a1;->getValue()Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v4

    .line 346
    check-cast v4, Landroid/graphics/Rect;

    .line 347
    .line 348
    invoke-virtual {v8}, Lu0/k;->b()Lu0/j;

    .line 349
    .line 350
    .line 351
    move-result-object v9

    .line 352
    iget v10, v4, Landroid/graphics/Rect;->left:I

    .line 353
    .line 354
    int-to-float v10, v10

    .line 355
    invoke-virtual {v7, v9, v10}, Lw0/I;->c(Lu0/j;F)V

    .line 356
    .line 357
    .line 358
    invoke-virtual {v8}, Lu0/k;->d()Lu0/j;

    .line 359
    .line 360
    .line 361
    move-result-object v9

    .line 362
    iget v10, v4, Landroid/graphics/Rect;->top:I

    .line 363
    .line 364
    int-to-float v10, v10

    .line 365
    invoke-virtual {v7, v9, v10}, Lw0/I;->c(Lu0/j;F)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v8}, Lu0/k;->c()Lu0/j;

    .line 369
    .line 370
    .line 371
    move-result-object v9

    .line 372
    iget v10, v4, Landroid/graphics/Rect;->right:I

    .line 373
    .line 374
    int-to-float v10, v10

    .line 375
    invoke-virtual {v7, v9, v10}, Lw0/I;->c(Lu0/j;F)V

    .line 376
    .line 377
    .line 378
    invoke-virtual {v8}, Lu0/k;->a()Lu0/j;

    .line 379
    .line 380
    .line 381
    move-result-object v8

    .line 382
    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    .line 383
    .line 384
    int-to-float v4, v4

    .line 385
    invoke-virtual {v7, v8, v4}, Lw0/I;->c(Lu0/j;F)V

    .line 386
    .line 387
    .line 388
    add-int/lit8 v5, v5, 0x1

    .line 389
    .line 390
    goto :goto_3

    .line 391
    :cond_a
    return-object v6

    .line 392
    :pswitch_6
    move-object v2, v7

    .line 393
    check-cast v0, Lb0/y;

    .line 394
    .line 395
    move-object v7, v2

    .line 396
    check-cast v7, Lb0/e;

    .line 397
    .line 398
    iget v2, v7, Lb0/e;->a:I

    .line 399
    .line 400
    invoke-virtual {v0, v2}, Lb0/y;->b1(I)Z

    .line 401
    .line 402
    .line 403
    move-result v0

    .line 404
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    return-object v0

    .line 409
    :pswitch_7
    move-object v2, v7

    .line 410
    check-cast v0, LW/o;

    .line 411
    .line 412
    move-object v7, v2

    .line 413
    check-cast v7, LK/e;

    .line 414
    .line 415
    invoke-virtual {v7, v0}, LK/e;->b(Ljava/lang/Object;)V

    .line 416
    .line 417
    .line 418
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 419
    .line 420
    return-object v0

    .line 421
    :pswitch_8
    move-object v2, v7

    .line 422
    check-cast v0, Lw0/a;

    .line 423
    .line 424
    move-object v7, v2

    .line 425
    check-cast v7, Lw0/F;

    .line 426
    .line 427
    invoke-interface {v0}, Lw0/a;->l0()I

    .line 428
    .line 429
    .line 430
    move-result v2

    .line 431
    const v3, 0x7fffffff

    .line 432
    .line 433
    .line 434
    if-ne v2, v3, :cond_b

    .line 435
    .line 436
    goto/16 :goto_7

    .line 437
    .line 438
    :cond_b
    invoke-interface {v0}, Lw0/a;->c()Lw0/F;

    .line 439
    .line 440
    .line 441
    move-result-object v2

    .line 442
    iget-boolean v2, v2, Lw0/F;->b:Z

    .line 443
    .line 444
    if-eqz v2, :cond_c

    .line 445
    .line 446
    invoke-interface {v0}, Lw0/a;->P()V

    .line 447
    .line 448
    .line 449
    :cond_c
    invoke-interface {v0}, Lw0/a;->c()Lw0/F;

    .line 450
    .line 451
    .line 452
    move-result-object v2

    .line 453
    iget-object v2, v2, Lw0/F;->g:Ljava/util/HashMap;

    .line 454
    .line 455
    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 456
    .line 457
    .line 458
    move-result-object v2

    .line 459
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 460
    .line 461
    .line 462
    move-result-object v2

    .line 463
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 464
    .line 465
    .line 466
    move-result v3

    .line 467
    if-eqz v3, :cond_d

    .line 468
    .line 469
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 470
    .line 471
    .line 472
    move-result-object v3

    .line 473
    check-cast v3, Ljava/util/Map$Entry;

    .line 474
    .line 475
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v4

    .line 479
    check-cast v4, Lu0/h;

    .line 480
    .line 481
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v3

    .line 485
    check-cast v3, Ljava/lang/Number;

    .line 486
    .line 487
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 488
    .line 489
    .line 490
    move-result v3

    .line 491
    invoke-interface {v0}, Lw0/a;->J()Lw0/q;

    .line 492
    .line 493
    .line 494
    move-result-object v5

    .line 495
    invoke-static {v7, v4, v3, v5}, Lw0/F;->a(Lw0/F;Lu0/h;ILw0/b0;)V

    .line 496
    .line 497
    .line 498
    goto :goto_4

    .line 499
    :cond_d
    invoke-interface {v0}, Lw0/a;->J()Lw0/q;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    iget-object v0, v0, Lw0/b0;->t:Lw0/b0;

    .line 504
    .line 505
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 506
    .line 507
    .line 508
    :goto_5
    iget-object v2, v7, Lw0/F;->a:Lu0/L;

    .line 509
    .line 510
    invoke-interface {v2}, Lw0/a;->J()Lw0/q;

    .line 511
    .line 512
    .line 513
    move-result-object v2

    .line 514
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 515
    .line 516
    .line 517
    move-result v2

    .line 518
    if-nez v2, :cond_f

    .line 519
    .line 520
    invoke-virtual {v7, v0}, Lw0/F;->b(Lw0/b0;)Ljava/util/Map;

    .line 521
    .line 522
    .line 523
    move-result-object v2

    .line 524
    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 525
    .line 526
    .line 527
    move-result-object v2

    .line 528
    check-cast v2, Ljava/lang/Iterable;

    .line 529
    .line 530
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 531
    .line 532
    .line 533
    move-result-object v2

    .line 534
    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 535
    .line 536
    .line 537
    move-result v3

    .line 538
    if-eqz v3, :cond_e

    .line 539
    .line 540
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 541
    .line 542
    .line 543
    move-result-object v3

    .line 544
    check-cast v3, Lu0/h;

    .line 545
    .line 546
    invoke-virtual {v7, v0, v3}, Lw0/F;->c(Lw0/b0;Lu0/h;)I

    .line 547
    .line 548
    .line 549
    move-result v4

    .line 550
    invoke-static {v7, v3, v4, v0}, Lw0/F;->a(Lw0/F;Lu0/h;ILw0/b0;)V

    .line 551
    .line 552
    .line 553
    goto :goto_6

    .line 554
    :cond_e
    iget-object v0, v0, Lw0/b0;->t:Lw0/b0;

    .line 555
    .line 556
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 557
    .line 558
    .line 559
    goto :goto_5

    .line 560
    :cond_f
    :goto_7
    return-object v6

    .line 561
    :pswitch_9
    move-object v2, v7

    .line 562
    check-cast v0, Ljava/lang/Throwable;

    .line 563
    .line 564
    move-object v7, v2

    .line 565
    check-cast v7, Lq0/I;

    .line 566
    .line 567
    iget-object v2, v7, Lq0/I;->f:Lc2/g;

    .line 568
    .line 569
    if-eqz v2, :cond_10

    .line 570
    .line 571
    invoke-virtual {v2, v0}, Lc2/g;->w(Ljava/lang/Throwable;)Z

    .line 572
    .line 573
    .line 574
    :cond_10
    iput-object v4, v7, Lq0/I;->f:Lc2/g;

    .line 575
    .line 576
    return-object v6

    .line 577
    :pswitch_a
    move-object v2, v7

    .line 578
    invoke-static {v0, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 579
    .line 580
    .line 581
    move-result v0

    .line 582
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 583
    .line 584
    .line 585
    move-result-object v0

    .line 586
    return-object v0

    .line 587
    :pswitch_b
    move-object v2, v7

    .line 588
    check-cast v0, Lj0/B;

    .line 589
    .line 590
    move-object v7, v2

    .line 591
    check-cast v7, Lj0/c;

    .line 592
    .line 593
    invoke-virtual {v7, v0}, Lj0/c;->g(Lj0/B;)V

    .line 594
    .line 595
    .line 596
    iget-object v2, v7, Lj0/c;->i:LU1/c;

    .line 597
    .line 598
    if-eqz v2, :cond_11

    .line 599
    .line 600
    invoke-interface {v2, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    :cond_11
    return-object v6

    .line 604
    :pswitch_c
    move-object v2, v7

    .line 605
    check-cast v0, Lf0/d;

    .line 606
    .line 607
    move-object v7, v2

    .line 608
    check-cast v7, Lg0/c;

    .line 609
    .line 610
    iget-object v2, v7, Lg0/c;->l:Ld0/j;

    .line 611
    .line 612
    iget-boolean v3, v7, Lg0/c;->n:Z

    .line 613
    .line 614
    if-eqz v3, :cond_12

    .line 615
    .line 616
    iget-boolean v3, v7, Lg0/c;->w:Z

    .line 617
    .line 618
    if-eqz v3, :cond_12

    .line 619
    .line 620
    if-eqz v2, :cond_12

    .line 621
    .line 622
    invoke-interface {v0}, Lf0/d;->Q()LI/e0;

    .line 623
    .line 624
    .line 625
    move-result-object v3

    .line 626
    invoke-virtual {v3}, LI/e0;->t()J

    .line 627
    .line 628
    .line 629
    move-result-wide v4

    .line 630
    invoke-virtual {v3}, LI/e0;->m()Ld0/u;

    .line 631
    .line 632
    .line 633
    move-result-object v8

    .line 634
    invoke-interface {v8}, Ld0/u;->k()V

    .line 635
    .line 636
    .line 637
    :try_start_0
    iget-object v8, v3, LI/e0;->d:Ljava/lang/Object;

    .line 638
    .line 639
    check-cast v8, LA0/h;

    .line 640
    .line 641
    iget-object v8, v8, LA0/h;->e:Ljava/lang/Object;

    .line 642
    .line 643
    check-cast v8, LI/e0;

    .line 644
    .line 645
    invoke-virtual {v8}, LI/e0;->m()Ld0/u;

    .line 646
    .line 647
    .line 648
    move-result-object v8

    .line 649
    invoke-interface {v8, v2}, Ld0/u;->d(Ld0/j;)V

    .line 650
    .line 651
    .line 652
    invoke-virtual {v7, v0}, Lg0/c;->c(Lf0/d;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 653
    .line 654
    .line 655
    invoke-virtual {v3}, LI/e0;->m()Ld0/u;

    .line 656
    .line 657
    .line 658
    move-result-object v0

    .line 659
    invoke-interface {v0}, Ld0/u;->i()V

    .line 660
    .line 661
    .line 662
    invoke-virtual {v3, v4, v5}, LI/e0;->E(J)V

    .line 663
    .line 664
    .line 665
    goto :goto_8

    .line 666
    :catchall_0
    move-exception v0

    .line 667
    invoke-virtual {v3}, LI/e0;->m()Ld0/u;

    .line 668
    .line 669
    .line 670
    move-result-object v2

    .line 671
    invoke-interface {v2}, Ld0/u;->i()V

    .line 672
    .line 673
    .line 674
    invoke-virtual {v3, v4, v5}, LI/e0;->E(J)V

    .line 675
    .line 676
    .line 677
    throw v0

    .line 678
    :cond_12
    invoke-virtual {v7, v0}, Lg0/c;->c(Lf0/d;)V

    .line 679
    .line 680
    .line 681
    :goto_8
    return-object v6

    .line 682
    :pswitch_d
    move-object v2, v7

    .line 683
    check-cast v0, Ld0/E;

    .line 684
    .line 685
    move-object v7, v2

    .line 686
    check-cast v7, Ld0/U;

    .line 687
    .line 688
    iget v2, v7, Ld0/U;->r:F

    .line 689
    .line 690
    invoke-interface {v0, v2}, Ld0/E;->l(F)V

    .line 691
    .line 692
    .line 693
    iget v2, v7, Ld0/U;->s:F

    .line 694
    .line 695
    invoke-interface {v0, v2}, Ld0/E;->r(F)V

    .line 696
    .line 697
    .line 698
    iget v2, v7, Ld0/U;->t:F

    .line 699
    .line 700
    invoke-interface {v0, v2}, Ld0/E;->d(F)V

    .line 701
    .line 702
    .line 703
    const/4 v2, 0x0

    .line 704
    invoke-interface {v0, v2}, Ld0/E;->p(F)V

    .line 705
    .line 706
    .line 707
    invoke-interface {v0, v2}, Ld0/E;->h(F)V

    .line 708
    .line 709
    .line 710
    invoke-interface {v0, v2}, Ld0/E;->f(F)V

    .line 711
    .line 712
    .line 713
    invoke-interface {v0, v2}, Ld0/E;->u(F)V

    .line 714
    .line 715
    .line 716
    invoke-interface {v0, v2}, Ld0/E;->b(F)V

    .line 717
    .line 718
    .line 719
    invoke-interface {v0}, Ld0/E;->o()V

    .line 720
    .line 721
    .line 722
    iget v2, v7, Ld0/U;->u:F

    .line 723
    .line 724
    invoke-interface {v0, v2}, Ld0/E;->s(F)V

    .line 725
    .line 726
    .line 727
    iget-wide v2, v7, Ld0/U;->v:J

    .line 728
    .line 729
    invoke-interface {v0, v2, v3}, Ld0/E;->Z(J)V

    .line 730
    .line 731
    .line 732
    iget-object v2, v7, Ld0/U;->w:Ld0/T;

    .line 733
    .line 734
    invoke-interface {v0, v2}, Ld0/E;->a0(Ld0/T;)V

    .line 735
    .line 736
    .line 737
    iget-boolean v2, v7, Ld0/U;->x:Z

    .line 738
    .line 739
    invoke-interface {v0, v2}, Ld0/E;->n(Z)V

    .line 740
    .line 741
    .line 742
    invoke-interface {v0}, Ld0/E;->G()V

    .line 743
    .line 744
    .line 745
    iget-wide v2, v7, Ld0/U;->y:J

    .line 746
    .line 747
    invoke-interface {v0, v2, v3}, Ld0/E;->i(J)V

    .line 748
    .line 749
    .line 750
    iget-wide v2, v7, Ld0/U;->z:J

    .line 751
    .line 752
    invoke-interface {v0, v2, v3}, Ld0/E;->q(J)V

    .line 753
    .line 754
    .line 755
    invoke-interface {v0, v5}, Ld0/E;->k0(I)V

    .line 756
    .line 757
    .line 758
    iget v2, v7, Ld0/U;->A:I

    .line 759
    .line 760
    invoke-interface {v0, v2}, Ld0/E;->m(I)V

    .line 761
    .line 762
    .line 763
    invoke-interface {v0}, Ld0/E;->k()V

    .line 764
    .line 765
    .line 766
    return-object v6

    .line 767
    :pswitch_e
    move-object v2, v7

    .line 768
    check-cast v0, Ld0/E;

    .line 769
    .line 770
    move-object v7, v2

    .line 771
    check-cast v7, La0/n;

    .line 772
    .line 773
    sget v2, Lo/g;->d:F

    .line 774
    .line 775
    invoke-interface {v0}, LT0/c;->g()F

    .line 776
    .line 777
    .line 778
    move-result v3

    .line 779
    mul-float/2addr v3, v2

    .line 780
    invoke-interface {v0, v3}, Ld0/E;->f(F)V

    .line 781
    .line 782
    .line 783
    iget-object v2, v7, La0/n;->a:Ld0/T;

    .line 784
    .line 785
    invoke-interface {v0, v2}, Ld0/E;->a0(Ld0/T;)V

    .line 786
    .line 787
    .line 788
    iget-boolean v2, v7, La0/n;->b:Z

    .line 789
    .line 790
    invoke-interface {v0, v2}, Ld0/E;->n(Z)V

    .line 791
    .line 792
    .line 793
    iget-wide v2, v7, La0/n;->c:J

    .line 794
    .line 795
    invoke-interface {v0, v2, v3}, Ld0/E;->i(J)V

    .line 796
    .line 797
    .line 798
    iget-wide v2, v7, La0/n;->d:J

    .line 799
    .line 800
    invoke-interface {v0, v2, v3}, Ld0/E;->q(J)V

    .line 801
    .line 802
    .line 803
    return-object v6

    .line 804
    :pswitch_f
    move-object v2, v7

    .line 805
    check-cast v0, LZ/g;

    .line 806
    .line 807
    iget-object v3, v0, LW/p;->d:LW/p;

    .line 808
    .line 809
    iget-boolean v3, v3, LW/p;->q:Z

    .line 810
    .line 811
    if-nez v3, :cond_13

    .line 812
    .line 813
    sget-object v0, Lw0/x0;->e:Lw0/x0;

    .line 814
    .line 815
    goto :goto_a

    .line 816
    :cond_13
    iget-object v3, v0, LZ/g;->s:LZ/g;

    .line 817
    .line 818
    sget-object v5, Lw0/x0;->d:Lw0/x0;

    .line 819
    .line 820
    if-eqz v3, :cond_15

    .line 821
    .line 822
    move-object v7, v2

    .line 823
    check-cast v7, LA0/h;

    .line 824
    .line 825
    new-instance v2, LD0/i;

    .line 826
    .line 827
    const/4 v6, 0x3

    .line 828
    invoke-direct {v2, v6, v7}, LD0/i;-><init>(ILjava/lang/Object;)V

    .line 829
    .line 830
    .line 831
    invoke-virtual {v2, v3}, LD0/i;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 832
    .line 833
    .line 834
    move-result-object v6

    .line 835
    if-eq v6, v5, :cond_14

    .line 836
    .line 837
    goto :goto_9

    .line 838
    :cond_14
    invoke-static {v3, v2}, Lw0/j;->A(Lw0/y0;LU1/c;)V

    .line 839
    .line 840
    .line 841
    :cond_15
    :goto_9
    iput-object v4, v0, LZ/g;->s:LZ/g;

    .line 842
    .line 843
    iput-object v4, v0, LZ/g;->r:LZ/g;

    .line 844
    .line 845
    move-object v0, v5

    .line 846
    :goto_a
    return-object v0

    .line 847
    :pswitch_10
    move-object v2, v7

    .line 848
    check-cast v0, LE0/v;

    .line 849
    .line 850
    move-object v7, v2

    .line 851
    check-cast v7, Ljava/lang/String;

    .line 852
    .line 853
    sget-object v2, LE0/t;->a:[LZ1/c;

    .line 854
    .line 855
    sget-object v2, LE0/r;->a:LE0/u;

    .line 856
    .line 857
    invoke-static {v7}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 858
    .line 859
    .line 860
    move-result-object v3

    .line 861
    invoke-interface {v0, v2, v3}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 862
    .line 863
    .line 864
    return-object v6

    .line 865
    :pswitch_11
    move-object v2, v7

    .line 866
    check-cast v0, LE0/v;

    .line 867
    .line 868
    move-object v7, v2

    .line 869
    check-cast v7, LE0/g;

    .line 870
    .line 871
    iget v2, v7, LE0/g;->a:I

    .line 872
    .line 873
    invoke-static {v0, v2}, LE0/t;->b(LE0/v;I)V

    .line 874
    .line 875
    .line 876
    return-object v6

    .line 877
    :pswitch_12
    move-object v2, v7

    .line 878
    check-cast v0, Ljava/lang/Throwable;

    .line 879
    .line 880
    if-eqz v0, :cond_16

    .line 881
    .line 882
    move-object v7, v2

    .line 883
    check-cast v7, Landroid/os/CancellationSignal;

    .line 884
    .line 885
    invoke-virtual {v7}, Landroid/os/CancellationSignal;->cancel()V

    .line 886
    .line 887
    .line 888
    :cond_16
    return-object v6

    .line 889
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
