.class public final LD0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW/s;


# static fields
.field public static final d:LD0/j;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LD0/j;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LD0/j;->d:LD0/j;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(LN1/h;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->H(LN1/f;LN1/h;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final k(LN1/g;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->E(LN1/f;LN1/g;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final n(LU1/e;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final r(LN1/g;)LN1/f;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->u(LN1/f;LN1/g;)LN1/f;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final s()F
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method
