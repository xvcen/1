.class public final synthetic LD0/m;
.super LV1/a;
.source "SourceFile"

# interfaces
.implements LU1/c;


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, LD0/n;

    .line 2
    .line 3
    iget-object v0, p0, LV1/a;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, LK/e;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, LK/e;->b(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 11
    .line 12
    return-object p1
.end method
