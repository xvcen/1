.class public final synthetic LD1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, LD1/a;->d:I

    iput-object p1, p0, LD1/a;->f:Ljava/lang/Object;

    iput-object p2, p0, LD1/a;->g:Ljava/lang/Object;

    iput-object p3, p0, LD1/a;->h:Ljava/lang/Object;

    iput-object p4, p0, LD1/a;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ll/c;Ll/i;LU1/c;LV1/o;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, LD1/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD1/a;->f:Ljava/lang/Object;

    iput-object p2, p0, LD1/a;->g:Ljava/lang/Object;

    iput-object p3, p0, LD1/a;->e:Ljava/lang/Object;

    iput-object p4, p0, LD1/a;->h:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LD1/a;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LD1/a;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw/S;

    .line 9
    .line 10
    iget-object v1, p0, LD1/a;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LM0/y;

    .line 13
    .line 14
    iget-object v2, p0, LD1/a;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, LM0/x;

    .line 17
    .line 18
    iget-object v3, p0, LD1/a;->e:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v3, LM0/k;

    .line 21
    .line 22
    check-cast p1, LI/I;

    .line 23
    .line 24
    invoke-virtual {v0}, Lw/S;->b()Z

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    iget-object p1, v0, Lw/S;->d:LF/r;

    .line 31
    .line 32
    iget-object v4, v0, Lw/S;->v:Lw/p;

    .line 33
    .line 34
    iget-object v5, v0, Lw/S;->w:Lw/p;

    .line 35
    .line 36
    new-instance v6, LV1/s;

    .line 37
    .line 38
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 39
    .line 40
    .line 41
    new-instance v7, LB/r;

    .line 42
    .line 43
    const/4 v8, 0x7

    .line 44
    invoke-direct {v7, p1, v4, v6, v8}, LB/r;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 45
    .line 46
    .line 47
    iget-object p1, v1, LM0/y;->a:LM0/s;

    .line 48
    .line 49
    invoke-interface {p1, v2, v3, v7, v5}, LM0/s;->f(LM0/x;LM0/k;LB/r;Lw/p;)V

    .line 50
    .line 51
    .line 52
    new-instance v2, LM0/D;

    .line 53
    .line 54
    invoke-direct {v2, v1, p1}, LM0/D;-><init>(LM0/y;LM0/s;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, v1, LM0/y;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 58
    .line 59
    invoke-virtual {p1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iput-object v2, v6, LV1/s;->d:Ljava/lang/Object;

    .line 63
    .line 64
    iput-object v2, v0, Lw/S;->e:LM0/D;

    .line 65
    .line 66
    :cond_0
    new-instance p1, Lw/y;

    .line 67
    .line 68
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 69
    .line 70
    .line 71
    return-object p1

    .line 72
    :pswitch_0
    iget-object v0, p0, LD1/a;->f:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v0, LV1/p;

    .line 75
    .line 76
    iget-object v1, p0, LD1/a;->g:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v1, Lp/m0;

    .line 79
    .line 80
    iget-object v2, p0, LD1/a;->h:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v2, Lp/P0;

    .line 83
    .line 84
    iget-object v3, p0, LD1/a;->e:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v3, LF/a;

    .line 87
    .line 88
    check-cast p1, Ll/g;

    .line 89
    .line 90
    iget-object v4, p1, Ll/g;->e:LI/m0;

    .line 91
    .line 92
    iget-object v5, p1, Ll/g;->d:LU1/a;

    .line 93
    .line 94
    iget-object p1, p1, Ll/g;->i:LI/m0;

    .line 95
    .line 96
    invoke-virtual {v4}, LI/m0;->getValue()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    check-cast v4, Ljava/lang/Number;

    .line 101
    .line 102
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    iget v6, v0, LV1/p;->d:F

    .line 107
    .line 108
    sub-float/2addr v4, v6

    .line 109
    invoke-static {v4}, Lp/a0;->a(F)Z

    .line 110
    .line 111
    .line 112
    move-result v6

    .line 113
    if-nez v6, :cond_2

    .line 114
    .line 115
    invoke-virtual {v1, v2, v4}, Lp/m0;->c(Lp/P0;F)F

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    sub-float v1, v4, v1

    .line 120
    .line 121
    invoke-static {v1}, Lp/a0;->a(F)Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    if-nez v1, :cond_1

    .line 126
    .line 127
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 128
    .line 129
    invoke-virtual {p1, v0}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    invoke-interface {v5}, LU1/a;->a()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_1
    iget v1, v0, LV1/p;->d:F

    .line 137
    .line 138
    add-float/2addr v1, v4

    .line 139
    iput v1, v0, LV1/p;->d:F

    .line 140
    .line 141
    :cond_2
    iget v0, v0, LV1/p;->d:F

    .line 142
    .line 143
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-virtual {v3, v0}, LF/a;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    check-cast v0, Ljava/lang/Boolean;

    .line 152
    .line 153
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    if-eqz v0, :cond_3

    .line 158
    .line 159
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 160
    .line 161
    invoke-virtual {p1, v0}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v5}, LU1/a;->a()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    :cond_3
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 168
    .line 169
    return-object p1

    .line 170
    :pswitch_1
    iget-object v0, p0, LD1/a;->f:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v0, LV1/p;

    .line 173
    .line 174
    iget-object v1, p0, LD1/a;->g:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast v1, Lp/N0;

    .line 177
    .line 178
    iget-object v2, p0, LD1/a;->h:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v2, LV1/p;

    .line 181
    .line 182
    iget-object v3, p0, LD1/a;->e:Ljava/lang/Object;

    .line 183
    .line 184
    check-cast v3, LF/r;

    .line 185
    .line 186
    check-cast p1, Ll/g;

    .line 187
    .line 188
    iget-object v4, p1, Ll/g;->e:LI/m0;

    .line 189
    .line 190
    invoke-virtual {v4}, LI/m0;->getValue()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v4

    .line 194
    check-cast v4, Ljava/lang/Number;

    .line 195
    .line 196
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 197
    .line 198
    .line 199
    move-result v4

    .line 200
    iget v5, v0, LV1/p;->d:F

    .line 201
    .line 202
    sub-float/2addr v4, v5

    .line 203
    invoke-virtual {v1, v4}, Lp/N0;->a(F)F

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    iget-object v5, p1, Ll/g;->e:LI/m0;

    .line 208
    .line 209
    invoke-virtual {v5}, LI/m0;->getValue()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v5

    .line 213
    check-cast v5, Ljava/lang/Number;

    .line 214
    .line 215
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 216
    .line 217
    .line 218
    move-result v5

    .line 219
    iput v5, v0, LV1/p;->d:F

    .line 220
    .line 221
    iget-object v0, p1, Ll/g;->a:LF/r;

    .line 222
    .line 223
    iget-object v0, v0, LF/r;->f:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v0, LU1/c;

    .line 226
    .line 227
    iget-object v5, p1, Ll/g;->f:Ll/n;

    .line 228
    .line 229
    invoke-interface {v0, v5}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    check-cast v0, Ljava/lang/Number;

    .line 234
    .line 235
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 236
    .line 237
    .line 238
    move-result v0

    .line 239
    iput v0, v2, LV1/p;->d:F

    .line 240
    .line 241
    sub-float/2addr v4, v1

    .line 242
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    const/high16 v1, 0x3f000000    # 0.5f

    .line 247
    .line 248
    cmpl-float v0, v0, v1

    .line 249
    .line 250
    if-lez v0, :cond_4

    .line 251
    .line 252
    iget-object v0, p1, Ll/g;->i:LI/m0;

    .line 253
    .line 254
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 255
    .line 256
    invoke-virtual {v0, v1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    iget-object p1, p1, Ll/g;->d:LU1/a;

    .line 260
    .line 261
    invoke-interface {p1}, LU1/a;->a()Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    :cond_4
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 265
    .line 266
    .line 267
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 268
    .line 269
    return-object p1

    .line 270
    :pswitch_2
    iget-object v0, p0, LD1/a;->f:Ljava/lang/Object;

    .line 271
    .line 272
    check-cast v0, Ll/c;

    .line 273
    .line 274
    iget-object v1, p0, LD1/a;->g:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v1, Ll/i;

    .line 277
    .line 278
    iget-object v2, p0, LD1/a;->e:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v2, LU1/c;

    .line 281
    .line 282
    iget-object v3, p0, LD1/a;->h:Ljava/lang/Object;

    .line 283
    .line 284
    check-cast v3, LV1/o;

    .line 285
    .line 286
    check-cast p1, Ll/g;

    .line 287
    .line 288
    iget-object v4, v0, Ll/c;->c:Ll/i;

    .line 289
    .line 290
    invoke-static {p1, v4}, Ll/d;->j(Ll/g;Ll/i;)V

    .line 291
    .line 292
    .line 293
    iget-object v4, p1, Ll/g;->e:LI/m0;

    .line 294
    .line 295
    invoke-virtual {v4}, LI/m0;->getValue()Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object v5

    .line 299
    invoke-static {v0, v5}, Ll/c;->a(Ll/c;Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v5

    .line 303
    invoke-virtual {v4}, LI/m0;->getValue()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v4

    .line 307
    invoke-static {v5, v4}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    move-result v4

    .line 311
    if-nez v4, :cond_6

    .line 312
    .line 313
    iget-object v4, v0, Ll/c;->c:Ll/i;

    .line 314
    .line 315
    iget-object v4, v4, Ll/i;->e:LI/m0;

    .line 316
    .line 317
    invoke-virtual {v4, v5}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    iget-object v1, v1, Ll/i;->e:LI/m0;

    .line 321
    .line 322
    invoke-virtual {v1, v5}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 323
    .line 324
    .line 325
    if-eqz v2, :cond_5

    .line 326
    .line 327
    invoke-interface {v2, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    :cond_5
    iget-object v0, p1, Ll/g;->i:LI/m0;

    .line 331
    .line 332
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 333
    .line 334
    invoke-virtual {v0, v1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    iget-object p1, p1, Ll/g;->d:LU1/a;

    .line 338
    .line 339
    invoke-interface {p1}, LU1/a;->a()Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    const/4 p1, 0x1

    .line 343
    iput-boolean p1, v3, LV1/o;->d:Z

    .line 344
    .line 345
    goto :goto_1

    .line 346
    :cond_6
    if-eqz v2, :cond_7

    .line 347
    .line 348
    invoke-interface {v2, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    :cond_7
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 352
    .line 353
    return-object p1

    .line 354
    :pswitch_3
    iget-object v0, p0, LD1/a;->f:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v0, LD1/b;

    .line 357
    .line 358
    iget-object v1, p0, LD1/a;->g:Ljava/lang/Object;

    .line 359
    .line 360
    check-cast v1, LT0/c;

    .line 361
    .line 362
    iget-object v2, p0, LD1/a;->h:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v2, Lu0/r;

    .line 365
    .line 366
    iget-object v3, p0, LD1/a;->e:Ljava/lang/Object;

    .line 367
    .line 368
    check-cast v3, LU1/c;

    .line 369
    .line 370
    check-cast p1, Lf0/d;

    .line 371
    .line 372
    const-string v4, "$this$onDraw"

    .line 373
    .line 374
    invoke-static {p1, v4}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    iget-object v0, v0, LD1/b;->a:LD1/d;

    .line 378
    .line 379
    invoke-virtual {v0, p1, v1, v2, v3}, LD1/d;->b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V

    .line 380
    .line 381
    .line 382
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 383
    .line 384
    return-object p1

    .line 385
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
