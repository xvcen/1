.class public final LD1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/a;


# instance fields
.field public final a:LC1/a;

.field public final b:LD1/b;

.field public final c:Z


# direct methods
.method public constructor <init>(LC1/a;LD1/b;)V
    .locals 1

    .line 1
    const-string v0, "backdrop1"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LD1/c;->a:LC1/a;

    .line 10
    .line 11
    iput-object p2, p0, LD1/c;->b:LD1/b;

    .line 12
    .line 13
    invoke-interface {p1}, LC1/a;->a()Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-nez p1, :cond_1

    .line 18
    .line 19
    iget-boolean p1, p2, LD1/b;->c:Z

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 p1, 0x0

    .line 25
    goto :goto_1

    .line 26
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 27
    :goto_1
    iput-boolean p1, p0, LD1/c;->c:Z

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LD1/c;->c:Z

    .line 2
    .line 3
    return v0
.end method

.method public final b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V
    .locals 1

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "density"

    .line 7
    .line 8
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LD1/c;->a:LC1/a;

    .line 12
    .line 13
    invoke-interface {v0, p1, p2, p3, p4}, LC1/a;->b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, LD1/c;->b:LD1/b;

    .line 17
    .line 18
    invoke-virtual {v0, p1, p2, p3, p4}, LD1/b;->b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method
