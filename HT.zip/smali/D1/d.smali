.class public final LD1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/a;


# instance fields
.field public final a:Lg0/c;

.field public final b:LI/m0;

.field public c:LC1/h;


# direct methods
.method public constructor <init>(Lg0/c;)V
    .locals 1

    .line 1
    const-string v0, "graphicsLayer"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LD1/d;->a:Lg0/c;

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    invoke-static {p1}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, LD1/d;->b:LI/m0;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final b(Lf0/d;LT0/c;Lu0/r;LU1/c;)V
    .locals 7

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "density"

    .line 7
    .line 8
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    if-nez p3, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    iget-object v0, p0, LD1/d;->b:LI/m0;

    .line 15
    .line 16
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Lu0/r;

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    :goto_0
    return-void

    .line 25
    :cond_1
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v1}, LI/e0;->t()J

    .line 30
    .line 31
    .line 32
    move-result-wide v2

    .line 33
    invoke-virtual {v1}, LI/e0;->m()Ld0/u;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    invoke-interface {v4}, Ld0/u;->k()V

    .line 38
    .line 39
    .line 40
    :try_start_0
    iget-object v4, v1, LI/e0;->d:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v4, LA0/h;

    .line 43
    .line 44
    if-eqz p4, :cond_2

    .line 45
    .line 46
    invoke-virtual {p0}, LD1/d;->c()LC1/h;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    invoke-virtual {v5, v4, p2, p4}, LC1/h;->c(LA0/h;LT0/c;LU1/c;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    .line 52
    .line 53
    goto :goto_1

    .line 54
    :catchall_0
    move-exception p1

    .line 55
    goto :goto_3

    .line 56
    :cond_2
    :goto_1
    const-wide/16 v5, 0x0

    .line 57
    .line 58
    :try_start_1
    invoke-interface {v0, p3, v5, v6}, Lu0/r;->N(Lu0/r;J)J

    .line 59
    .line 60
    .line 61
    move-result-wide p2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 62
    goto :goto_2

    .line 63
    :catch_0
    :try_start_2
    invoke-interface {p3, v5, v6}, Lu0/r;->A(J)J

    .line 64
    .line 65
    .line 66
    move-result-wide p2

    .line 67
    invoke-interface {v0, v5, v6}, Lu0/r;->A(J)J

    .line 68
    .line 69
    .line 70
    move-result-wide v5

    .line 71
    invoke-static {p2, p3, v5, v6}, Lc0/b;->d(JJ)J

    .line 72
    .line 73
    .line 74
    move-result-wide p2

    .line 75
    :goto_2
    const/16 p4, 0x20

    .line 76
    .line 77
    shr-long v5, p2, p4

    .line 78
    .line 79
    long-to-int p4, v5

    .line 80
    invoke-static {p4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 81
    .line 82
    .line 83
    move-result p4

    .line 84
    neg-float p4, p4

    .line 85
    const-wide v5, 0xffffffffL

    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    and-long/2addr p2, v5

    .line 91
    long-to-int p2, p2

    .line 92
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 93
    .line 94
    .line 95
    move-result p2

    .line 96
    neg-float p2, p2

    .line 97
    invoke-virtual {v4, p4, p2}, LA0/h;->t(FF)V

    .line 98
    .line 99
    .line 100
    iget-object p2, p0, LD1/d;->a:Lg0/c;

    .line 101
    .line 102
    invoke-static {p1, p2}, LT0/g;->r(Lf0/d;Lg0/c;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 103
    .line 104
    .line 105
    invoke-virtual {v1}, LI/e0;->m()Ld0/u;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    invoke-interface {p1}, Ld0/u;->i()V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v1, v2, v3}, LI/e0;->E(J)V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :goto_3
    invoke-virtual {v1}, LI/e0;->m()Ld0/u;

    .line 117
    .line 118
    .line 119
    move-result-object p2

    .line 120
    invoke-interface {p2}, Ld0/u;->i()V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v1, v2, v3}, LI/e0;->E(J)V

    .line 124
    .line 125
    .line 126
    throw p1
.end method

.method public final c()LC1/h;
    .locals 4

    .line 1
    iget-object v0, p0, LD1/d;->c:LC1/h;

    .line 2
    .line 3
    const/high16 v1, 0x3f800000    # 1.0f

    .line 4
    .line 5
    const-wide v2, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iput-wide v2, v0, LC1/h;->d:J

    .line 13
    .line 14
    iput v1, v0, LC1/h;->e:F

    .line 15
    .line 16
    iput v1, v0, LC1/h;->f:F

    .line 17
    .line 18
    iput v1, v0, LC1/h;->g:F

    .line 19
    .line 20
    iput v1, v0, LC1/h;->h:F

    .line 21
    .line 22
    sget v1, Ld0/F;->b:I

    .line 23
    .line 24
    sget-wide v1, Ld0/W;->b:J

    .line 25
    .line 26
    return-object v0

    .line 27
    :cond_0
    new-instance v0, LC1/h;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-wide v2, v0, LC1/h;->d:J

    .line 33
    .line 34
    iput v1, v0, LC1/h;->e:F

    .line 35
    .line 36
    iput v1, v0, LC1/h;->f:F

    .line 37
    .line 38
    iput v1, v0, LC1/h;->g:F

    .line 39
    .line 40
    iput v1, v0, LC1/h;->h:F

    .line 41
    .line 42
    sget v1, Ld0/F;->b:I

    .line 43
    .line 44
    sget-wide v1, Ld0/W;->b:J

    .line 45
    .line 46
    iput-object v0, p0, LD1/d;->c:LC1/h;

    .line 47
    .line 48
    return-object v0
.end method
