.class final LD1/e;
.super Lw0/V;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;"
    }
.end annotation


# instance fields
.field public final a:LD1/d;


# direct methods
.method public constructor <init>(LD1/d;)V
    .locals 1

    .line 1
    const-string v0, "backdrop"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LD1/e;->a:LD1/d;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 3

    .line 1
    new-instance v0, LD1/g;

    .line 2
    .line 3
    const-string v1, "backdrop"

    .line 4
    .line 5
    iget-object v2, p0, LD1/e;->a:LD1/d;

    .line 6
    .line 7
    invoke-static {v2, v1}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-direct {v0}, LW/p;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v2, v0, LD1/g;->r:LD1/d;

    .line 14
    .line 15
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 2

    .line 1
    check-cast p1, LD1/g;

    .line 2
    .line 3
    const-string v0, "node"

    .line 4
    .line 5
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "<set-?>"

    .line 9
    .line 10
    iget-object v1, p0, LD1/e;->a:LD1/d;

    .line 11
    .line 12
    invoke-static {v1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iput-object v1, p1, LD1/g;->r:LD1/d;

    .line 16
    .line 17
    invoke-static {p1}, Lw0/j;->j(Lw0/l;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, LD1/e;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, LD1/e;

    .line 12
    .line 13
    iget-object p1, p1, LD1/e;->a:LD1/d;

    .line 14
    .line 15
    iget-object v1, p0, LD1/e;->a:LD1/d;

    .line 16
    .line 17
    invoke-static {v1, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    if-nez p1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    return v0
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, LD1/e;->a:LD1/d;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
