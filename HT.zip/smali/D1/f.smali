.class public abstract LD1/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA1/v;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LA1/v;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, LA1/v;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LD1/f;->a:LA1/v;

    .line 9
    .line 10
    return-void
.end method

.method public static final a(LW/q;LD1/d;)LW/q;
    .locals 1

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "backdrop"

    .line 7
    .line 8
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, LD1/e;

    .line 12
    .line 13
    invoke-direct {v0, p1}, LD1/e;-><init>(LD1/d;)V

    .line 14
    .line 15
    .line 16
    invoke-interface {p0, v0}, LW/q;->c(LW/q;)LW/q;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0
.end method

.method public static final b(LI/r;)LD1/d;
    .locals 4

    .line 1
    sget v0, Ld0/F;->b:I

    .line 2
    .line 3
    sget-object v0, Lx0/i0;->g:LI/b1;

    .line 4
    .line 5
    invoke-virtual {p0, v0}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ld0/A;

    .line 10
    .line 11
    invoke-virtual {p0}, LI/r;->K()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v2, LI/m;->a:LI/h;

    .line 16
    .line 17
    if-ne v1, v2, :cond_0

    .line 18
    .line 19
    new-instance v1, Ld0/B;

    .line 20
    .line 21
    invoke-direct {v1, v0}, Ld0/B;-><init>(Ld0/A;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, v1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    check-cast v1, Ld0/B;

    .line 28
    .line 29
    iget-object v0, v1, Ld0/B;->e:Lg0/c;

    .line 30
    .line 31
    invoke-virtual {p0, v0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    sget-object v3, LD1/f;->a:LA1/v;

    .line 36
    .line 37
    invoke-virtual {p0, v3}, LI/r;->e(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    or-int/2addr v1, v3

    .line 42
    invoke-virtual {p0}, LI/r;->K()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    if-nez v1, :cond_1

    .line 47
    .line 48
    if-ne v3, v2, :cond_2

    .line 49
    .line 50
    :cond_1
    new-instance v3, LD1/d;

    .line 51
    .line 52
    invoke-direct {v3, v0}, LD1/d;-><init>(Lg0/c;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p0, v3}, LI/r;->d0(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    check-cast v3, LD1/d;

    .line 59
    .line 60
    return-object v3
.end method
