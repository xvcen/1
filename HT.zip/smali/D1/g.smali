.class public final LD1/g;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/l;
.implements Lw0/m;


# instance fields
.field public r:LD1/d;


# virtual methods
.method public final N0()V
    .locals 2

    .line 1
    iget-object v0, p0, LD1/g;->r:LD1/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v0, v0, LD1/d;->b:LI/m0;

    .line 5
    .line 6
    invoke-virtual {v0, v1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final O(Lw0/b0;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Lw0/b0;->h1()LW/p;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v0, v0, LW/p;->q:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, LD1/g;->r:LD1/d;

    .line 10
    .line 11
    iget-object v0, v0, LD1/d;->b:LI/m0;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final U(Lw0/G;)V
    .locals 7

    .line 1
    invoke-virtual {p1}, Lw0/G;->c()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LD1/g;->r:LD1/d;

    .line 5
    .line 6
    iget-object v3, v0, LD1/d;->a:Lg0/c;

    .line 7
    .line 8
    new-instance v6, LC1/e;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {v6, v0, p0, p1}, LC1/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p1, Lw0/G;->d:Lf0/b;

    .line 15
    .line 16
    invoke-interface {v0}, Lf0/d;->a()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    invoke-static {v0, v1}, LT0/l;->N(J)J

    .line 21
    .line 22
    .line 23
    move-result-wide v4

    .line 24
    move-object v1, p0

    .line 25
    move-object v2, p1

    .line 26
    invoke-static/range {v1 .. v6}, LC1/c;->c(Lw0/h;Lf0/d;Lg0/c;JLU1/c;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
