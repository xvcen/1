.class public final LE/c;
.super LP1/h;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public f:Lq0/u;

.field public g:Lq0/m;

.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LE/d;


# direct methods
.method public constructor <init>(LE/d;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LE/c;->j:LE/d;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LP1/h;-><init>(LN1/c;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lq0/I;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LE/c;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LE/c;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LE/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LE/c;

    .line 2
    .line 3
    iget-object v1, p0, LE/c;->j:LE/d;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LE/c;-><init>(LE/d;LN1/c;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, LE/c;->i:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LE/c;->h:I

    .line 4
    .line 5
    sget-object v2, Lq0/m;->d:Lq0/m;

    .line 6
    .line 7
    iget-object v3, v0, LE/c;->j:LE/d;

    .line 8
    .line 9
    const/4 v4, 0x3

    .line 10
    const/4 v5, 0x2

    .line 11
    const/4 v7, 0x1

    .line 12
    sget-object v9, LO1/a;->d:LO1/a;

    .line 13
    .line 14
    if-eqz v1, :cond_3

    .line 15
    .line 16
    if-eq v1, v7, :cond_2

    .line 17
    .line 18
    if-eq v1, v5, :cond_1

    .line 19
    .line 20
    if-ne v1, v4, :cond_0

    .line 21
    .line 22
    iget-object v1, v0, LE/c;->f:Lq0/u;

    .line 23
    .line 24
    iget-object v3, v0, LE/c;->i:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v3, Lq0/I;

    .line 27
    .line 28
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    move-object/from16 v6, p1

    .line 32
    .line 33
    move v5, v4

    .line 34
    move-object v8, v9

    .line 35
    const/4 v4, 0x0

    .line 36
    goto/16 :goto_17

    .line 37
    .line 38
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw v1

    .line 46
    :cond_1
    iget-object v1, v0, LE/c;->g:Lq0/m;

    .line 47
    .line 48
    iget-object v10, v0, LE/c;->f:Lq0/u;

    .line 49
    .line 50
    iget-object v11, v0, LE/c;->i:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v11, Lq0/I;

    .line 53
    .line 54
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    move-object/from16 v12, p1

    .line 58
    .line 59
    goto/16 :goto_7

    .line 60
    .line 61
    :cond_2
    iget-object v1, v0, LE/c;->i:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v1, Lq0/I;

    .line 64
    .line 65
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    move-object/from16 v10, p1

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_3
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    iget-object v1, v0, LE/c;->i:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v1, Lq0/I;

    .line 77
    .line 78
    iput-object v1, v0, LE/c;->i:Ljava/lang/Object;

    .line 79
    .line 80
    iput v7, v0, LE/c;->h:I

    .line 81
    .line 82
    invoke-static {v1, v7, v2, v0}, Lp/p1;->a(Lq0/I;ZLq0/m;LP1/a;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v10

    .line 86
    if-ne v10, v9, :cond_4

    .line 87
    .line 88
    :goto_0
    move-object v8, v9

    .line 89
    goto/16 :goto_16

    .line 90
    .line 91
    :cond_4
    :goto_1
    check-cast v10, Lq0/u;

    .line 92
    .line 93
    iget v11, v10, Lq0/u;->i:I

    .line 94
    .line 95
    iget-wide v12, v10, Lq0/u;->c:J

    .line 96
    .line 97
    if-ne v11, v4, :cond_5

    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_5
    const/4 v14, 0x4

    .line 101
    if-ne v11, v14, :cond_2a

    .line 102
    .line 103
    :goto_2
    const/16 v11, 0x20

    .line 104
    .line 105
    shr-long v14, v12, v11

    .line 106
    .line 107
    long-to-int v14, v14

    .line 108
    invoke-static {v14}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 109
    .line 110
    .line 111
    move-result v15

    .line 112
    const/16 v16, 0x0

    .line 113
    .line 114
    cmpl-float v15, v15, v16

    .line 115
    .line 116
    if-ltz v15, :cond_6

    .line 117
    .line 118
    invoke-static {v14}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 119
    .line 120
    .line 121
    move-result v14

    .line 122
    iget-object v15, v1, Lq0/I;->i:Lq0/K;

    .line 123
    .line 124
    move/from16 p1, v11

    .line 125
    .line 126
    move-wide/from16 v17, v12

    .line 127
    .line 128
    iget-wide v11, v15, Lq0/K;->A:J

    .line 129
    .line 130
    shr-long v11, v11, p1

    .line 131
    .line 132
    long-to-int v11, v11

    .line 133
    int-to-float v11, v11

    .line 134
    cmpg-float v11, v14, v11

    .line 135
    .line 136
    if-gez v11, :cond_6

    .line 137
    .line 138
    const-wide v11, 0xffffffffL

    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    and-long v13, v17, v11

    .line 144
    .line 145
    long-to-int v13, v13

    .line 146
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 147
    .line 148
    .line 149
    move-result v14

    .line 150
    cmpl-float v14, v14, v16

    .line 151
    .line 152
    if-ltz v14, :cond_6

    .line 153
    .line 154
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 155
    .line 156
    .line 157
    move-result v13

    .line 158
    iget-object v14, v1, Lq0/I;->i:Lq0/K;

    .line 159
    .line 160
    iget-wide v14, v14, Lq0/K;->A:J

    .line 161
    .line 162
    and-long/2addr v11, v14

    .line 163
    long-to-int v11, v11

    .line 164
    int-to-float v11, v11

    .line 165
    cmpg-float v11, v13, v11

    .line 166
    .line 167
    if-gez v11, :cond_6

    .line 168
    .line 169
    move v11, v7

    .line 170
    goto :goto_3

    .line 171
    :cond_6
    const/4 v11, 0x0

    .line 172
    :goto_3
    iget-boolean v12, v3, LE/d;->u:Z

    .line 173
    .line 174
    if-nez v12, :cond_8

    .line 175
    .line 176
    if-eqz v11, :cond_7

    .line 177
    .line 178
    goto :goto_4

    .line 179
    :cond_7
    sget-object v11, Lq0/m;->e:Lq0/m;

    .line 180
    .line 181
    goto :goto_5

    .line 182
    :cond_8
    :goto_4
    move-object v11, v2

    .line 183
    :goto_5
    move-object/from16 v20, v11

    .line 184
    .line 185
    move-object v11, v1

    .line 186
    move-object/from16 v1, v20

    .line 187
    .line 188
    :goto_6
    iput-object v11, v0, LE/c;->i:Ljava/lang/Object;

    .line 189
    .line 190
    iput-object v10, v0, LE/c;->f:Lq0/u;

    .line 191
    .line 192
    iput-object v1, v0, LE/c;->g:Lq0/m;

    .line 193
    .line 194
    iput v5, v0, LE/c;->h:I

    .line 195
    .line 196
    invoke-virtual {v11, v1, v0}, Lq0/I;->y(Lq0/m;LP1/a;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v12

    .line 200
    if-ne v12, v9, :cond_9

    .line 201
    .line 202
    goto :goto_0

    .line 203
    :cond_9
    :goto_7
    check-cast v12, Lq0/l;

    .line 204
    .line 205
    iget-object v13, v12, Lq0/l;->a:Ljava/lang/Object;

    .line 206
    .line 207
    invoke-interface {v13}, Ljava/util/Collection;->size()I

    .line 208
    .line 209
    .line 210
    move-result v14

    .line 211
    const/4 v15, 0x0

    .line 212
    :goto_8
    if-ge v15, v14, :cond_b

    .line 213
    .line 214
    invoke-interface {v13, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v16

    .line 218
    move-object/from16 v6, v16

    .line 219
    .line 220
    check-cast v6, Lq0/u;

    .line 221
    .line 222
    invoke-virtual {v6}, Lq0/u;->b()Z

    .line 223
    .line 224
    .line 225
    move-result v18

    .line 226
    move-object/from16 v19, v9

    .line 227
    .line 228
    if-nez v18, :cond_a

    .line 229
    .line 230
    iget-wide v8, v6, Lq0/u;->a:J

    .line 231
    .line 232
    iget-wide v4, v10, Lq0/u;->a:J

    .line 233
    .line 234
    invoke-static {v8, v9, v4, v5}, Lq0/t;->e(JJ)Z

    .line 235
    .line 236
    .line 237
    move-result v4

    .line 238
    if-eqz v4, :cond_a

    .line 239
    .line 240
    iget-boolean v4, v6, Lq0/u;->d:Z

    .line 241
    .line 242
    if-eqz v4, :cond_a

    .line 243
    .line 244
    goto :goto_9

    .line 245
    :cond_a
    add-int/lit8 v15, v15, 0x1

    .line 246
    .line 247
    move-object/from16 v9, v19

    .line 248
    .line 249
    const/4 v4, 0x3

    .line 250
    const/4 v5, 0x2

    .line 251
    goto :goto_8

    .line 252
    :cond_b
    move-object/from16 v19, v9

    .line 253
    .line 254
    const/16 v16, 0x0

    .line 255
    .line 256
    :goto_9
    move-object/from16 v4, v16

    .line 257
    .line 258
    check-cast v4, Lq0/u;

    .line 259
    .line 260
    if-nez v4, :cond_c

    .line 261
    .line 262
    goto :goto_a

    .line 263
    :cond_c
    iget-wide v5, v4, Lq0/u;->b:J

    .line 264
    .line 265
    iget-wide v8, v10, Lq0/u;->b:J

    .line 266
    .line 267
    sub-long/2addr v5, v8

    .line 268
    invoke-virtual {v11}, Lq0/I;->B()Lx0/J0;

    .line 269
    .line 270
    .line 271
    move-result-object v8

    .line 272
    invoke-interface {v8}, Lx0/J0;->c()J

    .line 273
    .line 274
    .line 275
    move-result-wide v8

    .line 276
    cmp-long v5, v5, v8

    .line 277
    .line 278
    if-ltz v5, :cond_d

    .line 279
    .line 280
    goto :goto_a

    .line 281
    :cond_d
    iget v5, v12, Lq0/l;->c:I

    .line 282
    .line 283
    const/4 v6, 0x2

    .line 284
    if-ne v5, v6, :cond_e

    .line 285
    .line 286
    :goto_a
    const/4 v4, 0x0

    .line 287
    goto :goto_b

    .line 288
    :cond_e
    iget-wide v8, v4, Lq0/u;->c:J

    .line 289
    .line 290
    iget-wide v12, v10, Lq0/u;->c:J

    .line 291
    .line 292
    invoke-static {v8, v9, v12, v13}, Lc0/b;->d(JJ)J

    .line 293
    .line 294
    .line 295
    move-result-wide v8

    .line 296
    invoke-static {v8, v9}, Lc0/b;->c(J)F

    .line 297
    .line 298
    .line 299
    move-result v5

    .line 300
    invoke-virtual {v11}, Lq0/I;->B()Lx0/J0;

    .line 301
    .line 302
    .line 303
    move-result-object v8

    .line 304
    invoke-interface {v8}, Lx0/J0;->e()F

    .line 305
    .line 306
    .line 307
    move-result v8

    .line 308
    cmpl-float v5, v5, v8

    .line 309
    .line 310
    if-lez v5, :cond_29

    .line 311
    .line 312
    :goto_b
    if-nez v4, :cond_f

    .line 313
    .line 314
    goto/16 :goto_1a

    .line 315
    .line 316
    :cond_f
    iget-boolean v1, v3, LE/d;->u:Z

    .line 317
    .line 318
    if-nez v1, :cond_24

    .line 319
    .line 320
    iget-object v1, v3, LW/p;->d:LW/p;

    .line 321
    .line 322
    const/4 v5, 0x0

    .line 323
    :goto_c
    const/16 v6, 0x10

    .line 324
    .line 325
    if-eqz v1, :cond_17

    .line 326
    .line 327
    instance-of v8, v1, Lb0/y;

    .line 328
    .line 329
    if-eqz v8, :cond_10

    .line 330
    .line 331
    check-cast v1, Lb0/y;

    .line 332
    .line 333
    invoke-static {v1}, Lb0/y;->c1(Lb0/y;)Z

    .line 334
    .line 335
    .line 336
    goto/16 :goto_14

    .line 337
    .line 338
    :cond_10
    iget v8, v1, LW/p;->f:I

    .line 339
    .line 340
    and-int/lit16 v8, v8, 0x400

    .line 341
    .line 342
    if-eqz v8, :cond_16

    .line 343
    .line 344
    instance-of v8, v1, Lw0/i;

    .line 345
    .line 346
    if-eqz v8, :cond_16

    .line 347
    .line 348
    move-object v8, v1

    .line 349
    check-cast v8, Lw0/i;

    .line 350
    .line 351
    iget-object v8, v8, Lw0/i;->s:LW/p;

    .line 352
    .line 353
    const/4 v9, 0x0

    .line 354
    :goto_d
    if-eqz v8, :cond_15

    .line 355
    .line 356
    iget v12, v8, LW/p;->f:I

    .line 357
    .line 358
    and-int/lit16 v12, v12, 0x400

    .line 359
    .line 360
    if-eqz v12, :cond_14

    .line 361
    .line 362
    add-int/lit8 v9, v9, 0x1

    .line 363
    .line 364
    if-ne v9, v7, :cond_11

    .line 365
    .line 366
    move-object v1, v8

    .line 367
    goto :goto_e

    .line 368
    :cond_11
    if-nez v5, :cond_12

    .line 369
    .line 370
    new-instance v5, LK/e;

    .line 371
    .line 372
    new-array v12, v6, [LW/p;

    .line 373
    .line 374
    invoke-direct {v5, v12}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 375
    .line 376
    .line 377
    :cond_12
    if-eqz v1, :cond_13

    .line 378
    .line 379
    invoke-virtual {v5, v1}, LK/e;->b(Ljava/lang/Object;)V

    .line 380
    .line 381
    .line 382
    const/4 v1, 0x0

    .line 383
    :cond_13
    invoke-virtual {v5, v8}, LK/e;->b(Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    :cond_14
    :goto_e
    iget-object v8, v8, LW/p;->i:LW/p;

    .line 387
    .line 388
    goto :goto_d

    .line 389
    :cond_15
    if-ne v9, v7, :cond_16

    .line 390
    .line 391
    goto :goto_c

    .line 392
    :cond_16
    invoke-static {v5}, Lw0/j;->e(LK/e;)LW/p;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    goto :goto_c

    .line 397
    :cond_17
    iget-object v1, v3, LW/p;->d:LW/p;

    .line 398
    .line 399
    iget-boolean v1, v1, LW/p;->q:Z

    .line 400
    .line 401
    if-nez v1, :cond_18

    .line 402
    .line 403
    const-string v1, "visitChildren called on an unattached node"

    .line 404
    .line 405
    invoke-static {v1}, Lt0/a;->b(Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    :cond_18
    new-instance v1, LK/e;

    .line 409
    .line 410
    new-array v5, v6, [LW/p;

    .line 411
    .line 412
    invoke-direct {v1, v5}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 413
    .line 414
    .line 415
    iget-object v5, v3, LW/p;->d:LW/p;

    .line 416
    .line 417
    iget-object v8, v5, LW/p;->i:LW/p;

    .line 418
    .line 419
    if-nez v8, :cond_19

    .line 420
    .line 421
    invoke-static {v1, v5}, Lw0/j;->b(LK/e;LW/p;)V

    .line 422
    .line 423
    .line 424
    goto :goto_f

    .line 425
    :cond_19
    invoke-virtual {v1, v8}, LK/e;->b(Ljava/lang/Object;)V

    .line 426
    .line 427
    .line 428
    :cond_1a
    :goto_f
    iget v5, v1, LK/e;->f:I

    .line 429
    .line 430
    if-eqz v5, :cond_24

    .line 431
    .line 432
    add-int/lit8 v5, v5, -0x1

    .line 433
    .line 434
    invoke-virtual {v1, v5}, LK/e;->j(I)Ljava/lang/Object;

    .line 435
    .line 436
    .line 437
    move-result-object v5

    .line 438
    check-cast v5, LW/p;

    .line 439
    .line 440
    iget v8, v5, LW/p;->g:I

    .line 441
    .line 442
    and-int/lit16 v8, v8, 0x400

    .line 443
    .line 444
    if-nez v8, :cond_1b

    .line 445
    .line 446
    invoke-static {v1, v5}, Lw0/j;->b(LK/e;LW/p;)V

    .line 447
    .line 448
    .line 449
    goto :goto_f

    .line 450
    :cond_1b
    :goto_10
    if-eqz v5, :cond_1a

    .line 451
    .line 452
    iget v8, v5, LW/p;->f:I

    .line 453
    .line 454
    and-int/lit16 v8, v8, 0x400

    .line 455
    .line 456
    if-eqz v8, :cond_23

    .line 457
    .line 458
    const/4 v8, 0x0

    .line 459
    :goto_11
    if-eqz v5, :cond_1a

    .line 460
    .line 461
    instance-of v9, v5, Lb0/y;

    .line 462
    .line 463
    if-eqz v9, :cond_1c

    .line 464
    .line 465
    check-cast v5, Lb0/y;

    .line 466
    .line 467
    invoke-static {v5}, Lb0/y;->c1(Lb0/y;)Z

    .line 468
    .line 469
    .line 470
    goto :goto_14

    .line 471
    :cond_1c
    iget v9, v5, LW/p;->f:I

    .line 472
    .line 473
    and-int/lit16 v9, v9, 0x400

    .line 474
    .line 475
    if-eqz v9, :cond_22

    .line 476
    .line 477
    instance-of v9, v5, Lw0/i;

    .line 478
    .line 479
    if-eqz v9, :cond_22

    .line 480
    .line 481
    move-object v9, v5

    .line 482
    check-cast v9, Lw0/i;

    .line 483
    .line 484
    iget-object v9, v9, Lw0/i;->s:LW/p;

    .line 485
    .line 486
    const/4 v12, 0x0

    .line 487
    :goto_12
    if-eqz v9, :cond_21

    .line 488
    .line 489
    iget v13, v9, LW/p;->f:I

    .line 490
    .line 491
    and-int/lit16 v13, v13, 0x400

    .line 492
    .line 493
    if-eqz v13, :cond_20

    .line 494
    .line 495
    add-int/lit8 v12, v12, 0x1

    .line 496
    .line 497
    if-ne v12, v7, :cond_1d

    .line 498
    .line 499
    move-object v5, v9

    .line 500
    goto :goto_13

    .line 501
    :cond_1d
    if-nez v8, :cond_1e

    .line 502
    .line 503
    new-instance v8, LK/e;

    .line 504
    .line 505
    new-array v13, v6, [LW/p;

    .line 506
    .line 507
    invoke-direct {v8, v13}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 508
    .line 509
    .line 510
    :cond_1e
    if-eqz v5, :cond_1f

    .line 511
    .line 512
    invoke-virtual {v8, v5}, LK/e;->b(Ljava/lang/Object;)V

    .line 513
    .line 514
    .line 515
    const/4 v5, 0x0

    .line 516
    :cond_1f
    invoke-virtual {v8, v9}, LK/e;->b(Ljava/lang/Object;)V

    .line 517
    .line 518
    .line 519
    :cond_20
    :goto_13
    iget-object v9, v9, LW/p;->i:LW/p;

    .line 520
    .line 521
    goto :goto_12

    .line 522
    :cond_21
    if-ne v12, v7, :cond_22

    .line 523
    .line 524
    goto :goto_11

    .line 525
    :cond_22
    invoke-static {v8}, Lw0/j;->e(LK/e;)LW/p;

    .line 526
    .line 527
    .line 528
    move-result-object v5

    .line 529
    goto :goto_11

    .line 530
    :cond_23
    iget-object v5, v5, LW/p;->i:LW/p;

    .line 531
    .line 532
    goto :goto_10

    .line 533
    :cond_24
    :goto_14
    iget-object v1, v3, LE/d;->t:LU1/a;

    .line 534
    .line 535
    invoke-interface {v1}, LU1/a;->a()Ljava/lang/Object;

    .line 536
    .line 537
    .line 538
    invoke-virtual {v4}, Lq0/u;->a()V

    .line 539
    .line 540
    .line 541
    move-object v1, v10

    .line 542
    move-object v3, v11

    .line 543
    :goto_15
    iput-object v3, v0, LE/c;->i:Ljava/lang/Object;

    .line 544
    .line 545
    iput-object v1, v0, LE/c;->f:Lq0/u;

    .line 546
    .line 547
    const/4 v4, 0x0

    .line 548
    iput-object v4, v0, LE/c;->g:Lq0/m;

    .line 549
    .line 550
    const/4 v5, 0x3

    .line 551
    iput v5, v0, LE/c;->h:I

    .line 552
    .line 553
    invoke-virtual {v3, v2, v0}, Lq0/I;->y(Lq0/m;LP1/a;)Ljava/lang/Object;

    .line 554
    .line 555
    .line 556
    move-result-object v6

    .line 557
    move-object/from16 v8, v19

    .line 558
    .line 559
    if-ne v6, v8, :cond_25

    .line 560
    .line 561
    :goto_16
    return-object v8

    .line 562
    :cond_25
    :goto_17
    check-cast v6, Lq0/l;

    .line 563
    .line 564
    iget-object v6, v6, Lq0/l;->a:Ljava/lang/Object;

    .line 565
    .line 566
    invoke-interface {v6}, Ljava/util/Collection;->size()I

    .line 567
    .line 568
    .line 569
    move-result v7

    .line 570
    const/4 v9, 0x0

    .line 571
    :goto_18
    if-ge v9, v7, :cond_27

    .line 572
    .line 573
    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 574
    .line 575
    .line 576
    move-result-object v10

    .line 577
    move-object v11, v10

    .line 578
    check-cast v11, Lq0/u;

    .line 579
    .line 580
    invoke-virtual {v11}, Lq0/u;->b()Z

    .line 581
    .line 582
    .line 583
    move-result v12

    .line 584
    if-nez v12, :cond_26

    .line 585
    .line 586
    iget-wide v12, v11, Lq0/u;->a:J

    .line 587
    .line 588
    iget-wide v14, v1, Lq0/u;->a:J

    .line 589
    .line 590
    invoke-static {v12, v13, v14, v15}, Lq0/t;->e(JJ)Z

    .line 591
    .line 592
    .line 593
    move-result v12

    .line 594
    if-eqz v12, :cond_26

    .line 595
    .line 596
    iget-boolean v11, v11, Lq0/u;->d:Z

    .line 597
    .line 598
    if-eqz v11, :cond_26

    .line 599
    .line 600
    goto :goto_19

    .line 601
    :cond_26
    add-int/lit8 v9, v9, 0x1

    .line 602
    .line 603
    goto :goto_18

    .line 604
    :cond_27
    move-object v10, v4

    .line 605
    :goto_19
    check-cast v10, Lq0/u;

    .line 606
    .line 607
    if-nez v10, :cond_28

    .line 608
    .line 609
    goto :goto_1a

    .line 610
    :cond_28
    invoke-virtual {v10}, Lq0/u;->a()V

    .line 611
    .line 612
    .line 613
    move-object/from16 v19, v8

    .line 614
    .line 615
    goto :goto_15

    .line 616
    :cond_29
    move v5, v6

    .line 617
    move-object/from16 v9, v19

    .line 618
    .line 619
    const/4 v4, 0x3

    .line 620
    goto/16 :goto_6

    .line 621
    .line 622
    :cond_2a
    :goto_1a
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 623
    .line 624
    return-object v1
.end method
