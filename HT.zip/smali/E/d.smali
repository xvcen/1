.class public final LE/d;
.super Lw0/i;
.source "SourceFile"

# interfaces
.implements Lw0/p0;
.implements Lb0/g;
.implements Lb0/v;


# instance fields
.field public t:LU1/a;

.field public u:Z

.field public final v:Lq0/K;


# direct methods
.method public constructor <init>(LU1/a;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Lw0/i;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE/d;->t:LU1/a;

    .line 5
    .line 6
    new-instance p1, LB1/e;

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    invoke-direct {p1, v0, p0}, LB1/e;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    sget-object v0, Lq0/E;->a:Lq0/l;

    .line 13
    .line 14
    new-instance v0, Lq0/K;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-direct {v0, v1, v1, p1}, Lq0/K;-><init>(Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v0}, Lw0/i;->U0(Lw0/h;)Lw0/h;

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, LE/d;->v:Lq0/K;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final B()J
    .locals 5

    .line 1
    sget-object v0, LE/b;->a:Lw0/k;

    .line 2
    .line 3
    invoke-static {p0}, Lw0/j;->u(Lw0/h;)Lw0/E;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-object v1, v1, Lw0/E;->B:LT0/c;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget v2, Lw0/w0;->b:I

    .line 13
    .line 14
    iget v2, v0, Lw0/k;->a:F

    .line 15
    .line 16
    invoke-interface {v1, v2}, LT0/c;->Y(F)I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    iget v3, v0, Lw0/k;->b:F

    .line 21
    .line 22
    invoke-interface {v1, v3}, LT0/c;->Y(F)I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    iget v4, v0, Lw0/k;->c:F

    .line 27
    .line 28
    invoke-interface {v1, v4}, LT0/c;->Y(F)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    iget v0, v0, Lw0/k;->d:F

    .line 33
    .line 34
    invoke-interface {v1, v0}, LT0/c;->Y(F)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v2, v3, v4, v0}, Lw0/Z;->c(IIII)J

    .line 39
    .line 40
    .line 41
    move-result-wide v0

    .line 42
    return-wide v0
.end method

.method public final i0(Lb0/x;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Lb0/x;->a()Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iput-boolean p1, p0, LE/d;->u:Z

    .line 6
    .line 7
    return-void
.end method

.method public final o0()V
    .locals 1

    .line 1
    iget-object v0, p0, LE/d;->v:Lq0/K;

    .line 2
    .line 3
    invoke-virtual {v0}, Lq0/K;->o0()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final v0(Lq0/l;Lq0/m;J)V
    .locals 1

    .line 1
    iget-object v0, p0, LE/d;->v:Lq0/K;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2, p3, p4}, Lq0/K;->v0(Lq0/l;Lq0/m;J)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
