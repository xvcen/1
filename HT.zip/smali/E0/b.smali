.class public final LE0/b;
.super Lw0/V;
.source "SourceFile"

# interfaces
.implements LW/o;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;",
        "LW/o;"
    }
.end annotation


# instance fields
.field public final a:LU1/c;


# direct methods
.method public constructor <init>(LU1/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE0/b;->a:LU1/c;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 2

    .line 1
    new-instance v0, LE0/c;

    .line 2
    .line 3
    invoke-direct {v0}, LW/p;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LE0/b;->a:LU1/c;

    .line 7
    .line 8
    iput-object v1, v0, LE0/c;->r:LU1/c;

    .line 9
    .line 10
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 1

    .line 1
    check-cast p1, LE0/c;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LE0/b;->a:LU1/c;

    .line 7
    .line 8
    iput-object v0, p1, LE0/c;->r:LU1/c;

    .line 9
    .line 10
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_1

    .line 4
    :cond_0
    instance-of v0, p1, LE0/b;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_1
    check-cast p1, LE0/b;

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, LE0/b;->a:LU1/c;

    .line 15
    .line 16
    iget-object p1, p1, LE0/b;->a:LU1/c;

    .line 17
    .line 18
    if-eq v0, p1, :cond_2

    .line 19
    .line 20
    :goto_0
    const/4 p1, 0x0

    .line 21
    return p1

    .line 22
    :cond_2
    :goto_1
    const/4 p1, 0x1

    .line 23
    return p1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    mul-int/lit8 v0, v0, 0x1f

    .line 7
    .line 8
    iget-object v1, p0, LE0/b;->a:LU1/c;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    add-int/2addr v1, v0

    .line 15
    return v1
.end method
