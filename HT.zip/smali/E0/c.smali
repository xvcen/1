.class public final LE0/c;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/t0;


# instance fields
.field public r:LU1/c;


# virtual methods
.method public final C(LE0/v;)V
    .locals 1

    .line 1
    iget-object v0, p0, LE0/c;->r:LU1/c;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final q0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final r0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method
