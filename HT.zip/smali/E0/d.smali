.class public final LE0/d;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/t0;


# virtual methods
.method public final C(LE0/v;)V
    .locals 0

    .line 1
    return-void
.end method
