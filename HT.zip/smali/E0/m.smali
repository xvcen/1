.class public final LE0/m;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/t0;


# instance fields
.field public final synthetic r:LV1/j;


# direct methods
.method public constructor <init>(LU1/c;)V
    .locals 0

    .line 1
    check-cast p1, LV1/j;

    .line 2
    .line 3
    iput-object p1, p0, LE0/m;->r:LV1/j;

    .line 4
    .line 5
    invoke-direct {p0}, LW/p;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final C(LE0/v;)V
    .locals 1

    .line 1
    iget-object v0, p0, LE0/m;->r:LV1/j;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
