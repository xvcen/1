.class public final LE0/o;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LE0/n;

.field public final b:LT0/m;


# direct methods
.method public constructor <init>(LE0/n;LT0/m;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE0/o;->a:LE0/n;

    .line 5
    .line 6
    iput-object p2, p0, LE0/o;->b:LT0/m;

    .line 7
    .line 8
    return-void
.end method
