.class public abstract LE0/s;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LE0/u;

.field public static final b:LE0/u;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LE0/u;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, LE0/i;->v:LE0/i;

    .line 5
    .line 6
    const-string v3, "TestTagsAsResourceId"

    .line 7
    .line 8
    invoke-direct {v0, v3, v1, v2}, LE0/u;-><init>(Ljava/lang/String;ZLU1/e;)V

    .line 9
    .line 10
    .line 11
    sput-object v0, LE0/s;->a:LE0/u;

    .line 12
    .line 13
    sget-object v0, LE0/i;->u:LE0/i;

    .line 14
    .line 15
    new-instance v1, LE0/u;

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    const-string v3, "AccessibilityClassName"

    .line 19
    .line 20
    invoke-direct {v1, v3, v2, v0}, LE0/u;-><init>(Ljava/lang/String;ZLU1/e;)V

    .line 21
    .line 22
    .line 23
    sput-object v1, LE0/s;->b:LE0/u;

    .line 24
    .line 25
    return-void
.end method
