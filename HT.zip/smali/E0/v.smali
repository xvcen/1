.class public interface abstract LE0/v;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LE0/u;Ljava/lang/Object;)V
.end method
