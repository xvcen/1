.class public final LF/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/inputmethod/InputConnection;


# instance fields
.field public final a:LA0/h;

.field public final b:Z

.field public final c:Lw/S;

.field public final d:LH/m0;

.field public final e:Lx0/J0;

.field public f:I

.field public g:LM0/x;

.field public h:I

.field public i:Z

.field public final j:Ljava/util/ArrayList;

.field public k:Z


# direct methods
.method public constructor <init>(LM0/x;LA0/h;ZLw/S;LH/m0;Lx0/J0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LF/A;->a:LA0/h;

    .line 5
    .line 6
    iput-boolean p3, p0, LF/A;->b:Z

    .line 7
    .line 8
    iput-object p4, p0, LF/A;->c:Lw/S;

    .line 9
    .line 10
    iput-object p5, p0, LF/A;->d:LH/m0;

    .line 11
    .line 12
    iput-object p6, p0, LF/A;->e:Lx0/J0;

    .line 13
    .line 14
    iput-object p1, p0, LF/A;->g:LM0/x;

    .line 15
    .line 16
    new-instance p1, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, LF/A;->j:Ljava/util/ArrayList;

    .line 22
    .line 23
    const/4 p1, 0x1

    .line 24
    iput-boolean p1, p0, LF/A;->k:Z

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final a(LM0/g;)V
    .locals 1

    .line 1
    iget v0, p0, LF/A;->f:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, 0x1

    .line 4
    .line 5
    iput v0, p0, LF/A;->f:I

    .line 6
    .line 7
    :try_start_0
    iget-object v0, p0, LF/A;->j:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, LF/A;->b()Z

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    invoke-virtual {p0}, LF/A;->b()Z

    .line 18
    .line 19
    .line 20
    throw p1
.end method

.method public final b()Z
    .locals 3

    .line 1
    iget v0, p0, LF/A;->f:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, -0x1

    .line 4
    .line 5
    iput v0, p0, LF/A;->f:I

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, LF/A;->j:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    invoke-static {v0}, LK1/m;->D0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v2, p0, LF/A;->a:LA0/h;

    .line 22
    .line 23
    iget-object v2, v2, LA0/h;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v2, LF/z;

    .line 26
    .line 27
    iget-object v2, v2, LF/z;->c:LU1/c;

    .line 28
    .line 29
    invoke-interface {v2, v1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 33
    .line 34
    .line 35
    :cond_0
    iget v0, p0, LF/A;->f:I

    .line 36
    .line 37
    if-lez v0, :cond_1

    .line 38
    .line 39
    const/4 v0, 0x1

    .line 40
    return v0

    .line 41
    :cond_1
    const/4 v0, 0x0

    .line 42
    return v0
.end method

.method public final beginBatchEdit()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget v0, p0, LF/A;->f:I

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    add-int/2addr v0, v1

    .line 9
    iput v0, p0, LF/A;->f:I

    .line 10
    .line 11
    return v1

    .line 12
    :cond_0
    return v0
.end method

.method public final c(I)V
    .locals 2

    .line 1
    new-instance v0, Landroid/view/KeyEvent;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, p1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, LF/A;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 8
    .line 9
    .line 10
    new-instance v0, Landroid/view/KeyEvent;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-direct {v0, v1, p1}, Landroid/view/KeyEvent;-><init>(II)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, v0}, LF/A;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final clearMetaKeyStates(I)Z
    .locals 0

    .line 1
    iget-boolean p1, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    :cond_0
    return p1
.end method

.method public final closeConnection()V
    .locals 4

    .line 1
    iget-object v0, p0, LF/A;->j:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, LF/A;->f:I

    .line 8
    .line 9
    iput-boolean v0, p0, LF/A;->k:Z

    .line 10
    .line 11
    iget-object v1, p0, LF/A;->a:LA0/h;

    .line 12
    .line 13
    iget-object v1, v1, LA0/h;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, LF/z;

    .line 16
    .line 17
    iget-object v1, v1, LF/z;->j:Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    :goto_0
    if-ge v0, v2, :cond_1

    .line 24
    .line 25
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Ljava/lang/ref/WeakReference;

    .line 30
    .line 31
    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-static {v3, p0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-eqz v3, :cond_0

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    return-void
.end method

.method public final commitCompletion(Landroid/view/inputmethod/CompletionInfo;)Z
    .locals 0

    .line 1
    iget-boolean p1, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    :cond_0
    return p1
.end method

.method public final commitContent(Landroid/view/inputmethod/InputContentInfo;ILandroid/os/Bundle;)Z
    .locals 0

    .line 1
    iget-boolean p1, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    :cond_0
    return p1
.end method

.method public final commitCorrection(Landroid/view/inputmethod/CorrectionInfo;)Z
    .locals 0

    .line 1
    iget-boolean p1, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    iget-boolean p1, p0, LF/A;->b:Z

    .line 6
    .line 7
    :cond_0
    return p1
.end method

.method public final commitText(Ljava/lang/CharSequence;I)Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LM0/a;

    .line 6
    .line 7
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {v1, p1, p2}, LM0/a;-><init>(Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v1}, LF/A;->a(LM0/g;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return v0
.end method

.method public final deleteSurroundingText(II)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LM0/e;

    .line 6
    .line 7
    invoke-direct {v0, p1, p2}, LM0/e;-><init>(II)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, LF/A;->a(LM0/g;)V

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    return p1

    .line 15
    :cond_0
    return v0
.end method

.method public final deleteSurroundingTextInCodePoints(II)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LM0/f;

    .line 6
    .line 7
    invoke-direct {v0, p1, p2}, LM0/f;-><init>(II)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, LF/A;->a(LM0/g;)V

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    return p1

    .line 15
    :cond_0
    return v0
.end method

.method public final endBatchEdit()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LF/A;->b()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    return v0
.end method

.method public final finishComposingText()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LM0/i;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, LF/A;->a(LM0/g;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    :cond_0
    return v0
.end method

.method public final getCursorCapsMode(I)I
    .locals 4

    .line 1
    iget-object v0, p0, LF/A;->g:LM0/x;

    .line 2
    .line 3
    iget-object v1, v0, LM0/x;->a:LH0/g;

    .line 4
    .line 5
    iget-object v1, v1, LH0/g;->e:Ljava/lang/String;

    .line 6
    .line 7
    iget-wide v2, v0, LM0/x;->b:J

    .line 8
    .line 9
    invoke-static {v2, v3}, LH0/N;->f(J)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {v1, v0, p1}, Landroid/text/TextUtils;->getCapsMode(Ljava/lang/CharSequence;II)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1
.end method

.method public final getExtractedText(Landroid/view/inputmethod/ExtractedTextRequest;I)Landroid/view/inputmethod/ExtractedText;
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    and-int/2addr p2, v0

    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz p2, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    move v0, v1

    .line 8
    :goto_0
    iput-boolean v0, p0, LF/A;->i:Z

    .line 9
    .line 10
    if-eqz v0, :cond_2

    .line 11
    .line 12
    if-eqz p1, :cond_1

    .line 13
    .line 14
    iget v1, p1, Landroid/view/inputmethod/ExtractedTextRequest;->token:I

    .line 15
    .line 16
    :cond_1
    iput v1, p0, LF/A;->h:I

    .line 17
    .line 18
    :cond_2
    iget-object p1, p0, LF/A;->g:LM0/x;

    .line 19
    .line 20
    invoke-static {p1}, LF/v;->d(LM0/x;)Landroid/view/inputmethod/ExtractedText;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    return-object p1
.end method

.method public final getHandler()Landroid/os/Handler;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getSelectedText(I)Ljava/lang/CharSequence;
    .locals 2

    .line 1
    iget-object p1, p0, LF/A;->g:LM0/x;

    .line 2
    .line 3
    iget-wide v0, p1, LM0/x;->b:J

    .line 4
    .line 5
    invoke-static {v0, v1}, LH0/N;->c(J)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return-object p1

    .line 13
    :cond_0
    iget-object p1, p0, LF/A;->g:LM0/x;

    .line 14
    .line 15
    invoke-static {p1}, LX1/a;->M(LM0/x;)LH0/g;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 20
    .line 21
    return-object p1
.end method

.method public final getTextAfterCursor(II)Ljava/lang/CharSequence;
    .locals 0

    .line 1
    iget-object p2, p0, LF/A;->g:LM0/x;

    .line 2
    .line 3
    invoke-static {p2, p1}, LX1/a;->N(LM0/x;I)LH0/g;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 8
    .line 9
    return-object p1
.end method

.method public final getTextBeforeCursor(II)Ljava/lang/CharSequence;
    .locals 0

    .line 1
    iget-object p2, p0, LF/A;->g:LM0/x;

    .line 2
    .line 3
    invoke-static {p2, p1}, LX1/a;->O(LM0/x;I)LH0/g;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 8
    .line 9
    return-object p1
.end method

.method public final performContextMenuAction(I)Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    packed-switch p1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    return v0

    .line 10
    :pswitch_0
    const/16 p1, 0x117

    .line 11
    .line 12
    invoke-virtual {p0, p1}, LF/A;->c(I)V

    .line 13
    .line 14
    .line 15
    return v0

    .line 16
    :pswitch_1
    const/16 p1, 0x116

    .line 17
    .line 18
    invoke-virtual {p0, p1}, LF/A;->c(I)V

    .line 19
    .line 20
    .line 21
    return v0

    .line 22
    :pswitch_2
    const/16 p1, 0x115

    .line 23
    .line 24
    invoke-virtual {p0, p1}, LF/A;->c(I)V

    .line 25
    .line 26
    .line 27
    return v0

    .line 28
    :pswitch_3
    new-instance p1, LM0/w;

    .line 29
    .line 30
    iget-object v1, p0, LF/A;->g:LM0/x;

    .line 31
    .line 32
    iget-object v1, v1, LM0/x;->a:LH0/g;

    .line 33
    .line 34
    iget-object v1, v1, LH0/g;->e:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-direct {p1, v0, v1}, LM0/w;-><init>(II)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0, p1}, LF/A;->a(LM0/g;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    return v0

    .line 47
    :pswitch_data_0
    .packed-switch 0x102001f
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final performEditorAction(I)Z
    .locals 3

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    packed-switch p1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v2, "IME sends unsupported Editor Action: "

    .line 14
    .line 15
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    const-string v1, "RecordingIC"

    .line 26
    .line 27
    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 28
    .line 29
    .line 30
    :cond_0
    move p1, v0

    .line 31
    goto :goto_0

    .line 32
    :pswitch_0
    const/4 p1, 0x5

    .line 33
    goto :goto_0

    .line 34
    :pswitch_1
    const/4 p1, 0x7

    .line 35
    goto :goto_0

    .line 36
    :pswitch_2
    const/4 p1, 0x6

    .line 37
    goto :goto_0

    .line 38
    :pswitch_3
    const/4 p1, 0x4

    .line 39
    goto :goto_0

    .line 40
    :pswitch_4
    const/4 p1, 0x3

    .line 41
    goto :goto_0

    .line 42
    :pswitch_5
    const/4 p1, 0x2

    .line 43
    :goto_0
    iget-object v1, p0, LF/A;->a:LA0/h;

    .line 44
    .line 45
    iget-object v1, v1, LA0/h;->e:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v1, LF/z;

    .line 48
    .line 49
    iget-object v1, v1, LF/z;->d:LU1/c;

    .line 50
    .line 51
    new-instance v2, LM0/j;

    .line 52
    .line 53
    invoke-direct {v2, p1}, LM0/j;-><init>(I)V

    .line 54
    .line 55
    .line 56
    invoke-interface {v1, v2}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    :cond_1
    return v0

    .line 60
    nop

    .line 61
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final performHandwritingGesture(Landroid/view/inputmethod/HandwritingGesture;Ljava/util/concurrent/Executor;Ljava/util/function/IntConsumer;)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 8
    .line 9
    const/16 v4, 0x22

    .line 10
    .line 11
    if-lt v3, v4, :cond_35

    .line 12
    .line 13
    new-instance v3, LB/y;

    .line 14
    .line 15
    const/4 v4, 0x5

    .line 16
    invoke-direct {v3, v4, v0}, LB/y;-><init>(ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v4, v0, LF/A;->c:Lw/S;

    .line 20
    .line 21
    const/4 v5, 0x3

    .line 22
    if-eqz v4, :cond_32

    .line 23
    .line 24
    iget-object v6, v4, Lw/S;->j:LH0/g;

    .line 25
    .line 26
    if-nez v6, :cond_0

    .line 27
    .line 28
    goto/16 :goto_16

    .line 29
    .line 30
    :cond_0
    invoke-virtual {v4}, Lw/S;->d()Lw/p0;

    .line 31
    .line 32
    .line 33
    move-result-object v7

    .line 34
    if-eqz v7, :cond_1

    .line 35
    .line 36
    iget-object v7, v7, Lw/p0;->a:LH0/L;

    .line 37
    .line 38
    iget-object v7, v7, LH0/L;->a:LH0/K;

    .line 39
    .line 40
    if-eqz v7, :cond_1

    .line 41
    .line 42
    iget-object v7, v7, LH0/K;->a:LH0/g;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    const/4 v7, 0x0

    .line 46
    :goto_0
    invoke-virtual {v6, v7}, LH0/g;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v7

    .line 50
    if-nez v7, :cond_2

    .line 51
    .line 52
    goto/16 :goto_16

    .line 53
    .line 54
    :cond_2
    invoke-static/range {p1 .. p1}, LB/x;->t(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    const-wide v9, 0xffffffffL

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    const/4 v7, 0x0

    .line 64
    const/16 v11, 0x20

    .line 65
    .line 66
    const/4 v12, 0x1

    .line 67
    iget-object v13, v0, LF/A;->d:LH/m0;

    .line 68
    .line 69
    if-eqz v5, :cond_6

    .line 70
    .line 71
    invoke-static/range {p1 .. p1}, LB/x;->n(Ljava/lang/Object;)Landroid/view/inputmethod/SelectGesture;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    invoke-static {v5}, LB/x;->i(Landroid/view/inputmethod/SelectGesture;)Landroid/graphics/RectF;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    invoke-static {v6}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    invoke-static {v5}, LB/x;->c(Landroid/view/inputmethod/SelectGesture;)I

    .line 84
    .line 85
    .line 86
    move-result v8

    .line 87
    if-eq v8, v12, :cond_3

    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_3
    move v7, v12

    .line 91
    :goto_1
    invoke-static {v4, v6, v7}, LF/v;->i(Lw/S;Lc0/c;I)J

    .line 92
    .line 93
    .line 94
    move-result-wide v6

    .line 95
    invoke-static {v6, v7}, LH0/N;->c(J)Z

    .line 96
    .line 97
    .line 98
    move-result v4

    .line 99
    if-eqz v4, :cond_4

    .line 100
    .line 101
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 102
    .line 103
    .line 104
    move-result-object v4

    .line 105
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 106
    .line 107
    .line 108
    move-result v5

    .line 109
    goto/16 :goto_16

    .line 110
    .line 111
    :cond_4
    new-instance v4, LM0/w;

    .line 112
    .line 113
    shr-long v14, v6, v11

    .line 114
    .line 115
    long-to-int v5, v14

    .line 116
    and-long/2addr v6, v9

    .line 117
    long-to-int v6, v6

    .line 118
    invoke-direct {v4, v5, v6}, LM0/w;-><init>(II)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v3, v4}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    if-eqz v13, :cond_5

    .line 125
    .line 126
    invoke-virtual {v13, v12}, LH/m0;->h(Z)V

    .line 127
    .line 128
    .line 129
    :cond_5
    :goto_2
    move v5, v12

    .line 130
    goto/16 :goto_16

    .line 131
    .line 132
    :cond_6
    invoke-static/range {p1 .. p1}, LF/p;->q(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v5

    .line 136
    if-eqz v5, :cond_a

    .line 137
    .line 138
    invoke-static/range {p1 .. p1}, LF/p;->k(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteGesture;

    .line 139
    .line 140
    .line 141
    move-result-object v5

    .line 142
    invoke-static {v5}, LB/x;->a(Landroid/view/inputmethod/DeleteGesture;)I

    .line 143
    .line 144
    .line 145
    move-result v8

    .line 146
    if-eq v8, v12, :cond_7

    .line 147
    .line 148
    move v8, v7

    .line 149
    goto :goto_3

    .line 150
    :cond_7
    move v8, v12

    .line 151
    :goto_3
    invoke-static {v5}, LB/x;->g(Landroid/view/inputmethod/DeleteGesture;)Landroid/graphics/RectF;

    .line 152
    .line 153
    .line 154
    move-result-object v9

    .line 155
    invoke-static {v9}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 156
    .line 157
    .line 158
    move-result-object v9

    .line 159
    invoke-static {v4, v9, v8}, LF/v;->i(Lw/S;Lc0/c;I)J

    .line 160
    .line 161
    .line 162
    move-result-wide v9

    .line 163
    invoke-static {v9, v10}, LH0/N;->c(J)Z

    .line 164
    .line 165
    .line 166
    move-result v4

    .line 167
    if-eqz v4, :cond_8

    .line 168
    .line 169
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 170
    .line 171
    .line 172
    move-result-object v4

    .line 173
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 174
    .line 175
    .line 176
    move-result v5

    .line 177
    goto/16 :goto_16

    .line 178
    .line 179
    :cond_8
    if-ne v8, v12, :cond_9

    .line 180
    .line 181
    move v7, v12

    .line 182
    :cond_9
    invoke-static {v9, v10, v6, v7, v3}, LF/v;->n(JLH0/g;ZLB/y;)V

    .line 183
    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_a
    invoke-static/range {p1 .. p1}, LF/p;->x(Ljava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v5

    .line 190
    if-eqz v5, :cond_d

    .line 191
    .line 192
    invoke-static/range {p1 .. p1}, LF/p;->m(Ljava/lang/Object;)Landroid/view/inputmethod/SelectRangeGesture;

    .line 193
    .line 194
    .line 195
    move-result-object v5

    .line 196
    invoke-static {v5}, LF/p;->h(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 197
    .line 198
    .line 199
    move-result-object v6

    .line 200
    invoke-static {v6}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 201
    .line 202
    .line 203
    move-result-object v6

    .line 204
    invoke-static {v5}, LF/p;->w(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 205
    .line 206
    .line 207
    move-result-object v8

    .line 208
    invoke-static {v8}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 209
    .line 210
    .line 211
    move-result-object v8

    .line 212
    invoke-static {v5}, LB/x;->d(Landroid/view/inputmethod/SelectRangeGesture;)I

    .line 213
    .line 214
    .line 215
    move-result v14

    .line 216
    if-eq v14, v12, :cond_b

    .line 217
    .line 218
    goto :goto_4

    .line 219
    :cond_b
    move v7, v12

    .line 220
    :goto_4
    invoke-static {v4, v6, v8, v7}, LF/v;->b(Lw/S;Lc0/c;Lc0/c;I)J

    .line 221
    .line 222
    .line 223
    move-result-wide v6

    .line 224
    invoke-static {v6, v7}, LH0/N;->c(J)Z

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    if-eqz v4, :cond_c

    .line 229
    .line 230
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 231
    .line 232
    .line 233
    move-result-object v4

    .line 234
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 235
    .line 236
    .line 237
    move-result v5

    .line 238
    goto/16 :goto_16

    .line 239
    .line 240
    :cond_c
    new-instance v4, LM0/w;

    .line 241
    .line 242
    shr-long v14, v6, v11

    .line 243
    .line 244
    long-to-int v5, v14

    .line 245
    and-long/2addr v6, v9

    .line 246
    long-to-int v6, v6

    .line 247
    invoke-direct {v4, v5, v6}, LM0/w;-><init>(II)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v3, v4}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    if-eqz v13, :cond_5

    .line 254
    .line 255
    invoke-virtual {v13, v12}, LH/m0;->h(Z)V

    .line 256
    .line 257
    .line 258
    goto/16 :goto_2

    .line 259
    .line 260
    :cond_d
    invoke-static/range {p1 .. p1}, LF/p;->z(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    move-result v5

    .line 264
    if-eqz v5, :cond_11

    .line 265
    .line 266
    invoke-static/range {p1 .. p1}, LF/p;->l(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteRangeGesture;

    .line 267
    .line 268
    .line 269
    move-result-object v5

    .line 270
    invoke-static {v5}, LB/x;->b(Landroid/view/inputmethod/DeleteRangeGesture;)I

    .line 271
    .line 272
    .line 273
    move-result v8

    .line 274
    if-eq v8, v12, :cond_e

    .line 275
    .line 276
    move v8, v7

    .line 277
    goto :goto_5

    .line 278
    :cond_e
    move v8, v12

    .line 279
    :goto_5
    invoke-static {v5}, LB/x;->h(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 280
    .line 281
    .line 282
    move-result-object v9

    .line 283
    invoke-static {v9}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 284
    .line 285
    .line 286
    move-result-object v9

    .line 287
    invoke-static {v5}, LB/x;->u(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 288
    .line 289
    .line 290
    move-result-object v10

    .line 291
    invoke-static {v10}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 292
    .line 293
    .line 294
    move-result-object v10

    .line 295
    invoke-static {v4, v9, v10, v8}, LF/v;->b(Lw/S;Lc0/c;Lc0/c;I)J

    .line 296
    .line 297
    .line 298
    move-result-wide v9

    .line 299
    invoke-static {v9, v10}, LH0/N;->c(J)Z

    .line 300
    .line 301
    .line 302
    move-result v4

    .line 303
    if-eqz v4, :cond_f

    .line 304
    .line 305
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 310
    .line 311
    .line 312
    move-result v5

    .line 313
    goto/16 :goto_16

    .line 314
    .line 315
    :cond_f
    if-ne v8, v12, :cond_10

    .line 316
    .line 317
    move v7, v12

    .line 318
    :cond_10
    invoke-static {v9, v10, v6, v7, v3}, LF/v;->n(JLH0/g;ZLB/y;)V

    .line 319
    .line 320
    .line 321
    goto/16 :goto_2

    .line 322
    .line 323
    :cond_11
    invoke-static/range {p1 .. p1}, LB/x;->A(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    move-result v5

    .line 327
    const/4 v9, 0x2

    .line 328
    iget-object v10, v0, LF/A;->e:Lx0/J0;

    .line 329
    .line 330
    const/4 v13, -0x1

    .line 331
    if-eqz v5, :cond_1a

    .line 332
    .line 333
    invoke-static/range {p1 .. p1}, LB/x;->l(Ljava/lang/Object;)Landroid/view/inputmethod/JoinOrSplitGesture;

    .line 334
    .line 335
    .line 336
    move-result-object v5

    .line 337
    if-nez v10, :cond_12

    .line 338
    .line 339
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 340
    .line 341
    .line 342
    move-result-object v4

    .line 343
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 344
    .line 345
    .line 346
    move-result v5

    .line 347
    goto/16 :goto_16

    .line 348
    .line 349
    :cond_12
    invoke-static {v5}, LF/p;->f(Landroid/view/inputmethod/JoinOrSplitGesture;)Landroid/graphics/PointF;

    .line 350
    .line 351
    .line 352
    move-result-object v8

    .line 353
    invoke-static {v8}, LF/v;->e(Landroid/graphics/PointF;)J

    .line 354
    .line 355
    .line 356
    move-result-wide v14

    .line 357
    invoke-static {v4, v14, v15, v10}, LF/v;->a(Lw/S;JLx0/J0;)I

    .line 358
    .line 359
    .line 360
    move-result v8

    .line 361
    if-eq v8, v13, :cond_19

    .line 362
    .line 363
    invoke-virtual {v4}, Lw/S;->d()Lw/p0;

    .line 364
    .line 365
    .line 366
    move-result-object v4

    .line 367
    if-eqz v4, :cond_13

    .line 368
    .line 369
    iget-object v4, v4, Lw/p0;->a:LH0/L;

    .line 370
    .line 371
    invoke-static {v4, v8}, LF/v;->c(LH0/L;I)Z

    .line 372
    .line 373
    .line 374
    move-result v4

    .line 375
    if-ne v4, v12, :cond_13

    .line 376
    .line 377
    goto :goto_9

    .line 378
    :cond_13
    move v4, v8

    .line 379
    :goto_6
    if-lez v4, :cond_15

    .line 380
    .line 381
    invoke-static {v6, v4}, Ljava/lang/Character;->codePointBefore(Ljava/lang/CharSequence;I)I

    .line 382
    .line 383
    .line 384
    move-result v5

    .line 385
    invoke-static {v5}, LF/v;->k(I)Z

    .line 386
    .line 387
    .line 388
    move-result v10

    .line 389
    if-nez v10, :cond_14

    .line 390
    .line 391
    goto :goto_7

    .line 392
    :cond_14
    invoke-static {v5}, Ljava/lang/Character;->charCount(I)I

    .line 393
    .line 394
    .line 395
    move-result v5

    .line 396
    sub-int/2addr v4, v5

    .line 397
    goto :goto_6

    .line 398
    :cond_15
    :goto_7
    iget-object v5, v6, LH0/g;->e:Ljava/lang/String;

    .line 399
    .line 400
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 401
    .line 402
    .line 403
    move-result v5

    .line 404
    if-ge v8, v5, :cond_17

    .line 405
    .line 406
    invoke-static {v6, v8}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 407
    .line 408
    .line 409
    move-result v5

    .line 410
    invoke-static {v5}, LF/v;->k(I)Z

    .line 411
    .line 412
    .line 413
    move-result v10

    .line 414
    if-nez v10, :cond_16

    .line 415
    .line 416
    goto :goto_8

    .line 417
    :cond_16
    invoke-static {v5}, Ljava/lang/Character;->charCount(I)I

    .line 418
    .line 419
    .line 420
    move-result v5

    .line 421
    add-int/2addr v8, v5

    .line 422
    goto :goto_7

    .line 423
    :cond_17
    :goto_8
    invoke-static {v4, v8}, LH0/F;->b(II)J

    .line 424
    .line 425
    .line 426
    move-result-wide v4

    .line 427
    invoke-static {v4, v5}, LH0/N;->c(J)Z

    .line 428
    .line 429
    .line 430
    move-result v8

    .line 431
    if-eqz v8, :cond_18

    .line 432
    .line 433
    shr-long/2addr v4, v11

    .line 434
    long-to-int v4, v4

    .line 435
    new-instance v5, LM0/w;

    .line 436
    .line 437
    invoke-direct {v5, v4, v4}, LM0/w;-><init>(II)V

    .line 438
    .line 439
    .line 440
    new-instance v4, LM0/a;

    .line 441
    .line 442
    const-string v6, " "

    .line 443
    .line 444
    invoke-direct {v4, v6, v12}, LM0/a;-><init>(Ljava/lang/String;I)V

    .line 445
    .line 446
    .line 447
    new-array v6, v9, [LM0/g;

    .line 448
    .line 449
    aput-object v5, v6, v7

    .line 450
    .line 451
    aput-object v4, v6, v12

    .line 452
    .line 453
    new-instance v4, LF/q;

    .line 454
    .line 455
    invoke-direct {v4, v6}, LF/q;-><init>([LM0/g;)V

    .line 456
    .line 457
    .line 458
    invoke-virtual {v3, v4}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    goto/16 :goto_2

    .line 462
    .line 463
    :cond_18
    invoke-static {v4, v5, v6, v7, v3}, LF/v;->n(JLH0/g;ZLB/y;)V

    .line 464
    .line 465
    .line 466
    goto/16 :goto_2

    .line 467
    .line 468
    :cond_19
    :goto_9
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 469
    .line 470
    .line 471
    move-result-object v4

    .line 472
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 473
    .line 474
    .line 475
    move-result v5

    .line 476
    goto/16 :goto_16

    .line 477
    .line 478
    :cond_1a
    invoke-static/range {p1 .. p1}, LB/x;->w(Ljava/lang/Object;)Z

    .line 479
    .line 480
    .line 481
    move-result v5

    .line 482
    if-eqz v5, :cond_1e

    .line 483
    .line 484
    invoke-static/range {p1 .. p1}, LB/x;->k(Ljava/lang/Object;)Landroid/view/inputmethod/InsertGesture;

    .line 485
    .line 486
    .line 487
    move-result-object v5

    .line 488
    if-nez v10, :cond_1b

    .line 489
    .line 490
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 491
    .line 492
    .line 493
    move-result-object v4

    .line 494
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 495
    .line 496
    .line 497
    move-result v5

    .line 498
    goto/16 :goto_16

    .line 499
    .line 500
    :cond_1b
    invoke-static {v5}, LB/x;->f(Landroid/view/inputmethod/InsertGesture;)Landroid/graphics/PointF;

    .line 501
    .line 502
    .line 503
    move-result-object v6

    .line 504
    invoke-static {v6}, LF/v;->e(Landroid/graphics/PointF;)J

    .line 505
    .line 506
    .line 507
    move-result-wide v14

    .line 508
    invoke-static {v4, v14, v15, v10}, LF/v;->a(Lw/S;JLx0/J0;)I

    .line 509
    .line 510
    .line 511
    move-result v6

    .line 512
    if-eq v6, v13, :cond_1d

    .line 513
    .line 514
    invoke-virtual {v4}, Lw/S;->d()Lw/p0;

    .line 515
    .line 516
    .line 517
    move-result-object v4

    .line 518
    if-eqz v4, :cond_1c

    .line 519
    .line 520
    iget-object v4, v4, Lw/p0;->a:LH0/L;

    .line 521
    .line 522
    invoke-static {v4, v6}, LF/v;->c(LH0/L;I)Z

    .line 523
    .line 524
    .line 525
    move-result v4

    .line 526
    if-ne v4, v12, :cond_1c

    .line 527
    .line 528
    goto :goto_a

    .line 529
    :cond_1c
    invoke-static {v5}, LF/p;->o(Landroid/view/inputmethod/InsertGesture;)Ljava/lang/String;

    .line 530
    .line 531
    .line 532
    move-result-object v4

    .line 533
    new-instance v5, LM0/w;

    .line 534
    .line 535
    invoke-direct {v5, v6, v6}, LM0/w;-><init>(II)V

    .line 536
    .line 537
    .line 538
    new-instance v6, LM0/a;

    .line 539
    .line 540
    invoke-direct {v6, v4, v12}, LM0/a;-><init>(Ljava/lang/String;I)V

    .line 541
    .line 542
    .line 543
    new-array v4, v9, [LM0/g;

    .line 544
    .line 545
    aput-object v5, v4, v7

    .line 546
    .line 547
    aput-object v6, v4, v12

    .line 548
    .line 549
    new-instance v5, LF/q;

    .line 550
    .line 551
    invoke-direct {v5, v4}, LF/q;-><init>([LM0/g;)V

    .line 552
    .line 553
    .line 554
    invoke-virtual {v3, v5}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 555
    .line 556
    .line 557
    goto/16 :goto_2

    .line 558
    .line 559
    :cond_1d
    :goto_a
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 560
    .line 561
    .line 562
    move-result-object v4

    .line 563
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 564
    .line 565
    .line 566
    move-result v5

    .line 567
    goto/16 :goto_16

    .line 568
    .line 569
    :cond_1e
    invoke-static/range {p1 .. p1}, LB/x;->y(Ljava/lang/Object;)Z

    .line 570
    .line 571
    .line 572
    move-result v5

    .line 573
    if-eqz v5, :cond_31

    .line 574
    .line 575
    invoke-static/range {p1 .. p1}, LB/x;->m(Ljava/lang/Object;)Landroid/view/inputmethod/RemoveSpaceGesture;

    .line 576
    .line 577
    .line 578
    move-result-object v5

    .line 579
    invoke-virtual {v4}, Lw/S;->d()Lw/p0;

    .line 580
    .line 581
    .line 582
    move-result-object v14

    .line 583
    if-eqz v14, :cond_1f

    .line 584
    .line 585
    iget-object v14, v14, Lw/p0;->a:LH0/L;

    .line 586
    .line 587
    goto :goto_b

    .line 588
    :cond_1f
    const/4 v14, 0x0

    .line 589
    :goto_b
    invoke-static {v5}, LF/p;->g(Landroid/view/inputmethod/RemoveSpaceGesture;)Landroid/graphics/PointF;

    .line 590
    .line 591
    .line 592
    move-result-object v15

    .line 593
    move/from16 v16, v11

    .line 594
    .line 595
    move/from16 v17, v12

    .line 596
    .line 597
    invoke-static {v15}, LF/v;->e(Landroid/graphics/PointF;)J

    .line 598
    .line 599
    .line 600
    move-result-wide v11

    .line 601
    invoke-static {v5}, LF/p;->v(Landroid/view/inputmethod/RemoveSpaceGesture;)Landroid/graphics/PointF;

    .line 602
    .line 603
    .line 604
    move-result-object v15

    .line 605
    invoke-static {v15}, LF/v;->e(Landroid/graphics/PointF;)J

    .line 606
    .line 607
    .line 608
    move-result-wide v7

    .line 609
    invoke-virtual {v4}, Lw/S;->c()Lu0/r;

    .line 610
    .line 611
    .line 612
    move-result-object v4

    .line 613
    if-eqz v14, :cond_24

    .line 614
    .line 615
    iget-object v14, v14, LH0/L;->b:LH0/p;

    .line 616
    .line 617
    if-nez v4, :cond_20

    .line 618
    .line 619
    goto :goto_d

    .line 620
    :cond_20
    invoke-interface {v4, v11, v12}, Lu0/r;->S(J)J

    .line 621
    .line 622
    .line 623
    move-result-wide v11

    .line 624
    invoke-interface {v4, v7, v8}, Lu0/r;->S(J)J

    .line 625
    .line 626
    .line 627
    move-result-wide v7

    .line 628
    invoke-static {v14, v11, v12, v10}, LF/v;->h(LH0/p;JLx0/J0;)I

    .line 629
    .line 630
    .line 631
    move-result v4

    .line 632
    invoke-static {v14, v7, v8, v10}, LF/v;->h(LH0/p;JLx0/J0;)I

    .line 633
    .line 634
    .line 635
    move-result v10

    .line 636
    if-ne v4, v13, :cond_21

    .line 637
    .line 638
    if-ne v10, v13, :cond_23

    .line 639
    .line 640
    sget-wide v7, LH0/N;->b:J

    .line 641
    .line 642
    goto :goto_e

    .line 643
    :cond_21
    if-ne v10, v13, :cond_22

    .line 644
    .line 645
    goto :goto_c

    .line 646
    :cond_22
    invoke-static {v4, v10}, Ljava/lang/Math;->min(II)I

    .line 647
    .line 648
    .line 649
    move-result v4

    .line 650
    :goto_c
    move v10, v4

    .line 651
    :cond_23
    invoke-virtual {v14, v10}, LH0/p;->f(I)F

    .line 652
    .line 653
    .line 654
    move-result v4

    .line 655
    invoke-virtual {v14, v10}, LH0/p;->b(I)F

    .line 656
    .line 657
    .line 658
    move-result v10

    .line 659
    add-float/2addr v10, v4

    .line 660
    int-to-float v4, v9

    .line 661
    div-float/2addr v10, v4

    .line 662
    new-instance v4, Lc0/c;

    .line 663
    .line 664
    shr-long v11, v11, v16

    .line 665
    .line 666
    long-to-int v11, v11

    .line 667
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 668
    .line 669
    .line 670
    move-result v12

    .line 671
    shr-long v7, v7, v16

    .line 672
    .line 673
    long-to-int v7, v7

    .line 674
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 675
    .line 676
    .line 677
    move-result v8

    .line 678
    invoke-static {v12, v8}, Ljava/lang/Math;->min(FF)F

    .line 679
    .line 680
    .line 681
    move-result v8

    .line 682
    const v12, 0x3dcccccd    # 0.1f

    .line 683
    .line 684
    .line 685
    sub-float v15, v10, v12

    .line 686
    .line 687
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 688
    .line 689
    .line 690
    move-result v11

    .line 691
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 692
    .line 693
    .line 694
    move-result v7

    .line 695
    invoke-static {v11, v7}, Ljava/lang/Math;->max(FF)F

    .line 696
    .line 697
    .line 698
    move-result v7

    .line 699
    add-float/2addr v10, v12

    .line 700
    invoke-direct {v4, v8, v15, v7, v10}, Lc0/c;-><init>(FFFF)V

    .line 701
    .line 702
    .line 703
    sget-object v7, LH0/J;->a:LH/z;

    .line 704
    .line 705
    const/4 v8, 0x0

    .line 706
    invoke-virtual {v14, v4, v8, v7}, LH0/p;->h(Lc0/c;ILH/z;)J

    .line 707
    .line 708
    .line 709
    move-result-wide v10

    .line 710
    move-wide v7, v10

    .line 711
    goto :goto_e

    .line 712
    :cond_24
    :goto_d
    sget-wide v7, LH0/N;->b:J

    .line 713
    .line 714
    :goto_e
    invoke-static {v7, v8}, LH0/N;->c(J)Z

    .line 715
    .line 716
    .line 717
    move-result v4

    .line 718
    if-eqz v4, :cond_25

    .line 719
    .line 720
    invoke-static {v5}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 721
    .line 722
    .line 723
    move-result-object v4

    .line 724
    invoke-static {v4, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 725
    .line 726
    .line 727
    move-result v5

    .line 728
    goto/16 :goto_16

    .line 729
    .line 730
    :cond_25
    invoke-static {v7, v8}, LH0/N;->f(J)I

    .line 731
    .line 732
    .line 733
    move-result v4

    .line 734
    invoke-static {v7, v8}, LH0/N;->e(J)I

    .line 735
    .line 736
    .line 737
    move-result v10

    .line 738
    invoke-virtual {v6, v4, v10}, LH0/g;->a(II)LH0/g;

    .line 739
    .line 740
    .line 741
    move-result-object v4

    .line 742
    iget-object v4, v4, LH0/g;->e:Ljava/lang/String;

    .line 743
    .line 744
    const-string v6, "\\s+"

    .line 745
    .line 746
    invoke-static {v6}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 747
    .line 748
    .line 749
    move-result-object v6

    .line 750
    const-string v10, "compile(...)"

    .line 751
    .line 752
    invoke-static {v6, v10}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 753
    .line 754
    .line 755
    const-string v10, "input"

    .line 756
    .line 757
    invoke-static {v4, v10}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 758
    .line 759
    .line 760
    invoke-virtual {v6, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 761
    .line 762
    .line 763
    move-result-object v6

    .line 764
    const-string v10, "matcher(...)"

    .line 765
    .line 766
    invoke-static {v6, v10}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 767
    .line 768
    .line 769
    const/4 v11, 0x0

    .line 770
    invoke-virtual {v6, v11}, Ljava/util/regex/Matcher;->find(I)Z

    .line 771
    .line 772
    .line 773
    move-result v12

    .line 774
    const/16 v11, 0x9

    .line 775
    .line 776
    if-nez v12, :cond_26

    .line 777
    .line 778
    const/4 v12, 0x0

    .line 779
    goto :goto_f

    .line 780
    :cond_26
    new-instance v12, LF/r;

    .line 781
    .line 782
    invoke-direct {v12, v11, v6, v4}, LF/r;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 783
    .line 784
    .line 785
    :goto_f
    if-nez v12, :cond_27

    .line 786
    .line 787
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 788
    .line 789
    .line 790
    move-result-object v4

    .line 791
    move-object/from16 v20, v5

    .line 792
    .line 793
    move v0, v13

    .line 794
    move v9, v0

    .line 795
    move v11, v9

    .line 796
    goto/16 :goto_14

    .line 797
    .line 798
    :cond_27
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 799
    .line 800
    .line 801
    move-result v6

    .line 802
    new-instance v14, Ljava/lang/StringBuilder;

    .line 803
    .line 804
    invoke-direct {v14, v6}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 805
    .line 806
    .line 807
    move-object v15, v12

    .line 808
    move v9, v13

    .line 809
    const/4 v12, 0x0

    .line 810
    :goto_10
    invoke-virtual {v15}, LF/r;->s()LY1/d;

    .line 811
    .line 812
    .line 813
    move-result-object v11

    .line 814
    iget v11, v11, LY1/b;->d:I

    .line 815
    .line 816
    invoke-virtual {v14, v4, v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 817
    .line 818
    .line 819
    if-ne v9, v13, :cond_28

    .line 820
    .line 821
    invoke-virtual {v15}, LF/r;->s()LY1/d;

    .line 822
    .line 823
    .line 824
    move-result-object v9

    .line 825
    iget v9, v9, LY1/b;->d:I

    .line 826
    .line 827
    :cond_28
    invoke-virtual {v15}, LF/r;->s()LY1/d;

    .line 828
    .line 829
    .line 830
    move-result-object v11

    .line 831
    iget v11, v11, LY1/b;->e:I

    .line 832
    .line 833
    add-int/lit8 v11, v11, 0x1

    .line 834
    .line 835
    const-string v12, ""

    .line 836
    .line 837
    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 838
    .line 839
    .line 840
    invoke-virtual {v15}, LF/r;->s()LY1/d;

    .line 841
    .line 842
    .line 843
    move-result-object v12

    .line 844
    iget v12, v12, LY1/b;->e:I

    .line 845
    .line 846
    add-int/lit8 v12, v12, 0x1

    .line 847
    .line 848
    iget-object v13, v15, LF/r;->f:Ljava/lang/Object;

    .line 849
    .line 850
    check-cast v13, Ljava/lang/String;

    .line 851
    .line 852
    iget-object v15, v15, LF/r;->e:Ljava/lang/Object;

    .line 853
    .line 854
    check-cast v15, Ljava/util/regex/Matcher;

    .line 855
    .line 856
    invoke-virtual {v15}, Ljava/util/regex/Matcher;->end()I

    .line 857
    .line 858
    .line 859
    move-result v19

    .line 860
    invoke-virtual {v15}, Ljava/util/regex/Matcher;->end()I

    .line 861
    .line 862
    .line 863
    move-result v0

    .line 864
    move-object/from16 v20, v5

    .line 865
    .line 866
    invoke-virtual {v15}, Ljava/util/regex/Matcher;->start()I

    .line 867
    .line 868
    .line 869
    move-result v5

    .line 870
    if-ne v0, v5, :cond_29

    .line 871
    .line 872
    move/from16 v0, v17

    .line 873
    .line 874
    goto :goto_11

    .line 875
    :cond_29
    const/4 v0, 0x0

    .line 876
    :goto_11
    add-int v0, v19, v0

    .line 877
    .line 878
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    .line 879
    .line 880
    .line 881
    move-result v5

    .line 882
    if-gt v0, v5, :cond_2b

    .line 883
    .line 884
    invoke-virtual {v15}, Ljava/util/regex/Matcher;->pattern()Ljava/util/regex/Pattern;

    .line 885
    .line 886
    .line 887
    move-result-object v5

    .line 888
    invoke-virtual {v5, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 889
    .line 890
    .line 891
    move-result-object v5

    .line 892
    invoke-static {v5, v10}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 893
    .line 894
    .line 895
    invoke-virtual {v5, v0}, Ljava/util/regex/Matcher;->find(I)Z

    .line 896
    .line 897
    .line 898
    move-result v0

    .line 899
    if-nez v0, :cond_2a

    .line 900
    .line 901
    const/4 v0, 0x0

    .line 902
    const/16 v15, 0x9

    .line 903
    .line 904
    goto :goto_12

    .line 905
    :cond_2a
    new-instance v0, LF/r;

    .line 906
    .line 907
    const/16 v15, 0x9

    .line 908
    .line 909
    invoke-direct {v0, v15, v5, v13}, LF/r;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 910
    .line 911
    .line 912
    goto :goto_12

    .line 913
    :cond_2b
    const/16 v15, 0x9

    .line 914
    .line 915
    const/4 v0, 0x0

    .line 916
    :goto_12
    if-ge v12, v6, :cond_2d

    .line 917
    .line 918
    if-nez v0, :cond_2c

    .line 919
    .line 920
    goto :goto_13

    .line 921
    :cond_2c
    move-object v15, v0

    .line 922
    move-object/from16 v5, v20

    .line 923
    .line 924
    const/4 v13, -0x1

    .line 925
    move-object/from16 v0, p0

    .line 926
    .line 927
    goto :goto_10

    .line 928
    :cond_2d
    :goto_13
    if-ge v12, v6, :cond_2e

    .line 929
    .line 930
    invoke-virtual {v14, v4, v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 931
    .line 932
    .line 933
    :cond_2e
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 934
    .line 935
    .line 936
    move-result-object v4

    .line 937
    const-string v0, "toString(...)"

    .line 938
    .line 939
    invoke-static {v4, v0}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 940
    .line 941
    .line 942
    const/4 v0, -0x1

    .line 943
    :goto_14
    if-eq v9, v0, :cond_30

    .line 944
    .line 945
    if-ne v11, v0, :cond_2f

    .line 946
    .line 947
    goto :goto_15

    .line 948
    :cond_2f
    shr-long v5, v7, v16

    .line 949
    .line 950
    long-to-int v0, v5

    .line 951
    add-int v5, v0, v9

    .line 952
    .line 953
    add-int/2addr v0, v11

    .line 954
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 955
    .line 956
    .line 957
    move-result v6

    .line 958
    invoke-static {v7, v8}, LH0/N;->d(J)I

    .line 959
    .line 960
    .line 961
    move-result v7

    .line 962
    sub-int/2addr v7, v11

    .line 963
    sub-int/2addr v6, v7

    .line 964
    invoke-virtual {v4, v9, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 965
    .line 966
    .line 967
    move-result-object v4

    .line 968
    const-string v6, "substring(...)"

    .line 969
    .line 970
    invoke-static {v4, v6}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 971
    .line 972
    .line 973
    new-instance v6, LM0/w;

    .line 974
    .line 975
    invoke-direct {v6, v5, v0}, LM0/w;-><init>(II)V

    .line 976
    .line 977
    .line 978
    new-instance v0, LM0/a;

    .line 979
    .line 980
    move/from16 v5, v17

    .line 981
    .line 982
    invoke-direct {v0, v4, v5}, LM0/a;-><init>(Ljava/lang/String;I)V

    .line 983
    .line 984
    .line 985
    const/4 v4, 0x2

    .line 986
    new-array v4, v4, [LM0/g;

    .line 987
    .line 988
    const/16 v18, 0x0

    .line 989
    .line 990
    aput-object v6, v4, v18

    .line 991
    .line 992
    aput-object v0, v4, v5

    .line 993
    .line 994
    new-instance v0, LF/q;

    .line 995
    .line 996
    invoke-direct {v0, v4}, LF/q;-><init>([LM0/g;)V

    .line 997
    .line 998
    .line 999
    invoke-virtual {v3, v0}, LB/y;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1000
    .line 1001
    .line 1002
    goto :goto_16

    .line 1003
    :cond_30
    :goto_15
    invoke-static/range {v20 .. v20}, LB/x;->j(Ljava/lang/Object;)Landroid/view/inputmethod/HandwritingGesture;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v0

    .line 1007
    invoke-static {v0, v3}, LF/v;->g(Landroid/view/inputmethod/HandwritingGesture;LB/y;)I

    .line 1008
    .line 1009
    .line 1010
    move-result v5

    .line 1011
    goto :goto_16

    .line 1012
    :cond_31
    move v4, v9

    .line 1013
    move v5, v4

    .line 1014
    :cond_32
    :goto_16
    if-nez v2, :cond_33

    .line 1015
    .line 1016
    goto :goto_17

    .line 1017
    :cond_33
    if-eqz v1, :cond_34

    .line 1018
    .line 1019
    new-instance v0, LF/h;

    .line 1020
    .line 1021
    invoke-direct {v0, v2, v5}, LF/h;-><init>(Ljava/util/function/IntConsumer;I)V

    .line 1022
    .line 1023
    .line 1024
    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1025
    .line 1026
    .line 1027
    return-void

    .line 1028
    :cond_34
    invoke-interface {v2, v5}, Ljava/util/function/IntConsumer;->accept(I)V

    .line 1029
    .line 1030
    .line 1031
    :cond_35
    :goto_17
    return-void
.end method

.method public final performPrivateCommand(Ljava/lang/String;Landroid/os/Bundle;)Z
    .locals 0

    .line 1
    iget-boolean p1, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    :cond_0
    return p1
.end method

.method public final previewHandwritingGesture(Landroid/view/inputmethod/PreviewableHandwritingGesture;Landroid/os/CancellationSignal;)Z
    .locals 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-lt v0, v1, :cond_14

    .line 7
    .line 8
    iget-object v0, p0, LF/A;->c:Lw/S;

    .line 9
    .line 10
    if-eqz v0, :cond_14

    .line 11
    .line 12
    iget-object v1, v0, Lw/S;->j:LH0/g;

    .line 13
    .line 14
    if-nez v1, :cond_0

    .line 15
    .line 16
    goto/16 :goto_6

    .line 17
    .line 18
    :cond_0
    invoke-virtual {v0}, Lw/S;->d()Lw/p0;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    if-eqz v3, :cond_1

    .line 23
    .line 24
    iget-object v3, v3, Lw/p0;->a:LH0/L;

    .line 25
    .line 26
    iget-object v3, v3, LH0/L;->a:LH0/K;

    .line 27
    .line 28
    if-eqz v3, :cond_1

    .line 29
    .line 30
    iget-object v3, v3, LH0/K;->a:LH0/g;

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    const/4 v3, 0x0

    .line 34
    :goto_0
    invoke-virtual {v1, v3}, LH0/g;->equals(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-nez v1, :cond_2

    .line 39
    .line 40
    goto/16 :goto_6

    .line 41
    .line 42
    :cond_2
    invoke-static {p1}, LB/x;->t(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    sget-object v3, Lw/H;->d:Lw/H;

    .line 47
    .line 48
    iget-object v4, p0, LF/A;->d:LH/m0;

    .line 49
    .line 50
    const/4 v5, 0x1

    .line 51
    if-eqz v1, :cond_6

    .line 52
    .line 53
    invoke-static {p1}, LB/x;->n(Ljava/lang/Object;)Landroid/view/inputmethod/SelectGesture;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-eqz v4, :cond_12

    .line 58
    .line 59
    invoke-static {p1}, LB/x;->i(Landroid/view/inputmethod/SelectGesture;)Landroid/graphics/RectF;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-static {v1}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-static {p1}, LB/x;->c(Landroid/view/inputmethod/SelectGesture;)I

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    if-eq p1, v5, :cond_3

    .line 72
    .line 73
    move p1, v2

    .line 74
    goto :goto_1

    .line 75
    :cond_3
    move p1, v5

    .line 76
    :goto_1
    invoke-static {v0, v1, p1}, LF/v;->i(Lw/S;Lc0/c;I)J

    .line 77
    .line 78
    .line 79
    move-result-wide v0

    .line 80
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 81
    .line 82
    if-eqz p1, :cond_4

    .line 83
    .line 84
    invoke-virtual {p1, v0, v1}, Lw/S;->f(J)V

    .line 85
    .line 86
    .line 87
    :cond_4
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 88
    .line 89
    if-eqz p1, :cond_5

    .line 90
    .line 91
    sget-wide v6, LH0/N;->b:J

    .line 92
    .line 93
    invoke-virtual {p1, v6, v7}, Lw/S;->e(J)V

    .line 94
    .line 95
    .line 96
    :cond_5
    invoke-static {v0, v1}, LH0/N;->c(J)Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-nez p1, :cond_12

    .line 101
    .line 102
    invoke-virtual {v4, v2}, LH/m0;->t(Z)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v4, v3}, LH/m0;->q(Lw/H;)V

    .line 106
    .line 107
    .line 108
    goto/16 :goto_5

    .line 109
    .line 110
    :cond_6
    invoke-static {p1}, LF/p;->q(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    if-eqz v1, :cond_a

    .line 115
    .line 116
    invoke-static {p1}, LF/p;->k(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteGesture;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    if-eqz v4, :cond_12

    .line 121
    .line 122
    invoke-static {p1}, LB/x;->g(Landroid/view/inputmethod/DeleteGesture;)Landroid/graphics/RectF;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    invoke-static {v1}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    invoke-static {p1}, LB/x;->a(Landroid/view/inputmethod/DeleteGesture;)I

    .line 131
    .line 132
    .line 133
    move-result p1

    .line 134
    if-eq p1, v5, :cond_7

    .line 135
    .line 136
    move p1, v2

    .line 137
    goto :goto_2

    .line 138
    :cond_7
    move p1, v5

    .line 139
    :goto_2
    invoke-static {v0, v1, p1}, LF/v;->i(Lw/S;Lc0/c;I)J

    .line 140
    .line 141
    .line 142
    move-result-wide v0

    .line 143
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 144
    .line 145
    if-eqz p1, :cond_8

    .line 146
    .line 147
    invoke-virtual {p1, v0, v1}, Lw/S;->e(J)V

    .line 148
    .line 149
    .line 150
    :cond_8
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 151
    .line 152
    if-eqz p1, :cond_9

    .line 153
    .line 154
    sget-wide v6, LH0/N;->b:J

    .line 155
    .line 156
    invoke-virtual {p1, v6, v7}, Lw/S;->f(J)V

    .line 157
    .line 158
    .line 159
    :cond_9
    invoke-static {v0, v1}, LH0/N;->c(J)Z

    .line 160
    .line 161
    .line 162
    move-result p1

    .line 163
    if-nez p1, :cond_12

    .line 164
    .line 165
    invoke-virtual {v4, v2}, LH/m0;->t(Z)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v4, v3}, LH/m0;->q(Lw/H;)V

    .line 169
    .line 170
    .line 171
    goto/16 :goto_5

    .line 172
    .line 173
    :cond_a
    invoke-static {p1}, LF/p;->x(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    if-eqz v1, :cond_e

    .line 178
    .line 179
    invoke-static {p1}, LF/p;->m(Ljava/lang/Object;)Landroid/view/inputmethod/SelectRangeGesture;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    if-eqz v4, :cond_12

    .line 184
    .line 185
    invoke-static {p1}, LF/p;->h(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    invoke-static {v1}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    invoke-static {p1}, LF/p;->w(Landroid/view/inputmethod/SelectRangeGesture;)Landroid/graphics/RectF;

    .line 194
    .line 195
    .line 196
    move-result-object v6

    .line 197
    invoke-static {v6}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 198
    .line 199
    .line 200
    move-result-object v6

    .line 201
    invoke-static {p1}, LB/x;->d(Landroid/view/inputmethod/SelectRangeGesture;)I

    .line 202
    .line 203
    .line 204
    move-result p1

    .line 205
    if-eq p1, v5, :cond_b

    .line 206
    .line 207
    move p1, v2

    .line 208
    goto :goto_3

    .line 209
    :cond_b
    move p1, v5

    .line 210
    :goto_3
    invoke-static {v0, v1, v6, p1}, LF/v;->b(Lw/S;Lc0/c;Lc0/c;I)J

    .line 211
    .line 212
    .line 213
    move-result-wide v0

    .line 214
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 215
    .line 216
    if-eqz p1, :cond_c

    .line 217
    .line 218
    invoke-virtual {p1, v0, v1}, Lw/S;->f(J)V

    .line 219
    .line 220
    .line 221
    :cond_c
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 222
    .line 223
    if-eqz p1, :cond_d

    .line 224
    .line 225
    sget-wide v6, LH0/N;->b:J

    .line 226
    .line 227
    invoke-virtual {p1, v6, v7}, Lw/S;->e(J)V

    .line 228
    .line 229
    .line 230
    :cond_d
    invoke-static {v0, v1}, LH0/N;->c(J)Z

    .line 231
    .line 232
    .line 233
    move-result p1

    .line 234
    if-nez p1, :cond_12

    .line 235
    .line 236
    invoke-virtual {v4, v2}, LH/m0;->t(Z)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v4, v3}, LH/m0;->q(Lw/H;)V

    .line 240
    .line 241
    .line 242
    goto :goto_5

    .line 243
    :cond_e
    invoke-static {p1}, LF/p;->z(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move-result v1

    .line 247
    if-eqz v1, :cond_14

    .line 248
    .line 249
    invoke-static {p1}, LF/p;->l(Ljava/lang/Object;)Landroid/view/inputmethod/DeleteRangeGesture;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    if-eqz v4, :cond_12

    .line 254
    .line 255
    invoke-static {p1}, LB/x;->h(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 256
    .line 257
    .line 258
    move-result-object v1

    .line 259
    invoke-static {v1}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 260
    .line 261
    .line 262
    move-result-object v1

    .line 263
    invoke-static {p1}, LB/x;->u(Landroid/view/inputmethod/DeleteRangeGesture;)Landroid/graphics/RectF;

    .line 264
    .line 265
    .line 266
    move-result-object v6

    .line 267
    invoke-static {v6}, Ld0/D;->y(Landroid/graphics/RectF;)Lc0/c;

    .line 268
    .line 269
    .line 270
    move-result-object v6

    .line 271
    invoke-static {p1}, LB/x;->b(Landroid/view/inputmethod/DeleteRangeGesture;)I

    .line 272
    .line 273
    .line 274
    move-result p1

    .line 275
    if-eq p1, v5, :cond_f

    .line 276
    .line 277
    move p1, v2

    .line 278
    goto :goto_4

    .line 279
    :cond_f
    move p1, v5

    .line 280
    :goto_4
    invoke-static {v0, v1, v6, p1}, LF/v;->b(Lw/S;Lc0/c;Lc0/c;I)J

    .line 281
    .line 282
    .line 283
    move-result-wide v0

    .line 284
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 285
    .line 286
    if-eqz p1, :cond_10

    .line 287
    .line 288
    invoke-virtual {p1, v0, v1}, Lw/S;->e(J)V

    .line 289
    .line 290
    .line 291
    :cond_10
    iget-object p1, v4, LH/m0;->d:Lw/S;

    .line 292
    .line 293
    if-eqz p1, :cond_11

    .line 294
    .line 295
    sget-wide v6, LH0/N;->b:J

    .line 296
    .line 297
    invoke-virtual {p1, v6, v7}, Lw/S;->f(J)V

    .line 298
    .line 299
    .line 300
    :cond_11
    invoke-static {v0, v1}, LH0/N;->c(J)Z

    .line 301
    .line 302
    .line 303
    move-result p1

    .line 304
    if-nez p1, :cond_12

    .line 305
    .line 306
    invoke-virtual {v4, v2}, LH/m0;->t(Z)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v4, v3}, LH/m0;->q(Lw/H;)V

    .line 310
    .line 311
    .line 312
    :cond_12
    :goto_5
    if-eqz p2, :cond_13

    .line 313
    .line 314
    new-instance p1, LD0/h;

    .line 315
    .line 316
    const/4 v0, 0x1

    .line 317
    invoke-direct {p1, v0, v4}, LD0/h;-><init>(ILjava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {p2, p1}, Landroid/os/CancellationSignal;->setOnCancelListener(Landroid/os/CancellationSignal$OnCancelListener;)V

    .line 321
    .line 322
    .line 323
    :cond_13
    return v5

    .line 324
    :cond_14
    :goto_6
    return v2
.end method

.method public final reportFullscreenMode(Z)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public final requestCursorUpdates(I)Z
    .locals 9

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_a

    .line 4
    .line 5
    and-int/lit8 v0, p1, 0x1

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x1

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    move v0, v2

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move v0, v1

    .line 14
    :goto_0
    and-int/lit8 v3, p1, 0x2

    .line 15
    .line 16
    if-eqz v3, :cond_1

    .line 17
    .line 18
    move v3, v2

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    move v3, v1

    .line 21
    :goto_1
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/16 v5, 0x21

    .line 24
    .line 25
    if-lt v4, v5, :cond_8

    .line 26
    .line 27
    and-int/lit8 v5, p1, 0x10

    .line 28
    .line 29
    if-eqz v5, :cond_2

    .line 30
    .line 31
    move v5, v2

    .line 32
    goto :goto_2

    .line 33
    :cond_2
    move v5, v1

    .line 34
    :goto_2
    and-int/lit8 v6, p1, 0x8

    .line 35
    .line 36
    if-eqz v6, :cond_3

    .line 37
    .line 38
    move v6, v2

    .line 39
    goto :goto_3

    .line 40
    :cond_3
    move v6, v1

    .line 41
    :goto_3
    and-int/lit8 v7, p1, 0x4

    .line 42
    .line 43
    if-eqz v7, :cond_4

    .line 44
    .line 45
    move v7, v2

    .line 46
    goto :goto_4

    .line 47
    :cond_4
    move v7, v1

    .line 48
    :goto_4
    const/16 v8, 0x22

    .line 49
    .line 50
    if-lt v4, v8, :cond_5

    .line 51
    .line 52
    and-int/lit8 p1, p1, 0x20

    .line 53
    .line 54
    if-eqz p1, :cond_5

    .line 55
    .line 56
    move v1, v2

    .line 57
    :cond_5
    if-nez v5, :cond_7

    .line 58
    .line 59
    if-nez v6, :cond_7

    .line 60
    .line 61
    if-nez v7, :cond_7

    .line 62
    .line 63
    if-nez v1, :cond_7

    .line 64
    .line 65
    if-lt v4, v8, :cond_6

    .line 66
    .line 67
    move p1, v2

    .line 68
    move v1, p1

    .line 69
    :goto_5
    move v5, v1

    .line 70
    :goto_6
    move v6, v5

    .line 71
    goto :goto_7

    .line 72
    :cond_6
    move p1, v1

    .line 73
    move v1, v2

    .line 74
    goto :goto_5

    .line 75
    :cond_7
    move p1, v1

    .line 76
    move v1, v7

    .line 77
    goto :goto_7

    .line 78
    :cond_8
    move p1, v1

    .line 79
    move v5, v2

    .line 80
    goto :goto_6

    .line 81
    :goto_7
    iget-object v4, p0, LF/A;->a:LA0/h;

    .line 82
    .line 83
    iget-object v4, v4, LA0/h;->e:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v4, LF/z;

    .line 86
    .line 87
    iget-object v4, v4, LF/z;->m:LF/w;

    .line 88
    .line 89
    iget-object v7, v4, LF/w;->c:Ljava/lang/Object;

    .line 90
    .line 91
    monitor-enter v7

    .line 92
    :try_start_0
    iput-boolean v5, v4, LF/w;->f:Z

    .line 93
    .line 94
    iput-boolean v6, v4, LF/w;->g:Z

    .line 95
    .line 96
    iput-boolean v1, v4, LF/w;->h:Z

    .line 97
    .line 98
    iput-boolean p1, v4, LF/w;->i:Z

    .line 99
    .line 100
    if-eqz v0, :cond_9

    .line 101
    .line 102
    iput-boolean v2, v4, LF/w;->e:Z

    .line 103
    .line 104
    iget-object p1, v4, LF/w;->j:LM0/x;

    .line 105
    .line 106
    if-eqz p1, :cond_9

    .line 107
    .line 108
    invoke-virtual {v4}, LF/w;->a()V

    .line 109
    .line 110
    .line 111
    goto :goto_8

    .line 112
    :catchall_0
    move-exception p1

    .line 113
    goto :goto_9

    .line 114
    :cond_9
    :goto_8
    iput-boolean v3, v4, LF/w;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 115
    .line 116
    monitor-exit v7

    .line 117
    return v2

    .line 118
    :goto_9
    monitor-exit v7

    .line 119
    throw p1

    .line 120
    :cond_a
    return v0
.end method

.method public final sendKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, LF/A;->a:LA0/h;

    .line 6
    .line 7
    iget-object v0, v0, LA0/h;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, LF/z;

    .line 10
    .line 11
    iget-object v0, v0, LF/z;->k:Ljava/lang/Object;

    .line 12
    .line 13
    invoke-interface {v0}, LJ1/d;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Landroid/view/inputmethod/BaseInputConnection;

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Landroid/view/inputmethod/BaseInputConnection;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 20
    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    return p1

    .line 24
    :cond_0
    return v0
.end method

.method public final setComposingRegion(II)Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LM0/u;

    .line 6
    .line 7
    invoke-direct {v1, p1, p2}, LM0/u;-><init>(II)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1}, LF/A;->a(LM0/g;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    return v0
.end method

.method public final setComposingText(Ljava/lang/CharSequence;I)Z
    .locals 2

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LM0/v;

    .line 6
    .line 7
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {v1, p1, p2}, LM0/v;-><init>(Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v1}, LF/A;->a(LM0/g;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return v0
.end method

.method public final setSelection(II)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LF/A;->k:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LM0/w;

    .line 6
    .line 7
    invoke-direct {v0, p1, p2}, LM0/w;-><init>(II)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, LF/A;->a(LM0/g;)V

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    return p1

    .line 15
    :cond_0
    return v0
.end method
