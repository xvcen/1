.class public final synthetic LF/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LF/o;LM0/q;LM0/x;Lw/S;Ld0/s;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    iput v0, p0, LF/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/a;->f:Ljava/lang/Object;

    iput-object p2, p0, LF/a;->g:Ljava/lang/Object;

    iput-object p3, p0, LF/a;->e:Ljava/lang/Object;

    iput-object p4, p0, LF/a;->h:Ljava/lang/Object;

    iput-object p5, p0, LF/a;->i:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p6, p0, LF/a;->d:I

    iput-object p1, p0, LF/a;->e:Ljava/lang/Object;

    iput-object p2, p0, LF/a;->f:Ljava/lang/Object;

    iput-object p3, p0, LF/a;->g:Ljava/lang/Object;

    iput-object p4, p0, LF/a;->h:Ljava/lang/Object;

    iput-object p5, p0, LF/a;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LF/a;->d:I

    .line 4
    .line 5
    sget-object v2, LJ1/m;->a:LJ1/m;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    const/4 v5, 0x1

    .line 10
    iget-object v6, v0, LF/a;->i:Ljava/lang/Object;

    .line 11
    .line 12
    iget-object v7, v0, LF/a;->h:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v8, v0, LF/a;->e:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object v9, v0, LF/a;->g:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v10, v0, LF/a;->f:Ljava/lang/Object;

    .line 19
    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    check-cast v10, LF/o;

    .line 24
    .line 25
    check-cast v9, LM0/q;

    .line 26
    .line 27
    check-cast v8, LM0/x;

    .line 28
    .line 29
    check-cast v7, Lw/S;

    .line 30
    .line 31
    check-cast v6, Ld0/s;

    .line 32
    .line 33
    move-object/from16 v1, p1

    .line 34
    .line 35
    check-cast v1, Lw0/G;

    .line 36
    .line 37
    invoke-virtual {v1}, Lw0/G;->c()V

    .line 38
    .line 39
    .line 40
    iget-object v11, v1, Lw0/G;->d:Lf0/b;

    .line 41
    .line 42
    iget-object v10, v10, LF/o;->c:LI/i0;

    .line 43
    .line 44
    invoke-virtual {v10}, LI/i0;->g()F

    .line 45
    .line 46
    .line 47
    move-result v10

    .line 48
    const/4 v12, 0x0

    .line 49
    cmpg-float v13, v10, v12

    .line 50
    .line 51
    if-nez v13, :cond_0

    .line 52
    .line 53
    goto/16 :goto_b

    .line 54
    .line 55
    :cond_0
    iget-wide v13, v8, LM0/x;->b:J

    .line 56
    .line 57
    sget v8, LH0/N;->c:I

    .line 58
    .line 59
    const/16 v8, 0x20

    .line 60
    .line 61
    shr-long/2addr v13, v8

    .line 62
    long-to-int v13, v13

    .line 63
    invoke-interface {v9, v13}, LM0/q;->n(I)I

    .line 64
    .line 65
    .line 66
    move-result v9

    .line 67
    invoke-virtual {v7}, Lw/S;->d()Lw/p0;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    if-eqz v7, :cond_1

    .line 72
    .line 73
    iget-object v7, v7, Lw/p0;->a:LH0/L;

    .line 74
    .line 75
    invoke-virtual {v7, v9}, LH0/L;->c(I)Lc0/c;

    .line 76
    .line 77
    .line 78
    move-result-object v7

    .line 79
    goto :goto_0

    .line 80
    :cond_1
    new-instance v7, Lc0/c;

    .line 81
    .line 82
    invoke-direct {v7, v12, v12, v12, v12}, Lc0/c;-><init>(FFFF)V

    .line 83
    .line 84
    .line 85
    :goto_0
    sget v9, Lw/c0;->a:F

    .line 86
    .line 87
    invoke-virtual {v1, v9}, Lw0/G;->K(F)F

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    float-to-double v12, v1

    .line 92
    invoke-static {v12, v13}, Ljava/lang/Math;->floor(D)D

    .line 93
    .line 94
    .line 95
    move-result-wide v12

    .line 96
    double-to-float v1, v12

    .line 97
    const/high16 v9, 0x3f800000    # 1.0f

    .line 98
    .line 99
    cmpg-float v12, v1, v9

    .line 100
    .line 101
    if-gez v12, :cond_2

    .line 102
    .line 103
    move v1, v9

    .line 104
    :cond_2
    iget v9, v7, Lc0/c;->a:F

    .line 105
    .line 106
    const/4 v12, 0x2

    .line 107
    int-to-float v13, v12

    .line 108
    div-float v13, v1, v13

    .line 109
    .line 110
    add-float/2addr v9, v13

    .line 111
    invoke-interface {v11}, Lf0/d;->a()J

    .line 112
    .line 113
    .line 114
    move-result-wide v14

    .line 115
    shr-long/2addr v14, v8

    .line 116
    long-to-int v14, v14

    .line 117
    invoke-static {v14}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 118
    .line 119
    .line 120
    move-result v14

    .line 121
    sub-float/2addr v14, v13

    .line 122
    cmpl-float v15, v9, v14

    .line 123
    .line 124
    if-lez v15, :cond_3

    .line 125
    .line 126
    move v9, v14

    .line 127
    :cond_3
    cmpg-float v14, v9, v13

    .line 128
    .line 129
    if-gez v14, :cond_4

    .line 130
    .line 131
    goto :goto_1

    .line 132
    :cond_4
    move v13, v9

    .line 133
    :goto_1
    float-to-int v9, v1

    .line 134
    rem-int/2addr v9, v12

    .line 135
    if-ne v9, v5, :cond_5

    .line 136
    .line 137
    float-to-double v12, v13

    .line 138
    invoke-static {v12, v13}, Ljava/lang/Math;->floor(D)D

    .line 139
    .line 140
    .line 141
    move-result-wide v12

    .line 142
    double-to-float v9, v12

    .line 143
    const/high16 v12, 0x3f000000    # 0.5f

    .line 144
    .line 145
    add-float/2addr v9, v12

    .line 146
    goto :goto_2

    .line 147
    :cond_5
    float-to-double v12, v13

    .line 148
    invoke-static {v12, v13}, Ljava/lang/Math;->rint(D)D

    .line 149
    .line 150
    .line 151
    move-result-wide v12

    .line 152
    double-to-float v9, v12

    .line 153
    :goto_2
    iget v12, v7, Lc0/c;->b:F

    .line 154
    .line 155
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 156
    .line 157
    .line 158
    move-result v13

    .line 159
    int-to-long v13, v13

    .line 160
    invoke-static {v12}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 161
    .line 162
    .line 163
    move-result v12

    .line 164
    move/from16 p1, v8

    .line 165
    .line 166
    move v15, v9

    .line 167
    int-to-long v8, v12

    .line 168
    shl-long v12, v13, p1

    .line 169
    .line 170
    const-wide v16, 0xffffffffL

    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    and-long v8, v8, v16

    .line 176
    .line 177
    or-long v19, v12, v8

    .line 178
    .line 179
    iget v7, v7, Lc0/c;->d:F

    .line 180
    .line 181
    invoke-static {v15}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 182
    .line 183
    .line 184
    move-result v8

    .line 185
    int-to-long v8, v8

    .line 186
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 187
    .line 188
    .line 189
    move-result v7

    .line 190
    int-to-long v12, v7

    .line 191
    shl-long v7, v8, p1

    .line 192
    .line 193
    and-long v12, v12, v16

    .line 194
    .line 195
    or-long v21, v7, v12

    .line 196
    .line 197
    iget-object v7, v11, Lf0/b;->d:Lf0/a;

    .line 198
    .line 199
    iget-object v7, v7, Lf0/a;->c:Ld0/u;

    .line 200
    .line 201
    iget-object v8, v11, Lf0/b;->g:Ld0/h;

    .line 202
    .line 203
    if-nez v8, :cond_6

    .line 204
    .line 205
    invoke-static {}, Ld0/D;->e()Ld0/h;

    .line 206
    .line 207
    .line 208
    move-result-object v8

    .line 209
    invoke-virtual {v8, v5}, Ld0/h;->l(I)V

    .line 210
    .line 211
    .line 212
    iput-object v8, v11, Lf0/b;->g:Ld0/h;

    .line 213
    .line 214
    :cond_6
    if-eqz v6, :cond_7

    .line 215
    .line 216
    invoke-interface {v11}, Lf0/d;->a()J

    .line 217
    .line 218
    .line 219
    move-result-wide v11

    .line 220
    invoke-virtual {v6, v10, v11, v12, v8}, Ld0/s;->a(FJLd0/h;)V

    .line 221
    .line 222
    .line 223
    goto :goto_3

    .line 224
    :cond_7
    iget-object v6, v8, Ld0/h;->a:Landroid/graphics/Paint;

    .line 225
    .line 226
    invoke-virtual {v6}, Landroid/graphics/Paint;->getAlpha()I

    .line 227
    .line 228
    .line 229
    move-result v6

    .line 230
    int-to-float v6, v6

    .line 231
    const/high16 v9, 0x437f0000    # 255.0f

    .line 232
    .line 233
    div-float/2addr v6, v9

    .line 234
    cmpg-float v6, v6, v10

    .line 235
    .line 236
    if-nez v6, :cond_8

    .line 237
    .line 238
    goto :goto_3

    .line 239
    :cond_8
    invoke-virtual {v8, v10}, Ld0/h;->c(F)V

    .line 240
    .line 241
    .line 242
    :goto_3
    iget-object v6, v8, Ld0/h;->a:Landroid/graphics/Paint;

    .line 243
    .line 244
    iget-object v9, v8, Ld0/h;->d:Ld0/o;

    .line 245
    .line 246
    invoke-static {v9, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v9

    .line 250
    if-nez v9, :cond_9

    .line 251
    .line 252
    invoke-virtual {v8, v3}, Ld0/h;->f(Ld0/o;)V

    .line 253
    .line 254
    .line 255
    :cond_9
    iget v3, v8, Ld0/h;->b:I

    .line 256
    .line 257
    const/4 v9, 0x3

    .line 258
    if-ne v3, v9, :cond_a

    .line 259
    .line 260
    goto :goto_4

    .line 261
    :cond_a
    invoke-virtual {v8, v9}, Ld0/h;->d(I)V

    .line 262
    .line 263
    .line 264
    :goto_4
    invoke-virtual {v6}, Landroid/graphics/Paint;->getStrokeWidth()F

    .line 265
    .line 266
    .line 267
    move-result v3

    .line 268
    cmpg-float v3, v3, v1

    .line 269
    .line 270
    if-nez v3, :cond_b

    .line 271
    .line 272
    goto :goto_5

    .line 273
    :cond_b
    invoke-virtual {v8, v1}, Ld0/h;->k(F)V

    .line 274
    .line 275
    .line 276
    :goto_5
    invoke-virtual {v6}, Landroid/graphics/Paint;->getStrokeMiter()F

    .line 277
    .line 278
    .line 279
    move-result v1

    .line 280
    const/high16 v3, 0x40800000    # 4.0f

    .line 281
    .line 282
    cmpg-float v1, v1, v3

    .line 283
    .line 284
    if-nez v1, :cond_c

    .line 285
    .line 286
    goto :goto_6

    .line 287
    :cond_c
    iget-object v1, v8, Ld0/h;->a:Landroid/graphics/Paint;

    .line 288
    .line 289
    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStrokeMiter(F)V

    .line 290
    .line 291
    .line 292
    :goto_6
    invoke-virtual {v8}, Ld0/h;->a()I

    .line 293
    .line 294
    .line 295
    move-result v1

    .line 296
    if-nez v1, :cond_d

    .line 297
    .line 298
    goto :goto_7

    .line 299
    :cond_d
    invoke-virtual {v8, v4}, Ld0/h;->i(I)V

    .line 300
    .line 301
    .line 302
    :goto_7
    invoke-virtual {v8}, Ld0/h;->b()I

    .line 303
    .line 304
    .line 305
    move-result v1

    .line 306
    if-nez v1, :cond_e

    .line 307
    .line 308
    goto :goto_8

    .line 309
    :cond_e
    invoke-virtual {v8, v4}, Ld0/h;->j(I)V

    .line 310
    .line 311
    .line 312
    :goto_8
    invoke-virtual {v6}, Landroid/graphics/Paint;->isFilterBitmap()Z

    .line 313
    .line 314
    .line 315
    move-result v1

    .line 316
    if-ne v1, v5, :cond_f

    .line 317
    .line 318
    :goto_9
    move-object/from16 v18, v7

    .line 319
    .line 320
    move-object/from16 v23, v8

    .line 321
    .line 322
    goto :goto_a

    .line 323
    :cond_f
    invoke-virtual {v8, v5}, Ld0/h;->g(I)V

    .line 324
    .line 325
    .line 326
    goto :goto_9

    .line 327
    :goto_a
    invoke-interface/range {v18 .. v23}, Ld0/u;->c(JJLd0/h;)V

    .line 328
    .line 329
    .line 330
    :goto_b
    return-object v2

    .line 331
    :pswitch_0
    check-cast v8, Lp/m0;

    .line 332
    .line 333
    check-cast v10, LV1/s;

    .line 334
    .line 335
    check-cast v9, LV1/p;

    .line 336
    .line 337
    check-cast v7, Lp/S0;

    .line 338
    .line 339
    check-cast v6, LV1/o;

    .line 340
    .line 341
    move-object/from16 v1, p1

    .line 342
    .line 343
    check-cast v1, Ljava/lang/Float;

    .line 344
    .line 345
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 346
    .line 347
    .line 348
    move-result v1

    .line 349
    iget-object v2, v8, Lp/m0;->f:Ljava/lang/Object;

    .line 350
    .line 351
    check-cast v2, Le2/c;

    .line 352
    .line 353
    invoke-static {v2}, Lp/m0;->g(Le2/c;)Lp/b0;

    .line 354
    .line 355
    .line 356
    move-result-object v2

    .line 357
    if-eqz v2, :cond_10

    .line 358
    .line 359
    invoke-virtual {v8, v2}, Lp/m0;->h(Lp/b0;)V

    .line 360
    .line 361
    .line 362
    iget-object v3, v10, LV1/s;->d:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v3, Lp/b0;

    .line 365
    .line 366
    invoke-virtual {v3, v2}, Lp/b0;->a(Lp/b0;)Lp/b0;

    .line 367
    .line 368
    .line 369
    move-result-object v3

    .line 370
    iput-object v3, v10, LV1/s;->d:Ljava/lang/Object;

    .line 371
    .line 372
    iget-wide v10, v3, Lp/b0;->a:J

    .line 373
    .line 374
    invoke-virtual {v7, v10, v11}, Lp/S0;->e(J)J

    .line 375
    .line 376
    .line 377
    move-result-wide v10

    .line 378
    invoke-virtual {v7, v10, v11}, Lp/S0;->i(J)F

    .line 379
    .line 380
    .line 381
    move-result v3

    .line 382
    iput v3, v9, LV1/p;->d:F

    .line 383
    .line 384
    sub-float/2addr v3, v1

    .line 385
    invoke-static {v3}, Lp/a0;->a(F)Z

    .line 386
    .line 387
    .line 388
    move-result v1

    .line 389
    xor-int/2addr v1, v5

    .line 390
    iput-boolean v1, v6, LV1/o;->d:Z

    .line 391
    .line 392
    :cond_10
    if-eqz v2, :cond_11

    .line 393
    .line 394
    move v4, v5

    .line 395
    :cond_11
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 396
    .line 397
    .line 398
    move-result-object v1

    .line 399
    return-object v1

    .line 400
    :pswitch_1
    check-cast v8, LM0/x;

    .line 401
    .line 402
    check-cast v10, LF/g;

    .line 403
    .line 404
    check-cast v9, LM0/k;

    .line 405
    .line 406
    check-cast v7, LB/r;

    .line 407
    .line 408
    check-cast v6, LU1/c;

    .line 409
    .line 410
    move-object/from16 v1, p1

    .line 411
    .line 412
    check-cast v1, LF/z;

    .line 413
    .line 414
    iget-object v4, v10, LF/g;->a:LF/u;

    .line 415
    .line 416
    iput-object v8, v1, LF/z;->h:LM0/x;

    .line 417
    .line 418
    iput-object v9, v1, LF/z;->i:LM0/k;

    .line 419
    .line 420
    iput-object v7, v1, LF/z;->c:LU1/c;

    .line 421
    .line 422
    iput-object v6, v1, LF/z;->d:LU1/c;

    .line 423
    .line 424
    if-eqz v4, :cond_12

    .line 425
    .line 426
    iget-object v5, v4, LF/u;->s:Lw/S;

    .line 427
    .line 428
    goto :goto_c

    .line 429
    :cond_12
    move-object v5, v3

    .line 430
    :goto_c
    iput-object v5, v1, LF/z;->e:Lw/S;

    .line 431
    .line 432
    if-eqz v4, :cond_13

    .line 433
    .line 434
    iget-object v5, v4, LF/u;->t:LH/m0;

    .line 435
    .line 436
    goto :goto_d

    .line 437
    :cond_13
    move-object v5, v3

    .line 438
    :goto_d
    iput-object v5, v1, LF/z;->f:LH/m0;

    .line 439
    .line 440
    if-eqz v4, :cond_14

    .line 441
    .line 442
    sget-object v3, Lx0/i0;->s:LI/b1;

    .line 443
    .line 444
    invoke-static {v4, v3}, Lw0/j;->h(Lw0/g;LI/t0;)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    move-result-object v3

    .line 448
    check-cast v3, Lx0/J0;

    .line 449
    .line 450
    :cond_14
    iput-object v3, v1, LF/z;->g:Lx0/J0;

    .line 451
    .line 452
    return-object v2

    .line 453
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
