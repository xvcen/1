.class public final LF/c;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LF/g;

.field public final synthetic j:LF/r;


# direct methods
.method public constructor <init>(LF/g;LF/r;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LF/c;->i:LF/g;

    .line 2
    .line 3
    iput-object p2, p0, LF/c;->j:LF/r;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LF/c;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LF/c;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LF/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance p2, LF/c;

    .line 2
    .line 3
    iget-object v0, p0, LF/c;->i:LF/g;

    .line 4
    .line 5
    iget-object v1, p0, LF/c;->j:LF/r;

    .line 6
    .line 7
    invoke-direct {p2, v0, v1, p1}, LF/c;-><init>(LF/g;LF/r;LN1/c;)V

    .line 8
    .line 9
    .line 10
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LF/c;->h:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    sget-object v3, LO1/a;->d:LO1/a;

    .line 6
    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    if-eq v0, v2, :cond_1

    .line 10
    .line 11
    if-eq v0, v1, :cond_0

    .line 12
    .line 13
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 16
    .line 17
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw p1

    .line 21
    :cond_0
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    new-instance p1, LC0/e;

    .line 25
    .line 26
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    new-instance p1, Ll/V;

    .line 38
    .line 39
    const/16 v0, 0x14

    .line 40
    .line 41
    invoke-direct {p1, v0}, Ll/V;-><init>(I)V

    .line 42
    .line 43
    .line 44
    iput v2, p0, LF/c;->h:I

    .line 45
    .line 46
    iget-object v0, p0, LP1/c;->e:LN1/h;

    .line 47
    .line 48
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-static {v0}, LI/k;->n(LN1/h;)LI/g;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    new-instance v2, LI/Y;

    .line 56
    .line 57
    const/4 v4, 0x0

    .line 58
    invoke-direct {v2, p1, v4}, LI/Y;-><init>(LU1/c;I)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v0, v2, p0}, LI/g;->c(LU1/c;LN1/c;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    if-ne p1, v3, :cond_3

    .line 66
    .line 67
    return-object v3

    .line 68
    :cond_3
    :goto_0
    iget-object p1, p0, LF/c;->i:LF/g;

    .line 69
    .line 70
    invoke-virtual {p1}, LF/g;->i()Lf2/q;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    if-eqz p1, :cond_4

    .line 75
    .line 76
    new-instance v0, LF/b;

    .line 77
    .line 78
    iget-object v2, p0, LF/c;->j:LF/r;

    .line 79
    .line 80
    const/4 v4, 0x0

    .line 81
    invoke-direct {v0, v4, v2}, LF/b;-><init>(ILjava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iput v1, p0, LF/c;->h:I

    .line 85
    .line 86
    check-cast p1, Lf2/v;

    .line 87
    .line 88
    invoke-static {p1, v0, p0}, Lf2/v;->k(Lf2/v;Lf2/e;LN1/c;)V

    .line 89
    .line 90
    .line 91
    return-object v3

    .line 92
    :cond_4
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 93
    .line 94
    return-object p1
.end method
