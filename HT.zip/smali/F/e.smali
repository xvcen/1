.class public final LF/e;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lx0/M;

.field public final synthetic k:LU1/c;

.field public final synthetic l:LF/g;

.field public final synthetic m:LF/u;


# direct methods
.method public constructor <init>(Lx0/M;LU1/c;LF/g;LF/u;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LF/e;->j:Lx0/M;

    .line 2
    .line 3
    iput-object p2, p0, LF/e;->k:LU1/c;

    .line 4
    .line 5
    iput-object p3, p0, LF/e;->l:LF/g;

    .line 6
    .line 7
    iput-object p4, p0, LF/e;->m:LF/u;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p5}, LP1/i;-><init>(ILN1/c;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LF/e;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LF/e;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LF/e;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    sget-object p1, LO1/a;->d:LO1/a;

    .line 17
    .line 18
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 6

    .line 1
    new-instance v0, LF/e;

    .line 2
    .line 3
    iget-object v3, p0, LF/e;->l:LF/g;

    .line 4
    .line 5
    iget-object v4, p0, LF/e;->m:LF/u;

    .line 6
    .line 7
    iget-object v1, p0, LF/e;->j:Lx0/M;

    .line 8
    .line 9
    iget-object v2, p0, LF/e;->k:LU1/c;

    .line 10
    .line 11
    move-object v5, p1

    .line 12
    invoke-direct/range {v0 .. v5}, LF/e;-><init>(Lx0/M;LU1/c;LF/g;LF/u;LN1/c;)V

    .line 13
    .line 14
    .line 15
    iput-object p2, v0, LF/e;->i:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, LO1/a;->d:LO1/a;

    .line 2
    .line 3
    iget v1, p0, LF/e;->h:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    iget-object v4, p0, LF/e;->l:LF/g;

    .line 8
    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    if-eq v1, v3, :cond_0

    .line 12
    .line 13
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 16
    .line 17
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw p1

    .line 21
    :cond_0
    :try_start_0
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    new-instance p1, LC0/e;

    .line 25
    .line 26
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 27
    .line 28
    .line 29
    throw p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, LF/e;->i:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Lc2/s;

    .line 38
    .line 39
    sget-object v1, LF/y;->a:LF/x;

    .line 40
    .line 41
    iget-object v5, p0, LF/e;->j:Lx0/M;

    .line 42
    .line 43
    iget-object v6, v5, Lx0/M;->d:Landroid/view/View;

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    new-instance v1, LF/r;

    .line 49
    .line 50
    invoke-direct {v1, v6}, LF/r;-><init>(Landroid/view/View;)V

    .line 51
    .line 52
    .line 53
    new-instance v6, LF/z;

    .line 54
    .line 55
    iget-object v7, v5, Lx0/M;->d:Landroid/view/View;

    .line 56
    .line 57
    new-instance v8, LF/d;

    .line 58
    .line 59
    iget-object v9, p0, LF/e;->m:LF/u;

    .line 60
    .line 61
    invoke-direct {v8, v9}, LF/d;-><init>(LF/u;)V

    .line 62
    .line 63
    .line 64
    invoke-direct {v6, v7, v8, v1}, LF/z;-><init>(Landroid/view/View;LF/d;LF/r;)V

    .line 65
    .line 66
    .line 67
    sget-boolean v7, LE/e;->a:Z

    .line 68
    .line 69
    if-eqz v7, :cond_2

    .line 70
    .line 71
    new-instance v7, LF/c;

    .line 72
    .line 73
    invoke-direct {v7, v4, v1, v2}, LF/c;-><init>(LF/g;LF/r;LN1/c;)V

    .line 74
    .line 75
    .line 76
    const/4 v1, 0x3

    .line 77
    invoke-static {p1, v2, v7, v1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 78
    .line 79
    .line 80
    :cond_2
    iget-object p1, p0, LF/e;->k:LU1/c;

    .line 81
    .line 82
    if-eqz p1, :cond_3

    .line 83
    .line 84
    invoke-interface {p1, v6}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    :cond_3
    iput-object v6, v4, LF/g;->c:LF/z;

    .line 88
    .line 89
    :try_start_1
    iput v3, p0, LF/e;->h:I

    .line 90
    .line 91
    invoke-virtual {v5, v6, p0}, Lx0/M;->a(LF/z;LP1/c;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 92
    .line 93
    .line 94
    return-object v0

    .line 95
    :goto_0
    iput-object v2, v4, LF/g;->c:LF/z;

    .line 96
    .line 97
    throw p1
.end method
