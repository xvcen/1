.class public final synthetic LF/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LF/l;


# direct methods
.method public synthetic constructor <init>(LF/l;I)V
    .locals 0

    .line 1
    iput p2, p0, LF/k;->d:I

    iput-object p1, p0, LF/k;->e:LF/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LF/l;LE0/v;)V
    .locals 0

    .line 2
    const/4 p2, 0x3

    iput p2, p0, LF/k;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/k;->e:LF/l;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, LF/k;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v4, p0, LF/k;->e:LF/l;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    check-cast p1, LH0/g;

    .line 12
    .line 13
    iget-boolean v0, v4, LF/l;->w:Z

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    move v2, v3

    .line 18
    goto/16 :goto_0

    .line 19
    .line 20
    :cond_0
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 21
    .line 22
    iget-object v0, v0, Lw/S;->e:LM0/D;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    new-instance v5, LM0/i;

    .line 27
    .line 28
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    new-instance v6, LM0/a;

    .line 32
    .line 33
    invoke-direct {v6, p1, v2}, LM0/a;-><init>(LH0/g;I)V

    .line 34
    .line 35
    .line 36
    const/4 p1, 0x2

    .line 37
    new-array p1, p1, [LM0/g;

    .line 38
    .line 39
    aput-object v5, p1, v3

    .line 40
    .line 41
    aput-object v6, p1, v2

    .line 42
    .line 43
    invoke-static {p1}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    iget-object v3, v4, LF/l;->v:Lw/S;

    .line 48
    .line 49
    iget-object v4, v3, Lw/S;->d:LF/r;

    .line 50
    .line 51
    iget-object v3, v3, Lw/S;->v:Lw/p;

    .line 52
    .line 53
    invoke-virtual {v4, p1}, LF/r;->m(Ljava/util/List;)LM0/x;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {v0, v1, p1}, LM0/D;->a(LM0/x;LM0/x;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v3, p1}, Lw/p;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    iget-object v0, v4, LF/l;->u:LM0/x;

    .line 65
    .line 66
    iget-object v1, v0, LM0/x;->a:LH0/g;

    .line 67
    .line 68
    iget-object v1, v1, LH0/g;->e:Ljava/lang/String;

    .line 69
    .line 70
    iget-wide v5, v0, LM0/x;->b:J

    .line 71
    .line 72
    sget v0, LH0/N;->c:I

    .line 73
    .line 74
    const/16 v0, 0x20

    .line 75
    .line 76
    shr-long v7, v5, v0

    .line 77
    .line 78
    long-to-int v7, v7

    .line 79
    const-wide v8, 0xffffffffL

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    and-long/2addr v5, v8

    .line 85
    long-to-int v5, v5

    .line 86
    const-string v6, "<this>"

    .line 87
    .line 88
    invoke-static {v1, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    const-string v6, "replacement"

    .line 92
    .line 93
    invoke-static {p1, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    if-lt v5, v7, :cond_2

    .line 97
    .line 98
    new-instance v6, Ljava/lang/StringBuilder;

    .line 99
    .line 100
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v6, v1, v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    .line 110
    .line 111
    .line 112
    move-result v3

    .line 113
    invoke-virtual {v6, v1, v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    iget-object v3, v4, LF/l;->u:LM0/x;

    .line 121
    .line 122
    iget-wide v5, v3, LM0/x;->b:J

    .line 123
    .line 124
    shr-long/2addr v5, v0

    .line 125
    long-to-int v0, v5

    .line 126
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 129
    .line 130
    .line 131
    move-result p1

    .line 132
    add-int/2addr p1, v0

    .line 133
    invoke-static {p1, p1}, LH0/F;->b(II)J

    .line 134
    .line 135
    .line 136
    move-result-wide v5

    .line 137
    iget-object p1, v4, LF/l;->v:Lw/S;

    .line 138
    .line 139
    iget-object p1, p1, Lw/S;->v:Lw/p;

    .line 140
    .line 141
    new-instance v0, LM0/x;

    .line 142
    .line 143
    const/4 v3, 0x4

    .line 144
    invoke-direct {v0, v1, v5, v6, v3}, LM0/x;-><init>(Ljava/lang/String;JI)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1, v0}, Lw/p;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    :goto_0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    return-object p1

    .line 155
    :cond_2
    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    .line 156
    .line 157
    new-instance v0, Ljava/lang/StringBuilder;

    .line 158
    .line 159
    const-string v1, "End index ("

    .line 160
    .line 161
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    const-string v1, ") is less than start index ("

    .line 168
    .line 169
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    const-string v1, ")."

    .line 176
    .line 177
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    invoke-direct {p1, v0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    throw p1

    .line 188
    :pswitch_0
    check-cast p1, LH0/g;

    .line 189
    .line 190
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 191
    .line 192
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 193
    .line 194
    iget-boolean v1, v4, LF/l;->w:Z

    .line 195
    .line 196
    invoke-static {v0, p1, v1}, LF/l;->X0(Lw/S;Ljava/lang/String;Z)V

    .line 197
    .line 198
    .line 199
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 200
    .line 201
    return-object p1

    .line 202
    :pswitch_1
    check-cast p1, Ljava/util/List;

    .line 203
    .line 204
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 205
    .line 206
    invoke-virtual {v0}, Lw/S;->d()Lw/p0;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    if-eqz v0, :cond_3

    .line 211
    .line 212
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 213
    .line 214
    invoke-virtual {v0}, Lw/S;->d()Lw/p0;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    iget-object v0, v0, Lw/p0;->a:LH0/L;

    .line 222
    .line 223
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    goto :goto_1

    .line 227
    :cond_3
    move v2, v3

    .line 228
    :goto_1
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    return-object p1

    .line 233
    :pswitch_2
    check-cast p1, LX/g;

    .line 234
    .line 235
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 236
    .line 237
    iget-object v0, v0, Lw/S;->t:LI/m0;

    .line 238
    .line 239
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 240
    .line 241
    invoke-virtual {v0, v2}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 242
    .line 243
    .line 244
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 245
    .line 246
    iget-object v0, v0, Lw/S;->s:LI/m0;

    .line 247
    .line 248
    invoke-virtual {v0, v2}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 249
    .line 250
    .line 251
    iget-object v0, v4, LF/l;->v:Lw/S;

    .line 252
    .line 253
    iget-object v3, p1, LX/g;->a:Landroid/view/autofill/AutofillValue;

    .line 254
    .line 255
    invoke-static {v3}, LI0/g;->x(Landroid/view/autofill/AutofillValue;)Z

    .line 256
    .line 257
    .line 258
    move-result v3

    .line 259
    if-eqz v3, :cond_4

    .line 260
    .line 261
    iget-object p1, p1, LX/g;->a:Landroid/view/autofill/AutofillValue;

    .line 262
    .line 263
    invoke-static {p1}, LI0/g;->i(Landroid/view/autofill/AutofillValue;)Ljava/lang/CharSequence;

    .line 264
    .line 265
    .line 266
    move-result-object v1

    .line 267
    :cond_4
    const-string p1, "null cannot be cast to non-null type kotlin.String"

    .line 268
    .line 269
    invoke-static {v1, p1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    check-cast v1, Ljava/lang/String;

    .line 273
    .line 274
    iget-boolean p1, v4, LF/l;->w:Z

    .line 275
    .line 276
    invoke-static {v0, v1, p1}, LF/l;->X0(Lw/S;Ljava/lang/String;Z)V

    .line 277
    .line 278
    .line 279
    return-object v2

    .line 280
    nop

    .line 281
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
