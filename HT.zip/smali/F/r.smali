.class public final LF/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI/i;
.implements LJ/I;
.implements LJ0/d;
.implements LT/f;
.implements Lf2/d;
.implements Ll1/o;


# instance fields
.field public final synthetic d:I

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, LF/r;->d:I

    sparse-switch p1, :sswitch_data_0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    new-instance p1, Li/E;

    invoke-direct {p1}, Li/E;-><init>()V

    .line 29
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 30
    new-instance p1, Li/E;

    invoke-direct {p1}, Li/E;-><init>()V

    .line 31
    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void

    .line 32
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    new-instance p1, LK/e;

    const/16 v0, 0x10

    new-array v0, v0, [Ljava/lang/ref/Reference;

    invoke-direct {p1, v0}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 34
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 35
    new-instance p1, Ljava/lang/ref/ReferenceQueue;

    invoke-direct {p1}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void

    .line 36
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 37
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1a

    if-lt p1, v0, :cond_0

    .line 38
    new-instance p1, Lh1/i;

    .line 39
    invoke-direct {p1, p0}, Lh1/h;-><init>(LF/r;)V

    .line 40
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    goto :goto_0

    .line 41
    :cond_0
    new-instance p1, Lh1/h;

    invoke-direct {p1, p0}, Lh1/h;-><init>(LF/r;)V

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    :goto_0
    return-void

    .line 42
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    new-instance p1, LK/e;

    const/16 v0, 0x10

    new-array v0, v0, [Lw0/E;

    invoke-direct {p1, v0}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 44
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    return-void

    .line 45
    :sswitch_3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    new-instance p1, Lr0/d;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Lr0/d;-><init>(I)V

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 47
    new-instance p1, Lr0/d;

    invoke-direct {p1, v0}, Lr0/d;-><init>(I)V

    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void

    .line 48
    :sswitch_4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 49
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object p1

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    return-void

    .line 50
    :sswitch_5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 51
    new-instance p1, LA1/i;

    const/16 v0, 0x8

    .line 52
    invoke-direct {p1, v0}, LA1/i;-><init>(I)V

    .line 53
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 54
    new-instance p1, Li/t;

    const/16 v0, 0x10

    invoke-direct {p1, v0}, Li/t;-><init>(I)V

    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void

    :sswitch_data_0
    .sparse-switch
        0x6 -> :sswitch_5
        0xe -> :sswitch_4
        0x13 -> :sswitch_3
        0x1b -> :sswitch_2
        0x1c -> :sswitch_1
        0x1d -> :sswitch_0
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LF/r;->d:I

    iput-object p2, p0, LF/r;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LF/r;->d:I

    iput-object p2, p0, LF/r;->e:Ljava/lang/Object;

    iput-object p3, p0, LF/r;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .locals 0

    .line 3
    iput p1, p0, LF/r;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LA0/h;)V
    .locals 1

    const/16 v0, 0x12

    iput v0, p0, LF/r;->d:I

    .line 23
    sget-object v0, Lp/z0;->c:Lp/u0;

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 26
    iput-object v0, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LA1/b;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, LF/r;->d:I

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 10
    new-instance p1, LQ/a;

    const/4 v0, 0x0

    .line 11
    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 12
    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LF/r;->d:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 14
    new-instance p1, LA1/P;

    const/4 v0, 0x7

    invoke-direct {p1, v0, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    invoke-static {p1}, La/a;->B(LU1/a;)LJ1/d;

    move-result-object p1

    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsetsAnimation$Bounds;)V
    .locals 1

    const/16 v0, 0xc

    iput v0, p0, LF/r;->d:I

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    invoke-static {p1}, LI0/b;->f(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lb1/b;->c(Landroid/graphics/Insets;)Lb1/b;

    move-result-object v0

    .line 20
    iput-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 21
    invoke-static {p1}, LI0/b;->z(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p1}, Lb1/b;->c(Landroid/graphics/Insets;)Lb1/b;

    move-result-object p1

    .line 22
    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 1

    const/16 v0, 0xe

    iput v0, p0, LF/r;->d:I

    .line 15
    invoke-direct {p0, v0}, LF/r;-><init>(I)V

    .line 16
    invoke-static {p1}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object v0

    iput-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 17
    invoke-static {p1}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    return-void
.end method

.method public constructor <init>(Lw0/E;Lu0/z;)V
    .locals 1

    const/16 v0, 0x19

    iput v0, p0, LF/r;->d:I

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 8
    invoke-static {p2}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    move-result-object p1

    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lw1/a;)V
    .locals 2

    const/16 v0, 0x17

    iput v0, p0, LF/r;->d:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, LF/r;->e:Ljava/lang/Object;

    .line 6
    new-instance v0, LF/r;

    const/16 v1, 0x16

    invoke-direct {v0, v1, p1}, LF/r;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LF/r;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lx0/x;)V
    .locals 1

    const/16 v0, 0x1c

    iput v0, p0, LF/r;->d:I

    .line 55
    iput-object p1, p0, LF/r;->f:Ljava/lang/Object;

    const/16 p1, 0x1c

    invoke-direct {p0, p1}, LF/r;-><init>(I)V

    return-void
.end method

.method public static p(Lw0/E;)V
    .locals 10

    .line 1
    iget v0, p0, Lw0/E;->P:I

    .line 2
    .line 3
    if-lez v0, :cond_b

    .line 4
    .line 5
    iget-object v0, p0, Lw0/E;->J:Lw0/H;

    .line 6
    .line 7
    iget-object v0, v0, Lw0/H;->c:Lw0/A;

    .line 8
    .line 9
    sget-object v1, Lw0/A;->h:Lw0/A;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_a

    .line 13
    .line 14
    invoke-virtual {p0}, Lw0/E;->l()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_a

    .line 19
    .line 20
    invoke-virtual {p0}, Lw0/E;->m()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_a

    .line 25
    .line 26
    iget-boolean v0, p0, Lw0/E;->Q:Z

    .line 27
    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    goto/16 :goto_5

    .line 31
    .line 32
    :cond_0
    invoke-virtual {p0}, Lw0/E;->D()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    goto/16 :goto_5

    .line 39
    .line 40
    :cond_1
    iget-object v0, p0, Lw0/E;->I:LQ/m;

    .line 41
    .line 42
    iget-object v0, v0, LQ/m;->j:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, LW/p;

    .line 45
    .line 46
    iget v1, v0, LW/p;->g:I

    .line 47
    .line 48
    const/16 v3, 0x100

    .line 49
    .line 50
    and-int/2addr v1, v3

    .line 51
    if-eqz v1, :cond_a

    .line 52
    .line 53
    :goto_0
    if-eqz v0, :cond_a

    .line 54
    .line 55
    iget v1, v0, LW/p;->f:I

    .line 56
    .line 57
    and-int/2addr v1, v3

    .line 58
    if-eqz v1, :cond_9

    .line 59
    .line 60
    const/4 v1, 0x0

    .line 61
    move-object v4, v0

    .line 62
    move-object v5, v1

    .line 63
    :goto_1
    if-eqz v4, :cond_9

    .line 64
    .line 65
    instance-of v6, v4, Lw0/m;

    .line 66
    .line 67
    if-eqz v6, :cond_2

    .line 68
    .line 69
    check-cast v4, Lw0/m;

    .line 70
    .line 71
    invoke-static {v4, v3}, Lw0/j;->r(Lw0/h;I)Lw0/b0;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    invoke-interface {v4, v6}, Lw0/m;->O(Lw0/b0;)V

    .line 76
    .line 77
    .line 78
    goto :goto_4

    .line 79
    :cond_2
    iget v6, v4, LW/p;->f:I

    .line 80
    .line 81
    and-int/2addr v6, v3

    .line 82
    if-eqz v6, :cond_8

    .line 83
    .line 84
    instance-of v6, v4, Lw0/i;

    .line 85
    .line 86
    if-eqz v6, :cond_8

    .line 87
    .line 88
    move-object v6, v4

    .line 89
    check-cast v6, Lw0/i;

    .line 90
    .line 91
    iget-object v6, v6, Lw0/i;->s:LW/p;

    .line 92
    .line 93
    move v7, v2

    .line 94
    :goto_2
    const/4 v8, 0x1

    .line 95
    if-eqz v6, :cond_7

    .line 96
    .line 97
    iget v9, v6, LW/p;->f:I

    .line 98
    .line 99
    and-int/2addr v9, v3

    .line 100
    if-eqz v9, :cond_6

    .line 101
    .line 102
    add-int/lit8 v7, v7, 0x1

    .line 103
    .line 104
    if-ne v7, v8, :cond_3

    .line 105
    .line 106
    move-object v4, v6

    .line 107
    goto :goto_3

    .line 108
    :cond_3
    if-nez v5, :cond_4

    .line 109
    .line 110
    new-instance v5, LK/e;

    .line 111
    .line 112
    const/16 v8, 0x10

    .line 113
    .line 114
    new-array v8, v8, [LW/p;

    .line 115
    .line 116
    invoke-direct {v5, v8}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_4
    if-eqz v4, :cond_5

    .line 120
    .line 121
    invoke-virtual {v5, v4}, LK/e;->b(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    move-object v4, v1

    .line 125
    :cond_5
    invoke-virtual {v5, v6}, LK/e;->b(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :cond_6
    :goto_3
    iget-object v6, v6, LW/p;->i:LW/p;

    .line 129
    .line 130
    goto :goto_2

    .line 131
    :cond_7
    if-ne v7, v8, :cond_8

    .line 132
    .line 133
    goto :goto_1

    .line 134
    :cond_8
    :goto_4
    invoke-static {v5}, Lw0/j;->e(LK/e;)LW/p;

    .line 135
    .line 136
    .line 137
    move-result-object v4

    .line 138
    goto :goto_1

    .line 139
    :cond_9
    iget v1, v0, LW/p;->g:I

    .line 140
    .line 141
    and-int/2addr v1, v3

    .line 142
    if-eqz v1, :cond_a

    .line 143
    .line 144
    iget-object v0, v0, LW/p;->i:LW/p;

    .line 145
    .line 146
    goto :goto_0

    .line 147
    :cond_a
    :goto_5
    iput-boolean v2, p0, Lw0/E;->O:Z

    .line 148
    .line 149
    invoke-virtual {p0}, Lw0/E;->u()LK/e;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    iget-object v0, p0, LK/e;->d:[Ljava/lang/Object;

    .line 154
    .line 155
    iget p0, p0, LK/e;->f:I

    .line 156
    .line 157
    :goto_6
    if-ge v2, p0, :cond_b

    .line 158
    .line 159
    aget-object v1, v0, v2

    .line 160
    .line 161
    check-cast v1, Lw0/E;

    .line 162
    .line 163
    invoke-static {v1}, LF/r;->p(Lw0/E;)V

    .line 164
    .line 165
    .line 166
    add-int/lit8 v2, v2, 0x1

    .line 167
    .line 168
    goto :goto_6

    .line 169
    :cond_b
    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ll1/x;

    .line 4
    .line 5
    return-object v0
.end method

.method public b(Ljava/lang/CharSequence;IILl1/u;)Z
    .locals 3

    .line 1
    iget v0, p4, Ll1/u;->c:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x4

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-lez v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Ll1/x;

    .line 12
    .line 13
    if-nez v0, :cond_2

    .line 14
    .line 15
    new-instance v0, Ll1/x;

    .line 16
    .line 17
    instance-of v2, p1, Landroid/text/Spannable;

    .line 18
    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    check-cast p1, Landroid/text/Spannable;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    new-instance v2, Landroid/text/SpannableString;

    .line 25
    .line 26
    invoke-direct {v2, p1}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 27
    .line 28
    .line 29
    move-object p1, v2

    .line 30
    :goto_0
    invoke-direct {v0, p1}, Ll1/x;-><init>(Landroid/text/Spannable;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 34
    .line 35
    :cond_2
    iget-object p1, p0, LF/r;->f:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, LA1/i;

    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    new-instance p1, Ll1/v;

    .line 43
    .line 44
    invoke-direct {p1, p4}, Ll1/v;-><init>(Ll1/u;)V

    .line 45
    .line 46
    .line 47
    iget-object p4, p0, LF/r;->e:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p4, Ll1/x;

    .line 50
    .line 51
    const/16 v0, 0x21

    .line 52
    .line 53
    invoke-virtual {p4, p1, p2, p3, v0}, Ll1/x;->setSpan(Ljava/lang/Object;III)V

    .line 54
    .line 55
    .line 56
    return v1
.end method

.method public c(LT/b;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LU1/e;

    .line 4
    .line 5
    invoke-interface {v0, p1, p2}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public cancel()V
    .locals 2

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LQ/a;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, LA1/b;

    .line 15
    .line 16
    invoke-virtual {v0}, LA1/b;->a()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public d(Lf2/e;LN1/c;)Ljava/lang/Object;
    .locals 5

    .line 1
    new-instance v0, LV1/o;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LF/r;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v1, Lg2/n;

    .line 9
    .line 10
    new-instance v2, Lf2/h;

    .line 11
    .line 12
    iget-object v3, p0, LF/r;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v3, Lf2/C;

    .line 15
    .line 16
    const/4 v4, 0x0

    .line 17
    invoke-direct {v2, v0, p1, v3, v4}, Lf2/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, v2, p2}, Lg2/h;->d(Lf2/e;LN1/c;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    sget-object p2, LO1/a;->d:LO1/a;

    .line 25
    .line 26
    if-ne p1, p2, :cond_0

    .line 27
    .line 28
    return-object p1

    .line 29
    :cond_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 30
    .line 31
    return-object p1
.end method

.method public e(I)I
    .locals 1

    .line 1
    :cond_0
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LJ0/e;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LJ0/e;->j(I)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    const/4 v0, -0x1

    .line 10
    if-ne p1, v0, :cond_1

    .line 11
    .line 12
    return v0

    .line 13
    :cond_1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Ljava/lang/CharSequence;

    .line 16
    .line 17
    invoke-interface {v0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    return p1
.end method

.method public f(Ljava/lang/Integer;)Ljava/util/List;
    .locals 4

    .line 1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LJ/I;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-interface {v0, v1}, LJ/I;->f(Ljava/lang/Integer;)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LI/P0;

    .line 13
    .line 14
    iget v2, v1, LI/P0;->v:I

    .line 15
    .line 16
    if-gez v2, :cond_0

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_0
    iget-object v3, v1, LI/P0;->b:[I

    .line 20
    .line 21
    invoke-virtual {v1, v3, v2}, LI/P0;->D([II)I

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-static {v1, p1, v2, v3}, LT0/l;->f(LI/P0;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-static {p1, v0}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    return-object p1
.end method

.method public g(I)I
    .locals 2

    .line 1
    :cond_0
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LJ0/e;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LJ0/e;->i(I)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    const/4 v0, -0x1

    .line 10
    if-ne p1, v0, :cond_1

    .line 11
    .line 12
    return v0

    .line 13
    :cond_1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Ljava/lang/CharSequence;

    .line 16
    .line 17
    add-int/lit8 v1, p1, -0x1

    .line 18
    .line 19
    invoke-interface {v0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    return p1
.end method

.method public h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LU1/c;

    .line 4
    .line 5
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public j(I)I
    .locals 3

    .line 1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/CharSequence;

    .line 4
    .line 5
    :cond_0
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LJ0/e;

    .line 8
    .line 9
    invoke-virtual {v1, p1}, LJ0/e;->i(I)I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    const/4 v1, -0x1

    .line 14
    if-eq p1, v1, :cond_2

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-ne p1, v2, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    invoke-interface {v0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    invoke-static {v1}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    return p1

    .line 34
    :cond_2
    :goto_0
    return v1
.end method

.method public k(I)I
    .locals 2

    .line 1
    :cond_0
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LJ0/e;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LJ0/e;->j(I)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    const/4 v0, -0x1

    .line 10
    if-eq p1, v0, :cond_1

    .line 11
    .line 12
    if-eqz p1, :cond_1

    .line 13
    .line 14
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Ljava/lang/CharSequence;

    .line 17
    .line 18
    add-int/lit8 v1, p1, -0x1

    .line 19
    .line 20
    invoke-interface {v0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    return p1

    .line 31
    :cond_1
    return v0
.end method

.method public l(J)Z
    .locals 7

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LF/r;

    .line 4
    .line 5
    iget-object v0, v0, LF/r;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Ljava/util/List;

    .line 8
    .line 9
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x0

    .line 14
    move v3, v2

    .line 15
    :goto_0
    if-ge v3, v1, :cond_1

    .line 16
    .line 17
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    move-object v5, v4

    .line 22
    check-cast v5, Lq0/x;

    .line 23
    .line 24
    iget-wide v5, v5, Lq0/x;->a:J

    .line 25
    .line 26
    invoke-static {v5, v6, p1, p2}, Lq0/t;->e(JJ)Z

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    if-eqz v5, :cond_0

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    const/4 v4, 0x0

    .line 37
    :goto_1
    check-cast v4, Lq0/x;

    .line 38
    .line 39
    if-eqz v4, :cond_2

    .line 40
    .line 41
    iget-boolean p1, v4, Lq0/x;->h:Z

    .line 42
    .line 43
    return p1

    .line 44
    :cond_2
    return v2
.end method

.method public m(Ljava/util/List;)LM0/x;
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    .line 3
    .line 4
    .line 5
    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v3, v0

    .line 8
    :goto_0
    if-ge v2, v1, :cond_0

    .line 9
    .line 10
    :try_start_1
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    check-cast v4, LM0/g;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 15
    .line 16
    :try_start_2
    iget-object v3, p0, LF/r;->f:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v3, LM0/h;

    .line 19
    .line 20
    invoke-interface {v4, v3}, LM0/g;->a(LM0/h;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 21
    .line 22
    .line 23
    add-int/lit8 v2, v2, 0x1

    .line 24
    .line 25
    move-object v3, v4

    .line 26
    goto :goto_0

    .line 27
    :catch_0
    move-exception v0

    .line 28
    move-object v3, v4

    .line 29
    goto :goto_2

    .line 30
    :catch_1
    move-exception v0

    .line 31
    goto :goto_2

    .line 32
    :cond_0
    iget-object p1, p0, LF/r;->f:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p1, LM0/h;

    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    new-instance v1, LH0/g;

    .line 40
    .line 41
    iget-object p1, p1, LM0/h;->a:LJ0/e;

    .line 42
    .line 43
    invoke-virtual {p1}, LJ0/e;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-direct {v1, p1}, LH0/g;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, LF/r;->f:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast p1, LM0/h;

    .line 53
    .line 54
    iget v2, p1, LM0/h;->b:I

    .line 55
    .line 56
    iget p1, p1, LM0/h;->c:I

    .line 57
    .line 58
    invoke-static {v2, p1}, LH0/F;->b(II)J

    .line 59
    .line 60
    .line 61
    move-result-wide v2

    .line 62
    new-instance p1, LH0/N;

    .line 63
    .line 64
    invoke-direct {p1, v2, v3}, LH0/N;-><init>(J)V

    .line 65
    .line 66
    .line 67
    iget-object v4, p0, LF/r;->e:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v4, LM0/x;

    .line 70
    .line 71
    iget-wide v4, v4, LM0/x;->b:J

    .line 72
    .line 73
    invoke-static {v4, v5}, LH0/N;->g(J)Z

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    if-nez v4, :cond_1

    .line 78
    .line 79
    move-object v0, p1

    .line 80
    :cond_1
    if-eqz v0, :cond_2

    .line 81
    .line 82
    iget-wide v2, v0, LH0/N;->a:J

    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_2
    invoke-static {v2, v3}, LH0/N;->e(J)I

    .line 86
    .line 87
    .line 88
    move-result p1

    .line 89
    invoke-static {v2, v3}, LH0/N;->f(J)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-static {p1, v0}, LH0/F;->b(II)J

    .line 94
    .line 95
    .line 96
    move-result-wide v2

    .line 97
    :goto_1
    iget-object p1, p0, LF/r;->f:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p1, LM0/h;

    .line 100
    .line 101
    invoke-virtual {p1}, LM0/h;->c()LH0/N;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    new-instance v0, LM0/x;

    .line 106
    .line 107
    invoke-direct {v0, v1, v2, v3, p1}, LM0/x;-><init>(LH0/g;JLH0/N;)V

    .line 108
    .line 109
    .line 110
    iput-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 111
    .line 112
    return-object v0

    .line 113
    :catch_2
    move-exception v1

    .line 114
    move-object v3, v0

    .line 115
    move-object v0, v1

    .line 116
    :goto_2
    new-instance v1, Ljava/lang/RuntimeException;

    .line 117
    .line 118
    new-instance v2, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 121
    .line 122
    .line 123
    new-instance v4, Ljava/lang/StringBuilder;

    .line 124
    .line 125
    const-string v5, "Error while applying EditCommand batch to buffer (length="

    .line 126
    .line 127
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    iget-object v5, p0, LF/r;->f:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v5, LM0/h;

    .line 133
    .line 134
    iget-object v5, v5, LM0/h;->a:LJ0/e;

    .line 135
    .line 136
    invoke-virtual {v5}, LJ0/e;->b()I

    .line 137
    .line 138
    .line 139
    move-result v5

    .line 140
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    const-string v5, ", composition="

    .line 144
    .line 145
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    iget-object v5, p0, LF/r;->f:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v5, LM0/h;

    .line 151
    .line 152
    invoke-virtual {v5}, LM0/h;->c()LH0/N;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 157
    .line 158
    .line 159
    const-string v5, ", selection="

    .line 160
    .line 161
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    .line 163
    .line 164
    iget-object v5, p0, LF/r;->f:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast v5, LM0/h;

    .line 167
    .line 168
    iget v6, v5, LM0/h;->b:I

    .line 169
    .line 170
    iget v5, v5, LM0/h;->c:I

    .line 171
    .line 172
    invoke-static {v6, v5}, LH0/F;->b(II)J

    .line 173
    .line 174
    .line 175
    move-result-wide v5

    .line 176
    invoke-static {v5, v6}, LH0/N;->h(J)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v5

    .line 180
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    const-string v5, "):"

    .line 184
    .line 185
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v4

    .line 192
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    const/16 v4, 0xa

    .line 196
    .line 197
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 198
    .line 199
    .line 200
    new-instance v4, LB/y;

    .line 201
    .line 202
    const/16 v5, 0xf

    .line 203
    .line 204
    invoke-direct {v4, v5, v3, p0}, LB/y;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    const/16 v3, 0x3c

    .line 208
    .line 209
    invoke-static {p1, v2, v4, v3}, LK1/m;->w0(Ljava/util/List;Ljava/lang/StringBuilder;LB/y;I)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    const-string v2, "toString(...)"

    .line 217
    .line 218
    invoke-static {p1, v2}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    invoke-direct {v1, p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 222
    .line 223
    .line 224
    throw v1
.end method

.method public n(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 4

    .line 1
    const-string v0, "key"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw1/a;

    .line 9
    .line 10
    iget-boolean v1, v0, Lw1/a;->g:Z

    .line 11
    .line 12
    if-eqz v1, :cond_3

    .line 13
    .line 14
    iget-object v1, v0, Lw1/a;->f:Landroid/os/Bundle;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    return-object v2

    .line 20
    :cond_0
    invoke-virtual {v1, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_1

    .line 25
    .line 26
    invoke-static {p1, v1}, LT0/l;->A(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    move-object v3, v2

    .line 32
    :goto_0
    invoke-virtual {v1, p1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-eqz p1, :cond_2

    .line 40
    .line 41
    iput-object v2, v0, Lw1/a;->f:Landroid/os/Bundle;

    .line 42
    .line 43
    :cond_2
    return-object v3

    .line 44
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    const-string v0, "You can \'consumeRestoredStateForKey\' only after the corresponding component has moved to the \'CREATED\' state"

    .line 47
    .line 48
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p1
.end method

.method public o(I)Lh1/g;
    .locals 47

    .line 1
    move/from16 v0, p1

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    move-object/from16 v3, p0

    .line 9
    .line 10
    iget-object v4, v3, LF/r;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v4, Lx0/x;

    .line 13
    .line 14
    iget-object v5, v4, Lx0/x;->j:Landroid/view/accessibility/AccessibilityManager;

    .line 15
    .line 16
    iget-object v6, v4, Lx0/x;->g:Lx0/s;

    .line 17
    .line 18
    invoke-virtual {v6}, Lx0/s;->getViewTreeOwners()Lx0/l;

    .line 19
    .line 20
    .line 21
    move-result-object v7

    .line 22
    if-eqz v7, :cond_0

    .line 23
    .line 24
    iget-object v7, v7, Lx0/l;->a:Landroidx/lifecycle/u;

    .line 25
    .line 26
    invoke-interface {v7}, Landroidx/lifecycle/u;->a()Landroidx/lifecycle/w;

    .line 27
    .line 28
    .line 29
    move-result-object v7

    .line 30
    if-eqz v7, :cond_0

    .line 31
    .line 32
    iget-object v7, v7, Landroidx/lifecycle/w;->c:Landroidx/lifecycle/p;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_0
    const/4 v7, 0x0

    .line 36
    :goto_0
    sget-object v9, Landroidx/lifecycle/p;->d:Landroidx/lifecycle/p;

    .line 37
    .line 38
    if-ne v7, v9, :cond_2

    .line 39
    .line 40
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_1

    .line 45
    .line 46
    invoke-static {}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain()Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    new-instance v8, Lh1/g;

    .line 51
    .line 52
    invoke-direct {v8, v1}, Lh1/g;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 53
    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_1
    const/4 v8, 0x0

    .line 57
    :goto_1
    move-object v15, v8

    .line 58
    move-object v8, v4

    .line 59
    :goto_2
    move v4, v0

    .line 60
    goto/16 :goto_5a

    .line 61
    .line 62
    :cond_2
    invoke-virtual {v4}, Lx0/x;->k()Li/l;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    invoke-virtual {v7, v0}, Li/l;->b(I)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    check-cast v7, LE0/o;

    .line 71
    .line 72
    if-nez v7, :cond_3

    .line 73
    .line 74
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-nez v1, :cond_1

    .line 79
    .line 80
    invoke-static {}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain()Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    new-instance v8, Lh1/g;

    .line 85
    .line 86
    invoke-direct {v8, v1}, Lh1/g;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_3
    iget-object v9, v7, LE0/o;->a:LE0/n;

    .line 91
    .line 92
    invoke-virtual {v9}, LE0/n;->k()LE0/k;

    .line 93
    .line 94
    .line 95
    move-result-object v10

    .line 96
    iget-object v11, v9, LE0/n;->c:Lw0/E;

    .line 97
    .line 98
    sget-object v12, LE0/r;->m:LE0/u;

    .line 99
    .line 100
    iget-object v10, v10, LE0/k;->d:Li/E;

    .line 101
    .line 102
    invoke-virtual {v10, v12}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v10

    .line 106
    if-nez v10, :cond_4

    .line 107
    .line 108
    const/4 v10, 0x0

    .line 109
    :cond_4
    sget-object v12, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 110
    .line 111
    invoke-static {v10, v12}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v10

    .line 115
    const/16 v12, 0x22

    .line 116
    .line 117
    if-eqz v10, :cond_6

    .line 118
    .line 119
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 120
    .line 121
    if-lt v14, v12, :cond_5

    .line 122
    .line 123
    invoke-static {v5}, Lh1/b;->e(Landroid/view/accessibility/AccessibilityManager;)Z

    .line 124
    .line 125
    .line 126
    move-result v14

    .line 127
    goto :goto_3

    .line 128
    :cond_5
    const/4 v14, 0x1

    .line 129
    :goto_3
    if-nez v14, :cond_6

    .line 130
    .line 131
    move-object v8, v4

    .line 132
    const/4 v15, 0x0

    .line 133
    goto :goto_2

    .line 134
    :cond_6
    invoke-static {}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain()Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 135
    .line 136
    .line 137
    move-result-object v14

    .line 138
    new-instance v15, Lh1/g;

    .line 139
    .line 140
    invoke-direct {v15, v14}, Lh1/g;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 141
    .line 142
    .line 143
    const/16 v16, 0x0

    .line 144
    .line 145
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 146
    .line 147
    if-lt v8, v12, :cond_7

    .line 148
    .line 149
    invoke-static {v14, v10}, Lh1/b;->g(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 150
    .line 151
    .line 152
    goto :goto_4

    .line 153
    :cond_7
    const/16 v1, 0x40

    .line 154
    .line 155
    invoke-virtual {v15, v1, v10}, Lh1/g;->f(IZ)V

    .line 156
    .line 157
    .line 158
    :goto_4
    const/4 v1, -0x1

    .line 159
    if-ne v0, v1, :cond_9

    .line 160
    .line 161
    invoke-virtual {v6}, Landroid/view/View;->getParentForAccessibility()Landroid/view/ViewParent;

    .line 162
    .line 163
    .line 164
    move-result-object v10

    .line 165
    instance-of v13, v10, Landroid/view/View;

    .line 166
    .line 167
    if-eqz v13, :cond_8

    .line 168
    .line 169
    check-cast v10, Landroid/view/View;

    .line 170
    .line 171
    goto :goto_5

    .line 172
    :cond_8
    move-object/from16 v10, v16

    .line 173
    .line 174
    :goto_5
    iput v1, v15, Lh1/g;->b:I

    .line 175
    .line 176
    invoke-virtual {v14, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;)V

    .line 177
    .line 178
    .line 179
    goto :goto_7

    .line 180
    :cond_9
    invoke-virtual {v9}, LE0/n;->l()LE0/n;

    .line 181
    .line 182
    .line 183
    move-result-object v10

    .line 184
    if-eqz v10, :cond_a

    .line 185
    .line 186
    iget v10, v10, LE0/n;->g:I

    .line 187
    .line 188
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 189
    .line 190
    .line 191
    move-result-object v10

    .line 192
    goto :goto_6

    .line 193
    :cond_a
    move-object/from16 v10, v16

    .line 194
    .line 195
    :goto_6
    if-eqz v10, :cond_ad

    .line 196
    .line 197
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 198
    .line 199
    .line 200
    move-result v10

    .line 201
    invoke-virtual {v6}, Lx0/s;->getSemanticsOwner()LE0/p;

    .line 202
    .line 203
    .line 204
    move-result-object v13

    .line 205
    invoke-virtual {v13}, LE0/p;->a()LE0/n;

    .line 206
    .line 207
    .line 208
    move-result-object v13

    .line 209
    iget v13, v13, LE0/n;->g:I

    .line 210
    .line 211
    if-ne v10, v13, :cond_b

    .line 212
    .line 213
    move v10, v1

    .line 214
    :cond_b
    iput v10, v15, Lh1/g;->b:I

    .line 215
    .line 216
    invoke-virtual {v14, v6, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;I)V

    .line 217
    .line 218
    .line 219
    :goto_7
    iput v0, v15, Lh1/g;->c:I

    .line 220
    .line 221
    invoke-virtual {v14, v6, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSource(Landroid/view/View;I)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v4, v7}, Lx0/x;->c(LE0/o;)Landroid/graphics/Rect;

    .line 225
    .line 226
    .line 227
    move-result-object v7

    .line 228
    invoke-virtual {v14, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInScreen(Landroid/graphics/Rect;)V

    .line 229
    .line 230
    .line 231
    iget-object v7, v4, Lx0/x;->N:Li/v;

    .line 232
    .line 233
    iget-object v10, v4, Lx0/x;->w:Li/N;

    .line 234
    .line 235
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 236
    .line 237
    .line 238
    move-result-object v13

    .line 239
    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 240
    .line 241
    .line 242
    move-result-object v13

    .line 243
    const-string v1, "android.view.View"

    .line 244
    .line 245
    invoke-virtual {v15, v1}, Lh1/g;->g(Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    iget-object v1, v9, LE0/n;->d:LE0/k;

    .line 249
    .line 250
    iget-object v12, v1, LE0/k;->d:Li/E;

    .line 251
    .line 252
    move-object/from16 v18, v2

    .line 253
    .line 254
    sget-object v2, LE0/r;->D:LE0/u;

    .line 255
    .line 256
    invoke-virtual {v12, v2}, Li/E;->c(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result v2

    .line 260
    if-eqz v2, :cond_c

    .line 261
    .line 262
    const-string v2, "android.widget.EditText"

    .line 263
    .line 264
    invoke-virtual {v15, v2}, Lh1/g;->g(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    :cond_c
    sget-object v2, LE0/r;->z:LE0/u;

    .line 268
    .line 269
    invoke-virtual {v12, v2}, Li/E;->c(Ljava/lang/Object;)Z

    .line 270
    .line 271
    .line 272
    move-result v2

    .line 273
    if-eqz v2, :cond_d

    .line 274
    .line 275
    const-string v2, "android.widget.TextView"

    .line 276
    .line 277
    invoke-virtual {v15, v2}, Lh1/g;->g(Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    :cond_d
    sget-object v2, LE0/r;->w:LE0/u;

    .line 281
    .line 282
    invoke-virtual {v12, v2}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v2

    .line 286
    if-nez v2, :cond_e

    .line 287
    .line 288
    move-object/from16 v2, v16

    .line 289
    .line 290
    :cond_e
    check-cast v2, LE0/g;

    .line 291
    .line 292
    if-eqz v2, :cond_13

    .line 293
    .line 294
    iget v3, v2, LE0/g;->a:I

    .line 295
    .line 296
    move-object/from16 v21, v5

    .line 297
    .line 298
    iget-boolean v5, v9, LE0/n;->e:Z

    .line 299
    .line 300
    if-nez v5, :cond_f

    .line 301
    .line 302
    const/4 v5, 0x4

    .line 303
    invoke-static {v5, v9}, LE0/n;->j(ILE0/n;)Ljava/util/List;

    .line 304
    .line 305
    .line 306
    move-result-object v20

    .line 307
    invoke-interface/range {v20 .. v20}, Ljava/util/List;->isEmpty()Z

    .line 308
    .line 309
    .line 310
    move-result v20

    .line 311
    move-object/from16 v22, v10

    .line 312
    .line 313
    if-eqz v20, :cond_14

    .line 314
    .line 315
    goto :goto_8

    .line 316
    :cond_f
    const/4 v5, 0x4

    .line 317
    move-object/from16 v22, v10

    .line 318
    .line 319
    :goto_8
    const-string v10, "AccessibilityNodeInfo.roleDescription"

    .line 320
    .line 321
    if-ne v3, v5, :cond_10

    .line 322
    .line 323
    const v3, 0x7f080024

    .line 324
    .line 325
    .line 326
    invoke-virtual {v13, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object v3

    .line 330
    invoke-virtual {v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 331
    .line 332
    .line 333
    move-result-object v5

    .line 334
    invoke-virtual {v5, v10, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 335
    .line 336
    .line 337
    goto :goto_9

    .line 338
    :cond_10
    const/4 v5, 0x2

    .line 339
    if-ne v3, v5, :cond_11

    .line 340
    .line 341
    const v3, 0x7f080023

    .line 342
    .line 343
    .line 344
    invoke-virtual {v13, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v3

    .line 348
    invoke-virtual {v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 349
    .line 350
    .line 351
    move-result-object v5

    .line 352
    invoke-virtual {v5, v10, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 353
    .line 354
    .line 355
    goto :goto_9

    .line 356
    :cond_11
    invoke-static {v3}, Lx0/E;->r(I)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v5

    .line 360
    const/4 v10, 0x5

    .line 361
    if-ne v3, v10, :cond_12

    .line 362
    .line 363
    invoke-virtual {v9}, LE0/n;->o()Z

    .line 364
    .line 365
    .line 366
    move-result v3

    .line 367
    if-nez v3, :cond_12

    .line 368
    .line 369
    iget-boolean v3, v1, LE0/k;->f:Z

    .line 370
    .line 371
    if-eqz v3, :cond_14

    .line 372
    .line 373
    :cond_12
    invoke-virtual {v15, v5}, Lh1/g;->g(Ljava/lang/String;)V

    .line 374
    .line 375
    .line 376
    goto :goto_9

    .line 377
    :cond_13
    move-object/from16 v21, v5

    .line 378
    .line 379
    move-object/from16 v22, v10

    .line 380
    .line 381
    :cond_14
    :goto_9
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 382
    .line 383
    .line 384
    move-result-object v3

    .line 385
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    move-result-object v3

    .line 389
    invoke-virtual {v14, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPackageName(Ljava/lang/CharSequence;)V

    .line 390
    .line 391
    .line 392
    invoke-static {v9}, LE0/q;->f(LE0/n;)Z

    .line 393
    .line 394
    .line 395
    move-result v3

    .line 396
    invoke-virtual {v14, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setImportantForAccessibility(Z)V

    .line 397
    .line 398
    .line 399
    const/16 v3, 0x22

    .line 400
    .line 401
    if-lt v8, v3, :cond_15

    .line 402
    .line 403
    invoke-static/range {v21 .. v21}, Lh1/b;->e(Landroid/view/accessibility/AccessibilityManager;)Z

    .line 404
    .line 405
    .line 406
    move-result v3

    .line 407
    :goto_a
    const/4 v5, 0x4

    .line 408
    goto :goto_b

    .line 409
    :cond_15
    const/4 v3, 0x1

    .line 410
    goto :goto_a

    .line 411
    :goto_b
    invoke-static {v5, v9}, LE0/n;->j(ILE0/n;)Ljava/util/List;

    .line 412
    .line 413
    .line 414
    move-result-object v8

    .line 415
    invoke-interface {v8}, Ljava/util/Collection;->size()I

    .line 416
    .line 417
    .line 418
    move-result v5

    .line 419
    move/from16 v21, v3

    .line 420
    .line 421
    const/4 v3, 0x0

    .line 422
    const/4 v10, 0x0

    .line 423
    :goto_c
    if-ge v10, v5, :cond_1d

    .line 424
    .line 425
    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 426
    .line 427
    .line 428
    move-result-object v23

    .line 429
    move/from16 v24, v5

    .line 430
    .line 431
    move-object/from16 v5, v23

    .line 432
    .line 433
    check-cast v5, LE0/n;

    .line 434
    .line 435
    move-object/from16 v23, v8

    .line 436
    .line 437
    invoke-virtual {v4}, Lx0/x;->k()Li/l;

    .line 438
    .line 439
    .line 440
    move-result-object v8

    .line 441
    move/from16 v25, v10

    .line 442
    .line 443
    iget v10, v5, LE0/n;->g:I

    .line 444
    .line 445
    invoke-virtual {v8, v10}, Li/l;->a(I)Z

    .line 446
    .line 447
    .line 448
    move-result v8

    .line 449
    if-eqz v8, :cond_1c

    .line 450
    .line 451
    invoke-virtual {v6}, Lx0/s;->getAndroidViewsHandler$ui()Lx0/W;

    .line 452
    .line 453
    .line 454
    move-result-object v8

    .line 455
    invoke-virtual {v8}, Lx0/W;->getLayoutNodeToHolder()Ljava/util/HashMap;

    .line 456
    .line 457
    .line 458
    move-result-object v8

    .line 459
    iget-object v5, v5, LE0/n;->c:Lw0/E;

    .line 460
    .line 461
    invoke-virtual {v8, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    move-result-object v5

    .line 465
    if-nez v5, :cond_1b

    .line 466
    .line 467
    const/4 v5, -0x1

    .line 468
    if-ne v10, v5, :cond_16

    .line 469
    .line 470
    goto :goto_e

    .line 471
    :cond_16
    invoke-virtual {v4}, Lx0/x;->k()Li/l;

    .line 472
    .line 473
    .line 474
    move-result-object v5

    .line 475
    invoke-virtual {v5, v10}, Li/l;->b(I)Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v5

    .line 479
    check-cast v5, LE0/o;

    .line 480
    .line 481
    if-eqz v5, :cond_18

    .line 482
    .line 483
    iget-object v5, v5, LE0/o;->a:LE0/n;

    .line 484
    .line 485
    if-eqz v5, :cond_18

    .line 486
    .line 487
    invoke-virtual {v5}, LE0/n;->k()LE0/k;

    .line 488
    .line 489
    .line 490
    move-result-object v5

    .line 491
    sget-object v8, LE0/r;->m:LE0/u;

    .line 492
    .line 493
    iget-object v5, v5, LE0/k;->d:Li/E;

    .line 494
    .line 495
    invoke-virtual {v5, v8}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v5

    .line 499
    if-nez v5, :cond_17

    .line 500
    .line 501
    move-object/from16 v5, v16

    .line 502
    .line 503
    :cond_17
    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 504
    .line 505
    invoke-static {v5, v8}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 506
    .line 507
    .line 508
    move-result v5

    .line 509
    goto :goto_d

    .line 510
    :cond_18
    const/4 v5, 0x0

    .line 511
    :goto_d
    if-nez v21, :cond_19

    .line 512
    .line 513
    if-nez v5, :cond_1a

    .line 514
    .line 515
    :cond_19
    invoke-virtual {v14, v6, v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    .line 516
    .line 517
    .line 518
    :cond_1a
    invoke-virtual {v7, v10, v3}, Li/v;->f(II)V

    .line 519
    .line 520
    .line 521
    add-int/lit8 v3, v3, 0x1

    .line 522
    .line 523
    goto :goto_e

    .line 524
    :cond_1b
    new-instance v0, Ljava/lang/ClassCastException;

    .line 525
    .line 526
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 527
    .line 528
    .line 529
    throw v0

    .line 530
    :cond_1c
    :goto_e
    add-int/lit8 v10, v25, 0x1

    .line 531
    .line 532
    move-object/from16 v8, v23

    .line 533
    .line 534
    move/from16 v5, v24

    .line 535
    .line 536
    goto :goto_c

    .line 537
    :cond_1d
    iget v3, v4, Lx0/x;->o:I

    .line 538
    .line 539
    iget-object v5, v15, Lh1/g;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 540
    .line 541
    if-ne v0, v3, :cond_1e

    .line 542
    .line 543
    const/4 v3, 0x1

    .line 544
    invoke-virtual {v5, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V

    .line 545
    .line 546
    .line 547
    sget-object v3, Lh1/f;->d:Lh1/f;

    .line 548
    .line 549
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 550
    .line 551
    .line 552
    goto :goto_f

    .line 553
    :cond_1e
    const/4 v3, 0x0

    .line 554
    invoke-virtual {v5, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V

    .line 555
    .line 556
    .line 557
    sget-object v3, Lh1/f;->c:Lh1/f;

    .line 558
    .line 559
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 560
    .line 561
    .line 562
    :goto_f
    invoke-static {v9}, Lx0/E;->i(LE0/n;)LH0/g;

    .line 563
    .line 564
    .line 565
    move-result-object v3

    .line 566
    if-eqz v3, :cond_41

    .line 567
    .line 568
    invoke-virtual {v6}, Lx0/s;->getFontFamilyResolver()LL0/d;

    .line 569
    .line 570
    .line 571
    invoke-virtual {v6}, Lx0/s;->getDensity()LT0/c;

    .line 572
    .line 573
    .line 574
    move-result-object v26

    .line 575
    iget-object v10, v4, Lx0/x;->J:LI/e0;

    .line 576
    .line 577
    new-instance v8, Landroid/text/SpannableString;

    .line 578
    .line 579
    move-object/from16 v29, v6

    .line 580
    .line 581
    iget-object v6, v3, LH0/g;->e:Ljava/lang/String;

    .line 582
    .line 583
    move-object/from16 v30, v11

    .line 584
    .line 585
    iget-object v11, v3, LH0/g;->d:Ljava/util/List;

    .line 586
    .line 587
    invoke-direct {v8, v6}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 588
    .line 589
    .line 590
    iget-object v3, v3, LH0/g;->f:Ljava/util/ArrayList;

    .line 591
    .line 592
    move-object/from16 v31, v6

    .line 593
    .line 594
    if-eqz v3, :cond_2f

    .line 595
    .line 596
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 597
    .line 598
    .line 599
    move-result v6

    .line 600
    move-object/from16 v32, v4

    .line 601
    .line 602
    const/4 v4, 0x0

    .line 603
    :goto_10
    if-ge v4, v6, :cond_2e

    .line 604
    .line 605
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 606
    .line 607
    .line 608
    move-result-object v23

    .line 609
    move-object/from16 v33, v3

    .line 610
    .line 611
    move-object/from16 v3, v23

    .line 612
    .line 613
    check-cast v3, LH0/e;

    .line 614
    .line 615
    move/from16 v34, v4

    .line 616
    .line 617
    iget-object v4, v3, LH0/e;->a:Ljava/lang/Object;

    .line 618
    .line 619
    check-cast v4, LH0/G;

    .line 620
    .line 621
    move/from16 v35, v6

    .line 622
    .line 623
    iget v6, v3, LH0/e;->b:I

    .line 624
    .line 625
    iget v3, v3, LH0/e;->c:I

    .line 626
    .line 627
    move-object/from16 v36, v7

    .line 628
    .line 629
    iget-object v7, v4, LH0/G;->a:LS0/o;

    .line 630
    .line 631
    move-object/from16 v37, v1

    .line 632
    .line 633
    invoke-interface {v7}, LS0/o;->a()J

    .line 634
    .line 635
    .line 636
    move-result-wide v0

    .line 637
    move-object/from16 v38, v13

    .line 638
    .line 639
    move-object v7, v14

    .line 640
    iget-wide v13, v4, LH0/G;->b:J

    .line 641
    .line 642
    move-object/from16 v39, v7

    .line 643
    .line 644
    iget-object v7, v4, LH0/G;->c:LL0/k;

    .line 645
    .line 646
    move-object/from16 v40, v7

    .line 647
    .line 648
    iget-object v7, v4, LH0/G;->d:LL0/i;

    .line 649
    .line 650
    move-wide/from16 v24, v13

    .line 651
    .line 652
    iget-object v13, v4, LH0/G;->j:LS0/p;

    .line 653
    .line 654
    iget-object v14, v4, LH0/G;->k:LO0/b;

    .line 655
    .line 656
    move-object/from16 v41, v9

    .line 657
    .line 658
    move-object/from16 v42, v10

    .line 659
    .line 660
    iget-wide v9, v4, LH0/G;->l:J

    .line 661
    .line 662
    move-wide/from16 v43, v9

    .line 663
    .line 664
    iget-object v9, v4, LH0/G;->m:LS0/l;

    .line 665
    .line 666
    iget-object v4, v4, LH0/G;->a:LS0/o;

    .line 667
    .line 668
    move-object/from16 v23, v4

    .line 669
    .line 670
    move-object v10, v5

    .line 671
    invoke-interface/range {v23 .. v23}, LS0/o;->a()J

    .line 672
    .line 673
    .line 674
    move-result-wide v4

    .line 675
    invoke-static {v0, v1, v4, v5}, Ld0/w;->c(JJ)Z

    .line 676
    .line 677
    .line 678
    move-result v4

    .line 679
    const-wide/16 v45, 0x10

    .line 680
    .line 681
    if-eqz v4, :cond_1f

    .line 682
    .line 683
    move-object/from16 v4, v23

    .line 684
    .line 685
    goto :goto_11

    .line 686
    :cond_1f
    cmp-long v4, v0, v45

    .line 687
    .line 688
    if-eqz v4, :cond_20

    .line 689
    .line 690
    new-instance v4, LS0/c;

    .line 691
    .line 692
    invoke-direct {v4, v0, v1}, LS0/c;-><init>(J)V

    .line 693
    .line 694
    .line 695
    goto :goto_11

    .line 696
    :cond_20
    sget-object v0, LS0/n;->a:LS0/n;

    .line 697
    .line 698
    move-object v4, v0

    .line 699
    :goto_11
    invoke-interface {v4}, LS0/o;->a()J

    .line 700
    .line 701
    .line 702
    move-result-wide v0

    .line 703
    invoke-static {v8, v0, v1, v6, v3}, LX1/a;->f0(Landroid/text/Spannable;JII)V

    .line 704
    .line 705
    .line 706
    move/from16 v28, v3

    .line 707
    .line 708
    move/from16 v27, v6

    .line 709
    .line 710
    move-object/from16 v23, v8

    .line 711
    .line 712
    invoke-static/range {v23 .. v28}, LX1/a;->g0(Landroid/text/Spannable;JLT0/c;II)V

    .line 713
    .line 714
    .line 715
    move-object/from16 v0, v23

    .line 716
    .line 717
    move/from16 v1, v27

    .line 718
    .line 719
    if-nez v40, :cond_22

    .line 720
    .line 721
    if-eqz v7, :cond_21

    .line 722
    .line 723
    goto :goto_12

    .line 724
    :cond_21
    const/16 v4, 0x21

    .line 725
    .line 726
    goto :goto_19

    .line 727
    :cond_22
    :goto_12
    if-nez v40, :cond_23

    .line 728
    .line 729
    sget-object v4, LL0/k;->f:LL0/k;

    .line 730
    .line 731
    goto :goto_13

    .line 732
    :cond_23
    move-object/from16 v4, v40

    .line 733
    .line 734
    :goto_13
    if-eqz v7, :cond_24

    .line 735
    .line 736
    iget v5, v7, LL0/i;->a:I

    .line 737
    .line 738
    goto :goto_14

    .line 739
    :cond_24
    const/4 v5, 0x0

    .line 740
    :goto_14
    new-instance v6, Landroid/text/style/StyleSpan;

    .line 741
    .line 742
    sget-object v7, LL0/k;->e:LL0/k;

    .line 743
    .line 744
    iget v4, v4, LL0/k;->d:I

    .line 745
    .line 746
    iget v7, v7, LL0/k;->d:I

    .line 747
    .line 748
    invoke-static {v4, v7}, LV1/i;->g(II)I

    .line 749
    .line 750
    .line 751
    move-result v4

    .line 752
    if-ltz v4, :cond_25

    .line 753
    .line 754
    const/4 v4, 0x1

    .line 755
    :goto_15
    const/4 v7, 0x1

    .line 756
    goto :goto_16

    .line 757
    :cond_25
    const/4 v4, 0x0

    .line 758
    goto :goto_15

    .line 759
    :goto_16
    if-ne v5, v7, :cond_26

    .line 760
    .line 761
    const/4 v5, 0x1

    .line 762
    goto :goto_17

    .line 763
    :cond_26
    const/4 v5, 0x0

    .line 764
    :goto_17
    if-eqz v5, :cond_27

    .line 765
    .line 766
    if-eqz v4, :cond_27

    .line 767
    .line 768
    const/4 v4, 0x3

    .line 769
    goto :goto_18

    .line 770
    :cond_27
    if-eqz v4, :cond_28

    .line 771
    .line 772
    const/4 v4, 0x1

    .line 773
    goto :goto_18

    .line 774
    :cond_28
    if-eqz v5, :cond_29

    .line 775
    .line 776
    const/4 v4, 0x2

    .line 777
    goto :goto_18

    .line 778
    :cond_29
    const/4 v4, 0x0

    .line 779
    :goto_18
    invoke-direct {v6, v4}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 780
    .line 781
    .line 782
    const/16 v4, 0x21

    .line 783
    .line 784
    invoke-virtual {v0, v6, v1, v3, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 785
    .line 786
    .line 787
    :goto_19
    if-eqz v9, :cond_2b

    .line 788
    .line 789
    iget v5, v9, LS0/l;->a:I

    .line 790
    .line 791
    or-int/lit8 v6, v5, 0x1

    .line 792
    .line 793
    if-ne v6, v5, :cond_2a

    .line 794
    .line 795
    new-instance v6, Landroid/text/style/UnderlineSpan;

    .line 796
    .line 797
    invoke-direct {v6}, Landroid/text/style/UnderlineSpan;-><init>()V

    .line 798
    .line 799
    .line 800
    invoke-virtual {v0, v6, v1, v3, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 801
    .line 802
    .line 803
    :cond_2a
    or-int/lit8 v6, v5, 0x2

    .line 804
    .line 805
    if-ne v6, v5, :cond_2b

    .line 806
    .line 807
    new-instance v5, Landroid/text/style/StrikethroughSpan;

    .line 808
    .line 809
    invoke-direct {v5}, Landroid/text/style/StrikethroughSpan;-><init>()V

    .line 810
    .line 811
    .line 812
    invoke-virtual {v0, v5, v1, v3, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 813
    .line 814
    .line 815
    :cond_2b
    if-eqz v13, :cond_2c

    .line 816
    .line 817
    new-instance v5, Landroid/text/style/ScaleXSpan;

    .line 818
    .line 819
    iget v6, v13, LS0/p;->a:F

    .line 820
    .line 821
    invoke-direct {v5, v6}, Landroid/text/style/ScaleXSpan;-><init>(F)V

    .line 822
    .line 823
    .line 824
    invoke-virtual {v0, v5, v1, v3, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 825
    .line 826
    .line 827
    :cond_2c
    invoke-static {v0, v14, v1, v3}, LX1/a;->h0(Landroid/text/Spannable;LO0/b;II)V

    .line 828
    .line 829
    .line 830
    cmp-long v5, v43, v45

    .line 831
    .line 832
    if-eqz v5, :cond_2d

    .line 833
    .line 834
    new-instance v5, Landroid/text/style/BackgroundColorSpan;

    .line 835
    .line 836
    invoke-static/range {v43 .. v44}, Ld0/D;->w(J)I

    .line 837
    .line 838
    .line 839
    move-result v6

    .line 840
    invoke-direct {v5, v6}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    .line 841
    .line 842
    .line 843
    invoke-virtual {v0, v5, v1, v3, v4}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 844
    .line 845
    .line 846
    :cond_2d
    add-int/lit8 v4, v34, 0x1

    .line 847
    .line 848
    move-object v8, v0

    .line 849
    move-object v5, v10

    .line 850
    move-object/from16 v3, v33

    .line 851
    .line 852
    move/from16 v6, v35

    .line 853
    .line 854
    move-object/from16 v7, v36

    .line 855
    .line 856
    move-object/from16 v1, v37

    .line 857
    .line 858
    move-object/from16 v13, v38

    .line 859
    .line 860
    move-object/from16 v14, v39

    .line 861
    .line 862
    move-object/from16 v9, v41

    .line 863
    .line 864
    move-object/from16 v10, v42

    .line 865
    .line 866
    move/from16 v0, p1

    .line 867
    .line 868
    goto/16 :goto_10

    .line 869
    .line 870
    :cond_2e
    :goto_1a
    move-object/from16 v37, v1

    .line 871
    .line 872
    move-object/from16 v36, v7

    .line 873
    .line 874
    move-object v0, v8

    .line 875
    move-object/from16 v41, v9

    .line 876
    .line 877
    move-object/from16 v42, v10

    .line 878
    .line 879
    move-object/from16 v38, v13

    .line 880
    .line 881
    move-object/from16 v39, v14

    .line 882
    .line 883
    move-object v10, v5

    .line 884
    goto :goto_1b

    .line 885
    :cond_2f
    move-object/from16 v32, v4

    .line 886
    .line 887
    goto :goto_1a

    .line 888
    :goto_1b
    invoke-virtual/range {v31 .. v31}, Ljava/lang/String;->length()I

    .line 889
    .line 890
    .line 891
    move-result v1

    .line 892
    sget-object v3, LK1/t;->d:LK1/t;

    .line 893
    .line 894
    if-eqz v11, :cond_31

    .line 895
    .line 896
    new-instance v4, Ljava/util/ArrayList;

    .line 897
    .line 898
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 899
    .line 900
    .line 901
    move-result v5

    .line 902
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 903
    .line 904
    .line 905
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 906
    .line 907
    .line 908
    move-result v5

    .line 909
    const/4 v6, 0x0

    .line 910
    :goto_1c
    if-ge v6, v5, :cond_32

    .line 911
    .line 912
    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 913
    .line 914
    .line 915
    move-result-object v7

    .line 916
    move-object v8, v7

    .line 917
    check-cast v8, LH0/e;

    .line 918
    .line 919
    iget-object v9, v8, LH0/e;->a:Ljava/lang/Object;

    .line 920
    .line 921
    instance-of v9, v9, LH0/Q;

    .line 922
    .line 923
    if-eqz v9, :cond_30

    .line 924
    .line 925
    iget v9, v8, LH0/e;->b:I

    .line 926
    .line 927
    iget v8, v8, LH0/e;->c:I

    .line 928
    .line 929
    const/4 v13, 0x0

    .line 930
    invoke-static {v13, v1, v9, v8}, LH0/h;->b(IIII)Z

    .line 931
    .line 932
    .line 933
    move-result v8

    .line 934
    if-eqz v8, :cond_30

    .line 935
    .line 936
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 937
    .line 938
    .line 939
    :cond_30
    add-int/lit8 v6, v6, 0x1

    .line 940
    .line 941
    goto :goto_1c

    .line 942
    :cond_31
    move-object v4, v3

    .line 943
    :cond_32
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 944
    .line 945
    .line 946
    move-result v1

    .line 947
    const/4 v5, 0x0

    .line 948
    :goto_1d
    if-ge v5, v1, :cond_34

    .line 949
    .line 950
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 951
    .line 952
    .line 953
    move-result-object v6

    .line 954
    check-cast v6, LH0/e;

    .line 955
    .line 956
    iget-object v7, v6, LH0/e;->a:Ljava/lang/Object;

    .line 957
    .line 958
    check-cast v7, LH0/Q;

    .line 959
    .line 960
    iget v8, v6, LH0/e;->b:I

    .line 961
    .line 962
    iget v6, v6, LH0/e;->c:I

    .line 963
    .line 964
    instance-of v9, v7, LH0/Q;

    .line 965
    .line 966
    if-eqz v9, :cond_33

    .line 967
    .line 968
    new-instance v9, Landroid/text/style/TtsSpan$VerbatimBuilder;

    .line 969
    .line 970
    iget-object v7, v7, LH0/Q;->a:Ljava/lang/String;

    .line 971
    .line 972
    invoke-direct {v9, v7}, Landroid/text/style/TtsSpan$VerbatimBuilder;-><init>(Ljava/lang/String;)V

    .line 973
    .line 974
    .line 975
    invoke-virtual {v9}, Landroid/text/style/TtsSpan$Builder;->build()Landroid/text/style/TtsSpan;

    .line 976
    .line 977
    .line 978
    move-result-object v7

    .line 979
    const/16 v9, 0x21

    .line 980
    .line 981
    invoke-virtual {v0, v7, v8, v6, v9}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 982
    .line 983
    .line 984
    add-int/lit8 v5, v5, 0x1

    .line 985
    .line 986
    goto :goto_1d

    .line 987
    :cond_33
    new-instance v0, LC0/e;

    .line 988
    .line 989
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 990
    .line 991
    .line 992
    throw v0

    .line 993
    :cond_34
    invoke-virtual/range {v31 .. v31}, Ljava/lang/String;->length()I

    .line 994
    .line 995
    .line 996
    move-result v1

    .line 997
    if-eqz v11, :cond_36

    .line 998
    .line 999
    new-instance v4, Ljava/util/ArrayList;

    .line 1000
    .line 1001
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 1002
    .line 1003
    .line 1004
    move-result v5

    .line 1005
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 1006
    .line 1007
    .line 1008
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 1009
    .line 1010
    .line 1011
    move-result v5

    .line 1012
    const/4 v6, 0x0

    .line 1013
    :goto_1e
    if-ge v6, v5, :cond_37

    .line 1014
    .line 1015
    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v7

    .line 1019
    move-object v8, v7

    .line 1020
    check-cast v8, LH0/e;

    .line 1021
    .line 1022
    iget-object v9, v8, LH0/e;->a:Ljava/lang/Object;

    .line 1023
    .line 1024
    instance-of v9, v9, LH0/P;

    .line 1025
    .line 1026
    if-eqz v9, :cond_35

    .line 1027
    .line 1028
    iget v9, v8, LH0/e;->b:I

    .line 1029
    .line 1030
    iget v8, v8, LH0/e;->c:I

    .line 1031
    .line 1032
    const/4 v13, 0x0

    .line 1033
    invoke-static {v13, v1, v9, v8}, LH0/h;->b(IIII)Z

    .line 1034
    .line 1035
    .line 1036
    move-result v8

    .line 1037
    if-eqz v8, :cond_35

    .line 1038
    .line 1039
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1040
    .line 1041
    .line 1042
    :cond_35
    add-int/lit8 v6, v6, 0x1

    .line 1043
    .line 1044
    goto :goto_1e

    .line 1045
    :cond_36
    move-object v4, v3

    .line 1046
    :cond_37
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 1047
    .line 1048
    .line 1049
    move-result v1

    .line 1050
    const/4 v5, 0x0

    .line 1051
    :goto_1f
    if-ge v5, v1, :cond_39

    .line 1052
    .line 1053
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v6

    .line 1057
    check-cast v6, LH0/e;

    .line 1058
    .line 1059
    iget-object v7, v6, LH0/e;->a:Ljava/lang/Object;

    .line 1060
    .line 1061
    check-cast v7, LH0/P;

    .line 1062
    .line 1063
    iget v8, v6, LH0/e;->b:I

    .line 1064
    .line 1065
    iget v6, v6, LH0/e;->c:I

    .line 1066
    .line 1067
    move-object/from16 v9, v42

    .line 1068
    .line 1069
    iget-object v13, v9, LI/e0;->d:Ljava/lang/Object;

    .line 1070
    .line 1071
    check-cast v13, Ljava/util/WeakHashMap;

    .line 1072
    .line 1073
    invoke-virtual {v13, v7}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1074
    .line 1075
    .line 1076
    move-result-object v14

    .line 1077
    if-nez v14, :cond_38

    .line 1078
    .line 1079
    new-instance v14, Landroid/text/style/URLSpan;

    .line 1080
    .line 1081
    move/from16 v23, v1

    .line 1082
    .line 1083
    iget-object v1, v7, LH0/P;->a:Ljava/lang/String;

    .line 1084
    .line 1085
    invoke-direct {v14, v1}, Landroid/text/style/URLSpan;-><init>(Ljava/lang/String;)V

    .line 1086
    .line 1087
    .line 1088
    invoke-virtual {v13, v7, v14}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1089
    .line 1090
    .line 1091
    goto :goto_20

    .line 1092
    :cond_38
    move/from16 v23, v1

    .line 1093
    .line 1094
    :goto_20
    check-cast v14, Landroid/text/style/URLSpan;

    .line 1095
    .line 1096
    const/16 v1, 0x21

    .line 1097
    .line 1098
    invoke-virtual {v0, v14, v8, v6, v1}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1099
    .line 1100
    .line 1101
    add-int/lit8 v5, v5, 0x1

    .line 1102
    .line 1103
    move-object/from16 v42, v9

    .line 1104
    .line 1105
    move/from16 v1, v23

    .line 1106
    .line 1107
    goto :goto_1f

    .line 1108
    :cond_39
    move-object/from16 v9, v42

    .line 1109
    .line 1110
    invoke-virtual/range {v31 .. v31}, Ljava/lang/String;->length()I

    .line 1111
    .line 1112
    .line 1113
    move-result v1

    .line 1114
    if-eqz v11, :cond_3b

    .line 1115
    .line 1116
    new-instance v3, Ljava/util/ArrayList;

    .line 1117
    .line 1118
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 1119
    .line 1120
    .line 1121
    move-result v4

    .line 1122
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 1123
    .line 1124
    .line 1125
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 1126
    .line 1127
    .line 1128
    move-result v4

    .line 1129
    const/4 v5, 0x0

    .line 1130
    :goto_21
    if-ge v5, v4, :cond_3b

    .line 1131
    .line 1132
    invoke-interface {v11, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1133
    .line 1134
    .line 1135
    move-result-object v6

    .line 1136
    move-object v7, v6

    .line 1137
    check-cast v7, LH0/e;

    .line 1138
    .line 1139
    iget-object v8, v7, LH0/e;->a:Ljava/lang/Object;

    .line 1140
    .line 1141
    instance-of v8, v8, LH0/m;

    .line 1142
    .line 1143
    if-eqz v8, :cond_3a

    .line 1144
    .line 1145
    iget v8, v7, LH0/e;->b:I

    .line 1146
    .line 1147
    iget v7, v7, LH0/e;->c:I

    .line 1148
    .line 1149
    const/4 v13, 0x0

    .line 1150
    invoke-static {v13, v1, v8, v7}, LH0/h;->b(IIII)Z

    .line 1151
    .line 1152
    .line 1153
    move-result v7

    .line 1154
    if-eqz v7, :cond_3a

    .line 1155
    .line 1156
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1157
    .line 1158
    .line 1159
    :cond_3a
    add-int/lit8 v5, v5, 0x1

    .line 1160
    .line 1161
    goto :goto_21

    .line 1162
    :cond_3b
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 1163
    .line 1164
    .line 1165
    move-result v1

    .line 1166
    const/4 v4, 0x0

    .line 1167
    :goto_22
    if-ge v4, v1, :cond_40

    .line 1168
    .line 1169
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1170
    .line 1171
    .line 1172
    move-result-object v5

    .line 1173
    check-cast v5, LH0/e;

    .line 1174
    .line 1175
    iget v6, v5, LH0/e;->b:I

    .line 1176
    .line 1177
    iget-object v7, v5, LH0/e;->a:Ljava/lang/Object;

    .line 1178
    .line 1179
    iget v8, v5, LH0/e;->c:I

    .line 1180
    .line 1181
    if-eq v6, v8, :cond_3f

    .line 1182
    .line 1183
    move-object v11, v7

    .line 1184
    check-cast v11, LH0/m;

    .line 1185
    .line 1186
    instance-of v13, v11, LH0/l;

    .line 1187
    .line 1188
    if-eqz v13, :cond_3d

    .line 1189
    .line 1190
    check-cast v11, LH0/l;

    .line 1191
    .line 1192
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1193
    .line 1194
    .line 1195
    new-instance v5, LH0/e;

    .line 1196
    .line 1197
    const-string v11, "null cannot be cast to non-null type androidx.compose.ui.text.LinkAnnotation.Url"

    .line 1198
    .line 1199
    invoke-static {v7, v11}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1200
    .line 1201
    .line 1202
    check-cast v7, LH0/l;

    .line 1203
    .line 1204
    invoke-direct {v5, v6, v8, v7}, LH0/e;-><init>(IILjava/lang/Object;)V

    .line 1205
    .line 1206
    .line 1207
    iget-object v11, v9, LI/e0;->e:Ljava/lang/Object;

    .line 1208
    .line 1209
    check-cast v11, Ljava/util/WeakHashMap;

    .line 1210
    .line 1211
    invoke-virtual {v11, v5}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1212
    .line 1213
    .line 1214
    move-result-object v13

    .line 1215
    if-nez v13, :cond_3c

    .line 1216
    .line 1217
    new-instance v13, Landroid/text/style/URLSpan;

    .line 1218
    .line 1219
    iget-object v7, v7, LH0/l;->a:Ljava/lang/String;

    .line 1220
    .line 1221
    invoke-direct {v13, v7}, Landroid/text/style/URLSpan;-><init>(Ljava/lang/String;)V

    .line 1222
    .line 1223
    .line 1224
    invoke-virtual {v11, v5, v13}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1225
    .line 1226
    .line 1227
    :cond_3c
    check-cast v13, Landroid/text/style/URLSpan;

    .line 1228
    .line 1229
    const/16 v5, 0x21

    .line 1230
    .line 1231
    invoke-virtual {v0, v13, v6, v8, v5}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1232
    .line 1233
    .line 1234
    goto :goto_23

    .line 1235
    :cond_3d
    iget-object v7, v9, LI/e0;->f:Ljava/lang/Object;

    .line 1236
    .line 1237
    check-cast v7, Ljava/util/WeakHashMap;

    .line 1238
    .line 1239
    invoke-virtual {v7, v5}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1240
    .line 1241
    .line 1242
    move-result-object v13

    .line 1243
    if-nez v13, :cond_3e

    .line 1244
    .line 1245
    new-instance v13, LP0/g;

    .line 1246
    .line 1247
    invoke-direct {v13, v11}, LP0/g;-><init>(LH0/m;)V

    .line 1248
    .line 1249
    .line 1250
    invoke-virtual {v7, v5, v13}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1251
    .line 1252
    .line 1253
    :cond_3e
    check-cast v13, Landroid/text/style/ClickableSpan;

    .line 1254
    .line 1255
    const/16 v5, 0x21

    .line 1256
    .line 1257
    invoke-virtual {v0, v13, v6, v8, v5}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1258
    .line 1259
    .line 1260
    goto :goto_23

    .line 1261
    :cond_3f
    const/16 v5, 0x21

    .line 1262
    .line 1263
    :goto_23
    add-int/lit8 v4, v4, 0x1

    .line 1264
    .line 1265
    goto :goto_22

    .line 1266
    :cond_40
    invoke-static {v0}, Lx0/x;->H(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1267
    .line 1268
    .line 1269
    move-result-object v0

    .line 1270
    check-cast v0, Landroid/text/SpannableString;

    .line 1271
    .line 1272
    goto :goto_24

    .line 1273
    :cond_41
    move-object/from16 v37, v1

    .line 1274
    .line 1275
    move-object/from16 v32, v4

    .line 1276
    .line 1277
    move-object/from16 v29, v6

    .line 1278
    .line 1279
    move-object/from16 v36, v7

    .line 1280
    .line 1281
    move-object/from16 v41, v9

    .line 1282
    .line 1283
    move-object/from16 v30, v11

    .line 1284
    .line 1285
    move-object/from16 v38, v13

    .line 1286
    .line 1287
    move-object/from16 v39, v14

    .line 1288
    .line 1289
    move-object v10, v5

    .line 1290
    move-object/from16 v0, v16

    .line 1291
    .line 1292
    :goto_24
    invoke-virtual {v10, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    .line 1293
    .line 1294
    .line 1295
    sget-object v0, LE0/r;->J:LE0/u;

    .line 1296
    .line 1297
    invoke-virtual {v12, v0}, Li/E;->c(Ljava/lang/Object;)Z

    .line 1298
    .line 1299
    .line 1300
    move-result v1

    .line 1301
    if-eqz v1, :cond_43

    .line 1302
    .line 1303
    move-object/from16 v7, v39

    .line 1304
    .line 1305
    const/4 v3, 0x1

    .line 1306
    invoke-virtual {v7, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentInvalid(Z)V

    .line 1307
    .line 1308
    .line 1309
    invoke-virtual {v12, v0}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1310
    .line 1311
    .line 1312
    move-result-object v0

    .line 1313
    if-nez v0, :cond_42

    .line 1314
    .line 1315
    move-object/from16 v0, v16

    .line 1316
    .line 1317
    :cond_42
    check-cast v0, Ljava/lang/CharSequence;

    .line 1318
    .line 1319
    invoke-virtual {v7, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setError(Ljava/lang/CharSequence;)V

    .line 1320
    .line 1321
    .line 1322
    :goto_25
    move-object/from16 v1, v38

    .line 1323
    .line 1324
    move-object/from16 v0, v41

    .line 1325
    .line 1326
    goto :goto_26

    .line 1327
    :cond_43
    move-object/from16 v7, v39

    .line 1328
    .line 1329
    goto :goto_25

    .line 1330
    :goto_26
    invoke-static {v0, v1}, Lx0/E;->h(LE0/n;Landroid/content/res/Resources;)Ljava/lang/String;

    .line 1331
    .line 1332
    .line 1333
    move-result-object v3

    .line 1334
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1335
    .line 1336
    const/16 v5, 0x1e

    .line 1337
    .line 1338
    if-lt v4, v5, :cond_44

    .line 1339
    .line 1340
    invoke-static {v10, v3}, LA0/g;->e(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 1341
    .line 1342
    .line 1343
    goto :goto_27

    .line 1344
    :cond_44
    invoke-virtual {v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 1345
    .line 1346
    .line 1347
    move-result-object v4

    .line 1348
    const-string v5, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"

    .line 1349
    .line 1350
    invoke-virtual {v4, v5, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 1351
    .line 1352
    .line 1353
    :goto_27
    invoke-static {v0}, Lx0/E;->g(LE0/n;)Z

    .line 1354
    .line 1355
    .line 1356
    move-result v3

    .line 1357
    invoke-virtual {v7, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 1358
    .line 1359
    .line 1360
    sget-object v3, LE0/r;->H:LE0/u;

    .line 1361
    .line 1362
    invoke-virtual {v12, v3}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1363
    .line 1364
    .line 1365
    move-result-object v3

    .line 1366
    if-nez v3, :cond_45

    .line 1367
    .line 1368
    move-object/from16 v3, v16

    .line 1369
    .line 1370
    :cond_45
    check-cast v3, LG0/a;

    .line 1371
    .line 1372
    if-eqz v3, :cond_47

    .line 1373
    .line 1374
    sget-object v4, LG0/a;->d:LG0/a;

    .line 1375
    .line 1376
    if-ne v3, v4, :cond_46

    .line 1377
    .line 1378
    const/4 v4, 0x1

    .line 1379
    invoke-virtual {v10, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 1380
    .line 1381
    .line 1382
    goto :goto_28

    .line 1383
    :cond_46
    sget-object v4, LG0/a;->e:LG0/a;

    .line 1384
    .line 1385
    if-ne v3, v4, :cond_47

    .line 1386
    .line 1387
    const/4 v13, 0x0

    .line 1388
    invoke-virtual {v10, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 1389
    .line 1390
    .line 1391
    :cond_47
    :goto_28
    sget-object v3, LE0/r;->G:LE0/u;

    .line 1392
    .line 1393
    invoke-virtual {v12, v3}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1394
    .line 1395
    .line 1396
    move-result-object v3

    .line 1397
    if-nez v3, :cond_48

    .line 1398
    .line 1399
    move-object/from16 v3, v16

    .line 1400
    .line 1401
    :cond_48
    check-cast v3, Ljava/lang/Boolean;

    .line 1402
    .line 1403
    if-eqz v3, :cond_4b

    .line 1404
    .line 1405
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1406
    .line 1407
    .line 1408
    move-result v3

    .line 1409
    if-nez v2, :cond_49

    .line 1410
    .line 1411
    const/4 v5, 0x4

    .line 1412
    goto :goto_29

    .line 1413
    :cond_49
    iget v4, v2, LE0/g;->a:I

    .line 1414
    .line 1415
    const/4 v5, 0x4

    .line 1416
    if-ne v4, v5, :cond_4a

    .line 1417
    .line 1418
    invoke-virtual {v7, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSelected(Z)V

    .line 1419
    .line 1420
    .line 1421
    goto :goto_2a

    .line 1422
    :cond_4a
    :goto_29
    invoke-virtual {v10, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 1423
    .line 1424
    .line 1425
    :goto_2a
    move-object/from16 v3, v37

    .line 1426
    .line 1427
    goto :goto_2b

    .line 1428
    :cond_4b
    const/4 v5, 0x4

    .line 1429
    goto :goto_2a

    .line 1430
    :goto_2b
    iget-boolean v4, v3, LE0/k;->f:Z

    .line 1431
    .line 1432
    if-eqz v4, :cond_4c

    .line 1433
    .line 1434
    invoke-static {v5, v0}, LE0/n;->j(ILE0/n;)Ljava/util/List;

    .line 1435
    .line 1436
    .line 1437
    move-result-object v4

    .line 1438
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 1439
    .line 1440
    .line 1441
    move-result v4

    .line 1442
    if-eqz v4, :cond_4f

    .line 1443
    .line 1444
    :cond_4c
    sget-object v4, LE0/r;->a:LE0/u;

    .line 1445
    .line 1446
    invoke-virtual {v12, v4}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1447
    .line 1448
    .line 1449
    move-result-object v4

    .line 1450
    if-nez v4, :cond_4d

    .line 1451
    .line 1452
    move-object/from16 v4, v16

    .line 1453
    .line 1454
    :cond_4d
    check-cast v4, Ljava/util/List;

    .line 1455
    .line 1456
    if-eqz v4, :cond_4e

    .line 1457
    .line 1458
    invoke-static {v4}, LK1/m;->u0(Ljava/util/List;)Ljava/lang/Object;

    .line 1459
    .line 1460
    .line 1461
    move-result-object v4

    .line 1462
    check-cast v4, Ljava/lang/String;

    .line 1463
    .line 1464
    goto :goto_2c

    .line 1465
    :cond_4e
    move-object/from16 v4, v16

    .line 1466
    .line 1467
    :goto_2c
    invoke-virtual {v7, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 1468
    .line 1469
    .line 1470
    :cond_4f
    sget-object v4, LE0/r;->x:LE0/u;

    .line 1471
    .line 1472
    invoke-virtual {v12, v4}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1473
    .line 1474
    .line 1475
    move-result-object v4

    .line 1476
    if-nez v4, :cond_50

    .line 1477
    .line 1478
    move-object/from16 v4, v16

    .line 1479
    .line 1480
    :cond_50
    check-cast v4, Ljava/lang/String;

    .line 1481
    .line 1482
    if-eqz v4, :cond_53

    .line 1483
    .line 1484
    move-object v5, v0

    .line 1485
    :goto_2d
    if-eqz v5, :cond_52

    .line 1486
    .line 1487
    iget-object v6, v5, LE0/n;->d:LE0/k;

    .line 1488
    .line 1489
    sget-object v8, LE0/s;->a:LE0/u;

    .line 1490
    .line 1491
    iget-object v9, v6, LE0/k;->d:Li/E;

    .line 1492
    .line 1493
    invoke-virtual {v9, v8}, Li/E;->c(Ljava/lang/Object;)Z

    .line 1494
    .line 1495
    .line 1496
    move-result v9

    .line 1497
    if-eqz v9, :cond_51

    .line 1498
    .line 1499
    invoke-virtual {v6, v8}, LE0/k;->c(LE0/u;)Ljava/lang/Object;

    .line 1500
    .line 1501
    .line 1502
    move-result-object v5

    .line 1503
    check-cast v5, Ljava/lang/Boolean;

    .line 1504
    .line 1505
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1506
    .line 1507
    .line 1508
    move-result v5

    .line 1509
    goto :goto_2e

    .line 1510
    :cond_51
    invoke-virtual {v5}, LE0/n;->l()LE0/n;

    .line 1511
    .line 1512
    .line 1513
    move-result-object v5

    .line 1514
    goto :goto_2d

    .line 1515
    :cond_52
    const/4 v5, 0x0

    .line 1516
    :goto_2e
    if-eqz v5, :cond_53

    .line 1517
    .line 1518
    invoke-virtual {v7, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->setViewIdResourceName(Ljava/lang/String;)V

    .line 1519
    .line 1520
    .line 1521
    :cond_53
    sget-object v4, LE0/r;->h:LE0/u;

    .line 1522
    .line 1523
    invoke-static {v3, v4}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1524
    .line 1525
    .line 1526
    move-result-object v4

    .line 1527
    check-cast v4, LJ1/m;

    .line 1528
    .line 1529
    const/16 v5, 0x1c

    .line 1530
    .line 1531
    if-eqz v4, :cond_55

    .line 1532
    .line 1533
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1534
    .line 1535
    if-lt v4, v5, :cond_54

    .line 1536
    .line 1537
    const/4 v4, 0x1

    .line 1538
    invoke-static {v10, v4}, Lh1/c;->e(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 1539
    .line 1540
    .line 1541
    goto :goto_2f

    .line 1542
    :cond_54
    const/4 v4, 0x1

    .line 1543
    const/4 v6, 0x2

    .line 1544
    invoke-virtual {v15, v6, v4}, Lh1/g;->f(IZ)V

    .line 1545
    .line 1546
    .line 1547
    :cond_55
    :goto_2f
    move/from16 v4, p1

    .line 1548
    .line 1549
    const/4 v6, -0x1

    .line 1550
    if-eq v4, v6, :cond_57

    .line 1551
    .line 1552
    iget v8, v0, LE0/n;->g:I

    .line 1553
    .line 1554
    move-object/from16 v9, v36

    .line 1555
    .line 1556
    invoke-virtual {v9, v8}, Li/v;->d(I)I

    .line 1557
    .line 1558
    .line 1559
    move-result v8

    .line 1560
    if-eq v8, v6, :cond_56

    .line 1561
    .line 1562
    invoke-virtual {v7, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setDrawingOrder(I)V

    .line 1563
    .line 1564
    .line 1565
    goto :goto_30

    .line 1566
    :cond_56
    const-string v6, "AccessibilityDelegate"

    .line 1567
    .line 1568
    const-string v8, "Drawing order is not available, was AccessibilityNodeInfo requested for a child node before its parent?"

    .line 1569
    .line 1570
    invoke-static {v6, v8}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1571
    .line 1572
    .line 1573
    :cond_57
    :goto_30
    sget-object v6, LE0/r;->I:LE0/u;

    .line 1574
    .line 1575
    invoke-virtual {v12, v6}, Li/E;->c(Ljava/lang/Object;)Z

    .line 1576
    .line 1577
    .line 1578
    move-result v6

    .line 1579
    invoke-virtual {v7, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPassword(Z)V

    .line 1580
    .line 1581
    .line 1582
    sget-object v6, LE0/r;->K:LE0/u;

    .line 1583
    .line 1584
    invoke-virtual {v12, v6}, Li/E;->c(Ljava/lang/Object;)Z

    .line 1585
    .line 1586
    .line 1587
    move-result v6

    .line 1588
    invoke-virtual {v7, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setEditable(Z)V

    .line 1589
    .line 1590
    .line 1591
    sget-object v6, LE0/r;->L:LE0/u;

    .line 1592
    .line 1593
    invoke-static {v3, v6}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1594
    .line 1595
    .line 1596
    move-result-object v6

    .line 1597
    check-cast v6, Ljava/lang/Integer;

    .line 1598
    .line 1599
    if-eqz v6, :cond_58

    .line 1600
    .line 1601
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1602
    .line 1603
    .line 1604
    move-result v6

    .line 1605
    goto :goto_31

    .line 1606
    :cond_58
    const/4 v6, -0x1

    .line 1607
    :goto_31
    invoke-virtual {v7, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMaxTextLength(I)V

    .line 1608
    .line 1609
    .line 1610
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 1611
    .line 1612
    .line 1613
    move-result v6

    .line 1614
    invoke-virtual {v7, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setEnabled(Z)V

    .line 1615
    .line 1616
    .line 1617
    sget-object v6, LE0/r;->k:LE0/u;

    .line 1618
    .line 1619
    invoke-virtual {v12, v6}, Li/E;->c(Ljava/lang/Object;)Z

    .line 1620
    .line 1621
    .line 1622
    move-result v8

    .line 1623
    invoke-virtual {v7, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setFocusable(Z)V

    .line 1624
    .line 1625
    .line 1626
    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocusable()Z

    .line 1627
    .line 1628
    .line 1629
    move-result v8

    .line 1630
    if-eqz v8, :cond_5a

    .line 1631
    .line 1632
    invoke-virtual {v3, v6}, LE0/k;->c(LE0/u;)Ljava/lang/Object;

    .line 1633
    .line 1634
    .line 1635
    move-result-object v8

    .line 1636
    check-cast v8, Ljava/lang/Boolean;

    .line 1637
    .line 1638
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1639
    .line 1640
    .line 1641
    move-result v8

    .line 1642
    invoke-virtual {v7, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setFocused(Z)V

    .line 1643
    .line 1644
    .line 1645
    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z

    .line 1646
    .line 1647
    .line 1648
    move-result v8

    .line 1649
    if-eqz v8, :cond_59

    .line 1650
    .line 1651
    const/4 v8, 0x2

    .line 1652
    invoke-virtual {v10, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 1653
    .line 1654
    .line 1655
    move-object/from16 v8, v32

    .line 1656
    .line 1657
    iput v4, v8, Lx0/x;->p:I

    .line 1658
    .line 1659
    :goto_32
    const/4 v9, 0x1

    .line 1660
    goto :goto_33

    .line 1661
    :cond_59
    move-object/from16 v8, v32

    .line 1662
    .line 1663
    const/4 v9, 0x1

    .line 1664
    invoke-virtual {v10, v9}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 1665
    .line 1666
    .line 1667
    goto :goto_33

    .line 1668
    :cond_5a
    move-object/from16 v8, v32

    .line 1669
    .line 1670
    goto :goto_32

    .line 1671
    :goto_33
    invoke-static {v0}, LE0/q;->e(LE0/n;)Z

    .line 1672
    .line 1673
    .line 1674
    move-result v11

    .line 1675
    xor-int/2addr v11, v9

    .line 1676
    invoke-virtual {v7, v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->setVisibleToUser(Z)V

    .line 1677
    .line 1678
    .line 1679
    sget-object v9, LE0/r;->j:LE0/u;

    .line 1680
    .line 1681
    invoke-static {v3, v9}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1682
    .line 1683
    .line 1684
    move-result-object v9

    .line 1685
    invoke-static {v9}, LM0/m;->l(Ljava/lang/Object;)V

    .line 1686
    .line 1687
    .line 1688
    const/4 v13, 0x0

    .line 1689
    invoke-virtual {v10, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    .line 1690
    .line 1691
    .line 1692
    sget-object v9, LE0/j;->b:LE0/u;

    .line 1693
    .line 1694
    invoke-static {v3, v9}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1695
    .line 1696
    .line 1697
    move-result-object v9

    .line 1698
    check-cast v9, LE0/a;

    .line 1699
    .line 1700
    const/16 v11, 0x10

    .line 1701
    .line 1702
    if-eqz v9, :cond_63

    .line 1703
    .line 1704
    sget-object v13, LE0/r;->G:LE0/u;

    .line 1705
    .line 1706
    invoke-static {v3, v13}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1707
    .line 1708
    .line 1709
    move-result-object v13

    .line 1710
    sget-object v14, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1711
    .line 1712
    invoke-static {v13, v14}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1713
    .line 1714
    .line 1715
    move-result v13

    .line 1716
    if-nez v2, :cond_5c

    .line 1717
    .line 1718
    :cond_5b
    const/4 v5, 0x0

    .line 1719
    goto :goto_34

    .line 1720
    :cond_5c
    iget v14, v2, LE0/g;->a:I

    .line 1721
    .line 1722
    const/4 v5, 0x4

    .line 1723
    if-ne v14, v5, :cond_5b

    .line 1724
    .line 1725
    const/4 v5, 0x1

    .line 1726
    :goto_34
    if-nez v5, :cond_60

    .line 1727
    .line 1728
    if-nez v2, :cond_5e

    .line 1729
    .line 1730
    :cond_5d
    const/4 v2, 0x0

    .line 1731
    goto :goto_35

    .line 1732
    :cond_5e
    iget v2, v2, LE0/g;->a:I

    .line 1733
    .line 1734
    const/4 v5, 0x3

    .line 1735
    if-ne v2, v5, :cond_5d

    .line 1736
    .line 1737
    const/4 v2, 0x1

    .line 1738
    :goto_35
    if-eqz v2, :cond_5f

    .line 1739
    .line 1740
    goto :goto_36

    .line 1741
    :cond_5f
    const/4 v2, 0x0

    .line 1742
    goto :goto_37

    .line 1743
    :cond_60
    :goto_36
    const/4 v2, 0x1

    .line 1744
    :goto_37
    if-eqz v2, :cond_62

    .line 1745
    .line 1746
    if-eqz v2, :cond_61

    .line 1747
    .line 1748
    if-nez v13, :cond_61

    .line 1749
    .line 1750
    goto :goto_38

    .line 1751
    :cond_61
    const/4 v2, 0x0

    .line 1752
    goto :goto_39

    .line 1753
    :cond_62
    :goto_38
    const/4 v2, 0x1

    .line 1754
    :goto_39
    invoke-virtual {v10, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    .line 1755
    .line 1756
    .line 1757
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 1758
    .line 1759
    .line 1760
    move-result v2

    .line 1761
    if-eqz v2, :cond_63

    .line 1762
    .line 1763
    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    .line 1764
    .line 1765
    .line 1766
    move-result v2

    .line 1767
    if-eqz v2, :cond_63

    .line 1768
    .line 1769
    new-instance v2, Lh1/f;

    .line 1770
    .line 1771
    iget-object v5, v9, LE0/a;->a:Ljava/lang/String;

    .line 1772
    .line 1773
    invoke-direct {v2, v11, v5}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1774
    .line 1775
    .line 1776
    invoke-virtual {v15, v2}, Lh1/g;->a(Lh1/f;)V

    .line 1777
    .line 1778
    .line 1779
    :cond_63
    const/4 v13, 0x0

    .line 1780
    invoke-virtual {v10, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLongClickable(Z)V

    .line 1781
    .line 1782
    .line 1783
    sget-object v2, LE0/j;->c:LE0/u;

    .line 1784
    .line 1785
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1786
    .line 1787
    .line 1788
    move-result-object v2

    .line 1789
    check-cast v2, LE0/a;

    .line 1790
    .line 1791
    if-eqz v2, :cond_64

    .line 1792
    .line 1793
    const/4 v9, 0x1

    .line 1794
    invoke-virtual {v10, v9}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLongClickable(Z)V

    .line 1795
    .line 1796
    .line 1797
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 1798
    .line 1799
    .line 1800
    move-result v5

    .line 1801
    if-eqz v5, :cond_64

    .line 1802
    .line 1803
    new-instance v5, Lh1/f;

    .line 1804
    .line 1805
    const/16 v9, 0x20

    .line 1806
    .line 1807
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1808
    .line 1809
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1810
    .line 1811
    .line 1812
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1813
    .line 1814
    .line 1815
    :cond_64
    sget-object v2, LE0/j;->p:LE0/u;

    .line 1816
    .line 1817
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1818
    .line 1819
    .line 1820
    move-result-object v2

    .line 1821
    check-cast v2, LE0/a;

    .line 1822
    .line 1823
    if-eqz v2, :cond_65

    .line 1824
    .line 1825
    new-instance v5, Lh1/f;

    .line 1826
    .line 1827
    const/16 v9, 0x4000

    .line 1828
    .line 1829
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1830
    .line 1831
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1832
    .line 1833
    .line 1834
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1835
    .line 1836
    .line 1837
    :cond_65
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 1838
    .line 1839
    .line 1840
    move-result v2

    .line 1841
    if-eqz v2, :cond_6a

    .line 1842
    .line 1843
    sget-object v2, LE0/j;->j:LE0/u;

    .line 1844
    .line 1845
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1846
    .line 1847
    .line 1848
    move-result-object v2

    .line 1849
    check-cast v2, LE0/a;

    .line 1850
    .line 1851
    if-eqz v2, :cond_66

    .line 1852
    .line 1853
    new-instance v5, Lh1/f;

    .line 1854
    .line 1855
    const/high16 v9, 0x200000

    .line 1856
    .line 1857
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1858
    .line 1859
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1860
    .line 1861
    .line 1862
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1863
    .line 1864
    .line 1865
    :cond_66
    sget-object v2, LE0/j;->o:LE0/u;

    .line 1866
    .line 1867
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1868
    .line 1869
    .line 1870
    move-result-object v2

    .line 1871
    check-cast v2, LE0/a;

    .line 1872
    .line 1873
    if-eqz v2, :cond_67

    .line 1874
    .line 1875
    new-instance v5, Lh1/f;

    .line 1876
    .line 1877
    const v9, 0x1020054

    .line 1878
    .line 1879
    .line 1880
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1881
    .line 1882
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1883
    .line 1884
    .line 1885
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1886
    .line 1887
    .line 1888
    :cond_67
    sget-object v2, LE0/j;->q:LE0/u;

    .line 1889
    .line 1890
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1891
    .line 1892
    .line 1893
    move-result-object v2

    .line 1894
    check-cast v2, LE0/a;

    .line 1895
    .line 1896
    if-eqz v2, :cond_68

    .line 1897
    .line 1898
    new-instance v5, Lh1/f;

    .line 1899
    .line 1900
    const/high16 v9, 0x10000

    .line 1901
    .line 1902
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1903
    .line 1904
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1905
    .line 1906
    .line 1907
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1908
    .line 1909
    .line 1910
    :cond_68
    sget-object v2, LE0/j;->r:LE0/u;

    .line 1911
    .line 1912
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1913
    .line 1914
    .line 1915
    move-result-object v2

    .line 1916
    check-cast v2, LE0/a;

    .line 1917
    .line 1918
    if-eqz v2, :cond_6a

    .line 1919
    .line 1920
    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z

    .line 1921
    .line 1922
    .line 1923
    move-result v5

    .line 1924
    if-eqz v5, :cond_6a

    .line 1925
    .line 1926
    invoke-virtual/range {v29 .. v29}, Lx0/s;->getClipboardManager()Lx0/i;

    .line 1927
    .line 1928
    .line 1929
    move-result-object v5

    .line 1930
    iget-object v5, v5, Lx0/i;->a:Landroid/content/ClipboardManager;

    .line 1931
    .line 1932
    invoke-virtual {v5}, Landroid/content/ClipboardManager;->getPrimaryClipDescription()Landroid/content/ClipDescription;

    .line 1933
    .line 1934
    .line 1935
    move-result-object v5

    .line 1936
    if-eqz v5, :cond_69

    .line 1937
    .line 1938
    const-string v9, "text/*"

    .line 1939
    .line 1940
    invoke-virtual {v5, v9}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z

    .line 1941
    .line 1942
    .line 1943
    move-result v5

    .line 1944
    goto :goto_3a

    .line 1945
    :cond_69
    const/4 v5, 0x0

    .line 1946
    :goto_3a
    if-eqz v5, :cond_6a

    .line 1947
    .line 1948
    new-instance v5, Lh1/f;

    .line 1949
    .line 1950
    const v9, 0x8000

    .line 1951
    .line 1952
    .line 1953
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 1954
    .line 1955
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 1956
    .line 1957
    .line 1958
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 1959
    .line 1960
    .line 1961
    :cond_6a
    invoke-static {v0}, Lx0/x;->l(LE0/n;)Ljava/lang/String;

    .line 1962
    .line 1963
    .line 1964
    move-result-object v2

    .line 1965
    if-eqz v2, :cond_6c

    .line 1966
    .line 1967
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 1968
    .line 1969
    .line 1970
    move-result v2

    .line 1971
    if-nez v2, :cond_6b

    .line 1972
    .line 1973
    goto :goto_3b

    .line 1974
    :cond_6b
    const/4 v2, 0x0

    .line 1975
    goto :goto_3c

    .line 1976
    :cond_6c
    :goto_3b
    const/4 v2, 0x1

    .line 1977
    :goto_3c
    if-nez v2, :cond_77

    .line 1978
    .line 1979
    invoke-virtual {v8, v0}, Lx0/x;->j(LE0/n;)I

    .line 1980
    .line 1981
    .line 1982
    move-result v2

    .line 1983
    invoke-virtual {v8, v0}, Lx0/x;->i(LE0/n;)I

    .line 1984
    .line 1985
    .line 1986
    move-result v5

    .line 1987
    invoke-virtual {v7, v2, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTextSelection(II)V

    .line 1988
    .line 1989
    .line 1990
    sget-object v2, LE0/j;->i:LE0/u;

    .line 1991
    .line 1992
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 1993
    .line 1994
    .line 1995
    move-result-object v2

    .line 1996
    check-cast v2, LE0/a;

    .line 1997
    .line 1998
    new-instance v5, Lh1/f;

    .line 1999
    .line 2000
    if-eqz v2, :cond_6d

    .line 2001
    .line 2002
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 2003
    .line 2004
    goto :goto_3d

    .line 2005
    :cond_6d
    move-object/from16 v2, v16

    .line 2006
    .line 2007
    :goto_3d
    const/high16 v9, 0x20000

    .line 2008
    .line 2009
    invoke-direct {v5, v9, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 2010
    .line 2011
    .line 2012
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 2013
    .line 2014
    .line 2015
    const/16 v2, 0x100

    .line 2016
    .line 2017
    invoke-virtual {v10, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 2018
    .line 2019
    .line 2020
    const/16 v2, 0x200

    .line 2021
    .line 2022
    invoke-virtual {v10, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 2023
    .line 2024
    .line 2025
    const/16 v2, 0xb

    .line 2026
    .line 2027
    invoke-virtual {v10, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMovementGranularities(I)V

    .line 2028
    .line 2029
    .line 2030
    sget-object v2, LE0/r;->a:LE0/u;

    .line 2031
    .line 2032
    invoke-static {v3, v2}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2033
    .line 2034
    .line 2035
    move-result-object v2

    .line 2036
    check-cast v2, Ljava/util/List;

    .line 2037
    .line 2038
    if-eqz v2, :cond_6f

    .line 2039
    .line 2040
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 2041
    .line 2042
    .line 2043
    move-result v2

    .line 2044
    if-eqz v2, :cond_6e

    .line 2045
    .line 2046
    goto :goto_3e

    .line 2047
    :cond_6e
    const/4 v2, 0x0

    .line 2048
    goto :goto_3f

    .line 2049
    :cond_6f
    :goto_3e
    const/4 v2, 0x1

    .line 2050
    :goto_3f
    if-eqz v2, :cond_77

    .line 2051
    .line 2052
    sget-object v2, LE0/j;->a:LE0/u;

    .line 2053
    .line 2054
    invoke-virtual {v12, v2}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2055
    .line 2056
    .line 2057
    move-result v2

    .line 2058
    if-eqz v2, :cond_77

    .line 2059
    .line 2060
    sget-object v2, LE0/r;->D:LE0/u;

    .line 2061
    .line 2062
    invoke-virtual {v12, v2}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2063
    .line 2064
    .line 2065
    move-result v2

    .line 2066
    if-eqz v2, :cond_70

    .line 2067
    .line 2068
    invoke-static {v3, v6}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2069
    .line 2070
    .line 2071
    move-result-object v2

    .line 2072
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2073
    .line 2074
    invoke-static {v2, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2075
    .line 2076
    .line 2077
    move-result v2

    .line 2078
    if-nez v2, :cond_70

    .line 2079
    .line 2080
    goto :goto_44

    .line 2081
    :cond_70
    invoke-virtual/range {v30 .. v30}, Lw0/E;->q()Lw0/E;

    .line 2082
    .line 2083
    .line 2084
    move-result-object v2

    .line 2085
    :goto_40
    if-eqz v2, :cond_73

    .line 2086
    .line 2087
    invoke-virtual {v2}, Lw0/E;->s()LE0/k;

    .line 2088
    .line 2089
    .line 2090
    move-result-object v3

    .line 2091
    if-eqz v3, :cond_71

    .line 2092
    .line 2093
    iget-boolean v5, v3, LE0/k;->f:Z

    .line 2094
    .line 2095
    const/4 v9, 0x1

    .line 2096
    if-ne v5, v9, :cond_71

    .line 2097
    .line 2098
    sget-object v5, LE0/r;->D:LE0/u;

    .line 2099
    .line 2100
    iget-object v3, v3, LE0/k;->d:Li/E;

    .line 2101
    .line 2102
    invoke-virtual {v3, v5}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2103
    .line 2104
    .line 2105
    move-result v3

    .line 2106
    if-eqz v3, :cond_71

    .line 2107
    .line 2108
    const/4 v3, 0x1

    .line 2109
    goto :goto_41

    .line 2110
    :cond_71
    const/4 v3, 0x0

    .line 2111
    :goto_41
    if-eqz v3, :cond_72

    .line 2112
    .line 2113
    goto :goto_42

    .line 2114
    :cond_72
    invoke-virtual {v2}, Lw0/E;->q()Lw0/E;

    .line 2115
    .line 2116
    .line 2117
    move-result-object v2

    .line 2118
    goto :goto_40

    .line 2119
    :cond_73
    move-object/from16 v2, v16

    .line 2120
    .line 2121
    :goto_42
    if-eqz v2, :cond_76

    .line 2122
    .line 2123
    invoke-virtual {v2}, Lw0/E;->s()LE0/k;

    .line 2124
    .line 2125
    .line 2126
    move-result-object v2

    .line 2127
    if-eqz v2, :cond_75

    .line 2128
    .line 2129
    iget-object v2, v2, LE0/k;->d:Li/E;

    .line 2130
    .line 2131
    invoke-virtual {v2, v6}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2132
    .line 2133
    .line 2134
    move-result-object v2

    .line 2135
    if-nez v2, :cond_74

    .line 2136
    .line 2137
    move-object/from16 v2, v16

    .line 2138
    .line 2139
    :cond_74
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2140
    .line 2141
    invoke-static {v2, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2142
    .line 2143
    .line 2144
    move-result v3

    .line 2145
    goto :goto_43

    .line 2146
    :cond_75
    const/4 v3, 0x0

    .line 2147
    :goto_43
    if-nez v3, :cond_76

    .line 2148
    .line 2149
    :goto_44
    const/4 v2, 0x1

    .line 2150
    goto :goto_45

    .line 2151
    :cond_76
    const/4 v2, 0x0

    .line 2152
    :goto_45
    if-nez v2, :cond_77

    .line 2153
    .line 2154
    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->getMovementGranularities()I

    .line 2155
    .line 2156
    .line 2157
    move-result v2

    .line 2158
    or-int/lit8 v2, v2, 0x14

    .line 2159
    .line 2160
    invoke-virtual {v10, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMovementGranularities(I)V

    .line 2161
    .line 2162
    .line 2163
    :cond_77
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2164
    .line 2165
    const/16 v3, 0x1a

    .line 2166
    .line 2167
    if-lt v2, v3, :cond_7d

    .line 2168
    .line 2169
    new-instance v2, Ljava/util/ArrayList;

    .line 2170
    .line 2171
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2172
    .line 2173
    .line 2174
    const-string v5, "androidx.compose.ui.semantics.id"

    .line 2175
    .line 2176
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2177
    .line 2178
    .line 2179
    invoke-virtual {v15}, Lh1/g;->e()Ljava/lang/CharSequence;

    .line 2180
    .line 2181
    .line 2182
    move-result-object v5

    .line 2183
    if-eqz v5, :cond_79

    .line 2184
    .line 2185
    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    .line 2186
    .line 2187
    .line 2188
    move-result v5

    .line 2189
    if-nez v5, :cond_78

    .line 2190
    .line 2191
    goto :goto_46

    .line 2192
    :cond_78
    const/4 v5, 0x0

    .line 2193
    goto :goto_47

    .line 2194
    :cond_79
    :goto_46
    const/4 v5, 0x1

    .line 2195
    :goto_47
    if-nez v5, :cond_7a

    .line 2196
    .line 2197
    sget-object v5, LE0/j;->a:LE0/u;

    .line 2198
    .line 2199
    invoke-virtual {v12, v5}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2200
    .line 2201
    .line 2202
    move-result v5

    .line 2203
    if-eqz v5, :cond_7a

    .line 2204
    .line 2205
    const-string v5, "android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_KEY"

    .line 2206
    .line 2207
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2208
    .line 2209
    .line 2210
    :cond_7a
    sget-object v5, LE0/r;->x:LE0/u;

    .line 2211
    .line 2212
    invoke-virtual {v12, v5}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2213
    .line 2214
    .line 2215
    move-result v5

    .line 2216
    if-eqz v5, :cond_7b

    .line 2217
    .line 2218
    const-string v5, "androidx.compose.ui.semantics.testTag"

    .line 2219
    .line 2220
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2221
    .line 2222
    .line 2223
    :cond_7b
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2224
    .line 2225
    .line 2226
    move-result-object v5

    .line 2227
    sget-object v6, LE0/r;->M:LE0/u;

    .line 2228
    .line 2229
    iget-object v5, v5, LE0/k;->d:Li/E;

    .line 2230
    .line 2231
    invoke-virtual {v5, v6}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2232
    .line 2233
    .line 2234
    move-result v5

    .line 2235
    if-eqz v5, :cond_7c

    .line 2236
    .line 2237
    const-string v5, "androidx.compose.ui.semantics.shapeType"

    .line 2238
    .line 2239
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2240
    .line 2241
    .line 2242
    const-string v5, "androidx.compose.ui.semantics.shapeRect"

    .line 2243
    .line 2244
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2245
    .line 2246
    .line 2247
    const-string v5, "androidx.compose.ui.semantics.shapeCorners"

    .line 2248
    .line 2249
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2250
    .line 2251
    .line 2252
    const-string v5, "androidx.compose.ui.semantics.shapeRegion"

    .line 2253
    .line 2254
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2255
    .line 2256
    .line 2257
    :cond_7c
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2258
    .line 2259
    .line 2260
    move-result-object v5

    .line 2261
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2262
    .line 2263
    .line 2264
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2265
    .line 2266
    if-lt v5, v3, :cond_7d

    .line 2267
    .line 2268
    invoke-static {v10, v2}, Ld0/n;->f(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/util/ArrayList;)V

    .line 2269
    .line 2270
    .line 2271
    :cond_7d
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2272
    .line 2273
    .line 2274
    move-result-object v2

    .line 2275
    sget-object v3, LE0/r;->c:LE0/u;

    .line 2276
    .line 2277
    invoke-static {v2, v3}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2278
    .line 2279
    .line 2280
    move-result-object v2

    .line 2281
    check-cast v2, LE0/f;

    .line 2282
    .line 2283
    if-eqz v2, :cond_83

    .line 2284
    .line 2285
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2286
    .line 2287
    .line 2288
    move-result-object v3

    .line 2289
    sget-object v5, LE0/j;->h:LE0/u;

    .line 2290
    .line 2291
    iget-object v3, v3, LE0/k;->d:Li/E;

    .line 2292
    .line 2293
    invoke-virtual {v3, v5}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2294
    .line 2295
    .line 2296
    move-result v3

    .line 2297
    if-eqz v3, :cond_7e

    .line 2298
    .line 2299
    const-string v3, "android.widget.SeekBar"

    .line 2300
    .line 2301
    invoke-virtual {v15, v3}, Lh1/g;->g(Ljava/lang/String;)V

    .line 2302
    .line 2303
    .line 2304
    goto :goto_48

    .line 2305
    :cond_7e
    const-string v3, "android.widget.ProgressBar"

    .line 2306
    .line 2307
    invoke-virtual {v15, v3}, Lh1/g;->g(Ljava/lang/String;)V

    .line 2308
    .line 2309
    .line 2310
    :goto_48
    sget-object v3, LE0/f;->b:LE0/f;

    .line 2311
    .line 2312
    sget-object v3, LE0/f;->b:LE0/f;

    .line 2313
    .line 2314
    if-eq v2, v3, :cond_7f

    .line 2315
    .line 2316
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2317
    .line 2318
    .line 2319
    move-result-object v3

    .line 2320
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2321
    .line 2322
    .line 2323
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->floatValue()F

    .line 2324
    .line 2325
    .line 2326
    move-result v3

    .line 2327
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2328
    .line 2329
    .line 2330
    move-result-object v6

    .line 2331
    invoke-virtual {v6}, LY1/a;->a()Ljava/lang/Comparable;

    .line 2332
    .line 2333
    .line 2334
    move-result-object v6

    .line 2335
    check-cast v6, Ljava/lang/Number;

    .line 2336
    .line 2337
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 2338
    .line 2339
    .line 2340
    move-result v6

    .line 2341
    new-instance v7, LA0/b;

    .line 2342
    .line 2343
    const/4 v9, 0x0

    .line 2344
    const/4 v12, 0x1

    .line 2345
    invoke-static {v12, v3, v6, v9}, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;->obtain(IFFF)Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;

    .line 2346
    .line 2347
    .line 2348
    move-result-object v3

    .line 2349
    invoke-direct {v7, v3}, LA0/b;-><init>(Ljava/lang/Object;)V

    .line 2350
    .line 2351
    .line 2352
    iget-object v3, v7, LA0/b;->a:Ljava/lang/Object;

    .line 2353
    .line 2354
    check-cast v3, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;

    .line 2355
    .line 2356
    invoke-virtual {v10, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setRangeInfo(Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;)V

    .line 2357
    .line 2358
    .line 2359
    :cond_7f
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2360
    .line 2361
    .line 2362
    move-result-object v3

    .line 2363
    iget-object v3, v3, LE0/k;->d:Li/E;

    .line 2364
    .line 2365
    invoke-virtual {v3, v5}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2366
    .line 2367
    .line 2368
    move-result v3

    .line 2369
    if-eqz v3, :cond_83

    .line 2370
    .line 2371
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 2372
    .line 2373
    .line 2374
    move-result v3

    .line 2375
    if-eqz v3, :cond_83

    .line 2376
    .line 2377
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2378
    .line 2379
    .line 2380
    move-result-object v3

    .line 2381
    invoke-virtual {v3}, LY1/a;->a()Ljava/lang/Comparable;

    .line 2382
    .line 2383
    .line 2384
    move-result-object v3

    .line 2385
    check-cast v3, Ljava/lang/Number;

    .line 2386
    .line 2387
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 2388
    .line 2389
    .line 2390
    move-result v3

    .line 2391
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2392
    .line 2393
    .line 2394
    move-result-object v5

    .line 2395
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2396
    .line 2397
    .line 2398
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->floatValue()F

    .line 2399
    .line 2400
    .line 2401
    move-result v5

    .line 2402
    cmpg-float v6, v3, v5

    .line 2403
    .line 2404
    if-gez v6, :cond_80

    .line 2405
    .line 2406
    move v3, v5

    .line 2407
    :cond_80
    const/16 v17, 0x0

    .line 2408
    .line 2409
    cmpg-float v3, v17, v3

    .line 2410
    .line 2411
    if-gez v3, :cond_81

    .line 2412
    .line 2413
    sget-object v3, Lh1/f;->e:Lh1/f;

    .line 2414
    .line 2415
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2416
    .line 2417
    .line 2418
    :cond_81
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2419
    .line 2420
    .line 2421
    move-result-object v3

    .line 2422
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2423
    .line 2424
    .line 2425
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->floatValue()F

    .line 2426
    .line 2427
    .line 2428
    move-result v3

    .line 2429
    invoke-virtual {v2}, LE0/f;->a()LY1/a;

    .line 2430
    .line 2431
    .line 2432
    move-result-object v2

    .line 2433
    invoke-virtual {v2}, LY1/a;->a()Ljava/lang/Comparable;

    .line 2434
    .line 2435
    .line 2436
    move-result-object v2

    .line 2437
    check-cast v2, Ljava/lang/Number;

    .line 2438
    .line 2439
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 2440
    .line 2441
    .line 2442
    move-result v2

    .line 2443
    cmpl-float v5, v3, v2

    .line 2444
    .line 2445
    if-lez v5, :cond_82

    .line 2446
    .line 2447
    move v3, v2

    .line 2448
    :cond_82
    const/16 v17, 0x0

    .line 2449
    .line 2450
    cmpl-float v2, v17, v3

    .line 2451
    .line 2452
    if-lez v2, :cond_83

    .line 2453
    .line 2454
    sget-object v2, Lh1/f;->f:Lh1/f;

    .line 2455
    .line 2456
    invoke-virtual {v15, v2}, Lh1/g;->a(Lh1/f;)V

    .line 2457
    .line 2458
    .line 2459
    :cond_83
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2460
    .line 2461
    invoke-static {v0, v15}, Lx0/E;->d(LE0/n;Lh1/g;)V

    .line 2462
    .line 2463
    .line 2464
    invoke-static {v0, v15}, LT0/g;->J(LE0/n;Lh1/g;)V

    .line 2465
    .line 2466
    .line 2467
    invoke-static {v0, v15}, LT0/g;->K(LE0/n;Lh1/g;)V

    .line 2468
    .line 2469
    .line 2470
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2471
    .line 2472
    .line 2473
    move-result-object v3

    .line 2474
    sget-object v5, LE0/r;->t:LE0/u;

    .line 2475
    .line 2476
    invoke-static {v3, v5}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2477
    .line 2478
    .line 2479
    move-result-object v3

    .line 2480
    check-cast v3, LE0/h;

    .line 2481
    .line 2482
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2483
    .line 2484
    .line 2485
    move-result-object v5

    .line 2486
    sget-object v6, LE0/j;->d:LE0/u;

    .line 2487
    .line 2488
    invoke-static {v5, v6}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2489
    .line 2490
    .line 2491
    move-result-object v5

    .line 2492
    check-cast v5, LE0/a;

    .line 2493
    .line 2494
    if-eqz v3, :cond_8f

    .line 2495
    .line 2496
    if-eqz v5, :cond_8f

    .line 2497
    .line 2498
    invoke-virtual {v0}, LE0/n;->k()LE0/k;

    .line 2499
    .line 2500
    .line 2501
    move-result-object v6

    .line 2502
    sget-object v7, LE0/r;->f:LE0/u;

    .line 2503
    .line 2504
    iget-object v6, v6, LE0/k;->d:Li/E;

    .line 2505
    .line 2506
    invoke-virtual {v6, v7}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2507
    .line 2508
    .line 2509
    move-result-object v6

    .line 2510
    if-nez v6, :cond_84

    .line 2511
    .line 2512
    move-object/from16 v6, v16

    .line 2513
    .line 2514
    :cond_84
    if-nez v6, :cond_87

    .line 2515
    .line 2516
    invoke-virtual {v0}, LE0/n;->k()LE0/k;

    .line 2517
    .line 2518
    .line 2519
    move-result-object v6

    .line 2520
    sget-object v7, LE0/r;->e:LE0/u;

    .line 2521
    .line 2522
    iget-object v6, v6, LE0/k;->d:Li/E;

    .line 2523
    .line 2524
    invoke-virtual {v6, v7}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2525
    .line 2526
    .line 2527
    move-result-object v6

    .line 2528
    if-nez v6, :cond_85

    .line 2529
    .line 2530
    move-object/from16 v6, v16

    .line 2531
    .line 2532
    :cond_85
    if-eqz v6, :cond_86

    .line 2533
    .line 2534
    goto :goto_49

    .line 2535
    :cond_86
    const/4 v6, 0x0

    .line 2536
    goto :goto_4a

    .line 2537
    :cond_87
    :goto_49
    const/4 v6, 0x1

    .line 2538
    :goto_4a
    if-nez v6, :cond_88

    .line 2539
    .line 2540
    const-string v6, "android.widget.HorizontalScrollView"

    .line 2541
    .line 2542
    invoke-virtual {v15, v6}, Lh1/g;->g(Ljava/lang/String;)V

    .line 2543
    .line 2544
    .line 2545
    :cond_88
    iget-object v6, v3, LE0/h;->b:Ln/n0;

    .line 2546
    .line 2547
    invoke-virtual {v6}, Ln/n0;->a()Ljava/lang/Object;

    .line 2548
    .line 2549
    .line 2550
    move-result-object v6

    .line 2551
    check-cast v6, Ljava/lang/Number;

    .line 2552
    .line 2553
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 2554
    .line 2555
    .line 2556
    move-result v6

    .line 2557
    const/16 v17, 0x0

    .line 2558
    .line 2559
    cmpl-float v6, v6, v17

    .line 2560
    .line 2561
    if-lez v6, :cond_89

    .line 2562
    .line 2563
    const/4 v9, 0x1

    .line 2564
    invoke-virtual {v10, v9}, Landroid/view/accessibility/AccessibilityNodeInfo;->setScrollable(Z)V

    .line 2565
    .line 2566
    .line 2567
    :cond_89
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 2568
    .line 2569
    .line 2570
    move-result v6

    .line 2571
    if-eqz v6, :cond_8f

    .line 2572
    .line 2573
    invoke-static {v3}, Lx0/x;->r(LE0/h;)Z

    .line 2574
    .line 2575
    .line 2576
    move-result v6

    .line 2577
    sget-object v7, LT0/o;->e:LT0/o;

    .line 2578
    .line 2579
    if-eqz v6, :cond_8c

    .line 2580
    .line 2581
    sget-object v6, Lh1/f;->e:Lh1/f;

    .line 2582
    .line 2583
    invoke-virtual {v15, v6}, Lh1/g;->a(Lh1/f;)V

    .line 2584
    .line 2585
    .line 2586
    move-object/from16 v6, v30

    .line 2587
    .line 2588
    iget-object v9, v6, Lw0/E;->C:LT0/o;

    .line 2589
    .line 2590
    if-ne v9, v7, :cond_8a

    .line 2591
    .line 2592
    const/4 v9, 0x1

    .line 2593
    goto :goto_4b

    .line 2594
    :cond_8a
    const/4 v9, 0x0

    .line 2595
    :goto_4b
    if-nez v9, :cond_8b

    .line 2596
    .line 2597
    sget-object v9, Lh1/f;->j:Lh1/f;

    .line 2598
    .line 2599
    goto :goto_4c

    .line 2600
    :cond_8b
    sget-object v9, Lh1/f;->h:Lh1/f;

    .line 2601
    .line 2602
    :goto_4c
    invoke-virtual {v15, v9}, Lh1/g;->a(Lh1/f;)V

    .line 2603
    .line 2604
    .line 2605
    goto :goto_4d

    .line 2606
    :cond_8c
    move-object/from16 v6, v30

    .line 2607
    .line 2608
    :goto_4d
    invoke-static {v3}, Lx0/x;->q(LE0/h;)Z

    .line 2609
    .line 2610
    .line 2611
    move-result v3

    .line 2612
    if-eqz v3, :cond_8f

    .line 2613
    .line 2614
    sget-object v3, Lh1/f;->f:Lh1/f;

    .line 2615
    .line 2616
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2617
    .line 2618
    .line 2619
    iget-object v3, v6, Lw0/E;->C:LT0/o;

    .line 2620
    .line 2621
    if-ne v3, v7, :cond_8d

    .line 2622
    .line 2623
    const/4 v3, 0x1

    .line 2624
    goto :goto_4e

    .line 2625
    :cond_8d
    const/4 v3, 0x0

    .line 2626
    :goto_4e
    if-nez v3, :cond_8e

    .line 2627
    .line 2628
    sget-object v3, Lh1/f;->h:Lh1/f;

    .line 2629
    .line 2630
    goto :goto_4f

    .line 2631
    :cond_8e
    sget-object v3, Lh1/f;->j:Lh1/f;

    .line 2632
    .line 2633
    :goto_4f
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2634
    .line 2635
    .line 2636
    :cond_8f
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2637
    .line 2638
    .line 2639
    move-result-object v3

    .line 2640
    sget-object v6, LE0/r;->u:LE0/u;

    .line 2641
    .line 2642
    invoke-static {v3, v6}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2643
    .line 2644
    .line 2645
    move-result-object v3

    .line 2646
    check-cast v3, LE0/h;

    .line 2647
    .line 2648
    if-eqz v3, :cond_97

    .line 2649
    .line 2650
    if-eqz v5, :cond_97

    .line 2651
    .line 2652
    invoke-virtual {v0}, LE0/n;->k()LE0/k;

    .line 2653
    .line 2654
    .line 2655
    move-result-object v5

    .line 2656
    sget-object v6, LE0/r;->f:LE0/u;

    .line 2657
    .line 2658
    iget-object v5, v5, LE0/k;->d:Li/E;

    .line 2659
    .line 2660
    invoke-virtual {v5, v6}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2661
    .line 2662
    .line 2663
    move-result-object v5

    .line 2664
    if-nez v5, :cond_90

    .line 2665
    .line 2666
    move-object/from16 v5, v16

    .line 2667
    .line 2668
    :cond_90
    if-nez v5, :cond_93

    .line 2669
    .line 2670
    invoke-virtual {v0}, LE0/n;->k()LE0/k;

    .line 2671
    .line 2672
    .line 2673
    move-result-object v5

    .line 2674
    sget-object v6, LE0/r;->e:LE0/u;

    .line 2675
    .line 2676
    iget-object v5, v5, LE0/k;->d:Li/E;

    .line 2677
    .line 2678
    invoke-virtual {v5, v6}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2679
    .line 2680
    .line 2681
    move-result-object v5

    .line 2682
    if-nez v5, :cond_91

    .line 2683
    .line 2684
    move-object/from16 v5, v16

    .line 2685
    .line 2686
    :cond_91
    if-eqz v5, :cond_92

    .line 2687
    .line 2688
    goto :goto_50

    .line 2689
    :cond_92
    const/4 v5, 0x0

    .line 2690
    goto :goto_51

    .line 2691
    :cond_93
    :goto_50
    const/4 v5, 0x1

    .line 2692
    :goto_51
    if-nez v5, :cond_94

    .line 2693
    .line 2694
    const-string v5, "android.widget.ScrollView"

    .line 2695
    .line 2696
    invoke-virtual {v15, v5}, Lh1/g;->g(Ljava/lang/String;)V

    .line 2697
    .line 2698
    .line 2699
    :cond_94
    iget-object v5, v3, LE0/h;->b:Ln/n0;

    .line 2700
    .line 2701
    invoke-virtual {v5}, Ln/n0;->a()Ljava/lang/Object;

    .line 2702
    .line 2703
    .line 2704
    move-result-object v5

    .line 2705
    check-cast v5, Ljava/lang/Number;

    .line 2706
    .line 2707
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 2708
    .line 2709
    .line 2710
    move-result v5

    .line 2711
    const/16 v17, 0x0

    .line 2712
    .line 2713
    cmpl-float v5, v5, v17

    .line 2714
    .line 2715
    if-lez v5, :cond_95

    .line 2716
    .line 2717
    const/4 v9, 0x1

    .line 2718
    invoke-virtual {v10, v9}, Landroid/view/accessibility/AccessibilityNodeInfo;->setScrollable(Z)V

    .line 2719
    .line 2720
    .line 2721
    :cond_95
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 2722
    .line 2723
    .line 2724
    move-result v5

    .line 2725
    if-eqz v5, :cond_97

    .line 2726
    .line 2727
    invoke-static {v3}, Lx0/x;->r(LE0/h;)Z

    .line 2728
    .line 2729
    .line 2730
    move-result v5

    .line 2731
    if-eqz v5, :cond_96

    .line 2732
    .line 2733
    sget-object v5, Lh1/f;->e:Lh1/f;

    .line 2734
    .line 2735
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 2736
    .line 2737
    .line 2738
    sget-object v5, Lh1/f;->i:Lh1/f;

    .line 2739
    .line 2740
    invoke-virtual {v15, v5}, Lh1/g;->a(Lh1/f;)V

    .line 2741
    .line 2742
    .line 2743
    :cond_96
    invoke-static {v3}, Lx0/x;->q(LE0/h;)Z

    .line 2744
    .line 2745
    .line 2746
    move-result v3

    .line 2747
    if-eqz v3, :cond_97

    .line 2748
    .line 2749
    sget-object v3, Lh1/f;->f:Lh1/f;

    .line 2750
    .line 2751
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2752
    .line 2753
    .line 2754
    sget-object v3, Lh1/f;->g:Lh1/f;

    .line 2755
    .line 2756
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2757
    .line 2758
    .line 2759
    :cond_97
    const/16 v3, 0x1d

    .line 2760
    .line 2761
    if-lt v2, v3, :cond_98

    .line 2762
    .line 2763
    invoke-static {v0, v15}, Lx0/E;->c(LE0/n;Lh1/g;)V

    .line 2764
    .line 2765
    .line 2766
    :cond_98
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2767
    .line 2768
    .line 2769
    move-result-object v3

    .line 2770
    sget-object v5, LE0/r;->d:LE0/u;

    .line 2771
    .line 2772
    invoke-static {v3, v5}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2773
    .line 2774
    .line 2775
    move-result-object v3

    .line 2776
    check-cast v3, Ljava/lang/CharSequence;

    .line 2777
    .line 2778
    const/16 v5, 0x1c

    .line 2779
    .line 2780
    if-lt v2, v5, :cond_99

    .line 2781
    .line 2782
    invoke-static {v10, v3}, LA1/g0;->w(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 2783
    .line 2784
    .line 2785
    goto :goto_52

    .line 2786
    :cond_99
    invoke-virtual {v10}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 2787
    .line 2788
    .line 2789
    move-result-object v2

    .line 2790
    const-string v5, "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"

    .line 2791
    .line 2792
    invoke-virtual {v2, v5, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 2793
    .line 2794
    .line 2795
    :goto_52
    invoke-static {v0}, Lx0/E;->a(LE0/n;)Z

    .line 2796
    .line 2797
    .line 2798
    move-result v2

    .line 2799
    if-eqz v2, :cond_a6

    .line 2800
    .line 2801
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2802
    .line 2803
    .line 2804
    move-result-object v2

    .line 2805
    sget-object v3, LE0/j;->s:LE0/u;

    .line 2806
    .line 2807
    invoke-static {v2, v3}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2808
    .line 2809
    .line 2810
    move-result-object v2

    .line 2811
    check-cast v2, LE0/a;

    .line 2812
    .line 2813
    if-eqz v2, :cond_9a

    .line 2814
    .line 2815
    new-instance v3, Lh1/f;

    .line 2816
    .line 2817
    const/high16 v5, 0x40000

    .line 2818
    .line 2819
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 2820
    .line 2821
    invoke-direct {v3, v5, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 2822
    .line 2823
    .line 2824
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2825
    .line 2826
    .line 2827
    :cond_9a
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2828
    .line 2829
    .line 2830
    move-result-object v2

    .line 2831
    sget-object v3, LE0/j;->t:LE0/u;

    .line 2832
    .line 2833
    invoke-static {v2, v3}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2834
    .line 2835
    .line 2836
    move-result-object v2

    .line 2837
    check-cast v2, LE0/a;

    .line 2838
    .line 2839
    if-eqz v2, :cond_9b

    .line 2840
    .line 2841
    new-instance v3, Lh1/f;

    .line 2842
    .line 2843
    const/high16 v5, 0x80000

    .line 2844
    .line 2845
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 2846
    .line 2847
    invoke-direct {v3, v5, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 2848
    .line 2849
    .line 2850
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2851
    .line 2852
    .line 2853
    :cond_9b
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2854
    .line 2855
    .line 2856
    move-result-object v2

    .line 2857
    sget-object v3, LE0/j;->u:LE0/u;

    .line 2858
    .line 2859
    invoke-static {v2, v3}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 2860
    .line 2861
    .line 2862
    move-result-object v2

    .line 2863
    check-cast v2, LE0/a;

    .line 2864
    .line 2865
    if-eqz v2, :cond_9c

    .line 2866
    .line 2867
    new-instance v3, Lh1/f;

    .line 2868
    .line 2869
    const/high16 v5, 0x100000

    .line 2870
    .line 2871
    iget-object v2, v2, LE0/a;->a:Ljava/lang/String;

    .line 2872
    .line 2873
    invoke-direct {v3, v5, v2}, Lh1/f;-><init>(ILjava/lang/String;)V

    .line 2874
    .line 2875
    .line 2876
    invoke-virtual {v15, v3}, Lh1/g;->a(Lh1/f;)V

    .line 2877
    .line 2878
    .line 2879
    :cond_9c
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2880
    .line 2881
    .line 2882
    move-result-object v2

    .line 2883
    sget-object v3, LE0/j;->w:LE0/u;

    .line 2884
    .line 2885
    iget-object v2, v2, LE0/k;->d:Li/E;

    .line 2886
    .line 2887
    invoke-virtual {v2, v3}, Li/E;->c(Ljava/lang/Object;)Z

    .line 2888
    .line 2889
    .line 2890
    move-result v2

    .line 2891
    if-eqz v2, :cond_a6

    .line 2892
    .line 2893
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 2894
    .line 2895
    .line 2896
    move-result-object v2

    .line 2897
    invoke-virtual {v2, v3}, LE0/k;->c(LE0/u;)Ljava/lang/Object;

    .line 2898
    .line 2899
    .line 2900
    move-result-object v2

    .line 2901
    check-cast v2, Ljava/util/List;

    .line 2902
    .line 2903
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 2904
    .line 2905
    .line 2906
    move-result v3

    .line 2907
    sget-object v5, Lx0/x;->R:Li/w;

    .line 2908
    .line 2909
    iget v6, v5, Li/w;->b:I

    .line 2910
    .line 2911
    if-ge v3, v6, :cond_a5

    .line 2912
    .line 2913
    new-instance v3, Li/N;

    .line 2914
    .line 2915
    invoke-direct {v3}, Li/N;-><init>()V

    .line 2916
    .line 2917
    .line 2918
    invoke-static {}, Li/I;->a()Li/C;

    .line 2919
    .line 2920
    .line 2921
    move-result-object v6

    .line 2922
    move-object/from16 v7, v22

    .line 2923
    .line 2924
    iget-object v9, v7, Li/N;->d:[I

    .line 2925
    .line 2926
    iget v12, v7, Li/N;->f:I

    .line 2927
    .line 2928
    invoke-static {v9, v12, v4}, Lj/a;->a([III)I

    .line 2929
    .line 2930
    .line 2931
    move-result v9

    .line 2932
    if-ltz v9, :cond_9d

    .line 2933
    .line 2934
    const/4 v9, 0x1

    .line 2935
    goto :goto_53

    .line 2936
    :cond_9d
    const/4 v9, 0x0

    .line 2937
    :goto_53
    if-eqz v9, :cond_a3

    .line 2938
    .line 2939
    invoke-virtual {v7, v4}, Li/N;->b(I)Ljava/lang/Object;

    .line 2940
    .line 2941
    .line 2942
    move-result-object v9

    .line 2943
    check-cast v9, Li/C;

    .line 2944
    .line 2945
    new-array v11, v11, [I

    .line 2946
    .line 2947
    iget-object v12, v5, Li/w;->a:[I

    .line 2948
    .line 2949
    iget v5, v5, Li/w;->b:I

    .line 2950
    .line 2951
    move-object v14, v11

    .line 2952
    const/4 v11, 0x0

    .line 2953
    const/4 v13, 0x0

    .line 2954
    :goto_54
    if-ge v11, v5, :cond_9f

    .line 2955
    .line 2956
    aget v17, v12, v11

    .line 2957
    .line 2958
    move/from16 v18, v5

    .line 2959
    .line 2960
    add-int/lit8 v5, v13, 0x1

    .line 2961
    .line 2962
    move-object/from16 v20, v9

    .line 2963
    .line 2964
    array-length v9, v14

    .line 2965
    if-ge v9, v5, :cond_9e

    .line 2966
    .line 2967
    array-length v9, v14

    .line 2968
    const/16 v21, 0x3

    .line 2969
    .line 2970
    mul-int/lit8 v9, v9, 0x3

    .line 2971
    .line 2972
    const/16 v19, 0x2

    .line 2973
    .line 2974
    div-int/lit8 v9, v9, 0x2

    .line 2975
    .line 2976
    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    .line 2977
    .line 2978
    .line 2979
    move-result v9

    .line 2980
    invoke-static {v14, v9}, Ljava/util/Arrays;->copyOf([II)[I

    .line 2981
    .line 2982
    .line 2983
    move-result-object v9

    .line 2984
    const-string v14, "copyOf(...)"

    .line 2985
    .line 2986
    invoke-static {v9, v14}, LV1/i;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2987
    .line 2988
    .line 2989
    move-object v14, v9

    .line 2990
    goto :goto_55

    .line 2991
    :cond_9e
    const/16 v19, 0x2

    .line 2992
    .line 2993
    const/16 v21, 0x3

    .line 2994
    .line 2995
    :goto_55
    aput v17, v14, v13

    .line 2996
    .line 2997
    add-int/lit8 v11, v11, 0x1

    .line 2998
    .line 2999
    move v13, v5

    .line 3000
    move/from16 v5, v18

    .line 3001
    .line 3002
    move-object/from16 v9, v20

    .line 3003
    .line 3004
    goto :goto_54

    .line 3005
    :cond_9f
    move-object/from16 v20, v9

    .line 3006
    .line 3007
    new-instance v5, Ljava/util/ArrayList;

    .line 3008
    .line 3009
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 3010
    .line 3011
    .line 3012
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 3013
    .line 3014
    .line 3015
    move-result v9

    .line 3016
    if-gtz v9, :cond_a2

    .line 3017
    .line 3018
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 3019
    .line 3020
    .line 3021
    move-result v2

    .line 3022
    if-gtz v2, :cond_a0

    .line 3023
    .line 3024
    goto :goto_56

    .line 3025
    :cond_a0
    const/4 v9, 0x0

    .line 3026
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 3027
    .line 3028
    .line 3029
    move-result-object v0

    .line 3030
    invoke-static {v0}, LM0/m;->l(Ljava/lang/Object;)V

    .line 3031
    .line 3032
    .line 3033
    if-lez v13, :cond_a1

    .line 3034
    .line 3035
    aget v0, v14, v9

    .line 3036
    .line 3037
    throw v16

    .line 3038
    :cond_a1
    const-string v0, "Index must be between 0 and size"

    .line 3039
    .line 3040
    invoke-static {v0}, Lj/a;->d(Ljava/lang/String;)V

    .line 3041
    .line 3042
    .line 3043
    throw v16

    .line 3044
    :cond_a2
    const/4 v9, 0x0

    .line 3045
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 3046
    .line 3047
    .line 3048
    move-result-object v0

    .line 3049
    invoke-static {v0}, LM0/m;->l(Ljava/lang/Object;)V

    .line 3050
    .line 3051
    .line 3052
    invoke-static/range {v20 .. v20}, LV1/i;->b(Ljava/lang/Object;)V

    .line 3053
    .line 3054
    .line 3055
    throw v16

    .line 3056
    :cond_a3
    const/4 v9, 0x0

    .line 3057
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 3058
    .line 3059
    .line 3060
    move-result v11

    .line 3061
    if-gtz v11, :cond_a4

    .line 3062
    .line 3063
    :goto_56
    iget-object v2, v8, Lx0/x;->v:Li/N;

    .line 3064
    .line 3065
    invoke-virtual {v2, v4, v3}, Li/N;->c(ILjava/lang/Object;)V

    .line 3066
    .line 3067
    .line 3068
    invoke-virtual {v7, v4, v6}, Li/N;->c(ILjava/lang/Object;)V

    .line 3069
    .line 3070
    .line 3071
    goto :goto_57

    .line 3072
    :cond_a4
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 3073
    .line 3074
    .line 3075
    move-result-object v0

    .line 3076
    invoke-static {v0}, LM0/m;->l(Ljava/lang/Object;)V

    .line 3077
    .line 3078
    .line 3079
    invoke-virtual {v5, v9}, Li/w;->b(I)I

    .line 3080
    .line 3081
    .line 3082
    throw v16

    .line 3083
    :cond_a5
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 3084
    .line 3085
    new-instance v1, Ljava/lang/StringBuilder;

    .line 3086
    .line 3087
    const-string v2, "Can\'t have more than "

    .line 3088
    .line 3089
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3090
    .line 3091
    .line 3092
    iget v2, v5, Li/w;->b:I

    .line 3093
    .line 3094
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 3095
    .line 3096
    .line 3097
    const-string v2, " custom actions for one widget"

    .line 3098
    .line 3099
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3100
    .line 3101
    .line 3102
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3103
    .line 3104
    .line 3105
    move-result-object v1

    .line 3106
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 3107
    .line 3108
    .line 3109
    throw v0

    .line 3110
    :cond_a6
    :goto_57
    invoke-static {v0, v1}, Lx0/E;->b(LE0/n;Landroid/content/res/Resources;)Z

    .line 3111
    .line 3112
    .line 3113
    move-result v1

    .line 3114
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3115
    .line 3116
    const/16 v5, 0x1c

    .line 3117
    .line 3118
    if-lt v2, v5, :cond_a7

    .line 3119
    .line 3120
    invoke-static {v10, v1}, LA1/g0;->x(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 3121
    .line 3122
    .line 3123
    goto :goto_58

    .line 3124
    :cond_a7
    const/4 v9, 0x1

    .line 3125
    invoke-virtual {v15, v9, v1}, Lh1/g;->f(IZ)V

    .line 3126
    .line 3127
    .line 3128
    :goto_58
    iget-object v1, v8, Lx0/x;->F:Li/v;

    .line 3129
    .line 3130
    invoke-virtual {v1, v4}, Li/v;->d(I)I

    .line 3131
    .line 3132
    .line 3133
    move-result v1

    .line 3134
    const/4 v5, -0x1

    .line 3135
    if-eq v1, v5, :cond_a8

    .line 3136
    .line 3137
    invoke-virtual/range {v29 .. v29}, Lx0/s;->getAndroidViewsHandler$ui()Lx0/W;

    .line 3138
    .line 3139
    .line 3140
    move-result-object v2

    .line 3141
    invoke-static {v2, v1}, Lx0/E;->p(Lx0/W;I)V

    .line 3142
    .line 3143
    .line 3144
    move-object/from16 v2, v29

    .line 3145
    .line 3146
    invoke-virtual {v15, v2, v1}, Lh1/g;->h(Landroid/view/View;I)V

    .line 3147
    .line 3148
    .line 3149
    iget-object v1, v8, Lx0/x;->H:Ljava/lang/String;

    .line 3150
    .line 3151
    move-object/from16 v3, v16

    .line 3152
    .line 3153
    invoke-virtual {v8, v4, v15, v1, v3}, Lx0/x;->b(ILh1/g;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 3154
    .line 3155
    .line 3156
    goto :goto_59

    .line 3157
    :cond_a8
    move-object/from16 v2, v29

    .line 3158
    .line 3159
    :goto_59
    iget-object v1, v8, Lx0/x;->G:Li/v;

    .line 3160
    .line 3161
    invoke-virtual {v1, v4}, Li/v;->d(I)I

    .line 3162
    .line 3163
    .line 3164
    move-result v1

    .line 3165
    if-eq v1, v5, :cond_a9

    .line 3166
    .line 3167
    invoke-virtual {v2}, Lx0/s;->getAndroidViewsHandler$ui()Lx0/W;

    .line 3168
    .line 3169
    .line 3170
    move-result-object v2

    .line 3171
    invoke-static {v2, v1}, Lx0/E;->p(Lx0/W;I)V

    .line 3172
    .line 3173
    .line 3174
    :cond_a9
    invoke-virtual {v0}, LE0/n;->m()LE0/k;

    .line 3175
    .line 3176
    .line 3177
    move-result-object v0

    .line 3178
    sget-object v1, LE0/s;->b:LE0/u;

    .line 3179
    .line 3180
    invoke-static {v0, v1}, LE0/q;->d(LE0/k;LE0/u;)Ljava/lang/Object;

    .line 3181
    .line 3182
    .line 3183
    move-result-object v0

    .line 3184
    check-cast v0, Ljava/lang/String;

    .line 3185
    .line 3186
    if-eqz v0, :cond_aa

    .line 3187
    .line 3188
    invoke-virtual {v15, v0}, Lh1/g;->g(Ljava/lang/String;)V

    .line 3189
    .line 3190
    .line 3191
    :cond_aa
    :goto_5a
    iget-boolean v0, v8, Lx0/x;->s:Z

    .line 3192
    .line 3193
    if-eqz v0, :cond_ac

    .line 3194
    .line 3195
    iget v0, v8, Lx0/x;->o:I

    .line 3196
    .line 3197
    if-ne v4, v0, :cond_ab

    .line 3198
    .line 3199
    iput-object v15, v8, Lx0/x;->q:Lh1/g;

    .line 3200
    .line 3201
    :cond_ab
    iget v0, v8, Lx0/x;->p:I

    .line 3202
    .line 3203
    if-ne v4, v0, :cond_ac

    .line 3204
    .line 3205
    iput-object v15, v8, Lx0/x;->r:Lh1/g;

    .line 3206
    .line 3207
    :cond_ac
    return-object v15

    .line 3208
    :cond_ad
    move v4, v0

    .line 3209
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3210
    .line 3211
    const-string v1, "semanticsNode "

    .line 3212
    .line 3213
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3214
    .line 3215
    .line 3216
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 3217
    .line 3218
    .line 3219
    const-string v1, " has null parent"

    .line 3220
    .line 3221
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3222
    .line 3223
    .line 3224
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3225
    .line 3226
    .line 3227
    move-result-object v0

    .line 3228
    invoke-static {v0}, Lt0/a;->c(Ljava/lang/String;)Ljava/lang/Void;

    .line 3229
    .line 3230
    .line 3231
    new-instance v0, LC0/e;

    .line 3232
    .line 3233
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 3234
    .line 3235
    .line 3236
    throw v0
.end method

.method public q()Landroid/view/inputmethod/InputMethodManager;
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, LJ1/d;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 8
    .line 9
    return-object v0
.end method

.method public r()Lu0/z;
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LI/m0;

    .line 4
    .line 5
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lu0/z;

    .line 10
    .line 11
    return-object v0
.end method

.method public s()LY1/d;
    .locals 2

    .line 1
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/regex/Matcher;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->start()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->end()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-static {v1, v0}, LT0/l;->S(II)LY1/d;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public t()Lu1/d;
    .locals 6

    .line 1
    const-string v0, "androidx.lifecycle.internal.SavedStateHandlesProvider"

    .line 2
    .line 3
    iget-object v1, p0, LF/r;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lw1/a;

    .line 6
    .line 7
    iget-object v2, v1, Lw1/a;->c:Lt1/d;

    .line 8
    .line 9
    monitor-enter v2

    .line 10
    :try_start_0
    iget-object v1, v1, Lw1/a;->d:Ljava/util/LinkedHashMap;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    const/4 v4, 0x0

    .line 25
    if-eqz v3, :cond_2

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Ljava/util/Map$Entry;

    .line 32
    .line 33
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v5

    .line 37
    check-cast v5, Ljava/lang/String;

    .line 38
    .line 39
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, Lu1/d;

    .line 44
    .line 45
    invoke-static {v5, v0}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    if-eqz v5, :cond_1

    .line 50
    .line 51
    move-object v4, v3

    .line 52
    :cond_1
    if-eqz v4, :cond_0

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :catchall_0
    move-exception v0

    .line 56
    goto :goto_1

    .line 57
    :cond_2
    :goto_0
    monitor-exit v2

    .line 58
    return-object v4

    .line 59
    :goto_1
    monitor-exit v2

    .line 60
    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    iget v0, p0, LF/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "AnimationResult(endReason="

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Ll/f;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, ", endState="

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, LF/r;->e:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, Ll/i;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const/16 v1, 0x29

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0

    .line 47
    :pswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 48
    .line 49
    const-string v1, "Bounds{lower="

    .line 50
    .line 51
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    iget-object v1, p0, LF/r;->e:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v1, Lb1/b;

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v1, " upper="

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v1, Lb1/b;

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v1, "}"

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    return-object v0

    .line 83
    :pswitch_data_0
    .packed-switch 0xc
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public u(Ljava/lang/String;Lu1/d;)V
    .locals 3

    .line 1
    const-string v0, "provider"

    .line 2
    .line 3
    invoke-static {p2, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw1/a;

    .line 9
    .line 10
    iget-object v1, v0, Lw1/a;->c:Lt1/d;

    .line 11
    .line 12
    monitor-enter v1

    .line 13
    :try_start_0
    iget-object v2, v0, Lw1/a;->d:Ljava/util/LinkedHashMap;

    .line 14
    .line 15
    invoke-interface {v2, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-nez v2, :cond_0

    .line 20
    .line 21
    iget-object v0, v0, Lw1/a;->d:Ljava/util/LinkedHashMap;

    .line 22
    .line 23
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    .line 25
    .line 26
    monitor-exit v1

    .line 27
    return-void

    .line 28
    :catchall_0
    move-exception p1

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    :try_start_1
    const-string p1, "SavedStateProvider with the given key is already registered"

    .line 31
    .line 32
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 33
    .line 34
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 38
    :goto_0
    monitor-exit v1

    .line 39
    throw p1
.end method

.method public v()V
    .locals 2

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ln0/b;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v0, p0, LF/r;->e:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Ln/z;

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    invoke-virtual {v0, v1}, Ln/z;->Y0(Z)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public w()V
    .locals 5

    .line 1
    const-class v0, Landroidx/lifecycle/l;

    .line 2
    .line 3
    iget-object v1, p0, LF/r;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lw1/a;

    .line 6
    .line 7
    iget-boolean v1, v1, Lw1/a;->h:Z

    .line 8
    .line 9
    if-eqz v1, :cond_2

    .line 10
    .line 11
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lu1/a;

    .line 14
    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    new-instance v1, Lu1/a;

    .line 18
    .line 19
    invoke-direct {v1, p0}, Lu1/a;-><init>(LF/r;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    iput-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    :try_start_0
    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, LF/r;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v1, Lu1/a;

    .line 31
    .line 32
    if-eqz v1, :cond_1

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iget-object v1, v1, Lu1/a;->a:Ljava/util/LinkedHashSet;

    .line 39
    .line 40
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    :cond_1
    return-void

    .line 44
    :catch_0
    move-exception v1

    .line 45
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 46
    .line 47
    new-instance v3, Ljava/lang/StringBuilder;

    .line 48
    .line 49
    const-string v4, "Class "

    .line 50
    .line 51
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v0, " must have default constructor in order to be automatically recreated"

    .line 62
    .line 63
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-direct {v2, v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    throw v2

    .line 74
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 75
    .line 76
    const-string v1, "Can not perform this action after onSaveInstanceState"

    .line 77
    .line 78
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v0
.end method

.method public x(LI/a0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LF/r;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Li/E;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-eqz p1, :cond_2

    .line 10
    .line 11
    instance-of v0, p1, Li/D;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    check-cast p1, Li/D;

    .line 16
    .line 17
    iget-object v0, p1, Li/D;->a:[Ljava/lang/Object;

    .line 18
    .line 19
    iget p1, p1, Li/D;->b:I

    .line 20
    .line 21
    if-gtz p1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 p1, 0x0

    .line 25
    aget-object p1, v0, p1

    .line 26
    .line 27
    const-string v0, "null cannot be cast to non-null type V of androidx.compose.runtime.collection.MultiValueMap"

    .line 28
    .line 29
    invoke-static {p1, v0}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    new-instance p1, Ljava/lang/ClassCastException;

    .line 33
    .line 34
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 35
    .line 36
    .line 37
    throw p1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/ClassCastException;

    .line 39
    .line 40
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 41
    .line 42
    .line 43
    throw p1

    .line 44
    :cond_2
    :goto_0
    return-void
.end method
