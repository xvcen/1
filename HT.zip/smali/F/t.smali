.class public final LF/t;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LF/u;

.field public final synthetic j:LF/f;


# direct methods
.method public constructor <init>(LF/u;LF/f;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LF/t;->i:LF/u;

    .line 2
    .line 3
    iput-object p2, p0, LF/t;->j:LF/f;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LF/t;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LF/t;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LF/t;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    sget-object p1, LO1/a;->d:LO1/a;

    .line 17
    .line 18
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance p2, LF/t;

    .line 2
    .line 3
    iget-object v0, p0, LF/t;->i:LF/u;

    .line 4
    .line 5
    iget-object v1, p0, LF/t;->j:LF/f;

    .line 6
    .line 7
    invoke-direct {p2, v0, v1, p1}, LF/t;-><init>(LF/u;LF/f;LN1/c;)V

    .line 8
    .line 9
    .line 10
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LF/t;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-eq v0, v1, :cond_0

    .line 7
    .line 8
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 9
    .line 10
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 11
    .line 12
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw p1

    .line 16
    :cond_0
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    new-instance p1, LC0/e;

    .line 20
    .line 21
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 22
    .line 23
    .line 24
    throw p1

    .line 25
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iput v1, p0, LF/t;->h:I

    .line 29
    .line 30
    iget-object p1, p0, LF/t;->i:LF/u;

    .line 31
    .line 32
    iget-object v0, p0, LF/t;->j:LF/f;

    .line 33
    .line 34
    invoke-static {p1, v0, p0}, Lx0/C0;->a(LF/u;LF/f;LP1/c;)V

    .line 35
    .line 36
    .line 37
    sget-object p1, LO1/a;->d:LO1/a;

    .line 38
    .line 39
    return-object p1
.end method
