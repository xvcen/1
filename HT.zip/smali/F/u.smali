.class public final LF/u;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/g;
.implements Lw0/m;
.implements Lw0/h;


# instance fields
.field public r:LF/g;

.field public s:Lw/S;

.field public t:LH/m0;

.field public final u:LI/m0;


# direct methods
.method public constructor <init>(LF/g;Lw/S;LH/m0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LW/p;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF/u;->r:LF/g;

    .line 5
    .line 6
    iput-object p2, p0, LF/u;->s:Lw/S;

    .line 7
    .line 8
    iput-object p3, p0, LF/u;->t:LH/m0;

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-static {p1}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iput-object p1, p0, LF/u;->u:LI/m0;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final M0()V
    .locals 2

    .line 1
    iget-object v0, p0, LF/u;->r:LF/g;

    .line 2
    .line 3
    iget-object v1, v0, LF/g;->a:LF/u;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const-string v1, "Expected textInputModifierNode to be null"

    .line 9
    .line 10
    invoke-static {v1}, Lr/b;->c(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    :goto_0
    iput-object p0, v0, LF/g;->a:LF/u;

    .line 14
    .line 15
    return-void
.end method

.method public final N0()V
    .locals 1

    .line 1
    iget-object v0, p0, LF/u;->r:LF/g;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, LF/g;->k(LF/u;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final O(Lw0/b0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LF/u;->u:LI/m0;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
