.class public abstract LF/y;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LF/x;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, LF/x;->k:LF/x;

    .line 2
    .line 3
    sput-object v0, LF/y;->a:LF/x;

    .line 4
    .line 5
    return-void
.end method
