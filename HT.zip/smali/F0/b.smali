.class public final LF0/b;
.super LV1/j;
.source "SourceFile"

# interfaces
.implements LU1/a;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LF0/b;->e:I

    iput-object p2, p0, LF0/b;->f:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, LV1/j;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LF0/b;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lx0/v0;

    .line 9
    .line 10
    iget-object v0, v0, Lx0/v0;->a:Lq0/w;

    .line 11
    .line 12
    iget-object v0, v0, Lq0/w;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, LR/c;

    .line 15
    .line 16
    iget-boolean v1, v0, LR/c;->b:Z

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    iget-boolean v1, v0, LR/c;->c:Z

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    const-string v1, "ManagedValuesStore tried to enter composition twice. Did you attempt to install the same store multiple times or into two compositions?"

    .line 26
    .line 27
    invoke-static {v1}, LS/a;->a(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :cond_1
    invoke-virtual {v0}, LR/c;->a()V

    .line 31
    .line 32
    .line 33
    const/4 v1, 0x1

    .line 34
    iput-boolean v1, v0, LR/c;->c:Z

    .line 35
    .line 36
    :goto_0
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_0
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 40
    .line 41
    return-object v0

    .line 42
    :pswitch_1
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, Lx0/M;

    .line 45
    .line 46
    iget-object v0, v0, Lx0/M;->f:Lc2/s;

    .line 47
    .line 48
    const/4 v1, 0x0

    .line 49
    invoke-static {v0, v1}, Lc2/u;->c(Lc2/s;LW/r;)V

    .line 50
    .line 51
    .line 52
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 53
    .line 54
    return-object v0

    .line 55
    :pswitch_2
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Lw0/E;

    .line 58
    .line 59
    iget-object v0, v0, Lw0/E;->J:Lw0/H;

    .line 60
    .line 61
    iget-object v1, v0, Lw0/H;->o:Lw0/U;

    .line 62
    .line 63
    const/4 v2, 0x1

    .line 64
    iput-boolean v2, v1, Lw0/U;->B:Z

    .line 65
    .line 66
    iget-object v0, v0, Lw0/H;->p:Lw0/P;

    .line 67
    .line 68
    if-eqz v0, :cond_2

    .line 69
    .line 70
    iput-boolean v2, v0, Lw0/P;->v:Z

    .line 71
    .line 72
    :cond_2
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 73
    .line 74
    return-object v0

    .line 75
    :pswitch_3
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v0, Lp0/e;

    .line 78
    .line 79
    invoke-virtual {v0}, Lp0/e;->U0()Lc2/s;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    return-object v0

    .line 84
    :pswitch_4
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v0, LX/a;

    .line 87
    .line 88
    iget-object v0, v0, LX/a;->g:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, Lc2/s;

    .line 91
    .line 92
    return-object v0

    .line 93
    :pswitch_5
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v0, Ll/U;

    .line 96
    .line 97
    invoke-virtual {v0}, Ll/U;->c()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    sget-object v2, Lk/B;->f:Lk/B;

    .line 102
    .line 103
    if-ne v1, v2, :cond_3

    .line 104
    .line 105
    iget-object v0, v0, Ll/U;->d:LI/m0;

    .line 106
    .line 107
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    if-ne v0, v2, :cond_3

    .line 112
    .line 113
    const/4 v0, 0x1

    .line 114
    goto :goto_1

    .line 115
    :cond_3
    const/4 v0, 0x0

    .line 116
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    return-object v0

    .line 121
    :pswitch_6
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast v0, Lj0/H;

    .line 124
    .line 125
    iget-object v0, v0, Lj0/H;->h:LI/m0;

    .line 126
    .line 127
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 128
    .line 129
    invoke-virtual {v0, v1}, LI/m0;->setValue(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    return-object v1

    .line 133
    :pswitch_7
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v0, Lb0/y;

    .line 136
    .line 137
    invoke-virtual {v0}, Lb0/y;->W0()Lb0/s;

    .line 138
    .line 139
    .line 140
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 141
    .line 142
    return-object v0

    .line 143
    :pswitch_8
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v0, LW0/v;

    .line 146
    .line 147
    invoke-static {v0}, LW0/v;->g(LW0/v;)Lu0/r;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    const/4 v2, 0x0

    .line 152
    if-eqz v1, :cond_4

    .line 153
    .line 154
    invoke-interface {v1}, Lu0/r;->T()Z

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_4

    .line 159
    .line 160
    goto :goto_2

    .line 161
    :cond_4
    move-object v1, v2

    .line 162
    :goto_2
    if-eqz v1, :cond_5

    .line 163
    .line 164
    invoke-virtual {v0}, LW0/v;->getPopupContentSize-bOM6tXw()LT0/n;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    if-eqz v0, :cond_5

    .line 169
    .line 170
    const/4 v0, 0x1

    .line 171
    goto :goto_3

    .line 172
    :cond_5
    const/4 v0, 0x0

    .line 173
    :goto_3
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    return-object v0

    .line 178
    :pswitch_9
    new-instance v0, Landroid/view/inputmethod/BaseInputConnection;

    .line 179
    .line 180
    iget-object v1, p0, LF0/b;->f:Ljava/lang/Object;

    .line 181
    .line 182
    check-cast v1, LM0/A;

    .line 183
    .line 184
    iget-object v1, v1, LM0/A;->a:Landroid/view/View;

    .line 185
    .line 186
    const/4 v2, 0x0

    .line 187
    invoke-direct {v0, v1, v2}, Landroid/view/inputmethod/BaseInputConnection;-><init>(Landroid/view/View;Z)V

    .line 188
    .line 189
    .line 190
    return-object v0

    .line 191
    :pswitch_a
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v0, LI/e0;

    .line 194
    .line 195
    iget-object v0, v0, LI/e0;->d:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v0, Landroid/view/View;

    .line 198
    .line 199
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    const-string v1, "input_method"

    .line 204
    .line 205
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    const-string v1, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager"

    .line 210
    .line 211
    invoke-static {v0, v1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 215
    .line 216
    return-object v0

    .line 217
    :pswitch_b
    iget-object v0, p0, LF0/b;->f:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast v0, LF0/c;

    .line 220
    .line 221
    const/4 v1, 0x0

    .line 222
    iput-object v1, v0, LF0/c;->g:LB/c;

    .line 223
    .line 224
    const-string v1, "OnPositionedDispatch"

    .line 225
    .line 226
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    :try_start_0
    invoke-virtual {v0}, LF0/c;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 230
    .line 231
    .line 232
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 233
    .line 234
    .line 235
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 236
    .line 237
    return-object v0

    .line 238
    :catchall_0
    move-exception v0

    .line 239
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 240
    .line 241
    .line 242
    throw v0

    .line 243
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
