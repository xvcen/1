.class public final LF1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:LF1/a;

.field public static final f:LF1/a;


# instance fields
.field public final a:F

.field public final b:F

.field public final c:F

.field public final d:LF1/h;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LF1/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/16 v2, 0xf

    .line 5
    .line 6
    invoke-direct {v0, v1, v2}, LF1/a;-><init>(LF1/h;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LF1/a;->e:LF1/a;

    .line 10
    .line 11
    new-instance v0, LF1/a;

    .line 12
    .line 13
    sget-object v1, LF1/h;->a:LF1/e;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    sget-object v1, LF1/e;->c:LF1/d;

    .line 19
    .line 20
    const/4 v2, 0x7

    .line 21
    invoke-direct {v0, v1, v2}, LF1/a;-><init>(LF1/h;I)V

    .line 22
    .line 23
    .line 24
    sput-object v0, LF1/a;->f:LF1/a;

    .line 25
    .line 26
    new-instance v0, LF1/a;

    .line 27
    .line 28
    sget-object v1, LF1/e;->d:LF1/g;

    .line 29
    .line 30
    invoke-direct {v0, v1, v2}, LF1/a;-><init>(LF1/h;I)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public constructor <init>(FFFLF1/h;)V
    .locals 1

    .line 1
    const-string v0, "style"

    invoke-static {p4, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput p1, p0, LF1/a;->a:F

    .line 4
    iput p2, p0, LF1/a;->b:F

    .line 5
    iput p3, p0, LF1/a;->c:F

    .line 6
    iput-object p4, p0, LF1/a;->d:LF1/h;

    return-void
.end method

.method public constructor <init>(LF1/h;I)V
    .locals 2

    and-int/lit8 p2, p2, 0x8

    if-eqz p2, :cond_0

    .line 7
    sget-object p1, LF1/h;->a:LF1/e;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    sget-object p1, LF1/e;->b:LF1/f;

    :cond_0
    const/high16 p2, 0x3f000000    # 0.5f

    const/high16 v0, 0x3e800000    # 0.25f

    const/high16 v1, 0x3f800000    # 1.0f

    .line 9
    invoke-direct {p0, p2, v0, v1, p1}, LF1/a;-><init>(FFFLF1/h;)V

    return-void
.end method

.method public static a(LF1/a;FFFI)LF1/a;
    .locals 1

    .line 1
    and-int/lit8 v0, p4, 0x1

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget p1, p0, LF1/a;->a:F

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p4, p4, 0x2

    .line 8
    .line 9
    if-eqz p4, :cond_1

    .line 10
    .line 11
    iget p2, p0, LF1/a;->b:F

    .line 12
    .line 13
    :cond_1
    iget-object p4, p0, LF1/a;->d:LF1/h;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    const-string p0, "style"

    .line 19
    .line 20
    invoke-static {p4, p0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    new-instance p0, LF1/a;

    .line 24
    .line 25
    invoke-direct {p0, p1, p2, p3, p4}, LF1/a;-><init>(FFFLF1/h;)V

    .line 26
    .line 27
    .line 28
    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_1

    .line 4
    :cond_0
    instance-of v0, p1, LF1/a;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_1
    check-cast p1, LF1/a;

    .line 10
    .line 11
    iget v0, p0, LF1/a;->a:F

    .line 12
    .line 13
    iget v1, p1, LF1/a;->a:F

    .line 14
    .line 15
    invoke-static {v0, v1}, LT0/f;->b(FF)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_2

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    iget v0, p0, LF1/a;->b:F

    .line 23
    .line 24
    iget v1, p1, LF1/a;->b:F

    .line 25
    .line 26
    invoke-static {v0, v1}, LT0/f;->b(FF)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_3

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_3
    iget v0, p0, LF1/a;->c:F

    .line 34
    .line 35
    iget v1, p1, LF1/a;->c:F

    .line 36
    .line 37
    invoke-static {v0, v1}, Ljava/lang/Float;->compare(FF)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_4
    iget-object v0, p0, LF1/a;->d:LF1/h;

    .line 45
    .line 46
    iget-object p1, p1, LF1/a;->d:LF1/h;

    .line 47
    .line 48
    invoke-static {v0, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-nez p1, :cond_5

    .line 53
    .line 54
    :goto_0
    const/4 p1, 0x0

    .line 55
    return p1

    .line 56
    :cond_5
    :goto_1
    const/4 p1, 0x1

    .line 57
    return p1
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget v0, p0, LF1/a;->a:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, LF1/a;->b:F

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, LM0/m;->a(FII)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, LF1/a;->c:F

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, LM0/m;->a(FII)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v1, p0, LF1/a;->d:LF1/h;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    add-int/2addr v1, v0

    .line 29
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, LF1/a;->a:F

    .line 2
    .line 3
    invoke-static {v0}, LT0/f;->c(F)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget v1, p0, LF1/a;->b:F

    .line 8
    .line 9
    invoke-static {v1}, LT0/f;->c(F)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    new-instance v2, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v3, "Highlight(width="

    .line 16
    .line 17
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v0, ", blurRadius="

    .line 24
    .line 25
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v0, ", alpha="

    .line 32
    .line 33
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget v0, p0, LF1/a;->c:F

    .line 37
    .line 38
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string v0, ", style="

    .line 42
    .line 43
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, LF1/a;->d:LF1/h;

    .line 47
    .line 48
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string v0, ")"

    .line 52
    .line 53
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    return-object v0
.end method
