.class public final LF1/b;
.super Lw0/V;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;"
    }
.end annotation


# instance fields
.field public final a:LC1/l;

.field public final b:LU1/a;


# direct methods
.method public constructor <init>(LC1/l;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF1/b;->a:LC1/l;

    .line 5
    .line 6
    iput-object p2, p0, LF1/b;->b:LU1/a;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 3

    .line 1
    new-instance v0, LF1/c;

    .line 2
    .line 3
    iget-object v1, p0, LF1/b;->a:LC1/l;

    .line 4
    .line 5
    iget-object v2, p0, LF1/b;->b:LU1/a;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, LF1/c;-><init>(LC1/l;LU1/a;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 1

    .line 1
    check-cast p1, LF1/c;

    .line 2
    .line 3
    const-string v0, "node"

    .line 4
    .line 5
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LF1/b;->a:LC1/l;

    .line 9
    .line 10
    iput-object v0, p1, LF1/c;->r:LC1/l;

    .line 11
    .line 12
    iget-object v0, p0, LF1/b;->b:LU1/a;

    .line 13
    .line 14
    iput-object v0, p1, LF1/c;->s:LU1/a;

    .line 15
    .line 16
    invoke-static {p1}, Lw0/j;->j(Lw0/l;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, LF1/b;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, LF1/b;

    .line 12
    .line 13
    iget-object v1, p1, LF1/b;->a:LC1/l;

    .line 14
    .line 15
    iget-object v3, p0, LF1/b;->a:LC1/l;

    .line 16
    .line 17
    invoke-static {v3, v1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object v1, p0, LF1/b;->b:LU1/a;

    .line 25
    .line 26
    iget-object p1, p1, LF1/b;->b:LU1/a;

    .line 27
    .line 28
    invoke-static {v1, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-nez p1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    return v0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, LF1/b;->a:LC1/l;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, LF1/b;->b:LU1/a;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    return v1
.end method
