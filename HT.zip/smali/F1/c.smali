.class public final LF1/c;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/l;


# instance fields
.field public r:LC1/l;

.field public s:LU1/a;

.field public t:Lg0/c;

.field public final u:Ld0/h;

.field public v:Ld0/j;

.field public final w:LC1/j;


# direct methods
.method public constructor <init>(LC1/l;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LW/p;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF1/c;->r:LC1/l;

    .line 5
    .line 6
    iput-object p2, p0, LF1/c;->s:LU1/a;

    .line 7
    .line 8
    invoke-static {}, Ld0/D;->e()Ld0/h;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 p2, 0x1

    .line 13
    invoke-virtual {p1, p2}, Ld0/h;->l(I)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, LF1/c;->u:Ld0/h;

    .line 17
    .line 18
    new-instance p1, LC1/j;

    .line 19
    .line 20
    const/4 p2, 0x0

    .line 21
    invoke-direct {p1, p2}, LC1/j;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, LF1/c;->w:LC1/j;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final J0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final M0()V
    .locals 1

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ld0/A;->b()Lg0/c;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, LF1/c;->t:Lg0/c;

    .line 10
    .line 11
    return-void
.end method

.method public final N0()V
    .locals 3

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LF1/c;->t:Lg0/c;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-interface {v0, v1}, Ld0/A;->a(Lg0/c;)V

    .line 11
    .line 12
    .line 13
    iput-object v2, p0, LF1/c;->t:Lg0/c;

    .line 14
    .line 15
    :cond_0
    iput-object v2, p0, LF1/c;->v:Ld0/j;

    .line 16
    .line 17
    iget-object v0, p0, LF1/c;->w:LC1/j;

    .line 18
    .line 19
    iget-object v0, v0, LC1/j;->d:Ljava/util/LinkedHashMap;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final U(Lw0/G;)V
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget-object v2, v0, Lw0/G;->d:Lf0/b;

    .line 6
    .line 7
    iget-object v3, v1, LF1/c;->s:LU1/a;

    .line 8
    .line 9
    invoke-interface {v3}, LU1/a;->a()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    check-cast v3, LF1/a;

    .line 14
    .line 15
    if-eqz v3, :cond_8

    .line 16
    .line 17
    iget v4, v3, LF1/a;->a:F

    .line 18
    .line 19
    iget-object v5, v3, LF1/a;->d:LF1/h;

    .line 20
    .line 21
    const/4 v6, 0x0

    .line 22
    cmpg-float v7, v4, v6

    .line 23
    .line 24
    if-gtz v7, :cond_0

    .line 25
    .line 26
    goto/16 :goto_3

    .line 27
    .line 28
    :cond_0
    invoke-virtual {v0}, Lw0/G;->c()V

    .line 29
    .line 30
    .line 31
    iget-object v7, v1, LF1/c;->t:Lg0/c;

    .line 32
    .line 33
    if-eqz v7, :cond_7

    .line 34
    .line 35
    invoke-interface {v2}, Lf0/d;->a()J

    .line 36
    .line 37
    .line 38
    move-result-wide v8

    .line 39
    invoke-virtual {v0}, Lw0/G;->getLayoutDirection()LT0/o;

    .line 40
    .line 41
    .line 42
    move-result-object v10

    .line 43
    const/16 v11, 0x20

    .line 44
    .line 45
    shr-long v12, v8, v11

    .line 46
    .line 47
    long-to-int v12, v12

    .line 48
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 49
    .line 50
    .line 51
    move-result v12

    .line 52
    float-to-double v12, v12

    .line 53
    invoke-static {v12, v13}, Ljava/lang/Math;->ceil(D)D

    .line 54
    .line 55
    .line 56
    move-result-wide v12

    .line 57
    double-to-float v12, v12

    .line 58
    float-to-int v12, v12

    .line 59
    add-int/lit8 v12, v12, 0x2

    .line 60
    .line 61
    const-wide v15, 0xffffffffL

    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    and-long v13, v8, v15

    .line 67
    .line 68
    long-to-int v13, v13

    .line 69
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 70
    .line 71
    .line 72
    move-result v13

    .line 73
    float-to-double v13, v13

    .line 74
    invoke-static {v13, v14}, Ljava/lang/Math;->ceil(D)D

    .line 75
    .line 76
    .line 77
    move-result-wide v13

    .line 78
    double-to-float v13, v13

    .line 79
    float-to-int v13, v13

    .line 80
    add-int/lit8 v13, v13, 0x2

    .line 81
    .line 82
    move v14, v11

    .line 83
    int-to-long v11, v12

    .line 84
    shl-long/2addr v11, v14

    .line 85
    int-to-long v13, v13

    .line 86
    and-long/2addr v13, v15

    .line 87
    or-long/2addr v11, v13

    .line 88
    iget-object v13, v1, LF1/c;->r:LC1/l;

    .line 89
    .line 90
    iget-object v13, v13, LC1/l;->g:LC1/k;

    .line 91
    .line 92
    invoke-virtual {v13, v8, v9, v10, v0}, LC1/k;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    instance-of v9, v8, Ld0/L;

    .line 97
    .line 98
    if-eqz v9, :cond_1

    .line 99
    .line 100
    iget-object v9, v1, LF1/c;->v:Ld0/j;

    .line 101
    .line 102
    if-nez v9, :cond_2

    .line 103
    .line 104
    invoke-static {}, Ld0/l;->a()Ld0/j;

    .line 105
    .line 106
    .line 107
    move-result-object v9

    .line 108
    iput-object v9, v1, LF1/c;->v:Ld0/j;

    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_1
    const/4 v9, 0x0

    .line 112
    :cond_2
    :goto_0
    invoke-interface {v5}, LF1/h;->a()J

    .line 113
    .line 114
    .line 115
    move-result-wide v13

    .line 116
    iget-object v15, v1, LF1/c;->u:Ld0/h;

    .line 117
    .line 118
    invoke-virtual {v15, v13, v14}, Ld0/h;->e(J)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0, v4}, Lw0/G;->K(F)F

    .line 122
    .line 123
    .line 124
    move-result v4

    .line 125
    invoke-interface {v2}, Lf0/d;->a()J

    .line 126
    .line 127
    .line 128
    move-result-wide v13

    .line 129
    invoke-static {v13, v14}, Lc0/e;->b(J)F

    .line 130
    .line 131
    .line 132
    move-result v13

    .line 133
    const/high16 v14, 0x40000000    # 2.0f

    .line 134
    .line 135
    div-float/2addr v13, v14

    .line 136
    cmpl-float v16, v4, v13

    .line 137
    .line 138
    if-lez v16, :cond_3

    .line 139
    .line 140
    move v4, v13

    .line 141
    :cond_3
    move-wide/from16 v16, v11

    .line 142
    .line 143
    float-to-double v10, v4

    .line 144
    invoke-static {v10, v11}, Ljava/lang/Math;->ceil(D)D

    .line 145
    .line 146
    .line 147
    move-result-wide v10

    .line 148
    double-to-float v4, v10

    .line 149
    mul-float/2addr v4, v14

    .line 150
    invoke-virtual {v15, v4}, Ld0/h;->k(F)V

    .line 151
    .line 152
    .line 153
    iget v4, v3, LF1/a;->b:F

    .line 154
    .line 155
    invoke-virtual {v0, v4}, Lw0/G;->K(F)F

    .line 156
    .line 157
    .line 158
    move-result v4

    .line 159
    iget-object v10, v15, Ld0/h;->a:Landroid/graphics/Paint;

    .line 160
    .line 161
    cmpl-float v6, v4, v6

    .line 162
    .line 163
    if-lez v6, :cond_4

    .line 164
    .line 165
    new-instance v6, Landroid/graphics/BlurMaskFilter;

    .line 166
    .line 167
    sget-object v11, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    .line 168
    .line 169
    invoke-direct {v6, v4, v11}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    .line 170
    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_4
    const/4 v6, 0x0

    .line 174
    :goto_1
    invoke-virtual {v10, v6}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 175
    .line 176
    .line 177
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 178
    .line 179
    const/16 v6, 0x1f

    .line 180
    .line 181
    if-lt v4, v6, :cond_5

    .line 182
    .line 183
    iget-object v4, v1, LF1/c;->r:LC1/l;

    .line 184
    .line 185
    iget-object v4, v4, LC1/l;->g:LC1/k;

    .line 186
    .line 187
    iget-object v6, v1, LF1/c;->w:LC1/j;

    .line 188
    .line 189
    invoke-interface {v5, v0, v4, v6}, LF1/h;->h(Lw0/G;LC1/k;LC1/i;)Landroid/graphics/Shader;

    .line 190
    .line 191
    .line 192
    move-result-object v4

    .line 193
    invoke-virtual {v15, v4}, Ld0/h;->h(Landroid/graphics/Shader;)V

    .line 194
    .line 195
    .line 196
    :cond_5
    iget v3, v3, LF1/a;->c:F

    .line 197
    .line 198
    invoke-virtual {v7, v3}, Lg0/c;->g(F)V

    .line 199
    .line 200
    .line 201
    invoke-interface {v5}, LF1/h;->g()I

    .line 202
    .line 203
    .line 204
    move-result v3

    .line 205
    iget-object v4, v7, Lg0/c;->a:Lg0/e;

    .line 206
    .line 207
    invoke-interface {v4}, Lg0/e;->g()I

    .line 208
    .line 209
    .line 210
    move-result v5

    .line 211
    if-ne v5, v3, :cond_6

    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_6
    invoke-interface {v4, v3}, Lg0/e;->m(I)V

    .line 215
    .line 216
    .line 217
    :goto_2
    new-instance v3, LB/r;

    .line 218
    .line 219
    const/4 v4, 0x1

    .line 220
    invoke-direct {v3, v8, v9, v1, v4}, LB/r;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 221
    .line 222
    .line 223
    move-wide/from16 v4, v16

    .line 224
    .line 225
    invoke-virtual {v0, v7, v4, v5, v3}, Lw0/G;->M(Lg0/c;JLU1/c;)V

    .line 226
    .line 227
    .line 228
    iget-object v3, v2, Lf0/b;->e:LI/e0;

    .line 229
    .line 230
    iget-object v3, v3, LI/e0;->d:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v3, LA0/h;

    .line 233
    .line 234
    const/high16 v4, -0x40800000    # -1.0f

    .line 235
    .line 236
    invoke-virtual {v3, v4, v4}, LA0/h;->t(FF)V

    .line 237
    .line 238
    .line 239
    const/high16 v3, 0x3f800000    # 1.0f

    .line 240
    .line 241
    :try_start_0
    invoke-static {v0, v7}, LT0/g;->r(Lf0/d;Lg0/c;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 242
    .line 243
    .line 244
    iget-object v0, v2, Lf0/b;->e:LI/e0;

    .line 245
    .line 246
    iget-object v0, v0, LI/e0;->d:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v0, LA0/h;

    .line 249
    .line 250
    invoke-virtual {v0, v3, v3}, LA0/h;->t(FF)V

    .line 251
    .line 252
    .line 253
    return-void

    .line 254
    :catchall_0
    move-exception v0

    .line 255
    iget-object v2, v2, Lf0/b;->e:LI/e0;

    .line 256
    .line 257
    iget-object v2, v2, LI/e0;->d:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v2, LA0/h;

    .line 260
    .line 261
    invoke-virtual {v2, v3, v3}, LA0/h;->t(FF)V

    .line 262
    .line 263
    .line 264
    throw v0

    .line 265
    :cond_7
    return-void

    .line 266
    :cond_8
    :goto_3
    invoke-virtual {v0}, Lw0/G;->c()V

    .line 267
    .line 268
    .line 269
    return-void
.end method
