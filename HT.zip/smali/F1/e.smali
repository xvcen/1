.class public final LF1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:LF1/e;

.field public static final b:LF1/f;

.field public static final c:LF1/d;

.field public static final d:LF1/g;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LF1/e;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LF1/e;->a:LF1/e;

    .line 7
    .line 8
    new-instance v0, LF1/f;

    .line 9
    .line 10
    invoke-direct {v0}, LF1/f;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LF1/e;->b:LF1/f;

    .line 14
    .line 15
    new-instance v0, LF1/d;

    .line 16
    .line 17
    invoke-direct {v0}, LF1/d;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, LF1/e;->c:LF1/d;

    .line 21
    .line 22
    new-instance v0, LF1/g;

    .line 23
    .line 24
    invoke-direct {v0}, LF1/g;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v0, LF1/e;->d:LF1/g;

    .line 28
    .line 29
    return-void
.end method
