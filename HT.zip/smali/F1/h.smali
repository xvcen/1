.class public interface abstract LF1/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LF1/e;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, LF1/e;->a:LF1/e;

    .line 2
    .line 3
    sput-object v0, LF1/h;->a:LF1/e;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public abstract a()J
.end method

.method public abstract g()I
.end method

.method public abstract h(Lw0/G;LC1/k;LC1/i;)Landroid/graphics/Shader;
.end method
