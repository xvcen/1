.class public final LG/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static h:LG/b;


# instance fields
.field public final a:LT0/o;

.field public final b:LH0/O;

.field public final c:LT0/d;

.field public final d:LL0/d;

.field public final e:LH0/O;

.field public f:F

.field public g:F


# direct methods
.method public constructor <init>(LT0/o;LH0/O;LT0/d;LL0/d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG/b;->a:LT0/o;

    .line 5
    .line 6
    iput-object p2, p0, LG/b;->b:LH0/O;

    .line 7
    .line 8
    iput-object p3, p0, LG/b;->c:LT0/d;

    .line 9
    .line 10
    iput-object p4, p0, LG/b;->d:LL0/d;

    .line 11
    .line 12
    invoke-static {p2, p1}, LH0/F;->h(LH0/O;LT0/o;)LH0/O;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, LG/b;->e:LH0/O;

    .line 17
    .line 18
    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 19
    .line 20
    iput p1, p0, LG/b;->f:F

    .line 21
    .line 22
    iput p1, p0, LG/b;->g:F

    .line 23
    .line 24
    return-void
.end method
