.class public final LG/e;
.super Lw0/V;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw0/V;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:LH0/O;

.field public final c:LL0/d;

.field public final d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;LH0/O;LL0/d;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG/e;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, LG/e;->b:LH0/O;

    .line 7
    .line 8
    iput-object p3, p0, LG/e;->c:LL0/d;

    .line 9
    .line 10
    iput p4, p0, LG/e;->d:I

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final d()LW/p;
    .locals 3

    .line 1
    new-instance v0, LG/i;

    .line 2
    .line 3
    invoke-direct {v0}, LW/p;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LG/e;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v1, v0, LG/i;->r:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v1, p0, LG/e;->b:LH0/O;

    .line 11
    .line 12
    iput-object v1, v0, LG/i;->s:LH0/O;

    .line 13
    .line 14
    iget-object v1, p0, LG/e;->c:LL0/d;

    .line 15
    .line 16
    iput-object v1, v0, LG/i;->t:LL0/d;

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    iput v1, v0, LG/i;->u:I

    .line 20
    .line 21
    iput-boolean v1, v0, LG/i;->v:Z

    .line 22
    .line 23
    iget v2, p0, LG/e;->d:I

    .line 24
    .line 25
    iput v2, v0, LG/i;->w:I

    .line 26
    .line 27
    iput v1, v0, LG/i;->x:I

    .line 28
    .line 29
    return-object v0
.end method

.method public final e(LW/p;)V
    .locals 11

    .line 1
    check-cast p1, LG/i;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, LG/i;->s:LH0/O;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x1

    .line 10
    iget-object v3, p0, LG/e;->b:LH0/O;

    .line 11
    .line 12
    if-eq v3, v0, :cond_1

    .line 13
    .line 14
    iget-object v4, v3, LH0/O;->a:LH0/G;

    .line 15
    .line 16
    iget-object v0, v0, LH0/O;->a:LH0/G;

    .line 17
    .line 18
    invoke-virtual {v4, v0}, LH0/G;->b(LH0/G;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    move v0, v2

    .line 26
    goto :goto_1

    .line 27
    :cond_1
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    :goto_0
    move v0, v1

    .line 31
    :goto_1
    iget-object v4, p1, LG/i;->r:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v5, p0, LG/e;->a:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v4, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_2

    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_2
    iput-object v5, p1, LG/i;->r:Ljava/lang/String;

    .line 43
    .line 44
    const/4 v1, 0x0

    .line 45
    iput-object v1, p1, LG/i;->B:LG/h;

    .line 46
    .line 47
    move v1, v2

    .line 48
    :goto_2
    iget-object v4, p1, LG/i;->s:LH0/O;

    .line 49
    .line 50
    invoke-virtual {v4, v3}, LH0/O;->b(LH0/O;)Z

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    xor-int/2addr v4, v2

    .line 55
    iput-object v3, p1, LG/i;->s:LH0/O;

    .line 56
    .line 57
    iget v3, p1, LG/i;->x:I

    .line 58
    .line 59
    if-eq v3, v2, :cond_3

    .line 60
    .line 61
    iput v2, p1, LG/i;->x:I

    .line 62
    .line 63
    move v4, v2

    .line 64
    :cond_3
    iget v3, p1, LG/i;->w:I

    .line 65
    .line 66
    iget v5, p0, LG/e;->d:I

    .line 67
    .line 68
    if-eq v3, v5, :cond_4

    .line 69
    .line 70
    iput v5, p1, LG/i;->w:I

    .line 71
    .line 72
    move v4, v2

    .line 73
    :cond_4
    iget-boolean v3, p1, LG/i;->v:Z

    .line 74
    .line 75
    if-eq v3, v2, :cond_5

    .line 76
    .line 77
    iput-boolean v2, p1, LG/i;->v:Z

    .line 78
    .line 79
    move v4, v2

    .line 80
    :cond_5
    iget-object v3, p1, LG/i;->t:LL0/d;

    .line 81
    .line 82
    iget-object v5, p0, LG/e;->c:LL0/d;

    .line 83
    .line 84
    invoke-static {v3, v5}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    if-nez v3, :cond_6

    .line 89
    .line 90
    iput-object v5, p1, LG/i;->t:LL0/d;

    .line 91
    .line 92
    move v4, v2

    .line 93
    :cond_6
    iget v3, p1, LG/i;->u:I

    .line 94
    .line 95
    if-ne v3, v2, :cond_7

    .line 96
    .line 97
    move v2, v4

    .line 98
    goto :goto_3

    .line 99
    :cond_7
    iput v2, p1, LG/i;->u:I

    .line 100
    .line 101
    :goto_3
    if-nez v1, :cond_8

    .line 102
    .line 103
    if-eqz v2, :cond_9

    .line 104
    .line 105
    :cond_8
    invoke-virtual {p1}, LG/i;->U0()LG/d;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    iget-object v4, p1, LG/i;->r:Ljava/lang/String;

    .line 110
    .line 111
    iget-object v5, p1, LG/i;->s:LH0/O;

    .line 112
    .line 113
    iget-object v6, p1, LG/i;->t:LL0/d;

    .line 114
    .line 115
    iget v7, p1, LG/i;->u:I

    .line 116
    .line 117
    iget-boolean v8, p1, LG/i;->v:Z

    .line 118
    .line 119
    iget v9, p1, LG/i;->w:I

    .line 120
    .line 121
    iget v10, p1, LG/i;->x:I

    .line 122
    .line 123
    iput-object v4, v3, LG/d;->a:Ljava/lang/String;

    .line 124
    .line 125
    iput-object v5, v3, LG/d;->b:LH0/O;

    .line 126
    .line 127
    iput-object v6, v3, LG/d;->c:LL0/d;

    .line 128
    .line 129
    iput v7, v3, LG/d;->d:I

    .line 130
    .line 131
    iput-boolean v8, v3, LG/d;->e:Z

    .line 132
    .line 133
    iput v9, v3, LG/d;->f:I

    .line 134
    .line 135
    iput v10, v3, LG/d;->g:I

    .line 136
    .line 137
    iget-wide v4, v3, LG/d;->s:J

    .line 138
    .line 139
    const/4 v6, 0x2

    .line 140
    shl-long/2addr v4, v6

    .line 141
    const-wide/16 v6, 0x2

    .line 142
    .line 143
    or-long/2addr v4, v6

    .line 144
    iput-wide v4, v3, LG/d;->s:J

    .line 145
    .line 146
    invoke-virtual {v3}, LG/d;->c()V

    .line 147
    .line 148
    .line 149
    :cond_9
    iget-boolean v3, p1, LW/p;->q:Z

    .line 150
    .line 151
    if-nez v3, :cond_a

    .line 152
    .line 153
    goto :goto_4

    .line 154
    :cond_a
    if-nez v1, :cond_b

    .line 155
    .line 156
    if-eqz v0, :cond_c

    .line 157
    .line 158
    iget-object v3, p1, LG/i;->A:LG/f;

    .line 159
    .line 160
    if-eqz v3, :cond_c

    .line 161
    .line 162
    :cond_b
    invoke-static {p1}, Lw0/j;->l(Lw0/t0;)V

    .line 163
    .line 164
    .line 165
    :cond_c
    if-nez v1, :cond_d

    .line 166
    .line 167
    if-eqz v2, :cond_e

    .line 168
    .line 169
    :cond_d
    invoke-static {p1}, Lw0/j;->k(Lw0/u;)V

    .line 170
    .line 171
    .line 172
    invoke-static {p1}, Lw0/j;->j(Lw0/l;)V

    .line 173
    .line 174
    .line 175
    :cond_e
    if-eqz v0, :cond_f

    .line 176
    .line 177
    invoke-static {p1}, Lw0/j;->j(Lw0/l;)V

    .line 178
    .line 179
    .line 180
    :cond_f
    :goto_4
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, LG/e;

    .line 6
    .line 7
    if-nez v1, :cond_1

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_1
    check-cast p1, LG/e;

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, LG/e;->a:Ljava/lang/String;

    .line 16
    .line 17
    iget-object v2, p1, LG/e;->a:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v1, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_2

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_2
    iget-object v1, p0, LG/e;->b:LH0/O;

    .line 27
    .line 28
    iget-object v2, p1, LG/e;->b:LH0/O;

    .line 29
    .line 30
    invoke-static {v1, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_3

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_3
    iget-object v1, p0, LG/e;->c:LL0/d;

    .line 38
    .line 39
    iget-object v2, p1, LG/e;->c:LL0/d;

    .line 40
    .line 41
    invoke-static {v1, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-nez v1, :cond_4

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_4
    iget v1, p0, LG/e;->d:I

    .line 49
    .line 50
    iget p1, p1, LG/e;->d:I

    .line 51
    .line 52
    if-eq v1, p1, :cond_5

    .line 53
    .line 54
    :goto_0
    const/4 p1, 0x0

    .line 55
    return p1

    .line 56
    :cond_5
    return v0
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget-object v0, p0, LG/e;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, LG/e;->b:LH0/O;

    .line 11
    .line 12
    invoke-virtual {v2}, LH0/O;->hashCode()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    add-int/2addr v2, v0

    .line 17
    mul-int/2addr v2, v1

    .line 18
    iget-object v0, p0, LG/e;->c:LL0/d;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v0, v2

    .line 25
    mul-int/2addr v0, v1

    .line 26
    const/4 v2, 0x1

    .line 27
    invoke-static {v2, v0, v1}, LM0/m;->b(III)I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    invoke-static {v0, v1, v2}, LM0/m;->d(IIZ)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    iget v3, p0, LG/e;->d:I

    .line 36
    .line 37
    add-int/2addr v0, v3

    .line 38
    mul-int/2addr v0, v1

    .line 39
    add-int/2addr v0, v2

    .line 40
    mul-int/2addr v0, v1

    .line 41
    return v0
.end method
