.class public final synthetic LG/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lu0/L;


# direct methods
.method public synthetic constructor <init>(Lu0/L;I)V
    .locals 0

    .line 1
    iput p2, p0, LG/g;->d:I

    iput-object p1, p0, LG/g;->e:Lu0/L;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LG/g;->d:I

    .line 2
    .line 3
    check-cast p1, Lu0/K;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iget-object v1, p0, LG/g;->e:Lu0/L;

    .line 10
    .line 11
    invoke-static {p1, v1, v0, v0}, Lu0/K;->A(Lu0/K;Lu0/L;II)V

    .line 12
    .line 13
    .line 14
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 15
    .line 16
    return-object p1

    .line 17
    :pswitch_0
    const/4 v0, 0x0

    .line 18
    iget-object v1, p0, LG/g;->e:Lu0/L;

    .line 19
    .line 20
    invoke-static {p1, v1, v0, v0}, Lu0/K;->A(Lu0/K;Lu0/L;II)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :pswitch_1
    invoke-virtual {p1}, Lu0/K;->v()LT0/o;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sget-object v1, LT0/o;->d:LT0/o;

    .line 29
    .line 30
    iget-object v2, p0, LG/g;->e:Lu0/L;

    .line 31
    .line 32
    const-wide/16 v3, 0x0

    .line 33
    .line 34
    const/4 v5, 0x0

    .line 35
    const/4 v6, 0x0

    .line 36
    if-eq v0, v1, :cond_1

    .line 37
    .line 38
    invoke-virtual {p1}, Lu0/K;->w()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_0

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_0
    invoke-virtual {p1}, Lu0/K;->w()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    iget v1, v2, Lu0/L;->d:I

    .line 50
    .line 51
    sub-int/2addr v0, v1

    .line 52
    long-to-int v1, v3

    .line 53
    sub-int/2addr v0, v1

    .line 54
    int-to-long v3, v0

    .line 55
    const/16 v0, 0x20

    .line 56
    .line 57
    shl-long/2addr v3, v0

    .line 58
    int-to-long v0, v1

    .line 59
    const-wide v7, 0xffffffffL

    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    and-long/2addr v0, v7

    .line 65
    or-long/2addr v0, v3

    .line 66
    invoke-static {p1, v2}, Lu0/K;->c(Lu0/K;Lu0/L;)V

    .line 67
    .line 68
    .line 69
    iget-wide v3, v2, Lu0/L;->h:J

    .line 70
    .line 71
    invoke-static {v0, v1, v3, v4}, LT0/k;->c(JJ)J

    .line 72
    .line 73
    .line 74
    move-result-wide v0

    .line 75
    invoke-virtual {v2, v0, v1, v5, v6}, Lu0/L;->y0(JFLU1/c;)V

    .line 76
    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_1
    :goto_1
    invoke-static {p1, v2}, Lu0/K;->c(Lu0/K;Lu0/L;)V

    .line 80
    .line 81
    .line 82
    iget-wide v0, v2, Lu0/L;->h:J

    .line 83
    .line 84
    invoke-static {v3, v4, v0, v1}, LT0/k;->c(JJ)J

    .line 85
    .line 86
    .line 87
    move-result-wide v0

    .line 88
    invoke-virtual {v2, v0, v1, v5, v6}, Lu0/L;->y0(JFLU1/c;)V

    .line 89
    .line 90
    .line 91
    :goto_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 92
    .line 93
    return-object p1

    .line 94
    :pswitch_2
    const/4 v0, 0x0

    .line 95
    iget-object v1, p0, LG/g;->e:Lu0/L;

    .line 96
    .line 97
    invoke-static {p1, v1, v0, v0}, Lu0/K;->A(Lu0/K;Lu0/L;II)V

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :pswitch_3
    const/4 v0, 0x0

    .line 102
    iget-object v1, p0, LG/g;->e:Lu0/L;

    .line 103
    .line 104
    invoke-static {p1, v1, v0, v0}, Lu0/K;->x(Lu0/K;Lu0/L;II)V

    .line 105
    .line 106
    .line 107
    goto :goto_0

    .line 108
    nop

    .line 109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
