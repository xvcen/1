.class public final LG/i;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/u;
.implements Lw0/l;
.implements Lw0/t0;


# instance fields
.field public A:LG/f;

.field public B:LG/h;

.field public r:Ljava/lang/String;

.field public s:LH0/O;

.field public t:LL0/d;

.field public u:I

.field public v:Z

.field public w:I

.field public x:I

.field public y:Ljava/util/HashMap;

.field public z:LG/d;


# virtual methods
.method public final A(Lw0/L;Lu0/y;I)I
    .locals 1

    .line 1
    iget-object p2, p0, LG/i;->B:LG/h;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean v0, p2, LG/h;->c:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p2, 0x0

    .line 11
    :goto_0
    if-eqz p2, :cond_1

    .line 12
    .line 13
    iget-object p2, p2, LG/h;->d:LG/d;

    .line 14
    .line 15
    if-nez p2, :cond_2

    .line 16
    .line 17
    :cond_1
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    :cond_2
    invoke-virtual {p2, p1}, LG/d;->d(LT0/c;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {p1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p2, p3, p1}, LG/d;->a(ILT0/o;)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    return p1
.end method

.method public final C(LE0/v;)V
    .locals 6

    .line 1
    iget-object v0, p0, LG/i;->A:LG/f;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LG/f;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p0, v1}, LG/f;-><init>(LG/i;I)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, LG/i;->A:LG/f;

    .line 12
    .line 13
    :cond_0
    new-instance v1, LH0/g;

    .line 14
    .line 15
    iget-object v2, p0, LG/i;->r:Ljava/lang/String;

    .line 16
    .line 17
    invoke-direct {v1, v2}, LH0/g;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget-object v2, LE0/t;->a:[LZ1/c;

    .line 21
    .line 22
    sget-object v2, LE0/r;->z:LE0/u;

    .line 23
    .line 24
    invoke-static {v1}, LX1/a;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-interface {p1, v2, v1}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, LG/i;->B:LG/h;

    .line 32
    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    iget-boolean v2, v1, LG/h;->c:Z

    .line 36
    .line 37
    sget-object v3, LE0/r;->B:LE0/u;

    .line 38
    .line 39
    sget-object v4, LE0/t;->a:[LZ1/c;

    .line 40
    .line 41
    const/16 v5, 0x11

    .line 42
    .line 43
    aget-object v5, v4, v5

    .line 44
    .line 45
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-interface {p1, v3, v2}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    new-instance v2, LH0/g;

    .line 53
    .line 54
    iget-object v1, v1, LG/h;->b:Ljava/lang/String;

    .line 55
    .line 56
    invoke-direct {v2, v1}, LH0/g;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    sget-object v1, LE0/r;->A:LE0/u;

    .line 60
    .line 61
    const/16 v3, 0x10

    .line 62
    .line 63
    aget-object v3, v4, v3

    .line 64
    .line 65
    invoke-interface {p1, v1, v2}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    :cond_1
    new-instance v1, LG/f;

    .line 69
    .line 70
    const/4 v2, 0x1

    .line 71
    invoke-direct {v1, p0, v2}, LG/f;-><init>(LG/i;I)V

    .line 72
    .line 73
    .line 74
    sget-object v2, LE0/j;->k:LE0/u;

    .line 75
    .line 76
    new-instance v3, LE0/a;

    .line 77
    .line 78
    const/4 v4, 0x0

    .line 79
    invoke-direct {v3, v4, v1}, LE0/a;-><init>(Ljava/lang/String;LJ1/c;)V

    .line 80
    .line 81
    .line 82
    invoke-interface {p1, v2, v3}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    new-instance v1, LG/f;

    .line 86
    .line 87
    const/4 v2, 0x2

    .line 88
    invoke-direct {v1, p0, v2}, LG/f;-><init>(LG/i;I)V

    .line 89
    .line 90
    .line 91
    sget-object v2, LE0/j;->l:LE0/u;

    .line 92
    .line 93
    new-instance v3, LE0/a;

    .line 94
    .line 95
    invoke-direct {v3, v4, v1}, LE0/a;-><init>(Ljava/lang/String;LJ1/c;)V

    .line 96
    .line 97
    .line 98
    invoke-interface {p1, v2, v3}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    new-instance v1, LA1/P;

    .line 102
    .line 103
    const/16 v2, 0x9

    .line 104
    .line 105
    invoke-direct {v1, v2, p0}, LA1/P;-><init>(ILjava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    sget-object v2, LE0/j;->m:LE0/u;

    .line 109
    .line 110
    new-instance v3, LE0/a;

    .line 111
    .line 112
    invoke-direct {v3, v4, v1}, LE0/a;-><init>(Ljava/lang/String;LJ1/c;)V

    .line 113
    .line 114
    .line 115
    invoke-interface {p1, v2, v3}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    invoke-static {p1, v0}, LE0/t;->a(LE0/v;LU1/c;)V

    .line 119
    .line 120
    .line 121
    return-void
.end method

.method public final F0(Lw0/L;Lu0/y;I)I
    .locals 0

    .line 1
    iget-object p2, p0, LG/i;->B:LG/h;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean p3, p2, LG/h;->c:Z

    .line 6
    .line 7
    if-eqz p3, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p2, 0x0

    .line 11
    :goto_0
    if-eqz p2, :cond_1

    .line 12
    .line 13
    iget-object p2, p2, LG/h;->d:LG/d;

    .line 14
    .line 15
    if-nez p2, :cond_2

    .line 16
    .line 17
    :cond_1
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    :cond_2
    invoke-virtual {p2, p1}, LG/d;->d(LT0/c;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {p1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p2, p1}, LG/d;->e(LT0/o;)LH0/u;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-interface {p1}, LH0/u;->c()F

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    invoke-static {p1}, Lw/O;->j(F)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    return p1
.end method

.method public final J0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final S(Lw0/L;Lu0/y;I)I
    .locals 1

    .line 1
    iget-object p2, p0, LG/i;->B:LG/h;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean v0, p2, LG/h;->c:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p2, 0x0

    .line 11
    :goto_0
    if-eqz p2, :cond_1

    .line 12
    .line 13
    iget-object p2, p2, LG/h;->d:LG/d;

    .line 14
    .line 15
    if-nez p2, :cond_2

    .line 16
    .line 17
    :cond_1
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    :cond_2
    invoke-virtual {p2, p1}, LG/d;->d(LT0/c;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {p1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p2, p3, p1}, LG/d;->a(ILT0/o;)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    return p1
.end method

.method public final U(Lw0/G;)V
    .locals 10

    .line 1
    iget-boolean v0, p0, LW/p;->q:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto/16 :goto_4

    .line 6
    .line 7
    :cond_0
    iget-object v0, p0, LG/i;->B:LG/h;

    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    iget-boolean v1, v0, LG/h;->c:Z

    .line 12
    .line 13
    if-eqz v1, :cond_1

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_1
    const/4 v0, 0x0

    .line 17
    :goto_0
    if-eqz v0, :cond_2

    .line 18
    .line 19
    iget-object v0, v0, LG/h;->d:LG/d;

    .line 20
    .line 21
    if-nez v0, :cond_3

    .line 22
    .line 23
    :cond_2
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    :cond_3
    iget-object v1, v0, LG/d;->j:LH0/a;

    .line 28
    .line 29
    if-eqz v1, :cond_d

    .line 30
    .line 31
    iget-object p1, p1, Lw0/G;->d:Lf0/b;

    .line 32
    .line 33
    iget-object p1, p1, Lf0/b;->e:LI/e0;

    .line 34
    .line 35
    invoke-virtual {p1}, LI/e0;->m()Ld0/u;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    iget-boolean p1, v0, LG/d;->k:Z

    .line 40
    .line 41
    if-eqz p1, :cond_4

    .line 42
    .line 43
    iget-wide v3, v0, LG/d;->l:J

    .line 44
    .line 45
    const/16 v0, 0x20

    .line 46
    .line 47
    shr-long v5, v3, v0

    .line 48
    .line 49
    long-to-int v0, v5

    .line 50
    int-to-float v0, v0

    .line 51
    const-wide v5, 0xffffffffL

    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    and-long/2addr v3, v5

    .line 57
    long-to-int v3, v3

    .line 58
    int-to-float v3, v3

    .line 59
    invoke-interface {v2}, Ld0/u;->k()V

    .line 60
    .line 61
    .line 62
    const/4 v4, 0x0

    .line 63
    invoke-interface {v2, v4, v4, v0, v3}, Ld0/u;->n(FFFF)V

    .line 64
    .line 65
    .line 66
    :cond_4
    :try_start_0
    iget-object v0, p0, LG/i;->s:LH0/O;

    .line 67
    .line 68
    iget-object v0, v0, LH0/O;->a:LH0/G;

    .line 69
    .line 70
    iget-object v3, v0, LH0/G;->m:LS0/l;

    .line 71
    .line 72
    if-nez v3, :cond_5

    .line 73
    .line 74
    sget-object v3, LS0/l;->b:LS0/l;

    .line 75
    .line 76
    :cond_5
    move-object v6, v3

    .line 77
    goto :goto_1

    .line 78
    :catchall_0
    move-exception v0

    .line 79
    goto :goto_5

    .line 80
    :goto_1
    iget-object v3, v0, LH0/G;->n:Ld0/S;

    .line 81
    .line 82
    if-nez v3, :cond_6

    .line 83
    .line 84
    sget-object v3, Ld0/S;->d:Ld0/S;

    .line 85
    .line 86
    :cond_6
    move-object v5, v3

    .line 87
    iget-object v3, v0, LH0/G;->o:Lf0/c;

    .line 88
    .line 89
    if-nez v3, :cond_7

    .line 90
    .line 91
    sget-object v3, Lf0/f;->b:Lf0/f;

    .line 92
    .line 93
    :cond_7
    move-object v7, v3

    .line 94
    iget-object v0, v0, LH0/G;->a:LS0/o;

    .line 95
    .line 96
    invoke-interface {v0}, LS0/o;->d()Ld0/s;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    if-eqz v3, :cond_8

    .line 101
    .line 102
    iget-object v0, p0, LG/i;->s:LH0/O;

    .line 103
    .line 104
    iget-object v0, v0, LH0/O;->a:LH0/G;

    .line 105
    .line 106
    iget-object v0, v0, LH0/G;->a:LS0/o;

    .line 107
    .line 108
    invoke-interface {v0}, LS0/o;->c()F

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    invoke-virtual/range {v1 .. v7}, LH0/a;->g(Ld0/u;Ld0/s;FLd0/S;LS0/l;Lf0/c;)V

    .line 113
    .line 114
    .line 115
    goto :goto_3

    .line 116
    :cond_8
    sget-wide v3, Ld0/w;->g:J

    .line 117
    .line 118
    const-wide/16 v8, 0x10

    .line 119
    .line 120
    cmp-long v0, v3, v8

    .line 121
    .line 122
    if-eqz v0, :cond_9

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_9
    iget-object v0, p0, LG/i;->s:LH0/O;

    .line 126
    .line 127
    invoke-virtual {v0}, LH0/O;->a()J

    .line 128
    .line 129
    .line 130
    move-result-wide v3

    .line 131
    cmp-long v0, v3, v8

    .line 132
    .line 133
    if-eqz v0, :cond_a

    .line 134
    .line 135
    iget-object v0, p0, LG/i;->s:LH0/O;

    .line 136
    .line 137
    invoke-virtual {v0}, LH0/O;->a()J

    .line 138
    .line 139
    .line 140
    move-result-wide v3

    .line 141
    goto :goto_2

    .line 142
    :cond_a
    sget-wide v3, Ld0/w;->b:J

    .line 143
    .line 144
    :goto_2
    invoke-virtual/range {v1 .. v7}, LH0/a;->f(Ld0/u;JLd0/S;LS0/l;Lf0/c;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 145
    .line 146
    .line 147
    :goto_3
    if-eqz p1, :cond_b

    .line 148
    .line 149
    invoke-interface {v2}, Ld0/u;->i()V

    .line 150
    .line 151
    .line 152
    :cond_b
    :goto_4
    return-void

    .line 153
    :goto_5
    if-eqz p1, :cond_c

    .line 154
    .line 155
    invoke-interface {v2}, Ld0/u;->i()V

    .line 156
    .line 157
    .line 158
    :cond_c
    throw v0

    .line 159
    :cond_d
    new-instance p1, Ljava/lang/StringBuilder;

    .line 160
    .line 161
    const-string v0, "Internal Error: ParagraphLayoutCache could not provide a Paragraph during the draw phase. Please report this bug on the official Issue Tracker with the following diagnostic information: (layoutCache="

    .line 162
    .line 163
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    iget-object v0, p0, LG/i;->z:LG/d;

    .line 167
    .line 168
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    const-string v0, ", textSubstitution="

    .line 172
    .line 173
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    iget-object v0, p0, LG/i;->B:LG/h;

    .line 177
    .line 178
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    const/16 v0, 0x29

    .line 182
    .line 183
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    invoke-static {p1}, Lr/b;->b(Ljava/lang/String;)Ljava/lang/Void;

    .line 191
    .line 192
    .line 193
    new-instance p1, LC0/e;

    .line 194
    .line 195
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 196
    .line 197
    .line 198
    throw p1
.end method

.method public final U0()LG/d;
    .locals 9

    .line 1
    iget-object v0, p0, LG/i;->z:LG/d;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LG/d;

    .line 6
    .line 7
    iget-object v2, p0, LG/i;->r:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v3, p0, LG/i;->s:LH0/O;

    .line 10
    .line 11
    iget-object v4, p0, LG/i;->t:LL0/d;

    .line 12
    .line 13
    iget v5, p0, LG/i;->u:I

    .line 14
    .line 15
    iget-boolean v6, p0, LG/i;->v:Z

    .line 16
    .line 17
    iget v7, p0, LG/i;->w:I

    .line 18
    .line 19
    iget v8, p0, LG/i;->x:I

    .line 20
    .line 21
    invoke-direct/range {v1 .. v8}, LG/d;-><init>(Ljava/lang/String;LH0/O;LL0/d;IZII)V

    .line 22
    .line 23
    .line 24
    iput-object v1, p0, LG/i;->z:LG/d;

    .line 25
    .line 26
    :cond_0
    iget-object v0, p0, LG/i;->z:LG/d;

    .line 27
    .line 28
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    return-object v0
.end method

.method public final f0(Lw0/L;Lu0/y;I)I
    .locals 0

    .line 1
    iget-object p2, p0, LG/i;->B:LG/h;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-boolean p3, p2, LG/h;->c:Z

    .line 6
    .line 7
    if-eqz p3, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p2, 0x0

    .line 11
    :goto_0
    if-eqz p2, :cond_1

    .line 12
    .line 13
    iget-object p2, p2, LG/h;->d:LG/d;

    .line 14
    .line 15
    if-nez p2, :cond_2

    .line 16
    .line 17
    :cond_1
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    :cond_2
    invoke-virtual {p2, p1}, LG/d;->d(LT0/c;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {p1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p2, p1}, LG/d;->e(LT0/o;)LH0/u;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-interface {p1}, LH0/u;->a()F

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    invoke-static {p1}, Lw/O;->j(F)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    return p1
.end method

.method public final j(Lu0/B;Lu0/y;J)Lu0/A;
    .locals 4

    .line 1
    const-string v0, "TextStringSimpleNode::measure"

    .line 2
    .line 3
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    :try_start_0
    iget-object v0, p0, LG/i;->B:LG/h;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-boolean v1, v0, LG/h;->c:Z

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :goto_0
    if-eqz v0, :cond_1

    .line 17
    .line 18
    iget-object v0, v0, LG/h;->d:LG/d;

    .line 19
    .line 20
    if-nez v0, :cond_2

    .line 21
    .line 22
    :cond_1
    invoke-virtual {p0}, LG/i;->U0()LG/d;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    :cond_2
    invoke-virtual {v0, p1}, LG/d;->d(LT0/c;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v0, p3, p4, v1}, LG/d;->b(JLT0/o;)Z

    .line 34
    .line 35
    .line 36
    move-result p3

    .line 37
    iget-object p4, v0, LG/d;->n:LH0/u;

    .line 38
    .line 39
    if-eqz p4, :cond_3

    .line 40
    .line 41
    invoke-interface {p4}, LH0/u;->b()Z

    .line 42
    .line 43
    .line 44
    :cond_3
    iget-object p4, v0, LG/d;->j:LH0/a;

    .line 45
    .line 46
    invoke-static {p4}, LV1/i;->b(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p4, p4, LH0/a;->d:LI0/m;

    .line 50
    .line 51
    iget-wide v0, v0, LG/d;->l:J

    .line 52
    .line 53
    if-eqz p3, :cond_5

    .line 54
    .line 55
    const/4 p3, 0x2

    .line 56
    invoke-static {p0, p3}, Lw0/j;->r(Lw0/h;I)Lw0/b0;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    invoke-virtual {v2}, Lw0/b0;->o1()V

    .line 61
    .line 62
    .line 63
    iget-object v2, p0, LG/i;->y:Ljava/util/HashMap;

    .line 64
    .line 65
    if-nez v2, :cond_4

    .line 66
    .line 67
    new-instance v2, Ljava/util/HashMap;

    .line 68
    .line 69
    invoke-direct {v2, p3}, Ljava/util/HashMap;-><init>(I)V

    .line 70
    .line 71
    .line 72
    iput-object v2, p0, LG/i;->y:Ljava/util/HashMap;

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :catchall_0
    move-exception p1

    .line 76
    goto :goto_2

    .line 77
    :cond_4
    :goto_1
    sget-object p3, Lu0/c;->a:Lu0/h;

    .line 78
    .line 79
    const/4 v3, 0x0

    .line 80
    invoke-virtual {p4, v3}, LI0/m;->d(I)F

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    invoke-interface {v2, p3, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    sget-object p3, Lu0/c;->b:Lu0/h;

    .line 96
    .line 97
    iget v3, p4, LI0/m;->g:I

    .line 98
    .line 99
    add-int/lit8 v3, v3, -0x1

    .line 100
    .line 101
    invoke-virtual {p4, v3}, LI0/m;->d(I)F

    .line 102
    .line 103
    .line 104
    move-result p4

    .line 105
    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    .line 106
    .line 107
    .line 108
    move-result p4

    .line 109
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object p4

    .line 113
    invoke-interface {v2, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    :cond_5
    const/16 p3, 0x20

    .line 117
    .line 118
    shr-long p3, v0, p3

    .line 119
    .line 120
    long-to-int p3, p3

    .line 121
    const-wide v2, 0xffffffffL

    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    and-long/2addr v0, v2

    .line 127
    long-to-int p4, v0

    .line 128
    invoke-static {p3, p3, p4, p4}, La/a;->t(IIII)J

    .line 129
    .line 130
    .line 131
    move-result-wide v0

    .line 132
    invoke-interface {p2, v0, v1}, Lu0/y;->v(J)Lu0/L;

    .line 133
    .line 134
    .line 135
    move-result-object p2

    .line 136
    iget-object v0, p0, LG/i;->y:Ljava/util/HashMap;

    .line 137
    .line 138
    invoke-static {v0}, LV1/i;->b(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    new-instance v1, LG/g;

    .line 142
    .line 143
    const/4 v2, 0x0

    .line 144
    invoke-direct {v1, p2, v2}, LG/g;-><init>(Lu0/L;I)V

    .line 145
    .line 146
    .line 147
    invoke-interface {p1, p3, p4, v0, v1}, Lu0/B;->D0(IILjava/util/Map;LU1/c;)Lu0/A;

    .line 148
    .line 149
    .line 150
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 151
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 152
    .line 153
    .line 154
    return-object p1

    .line 155
    :goto_2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 156
    .line 157
    .line 158
    throw p1
.end method
