.class public final synthetic LG1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:Ld0/D;

.field public final synthetic e:Ld0/j;

.field public final synthetic f:LG1/e;

.field public final synthetic g:F

.field public final synthetic h:F


# direct methods
.method public synthetic constructor <init>(Ld0/D;Ld0/j;LG1/e;FF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LG1/d;->d:Ld0/D;

    iput-object p2, p0, LG1/d;->e:Ld0/j;

    iput-object p3, p0, LG1/d;->f:LG1/e;

    iput p4, p0, LG1/d;->g:F

    iput p5, p0, LG1/d;->h:F

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    check-cast p1, Lf0/d;

    .line 2
    .line 3
    const-string v0, "$this$record"

    .line 4
    .line 5
    invoke-static {p1, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-interface {p1}, Lf0/d;->Q()LI/e0;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {p1}, LI/e0;->m()Ld0/u;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-interface {p1}, Ld0/u;->k()V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, LG1/d;->d:Ld0/D;

    .line 20
    .line 21
    iget-object v1, p0, LG1/d;->e:Ld0/j;

    .line 22
    .line 23
    invoke-static {p1, v0, v1}, LC1/c;->a(Ld0/u;Ld0/D;Ld0/j;)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, LG1/d;->f:LG1/e;

    .line 27
    .line 28
    iget-object v1, v1, LG1/e;->u:Ld0/h;

    .line 29
    .line 30
    invoke-static {p1, v0, v1}, Ld0/D;->h(Ld0/u;Ld0/D;Ld0/h;)V

    .line 31
    .line 32
    .line 33
    iget v1, p0, LG1/d;->g:F

    .line 34
    .line 35
    iget v2, p0, LG1/d;->h:F

    .line 36
    .line 37
    invoke-interface {p1, v1, v2}, Ld0/u;->f(FF)V

    .line 38
    .line 39
    .line 40
    sget-object v3, LG1/c;->a:Ld0/h;

    .line 41
    .line 42
    invoke-static {p1, v0, v3}, Ld0/D;->h(Ld0/u;Ld0/D;Ld0/h;)V

    .line 43
    .line 44
    .line 45
    neg-float v0, v1

    .line 46
    neg-float v1, v2

    .line 47
    invoke-interface {p1, v0, v1}, Ld0/u;->f(FF)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p1}, Ld0/u;->i()V

    .line 51
    .line 52
    .line 53
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 54
    .line 55
    return-object p1
.end method
