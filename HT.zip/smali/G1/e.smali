.class public final LG1/e;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/l;


# instance fields
.field public r:LC1/l;

.field public s:LU1/a;

.field public t:Lg0/c;

.field public final u:Ld0/h;

.field public v:Ld0/j;

.field public w:F


# direct methods
.method public constructor <init>(LC1/l;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LW/p;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG1/e;->r:LC1/l;

    .line 5
    .line 6
    iput-object p2, p0, LG1/e;->s:LU1/a;

    .line 7
    .line 8
    invoke-static {}, Ld0/D;->e()Ld0/h;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, LG1/e;->u:Ld0/h;

    .line 13
    .line 14
    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 15
    .line 16
    iput p1, p0, LG1/e;->w:F

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final J0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final M0()V
    .locals 4

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ld0/A;->b()Lg0/c;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, v0, Lg0/c;->a:Lg0/e;

    .line 10
    .line 11
    invoke-interface {v1}, Lg0/e;->B()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x1

    .line 16
    if-ne v2, v3, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-interface {v1, v3}, Lg0/e;->E(I)V

    .line 20
    .line 21
    .line 22
    :goto_0
    iput-object v0, p0, LG1/e;->t:Lg0/c;

    .line 23
    .line 24
    return-void
.end method

.method public final N0()V
    .locals 2

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LG1/e;->t:Lg0/c;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-interface {v0, v1}, Ld0/A;->a(Lg0/c;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, LG1/e;->t:Lg0/c;

    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method public final U(Lw0/G;)V
    .locals 15

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    iget-object v7, v6, Lw0/G;->d:Lf0/b;

    .line 4
    .line 5
    invoke-virtual {v6}, Lw0/G;->c()V

    .line 6
    .line 7
    .line 8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v1, 0x1f

    .line 11
    .line 12
    if-ge v0, v1, :cond_0

    .line 13
    .line 14
    goto/16 :goto_3

    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, LG1/e;->s:LU1/a;

    .line 17
    .line 18
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, LG1/a;

    .line 23
    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    goto/16 :goto_3

    .line 27
    .line 28
    :cond_1
    iget-wide v1, v0, LG1/a;->b:J

    .line 29
    .line 30
    iget-object v8, p0, LG1/e;->t:Lg0/c;

    .line 31
    .line 32
    if-eqz v8, :cond_8

    .line 33
    .line 34
    iget-object v4, v8, Lg0/c;->a:Lg0/e;

    .line 35
    .line 36
    invoke-interface {v7}, Lf0/d;->a()J

    .line 37
    .line 38
    .line 39
    move-result-wide v9

    .line 40
    invoke-virtual {v6}, Lw0/G;->getLayoutDirection()LT0/o;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    iget v11, v0, LG1/a;->a:F

    .line 45
    .line 46
    invoke-virtual {v6, v11}, Lw0/G;->K(F)F

    .line 47
    .line 48
    .line 49
    move-result v11

    .line 50
    const/16 v12, 0x20

    .line 51
    .line 52
    shr-long v12, v1, v12

    .line 53
    .line 54
    long-to-int v12, v12

    .line 55
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 56
    .line 57
    .line 58
    move-result v12

    .line 59
    invoke-virtual {v6, v12}, Lw0/G;->K(F)F

    .line 60
    .line 61
    .line 62
    move-result v12

    .line 63
    const-wide v13, 0xffffffffL

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    and-long/2addr v1, v13

    .line 69
    long-to-int v1, v1

    .line 70
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    invoke-virtual {v6, v1}, Lw0/G;->K(F)F

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    iget-object v2, p0, LG1/e;->r:LC1/l;

    .line 79
    .line 80
    iget-object v2, v2, LC1/l;->g:LC1/k;

    .line 81
    .line 82
    invoke-virtual {v2, v9, v10, v5, v6}, LC1/k;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    instance-of v5, v2, Ld0/L;

    .line 87
    .line 88
    const/4 v9, 0x0

    .line 89
    if-eqz v5, :cond_2

    .line 90
    .line 91
    iget-object v5, p0, LG1/e;->v:Ld0/j;

    .line 92
    .line 93
    if-nez v5, :cond_3

    .line 94
    .line 95
    invoke-static {}, Ld0/l;->a()Ld0/j;

    .line 96
    .line 97
    .line 98
    move-result-object v5

    .line 99
    iput-object v5, p0, LG1/e;->v:Ld0/j;

    .line 100
    .line 101
    goto :goto_0

    .line 102
    :cond_2
    move-object v5, v9

    .line 103
    :cond_3
    :goto_0
    iget-object v10, p0, LG1/e;->u:Ld0/h;

    .line 104
    .line 105
    iget-wide v13, v0, LG1/a;->c:J

    .line 106
    .line 107
    invoke-virtual {v10, v13, v14}, Ld0/h;->e(J)V

    .line 108
    .line 109
    .line 110
    iget v10, v0, LG1/a;->d:F

    .line 111
    .line 112
    invoke-virtual {v8, v10}, Lg0/c;->g(F)V

    .line 113
    .line 114
    .line 115
    iget v0, v0, LG1/a;->e:I

    .line 116
    .line 117
    invoke-interface {v4}, Lg0/e;->g()I

    .line 118
    .line 119
    .line 120
    move-result v10

    .line 121
    if-ne v10, v0, :cond_4

    .line 122
    .line 123
    goto :goto_1

    .line 124
    :cond_4
    invoke-interface {v4, v0}, Lg0/e;->m(I)V

    .line 125
    .line 126
    .line 127
    :goto_1
    iget v0, p0, LG1/e;->w:F

    .line 128
    .line 129
    cmpg-float v0, v0, v11

    .line 130
    .line 131
    if-nez v0, :cond_5

    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_5
    const/4 v0, 0x0

    .line 135
    cmpl-float v0, v11, v0

    .line 136
    .line 137
    if-lez v0, :cond_6

    .line 138
    .line 139
    new-instance v9, Ld0/r;

    .line 140
    .line 141
    invoke-direct {v9, v11, v11}, Ld0/r;-><init>(FF)V

    .line 142
    .line 143
    .line 144
    :cond_6
    invoke-interface {v4}, Lg0/e;->j()LV/b;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    invoke-static {v0, v9}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-nez v0, :cond_7

    .line 153
    .line 154
    invoke-interface {v4, v9}, Lg0/e;->I(LV/b;)V

    .line 155
    .line 156
    .line 157
    :cond_7
    iput v11, p0, LG1/e;->w:F

    .line 158
    .line 159
    :goto_2
    new-instance v0, LG1/d;

    .line 160
    .line 161
    move-object v3, v5

    .line 162
    move v5, v1

    .line 163
    move-object v1, v2

    .line 164
    move-object v2, v3

    .line 165
    move-object v3, p0

    .line 166
    move v4, v12

    .line 167
    invoke-direct/range {v0 .. v5}, LG1/d;-><init>(Ld0/D;Ld0/j;LG1/e;FF)V

    .line 168
    .line 169
    .line 170
    invoke-interface {v7}, Lf0/d;->a()J

    .line 171
    .line 172
    .line 173
    move-result-wide v3

    .line 174
    invoke-static {v3, v4}, LT0/l;->N(J)J

    .line 175
    .line 176
    .line 177
    move-result-wide v3

    .line 178
    invoke-virtual {v6, v8, v3, v4, v0}, Lw0/G;->M(Lg0/c;JLU1/c;)V

    .line 179
    .line 180
    .line 181
    iget-object v0, v7, Lf0/b;->e:LI/e0;

    .line 182
    .line 183
    invoke-virtual {v0}, LI/e0;->m()Ld0/u;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    invoke-interface {v0}, Ld0/u;->k()V

    .line 188
    .line 189
    .line 190
    invoke-static {v0, v1, v2}, LC1/c;->a(Ld0/u;Ld0/D;Ld0/j;)V

    .line 191
    .line 192
    .line 193
    invoke-static {v6, v8}, LT0/g;->r(Lf0/d;Lg0/c;)V

    .line 194
    .line 195
    .line 196
    invoke-interface {v0}, Ld0/u;->i()V

    .line 197
    .line 198
    .line 199
    :cond_8
    :goto_3
    return-void
.end method
