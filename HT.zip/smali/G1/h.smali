.class public abstract LG1/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ld0/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Ld0/D;->e()Ld0/h;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Ld0/h;->d(I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LG1/h;->a:Ld0/h;

    .line 10
    .line 11
    return-void
.end method
