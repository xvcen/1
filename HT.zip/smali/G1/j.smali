.class public final LG1/j;
.super LW/p;
.source "SourceFile"

# interfaces
.implements Lw0/l;


# instance fields
.field public r:LC1/l;

.field public s:LU1/a;

.field public t:Lg0/c;

.field public final u:Ld0/h;


# direct methods
.method public constructor <init>(LC1/l;LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LW/p;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG1/j;->r:LC1/l;

    .line 5
    .line 6
    iput-object p2, p0, LG1/j;->s:LU1/a;

    .line 7
    .line 8
    invoke-static {}, Ld0/D;->e()Ld0/h;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, LG1/j;->u:Ld0/h;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final J0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final M0()V
    .locals 4

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0}, Ld0/A;->b()Lg0/c;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, v0, Lg0/c;->a:Lg0/e;

    .line 10
    .line 11
    invoke-interface {v1}, Lg0/e;->B()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x1

    .line 16
    if-ne v2, v3, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-interface {v1, v3}, Lg0/e;->E(I)V

    .line 20
    .line 21
    .line 22
    :goto_0
    iput-object v0, p0, LG1/j;->t:Lg0/c;

    .line 23
    .line 24
    return-void
.end method

.method public final N0()V
    .locals 2

    .line 1
    invoke-static {p0}, Lw0/j;->s(LW/p;)Ld0/A;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LG1/j;->t:Lg0/c;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-interface {v0, v1}, Ld0/A;->a(Lg0/c;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, LG1/j;->t:Lg0/c;

    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method public final U(Lw0/G;)V
    .locals 20

    .line 1
    move-object/from16 v5, p0

    .line 2
    .line 3
    move-object/from16 v6, p1

    .line 4
    .line 5
    iget-object v7, v6, Lw0/G;->d:Lf0/b;

    .line 6
    .line 7
    iget-object v0, v5, LG1/j;->s:LU1/a;

    .line 8
    .line 9
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, LG1/f;

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v6}, Lw0/G;->c()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    iget-wide v1, v0, LG1/f;->b:J

    .line 22
    .line 23
    iget v3, v0, LG1/f;->a:F

    .line 24
    .line 25
    iget-object v8, v5, LG1/j;->t:Lg0/c;

    .line 26
    .line 27
    if-eqz v8, :cond_3

    .line 28
    .line 29
    invoke-interface {v7}, Lf0/d;->a()J

    .line 30
    .line 31
    .line 32
    move-result-wide v9

    .line 33
    invoke-virtual {v6}, Lw0/G;->getLayoutDirection()LT0/o;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    move-wide v11, v1

    .line 38
    invoke-virtual {v6, v3}, Lw0/G;->K(F)F

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    const/16 v2, 0x20

    .line 43
    .line 44
    shr-long v13, v11, v2

    .line 45
    .line 46
    long-to-int v13, v13

    .line 47
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 48
    .line 49
    .line 50
    move-result v13

    .line 51
    invoke-virtual {v6, v13}, Lw0/G;->K(F)F

    .line 52
    .line 53
    .line 54
    move-result v13

    .line 55
    const-wide v14, 0xffffffffL

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    and-long/2addr v11, v14

    .line 61
    long-to-int v11, v11

    .line 62
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 63
    .line 64
    .line 65
    move-result v11

    .line 66
    invoke-virtual {v6, v11}, Lw0/G;->K(F)F

    .line 67
    .line 68
    .line 69
    move-result v11

    .line 70
    move-wide/from16 v16, v14

    .line 71
    .line 72
    shr-long v14, v9, v2

    .line 73
    .line 74
    long-to-int v12, v14

    .line 75
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 76
    .line 77
    .line 78
    move-result v12

    .line 79
    const/high16 v14, 0x40800000    # 4.0f

    .line 80
    .line 81
    mul-float/2addr v14, v1

    .line 82
    add-float/2addr v12, v14

    .line 83
    add-float/2addr v12, v13

    .line 84
    move/from16 v18, v2

    .line 85
    .line 86
    move v15, v3

    .line 87
    float-to-double v2, v12

    .line 88
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 89
    .line 90
    .line 91
    move-result-wide v2

    .line 92
    double-to-float v2, v2

    .line 93
    float-to-int v2, v2

    .line 94
    move v3, v11

    .line 95
    and-long v11, v9, v16

    .line 96
    .line 97
    long-to-int v11, v11

    .line 98
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 99
    .line 100
    .line 101
    move-result v11

    .line 102
    add-float/2addr v11, v14

    .line 103
    add-float/2addr v11, v3

    .line 104
    float-to-double v11, v11

    .line 105
    invoke-static {v11, v12}, Ljava/lang/Math;->ceil(D)D

    .line 106
    .line 107
    .line 108
    move-result-wide v11

    .line 109
    double-to-float v11, v11

    .line 110
    float-to-int v11, v11

    .line 111
    move v12, v1

    .line 112
    int-to-long v1, v2

    .line 113
    shl-long v1, v1, v18

    .line 114
    .line 115
    move-wide/from16 v18, v1

    .line 116
    .line 117
    int-to-long v1, v11

    .line 118
    and-long v1, v1, v16

    .line 119
    .line 120
    or-long v1, v18, v1

    .line 121
    .line 122
    iget-object v11, v5, LG1/j;->r:LC1/l;

    .line 123
    .line 124
    iget-object v11, v11, LC1/l;->g:LC1/k;

    .line 125
    .line 126
    invoke-virtual {v11, v9, v10, v4, v6}, LC1/k;->a(JLT0/o;LT0/c;)Ld0/D;

    .line 127
    .line 128
    .line 129
    move-result-object v4

    .line 130
    iget-wide v9, v0, LG1/f;->c:J

    .line 131
    .line 132
    iget-object v11, v5, LG1/j;->u:Ld0/h;

    .line 133
    .line 134
    invoke-virtual {v11, v9, v10}, Ld0/h;->e(J)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v6, v15}, Lw0/G;->K(F)F

    .line 138
    .line 139
    .line 140
    move-result v9

    .line 141
    iget-object v10, v11, Ld0/h;->a:Landroid/graphics/Paint;

    .line 142
    .line 143
    const/4 v11, 0x0

    .line 144
    cmpl-float v11, v9, v11

    .line 145
    .line 146
    if-lez v11, :cond_1

    .line 147
    .line 148
    new-instance v11, Landroid/graphics/BlurMaskFilter;

    .line 149
    .line 150
    sget-object v14, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    .line 151
    .line 152
    invoke-direct {v11, v9, v14}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    .line 153
    .line 154
    .line 155
    goto :goto_0

    .line 156
    :cond_1
    const/4 v11, 0x0

    .line 157
    :goto_0
    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 158
    .line 159
    .line 160
    iget v9, v0, LG1/f;->d:F

    .line 161
    .line 162
    invoke-virtual {v8, v9}, Lg0/c;->g(F)V

    .line 163
    .line 164
    .line 165
    iget v0, v0, LG1/f;->e:I

    .line 166
    .line 167
    iget-object v9, v8, Lg0/c;->a:Lg0/e;

    .line 168
    .line 169
    invoke-interface {v9}, Lg0/e;->g()I

    .line 170
    .line 171
    .line 172
    move-result v10

    .line 173
    if-ne v10, v0, :cond_2

    .line 174
    .line 175
    goto :goto_1

    .line 176
    :cond_2
    invoke-interface {v9, v0}, Lg0/e;->m(I)V

    .line 177
    .line 178
    .line 179
    :goto_1
    new-instance v0, LG1/i;

    .line 180
    .line 181
    move-wide v9, v1

    .line 182
    move v1, v12

    .line 183
    move v2, v13

    .line 184
    invoke-direct/range {v0 .. v5}, LG1/i;-><init>(FFFLd0/D;LG1/j;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v6, v8, v9, v10, v0}, Lw0/G;->M(Lg0/c;JLU1/c;)V

    .line 188
    .line 189
    .line 190
    neg-float v0, v1

    .line 191
    const/high16 v1, 0x40000000    # 2.0f

    .line 192
    .line 193
    mul-float/2addr v1, v0

    .line 194
    iget-object v0, v7, Lf0/b;->e:LI/e0;

    .line 195
    .line 196
    iget-object v0, v0, LI/e0;->d:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast v0, LA0/h;

    .line 199
    .line 200
    invoke-virtual {v0, v1, v1}, LA0/h;->t(FF)V

    .line 201
    .line 202
    .line 203
    :try_start_0
    invoke-static {v6, v8}, LT0/g;->r(Lf0/d;Lg0/c;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 204
    .line 205
    .line 206
    iget-object v0, v7, Lf0/b;->e:LI/e0;

    .line 207
    .line 208
    iget-object v0, v0, LI/e0;->d:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v0, LA0/h;

    .line 211
    .line 212
    neg-float v1, v1

    .line 213
    invoke-virtual {v0, v1, v1}, LA0/h;->t(FF)V

    .line 214
    .line 215
    .line 216
    goto :goto_2

    .line 217
    :catchall_0
    move-exception v0

    .line 218
    iget-object v2, v7, Lf0/b;->e:LI/e0;

    .line 219
    .line 220
    iget-object v2, v2, LI/e0;->d:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast v2, LA0/h;

    .line 223
    .line 224
    neg-float v1, v1

    .line 225
    invoke-virtual {v2, v1, v1}, LA0/h;->t(FF)V

    .line 226
    .line 227
    .line 228
    throw v0

    .line 229
    :cond_3
    :goto_2
    invoke-virtual {v6}, Lw0/G;->c()V

    .line 230
    .line 231
    .line 232
    return-void
.end method
