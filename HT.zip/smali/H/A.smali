.class public final LH/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH/h;


# static fields
.field public static final b:LH/A;

.field public static final c:LH/A;

.field public static final d:LH/z;

.field public static final e:LH/z;

.field public static final f:LH/z;

.field public static final g:LH/z;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LH/A;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LH/A;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LH/A;->b:LH/A;

    .line 8
    .line 9
    new-instance v0, LH/A;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, LH/A;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LH/A;->c:LH/A;

    .line 16
    .line 17
    new-instance v0, LH/z;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 21
    .line 22
    .line 23
    sput-object v0, LH/A;->d:LH/z;

    .line 24
    .line 25
    new-instance v0, LH/z;

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 29
    .line 30
    .line 31
    sput-object v0, LH/A;->e:LH/z;

    .line 32
    .line 33
    new-instance v0, LH/z;

    .line 34
    .line 35
    const/4 v1, 0x2

    .line 36
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 37
    .line 38
    .line 39
    sput-object v0, LH/A;->f:LH/z;

    .line 40
    .line 41
    new-instance v0, LH/z;

    .line 42
    .line 43
    const/4 v1, 0x3

    .line 44
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 45
    .line 46
    .line 47
    sput-object v0, LH/A;->g:LH/z;

    .line 48
    .line 49
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LH/A;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LH/v;I)J
    .locals 1

    .line 1
    iget v0, p0, LH/A;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, LH/v;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, LH0/L;

    .line 9
    .line 10
    invoke-virtual {p1, p2}, LH0/L;->i(I)J

    .line 11
    .line 12
    .line 13
    move-result-wide p1

    .line 14
    return-wide p1

    .line 15
    :pswitch_0
    iget-object p1, p1, LH/v;->e:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p1, LH0/L;

    .line 18
    .line 19
    iget-object p1, p1, LH0/L;->a:LH0/K;

    .line 20
    .line 21
    iget-object p1, p1, LH0/K;->a:LH0/g;

    .line 22
    .line 23
    iget-object p1, p1, LH0/g;->e:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {p1, p2}, Lw/O;->n(Ljava/lang/CharSequence;I)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    invoke-static {p1, p2}, Lw/O;->m(Ljava/lang/CharSequence;I)I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    invoke-static {v0, p1}, LH0/F;->b(II)J

    .line 34
    .line 35
    .line 36
    move-result-wide p1

    .line 37
    return-wide p1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
