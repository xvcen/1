.class public final synthetic LH/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lw/a0;


# direct methods
.method public synthetic constructor <init>(Lw/a0;I)V
    .locals 0

    .line 1
    iput p2, p0, LH/D;->d:I

    iput-object p1, p0, LH/D;->e:Lw/a0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LH/D;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lc0/b;

    .line 7
    .line 8
    iget-wide v0, p1, Lc0/b;->a:J

    .line 9
    .line 10
    sget-object p1, LH/A;->d:LH/z;

    .line 11
    .line 12
    iget-object v2, p0, LH/D;->e:Lw/a0;

    .line 13
    .line 14
    invoke-interface {v2, v0, v1, p1}, Lw/a0;->a(JLH/z;)V

    .line 15
    .line 16
    .line 17
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 18
    .line 19
    return-object p1

    .line 20
    :pswitch_0
    check-cast p1, Lq0/u;

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-static {p1, v0}, Lq0/t;->g(Lq0/u;Z)J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    iget-object v2, p0, LH/D;->e:Lw/a0;

    .line 28
    .line 29
    invoke-interface {v2, v0, v1}, Lw/a0;->e(J)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :pswitch_1
    check-cast p1, Lq0/u;

    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    invoke-static {p1, v0}, Lq0/t;->g(Lq0/u;Z)J

    .line 40
    .line 41
    .line 42
    move-result-wide v0

    .line 43
    iget-object v2, p0, LH/D;->e:Lw/a0;

    .line 44
    .line 45
    invoke-interface {v2, v0, v1}, Lw/a0;->e(J)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
