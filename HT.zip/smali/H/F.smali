.class public final LH/F;
.super LP1/h;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public f:I

.field public synthetic g:Ljava/lang/Object;

.field public final synthetic h:LA1/f0;

.field public final synthetic i:LH/X;

.field public final synthetic j:Lw/a0;


# direct methods
.method public constructor <init>(LA1/f0;LH/X;Lw/a0;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/F;->h:LA1/f0;

    .line 2
    .line 3
    iput-object p2, p0, LH/F;->i:LH/X;

    .line 4
    .line 5
    iput-object p3, p0, LH/F;->j:Lw/a0;

    .line 6
    .line 7
    invoke-direct {p0, p4}, LP1/h;-><init>(LN1/c;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lq0/I;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/F;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/F;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/F;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 4

    .line 1
    new-instance v0, LH/F;

    .line 2
    .line 3
    iget-object v1, p0, LH/F;->i:LH/X;

    .line 4
    .line 5
    iget-object v2, p0, LH/F;->j:Lw/a0;

    .line 6
    .line 7
    iget-object v3, p0, LH/F;->h:LA1/f0;

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2, p1}, LH/F;-><init>(LA1/f0;LH/X;Lw/a0;LN1/c;)V

    .line 10
    .line 11
    .line 12
    iput-object p2, v0, LH/F;->g:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LH/F;->f:I

    .line 4
    .line 5
    const/4 v2, 0x4

    .line 6
    const/4 v3, 0x3

    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x1

    .line 9
    sget-object v6, LO1/a;->d:LO1/a;

    .line 10
    .line 11
    if-eqz v1, :cond_3

    .line 12
    .line 13
    if-eq v1, v5, :cond_2

    .line 14
    .line 15
    if-eq v1, v4, :cond_1

    .line 16
    .line 17
    if-eq v1, v3, :cond_1

    .line 18
    .line 19
    if-ne v1, v2, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 25
    .line 26
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw v1

    .line 30
    :cond_1
    :goto_0
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    goto/16 :goto_6

    .line 34
    .line 35
    :cond_2
    iget-object v1, v0, LH/F;->g:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Lq0/I;

    .line 38
    .line 39
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    move-object/from16 v7, p1

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_3
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    iget-object v1, v0, LH/F;->g:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v1, Lq0/I;

    .line 51
    .line 52
    iput-object v1, v0, LH/F;->g:Ljava/lang/Object;

    .line 53
    .line 54
    iput v5, v0, LH/F;->f:I

    .line 55
    .line 56
    invoke-static {v1, v0}, LX1/a;->s(Lq0/I;LP1/a;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v7

    .line 60
    if-ne v7, v6, :cond_4

    .line 61
    .line 62
    goto/16 :goto_5

    .line 63
    .line 64
    :cond_4
    :goto_1
    check-cast v7, Lq0/l;

    .line 65
    .line 66
    iget-object v8, v0, LH/F;->h:LA1/f0;

    .line 67
    .line 68
    iget-object v9, v8, LA1/f0;->b:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v9, Lx0/J0;

    .line 71
    .line 72
    iget-object v10, v8, LA1/f0;->c:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v10, Lq0/u;

    .line 75
    .line 76
    iget-object v11, v7, Lq0/l;->a:Ljava/lang/Object;

    .line 77
    .line 78
    const/4 v12, 0x0

    .line 79
    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v11

    .line 83
    check-cast v11, Lq0/u;

    .line 84
    .line 85
    if-eqz v10, :cond_5

    .line 86
    .line 87
    iget-wide v13, v11, Lq0/u;->b:J

    .line 88
    .line 89
    move-wide v15, v13

    .line 90
    iget-wide v12, v10, Lq0/u;->b:J

    .line 91
    .line 92
    sub-long v13, v15, v12

    .line 93
    .line 94
    invoke-interface {v9}, Lx0/J0;->b()J

    .line 95
    .line 96
    .line 97
    move-result-wide v15

    .line 98
    cmp-long v12, v13, v15

    .line 99
    .line 100
    if-gez v12, :cond_5

    .line 101
    .line 102
    iget v12, v10, Lq0/u;->i:I

    .line 103
    .line 104
    invoke-static {v9, v12}, Lp/E;->f(Lx0/J0;I)F

    .line 105
    .line 106
    .line 107
    move-result v9

    .line 108
    iget-wide v12, v10, Lq0/u;->c:J

    .line 109
    .line 110
    iget-wide v14, v11, Lq0/u;->c:J

    .line 111
    .line 112
    invoke-static {v12, v13, v14, v15}, Lc0/b;->d(JJ)J

    .line 113
    .line 114
    .line 115
    move-result-wide v12

    .line 116
    invoke-static {v12, v13}, Lc0/b;->c(J)F

    .line 117
    .line 118
    .line 119
    move-result v10

    .line 120
    cmpg-float v9, v10, v9

    .line 121
    .line 122
    if-gez v9, :cond_5

    .line 123
    .line 124
    iget v9, v8, LA1/f0;->a:I

    .line 125
    .line 126
    add-int/2addr v9, v5

    .line 127
    iput v9, v8, LA1/f0;->a:I

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_5
    iput v5, v8, LA1/f0;->a:I

    .line 131
    .line 132
    :goto_2
    iput-object v11, v8, LA1/f0;->c:Ljava/lang/Object;

    .line 133
    .line 134
    invoke-static {v7}, La/a;->z(Lq0/l;)Z

    .line 135
    .line 136
    .line 137
    move-result v9

    .line 138
    const/4 v10, 0x0

    .line 139
    if-eqz v9, :cond_8

    .line 140
    .line 141
    iget v11, v7, Lq0/l;->d:I

    .line 142
    .line 143
    and-int/lit8 v11, v11, 0x21

    .line 144
    .line 145
    if-eqz v11, :cond_8

    .line 146
    .line 147
    iget-object v11, v7, Lq0/l;->a:Ljava/lang/Object;

    .line 148
    .line 149
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 150
    .line 151
    .line 152
    move-result v12

    .line 153
    const/4 v13, 0x0

    .line 154
    :goto_3
    if-ge v13, v12, :cond_7

    .line 155
    .line 156
    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v14

    .line 160
    check-cast v14, Lq0/u;

    .line 161
    .line 162
    invoke-virtual {v14}, Lq0/u;->b()Z

    .line 163
    .line 164
    .line 165
    move-result v14

    .line 166
    if-eqz v14, :cond_6

    .line 167
    .line 168
    goto :goto_4

    .line 169
    :cond_6
    add-int/lit8 v13, v13, 0x1

    .line 170
    .line 171
    goto :goto_3

    .line 172
    :cond_7
    iput-object v10, v0, LH/F;->g:Ljava/lang/Object;

    .line 173
    .line 174
    iput v4, v0, LH/F;->f:I

    .line 175
    .line 176
    iget-object v2, v0, LH/F;->i:LH/X;

    .line 177
    .line 178
    invoke-static {v1, v2, v8, v7, v0}, LX1/a;->X(Lq0/I;LH/X;LA1/f0;Lq0/l;LP1/a;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    if-ne v1, v6, :cond_a

    .line 183
    .line 184
    goto :goto_5

    .line 185
    :cond_8
    :goto_4
    if-nez v9, :cond_a

    .line 186
    .line 187
    iget v4, v8, LA1/f0;->a:I

    .line 188
    .line 189
    iget-object v8, v0, LH/F;->j:Lw/a0;

    .line 190
    .line 191
    if-ne v4, v5, :cond_9

    .line 192
    .line 193
    iput-object v10, v0, LH/F;->g:Ljava/lang/Object;

    .line 194
    .line 195
    iput v3, v0, LH/F;->f:I

    .line 196
    .line 197
    invoke-static {v1, v8, v7, v0}, LX1/a;->l0(Lq0/I;Lw/a0;Lq0/l;LP1/a;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    if-ne v1, v6, :cond_a

    .line 202
    .line 203
    goto :goto_5

    .line 204
    :cond_9
    iput-object v10, v0, LH/F;->g:Ljava/lang/Object;

    .line 205
    .line 206
    iput v2, v0, LH/F;->f:I

    .line 207
    .line 208
    invoke-static {v1, v8, v7, v4, v0}, LX1/a;->y(Lq0/I;Lw/a0;Lq0/l;ILP1/a;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v1

    .line 212
    if-ne v1, v6, :cond_a

    .line 213
    .line 214
    :goto_5
    return-object v6

    .line 215
    :cond_a
    :goto_6
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 216
    .line 217
    return-object v1
.end method
