.class public final LH/J;
.super LP1/h;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public f:I

.field public synthetic g:Ljava/lang/Object;

.field public final synthetic h:J

.field public final synthetic i:LV1/r;


# direct methods
.method public constructor <init>(JLV1/r;LN1/c;)V
    .locals 0

    .line 1
    iput-wide p1, p0, LH/J;->h:J

    .line 2
    .line 3
    iput-object p3, p0, LH/J;->i:LV1/r;

    .line 4
    .line 5
    invoke-direct {p0, p4}, LP1/h;-><init>(LN1/c;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lq0/I;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/J;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/J;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/J;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 4

    .line 1
    new-instance v0, LH/J;

    .line 2
    .line 3
    iget-wide v1, p0, LH/J;->h:J

    .line 4
    .line 5
    iget-object v3, p0, LH/J;->i:LV1/r;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, v3, p1}, LH/J;-><init>(JLV1/r;LN1/c;)V

    .line 8
    .line 9
    .line 10
    iput-object p2, v0, LH/J;->g:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LH/J;->f:I

    .line 2
    .line 3
    iget-object v1, p0, LH/J;->i:LV1/r;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-ne v0, v2, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, LH/J;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lq0/I;

    .line 13
    .line 14
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    .line 20
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object p1, p0, LH/J;->g:Ljava/lang/Object;

    .line 30
    .line 31
    move-object v0, p1

    .line 32
    check-cast v0, Lq0/I;

    .line 33
    .line 34
    new-instance p1, LA1/e;

    .line 35
    .line 36
    const/4 v3, 0x7

    .line 37
    invoke-direct {p1, v3, v1}, LA1/e;-><init>(ILjava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, LH/J;->g:Ljava/lang/Object;

    .line 41
    .line 42
    iput v2, p0, LH/J;->f:I

    .line 43
    .line 44
    iget-wide v2, p0, LH/J;->h:J

    .line 45
    .line 46
    invoke-static {v0, v2, v3, p1, p0}, Lp/E;->c(Lq0/I;JLA1/e;LP1/a;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    sget-object v2, LO1/a;->d:LO1/a;

    .line 51
    .line 52
    if-ne p1, v2, :cond_2

    .line 53
    .line 54
    return-object v2

    .line 55
    :cond_2
    :goto_0
    check-cast p1, Lq0/u;

    .line 56
    .line 57
    if-eqz p1, :cond_3

    .line 58
    .line 59
    iget-wide v1, v1, LV1/r;->d:J

    .line 60
    .line 61
    const-wide v3, 0x7fffffff7fffffffL

    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    and-long/2addr v1, v3

    .line 67
    const-wide v3, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    cmp-long p1, v1, v3

    .line 73
    .line 74
    if-eqz p1, :cond_3

    .line 75
    .line 76
    sget-object p1, LH/j;->e:LH/j;

    .line 77
    .line 78
    return-object p1

    .line 79
    :cond_3
    iget-object p1, v0, Lq0/I;->i:Lq0/K;

    .line 80
    .line 81
    iget-object p1, p1, Lq0/K;->v:Lq0/l;

    .line 82
    .line 83
    iget-object p1, p1, Lq0/l;->a:Ljava/lang/Object;

    .line 84
    .line 85
    invoke-static {p1}, LK1/m;->t0(Ljava/util/List;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    check-cast p1, Lq0/u;

    .line 90
    .line 91
    invoke-static {p1}, Lq0/t;->d(Lq0/u;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_4

    .line 96
    .line 97
    invoke-virtual {p1}, Lq0/u;->a()V

    .line 98
    .line 99
    .line 100
    sget-object p1, LH/j;->d:LH/j;

    .line 101
    .line 102
    return-object p1

    .line 103
    :cond_4
    sget-object p1, LH/j;->g:LH/j;

    .line 104
    .line 105
    return-object p1
.end method
