.class public final synthetic LH/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/f;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:LJ1/c;


# direct methods
.method public synthetic constructor <init>(LU1/c;Lo/d;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    iput v0, p0, LH/O;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH/O;->f:LJ1/c;

    iput-object p2, p0, LH/O;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;LJ1/c;I)V
    .locals 0

    .line 2
    iput p3, p0, LH/O;->d:I

    iput-object p1, p0, LH/O;->e:Ljava/lang/Object;

    iput-object p2, p0, LH/O;->f:LJ1/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LH/O;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LH/O;->f:LJ1/c;

    .line 7
    .line 8
    check-cast v0, LU1/c;

    .line 9
    .line 10
    iget-object v1, p0, LH/O;->e:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lo/d;

    .line 13
    .line 14
    check-cast p1, Ls/r;

    .line 15
    .line 16
    check-cast p2, LI/r;

    .line 17
    .line 18
    check-cast p3, Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    and-int/lit8 p3, p1, 0x11

    .line 25
    .line 26
    const/16 v2, 0x10

    .line 27
    .line 28
    const/4 v3, 0x0

    .line 29
    const/4 v4, 0x1

    .line 30
    if-eq p3, v2, :cond_0

    .line 31
    .line 32
    move p3, v4

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    move p3, v3

    .line 35
    :goto_0
    and-int/2addr p1, v4

    .line 36
    invoke-virtual {p2, p1, p3}, LI/r;->N(IZ)Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    if-eqz p1, :cond_2

    .line 41
    .line 42
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    sget-object p3, LI/m;->a:LI/h;

    .line 47
    .line 48
    if-ne p1, p3, :cond_1

    .line 49
    .line 50
    new-instance p1, Lo/f;

    .line 51
    .line 52
    invoke-direct {p1}, Lo/f;-><init>()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p2, p1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_1
    check-cast p1, Lo/f;

    .line 59
    .line 60
    iget-object p3, p1, Lo/f;->a:LU/t;

    .line 61
    .line 62
    invoke-virtual {p3}, LU/t;->clear()V

    .line 63
    .line 64
    .line 65
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1, v1, p2, v3}, Lo/f;->a(Lo/d;LI/r;I)V

    .line 69
    .line 70
    .line 71
    goto :goto_1

    .line 72
    :cond_2
    invoke-virtual {p2}, LI/r;->Q()V

    .line 73
    .line 74
    .line 75
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 76
    .line 77
    return-object p1

    .line 78
    :pswitch_0
    iget-object v0, p0, LH/O;->e:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Landroid/text/Spannable;

    .line 81
    .line 82
    iget-object v1, p0, LH/O;->f:LJ1/c;

    .line 83
    .line 84
    check-cast v1, LP0/c;

    .line 85
    .line 86
    check-cast p1, LH0/G;

    .line 87
    .line 88
    check-cast p2, Ljava/lang/Integer;

    .line 89
    .line 90
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 91
    .line 92
    .line 93
    move-result p2

    .line 94
    check-cast p3, Ljava/lang/Integer;

    .line 95
    .line 96
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 97
    .line 98
    .line 99
    move-result p3

    .line 100
    new-instance v2, LK0/b;

    .line 101
    .line 102
    iget-object v3, p1, LH0/G;->f:LL0/b;

    .line 103
    .line 104
    iget-object v4, p1, LH0/G;->c:LL0/k;

    .line 105
    .line 106
    if-nez v4, :cond_3

    .line 107
    .line 108
    sget-object v4, LL0/k;->f:LL0/k;

    .line 109
    .line 110
    :cond_3
    iget-object v5, p1, LH0/G;->d:LL0/i;

    .line 111
    .line 112
    if-eqz v5, :cond_4

    .line 113
    .line 114
    iget v5, v5, LL0/i;->a:I

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_4
    const/4 v5, 0x0

    .line 118
    :goto_2
    iget-object p1, p1, LH0/G;->e:LL0/j;

    .line 119
    .line 120
    if-eqz p1, :cond_5

    .line 121
    .line 122
    iget p1, p1, LL0/j;->a:I

    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_5
    const p1, 0xffff

    .line 126
    .line 127
    .line 128
    :goto_3
    iget-object v1, v1, LP0/c;->d:LP0/d;

    .line 129
    .line 130
    iget-object v6, v1, LP0/d;->e:LL0/d;

    .line 131
    .line 132
    check-cast v6, LL0/e;

    .line 133
    .line 134
    invoke-virtual {v6, v3, v4, v5, p1}, LL0/e;->b(LL0/b;LL0/k;II)LL0/p;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    instance-of v3, p1, LL0/p;

    .line 139
    .line 140
    const-string v4, "null cannot be cast to non-null type android.graphics.Typeface"

    .line 141
    .line 142
    if-nez v3, :cond_6

    .line 143
    .line 144
    new-instance v3, LI/e0;

    .line 145
    .line 146
    iget-object v5, v1, LP0/d;->j:LI/e0;

    .line 147
    .line 148
    invoke-direct {v3, p1, v5}, LI/e0;-><init>(LL0/p;LI/e0;)V

    .line 149
    .line 150
    .line 151
    iput-object v3, v1, LP0/d;->j:LI/e0;

    .line 152
    .line 153
    iget-object p1, v3, LI/e0;->f:Ljava/lang/Object;

    .line 154
    .line 155
    invoke-static {p1, v4}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    check-cast p1, Landroid/graphics/Typeface;

    .line 159
    .line 160
    goto :goto_4

    .line 161
    :cond_6
    iget-object p1, p1, LL0/p;->d:Ljava/lang/Object;

    .line 162
    .line 163
    invoke-static {p1, v4}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    check-cast p1, Landroid/graphics/Typeface;

    .line 167
    .line 168
    :goto_4
    const/4 v1, 0x1

    .line 169
    invoke-direct {v2, v1, p1}, LK0/b;-><init>(ILjava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    const/16 p1, 0x21

    .line 173
    .line 174
    invoke-interface {v0, v2, p2, p3, p1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 175
    .line 176
    .line 177
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 178
    .line 179
    return-object p1

    .line 180
    :pswitch_1
    iget-object v0, p0, LH/O;->e:Ljava/lang/Object;

    .line 181
    .line 182
    check-cast v0, LU1/a;

    .line 183
    .line 184
    iget-object v1, p0, LH/O;->f:LJ1/c;

    .line 185
    .line 186
    check-cast v1, LU1/c;

    .line 187
    .line 188
    check-cast p1, LW/q;

    .line 189
    .line 190
    check-cast p2, LI/r;

    .line 191
    .line 192
    check-cast p3, Ljava/lang/Integer;

    .line 193
    .line 194
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    .line 196
    .line 197
    const p1, 0x2d4acc1b

    .line 198
    .line 199
    .line 200
    invoke-virtual {p2, p1}, LI/r;->U(I)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    sget-object p3, LI/m;->a:LI/h;

    .line 208
    .line 209
    if-ne p1, p3, :cond_7

    .line 210
    .line 211
    invoke-static {v0}, LI/k;->l(LU1/a;)LI/F;

    .line 212
    .line 213
    .line 214
    move-result-object p1

    .line 215
    invoke-virtual {p2, p1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    :cond_7
    check-cast p1, LI/a1;

    .line 219
    .line 220
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    if-ne v0, p3, :cond_8

    .line 225
    .line 226
    new-instance v0, Ll/c;

    .line 227
    .line 228
    invoke-interface {p1}, LI/a1;->getValue()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v2

    .line 232
    check-cast v2, Lc0/b;

    .line 233
    .line 234
    iget-wide v2, v2, Lc0/b;->a:J

    .line 235
    .line 236
    new-instance v4, Lc0/b;

    .line 237
    .line 238
    invoke-direct {v4, v2, v3}, Lc0/b;-><init>(J)V

    .line 239
    .line 240
    .line 241
    sget-object v2, LH/U;->b:LF/r;

    .line 242
    .line 243
    sget-wide v5, LH/U;->c:J

    .line 244
    .line 245
    new-instance v3, Lc0/b;

    .line 246
    .line 247
    invoke-direct {v3, v5, v6}, Lc0/b;-><init>(J)V

    .line 248
    .line 249
    .line 250
    invoke-direct {v0, v4, v2, v3}, Ll/c;-><init>(Ljava/lang/Object;LF/r;Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {p2, v0}, LI/r;->d0(Ljava/lang/Object;)V

    .line 254
    .line 255
    .line 256
    :cond_8
    check-cast v0, Ll/c;

    .line 257
    .line 258
    invoke-virtual {p2, v0}, LI/r;->g(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v2

    .line 262
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v3

    .line 266
    if-nez v2, :cond_9

    .line 267
    .line 268
    if-ne v3, p3, :cond_a

    .line 269
    .line 270
    :cond_9
    new-instance v3, LH/T;

    .line 271
    .line 272
    const/4 v2, 0x0

    .line 273
    invoke-direct {v3, p1, v0, v2}, LH/T;-><init>(LI/a1;Ll/c;LN1/c;)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {p2, v3}, LI/r;->d0(Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    :cond_a
    check-cast v3, LU1/e;

    .line 280
    .line 281
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 282
    .line 283
    invoke-static {p2, v3, p1}, LI/k;->d(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 284
    .line 285
    .line 286
    iget-object p1, v0, Ll/c;->c:Ll/i;

    .line 287
    .line 288
    invoke-virtual {p2, p1}, LI/r;->e(Ljava/lang/Object;)Z

    .line 289
    .line 290
    .line 291
    move-result v0

    .line 292
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    move-result-object v2

    .line 296
    if-nez v0, :cond_b

    .line 297
    .line 298
    if-ne v2, p3, :cond_c

    .line 299
    .line 300
    :cond_b
    new-instance v2, LH/P;

    .line 301
    .line 302
    const/4 p3, 0x0

    .line 303
    invoke-direct {v2, p1, p3}, LH/P;-><init>(LI/a1;I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p2, v2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 307
    .line 308
    .line 309
    :cond_c
    check-cast v2, LU1/a;

    .line 310
    .line 311
    invoke-interface {v1, v2}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object p1

    .line 315
    check-cast p1, LW/q;

    .line 316
    .line 317
    const/4 p3, 0x0

    .line 318
    invoke-virtual {p2, p3}, LI/r;->p(Z)V

    .line 319
    .line 320
    .line 321
    return-object p1

    .line 322
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
