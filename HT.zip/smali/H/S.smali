.class public final LH/S;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf2/e;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LH/S;->d:I

    iput-object p2, p0, LH/S;->e:Ljava/lang/Object;

    iput-object p3, p0, LH/S;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lf2/c;LV1/s;Lf2/e;)V
    .locals 0

    const/4 p1, 0x1

    iput p1, p0, LH/S;->d:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LH/S;->e:Ljava/lang/Object;

    iput-object p3, p0, LH/S;->f:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LH/S;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    instance-of v0, p2, Lf2/k;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    move-object v0, p2

    .line 11
    check-cast v0, Lf2/k;

    .line 12
    .line 13
    iget v1, v0, Lf2/k;->i:I

    .line 14
    .line 15
    const/high16 v2, -0x80000000

    .line 16
    .line 17
    and-int v3, v1, v2

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    sub-int/2addr v1, v2

    .line 22
    iput v1, v0, Lf2/k;->i:I

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    new-instance v0, Lf2/k;

    .line 26
    .line 27
    invoke-direct {v0, p0, p2}, Lf2/k;-><init>(LH/S;LN1/c;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    iget-object p2, v0, Lf2/k;->h:Ljava/lang/Object;

    .line 31
    .line 32
    iget v1, v0, Lf2/k;->i:I

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    if-eqz v1, :cond_2

    .line 36
    .line 37
    if-ne v1, v2, :cond_1

    .line 38
    .line 39
    iget-object p1, v0, Lf2/k;->k:Ljava/lang/Object;

    .line 40
    .line 41
    iget-object v0, v0, Lf2/k;->g:LH/S;

    .line 42
    .line 43
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 50
    .line 51
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw p1

    .line 55
    :cond_2
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iget-object p2, p0, LH/S;->e:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p2, LU1/e;

    .line 61
    .line 62
    iput-object p0, v0, Lf2/k;->g:LH/S;

    .line 63
    .line 64
    iput-object p1, v0, Lf2/k;->k:Ljava/lang/Object;

    .line 65
    .line 66
    iput v2, v0, Lf2/k;->i:I

    .line 67
    .line 68
    invoke-interface {p2, p1, v0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p2

    .line 72
    sget-object v0, LO1/a;->d:LO1/a;

    .line 73
    .line 74
    if-ne p2, v0, :cond_3

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_3
    move-object v0, p0

    .line 78
    :goto_1
    check-cast p2, Ljava/lang/Boolean;

    .line 79
    .line 80
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 81
    .line 82
    .line 83
    move-result p2

    .line 84
    if-nez p2, :cond_4

    .line 85
    .line 86
    sget-object v0, LJ1/m;->a:LJ1/m;

    .line 87
    .line 88
    :goto_2
    return-object v0

    .line 89
    :cond_4
    iget-object p2, v0, LH/S;->f:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast p2, LV1/s;

    .line 92
    .line 93
    iput-object p1, p2, LV1/s;->d:Ljava/lang/Object;

    .line 94
    .line 95
    new-instance p1, Lg2/a;

    .line 96
    .line 97
    invoke-direct {p1, v0}, Lg2/a;-><init>(Lf2/e;)V

    .line 98
    .line 99
    .line 100
    throw p1

    .line 101
    :pswitch_0
    iget-object v0, p0, LH/S;->e:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v0, LV1/s;

    .line 104
    .line 105
    instance-of v1, p2, Lf2/b;

    .line 106
    .line 107
    if-eqz v1, :cond_5

    .line 108
    .line 109
    move-object v1, p2

    .line 110
    check-cast v1, Lf2/b;

    .line 111
    .line 112
    iget v2, v1, Lf2/b;->i:I

    .line 113
    .line 114
    const/high16 v3, -0x80000000

    .line 115
    .line 116
    and-int v4, v2, v3

    .line 117
    .line 118
    if-eqz v4, :cond_5

    .line 119
    .line 120
    sub-int/2addr v2, v3

    .line 121
    iput v2, v1, Lf2/b;->i:I

    .line 122
    .line 123
    goto :goto_3

    .line 124
    :cond_5
    new-instance v1, Lf2/b;

    .line 125
    .line 126
    invoke-direct {v1, p0, p2}, Lf2/b;-><init>(LH/S;LN1/c;)V

    .line 127
    .line 128
    .line 129
    :goto_3
    iget-object p2, v1, Lf2/b;->g:Ljava/lang/Object;

    .line 130
    .line 131
    iget v2, v1, Lf2/b;->i:I

    .line 132
    .line 133
    sget-object v3, LJ1/m;->a:LJ1/m;

    .line 134
    .line 135
    const/4 v4, 0x1

    .line 136
    if-eqz v2, :cond_7

    .line 137
    .line 138
    if-ne v2, v4, :cond_6

    .line 139
    .line 140
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    goto :goto_4

    .line 144
    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 145
    .line 146
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 147
    .line 148
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    throw p1

    .line 152
    :cond_7
    invoke-static {p2}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    iget-object p2, v0, LV1/s;->d:Ljava/lang/Object;

    .line 156
    .line 157
    sget-object v2, Lg2/c;->b:Lh2/t;

    .line 158
    .line 159
    if-eq p2, v2, :cond_8

    .line 160
    .line 161
    invoke-static {p2, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result p2

    .line 165
    if-nez p2, :cond_9

    .line 166
    .line 167
    :cond_8
    iput-object p1, v0, LV1/s;->d:Ljava/lang/Object;

    .line 168
    .line 169
    iget-object p2, p0, LH/S;->f:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast p2, Lf2/e;

    .line 172
    .line 173
    iput v4, v1, Lf2/b;->i:I

    .line 174
    .line 175
    invoke-interface {p2, p1, v1}, Lf2/e;->e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    sget-object p2, LO1/a;->d:LO1/a;

    .line 180
    .line 181
    if-ne p1, p2, :cond_9

    .line 182
    .line 183
    move-object v3, p2

    .line 184
    :cond_9
    :goto_4
    return-object v3

    .line 185
    :pswitch_1
    check-cast p1, Lc0/b;

    .line 186
    .line 187
    iget-wide v0, p1, Lc0/b;->a:J

    .line 188
    .line 189
    iget-object p1, p0, LH/S;->e:Ljava/lang/Object;

    .line 190
    .line 191
    check-cast p1, Ll/c;

    .line 192
    .line 193
    invoke-virtual {p1}, Ll/c;->c()Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v2

    .line 197
    check-cast v2, Lc0/b;

    .line 198
    .line 199
    iget-wide v2, v2, Lc0/b;->a:J

    .line 200
    .line 201
    const-wide v4, 0x7fffffff7fffffffL

    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    and-long/2addr v2, v4

    .line 207
    const-wide v6, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    cmp-long v2, v2, v6

    .line 213
    .line 214
    sget-object v3, LJ1/m;->a:LJ1/m;

    .line 215
    .line 216
    if-eqz v2, :cond_b

    .line 217
    .line 218
    and-long/2addr v4, v0

    .line 219
    cmp-long v2, v4, v6

    .line 220
    .line 221
    if-eqz v2, :cond_b

    .line 222
    .line 223
    invoke-virtual {p1}, Ll/c;->c()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    check-cast v2, Lc0/b;

    .line 228
    .line 229
    iget-wide v4, v2, Lc0/b;->a:J

    .line 230
    .line 231
    const-wide v6, 0xffffffffL

    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    and-long/2addr v4, v6

    .line 237
    long-to-int v2, v4

    .line 238
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 239
    .line 240
    .line 241
    move-result v2

    .line 242
    and-long v4, v0, v6

    .line 243
    .line 244
    long-to-int v4, v4

    .line 245
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 246
    .line 247
    .line 248
    move-result v4

    .line 249
    cmpg-float v2, v2, v4

    .line 250
    .line 251
    if-nez v2, :cond_a

    .line 252
    .line 253
    goto :goto_5

    .line 254
    :cond_a
    iget-object p2, p0, LH/S;->f:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast p2, Lc2/s;

    .line 257
    .line 258
    new-instance v2, LH/Q;

    .line 259
    .line 260
    const/4 v4, 0x0

    .line 261
    invoke-direct {v2, p1, v0, v1, v4}, LH/Q;-><init>(Ll/c;JLN1/c;)V

    .line 262
    .line 263
    .line 264
    const/4 p1, 0x3

    .line 265
    invoke-static {p2, v4, v2, p1}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 266
    .line 267
    .line 268
    goto :goto_6

    .line 269
    :cond_b
    :goto_5
    new-instance v2, Lc0/b;

    .line 270
    .line 271
    invoke-direct {v2, v0, v1}, Lc0/b;-><init>(J)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {p1, v2, p2}, Ll/c;->d(Lc0/b;LN1/c;)Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    sget-object p2, LO1/a;->d:LO1/a;

    .line 279
    .line 280
    if-ne p1, p2, :cond_c

    .line 281
    .line 282
    move-object v3, p1

    .line 283
    :cond_c
    :goto_6
    return-object v3

    .line 284
    nop

    .line 285
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
