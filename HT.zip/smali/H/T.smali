.class public final LH/T;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LI/a1;

.field public final synthetic k:Ll/c;


# direct methods
.method public constructor <init>(LI/a1;Ll/c;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/T;->j:LI/a1;

    .line 2
    .line 3
    iput-object p2, p0, LH/T;->k:Ll/c;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/T;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/T;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/T;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 3

    .line 1
    new-instance v0, LH/T;

    .line 2
    .line 3
    iget-object v1, p0, LH/T;->j:LI/a1;

    .line 4
    .line 5
    iget-object v2, p0, LH/T;->k:Ll/c;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, p1}, LH/T;-><init>(LI/a1;Ll/c;LN1/c;)V

    .line 8
    .line 9
    .line 10
    iput-object p2, v0, LH/T;->i:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LH/T;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, LH/T;->i:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p1, Lc2/s;

    .line 26
    .line 27
    new-instance v0, LH/P;

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    iget-object v3, p0, LH/T;->j:LI/a1;

    .line 31
    .line 32
    invoke-direct {v0, v3, v2}, LH/P;-><init>(LI/a1;I)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0}, LI/k;->v(LU1/a;)LA0/h;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    new-instance v2, LH/S;

    .line 40
    .line 41
    iget-object v3, p0, LH/T;->k:Ll/c;

    .line 42
    .line 43
    const/4 v4, 0x0

    .line 44
    invoke-direct {v2, v4, v3, p1}, LH/S;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iput v1, p0, LH/T;->h:I

    .line 48
    .line 49
    invoke-virtual {v0, v2, p0}, LA0/h;->d(Lf2/e;LN1/c;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    sget-object v0, LO1/a;->d:LO1/a;

    .line 54
    .line 55
    if-ne p1, v0, :cond_2

    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_2
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 59
    .line 60
    return-object p1
.end method
