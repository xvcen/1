.class public abstract LH/U;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ll/k;

.field public static final b:LF/r;

.field public static final c:J

.field public static final d:Ll/C;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, Ll/k;

    .line 2
    .line 3
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 4
    .line 5
    invoke-direct {v0, v1, v1}, Ll/k;-><init>(FF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LH/U;->a:Ll/k;

    .line 9
    .line 10
    new-instance v0, LA1/v;

    .line 11
    .line 12
    const/16 v1, 0xf

    .line 13
    .line 14
    invoke-direct {v0, v1}, LA1/v;-><init>(I)V

    .line 15
    .line 16
    .line 17
    new-instance v1, LA1/v;

    .line 18
    .line 19
    const/16 v2, 0x10

    .line 20
    .line 21
    invoke-direct {v1, v2}, LA1/v;-><init>(I)V

    .line 22
    .line 23
    .line 24
    new-instance v2, LF/r;

    .line 25
    .line 26
    const/16 v3, 0xf

    .line 27
    .line 28
    invoke-direct {v2, v3, v0, v1}, LF/r;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    sput-object v2, LH/U;->b:LF/r;

    .line 32
    .line 33
    const v0, 0x3c23d70a    # 0.01f

    .line 34
    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    int-to-long v1, v1

    .line 41
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    int-to-long v3, v0

    .line 46
    const/16 v0, 0x20

    .line 47
    .line 48
    shl-long v0, v1, v0

    .line 49
    .line 50
    const-wide v5, 0xffffffffL

    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    and-long v2, v3, v5

    .line 56
    .line 57
    or-long/2addr v0, v2

    .line 58
    sput-wide v0, LH/U;->c:J

    .line 59
    .line 60
    new-instance v2, Ll/C;

    .line 61
    .line 62
    new-instance v3, Lc0/b;

    .line 63
    .line 64
    invoke-direct {v3, v0, v1}, Lc0/b;-><init>(J)V

    .line 65
    .line 66
    .line 67
    invoke-direct {v2, v3}, Ll/C;-><init>(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    sput-object v2, LH/U;->d:Ll/C;

    .line 71
    .line 72
    return-void
.end method
