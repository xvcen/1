.class public abstract LH/V;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LI/B;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LA1/u;

    .line 2
    .line 3
    const/16 v1, 0x14

    .line 4
    .line 5
    invoke-direct {v0, v1}, LA1/u;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, LI/B;

    .line 9
    .line 10
    invoke-direct {v1, v0}, LI/B;-><init>(LU1/a;)V

    .line 11
    .line 12
    .line 13
    sput-object v1, LH/V;->a:LI/B;

    .line 14
    .line 15
    return-void
.end method
