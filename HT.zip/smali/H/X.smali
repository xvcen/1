.class public final LH/X;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:Z

.field public c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LH/m0;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LH/X;->a:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, LH/X;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, LH/X;->b:Z

    return-void
.end method

.method public constructor <init>(ZLH/y;LH/v;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LH/X;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, LH/X;->b:Z

    .line 3
    iput-object p2, p0, LH/X;->c:Ljava/lang/Object;

    .line 4
    iput-object p3, p0, LH/X;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()LH/i;
    .locals 2

    .line 1
    iget-object v0, p0, LH/X;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LH/v;

    .line 4
    .line 5
    iget v1, v0, LH/v;->b:I

    .line 6
    .line 7
    iget v0, v0, LH/v;->c:I

    .line 8
    .line 9
    if-ge v1, v0, :cond_0

    .line 10
    .line 11
    sget-object v0, LH/i;->e:LH/i;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_0
    if-le v1, v0, :cond_1

    .line 15
    .line 16
    sget-object v0, LH/i;->d:LH/i;

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_1
    sget-object v0, LH/i;->f:LH/i;

    .line 20
    .line 21
    return-object v0
.end method

.method public b()V
    .locals 2

    .line 1
    iget-boolean v0, p0, LH/X;->b:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, LH/X;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, LH/m0;

    .line 8
    .line 9
    iget-object v1, p0, LH/X;->c:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, LH0/N;

    .line 12
    .line 13
    invoke-static {v0, v1}, LH/m0;->b(LH/m0;LH0/N;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public c(LM0/x;JZLH/z;)J
    .locals 9

    .line 1
    iget-object v0, p0, LH/X;->d:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, LH/m0;

    .line 5
    .line 6
    const/4 v6, 0x0

    .line 7
    const/4 v8, 0x0

    .line 8
    move-object v2, p1

    .line 9
    move-wide v3, p2

    .line 10
    move v5, p4

    .line 11
    move-object v7, p5

    .line 12
    invoke-static/range {v1 .. v8}, LH/m0;->c(LH/m0;LM0/x;JZZLH/z;Z)J

    .line 13
    .line 14
    .line 15
    move-result-wide p1

    .line 16
    iget-object p3, p0, LH/X;->c:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p3, LH0/N;

    .line 19
    .line 20
    invoke-static {p1, p2, p3}, LH0/N;->a(JLjava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result p3

    .line 24
    if-nez p3, :cond_0

    .line 25
    .line 26
    const/4 p3, 0x0

    .line 27
    iput-boolean p3, p0, LH/X;->b:Z

    .line 28
    .line 29
    :cond_0
    invoke-static {p1, p2}, LH0/N;->c(J)Z

    .line 30
    .line 31
    .line 32
    move-result p3

    .line 33
    if-eqz p3, :cond_1

    .line 34
    .line 35
    sget-object p3, Lw/H;->f:Lw/H;

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    sget-object p3, Lw/H;->e:Lw/H;

    .line 39
    .line 40
    :goto_0
    invoke-virtual {v1, p3}, LH/m0;->q(Lw/H;)V

    .line 41
    .line 42
    .line 43
    return-wide p1
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    iget v0, p0, LH/X;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "SingleSelectionLayout(isStartHandle="

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-boolean v1, p0, LH/X;->b:Z

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", crossed="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, LH/X;->a()LH/i;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string v1, ", info=\n\t"

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, LH/X;->d:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, LH/v;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const/16 v1, 0x29

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    return-object v0

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
