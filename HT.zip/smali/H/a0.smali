.class public final synthetic LH/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LH/m0;


# direct methods
.method public synthetic constructor <init>(LH/m0;I)V
    .locals 0

    .line 1
    iput p2, p0, LH/a0;->d:I

    iput-object p1, p0, LH/a0;->e:LH/m0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LH/a0;->d:I

    .line 4
    .line 5
    iget-object v2, v0, LH/a0;->e:LH/m0;

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    move-object/from16 v1, p1

    .line 11
    .line 12
    check-cast v1, Lc0/b;

    .line 13
    .line 14
    invoke-virtual {v2}, LH/m0;->r()V

    .line 15
    .line 16
    .line 17
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 18
    .line 19
    return-object v1

    .line 20
    :pswitch_0
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, LI/I;

    .line 23
    .line 24
    new-instance v1, LB/l;

    .line 25
    .line 26
    const/4 v3, 0x4

    .line 27
    invoke-direct {v1, v3, v2}, LB/l;-><init>(ILjava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object v1

    .line 31
    :pswitch_1
    move-object/from16 v1, p1

    .line 32
    .line 33
    check-cast v1, Lu0/r;

    .line 34
    .line 35
    iget-object v3, v2, LH/m0;->d:Lw/S;

    .line 36
    .line 37
    sget-object v4, Lc0/c;->e:Lc0/c;

    .line 38
    .line 39
    if-eqz v3, :cond_7

    .line 40
    .line 41
    iget-boolean v6, v3, Lw/S;->p:Z

    .line 42
    .line 43
    if-nez v6, :cond_0

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    const/4 v3, 0x0

    .line 47
    :goto_0
    if-eqz v3, :cond_7

    .line 48
    .line 49
    iget-object v6, v2, LH/m0;->b:LM0/q;

    .line 50
    .line 51
    invoke-virtual {v2}, LH/m0;->n()LM0/x;

    .line 52
    .line 53
    .line 54
    move-result-object v7

    .line 55
    iget-wide v7, v7, LM0/x;->b:J

    .line 56
    .line 57
    sget v9, LH0/N;->c:I

    .line 58
    .line 59
    const/16 v9, 0x20

    .line 60
    .line 61
    shr-long/2addr v7, v9

    .line 62
    long-to-int v7, v7

    .line 63
    invoke-interface {v6, v7}, LM0/q;->n(I)I

    .line 64
    .line 65
    .line 66
    move-result v6

    .line 67
    iget-object v7, v2, LH/m0;->b:LM0/q;

    .line 68
    .line 69
    invoke-virtual {v2}, LH/m0;->n()LM0/x;

    .line 70
    .line 71
    .line 72
    move-result-object v8

    .line 73
    iget-wide v10, v8, LM0/x;->b:J

    .line 74
    .line 75
    const-wide v12, 0xffffffffL

    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    and-long/2addr v10, v12

    .line 81
    long-to-int v8, v10

    .line 82
    invoke-interface {v7, v8}, LM0/q;->n(I)I

    .line 83
    .line 84
    .line 85
    move-result v7

    .line 86
    iget-object v8, v2, LH/m0;->d:Lw/S;

    .line 87
    .line 88
    const-wide/16 v10, 0x0

    .line 89
    .line 90
    if-eqz v8, :cond_1

    .line 91
    .line 92
    invoke-virtual {v8}, Lw/S;->c()Lu0/r;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    if-eqz v8, :cond_1

    .line 97
    .line 98
    const/4 v14, 0x1

    .line 99
    invoke-virtual {v2, v14}, LH/m0;->l(Z)J

    .line 100
    .line 101
    .line 102
    move-result-wide v14

    .line 103
    invoke-interface {v8, v14, v15}, Lu0/r;->f0(J)J

    .line 104
    .line 105
    .line 106
    move-result-wide v14

    .line 107
    goto :goto_1

    .line 108
    :cond_1
    move-wide v14, v10

    .line 109
    :goto_1
    iget-object v8, v2, LH/m0;->d:Lw/S;

    .line 110
    .line 111
    if-eqz v8, :cond_2

    .line 112
    .line 113
    invoke-virtual {v8}, Lw/S;->c()Lu0/r;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    if-eqz v8, :cond_2

    .line 118
    .line 119
    const/4 v10, 0x0

    .line 120
    invoke-virtual {v2, v10}, LH/m0;->l(Z)J

    .line 121
    .line 122
    .line 123
    move-result-wide v10

    .line 124
    invoke-interface {v8, v10, v11}, Lu0/r;->f0(J)J

    .line 125
    .line 126
    .line 127
    move-result-wide v10

    .line 128
    :cond_2
    iget-object v8, v2, LH/m0;->d:Lw/S;

    .line 129
    .line 130
    const/16 v16, 0x0

    .line 131
    .line 132
    if-eqz v8, :cond_4

    .line 133
    .line 134
    invoke-virtual {v8}, Lw/S;->c()Lu0/r;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    if-eqz v8, :cond_4

    .line 139
    .line 140
    invoke-virtual {v3}, Lw/S;->d()Lw/p0;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    if-eqz v5, :cond_3

    .line 145
    .line 146
    iget-object v5, v5, Lw/p0;->a:LH0/L;

    .line 147
    .line 148
    invoke-virtual {v5, v6}, LH0/L;->c(I)Lc0/c;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    iget v5, v5, Lc0/c;->b:F

    .line 153
    .line 154
    goto :goto_2

    .line 155
    :cond_3
    move/from16 v5, v16

    .line 156
    .line 157
    :goto_2
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 158
    .line 159
    .line 160
    move-result v6

    .line 161
    move/from16 v17, v9

    .line 162
    .line 163
    move-wide/from16 v18, v10

    .line 164
    .line 165
    int-to-long v9, v6

    .line 166
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 167
    .line 168
    .line 169
    move-result v5

    .line 170
    int-to-long v5, v5

    .line 171
    shl-long v9, v9, v17

    .line 172
    .line 173
    and-long/2addr v5, v12

    .line 174
    or-long/2addr v5, v9

    .line 175
    invoke-interface {v8, v5, v6}, Lu0/r;->f0(J)J

    .line 176
    .line 177
    .line 178
    move-result-wide v5

    .line 179
    and-long/2addr v5, v12

    .line 180
    long-to-int v5, v5

    .line 181
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 182
    .line 183
    .line 184
    move-result v5

    .line 185
    goto :goto_3

    .line 186
    :cond_4
    move/from16 v17, v9

    .line 187
    .line 188
    move-wide/from16 v18, v10

    .line 189
    .line 190
    move/from16 v5, v16

    .line 191
    .line 192
    :goto_3
    iget-object v6, v2, LH/m0;->d:Lw/S;

    .line 193
    .line 194
    if-eqz v6, :cond_6

    .line 195
    .line 196
    invoke-virtual {v6}, Lw/S;->c()Lu0/r;

    .line 197
    .line 198
    .line 199
    move-result-object v6

    .line 200
    if-eqz v6, :cond_6

    .line 201
    .line 202
    invoke-virtual {v3}, Lw/S;->d()Lw/p0;

    .line 203
    .line 204
    .line 205
    move-result-object v8

    .line 206
    if-eqz v8, :cond_5

    .line 207
    .line 208
    iget-object v8, v8, Lw/p0;->a:LH0/L;

    .line 209
    .line 210
    invoke-virtual {v8, v7}, LH0/L;->c(I)Lc0/c;

    .line 211
    .line 212
    .line 213
    move-result-object v7

    .line 214
    iget v7, v7, Lc0/c;->b:F

    .line 215
    .line 216
    goto :goto_4

    .line 217
    :cond_5
    move/from16 v7, v16

    .line 218
    .line 219
    :goto_4
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 220
    .line 221
    .line 222
    move-result v8

    .line 223
    int-to-long v8, v8

    .line 224
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 225
    .line 226
    .line 227
    move-result v7

    .line 228
    int-to-long v10, v7

    .line 229
    shl-long v7, v8, v17

    .line 230
    .line 231
    and-long v9, v10, v12

    .line 232
    .line 233
    or-long/2addr v7, v9

    .line 234
    invoke-interface {v6, v7, v8}, Lu0/r;->f0(J)J

    .line 235
    .line 236
    .line 237
    move-result-wide v6

    .line 238
    and-long/2addr v6, v12

    .line 239
    long-to-int v6, v6

    .line 240
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 241
    .line 242
    .line 243
    move-result v16

    .line 244
    :cond_6
    move/from16 v6, v16

    .line 245
    .line 246
    shr-long v7, v14, v17

    .line 247
    .line 248
    long-to-int v7, v7

    .line 249
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 250
    .line 251
    .line 252
    move-result v8

    .line 253
    shr-long v9, v18, v17

    .line 254
    .line 255
    long-to-int v9, v9

    .line 256
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 257
    .line 258
    .line 259
    move-result v10

    .line 260
    invoke-static {v8, v10}, Ljava/lang/Math;->min(FF)F

    .line 261
    .line 262
    .line 263
    move-result v8

    .line 264
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 265
    .line 266
    .line 267
    move-result v7

    .line 268
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 269
    .line 270
    .line 271
    move-result v9

    .line 272
    invoke-static {v7, v9}, Ljava/lang/Math;->max(FF)F

    .line 273
    .line 274
    .line 275
    move-result v7

    .line 276
    invoke-static {v5, v6}, Ljava/lang/Math;->min(FF)F

    .line 277
    .line 278
    .line 279
    move-result v5

    .line 280
    and-long v9, v14, v12

    .line 281
    .line 282
    long-to-int v6, v9

    .line 283
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 284
    .line 285
    .line 286
    move-result v6

    .line 287
    and-long v9, v18, v12

    .line 288
    .line 289
    long-to-int v9, v9

    .line 290
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 291
    .line 292
    .line 293
    move-result v9

    .line 294
    invoke-static {v6, v9}, Ljava/lang/Math;->max(FF)F

    .line 295
    .line 296
    .line 297
    move-result v6

    .line 298
    const/16 v9, 0x19

    .line 299
    .line 300
    int-to-float v9, v9

    .line 301
    iget-object v3, v3, Lw/S;->a:Lw/Z;

    .line 302
    .line 303
    iget-object v3, v3, Lw/Z;->g:LT0/c;

    .line 304
    .line 305
    invoke-interface {v3}, LT0/c;->g()F

    .line 306
    .line 307
    .line 308
    move-result v3

    .line 309
    mul-float/2addr v3, v9

    .line 310
    add-float/2addr v3, v6

    .line 311
    new-instance v6, Lc0/c;

    .line 312
    .line 313
    invoke-direct {v6, v8, v5, v7, v3}, Lc0/c;-><init>(FFFF)V

    .line 314
    .line 315
    .line 316
    goto :goto_5

    .line 317
    :cond_7
    move-object v6, v4

    .line 318
    :goto_5
    iget-object v2, v2, LH/m0;->d:Lw/S;

    .line 319
    .line 320
    if-eqz v2, :cond_a

    .line 321
    .line 322
    invoke-virtual {v2}, Lw/S;->c()Lu0/r;

    .line 323
    .line 324
    .line 325
    move-result-object v2

    .line 326
    if-nez v2, :cond_8

    .line 327
    .line 328
    goto :goto_6

    .line 329
    :cond_8
    invoke-interface {v2}, Lu0/r;->T()Z

    .line 330
    .line 331
    .line 332
    move-result v3

    .line 333
    if-eqz v3, :cond_b

    .line 334
    .line 335
    invoke-interface {v1}, Lu0/r;->T()Z

    .line 336
    .line 337
    .line 338
    move-result v3

    .line 339
    if-nez v3, :cond_9

    .line 340
    .line 341
    goto :goto_7

    .line 342
    :cond_9
    invoke-virtual {v6}, Lc0/c;->d()J

    .line 343
    .line 344
    .line 345
    move-result-wide v3

    .line 346
    invoke-static {v2}, Lu0/v;->e(Lu0/r;)Lu0/r;

    .line 347
    .line 348
    .line 349
    move-result-object v2

    .line 350
    invoke-interface {v1, v2, v3, v4}, Lu0/r;->r0(Lu0/r;J)J

    .line 351
    .line 352
    .line 353
    move-result-wide v1

    .line 354
    invoke-virtual {v6}, Lc0/c;->c()J

    .line 355
    .line 356
    .line 357
    move-result-wide v3

    .line 358
    invoke-static {v1, v2, v3, v4}, LT0/l;->b(JJ)Lc0/c;

    .line 359
    .line 360
    .line 361
    move-result-object v4

    .line 362
    goto :goto_7

    .line 363
    :cond_a
    :goto_6
    const/4 v4, 0x0

    .line 364
    :cond_b
    :goto_7
    return-object v4

    .line 365
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
