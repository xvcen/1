.class public final synthetic LH/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:Lx0/J0;

.field public final synthetic e:J

.field public final synthetic f:Z

.field public final synthetic g:LW/q;

.field public final synthetic h:LH/l;


# direct methods
.method public synthetic constructor <init>(Lx0/J0;JZLW/q;LH/l;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH/b;->d:Lx0/J0;

    iput-wide p2, p0, LH/b;->e:J

    iput-boolean p4, p0, LH/b;->f:Z

    iput-object p5, p0, LH/b;->g:LW/q;

    iput-object p6, p0, LH/b;->h:LH/l;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    check-cast p1, LI/r;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x1

    .line 13
    if-eq v0, v1, :cond_0

    .line 14
    .line 15
    move v0, v2

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    and-int/2addr p2, v2

    .line 19
    invoke-virtual {p1, p2, v0}, LI/r;->N(IZ)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-eqz p2, :cond_1

    .line 24
    .line 25
    sget-object p2, Lx0/i0;->s:LI/b1;

    .line 26
    .line 27
    iget-object v0, p0, LH/b;->d:Lx0/J0;

    .line 28
    .line 29
    invoke-virtual {p2, v0}, LI/b1;->a(Ljava/lang/Object;)LI/u0;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    new-instance v0, LH/d;

    .line 34
    .line 35
    iget-wide v1, p0, LH/b;->e:J

    .line 36
    .line 37
    iget-boolean v3, p0, LH/b;->f:Z

    .line 38
    .line 39
    iget-object v4, p0, LH/b;->g:LW/q;

    .line 40
    .line 41
    iget-object v5, p0, LH/b;->h:LH/l;

    .line 42
    .line 43
    invoke-direct/range {v0 .. v5}, LH/d;-><init>(JZLW/q;LH/l;)V

    .line 44
    .line 45
    .line 46
    const v1, 0x4b1ac501    # 1.0142977E7f

    .line 47
    .line 48
    .line 49
    invoke-static {v1, v0, p1}, LQ/l;->c(ILJ1/c;LI/r;)LQ/f;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    const/16 v1, 0x38

    .line 54
    .line 55
    invoke-static {p2, v0, p1, v1}, LI/k;->a(LI/u0;LQ/f;LI/r;I)V

    .line 56
    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    invoke-virtual {p1}, LI/r;->Q()V

    .line 60
    .line 61
    .line 62
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 63
    .line 64
    return-object p1
.end method
