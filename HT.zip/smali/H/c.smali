.class public final synthetic LH/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:LH/l;

.field public final synthetic e:Z

.field public final synthetic f:LS0/j;

.field public final synthetic g:Z

.field public final synthetic h:J

.field public final synthetic i:F

.field public final synthetic j:LW/q;

.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(LH/l;ZLS0/j;ZJFLW/q;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH/c;->d:LH/l;

    iput-boolean p2, p0, LH/c;->e:Z

    iput-object p3, p0, LH/c;->f:LS0/j;

    iput-boolean p4, p0, LH/c;->g:Z

    iput-wide p5, p0, LH/c;->h:J

    iput p7, p0, LH/c;->i:F

    iput-object p8, p0, LH/c;->j:LW/q;

    iput p9, p0, LH/c;->k:I

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    move-object v8, p1

    .line 2
    check-cast v8, LI/r;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, LH/c;->k:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, LI/k;->x(I)I

    .line 14
    .line 15
    .line 16
    move-result v9

    .line 17
    iget-object v0, p0, LH/c;->d:LH/l;

    .line 18
    .line 19
    iget-boolean v1, p0, LH/c;->e:Z

    .line 20
    .line 21
    iget-object v2, p0, LH/c;->f:LS0/j;

    .line 22
    .line 23
    iget-boolean v3, p0, LH/c;->g:Z

    .line 24
    .line 25
    iget-wide v4, p0, LH/c;->h:J

    .line 26
    .line 27
    iget v6, p0, LH/c;->i:F

    .line 28
    .line 29
    iget-object v7, p0, LH/c;->j:LW/q;

    .line 30
    .line 31
    invoke-static/range {v0 .. v9}, La/a;->b(LH/l;ZLS0/j;ZJFLW/q;LI/r;I)V

    .line 32
    .line 33
    .line 34
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 35
    .line 36
    return-object p1
.end method
