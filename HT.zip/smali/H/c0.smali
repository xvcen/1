.class public final LH/c0;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public h:I

.field public final synthetic i:LH/m0;


# direct methods
.method public constructor <init>(LH/m0;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/c0;->i:LH/m0;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    check-cast p1, LN1/c;

    .line 2
    .line 3
    new-instance v0, LH/c0;

    .line 4
    .line 5
    iget-object v1, p0, LH/c0;->i:LH/m0;

    .line 6
    .line 7
    invoke-direct {v0, v1, p1}, LH/c0;-><init>(LH/m0;LN1/c;)V

    .line 8
    .line 9
    .line 10
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, LH/c0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, LH/c0;->h:I

    .line 2
    .line 3
    sget-object v1, LJ1/m;->a:LJ1/m;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    iget-object v4, p0, LH/c0;->i:LH/m0;

    .line 8
    .line 9
    sget-object v5, LO1/a;->d:LO1/a;

    .line 10
    .line 11
    if-eqz v0, :cond_2

    .line 12
    .line 13
    if-eq v0, v3, :cond_1

    .line 14
    .line 15
    if-ne v0, v2, :cond_0

    .line 16
    .line 17
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    goto :goto_5

    .line 21
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 24
    .line 25
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p1

    .line 29
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iput v3, p0, LH/c0;->h:I

    .line 37
    .line 38
    invoke-virtual {v4, p0}, LH/m0;->s(LP1/c;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-ne p1, v5, :cond_3

    .line 43
    .line 44
    goto :goto_4

    .line 45
    :cond_3
    :goto_0
    invoke-static {v4}, LH/m0;->a(LH/m0;)LJ1/g;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    if-eqz p1, :cond_7

    .line 50
    .line 51
    iget-object v0, p1, LJ1/g;->d:Ljava/lang/Object;

    .line 52
    .line 53
    move-object v11, v0

    .line 54
    check-cast v11, Ljava/lang/String;

    .line 55
    .line 56
    iget-object p1, p1, LJ1/g;->e:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast p1, LH0/N;

    .line 59
    .line 60
    iget-wide v7, p1, LH0/N;->a:J

    .line 61
    .line 62
    iget-object v9, v4, LH/m0;->j:LH/s;

    .line 63
    .line 64
    if-eqz v9, :cond_7

    .line 65
    .line 66
    iput v2, p0, LH/c0;->h:I

    .line 67
    .line 68
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result p1

    .line 72
    if-nez p1, :cond_4

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_4
    invoke-static {v7, v8}, LH0/N;->c(J)Z

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    if-eqz p1, :cond_5

    .line 80
    .line 81
    :goto_1
    move-object p1, v1

    .line 82
    goto :goto_2

    .line 83
    :cond_5
    new-instance v6, LH/n;

    .line 84
    .line 85
    const/4 v10, 0x0

    .line 86
    invoke-direct/range {v6 .. v11}, LH/n;-><init>(JLH/s;LN1/c;Ljava/lang/CharSequence;)V

    .line 87
    .line 88
    .line 89
    iget-object p1, v9, LH/s;->a:LN1/h;

    .line 90
    .line 91
    new-instance v0, LH/q;

    .line 92
    .line 93
    const/4 v2, 0x0

    .line 94
    invoke-direct {v0, v9, v6, v2}, LH/q;-><init>(LH/s;LU1/e;LN1/c;)V

    .line 95
    .line 96
    .line 97
    invoke-static {p1, v0, p0}, Lc2/u;->w(LN1/h;LU1/e;LP1/i;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    :goto_2
    if-ne p1, v5, :cond_6

    .line 102
    .line 103
    goto :goto_3

    .line 104
    :cond_6
    move-object p1, v1

    .line 105
    :goto_3
    if-ne p1, v5, :cond_7

    .line 106
    .line 107
    :goto_4
    return-object v5

    .line 108
    :cond_7
    :goto_5
    iput-boolean v3, v4, LH/m0;->B:Z

    .line 109
    .line 110
    return-object v1
.end method
