.class public final synthetic LH/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:J

.field public final synthetic e:Z

.field public final synthetic f:LW/q;

.field public final synthetic g:LH/l;


# direct methods
.method public synthetic constructor <init>(JZLW/q;LH/l;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LH/d;->d:J

    iput-boolean p3, p0, LH/d;->e:Z

    iput-object p4, p0, LH/d;->f:LW/q;

    iput-object p5, p0, LH/d;->g:LH/l;

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    check-cast p1, LI/r;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    and-int/lit8 v0, p2, 0x3

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    const/4 v2, 0x1

    .line 13
    const/4 v3, 0x0

    .line 14
    if-eq v0, v1, :cond_0

    .line 15
    .line 16
    move v0, v2

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move v0, v3

    .line 19
    :goto_0
    and-int/2addr p2, v2

    .line 20
    invoke-virtual {p1, p2, v0}, LI/r;->N(IZ)Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    if-eqz p2, :cond_8

    .line 25
    .line 26
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    iget-wide v4, p0, LH/d;->d:J

    .line 32
    .line 33
    cmp-long p2, v4, v0

    .line 34
    .line 35
    iget-boolean v0, p0, LH/d;->e:Z

    .line 36
    .line 37
    iget-object v6, p0, LH/d;->f:LW/q;

    .line 38
    .line 39
    iget-object v1, p0, LH/d;->g:LH/l;

    .line 40
    .line 41
    sget-object v12, LI/m;->a:LI/h;

    .line 42
    .line 43
    if-eqz p2, :cond_5

    .line 44
    .line 45
    const p2, 0x34c4c6

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1, p2}, LI/r;->U(I)V

    .line 49
    .line 50
    .line 51
    if-eqz v0, :cond_1

    .line 52
    .line 53
    sget-object p2, Ls/b;->b:Ls/n;

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_1
    sget-object p2, Ls/b;->a:Ls/n;

    .line 57
    .line 58
    :goto_1
    const/16 v7, 0x20

    .line 59
    .line 60
    shr-long v7, v4, v7

    .line 61
    .line 62
    long-to-int v7, v7

    .line 63
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    const-wide v8, 0xffffffffL

    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    and-long/2addr v4, v8

    .line 73
    long-to-int v4, v4

    .line 74
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 75
    .line 76
    .line 77
    move-result v8

    .line 78
    const/4 v10, 0x0

    .line 79
    const/16 v11, 0xc

    .line 80
    .line 81
    const/4 v9, 0x0

    .line 82
    invoke-static/range {v6 .. v11}, Ls/b;->k(LW/q;FFFFI)LW/q;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    sget-object v5, LW/c;->m:LW/g;

    .line 87
    .line 88
    invoke-static {p2, v5, p1, v3}, Ls/I;->a(Ls/d;LW/g;LI/r;I)Ls/J;

    .line 89
    .line 90
    .line 91
    move-result-object p2

    .line 92
    iget-wide v5, p1, LI/r;->R:J

    .line 93
    .line 94
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    invoke-virtual {p1}, LI/r;->k()LI/q0;

    .line 99
    .line 100
    .line 101
    move-result-object v6

    .line 102
    invoke-static {p1, v4}, LW/a;->c(LI/r;LW/q;)LW/q;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    sget-object v7, Lw0/f;->c:Lw0/e;

    .line 107
    .line 108
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    sget-object v7, Lw0/e;->b:Lw0/x;

    .line 112
    .line 113
    invoke-virtual {p1}, LI/r;->W()V

    .line 114
    .line 115
    .line 116
    iget-boolean v8, p1, LI/r;->Q:Z

    .line 117
    .line 118
    if-eqz v8, :cond_2

    .line 119
    .line 120
    invoke-virtual {p1, v7}, LI/r;->j(LU1/a;)V

    .line 121
    .line 122
    .line 123
    goto :goto_2

    .line 124
    :cond_2
    invoke-virtual {p1}, LI/r;->g0()V

    .line 125
    .line 126
    .line 127
    :goto_2
    sget-object v7, Lw0/e;->e:Lw0/d;

    .line 128
    .line 129
    invoke-static {p1, v7, p2}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    sget-object p2, Lw0/e;->d:Lw0/d;

    .line 133
    .line 134
    invoke-static {p1, p2, v6}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 138
    .line 139
    .line 140
    move-result-object p2

    .line 141
    sget-object v5, Lw0/e;->f:Lw0/d;

    .line 142
    .line 143
    invoke-static {p1, p2, v5}, LI/k;->o(LI/r;Ljava/lang/Integer;LU1/e;)V

    .line 144
    .line 145
    .line 146
    sget-object p2, Lw0/e;->g:Lw0/c;

    .line 147
    .line 148
    invoke-static {p1, p2}, LI/k;->s(LI/r;LU1/c;)V

    .line 149
    .line 150
    .line 151
    sget-object p2, Lw0/e;->c:Lw0/d;

    .line 152
    .line 153
    invoke-static {p1, p2, v4}, LI/k;->u(LI/r;LU1/e;Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p1, v1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result p2

    .line 160
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    if-nez p2, :cond_3

    .line 165
    .line 166
    if-ne v4, v12, :cond_4

    .line 167
    .line 168
    :cond_3
    new-instance v4, LH/e;

    .line 169
    .line 170
    const/4 p2, 0x0

    .line 171
    invoke-direct {v4, v1, p2}, LH/e;-><init>(LH/l;I)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p1, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_4
    check-cast v4, LU1/a;

    .line 178
    .line 179
    const/4 p2, 0x6

    .line 180
    sget-object v1, LW/n;->a:LW/n;

    .line 181
    .line 182
    invoke-static {v1, v4, v0, p1, p2}, La/a;->c(LW/q;LU1/a;ZLI/r;I)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p1, v2}, LI/r;->p(Z)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p1, v3}, LI/r;->p(Z)V

    .line 189
    .line 190
    .line 191
    goto :goto_3

    .line 192
    :cond_5
    const p2, 0x42f938

    .line 193
    .line 194
    .line 195
    invoke-virtual {p1, p2}, LI/r;->U(I)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {p1, v1}, LI/r;->g(Ljava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    move-result p2

    .line 202
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v2

    .line 206
    if-nez p2, :cond_6

    .line 207
    .line 208
    if-ne v2, v12, :cond_7

    .line 209
    .line 210
    :cond_6
    new-instance v2, LH/e;

    .line 211
    .line 212
    const/4 p2, 0x1

    .line 213
    invoke-direct {v2, v1, p2}, LH/e;-><init>(LH/l;I)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {p1, v2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 217
    .line 218
    .line 219
    :cond_7
    check-cast v2, LU1/a;

    .line 220
    .line 221
    invoke-static {v6, v2, v0, p1, v3}, La/a;->c(LW/q;LU1/a;ZLI/r;I)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {p1, v3}, LI/r;->p(Z)V

    .line 225
    .line 226
    .line 227
    goto :goto_3

    .line 228
    :cond_8
    invoke-virtual {p1}, LI/r;->Q()V

    .line 229
    .line 230
    .line 231
    :goto_3
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 232
    .line 233
    return-object p1
.end method
