.class public final synthetic LH/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/f;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Z)V
    .locals 0

    .line 1
    iput p1, p0, LH/f;->d:I

    iput-object p2, p0, LH/f;->f:Ljava/lang/Object;

    iput-boolean p3, p0, LH/f;->e:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LH/f;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LH/f;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw/n0;

    .line 9
    .line 10
    iget-object v1, v0, Lw/n0;->f:LI/m0;

    .line 11
    .line 12
    check-cast p1, LW/q;

    .line 13
    .line 14
    check-cast p2, LI/r;

    .line 15
    .line 16
    check-cast p3, Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    const p1, -0x7f685f60

    .line 22
    .line 23
    .line 24
    invoke-virtual {p2, p1}, LI/r;->U(I)V

    .line 25
    .line 26
    .line 27
    sget-object p1, Lx0/i0;->n:LI/b1;

    .line 28
    .line 29
    invoke-virtual {p2, p1}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    sget-object p3, LT0/o;->e:LT0/o;

    .line 34
    .line 35
    const/4 v2, 0x1

    .line 36
    const/4 v3, 0x0

    .line 37
    if-ne p1, p3, :cond_0

    .line 38
    .line 39
    move p1, v2

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move p1, v3

    .line 42
    :goto_0
    invoke-virtual {v1}, LI/m0;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p3

    .line 46
    check-cast p3, Lp/n0;

    .line 47
    .line 48
    sget-object v4, Lp/n0;->d:Lp/n0;

    .line 49
    .line 50
    if-eq p3, v4, :cond_2

    .line 51
    .line 52
    if-nez p1, :cond_1

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_1
    move p1, v3

    .line 56
    goto :goto_2

    .line 57
    :cond_2
    :goto_1
    move p1, v2

    .line 58
    :goto_2
    invoke-virtual {p2, v0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result p3

    .line 62
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    sget-object v5, LI/m;->a:LI/h;

    .line 67
    .line 68
    if-nez p3, :cond_3

    .line 69
    .line 70
    if-ne v4, v5, :cond_4

    .line 71
    .line 72
    :cond_3
    new-instance v4, LB/y;

    .line 73
    .line 74
    const/16 p3, 0x1b

    .line 75
    .line 76
    invoke-direct {v4, p3, v0}, LB/y;-><init>(ILjava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p2, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_4
    check-cast v4, LU1/c;

    .line 83
    .line 84
    invoke-static {v4, p2}, LI/k;->t(Ljava/lang/Object;LI/r;)LI/b0;

    .line 85
    .line 86
    .line 87
    move-result-object p3

    .line 88
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    if-ne v4, v5, :cond_5

    .line 93
    .line 94
    new-instance v4, LA1/a;

    .line 95
    .line 96
    const/16 v6, 0x8

    .line 97
    .line 98
    invoke-direct {v4, p3, v6}, LA1/a;-><init>(LI/b0;I)V

    .line 99
    .line 100
    .line 101
    new-instance p3, Lp/n;

    .line 102
    .line 103
    invoke-direct {p3, v4}, Lp/n;-><init>(LU1/c;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p2, p3}, LI/r;->d0(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    move-object v4, p3

    .line 110
    :cond_5
    check-cast v4, Lp/L0;

    .line 111
    .line 112
    invoke-virtual {p2, v4}, LI/r;->e(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result p3

    .line 116
    invoke-virtual {p2, v0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v6

    .line 120
    or-int/2addr p3, v6

    .line 121
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    if-nez p3, :cond_6

    .line 126
    .line 127
    if-ne v6, v5, :cond_7

    .line 128
    .line 129
    :cond_6
    new-instance v6, Lw/m0;

    .line 130
    .line 131
    invoke-direct {v6, v4, v0}, Lw/m0;-><init>(Lp/L0;Lw/n0;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {p2, v6}, LI/r;->d0(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :cond_7
    check-cast v6, Lw/m0;

    .line 138
    .line 139
    invoke-virtual {v1}, LI/m0;->getValue()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object p3

    .line 143
    check-cast p3, Lp/n0;

    .line 144
    .line 145
    iget-boolean v1, p0, LH/f;->e:Z

    .line 146
    .line 147
    if-eqz v1, :cond_8

    .line 148
    .line 149
    iget-object v0, v0, Lw/n0;->b:LI/i0;

    .line 150
    .line 151
    invoke-virtual {v0}, LI/i0;->g()F

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    const/4 v1, 0x0

    .line 156
    cmpg-float v0, v0, v1

    .line 157
    .line 158
    if-nez v0, :cond_9

    .line 159
    .line 160
    :cond_8
    move v2, v3

    .line 161
    :cond_9
    invoke-static {v6, p3, v2, p1}, Lp/z0;->b(Lw/m0;Lp/n0;ZZ)LW/q;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p2, v3}, LI/r;->p(Z)V

    .line 166
    .line 167
    .line 168
    return-object p1

    .line 169
    :pswitch_0
    iget-object v0, p0, LH/f;->f:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast v0, LU1/a;

    .line 172
    .line 173
    check-cast p1, LW/q;

    .line 174
    .line 175
    check-cast p2, LI/r;

    .line 176
    .line 177
    check-cast p3, Ljava/lang/Integer;

    .line 178
    .line 179
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    const p3, -0xbba9706

    .line 183
    .line 184
    .line 185
    invoke-virtual {p2, p3}, LI/r;->U(I)V

    .line 186
    .line 187
    .line 188
    sget-object p3, LH/u0;->a:LI/B;

    .line 189
    .line 190
    invoke-virtual {p2, p3}, LI/r;->i(LI/t0;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object p3

    .line 194
    check-cast p3, LH/t0;

    .line 195
    .line 196
    iget-wide v1, p3, LH/t0;->a:J

    .line 197
    .line 198
    invoke-virtual {p2, v1, v2}, LI/r;->d(J)Z

    .line 199
    .line 200
    .line 201
    move-result p3

    .line 202
    invoke-virtual {p2, v0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v3

    .line 206
    or-int/2addr p3, v3

    .line 207
    iget-boolean v3, p0, LH/f;->e:Z

    .line 208
    .line 209
    invoke-virtual {p2, v3}, LI/r;->f(Z)Z

    .line 210
    .line 211
    .line 212
    move-result v4

    .line 213
    or-int/2addr p3, v4

    .line 214
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v4

    .line 218
    if-nez p3, :cond_a

    .line 219
    .line 220
    sget-object p3, LI/m;->a:LI/h;

    .line 221
    .line 222
    if-ne v4, p3, :cond_b

    .line 223
    .line 224
    :cond_a
    new-instance v4, LH/g;

    .line 225
    .line 226
    invoke-direct {v4, v1, v2, v0, v3}, LH/g;-><init>(JLU1/a;Z)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {p2, v4}, LI/r;->d0(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    :cond_b
    check-cast v4, LU1/c;

    .line 233
    .line 234
    invoke-static {p1, v4}, La0/g;->d(LW/q;LU1/c;)LW/q;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    const/4 p3, 0x0

    .line 239
    invoke-virtual {p2, p3}, LI/r;->p(Z)V

    .line 240
    .line 241
    .line 242
    return-object p1

    .line 243
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
