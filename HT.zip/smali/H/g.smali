.class public final synthetic LH/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:J

.field public final synthetic e:LU1/a;

.field public final synthetic f:Z


# direct methods
.method public synthetic constructor <init>(JLU1/a;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LH/g;->d:J

    iput-object p3, p0, LH/g;->e:LU1/a;

    iput-boolean p4, p0, LH/g;->f:Z

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    check-cast p1, La0/c;

    .line 2
    .line 3
    iget-object v0, p1, La0/c;->d:La0/a;

    .line 4
    .line 5
    invoke-interface {v0}, La0/a;->a()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    const/16 v2, 0x20

    .line 10
    .line 11
    shr-long/2addr v0, v2

    .line 12
    long-to-int v0, v0

    .line 13
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/high16 v1, 0x40000000    # 2.0f

    .line 18
    .line 19
    div-float/2addr v0, v1

    .line 20
    invoke-static {p1, v0}, La/a;->q(La0/c;F)Ld0/g;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    new-instance v1, Ld0/o;

    .line 25
    .line 26
    iget-wide v2, p0, LH/g;->d:J

    .line 27
    .line 28
    const/4 v4, 0x5

    .line 29
    invoke-direct {v1, v2, v3, v4}, Ld0/o;-><init>(JI)V

    .line 30
    .line 31
    .line 32
    new-instance v2, LA1/I;

    .line 33
    .line 34
    iget-object v3, p0, LH/g;->e:LU1/a;

    .line 35
    .line 36
    iget-boolean v4, p0, LH/g;->f:Z

    .line 37
    .line 38
    invoke-direct {v2, v3, v4, v0, v1}, LA1/I;-><init>(LU1/a;ZLd0/g;Ld0/o;)V

    .line 39
    .line 40
    .line 41
    new-instance v0, LA0/h;

    .line 42
    .line 43
    const/16 v1, 0xb

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    invoke-direct {v0, v1, v3}, LA0/h;-><init>(IZ)V

    .line 47
    .line 48
    .line 49
    iput-object v2, v0, LA0/h;->e:Ljava/lang/Object;

    .line 50
    .line 51
    iput-object v0, p1, La0/c;->e:LA0/h;

    .line 52
    .line 53
    return-object v0
.end method
