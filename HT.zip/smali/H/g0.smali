.class public final LH/g0;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LH/m0;


# direct methods
.method public constructor <init>(LH/m0;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/g0;->i:LH/m0;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/g0;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/g0;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/g0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 1

    .line 1
    new-instance p2, LH/g0;

    .line 2
    .line 3
    iget-object v0, p0, LH/g0;->i:LH/m0;

    .line 4
    .line 5
    invoke-direct {p2, v0, p1}, LH/g0;-><init>(LH/m0;LN1/c;)V

    .line 6
    .line 7
    .line 8
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LH/g0;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    sget-object v2, LJ1/m;->a:LJ1/m;

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-object v2

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object p1, p0, LH/g0;->i:LH/m0;

    .line 26
    .line 27
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iget-wide v3, v0, LM0/x;->b:J

    .line 32
    .line 33
    invoke-static {v3, v4}, LH0/N;->c(J)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_2

    .line 38
    .line 39
    invoke-virtual {p1}, LH/m0;->j()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_2

    .line 44
    .line 45
    iget-object v0, p1, LH/m0;->f:LM0/G;

    .line 46
    .line 47
    instance-of v0, v0, LM0/r;

    .line 48
    .line 49
    if-nez v0, :cond_2

    .line 50
    .line 51
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v0}, LX1/a;->M(LM0/x;)LH0/g;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    iget-object v4, v4, LM0/x;->a:LH0/g;

    .line 68
    .line 69
    iget-object v4, v4, LH0/g;->e:Ljava/lang/String;

    .line 70
    .line 71
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    invoke-static {v3, v4}, LX1/a;->O(LM0/x;I)LH0/g;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    iget-object v5, v5, LM0/x;->a:LH0/g;

    .line 88
    .line 89
    iget-object v5, v5, LH0/g;->e:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    invoke-static {v4, v5}, LX1/a;->N(LM0/x;I)LH0/g;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    new-instance v5, LH0/d;

    .line 100
    .line 101
    invoke-direct {v5, v3}, LH0/d;-><init>(LH0/g;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v5, v4}, LH0/d;->a(LH0/g;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v5}, LH0/d;->b()LH0/g;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    invoke-virtual {p1}, LH/m0;->n()LM0/x;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    iget-wide v4, v4, LM0/x;->b:J

    .line 116
    .line 117
    invoke-static {v4, v5}, LH0/N;->f(J)I

    .line 118
    .line 119
    .line 120
    move-result v4

    .line 121
    invoke-static {v4, v4}, LH0/F;->b(II)J

    .line 122
    .line 123
    .line 124
    move-result-wide v4

    .line 125
    invoke-static {v3, v4, v5}, LH/m0;->e(LH0/g;J)LM0/x;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    iget-object v4, p1, LH/m0;->c:LU1/c;

    .line 130
    .line 131
    invoke-interface {v4, v3}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    sget-object v3, Lw/H;->d:Lw/H;

    .line 135
    .line 136
    invoke-virtual {p1, v3}, LH/m0;->q(Lw/H;)V

    .line 137
    .line 138
    .line 139
    iget-object v3, p1, LH/m0;->a:Lw/q0;

    .line 140
    .line 141
    iput-boolean v1, v3, Lw/q0;->e:Z

    .line 142
    .line 143
    goto :goto_0

    .line 144
    :cond_2
    const/4 v0, 0x0

    .line 145
    :goto_0
    if-nez v0, :cond_3

    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_3
    iget-object p1, p1, LH/m0;->h:Lx0/d0;

    .line 149
    .line 150
    if-eqz p1, :cond_4

    .line 151
    .line 152
    invoke-static {v0}, Lr/c;->a(LH0/g;)Lx0/c0;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    iput v1, p0, LH/g0;->h:I

    .line 157
    .line 158
    check-cast p1, Lx0/h;

    .line 159
    .line 160
    invoke-virtual {p1, v0}, Lx0/h;->a(Lx0/c0;)V

    .line 161
    .line 162
    .line 163
    sget-object p1, LO1/a;->d:LO1/a;

    .line 164
    .line 165
    if-ne v2, p1, :cond_4

    .line 166
    .line 167
    return-object p1

    .line 168
    :cond_4
    :goto_1
    return-object v2
.end method
