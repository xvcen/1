.class public interface abstract LH/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LH/v;I)J
.end method
