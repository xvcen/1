.class public final LH/j0;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:LH/m0;


# direct methods
.method public constructor <init>(LH/m0;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/j0;->i:LH/m0;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/j0;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/j0;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/j0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 1

    .line 1
    new-instance p2, LH/j0;

    .line 2
    .line 3
    iget-object v0, p0, LH/j0;->i:LH/m0;

    .line 4
    .line 5
    invoke-direct {p2, v0, p1}, LH/j0;-><init>(LH/m0;LN1/c;)V

    .line 6
    .line 7
    .line 8
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 45

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LH/j0;->h:I

    .line 4
    .line 5
    sget-object v2, LJ1/m;->a:LJ1/m;

    .line 6
    .line 7
    iget-object v4, v0, LH/j0;->i:LH/m0;

    .line 8
    .line 9
    const/4 v5, 0x2

    .line 10
    const/4 v6, 0x1

    .line 11
    sget-object v7, LO1/a;->d:LO1/a;

    .line 12
    .line 13
    if-eqz v1, :cond_2

    .line 14
    .line 15
    if-eq v1, v6, :cond_1

    .line 16
    .line 17
    if-ne v1, v5, :cond_0

    .line 18
    .line 19
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    move-object/from16 v0, p1

    .line 23
    .line 24
    goto/16 :goto_13

    .line 25
    .line 26
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 27
    .line 28
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 29
    .line 30
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    throw v1

    .line 34
    :cond_1
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    move-object/from16 v8, p1

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_2
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iget-object v1, v4, LH/m0;->h:Lx0/d0;

    .line 44
    .line 45
    if-eqz v1, :cond_28

    .line 46
    .line 47
    iput v6, v0, LH/j0;->h:I

    .line 48
    .line 49
    check-cast v1, Lx0/h;

    .line 50
    .line 51
    iget-object v1, v1, Lx0/h;->a:Lx0/i;

    .line 52
    .line 53
    iget-object v1, v1, Lx0/i;->a:Landroid/content/ClipboardManager;

    .line 54
    .line 55
    invoke-virtual {v1}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_3

    .line 60
    .line 61
    new-instance v8, Lx0/c0;

    .line 62
    .line 63
    invoke-direct {v8, v1}, Lx0/c0;-><init>(Landroid/content/ClipData;)V

    .line 64
    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_3
    const/4 v8, 0x0

    .line 68
    :goto_0
    if-ne v8, v7, :cond_4

    .line 69
    .line 70
    goto/16 :goto_12

    .line 71
    .line 72
    :cond_4
    :goto_1
    check-cast v8, Lx0/c0;

    .line 73
    .line 74
    if-eqz v8, :cond_28

    .line 75
    .line 76
    iput v5, v0, LH/j0;->h:I

    .line 77
    .line 78
    iget-object v1, v8, Lx0/c0;->a:Landroid/content/ClipData;

    .line 79
    .line 80
    const/4 v8, 0x0

    .line 81
    invoke-virtual {v1, v8}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    if-eqz v1, :cond_24

    .line 86
    .line 87
    invoke-virtual {v1}, Landroid/content/ClipData$Item;->getText()Ljava/lang/CharSequence;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    if-eqz v1, :cond_24

    .line 92
    .line 93
    instance-of v9, v1, Landroid/text/Spanned;

    .line 94
    .line 95
    if-nez v9, :cond_5

    .line 96
    .line 97
    new-instance v3, LH0/g;

    .line 98
    .line 99
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    invoke-direct {v3, v1}, LH0/g;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    move-object v0, v3

    .line 107
    goto/16 :goto_11

    .line 108
    .line 109
    :cond_5
    move-object v9, v1

    .line 110
    check-cast v9, Landroid/text/Spanned;

    .line 111
    .line 112
    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    .line 113
    .line 114
    .line 115
    move-result v10

    .line 116
    const-class v11, Landroid/text/Annotation;

    .line 117
    .line 118
    invoke-interface {v9, v8, v10, v11}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v10

    .line 122
    check-cast v10, [Landroid/text/Annotation;

    .line 123
    .line 124
    new-instance v11, Ljava/util/ArrayList;

    .line 125
    .line 126
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 127
    .line 128
    .line 129
    const-string v12, "<this>"

    .line 130
    .line 131
    invoke-static {v10, v12}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    array-length v12, v10

    .line 135
    sub-int/2addr v12, v6

    .line 136
    if-ltz v12, :cond_21

    .line 137
    .line 138
    move v13, v8

    .line 139
    :goto_2
    aget-object v14, v10, v13

    .line 140
    .line 141
    invoke-virtual {v14}, Landroid/text/Annotation;->getKey()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v15

    .line 145
    const-string v3, "androidx.compose.text.SpanStyle"

    .line 146
    .line 147
    invoke-static {v15, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v3

    .line 151
    if-nez v3, :cond_6

    .line 152
    .line 153
    move/from16 p1, v8

    .line 154
    .line 155
    move-object v8, v1

    .line 156
    goto/16 :goto_f

    .line 157
    .line 158
    :cond_6
    invoke-interface {v9, v14}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 159
    .line 160
    .line 161
    move-result v3

    .line 162
    invoke-interface {v9, v14}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 163
    .line 164
    .line 165
    move-result v15

    .line 166
    new-instance v5, Lr/a;

    .line 167
    .line 168
    invoke-virtual {v14}, Landroid/text/Annotation;->getValue()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v14

    .line 172
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 173
    .line 174
    .line 175
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    iput-object v6, v5, Lr/a;->a:Landroid/os/Parcel;

    .line 180
    .line 181
    invoke-static {v14, v8}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 182
    .line 183
    .line 184
    move-result-object v14

    .line 185
    array-length v0, v14

    .line 186
    invoke-virtual {v6, v14, v8, v0}, Landroid/os/Parcel;->unmarshall([BII)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v6, v8}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 190
    .line 191
    .line 192
    iget-object v0, v5, Lr/a;->a:Landroid/os/Parcel;

    .line 193
    .line 194
    sget-wide v16, Ld0/w;->g:J

    .line 195
    .line 196
    sget-wide v18, LT0/q;->c:J

    .line 197
    .line 198
    move-wide/from16 v21, v16

    .line 199
    .line 200
    move-wide/from16 v35, v21

    .line 201
    .line 202
    move-wide/from16 v23, v18

    .line 203
    .line 204
    move-wide/from16 v30, v23

    .line 205
    .line 206
    const/16 v25, 0x0

    .line 207
    .line 208
    const/16 v26, 0x0

    .line 209
    .line 210
    const/16 v27, 0x0

    .line 211
    .line 212
    const/16 v29, 0x0

    .line 213
    .line 214
    const/16 v32, 0x0

    .line 215
    .line 216
    const/16 v33, 0x0

    .line 217
    .line 218
    const/16 v37, 0x0

    .line 219
    .line 220
    const/16 v38, 0x0

    .line 221
    .line 222
    :goto_3
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 223
    .line 224
    .line 225
    move-result v6

    .line 226
    const/4 v14, 0x1

    .line 227
    if-le v6, v14, :cond_20

    .line 228
    .line 229
    invoke-virtual {v0}, Landroid/os/Parcel;->readByte()B

    .line 230
    .line 231
    .line 232
    move-result v6

    .line 233
    move/from16 p1, v8

    .line 234
    .line 235
    const/16 v8, 0x8

    .line 236
    .line 237
    if-ne v6, v14, :cond_8

    .line 238
    .line 239
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 240
    .line 241
    .line 242
    move-result v6

    .line 243
    if-lt v6, v8, :cond_7

    .line 244
    .line 245
    invoke-virtual {v5}, Lr/a;->a()J

    .line 246
    .line 247
    .line 248
    move-result-wide v21

    .line 249
    :goto_4
    move/from16 v8, p1

    .line 250
    .line 251
    goto :goto_3

    .line 252
    :cond_7
    :goto_5
    move-object v8, v1

    .line 253
    goto/16 :goto_e

    .line 254
    .line 255
    :cond_8
    const/4 v14, 0x5

    .line 256
    const/4 v8, 0x2

    .line 257
    if-ne v6, v8, :cond_9

    .line 258
    .line 259
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 260
    .line 261
    .line 262
    move-result v6

    .line 263
    if-lt v6, v14, :cond_7

    .line 264
    .line 265
    invoke-virtual {v5}, Lr/a;->b()J

    .line 266
    .line 267
    .line 268
    move-result-wide v23

    .line 269
    goto :goto_4

    .line 270
    :cond_9
    const/4 v8, 0x3

    .line 271
    const/4 v14, 0x4

    .line 272
    if-ne v6, v8, :cond_a

    .line 273
    .line 274
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 275
    .line 276
    .line 277
    move-result v6

    .line 278
    if-lt v6, v14, :cond_7

    .line 279
    .line 280
    new-instance v6, LL0/k;

    .line 281
    .line 282
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 283
    .line 284
    .line 285
    move-result v8

    .line 286
    invoke-direct {v6, v8}, LL0/k;-><init>(I)V

    .line 287
    .line 288
    .line 289
    move/from16 v8, p1

    .line 290
    .line 291
    move-object/from16 v25, v6

    .line 292
    .line 293
    goto :goto_3

    .line 294
    :cond_a
    if-ne v6, v14, :cond_d

    .line 295
    .line 296
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 297
    .line 298
    .line 299
    move-result v6

    .line 300
    const/4 v8, 0x1

    .line 301
    if-lt v6, v8, :cond_7

    .line 302
    .line 303
    invoke-virtual {v0}, Landroid/os/Parcel;->readByte()B

    .line 304
    .line 305
    .line 306
    move-result v6

    .line 307
    if-nez v6, :cond_c

    .line 308
    .line 309
    :cond_b
    move/from16 v6, p1

    .line 310
    .line 311
    goto :goto_6

    .line 312
    :cond_c
    if-ne v6, v8, :cond_b

    .line 313
    .line 314
    move v6, v8

    .line 315
    :goto_6
    new-instance v14, LL0/i;

    .line 316
    .line 317
    invoke-direct {v14, v6}, LL0/i;-><init>(I)V

    .line 318
    .line 319
    .line 320
    move/from16 v8, p1

    .line 321
    .line 322
    move-object/from16 v26, v14

    .line 323
    .line 324
    goto :goto_3

    .line 325
    :cond_d
    const/4 v8, 0x5

    .line 326
    const/4 v14, 0x1

    .line 327
    if-ne v6, v8, :cond_12

    .line 328
    .line 329
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 330
    .line 331
    .line 332
    move-result v6

    .line 333
    if-lt v6, v14, :cond_7

    .line 334
    .line 335
    invoke-virtual {v0}, Landroid/os/Parcel;->readByte()B

    .line 336
    .line 337
    .line 338
    move-result v6

    .line 339
    if-nez v6, :cond_e

    .line 340
    .line 341
    move/from16 v14, p1

    .line 342
    .line 343
    :goto_7
    const/4 v8, 0x2

    .line 344
    goto :goto_8

    .line 345
    :cond_e
    if-ne v6, v14, :cond_f

    .line 346
    .line 347
    const v14, 0xffff

    .line 348
    .line 349
    .line 350
    goto :goto_7

    .line 351
    :cond_f
    const/4 v8, 0x3

    .line 352
    if-ne v6, v8, :cond_10

    .line 353
    .line 354
    const/4 v8, 0x2

    .line 355
    const/4 v14, 0x2

    .line 356
    goto :goto_8

    .line 357
    :cond_10
    const/4 v8, 0x2

    .line 358
    if-ne v6, v8, :cond_11

    .line 359
    .line 360
    const/4 v14, 0x1

    .line 361
    goto :goto_8

    .line 362
    :cond_11
    move/from16 v14, p1

    .line 363
    .line 364
    :goto_8
    new-instance v6, LL0/j;

    .line 365
    .line 366
    invoke-direct {v6, v14}, LL0/j;-><init>(I)V

    .line 367
    .line 368
    .line 369
    move/from16 v8, p1

    .line 370
    .line 371
    move-object/from16 v27, v6

    .line 372
    .line 373
    goto/16 :goto_3

    .line 374
    .line 375
    :cond_12
    const/4 v8, 0x2

    .line 376
    const/4 v14, 0x6

    .line 377
    if-ne v6, v14, :cond_13

    .line 378
    .line 379
    invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v29

    .line 383
    goto/16 :goto_4

    .line 384
    .line 385
    :cond_13
    const/4 v14, 0x7

    .line 386
    if-ne v6, v14, :cond_14

    .line 387
    .line 388
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 389
    .line 390
    .line 391
    move-result v6

    .line 392
    const/4 v14, 0x5

    .line 393
    if-lt v6, v14, :cond_7

    .line 394
    .line 395
    invoke-virtual {v5}, Lr/a;->b()J

    .line 396
    .line 397
    .line 398
    move-result-wide v30

    .line 399
    goto/16 :goto_4

    .line 400
    .line 401
    :cond_14
    const/16 v14, 0x8

    .line 402
    .line 403
    if-ne v6, v14, :cond_15

    .line 404
    .line 405
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 406
    .line 407
    .line 408
    move-result v6

    .line 409
    const/4 v14, 0x4

    .line 410
    if-lt v6, v14, :cond_7

    .line 411
    .line 412
    invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F

    .line 413
    .line 414
    .line 415
    move-result v6

    .line 416
    new-instance v14, LS0/a;

    .line 417
    .line 418
    invoke-direct {v14, v6}, LS0/a;-><init>(F)V

    .line 419
    .line 420
    .line 421
    move/from16 v8, p1

    .line 422
    .line 423
    move-object/from16 v32, v14

    .line 424
    .line 425
    goto/16 :goto_3

    .line 426
    .line 427
    :cond_15
    const/16 v8, 0x9

    .line 428
    .line 429
    if-ne v6, v8, :cond_16

    .line 430
    .line 431
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 432
    .line 433
    .line 434
    move-result v6

    .line 435
    if-lt v6, v14, :cond_7

    .line 436
    .line 437
    new-instance v6, LS0/p;

    .line 438
    .line 439
    invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F

    .line 440
    .line 441
    .line 442
    move-result v8

    .line 443
    invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F

    .line 444
    .line 445
    .line 446
    move-result v14

    .line 447
    invoke-direct {v6, v8, v14}, LS0/p;-><init>(FF)V

    .line 448
    .line 449
    .line 450
    move/from16 v8, p1

    .line 451
    .line 452
    move-object/from16 v33, v6

    .line 453
    .line 454
    goto/16 :goto_3

    .line 455
    .line 456
    :cond_16
    const/16 v8, 0xa

    .line 457
    .line 458
    if-ne v6, v8, :cond_17

    .line 459
    .line 460
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 461
    .line 462
    .line 463
    move-result v6

    .line 464
    if-lt v6, v14, :cond_7

    .line 465
    .line 466
    invoke-virtual {v5}, Lr/a;->a()J

    .line 467
    .line 468
    .line 469
    move-result-wide v35

    .line 470
    goto/16 :goto_4

    .line 471
    .line 472
    :cond_17
    const/16 v8, 0xb

    .line 473
    .line 474
    if-ne v6, v8, :cond_1f

    .line 475
    .line 476
    invoke-virtual {v0}, Landroid/os/Parcel;->dataAvail()I

    .line 477
    .line 478
    .line 479
    move-result v6

    .line 480
    const/4 v14, 0x4

    .line 481
    if-lt v6, v14, :cond_7

    .line 482
    .line 483
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 484
    .line 485
    .line 486
    move-result v6

    .line 487
    and-int/lit8 v8, v6, 0x2

    .line 488
    .line 489
    if-eqz v8, :cond_18

    .line 490
    .line 491
    const/4 v14, 0x1

    .line 492
    goto :goto_9

    .line 493
    :cond_18
    move/from16 v14, p1

    .line 494
    .line 495
    :goto_9
    and-int/lit8 v6, v6, 0x1

    .line 496
    .line 497
    if-eqz v6, :cond_19

    .line 498
    .line 499
    const/4 v6, 0x1

    .line 500
    goto :goto_a

    .line 501
    :cond_19
    move/from16 v6, p1

    .line 502
    .line 503
    :goto_a
    sget-object v8, LS0/l;->d:LS0/l;

    .line 504
    .line 505
    move-object/from16 v16, v0

    .line 506
    .line 507
    sget-object v0, LS0/l;->c:LS0/l;

    .line 508
    .line 509
    if-eqz v14, :cond_1b

    .line 510
    .line 511
    if-eqz v6, :cond_1b

    .line 512
    .line 513
    filled-new-array {v8, v0}, [LS0/l;

    .line 514
    .line 515
    .line 516
    move-result-object v0

    .line 517
    invoke-static {v0}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 518
    .line 519
    .line 520
    move-result-object v0

    .line 521
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 522
    .line 523
    .line 524
    move-result-object v6

    .line 525
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 526
    .line 527
    .line 528
    move-result v8

    .line 529
    move/from16 v14, p1

    .line 530
    .line 531
    :goto_b
    if-ge v14, v8, :cond_1a

    .line 532
    .line 533
    invoke-interface {v0, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 534
    .line 535
    .line 536
    move-result-object v17

    .line 537
    move-object/from16 v18, v0

    .line 538
    .line 539
    move-object/from16 v0, v17

    .line 540
    .line 541
    check-cast v0, LS0/l;

    .line 542
    .line 543
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 544
    .line 545
    .line 546
    move-result v6

    .line 547
    iget v0, v0, LS0/l;->a:I

    .line 548
    .line 549
    or-int/2addr v0, v6

    .line 550
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 551
    .line 552
    .line 553
    move-result-object v6

    .line 554
    add-int/lit8 v14, v14, 0x1

    .line 555
    .line 556
    move-object/from16 v0, v18

    .line 557
    .line 558
    goto :goto_b

    .line 559
    :cond_1a
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 560
    .line 561
    .line 562
    move-result v0

    .line 563
    new-instance v6, LS0/l;

    .line 564
    .line 565
    invoke-direct {v6, v0}, LS0/l;-><init>(I)V

    .line 566
    .line 567
    .line 568
    move-object/from16 v37, v6

    .line 569
    .line 570
    goto :goto_d

    .line 571
    :cond_1b
    if-eqz v14, :cond_1c

    .line 572
    .line 573
    move-object/from16 v37, v8

    .line 574
    .line 575
    goto :goto_d

    .line 576
    :cond_1c
    if-eqz v6, :cond_1d

    .line 577
    .line 578
    :goto_c
    move-object/from16 v37, v0

    .line 579
    .line 580
    goto :goto_d

    .line 581
    :cond_1d
    sget-object v0, LS0/l;->b:LS0/l;

    .line 582
    .line 583
    goto :goto_c

    .line 584
    :cond_1e
    :goto_d
    move/from16 v8, p1

    .line 585
    .line 586
    move-object/from16 v0, v16

    .line 587
    .line 588
    goto/16 :goto_3

    .line 589
    .line 590
    :cond_1f
    move-object/from16 v16, v0

    .line 591
    .line 592
    const/16 v0, 0xc

    .line 593
    .line 594
    if-ne v6, v0, :cond_1e

    .line 595
    .line 596
    invoke-virtual/range {v16 .. v16}, Landroid/os/Parcel;->dataAvail()I

    .line 597
    .line 598
    .line 599
    move-result v0

    .line 600
    const/16 v6, 0x14

    .line 601
    .line 602
    if-lt v0, v6, :cond_7

    .line 603
    .line 604
    new-instance v39, Ld0/S;

    .line 605
    .line 606
    invoke-virtual {v5}, Lr/a;->a()J

    .line 607
    .line 608
    .line 609
    move-result-wide v40

    .line 610
    invoke-virtual/range {v16 .. v16}, Landroid/os/Parcel;->readFloat()F

    .line 611
    .line 612
    .line 613
    move-result v0

    .line 614
    invoke-virtual/range {v16 .. v16}, Landroid/os/Parcel;->readFloat()F

    .line 615
    .line 616
    .line 617
    move-result v6

    .line 618
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 619
    .line 620
    .line 621
    move-result v0

    .line 622
    move-object v8, v1

    .line 623
    int-to-long v0, v0

    .line 624
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 625
    .line 626
    .line 627
    move-result v6

    .line 628
    move-wide/from16 v17, v0

    .line 629
    .line 630
    int-to-long v0, v6

    .line 631
    const/16 v6, 0x20

    .line 632
    .line 633
    shl-long v17, v17, v6

    .line 634
    .line 635
    const-wide v19, 0xffffffffL

    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    and-long v0, v0, v19

    .line 641
    .line 642
    or-long v42, v17, v0

    .line 643
    .line 644
    invoke-virtual/range {v16 .. v16}, Landroid/os/Parcel;->readFloat()F

    .line 645
    .line 646
    .line 647
    move-result v44

    .line 648
    invoke-direct/range {v39 .. v44}, Ld0/S;-><init>(JJF)V

    .line 649
    .line 650
    .line 651
    move-object v1, v8

    .line 652
    move-object/from16 v0, v16

    .line 653
    .line 654
    move-object/from16 v38, v39

    .line 655
    .line 656
    goto/16 :goto_4

    .line 657
    .line 658
    :cond_20
    move/from16 p1, v8

    .line 659
    .line 660
    goto/16 :goto_5

    .line 661
    .line 662
    :goto_e
    new-instance v20, LH0/G;

    .line 663
    .line 664
    const v39, 0xc000

    .line 665
    .line 666
    .line 667
    const/16 v28, 0x0

    .line 668
    .line 669
    const/16 v34, 0x0

    .line 670
    .line 671
    invoke-direct/range {v20 .. v39}, LH0/G;-><init>(JJLL0/k;LL0/i;LL0/j;LL0/b;Ljava/lang/String;JLS0/a;LS0/p;LO0/b;JLS0/l;Ld0/S;I)V

    .line 672
    .line 673
    .line 674
    move-object/from16 v0, v20

    .line 675
    .line 676
    new-instance v1, LH0/e;

    .line 677
    .line 678
    invoke-direct {v1, v3, v15, v0}, LH0/e;-><init>(IILjava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 682
    .line 683
    .line 684
    :goto_f
    if-eq v13, v12, :cond_22

    .line 685
    .line 686
    add-int/lit8 v13, v13, 0x1

    .line 687
    .line 688
    move-object/from16 v0, p0

    .line 689
    .line 690
    move-object v1, v8

    .line 691
    const/4 v5, 0x2

    .line 692
    const/4 v6, 0x1

    .line 693
    move/from16 v8, p1

    .line 694
    .line 695
    goto/16 :goto_2

    .line 696
    .line 697
    :cond_21
    move-object v8, v1

    .line 698
    :cond_22
    new-instance v0, LH0/g;

    .line 699
    .line 700
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 701
    .line 702
    .line 703
    move-result-object v1

    .line 704
    sget-object v3, LH0/h;->a:LH0/g;

    .line 705
    .line 706
    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    .line 707
    .line 708
    .line 709
    move-result v3

    .line 710
    if-eqz v3, :cond_23

    .line 711
    .line 712
    const/4 v3, 0x0

    .line 713
    goto :goto_10

    .line 714
    :cond_23
    move-object v3, v11

    .line 715
    :goto_10
    invoke-direct {v0, v3, v1}, LH0/g;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 716
    .line 717
    .line 718
    goto :goto_11

    .line 719
    :cond_24
    const/4 v0, 0x0

    .line 720
    :goto_11
    if-ne v0, v7, :cond_25

    .line 721
    .line 722
    :goto_12
    return-object v7

    .line 723
    :cond_25
    :goto_13
    check-cast v0, LH0/g;

    .line 724
    .line 725
    if-nez v0, :cond_26

    .line 726
    .line 727
    goto :goto_14

    .line 728
    :cond_26
    invoke-virtual {v4}, LH/m0;->j()Z

    .line 729
    .line 730
    .line 731
    move-result v1

    .line 732
    if-nez v1, :cond_27

    .line 733
    .line 734
    goto :goto_14

    .line 735
    :cond_27
    invoke-virtual {v4}, LH/m0;->n()LM0/x;

    .line 736
    .line 737
    .line 738
    move-result-object v1

    .line 739
    invoke-virtual {v4}, LH/m0;->n()LM0/x;

    .line 740
    .line 741
    .line 742
    move-result-object v3

    .line 743
    iget-object v3, v3, LM0/x;->a:LH0/g;

    .line 744
    .line 745
    iget-object v3, v3, LH0/g;->e:Ljava/lang/String;

    .line 746
    .line 747
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 748
    .line 749
    .line 750
    move-result v3

    .line 751
    invoke-static {v1, v3}, LX1/a;->O(LM0/x;I)LH0/g;

    .line 752
    .line 753
    .line 754
    move-result-object v1

    .line 755
    new-instance v3, LH0/d;

    .line 756
    .line 757
    invoke-direct {v3, v1}, LH0/d;-><init>(LH0/g;)V

    .line 758
    .line 759
    .line 760
    invoke-virtual {v3, v0}, LH0/d;->a(LH0/g;)V

    .line 761
    .line 762
    .line 763
    invoke-virtual {v3}, LH0/d;->b()LH0/g;

    .line 764
    .line 765
    .line 766
    move-result-object v1

    .line 767
    invoke-virtual {v4}, LH/m0;->n()LM0/x;

    .line 768
    .line 769
    .line 770
    move-result-object v3

    .line 771
    invoke-virtual {v4}, LH/m0;->n()LM0/x;

    .line 772
    .line 773
    .line 774
    move-result-object v5

    .line 775
    iget-object v5, v5, LM0/x;->a:LH0/g;

    .line 776
    .line 777
    iget-object v5, v5, LH0/g;->e:Ljava/lang/String;

    .line 778
    .line 779
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 780
    .line 781
    .line 782
    move-result v5

    .line 783
    invoke-static {v3, v5}, LX1/a;->N(LM0/x;I)LH0/g;

    .line 784
    .line 785
    .line 786
    move-result-object v3

    .line 787
    new-instance v5, LH0/d;

    .line 788
    .line 789
    invoke-direct {v5, v1}, LH0/d;-><init>(LH0/g;)V

    .line 790
    .line 791
    .line 792
    invoke-virtual {v5, v3}, LH0/d;->a(LH0/g;)V

    .line 793
    .line 794
    .line 795
    invoke-virtual {v5}, LH0/d;->b()LH0/g;

    .line 796
    .line 797
    .line 798
    move-result-object v1

    .line 799
    invoke-virtual {v4}, LH/m0;->n()LM0/x;

    .line 800
    .line 801
    .line 802
    move-result-object v3

    .line 803
    iget-wide v5, v3, LM0/x;->b:J

    .line 804
    .line 805
    invoke-static {v5, v6}, LH0/N;->f(J)I

    .line 806
    .line 807
    .line 808
    move-result v3

    .line 809
    iget-object v0, v0, LH0/g;->e:Ljava/lang/String;

    .line 810
    .line 811
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 812
    .line 813
    .line 814
    move-result v0

    .line 815
    add-int/2addr v0, v3

    .line 816
    invoke-static {v0, v0}, LH0/F;->b(II)J

    .line 817
    .line 818
    .line 819
    move-result-wide v5

    .line 820
    invoke-static {v1, v5, v6}, LH/m0;->e(LH0/g;J)LM0/x;

    .line 821
    .line 822
    .line 823
    move-result-object v0

    .line 824
    iget-object v1, v4, LH/m0;->c:LU1/c;

    .line 825
    .line 826
    invoke-interface {v1, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 827
    .line 828
    .line 829
    sget-object v0, Lw/H;->d:Lw/H;

    .line 830
    .line 831
    invoke-virtual {v4, v0}, LH/m0;->q(Lw/H;)V

    .line 832
    .line 833
    .line 834
    iget-object v0, v4, LH/m0;->a:Lw/q0;

    .line 835
    .line 836
    const/4 v14, 0x1

    .line 837
    iput-boolean v14, v0, Lw/q0;->e:Z

    .line 838
    .line 839
    :cond_28
    :goto_14
    return-object v2
.end method
