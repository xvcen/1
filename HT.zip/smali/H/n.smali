.class public final LH/n;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LH/s;

.field public final synthetic k:Ljava/lang/CharSequence;

.field public final synthetic l:J


# direct methods
.method public constructor <init>(JLH/s;LN1/c;Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    iput-object p3, p0, LH/n;->j:LH/s;

    .line 2
    .line 3
    iput-object p5, p0, LH/n;->k:Ljava/lang/CharSequence;

    .line 4
    .line 5
    iput-wide p1, p0, LH/n;->l:J

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1}, LA0/a;->n(Ljava/lang/Object;)Landroid/view/textclassifier/TextClassifier;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    check-cast p2, LN1/c;

    .line 6
    .line 7
    invoke-virtual {p0, p2, p1}, LH/n;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, LH/n;

    .line 12
    .line 13
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 14
    .line 15
    invoke-virtual {p1, p2}, LH/n;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 6

    .line 1
    new-instance v0, LH/n;

    .line 2
    .line 3
    iget-object v5, p0, LH/n;->k:Ljava/lang/CharSequence;

    .line 4
    .line 5
    iget-wide v1, p0, LH/n;->l:J

    .line 6
    .line 7
    iget-object v3, p0, LH/n;->j:LH/s;

    .line 8
    .line 9
    move-object v4, p1

    .line 10
    invoke-direct/range {v0 .. v5}, LH/n;-><init>(JLH/s;LN1/c;Ljava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    iput-object p2, v0, LH/n;->i:Ljava/lang/Object;

    .line 14
    .line 15
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LH/n;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, LH/n;->i:Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {p1}, LA0/a;->n(Ljava/lang/Object;)Landroid/view/textclassifier/TextClassifier;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    iput v1, p0, LH/n;->h:I

    .line 30
    .line 31
    iget-object v2, p0, LH/n;->j:LH/s;

    .line 32
    .line 33
    iget-object v3, p0, LH/n;->k:Ljava/lang/CharSequence;

    .line 34
    .line 35
    iget-wide v4, p0, LH/n;->l:J

    .line 36
    .line 37
    move-object v7, p0

    .line 38
    invoke-static/range {v2 .. v7}, LH/s;->a(LH/s;Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassifier;LP1/c;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    sget-object v0, LO1/a;->d:LO1/a;

    .line 43
    .line 44
    if-ne p1, v0, :cond_2

    .line 45
    .line 46
    return-object v0

    .line 47
    :cond_2
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 48
    .line 49
    return-object p1
.end method
