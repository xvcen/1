.class public final LH/o;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:I

.field public final synthetic i:Landroid/view/textclassifier/TextClassifier;

.field public final synthetic j:LP1/i;


# direct methods
.method public constructor <init>(Landroid/view/textclassifier/TextClassifier;LU1/e;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH/o;->i:Landroid/view/textclassifier/TextClassifier;

    .line 2
    .line 3
    check-cast p2, LP1/i;

    .line 4
    .line 5
    iput-object p2, p0, LH/o;->j:LP1/i;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LH/o;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH/o;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH/o;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance p2, LH/o;

    .line 2
    .line 3
    iget-object v0, p0, LH/o;->i:Landroid/view/textclassifier/TextClassifier;

    .line 4
    .line 5
    iget-object v1, p0, LH/o;->j:LP1/i;

    .line 6
    .line 7
    invoke-direct {p2, v0, v1, p1}, LH/o;-><init>(Landroid/view/textclassifier/TextClassifier;LU1/e;LN1/c;)V

    .line 8
    .line 9
    .line 10
    return-object p2
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LH/o;->h:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, LH/o;->i:Landroid/view/textclassifier/TextClassifier;

    .line 24
    .line 25
    if-eqz p1, :cond_3

    .line 26
    .line 27
    iput v1, p0, LH/o;->h:I

    .line 28
    .line 29
    iget-object v0, p0, LH/o;->j:LP1/i;

    .line 30
    .line 31
    invoke-interface {v0, p1, p0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    sget-object v0, LO1/a;->d:LO1/a;

    .line 36
    .line 37
    if-ne p1, v0, :cond_2

    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_2
    return-object p1

    .line 41
    :cond_3
    const/4 p1, 0x0

    .line 42
    return-object p1
.end method
