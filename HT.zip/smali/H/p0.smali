.class public final synthetic LH/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LT0/c;

.field public final synthetic f:LI/b0;


# direct methods
.method public synthetic constructor <init>(LT0/c;LI/b0;I)V
    .locals 0

    .line 1
    iput p3, p0, LH/p0;->d:I

    iput-object p1, p0, LH/p0;->e:LT0/c;

    iput-object p2, p0, LH/p0;->f:LI/b0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LH/p0;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LT0/i;

    .line 7
    .line 8
    iget-wide v0, p1, LT0/i;->a:J

    .line 9
    .line 10
    const/16 v2, 0x20

    .line 11
    .line 12
    shr-long/2addr v0, v2

    .line 13
    long-to-int v0, v0

    .line 14
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    iget-object v1, p0, LH/p0;->e:LT0/c;

    .line 19
    .line 20
    invoke-interface {v1, v0}, LT0/c;->Y(F)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iget-wide v3, p1, LT0/i;->a:J

    .line 25
    .line 26
    const-wide v5, 0xffffffffL

    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    and-long/2addr v3, v5

    .line 32
    long-to-int p1, v3

    .line 33
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    invoke-interface {v1, p1}, LT0/c;->Y(F)I

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    int-to-long v0, v0

    .line 42
    shl-long/2addr v0, v2

    .line 43
    int-to-long v2, p1

    .line 44
    and-long/2addr v2, v5

    .line 45
    or-long/2addr v0, v2

    .line 46
    new-instance p1, LT0/n;

    .line 47
    .line 48
    invoke-direct {p1, v0, v1}, LT0/n;-><init>(J)V

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, LH/p0;->f:LI/b0;

    .line 52
    .line 53
    invoke-interface {v0, p1}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 57
    .line 58
    return-object p1

    .line 59
    :pswitch_0
    check-cast p1, LU1/a;

    .line 60
    .line 61
    new-instance v0, LB/y;

    .line 62
    .line 63
    const/16 v1, 0x8

    .line 64
    .line 65
    invoke-direct {v0, v1, p1}, LB/y;-><init>(ILjava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    new-instance p1, LH/p0;

    .line 69
    .line 70
    const/4 v1, 0x1

    .line 71
    iget-object v2, p0, LH/p0;->e:LT0/c;

    .line 72
    .line 73
    iget-object v3, p0, LH/p0;->f:LI/b0;

    .line 74
    .line 75
    invoke-direct {p1, v2, v3, v1}, LH/p0;-><init>(LT0/c;LI/b0;I)V

    .line 76
    .line 77
    .line 78
    invoke-static {}, Ln/X;->a()Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-eqz v1, :cond_2

    .line 83
    .line 84
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 85
    .line 86
    const/16 v2, 0x1c

    .line 87
    .line 88
    if-ne v1, v2, :cond_0

    .line 89
    .line 90
    sget-object v1, Ln/k0;->b:Ln/k0;

    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_0
    sget-object v1, Ln/k0;->c:Ln/k0;

    .line 94
    .line 95
    :goto_0
    invoke-static {}, Ln/X;->a()Z

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    if-eqz v2, :cond_1

    .line 100
    .line 101
    new-instance v2, Ln/T;

    .line 102
    .line 103
    invoke-direct {v2, v0, p1, v1}, Ln/T;-><init>(LB/y;LH/p0;Ln/i0;)V

    .line 104
    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_1
    sget-object v2, LW/n;->a:LW/n;

    .line 108
    .line 109
    :goto_1
    return-object v2

    .line 110
    :cond_2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 111
    .line 112
    const-string v0, "Magnifier is only supported on API level 28 and higher."

    .line 113
    .line 114
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw p1

    .line 118
    nop

    .line 119
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
