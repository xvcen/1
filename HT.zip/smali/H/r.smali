.class public final LH/r;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:Lk2/c;

.field public i:LH/s;

.field public j:Ljava/lang/CharSequence;

.field public k:J

.field public l:I

.field public synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/CharSequence;

.field public final synthetic o:J

.field public final synthetic p:LH/s;


# direct methods
.method public constructor <init>(JLH/s;LN1/c;Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    iput-object p5, p0, LH/r;->n:Ljava/lang/CharSequence;

    .line 2
    .line 3
    iput-wide p1, p0, LH/r;->o:J

    .line 4
    .line 5
    iput-object p3, p0, LH/r;->p:LH/s;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1}, LA0/a;->n(Ljava/lang/Object;)Landroid/view/textclassifier/TextClassifier;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    check-cast p2, LN1/c;

    .line 6
    .line 7
    invoke-virtual {p0, p2, p1}, LH/r;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, LH/r;

    .line 12
    .line 13
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 14
    .line 15
    invoke-virtual {p1, p2}, LH/r;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 6

    .line 1
    new-instance v0, LH/r;

    .line 2
    .line 3
    iget-wide v1, p0, LH/r;->o:J

    .line 4
    .line 5
    iget-object v3, p0, LH/r;->p:LH/s;

    .line 6
    .line 7
    iget-object v5, p0, LH/r;->n:Ljava/lang/CharSequence;

    .line 8
    .line 9
    move-object v4, p1

    .line 10
    invoke-direct/range {v0 .. v5}, LH/r;-><init>(JLH/s;LN1/c;Ljava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    iput-object p2, v0, LH/r;->m:Ljava/lang/Object;

    .line 14
    .line 15
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, LH/r;->l:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    if-eq v0, v2, :cond_1

    .line 8
    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    iget-wide v0, p0, LH/r;->k:J

    .line 12
    .line 13
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    goto/16 :goto_2

    .line 17
    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    .line 20
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    iget-wide v0, p0, LH/r;->k:J

    .line 27
    .line 28
    iget-object v2, p0, LH/r;->j:Ljava/lang/CharSequence;

    .line 29
    .line 30
    iget-object v3, p0, LH/r;->i:LH/s;

    .line 31
    .line 32
    iget-object v4, p0, LH/r;->h:Lk2/c;

    .line 33
    .line 34
    iget-object v5, p0, LH/r;->m:Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v5}, LA0/a;->o(Ljava/lang/Object;)Landroid/view/textclassifier/TextSelection;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, LH/r;->m:Ljava/lang/Object;

    .line 48
    .line 49
    invoke-static {p1}, LA0/a;->n(Ljava/lang/Object;)Landroid/view/textclassifier/TextClassifier;

    .line 50
    .line 51
    .line 52
    move-result-object v7

    .line 53
    invoke-static {}, LA1/g0;->B()V

    .line 54
    .line 55
    .line 56
    iget-wide v3, p0, LH/r;->o:J

    .line 57
    .line 58
    invoke-static {v3, v4}, LH0/N;->f(J)I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    invoke-static {v3, v4}, LH0/N;->e(J)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    iget-object v3, p0, LH/r;->n:Ljava/lang/CharSequence;

    .line 67
    .line 68
    invoke-static {v3, p1, v0}, LA1/g0;->n(Ljava/lang/CharSequence;II)Landroid/view/textclassifier/TextSelection$Request$Builder;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    iget-object v0, p0, LH/r;->p:LH/s;

    .line 73
    .line 74
    invoke-virtual {v0}, LH/s;->b()Landroid/os/LocaleList;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    invoke-static {p1, v4}, LA1/g0;->m(Landroid/view/textclassifier/TextSelection$Request$Builder;Landroid/os/LocaleList;)Landroid/view/textclassifier/TextSelection$Request$Builder;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 83
    .line 84
    const/16 v5, 0x1f

    .line 85
    .line 86
    if-lt v4, v5, :cond_3

    .line 87
    .line 88
    invoke-static {p1}, LD0/a;->B(Landroid/view/textclassifier/TextSelection$Request$Builder;)V

    .line 89
    .line 90
    .line 91
    :cond_3
    invoke-static {p1}, LA1/g0;->o(Landroid/view/textclassifier/TextSelection$Request$Builder;)Landroid/view/textclassifier/TextSelection$Request;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-static {v7, p1}, LA1/g0;->p(Landroid/view/textclassifier/TextClassifier;Landroid/view/textclassifier/TextSelection$Request;)Landroid/view/textclassifier/TextSelection;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    invoke-static {p1}, LA0/a;->b(Landroid/view/textclassifier/TextSelection;)I

    .line 100
    .line 101
    .line 102
    move-result v6

    .line 103
    invoke-static {p1}, LA0/a;->D(Landroid/view/textclassifier/TextSelection;)I

    .line 104
    .line 105
    .line 106
    move-result v8

    .line 107
    invoke-static {v6, v8}, LH0/F;->b(II)J

    .line 108
    .line 109
    .line 110
    move-result-wide v8

    .line 111
    sget-object v10, LO1/a;->d:LO1/a;

    .line 112
    .line 113
    if-lt v4, v5, :cond_5

    .line 114
    .line 115
    invoke-static {p1}, LD0/a;->l(Landroid/view/textclassifier/TextSelection;)Landroid/view/textclassifier/TextClassification;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    if-eqz v4, :cond_5

    .line 120
    .line 121
    iget-object v4, v0, LH/s;->e:Lk2/c;

    .line 122
    .line 123
    iput-object p1, p0, LH/r;->m:Ljava/lang/Object;

    .line 124
    .line 125
    iput-object v4, p0, LH/r;->h:Lk2/c;

    .line 126
    .line 127
    iput-object v0, p0, LH/r;->i:LH/s;

    .line 128
    .line 129
    iput-object v3, p0, LH/r;->j:Ljava/lang/CharSequence;

    .line 130
    .line 131
    iput-wide v8, p0, LH/r;->k:J

    .line 132
    .line 133
    iput v2, p0, LH/r;->l:I

    .line 134
    .line 135
    invoke-virtual {v4, p0}, Lk2/c;->d(LP1/c;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    if-ne v1, v10, :cond_4

    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_4
    move-object v5, p1

    .line 143
    move-object v2, v3

    .line 144
    move-object v3, v0

    .line 145
    move-wide v0, v8

    .line 146
    :goto_0
    const/4 p1, 0x0

    .line 147
    :try_start_0
    new-instance v6, LH/Y;

    .line 148
    .line 149
    invoke-static {v5}, LD0/a;->l(Landroid/view/textclassifier/TextSelection;)Landroid/view/textclassifier/TextClassification;

    .line 150
    .line 151
    .line 152
    move-result-object v5

    .line 153
    invoke-static {v5}, LV1/i;->b(Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    invoke-direct {v6, v2, v0, v1, v5}, LH/Y;-><init>(Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassification;)V

    .line 157
    .line 158
    .line 159
    iget-object v2, v3, LH/s;->g:LI/m0;

    .line 160
    .line 161
    invoke-virtual {v2, v6}, LI/m0;->setValue(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 162
    .line 163
    .line 164
    invoke-virtual {v4, p1}, Lk2/c;->f(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    goto :goto_2

    .line 168
    :catchall_0
    move-exception v0

    .line 169
    invoke-virtual {v4, p1}, Lk2/c;->f(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    throw v0

    .line 173
    :cond_5
    iput-wide v8, p0, LH/r;->k:J

    .line 174
    .line 175
    iput v1, p0, LH/r;->l:I

    .line 176
    .line 177
    iget-object v3, p0, LH/r;->p:LH/s;

    .line 178
    .line 179
    iget-object v4, p0, LH/r;->n:Ljava/lang/CharSequence;

    .line 180
    .line 181
    move-wide v5, v8

    .line 182
    move-object v8, p0

    .line 183
    invoke-static/range {v3 .. v8}, LH/s;->a(LH/s;Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassifier;LP1/c;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    if-ne p1, v10, :cond_6

    .line 188
    .line 189
    :goto_1
    return-object v10

    .line 190
    :cond_6
    move-wide v0, v5

    .line 191
    :goto_2
    new-instance p1, LH0/N;

    .line 192
    .line 193
    invoke-direct {p1, v0, v1}, LH0/N;-><init>(J)V

    .line 194
    .line 195
    .line 196
    return-object p1
.end method
