.class public final synthetic LH/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/g;


# virtual methods
.method public final k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, LN1/h;

    .line 2
    .line 3
    check-cast p2, Landroid/content/Context;

    .line 4
    .line 5
    check-cast p3, LH/w;

    .line 6
    .line 7
    check-cast p4, LO0/b;

    .line 8
    .line 9
    new-instance v0, LH/s;

    .line 10
    .line 11
    invoke-direct {v0, p1, p2, p3, p4}, LH/s;-><init>(LN1/h;Landroid/content/Context;LH/w;LO0/b;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method
