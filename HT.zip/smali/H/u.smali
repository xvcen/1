.class public abstract LH/u;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LI/b1;

.field public static final b:LH/t;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LA1/u;

    .line 2
    .line 3
    const/16 v1, 0x13

    .line 4
    .line 5
    invoke-direct {v0, v1}, LA1/u;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, LI/b1;

    .line 9
    .line 10
    invoke-direct {v1, v0}, LI/t0;-><init>(LU1/a;)V

    .line 11
    .line 12
    .line 13
    sput-object v1, LH/u;->a:LI/b1;

    .line 14
    .line 15
    new-instance v0, LH/t;

    .line 16
    .line 17
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, LH/u;->b:LH/t;

    .line 21
    .line 22
    return-void
.end method
