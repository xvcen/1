.class public abstract LH/u0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LI/B;

.field public static final b:LH/t0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, LA1/u;

    .line 2
    .line 3
    const/16 v1, 0x15

    .line 4
    .line 5
    invoke-direct {v0, v1}, LA1/u;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, LI/B;

    .line 9
    .line 10
    invoke-direct {v1, v0}, LI/B;-><init>(LU1/a;)V

    .line 11
    .line 12
    .line 13
    sput-object v1, LH/u0;->a:LI/B;

    .line 14
    .line 15
    const-wide v0, 0xff4286f4L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, Ld0/D;->c(J)J

    .line 21
    .line 22
    .line 23
    move-result-wide v0

    .line 24
    new-instance v2, LH/t0;

    .line 25
    .line 26
    const v3, 0x3ecccccd    # 0.4f

    .line 27
    .line 28
    .line 29
    invoke-static {v0, v1, v3}, Ld0/w;->b(JF)J

    .line 30
    .line 31
    .line 32
    move-result-wide v3

    .line 33
    invoke-direct {v2, v0, v1, v3, v4}, LH/t0;-><init>(JJ)V

    .line 34
    .line 35
    .line 36
    sput-object v2, LH/u0;->b:LH/t0;

    .line 37
    .line 38
    return-void
.end method
