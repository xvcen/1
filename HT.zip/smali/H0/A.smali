.class public final synthetic LH0/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LH0/A;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p0

    .line 4
    .line 5
    iget v2, v1, LH0/A;->d:I

    .line 6
    .line 7
    sget-object v3, LJ1/m;->a:LJ1/m;

    .line 8
    .line 9
    const/4 v4, 0x2

    .line 10
    const-string v5, "element"

    .line 11
    .line 12
    const-string v6, "acc"

    .line 13
    .line 14
    const/4 v7, 0x0

    .line 15
    sget-object v8, LT0/o;->d:LT0/o;

    .line 16
    .line 17
    const/high16 v9, 0x40000000    # 2.0f

    .line 18
    .line 19
    const/4 v10, -0x1

    .line 20
    const/4 v11, 0x0

    .line 21
    const/4 v12, 0x1

    .line 22
    packed-switch v2, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    check-cast v0, LT/b;

    .line 26
    .line 27
    move-object/from16 v0, p2

    .line 28
    .line 29
    check-cast v0, Lw/n0;

    .line 30
    .line 31
    iget-object v2, v0, Lw/n0;->a:LI/i0;

    .line 32
    .line 33
    invoke-virtual {v2}, LI/i0;->g()F

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    iget-object v0, v0, Lw/n0;->f:LI/m0;

    .line 42
    .line 43
    invoke-virtual {v0}, LI/m0;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lp/n0;

    .line 48
    .line 49
    sget-object v3, Lp/n0;->d:Lp/n0;

    .line 50
    .line 51
    if-ne v0, v3, :cond_0

    .line 52
    .line 53
    move v11, v12

    .line 54
    :cond_0
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    filled-new-array {v2, v0}, [Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-static {v0}, LX1/a;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    return-object v0

    .line 67
    :pswitch_0
    check-cast v0, Ljava/lang/Integer;

    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    move-object/from16 v2, p2

    .line 74
    .line 75
    check-cast v2, LT0/o;

    .line 76
    .line 77
    sub-int/2addr v0, v11

    .line 78
    int-to-float v0, v0

    .line 79
    div-float/2addr v0, v9

    .line 80
    const/4 v3, 0x0

    .line 81
    if-ne v2, v8, :cond_1

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_1
    int-to-float v2, v10

    .line 85
    mul-float/2addr v3, v2

    .line 86
    :goto_0
    int-to-float v2, v12

    .line 87
    add-float/2addr v2, v3

    .line 88
    mul-float/2addr v2, v0

    .line 89
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    return-object v0

    .line 98
    :pswitch_1
    check-cast v0, Ljava/lang/Integer;

    .line 99
    .line 100
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    move-object/from16 v2, p2

    .line 105
    .line 106
    check-cast v2, LT0/o;

    .line 107
    .line 108
    int-to-float v0, v0

    .line 109
    div-float/2addr v0, v9

    .line 110
    const/high16 v3, -0x40800000    # -1.0f

    .line 111
    .line 112
    if-ne v2, v8, :cond_2

    .line 113
    .line 114
    goto :goto_1

    .line 115
    :cond_2
    int-to-float v2, v10

    .line 116
    mul-float/2addr v3, v2

    .line 117
    :goto_1
    int-to-float v2, v12

    .line 118
    add-float/2addr v2, v3

    .line 119
    mul-float/2addr v2, v0

    .line 120
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    return-object v0

    .line 129
    :pswitch_2
    check-cast v0, LT/b;

    .line 130
    .line 131
    move-object/from16 v0, p2

    .line 132
    .line 133
    check-cast v0, Ln/q0;

    .line 134
    .line 135
    iget-object v0, v0, Ln/q0;->a:LI/j0;

    .line 136
    .line 137
    invoke-virtual {v0}, LI/j0;->g()I

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    return-object v0

    .line 146
    :pswitch_3
    check-cast v0, Lh2/w;

    .line 147
    .line 148
    move-object/from16 v2, p2

    .line 149
    .line 150
    check-cast v2, LN1/f;

    .line 151
    .line 152
    return-object v0

    .line 153
    :pswitch_4
    check-cast v0, Lc2/h0;

    .line 154
    .line 155
    move-object/from16 v2, p2

    .line 156
    .line 157
    check-cast v2, LN1/f;

    .line 158
    .line 159
    if-eqz v0, :cond_3

    .line 160
    .line 161
    move-object v7, v0

    .line 162
    goto :goto_2

    .line 163
    :cond_3
    instance-of v0, v2, Lc2/h0;

    .line 164
    .line 165
    if-eqz v0, :cond_4

    .line 166
    .line 167
    move-object v7, v2

    .line 168
    check-cast v7, Lc2/h0;

    .line 169
    .line 170
    :cond_4
    :goto_2
    return-object v7

    .line 171
    :pswitch_5
    move-object/from16 v2, p2

    .line 172
    .line 173
    check-cast v2, LN1/f;

    .line 174
    .line 175
    instance-of v3, v2, Lc2/h0;

    .line 176
    .line 177
    if-eqz v3, :cond_8

    .line 178
    .line 179
    instance-of v3, v0, Ljava/lang/Integer;

    .line 180
    .line 181
    if-eqz v3, :cond_5

    .line 182
    .line 183
    move-object v7, v0

    .line 184
    check-cast v7, Ljava/lang/Integer;

    .line 185
    .line 186
    :cond_5
    if-eqz v7, :cond_6

    .line 187
    .line 188
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 189
    .line 190
    .line 191
    move-result v0

    .line 192
    goto :goto_3

    .line 193
    :cond_6
    move v0, v12

    .line 194
    :goto_3
    if-nez v0, :cond_7

    .line 195
    .line 196
    move-object v0, v2

    .line 197
    goto :goto_4

    .line 198
    :cond_7
    add-int/2addr v0, v12

    .line 199
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    :cond_8
    :goto_4
    return-object v0

    .line 204
    :pswitch_6
    check-cast v0, Ljava/lang/Integer;

    .line 205
    .line 206
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 207
    .line 208
    .line 209
    move-result v0

    .line 210
    move-object/from16 v2, p2

    .line 211
    .line 212
    check-cast v2, LN1/f;

    .line 213
    .line 214
    add-int/2addr v0, v12

    .line 215
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    return-object v0

    .line 220
    :pswitch_7
    check-cast v0, Ljava/lang/Boolean;

    .line 221
    .line 222
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 223
    .line 224
    .line 225
    move-object/from16 v2, p2

    .line 226
    .line 227
    check-cast v2, LN1/f;

    .line 228
    .line 229
    return-object v0

    .line 230
    :pswitch_8
    check-cast v0, LN1/h;

    .line 231
    .line 232
    move-object/from16 v2, p2

    .line 233
    .line 234
    check-cast v2, LN1/f;

    .line 235
    .line 236
    invoke-interface {v0, v2}, LN1/h;->i(LN1/h;)LN1/h;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    return-object v0

    .line 241
    :pswitch_9
    check-cast v0, LN1/h;

    .line 242
    .line 243
    move-object/from16 v2, p2

    .line 244
    .line 245
    check-cast v2, LN1/f;

    .line 246
    .line 247
    invoke-interface {v0, v2}, LN1/h;->i(LN1/h;)LN1/h;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    return-object v0

    .line 252
    :pswitch_a
    check-cast v0, LT/b;

    .line 253
    .line 254
    return-object p2

    .line 255
    :pswitch_b
    check-cast v0, LN1/h;

    .line 256
    .line 257
    move-object/from16 v2, p2

    .line 258
    .line 259
    check-cast v2, LN1/f;

    .line 260
    .line 261
    invoke-static {v0, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    invoke-static {v2, v5}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    invoke-interface {v2}, LN1/f;->getKey()LN1/g;

    .line 268
    .line 269
    .line 270
    move-result-object v3

    .line 271
    invoke-interface {v0, v3}, LN1/h;->k(LN1/g;)LN1/h;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    sget-object v3, LN1/i;->d:LN1/i;

    .line 276
    .line 277
    if-ne v0, v3, :cond_9

    .line 278
    .line 279
    goto :goto_6

    .line 280
    :cond_9
    sget-object v4, LN1/d;->d:LN1/d;

    .line 281
    .line 282
    invoke-interface {v0, v4}, LN1/h;->r(LN1/g;)LN1/f;

    .line 283
    .line 284
    .line 285
    move-result-object v5

    .line 286
    check-cast v5, LN1/e;

    .line 287
    .line 288
    if-nez v5, :cond_a

    .line 289
    .line 290
    new-instance v3, LN1/b;

    .line 291
    .line 292
    invoke-direct {v3, v2, v0}, LN1/b;-><init>(LN1/f;LN1/h;)V

    .line 293
    .line 294
    .line 295
    :goto_5
    move-object v2, v3

    .line 296
    goto :goto_6

    .line 297
    :cond_a
    invoke-interface {v0, v4}, LN1/h;->k(LN1/g;)LN1/h;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    if-ne v0, v3, :cond_b

    .line 302
    .line 303
    new-instance v0, LN1/b;

    .line 304
    .line 305
    invoke-direct {v0, v5, v2}, LN1/b;-><init>(LN1/f;LN1/h;)V

    .line 306
    .line 307
    .line 308
    move-object v2, v0

    .line 309
    goto :goto_6

    .line 310
    :cond_b
    new-instance v3, LN1/b;

    .line 311
    .line 312
    new-instance v4, LN1/b;

    .line 313
    .line 314
    invoke-direct {v4, v2, v0}, LN1/b;-><init>(LN1/f;LN1/h;)V

    .line 315
    .line 316
    .line 317
    invoke-direct {v3, v5, v4}, LN1/b;-><init>(LN1/f;LN1/h;)V

    .line 318
    .line 319
    .line 320
    goto :goto_5

    .line 321
    :goto_6
    return-object v2

    .line 322
    :pswitch_c
    check-cast v0, Ljava/lang/String;

    .line 323
    .line 324
    move-object/from16 v2, p2

    .line 325
    .line 326
    check-cast v2, LN1/f;

    .line 327
    .line 328
    invoke-static {v0, v6}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 329
    .line 330
    .line 331
    invoke-static {v2, v5}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 335
    .line 336
    .line 337
    move-result v3

    .line 338
    if-nez v3, :cond_c

    .line 339
    .line 340
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    goto :goto_7

    .line 345
    :cond_c
    new-instance v3, Ljava/lang/StringBuilder;

    .line 346
    .line 347
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 351
    .line 352
    .line 353
    const-string v0, ", "

    .line 354
    .line 355
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 359
    .line 360
    .line 361
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 362
    .line 363
    .line 364
    move-result-object v0

    .line 365
    :goto_7
    return-object v0

    .line 366
    :pswitch_d
    check-cast v0, LI/r;

    .line 367
    .line 368
    move-object/from16 v2, p2

    .line 369
    .line 370
    check-cast v2, Ljava/lang/Integer;

    .line 371
    .line 372
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 373
    .line 374
    .line 375
    move-result v2

    .line 376
    and-int/lit8 v5, v2, 0x3

    .line 377
    .line 378
    if-eq v5, v4, :cond_d

    .line 379
    .line 380
    move v11, v12

    .line 381
    :cond_d
    and-int/2addr v2, v12

    .line 382
    invoke-virtual {v0, v2, v11}, LI/r;->N(IZ)Z

    .line 383
    .line 384
    .line 385
    move-result v2

    .line 386
    if-eqz v2, :cond_e

    .line 387
    .line 388
    goto :goto_8

    .line 389
    :cond_e
    invoke-virtual {v0}, LI/r;->Q()V

    .line 390
    .line 391
    .line 392
    :goto_8
    return-object v3

    .line 393
    :pswitch_e
    check-cast v0, LI/r;

    .line 394
    .line 395
    move-object/from16 v2, p2

    .line 396
    .line 397
    check-cast v2, Ljava/lang/Integer;

    .line 398
    .line 399
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 400
    .line 401
    .line 402
    move-result v2

    .line 403
    and-int/lit8 v5, v2, 0x3

    .line 404
    .line 405
    if-eq v5, v4, :cond_f

    .line 406
    .line 407
    move v11, v12

    .line 408
    :cond_f
    and-int/2addr v2, v12

    .line 409
    invoke-virtual {v0, v2, v11}, LI/r;->N(IZ)Z

    .line 410
    .line 411
    .line 412
    move-result v2

    .line 413
    if-eqz v2, :cond_10

    .line 414
    .line 415
    goto :goto_9

    .line 416
    :cond_10
    invoke-virtual {v0}, LI/r;->Q()V

    .line 417
    .line 418
    .line 419
    :goto_9
    return-object v3

    .line 420
    :pswitch_f
    check-cast v0, LT/b;

    .line 421
    .line 422
    move-object/from16 v0, p2

    .line 423
    .line 424
    check-cast v0, LS0/r;

    .line 425
    .line 426
    iget v0, v0, LS0/r;->a:I

    .line 427
    .line 428
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 429
    .line 430
    .line 431
    move-result-object v0

    .line 432
    return-object v0

    .line 433
    :pswitch_10
    check-cast v0, LT/b;

    .line 434
    .line 435
    move-object/from16 v2, p2

    .line 436
    .line 437
    check-cast v2, LS0/s;

    .line 438
    .line 439
    iget v3, v2, LS0/s;->a:I

    .line 440
    .line 441
    new-instance v4, LS0/r;

    .line 442
    .line 443
    invoke-direct {v4, v3}, LS0/r;-><init>(I)V

    .line 444
    .line 445
    .line 446
    sget-object v3, LH0/F;->e:LF/r;

    .line 447
    .line 448
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    iget-boolean v2, v2, LS0/s;->b:Z

    .line 453
    .line 454
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 455
    .line 456
    .line 457
    move-result-object v2

    .line 458
    filled-new-array {v0, v2}, [Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    move-result-object v0

    .line 462
    invoke-static {v0}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 463
    .line 464
    .line 465
    move-result-object v0

    .line 466
    return-object v0

    .line 467
    :pswitch_11
    check-cast v0, LT/b;

    .line 468
    .line 469
    move-object/from16 v0, p2

    .line 470
    .line 471
    check-cast v0, LS0/e;

    .line 472
    .line 473
    iget v0, v0, LS0/e;->a:I

    .line 474
    .line 475
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 476
    .line 477
    .line 478
    move-result-object v0

    .line 479
    return-object v0

    .line 480
    :pswitch_12
    check-cast v0, LT/b;

    .line 481
    .line 482
    move-object/from16 v0, p2

    .line 483
    .line 484
    check-cast v0, LH0/j;

    .line 485
    .line 486
    iget v0, v0, LH0/j;->a:I

    .line 487
    .line 488
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    return-object v0

    .line 493
    :pswitch_13
    check-cast v0, LT/b;

    .line 494
    .line 495
    move-object/from16 v2, p2

    .line 496
    .line 497
    check-cast v2, LH0/x;

    .line 498
    .line 499
    iget-boolean v3, v2, LH0/x;->a:Z

    .line 500
    .line 501
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 502
    .line 503
    .line 504
    move-result-object v3

    .line 505
    sget-object v4, LH0/E;->a:LF/r;

    .line 506
    .line 507
    iget v2, v2, LH0/x;->b:I

    .line 508
    .line 509
    new-instance v4, LH0/j;

    .line 510
    .line 511
    invoke-direct {v4, v2}, LH0/j;-><init>(I)V

    .line 512
    .line 513
    .line 514
    sget-object v2, LH0/F;->b:LF/r;

    .line 515
    .line 516
    invoke-static {v4, v2, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v0

    .line 520
    filled-new-array {v3, v0}, [Ljava/lang/Object;

    .line 521
    .line 522
    .line 523
    move-result-object v0

    .line 524
    invoke-static {v0}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    return-object v0

    .line 529
    :pswitch_14
    check-cast v0, LT/b;

    .line 530
    .line 531
    move-object/from16 v2, p2

    .line 532
    .line 533
    check-cast v2, LH0/M;

    .line 534
    .line 535
    iget-object v3, v2, LH0/M;->a:LH0/G;

    .line 536
    .line 537
    sget-object v4, LH0/E;->h:LF/r;

    .line 538
    .line 539
    invoke-static {v3, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 540
    .line 541
    .line 542
    move-result-object v3

    .line 543
    iget-object v5, v2, LH0/M;->b:LH0/G;

    .line 544
    .line 545
    invoke-static {v5, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 546
    .line 547
    .line 548
    move-result-object v5

    .line 549
    iget-object v6, v2, LH0/M;->c:LH0/G;

    .line 550
    .line 551
    invoke-static {v6, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 552
    .line 553
    .line 554
    move-result-object v6

    .line 555
    iget-object v2, v2, LH0/M;->d:LH0/G;

    .line 556
    .line 557
    invoke-static {v2, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 558
    .line 559
    .line 560
    move-result-object v0

    .line 561
    filled-new-array {v3, v5, v6, v0}, [Ljava/lang/Object;

    .line 562
    .line 563
    .line 564
    move-result-object v0

    .line 565
    invoke-static {v0}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 566
    .line 567
    .line 568
    move-result-object v0

    .line 569
    return-object v0

    .line 570
    :pswitch_15
    check-cast v0, LT/b;

    .line 571
    .line 572
    move-object/from16 v2, p2

    .line 573
    .line 574
    check-cast v2, LH0/G;

    .line 575
    .line 576
    iget-object v3, v2, LH0/G;->a:LS0/o;

    .line 577
    .line 578
    invoke-interface {v3}, LS0/o;->a()J

    .line 579
    .line 580
    .line 581
    move-result-wide v3

    .line 582
    new-instance v5, Ld0/w;

    .line 583
    .line 584
    invoke-direct {v5, v3, v4}, Ld0/w;-><init>(J)V

    .line 585
    .line 586
    .line 587
    sget-object v3, LH0/E;->p:LH0/D;

    .line 588
    .line 589
    invoke-static {v5, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    move-result-object v11

    .line 593
    iget-wide v4, v2, LH0/G;->b:J

    .line 594
    .line 595
    new-instance v6, LT0/q;

    .line 596
    .line 597
    invoke-direct {v6, v4, v5}, LT0/q;-><init>(J)V

    .line 598
    .line 599
    .line 600
    sget-object v4, LH0/E;->v:LH0/D;

    .line 601
    .line 602
    invoke-static {v6, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 603
    .line 604
    .line 605
    move-result-object v12

    .line 606
    iget-object v5, v2, LH0/G;->c:LL0/k;

    .line 607
    .line 608
    sget-object v6, LL0/k;->e:LL0/k;

    .line 609
    .line 610
    sget-object v6, LH0/E;->m:LF/r;

    .line 611
    .line 612
    invoke-static {v5, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 613
    .line 614
    .line 615
    move-result-object v13

    .line 616
    iget-object v5, v2, LH0/G;->d:LL0/i;

    .line 617
    .line 618
    sget-object v6, LH0/E;->t:LF/r;

    .line 619
    .line 620
    invoke-static {v5, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 621
    .line 622
    .line 623
    move-result-object v14

    .line 624
    iget-object v5, v2, LH0/G;->e:LL0/j;

    .line 625
    .line 626
    sget-object v6, LH0/E;->u:LF/r;

    .line 627
    .line 628
    invoke-static {v5, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    move-result-object v15

    .line 632
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 633
    .line 634
    .line 635
    move-result-object v16

    .line 636
    iget-object v5, v2, LH0/G;->g:Ljava/lang/String;

    .line 637
    .line 638
    iget-wide v6, v2, LH0/G;->h:J

    .line 639
    .line 640
    new-instance v8, LT0/q;

    .line 641
    .line 642
    invoke-direct {v8, v6, v7}, LT0/q;-><init>(J)V

    .line 643
    .line 644
    .line 645
    invoke-static {v8, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 646
    .line 647
    .line 648
    move-result-object v18

    .line 649
    iget-object v4, v2, LH0/G;->i:LS0/a;

    .line 650
    .line 651
    sget-object v6, LH0/E;->n:LF/r;

    .line 652
    .line 653
    invoke-static {v4, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 654
    .line 655
    .line 656
    move-result-object v19

    .line 657
    iget-object v4, v2, LH0/G;->j:LS0/p;

    .line 658
    .line 659
    sget-object v6, LH0/E;->k:LF/r;

    .line 660
    .line 661
    invoke-static {v4, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 662
    .line 663
    .line 664
    move-result-object v20

    .line 665
    iget-object v4, v2, LH0/G;->k:LO0/b;

    .line 666
    .line 667
    sget-object v6, LO0/b;->f:LO0/b;

    .line 668
    .line 669
    sget-object v6, LH0/E;->y:LF/r;

    .line 670
    .line 671
    invoke-static {v4, v6, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 672
    .line 673
    .line 674
    move-result-object v21

    .line 675
    iget-wide v6, v2, LH0/G;->l:J

    .line 676
    .line 677
    new-instance v4, Ld0/w;

    .line 678
    .line 679
    invoke-direct {v4, v6, v7}, Ld0/w;-><init>(J)V

    .line 680
    .line 681
    .line 682
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 683
    .line 684
    .line 685
    move-result-object v22

    .line 686
    iget-object v3, v2, LH0/G;->m:LS0/l;

    .line 687
    .line 688
    sget-object v4, LH0/E;->j:LF/r;

    .line 689
    .line 690
    invoke-static {v3, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 691
    .line 692
    .line 693
    move-result-object v23

    .line 694
    iget-object v2, v2, LH0/G;->n:Ld0/S;

    .line 695
    .line 696
    sget-object v3, Ld0/S;->d:Ld0/S;

    .line 697
    .line 698
    sget-object v3, LH0/E;->o:LF/r;

    .line 699
    .line 700
    invoke-static {v2, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 701
    .line 702
    .line 703
    move-result-object v24

    .line 704
    move-object/from16 v17, v5

    .line 705
    .line 706
    filled-new-array/range {v11 .. v24}, [Ljava/lang/Object;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    invoke-static {v0}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 711
    .line 712
    .line 713
    move-result-object v0

    .line 714
    return-object v0

    .line 715
    :pswitch_16
    check-cast v0, LT/b;

    .line 716
    .line 717
    move-object/from16 v0, p2

    .line 718
    .line 719
    check-cast v0, LH0/P;

    .line 720
    .line 721
    iget-object v0, v0, LH0/P;->a:Ljava/lang/String;

    .line 722
    .line 723
    return-object v0

    .line 724
    :pswitch_17
    check-cast v0, LT/b;

    .line 725
    .line 726
    move-object/from16 v2, p2

    .line 727
    .line 728
    check-cast v2, LH0/v;

    .line 729
    .line 730
    iget v3, v2, LH0/v;->a:I

    .line 731
    .line 732
    new-instance v4, LS0/k;

    .line 733
    .line 734
    invoke-direct {v4, v3}, LS0/k;-><init>(I)V

    .line 735
    .line 736
    .line 737
    sget-object v3, LH0/E;->q:LH0/D;

    .line 738
    .line 739
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 740
    .line 741
    .line 742
    move-result-object v5

    .line 743
    iget v3, v2, LH0/v;->b:I

    .line 744
    .line 745
    new-instance v4, LS0/m;

    .line 746
    .line 747
    invoke-direct {v4, v3}, LS0/m;-><init>(I)V

    .line 748
    .line 749
    .line 750
    sget-object v3, LH0/E;->r:LH0/D;

    .line 751
    .line 752
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 753
    .line 754
    .line 755
    move-result-object v6

    .line 756
    iget-wide v3, v2, LH0/v;->c:J

    .line 757
    .line 758
    new-instance v7, LT0/q;

    .line 759
    .line 760
    invoke-direct {v7, v3, v4}, LT0/q;-><init>(J)V

    .line 761
    .line 762
    .line 763
    sget-object v3, LH0/E;->v:LH0/D;

    .line 764
    .line 765
    invoke-static {v7, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 766
    .line 767
    .line 768
    move-result-object v7

    .line 769
    iget-object v3, v2, LH0/v;->d:LS0/q;

    .line 770
    .line 771
    sget-object v4, LS0/q;->c:LS0/q;

    .line 772
    .line 773
    sget-object v4, LH0/E;->l:LF/r;

    .line 774
    .line 775
    invoke-static {v3, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 776
    .line 777
    .line 778
    move-result-object v8

    .line 779
    iget-object v3, v2, LH0/v;->e:LH0/x;

    .line 780
    .line 781
    sget-object v4, LH0/F;->a:LF/r;

    .line 782
    .line 783
    invoke-static {v3, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 784
    .line 785
    .line 786
    move-result-object v9

    .line 787
    iget-object v3, v2, LH0/v;->f:LS0/i;

    .line 788
    .line 789
    sget-object v4, LS0/i;->d:LS0/i;

    .line 790
    .line 791
    sget-object v4, LH0/E;->A:LF/r;

    .line 792
    .line 793
    invoke-static {v3, v4, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 794
    .line 795
    .line 796
    move-result-object v10

    .line 797
    iget v3, v2, LH0/v;->g:I

    .line 798
    .line 799
    new-instance v4, LS0/e;

    .line 800
    .line 801
    invoke-direct {v4, v3}, LS0/e;-><init>(I)V

    .line 802
    .line 803
    .line 804
    sget-object v3, LH0/F;->c:LF/r;

    .line 805
    .line 806
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 807
    .line 808
    .line 809
    move-result-object v11

    .line 810
    iget v3, v2, LH0/v;->h:I

    .line 811
    .line 812
    new-instance v4, LS0/d;

    .line 813
    .line 814
    invoke-direct {v4, v3}, LS0/d;-><init>(I)V

    .line 815
    .line 816
    .line 817
    sget-object v3, LH0/E;->s:LH0/D;

    .line 818
    .line 819
    invoke-static {v4, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 820
    .line 821
    .line 822
    move-result-object v12

    .line 823
    iget-object v2, v2, LH0/v;->i:LS0/s;

    .line 824
    .line 825
    sget-object v3, LH0/F;->d:LF/r;

    .line 826
    .line 827
    invoke-static {v2, v3, v0}, LH0/E;->a(Ljava/lang/Object;LT/f;LT/b;)Ljava/lang/Object;

    .line 828
    .line 829
    .line 830
    move-result-object v13

    .line 831
    filled-new-array/range {v5 .. v13}, [Ljava/lang/Object;

    .line 832
    .line 833
    .line 834
    move-result-object v0

    .line 835
    invoke-static {v0}, LX1/a;->B([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 836
    .line 837
    .line 838
    move-result-object v0

    .line 839
    return-object v0

    .line 840
    nop

    .line 841
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
