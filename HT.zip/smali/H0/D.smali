.class public final LH0/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LT/f;


# instance fields
.field public final synthetic d:LU1/e;

.field public final synthetic e:LU1/c;


# direct methods
.method public constructor <init>(LU1/e;LU1/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LH0/D;->d:LU1/e;

    .line 5
    .line 6
    iput-object p2, p0, LH0/D;->e:LU1/c;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(LT/b;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LH0/D;->d:LU1/e;

    .line 2
    .line 3
    invoke-interface {v0, p1, p2}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LH0/D;->e:LU1/c;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
