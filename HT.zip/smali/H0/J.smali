.class public final LH0/J;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LH/z;

.field public static final b:LH/z;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LH/z;

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LH0/J;->a:LH/z;

    .line 8
    .line 9
    new-instance v0, LH/z;

    .line 10
    .line 11
    const/4 v1, 0x5

    .line 12
    invoke-direct {v0, v1}, LH/z;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LH0/J;->b:LH/z;

    .line 16
    .line 17
    return-void
.end method
