.class public abstract LH0/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH0/b;
