.class public final synthetic LH0/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;III)V
    .locals 0

    .line 1
    iput p4, p0, LH0/o;->d:I

    iput-object p1, p0, LH0/o;->g:Ljava/lang/Object;

    iput p2, p0, LH0/o;->e:I

    iput p3, p0, LH0/o;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LH0/o;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LH0/o;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lu0/L;

    .line 9
    .line 10
    iget v1, p0, LH0/o;->f:I

    .line 11
    .line 12
    check-cast p1, Lu0/K;

    .line 13
    .line 14
    iget v2, p0, LH0/o;->e:I

    .line 15
    .line 16
    invoke-static {p1, v0, v2, v1}, Lu0/K;->x(Lu0/K;Lu0/L;II)V

    .line 17
    .line 18
    .line 19
    :goto_0
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 20
    .line 21
    return-object p1

    .line 22
    :pswitch_0
    iget-object v0, p0, LH0/o;->g:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Ld0/j;

    .line 25
    .line 26
    check-cast p1, LH0/s;

    .line 27
    .line 28
    iget-object v1, p1, LH0/s;->a:LH0/a;

    .line 29
    .line 30
    iget v2, p0, LH0/o;->e:I

    .line 31
    .line 32
    invoke-virtual {p1, v2}, LH0/s;->d(I)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    iget v3, p0, LH0/o;->f:I

    .line 37
    .line 38
    invoke-virtual {p1, v3}, LH0/s;->d(I)I

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    iget-object v4, v1, LH0/a;->e:Ljava/lang/CharSequence;

    .line 43
    .line 44
    if-ltz v2, :cond_0

    .line 45
    .line 46
    if-gt v2, v3, :cond_0

    .line 47
    .line 48
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-gt v3, v5, :cond_0

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_0
    new-instance v5, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    const-string v6, "start("

    .line 58
    .line 59
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v6, ") or end("

    .line 66
    .line 67
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v6, ") is out of range [0.."

    .line 74
    .line 75
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 79
    .line 80
    .line 81
    move-result v4

    .line 82
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    const-string v4, "], or start > end!"

    .line 86
    .line 87
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    invoke-static {v4}, LN0/a;->a(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    :goto_1
    new-instance v4, Landroid/graphics/Path;

    .line 98
    .line 99
    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    .line 100
    .line 101
    .line 102
    iget-object v1, v1, LH0/a;->d:LI0/m;

    .line 103
    .line 104
    iget-object v5, v1, LI0/m;->f:Landroid/text/Layout;

    .line 105
    .line 106
    invoke-virtual {v5, v2, v3, v4}, Landroid/text/Layout;->getSelectionPath(IILandroid/graphics/Path;)V

    .line 107
    .line 108
    .line 109
    iget v1, v1, LI0/m;->h:I

    .line 110
    .line 111
    const/4 v2, 0x0

    .line 112
    if-eqz v1, :cond_1

    .line 113
    .line 114
    invoke-virtual {v4}, Landroid/graphics/Path;->isEmpty()Z

    .line 115
    .line 116
    .line 117
    move-result v3

    .line 118
    if-nez v3, :cond_1

    .line 119
    .line 120
    int-to-float v1, v1

    .line 121
    invoke-virtual {v4, v2, v1}, Landroid/graphics/Path;->offset(FF)V

    .line 122
    .line 123
    .line 124
    :cond_1
    iget p1, p1, LH0/s;->f:F

    .line 125
    .line 126
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 127
    .line 128
    .line 129
    move-result v1

    .line 130
    int-to-long v1, v1

    .line 131
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 132
    .line 133
    .line 134
    move-result p1

    .line 135
    int-to-long v5, p1

    .line 136
    const/16 p1, 0x20

    .line 137
    .line 138
    shl-long/2addr v1, p1

    .line 139
    const-wide v7, 0xffffffffL

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    and-long/2addr v5, v7

    .line 145
    or-long/2addr v1, v5

    .line 146
    new-instance v3, Landroid/graphics/Matrix;

    .line 147
    .line 148
    invoke-direct {v3}, Landroid/graphics/Matrix;-><init>()V

    .line 149
    .line 150
    .line 151
    shr-long v5, v1, p1

    .line 152
    .line 153
    long-to-int p1, v5

    .line 154
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 155
    .line 156
    .line 157
    move-result p1

    .line 158
    and-long/2addr v1, v7

    .line 159
    long-to-int v1, v1

    .line 160
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    invoke-virtual {v3, p1, v1}, Landroid/graphics/Matrix;->setTranslate(FF)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v4, v3}, Landroid/graphics/Path;->transform(Landroid/graphics/Matrix;)V

    .line 168
    .line 169
    .line 170
    iget-object p1, v0, Ld0/j;->a:Landroid/graphics/Path;

    .line 171
    .line 172
    const-wide/16 v0, 0x0

    .line 173
    .line 174
    long-to-int v2, v0

    .line 175
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 176
    .line 177
    .line 178
    move-result v2

    .line 179
    long-to-int v0, v0

    .line 180
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 181
    .line 182
    .line 183
    move-result v0

    .line 184
    invoke-virtual {p1, v4, v2, v0}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;FF)V

    .line 185
    .line 186
    .line 187
    goto/16 :goto_0

    .line 188
    .line 189
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
