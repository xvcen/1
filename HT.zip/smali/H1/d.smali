.class public final LH1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH1/f;


# instance fields
.field public final a:F

.field public final b:LH1/c;


# direct methods
.method public constructor <init>(F)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, LH1/d;->a:F

    .line 5
    .line 6
    sget-object p1, LH1/c;->e:LH1/c;

    .line 7
    .line 8
    iput-object p1, p0, LH1/d;->b:LH1/c;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(JLT0/o;LT0/c;)Ld0/D;
    .locals 2

    .line 1
    const-string v0, "layoutDirection"

    .line 2
    .line 3
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p3, "density"

    .line 7
    .line 8
    invoke-static {p4, p3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget p3, p0, LH1/d;->a:F

    .line 12
    .line 13
    invoke-interface {p4, p3}, LT0/c;->K(F)F

    .line 14
    .line 15
    .line 16
    move-result p3

    .line 17
    invoke-static {p1, p2}, Lc0/e;->b(J)F

    .line 18
    .line 19
    .line 20
    move-result p4

    .line 21
    const/high16 v0, 0x3f000000    # 0.5f

    .line 22
    .line 23
    mul-float/2addr p4, v0

    .line 24
    const/4 v0, 0x0

    .line 25
    cmpg-float v1, p3, v0

    .line 26
    .line 27
    if-gez v1, :cond_0

    .line 28
    .line 29
    move p3, v0

    .line 30
    :cond_0
    cmpl-float v0, p3, p4

    .line 31
    .line 32
    if-lez v0, :cond_1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    move p4, p3

    .line 36
    :goto_0
    iget-object p3, p0, LH1/d;->b:LH1/c;

    .line 37
    .line 38
    invoke-static {p1, p2, p4, p3}, LX1/a;->e0(JFLH1/c;)Ld0/D;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    return-object p1
.end method

.method public final b(JLT0/o;LC1/f;)LH1/e;
    .locals 1

    .line 1
    const-string v0, "layoutDirection"

    .line 2
    .line 3
    invoke-static {p3, v0}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p3, "density"

    .line 7
    .line 8
    invoke-static {p4, p3}, LV1/i;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p4}, LC1/f;->g()F

    .line 12
    .line 13
    .line 14
    move-result p3

    .line 15
    iget p4, p0, LH1/d;->a:F

    .line 16
    .line 17
    mul-float/2addr p3, p4

    .line 18
    invoke-static {p1, p2}, Lc0/e;->b(J)F

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    const/high16 p2, 0x3f000000    # 0.5f

    .line 23
    .line 24
    mul-float/2addr p1, p2

    .line 25
    const/4 p2, 0x0

    .line 26
    cmpg-float p4, p3, p2

    .line 27
    .line 28
    if-gez p4, :cond_0

    .line 29
    .line 30
    move p3, p2

    .line 31
    :cond_0
    cmpl-float p2, p3, p1

    .line 32
    .line 33
    if-lez p2, :cond_1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    move p1, p3

    .line 37
    :goto_0
    new-instance p2, LH1/e;

    .line 38
    .line 39
    invoke-direct {p2, p1, p1, p1, p1}, LH1/e;-><init>(FFFF)V

    .line 40
    .line 41
    .line 42
    return-object p2
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_1

    .line 4
    :cond_0
    instance-of v0, p1, LH1/d;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_1
    check-cast p1, LH1/d;

    .line 10
    .line 11
    iget v0, p1, LH1/d;->a:F

    .line 12
    .line 13
    iget v1, p0, LH1/d;->a:F

    .line 14
    .line 15
    invoke-static {v1, v0}, LT0/f;->b(FF)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_2

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_2
    iget-object v0, p0, LH1/d;->b:LH1/c;

    .line 23
    .line 24
    iget-object p1, p1, LH1/d;->b:LH1/c;

    .line 25
    .line 26
    if-eq v0, p1, :cond_3

    .line 27
    .line 28
    :goto_0
    const/4 p1, 0x0

    .line 29
    return p1

    .line 30
    :cond_3
    :goto_1
    const/4 p1, 0x1

    .line 31
    return p1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget v0, p0, LH1/d;->a:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, LH1/d;->b:LH1/c;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, LH1/d;->a:F

    .line 2
    .line 3
    invoke-static {v0}, LT0/f;->c(F)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    const-string v2, "RoundedRectangle(cornerRadius="

    .line 10
    .line 11
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string v0, ", style="

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, LH1/d;->b:LH1/c;

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string v0, ")"

    .line 28
    .line 29
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method
