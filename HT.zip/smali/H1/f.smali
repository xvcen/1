.class public interface abstract LH1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld0/T;


# virtual methods
.method public abstract b(JLT0/o;LC1/f;)LH1/e;
.end method
