.class public interface abstract LI/A;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LI/z;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, LI/z;->a:LI/z;

    .line 2
    .line 3
    sput-object v0, LI/A;->a:LI/z;

    .line 4
    .line 5
    return-void
.end method
