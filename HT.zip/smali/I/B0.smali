.class public final LI/B0;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:LU/f;

.field public i:I

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:LI/E0;

.field public final synthetic l:LI/D0;

.field public final synthetic m:LI/g;


# direct methods
.method public constructor <init>(LI/E0;LI/D0;LI/g;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LI/B0;->k:LI/E0;

    .line 2
    .line 3
    iput-object p2, p0, LI/B0;->l:LI/D0;

    .line 4
    .line 5
    iput-object p3, p0, LI/B0;->m:LI/g;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LP1/i;-><init>(ILN1/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lc2/s;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LI/B0;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LI/B0;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LI/B0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 4

    .line 1
    new-instance v0, LI/B0;

    .line 2
    .line 3
    iget-object v1, p0, LI/B0;->l:LI/D0;

    .line 4
    .line 5
    iget-object v2, p0, LI/B0;->m:LI/g;

    .line 6
    .line 7
    iget-object v3, p0, LI/B0;->k:LI/E0;

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2, p1}, LI/B0;-><init>(LI/E0;LI/D0;LI/g;LN1/c;)V

    .line 10
    .line 11
    .line 12
    iput-object p2, v0, LI/B0;->j:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    sget-object v0, LO1/a;->d:LO1/a;

    .line 2
    .line 3
    iget v1, p0, LI/B0;->i:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    if-ne v1, v3, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, LI/B0;->h:LU/f;

    .line 12
    .line 13
    iget-object v1, p0, LI/B0;->j:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lc2/Q;

    .line 16
    .line 17
    :try_start_0
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    .line 19
    .line 20
    goto/16 :goto_2

    .line 21
    .line 22
    :catchall_0
    move-exception p1

    .line 23
    goto/16 :goto_5

    .line 24
    .line 25
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 26
    .line 27
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 28
    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    throw p1

    .line 33
    :cond_1
    invoke-static {p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object p1, p0, LI/B0;->j:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Lc2/s;

    .line 39
    .line 40
    invoke-interface {p1}, Lc2/s;->f()LN1/h;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-static {p1}, Lc2/u;->j(LN1/h;)Lc2/Q;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    iget-object p1, p0, LI/B0;->k:LI/E0;

    .line 49
    .line 50
    iget-object v4, p1, LI/E0;->c:Ljava/lang/Object;

    .line 51
    .line 52
    monitor-enter v4

    .line 53
    :try_start_1
    iget-object v5, p1, LI/E0;->e:Ljava/lang/Throwable;

    .line 54
    .line 55
    if-nez v5, :cond_d

    .line 56
    .line 57
    iget-object v5, p1, LI/E0;->u:Lf2/G;

    .line 58
    .line 59
    invoke-virtual {v5}, Lf2/G;->getValue()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    check-cast v5, LI/y0;

    .line 64
    .line 65
    sget-object v6, LI/y0;->e:LI/y0;

    .line 66
    .line 67
    invoke-virtual {v5, v6}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    if-lez v5, :cond_c

    .line 72
    .line 73
    iget-object v5, p1, LI/E0;->d:Lc2/Q;

    .line 74
    .line 75
    if-nez v5, :cond_b

    .line 76
    .line 77
    iput-object v1, p1, LI/E0;->d:Lc2/Q;

    .line 78
    .line 79
    invoke-virtual {p1}, LI/E0;->x()Lc2/f;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_6

    .line 80
    .line 81
    .line 82
    monitor-exit v4

    .line 83
    iget-object p1, p0, LI/B0;->k:LI/E0;

    .line 84
    .line 85
    new-instance v4, LA1/e;

    .line 86
    .line 87
    const/16 v5, 0xa

    .line 88
    .line 89
    invoke-direct {v4, v5, p1}, LA1/e;-><init>(ILjava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    sget-object p1, LU/p;->a:LH0/z;

    .line 93
    .line 94
    invoke-static {p1}, LU/p;->e(LU1/c;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    sget-object p1, LU/p;->c:Ljava/lang/Object;

    .line 98
    .line 99
    monitor-enter p1

    .line 100
    :try_start_2
    sget-object v5, LU/p;->h:Ljava/lang/Object;

    .line 101
    .line 102
    invoke-static {v5, v4}, LK1/m;->z0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    sput-object v5, LU/p;->h:Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    .line 107
    .line 108
    monitor-exit p1

    .line 109
    new-instance p1, LU/f;

    .line 110
    .line 111
    invoke-direct {p1, v4}, LU/f;-><init>(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    sget-object v4, LI/E0;->y:Lf2/G;

    .line 115
    .line 116
    iget-object v4, p0, LI/B0;->k:LI/E0;

    .line 117
    .line 118
    iget-object v4, v4, LI/E0;->x:LI/h;

    .line 119
    .line 120
    :cond_2
    sget-object v5, LI/E0;->y:Lf2/G;

    .line 121
    .line 122
    invoke-virtual {v5}, Lf2/G;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v6

    .line 126
    check-cast v6, LL/b;

    .line 127
    .line 128
    move-object v7, v6

    .line 129
    check-cast v7, LO/b;

    .line 130
    .line 131
    sget-object v8, LP/b;->a:LP/b;

    .line 132
    .line 133
    iget-object v9, v7, LO/b;->f:LN/c;

    .line 134
    .line 135
    invoke-virtual {v9, v4}, LN/c;->containsKey(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v10

    .line 139
    if-eqz v10, :cond_3

    .line 140
    .line 141
    goto :goto_0

    .line 142
    :cond_3
    invoke-virtual {v7}, LK1/a;->isEmpty()Z

    .line 143
    .line 144
    .line 145
    move-result v10

    .line 146
    if-eqz v10, :cond_4

    .line 147
    .line 148
    new-instance v7, LO/a;

    .line 149
    .line 150
    invoke-direct {v7, v8, v8}, LO/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v9, v4, v7}, LN/c;->a(Ljava/lang/Object;LO/a;)LN/c;

    .line 154
    .line 155
    .line 156
    move-result-object v7

    .line 157
    new-instance v8, LO/b;

    .line 158
    .line 159
    invoke-direct {v8, v4, v4, v7}, LO/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;LN/c;)V

    .line 160
    .line 161
    .line 162
    move-object v7, v8

    .line 163
    goto :goto_0

    .line 164
    :cond_4
    iget-object v10, v7, LO/b;->e:Ljava/lang/Object;

    .line 165
    .line 166
    invoke-virtual {v9, v10}, LN/c;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v11

    .line 170
    invoke-static {v11}, LV1/i;->b(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    check-cast v11, LO/a;

    .line 174
    .line 175
    new-instance v12, LO/a;

    .line 176
    .line 177
    iget-object v11, v11, LO/a;->a:Ljava/lang/Object;

    .line 178
    .line 179
    invoke-direct {v12, v11, v4}, LO/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v9, v10, v12}, LN/c;->a(Ljava/lang/Object;LO/a;)LN/c;

    .line 183
    .line 184
    .line 185
    move-result-object v9

    .line 186
    new-instance v11, LO/a;

    .line 187
    .line 188
    invoke-direct {v11, v10, v8}, LO/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v9, v4, v11}, LN/c;->a(Ljava/lang/Object;LO/a;)LN/c;

    .line 192
    .line 193
    .line 194
    move-result-object v8

    .line 195
    new-instance v9, LO/b;

    .line 196
    .line 197
    iget-object v7, v7, LO/b;->d:Ljava/lang/Object;

    .line 198
    .line 199
    invoke-direct {v9, v7, v4, v8}, LO/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;LN/c;)V

    .line 200
    .line 201
    .line 202
    move-object v7, v9

    .line 203
    :goto_0
    if-eq v6, v7, :cond_6

    .line 204
    .line 205
    sget-object v8, Lg2/c;->b:Lh2/t;

    .line 206
    .line 207
    if-nez v6, :cond_5

    .line 208
    .line 209
    move-object v6, v8

    .line 210
    :cond_5
    invoke-virtual {v5, v6, v7}, Lf2/G;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    move-result v5

    .line 214
    if-eqz v5, :cond_2

    .line 215
    .line 216
    :cond_6
    :try_start_3
    iget-object v4, p0, LI/B0;->k:LI/E0;

    .line 217
    .line 218
    iget-object v5, v4, LI/E0;->c:Ljava/lang/Object;

    .line 219
    .line 220
    monitor-enter v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 221
    :try_start_4
    invoke-virtual {v4}, LI/E0;->C()Ljava/util/List;

    .line 222
    .line 223
    .line 224
    move-result-object v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 225
    :try_start_5
    monitor-exit v5

    .line 226
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 227
    .line 228
    .line 229
    move-result v5

    .line 230
    const/4 v6, 0x0

    .line 231
    :goto_1
    if-ge v6, v5, :cond_7

    .line 232
    .line 233
    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v7

    .line 237
    check-cast v7, LI/y;

    .line 238
    .line 239
    invoke-virtual {v7}, LI/y;->o()V

    .line 240
    .line 241
    .line 242
    add-int/lit8 v6, v6, 0x1

    .line 243
    .line 244
    goto :goto_1

    .line 245
    :catchall_1
    move-exception v0

    .line 246
    move-object v13, v0

    .line 247
    move-object v0, p1

    .line 248
    move-object p1, v13

    .line 249
    goto :goto_5

    .line 250
    :cond_7
    new-instance v4, LI/A0;

    .line 251
    .line 252
    iget-object v5, p0, LI/B0;->l:LI/D0;

    .line 253
    .line 254
    iget-object v6, p0, LI/B0;->m:LI/g;

    .line 255
    .line 256
    invoke-direct {v4, v5, v6, v2}, LI/A0;-><init>(LI/D0;LI/g;LN1/c;)V

    .line 257
    .line 258
    .line 259
    iput-object v1, p0, LI/B0;->j:Ljava/lang/Object;

    .line 260
    .line 261
    iput-object p1, p0, LI/B0;->h:LU/f;

    .line 262
    .line 263
    iput v3, p0, LI/B0;->i:I

    .line 264
    .line 265
    invoke-static {v4, p0}, Lc2/u;->d(LU1/e;LN1/c;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 269
    if-ne v3, v0, :cond_8

    .line 270
    .line 271
    return-object v0

    .line 272
    :cond_8
    move-object v0, p1

    .line 273
    :goto_2
    invoke-virtual {v0}, LU/f;->a()V

    .line 274
    .line 275
    .line 276
    iget-object p1, p0, LI/B0;->k:LI/E0;

    .line 277
    .line 278
    iget-object v0, p1, LI/E0;->c:Ljava/lang/Object;

    .line 279
    .line 280
    monitor-enter v0

    .line 281
    :try_start_6
    iget-object v3, p1, LI/E0;->d:Lc2/Q;

    .line 282
    .line 283
    if-ne v3, v1, :cond_9

    .line 284
    .line 285
    iput-object v2, p1, LI/E0;->d:Lc2/Q;

    .line 286
    .line 287
    goto :goto_3

    .line 288
    :catchall_2
    move-exception p1

    .line 289
    goto :goto_4

    .line 290
    :cond_9
    :goto_3
    invoke-virtual {p1}, LI/E0;->x()Lc2/f;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 291
    .line 292
    .line 293
    monitor-exit v0

    .line 294
    sget-object p1, LI/E0;->y:Lf2/G;

    .line 295
    .line 296
    iget-object p1, p0, LI/B0;->k:LI/E0;

    .line 297
    .line 298
    iget-object p1, p1, LI/E0;->x:LI/h;

    .line 299
    .line 300
    invoke-static {p1}, LI/h;->b(LI/h;)V

    .line 301
    .line 302
    .line 303
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 304
    .line 305
    return-object p1

    .line 306
    :goto_4
    monitor-exit v0

    .line 307
    throw p1

    .line 308
    :catchall_3
    move-exception v0

    .line 309
    :try_start_7
    monitor-exit v5

    .line 310
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 311
    :goto_5
    invoke-virtual {v0}, LU/f;->a()V

    .line 312
    .line 313
    .line 314
    iget-object v0, p0, LI/B0;->k:LI/E0;

    .line 315
    .line 316
    iget-object v3, v0, LI/E0;->c:Ljava/lang/Object;

    .line 317
    .line 318
    monitor-enter v3

    .line 319
    :try_start_8
    iget-object v4, v0, LI/E0;->d:Lc2/Q;

    .line 320
    .line 321
    if-ne v4, v1, :cond_a

    .line 322
    .line 323
    iput-object v2, v0, LI/E0;->d:Lc2/Q;

    .line 324
    .line 325
    goto :goto_6

    .line 326
    :catchall_4
    move-exception p1

    .line 327
    goto :goto_7

    .line 328
    :cond_a
    :goto_6
    invoke-virtual {v0}, LI/E0;->x()Lc2/f;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 329
    .line 330
    .line 331
    monitor-exit v3

    .line 332
    sget-object v0, LI/E0;->y:Lf2/G;

    .line 333
    .line 334
    iget-object v0, p0, LI/B0;->k:LI/E0;

    .line 335
    .line 336
    iget-object v0, v0, LI/E0;->x:LI/h;

    .line 337
    .line 338
    invoke-static {v0}, LI/h;->b(LI/h;)V

    .line 339
    .line 340
    .line 341
    throw p1

    .line 342
    :goto_7
    monitor-exit v3

    .line 343
    throw p1

    .line 344
    :catchall_5
    move-exception v0

    .line 345
    monitor-exit p1

    .line 346
    throw v0

    .line 347
    :catchall_6
    move-exception p1

    .line 348
    goto :goto_8

    .line 349
    :cond_b
    :try_start_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 350
    .line 351
    const-string v0, "Recomposer already running"

    .line 352
    .line 353
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    throw p1

    .line 357
    :cond_c
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 358
    .line 359
    const-string v0, "Recomposer shut down"

    .line 360
    .line 361
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    throw p1

    .line 365
    :cond_d
    throw v5
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    .line 366
    :goto_8
    monitor-exit v4

    .line 367
    throw p1
.end method
