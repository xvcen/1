.class public final synthetic LI/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 1
    iput p5, p0, LI/D;->d:I

    iput-object p1, p0, LI/D;->f:Ljava/lang/Object;

    iput-object p2, p0, LI/D;->g:Ljava/lang/Object;

    iput-object p3, p0, LI/D;->h:Ljava/lang/Object;

    iput p4, p0, LI/D;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>([Lu0/L;Ls/J;I[I)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, LI/D;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LI/D;->f:Ljava/lang/Object;

    iput-object p2, p0, LI/D;->g:Ljava/lang/Object;

    iput p3, p0, LI/D;->e:I

    iput-object p4, p0, LI/D;->h:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, LI/D;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LI/D;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw/J;

    .line 9
    .line 10
    iget-object v1, p0, LI/D;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lu0/B;

    .line 13
    .line 14
    iget-object v2, p0, LI/D;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Lu0/L;

    .line 17
    .line 18
    move-object v3, p1

    .line 19
    check-cast v3, Lu0/K;

    .line 20
    .line 21
    iget v4, v0, Lw/J;->b:I

    .line 22
    .line 23
    iget-object p1, v0, Lw/J;->a:Lw/n0;

    .line 24
    .line 25
    iget-object v5, v0, Lw/J;->c:LM0/E;

    .line 26
    .line 27
    iget-object v0, v0, Lw/J;->d:LU1/a;

    .line 28
    .line 29
    invoke-interface {v0}, LU1/a;->a()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Lw/p0;

    .line 34
    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    iget-object v0, v0, Lw/p0;->a:LH0/L;

    .line 38
    .line 39
    :goto_0
    move-object v6, v0

    .line 40
    goto :goto_1

    .line 41
    :cond_0
    const/4 v0, 0x0

    .line 42
    goto :goto_0

    .line 43
    :goto_1
    invoke-interface {v1}, Lu0/m;->getLayoutDirection()LT0/o;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sget-object v1, LT0/o;->e:LT0/o;

    .line 48
    .line 49
    const/4 v9, 0x0

    .line 50
    if-ne v0, v1, :cond_1

    .line 51
    .line 52
    const/4 v0, 0x1

    .line 53
    move v7, v0

    .line 54
    goto :goto_2

    .line 55
    :cond_1
    move v7, v9

    .line 56
    :goto_2
    iget v8, v2, Lu0/L;->d:I

    .line 57
    .line 58
    invoke-static/range {v3 .. v8}, Lw/O;->h(Lu0/K;ILM0/E;LH0/L;ZI)Lc0/c;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    sget-object v1, Lp/n0;->e:Lp/n0;

    .line 63
    .line 64
    iget v4, v2, Lu0/L;->d:I

    .line 65
    .line 66
    iget v5, p0, LI/D;->e:I

    .line 67
    .line 68
    invoke-virtual {p1, v1, v0, v5, v4}, Lw/n0;->a(Lp/n0;Lc0/c;II)V

    .line 69
    .line 70
    .line 71
    iget-object p1, p1, Lw/n0;->a:LI/i0;

    .line 72
    .line 73
    invoke-virtual {p1}, LI/i0;->g()F

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    neg-float p1, p1

    .line 78
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    invoke-static {v3, v2, p1, v9}, Lu0/K;->A(Lu0/K;Lu0/L;II)V

    .line 83
    .line 84
    .line 85
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 86
    .line 87
    return-object p1

    .line 88
    :pswitch_0
    iget-object v0, p0, LI/D;->f:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, [Lu0/L;

    .line 91
    .line 92
    iget-object v1, p0, LI/D;->g:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v1, Ls/J;

    .line 95
    .line 96
    iget-object v2, p0, LI/D;->h:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v2, [I

    .line 99
    .line 100
    check-cast p1, Lu0/K;

    .line 101
    .line 102
    array-length v3, v0

    .line 103
    const/4 v4, 0x0

    .line 104
    move v5, v4

    .line 105
    :goto_3
    if-ge v4, v3, :cond_2

    .line 106
    .line 107
    aget-object v6, v0, v4

    .line 108
    .line 109
    add-int/lit8 v7, v5, 0x1

    .line 110
    .line 111
    invoke-static {v6}, LV1/i;->b(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v6}, Lu0/L;->B()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    iget-object v8, v1, Ls/J;->b:LW/g;

    .line 118
    .line 119
    iget v9, v6, Lu0/L;->e:I

    .line 120
    .line 121
    iget v10, p0, LI/D;->e:I

    .line 122
    .line 123
    sub-int/2addr v10, v9

    .line 124
    int-to-float v9, v10

    .line 125
    const/high16 v10, 0x40000000    # 2.0f

    .line 126
    .line 127
    div-float/2addr v9, v10

    .line 128
    const/4 v10, 0x1

    .line 129
    int-to-float v10, v10

    .line 130
    iget v8, v8, LW/g;->a:F

    .line 131
    .line 132
    add-float/2addr v10, v8

    .line 133
    mul-float/2addr v10, v9

    .line 134
    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    .line 135
    .line 136
    .line 137
    move-result v8

    .line 138
    aget v5, v2, v5

    .line 139
    .line 140
    invoke-static {p1, v6, v5, v8}, Lu0/K;->x(Lu0/K;Lu0/L;II)V

    .line 141
    .line 142
    .line 143
    add-int/lit8 v4, v4, 0x1

    .line 144
    .line 145
    move v5, v7

    .line 146
    goto :goto_3

    .line 147
    :cond_2
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 148
    .line 149
    return-object p1

    .line 150
    :pswitch_1
    iget-object v0, p0, LI/D;->f:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v0, LI/F;

    .line 153
    .line 154
    iget-object v1, p0, LI/D;->g:Ljava/lang/Object;

    .line 155
    .line 156
    check-cast v1, LQ/g;

    .line 157
    .line 158
    iget-object v2, p0, LI/D;->h:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v2, Li/C;

    .line 161
    .line 162
    if-eq p1, v0, :cond_5

    .line 163
    .line 164
    instance-of v0, p1, LU/y;

    .line 165
    .line 166
    if-eqz v0, :cond_4

    .line 167
    .line 168
    iget v0, v1, LQ/g;->a:I

    .line 169
    .line 170
    iget v1, p0, LI/D;->e:I

    .line 171
    .line 172
    sub-int/2addr v0, v1

    .line 173
    invoke-virtual {v2, p1}, Li/C;->c(Ljava/lang/Object;)I

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    if-ltz v1, :cond_3

    .line 178
    .line 179
    iget-object v3, v2, Li/C;->c:[I

    .line 180
    .line 181
    aget v1, v3, v1

    .line 182
    .line 183
    goto :goto_4

    .line 184
    :cond_3
    const v1, 0x7fffffff

    .line 185
    .line 186
    .line 187
    :goto_4
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 188
    .line 189
    .line 190
    move-result v0

    .line 191
    invoke-virtual {v2, v0, p1}, Li/C;->f(ILjava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    :cond_4
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 195
    .line 196
    return-object p1

    .line 197
    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 198
    .line 199
    const-string v0, "A derived state calculation cannot read itself"

    .line 200
    .line 201
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    throw p1

    .line 205
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
