.class public interface abstract LI/G0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()V
.end method

.method public abstract d()V
.end method

.method public abstract g()V
.end method
