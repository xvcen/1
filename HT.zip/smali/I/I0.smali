.class public final LI/I0;
.super LN1/a;
.source "SourceFile"

# interfaces
.implements Lc2/q;


# instance fields
.field public final synthetic e:LV/e;

.field public final synthetic f:LI/J0;


# direct methods
.method public constructor <init>(LV/e;LI/J0;)V
    .locals 1

    .line 1
    sget-object v0, Lc2/p;->d:Lc2/p;

    .line 2
    .line 3
    iput-object p1, p0, LI/I0;->e:LV/e;

    .line 4
    .line 5
    iput-object p2, p0, LI/I0;->f:LI/J0;

    .line 6
    .line 7
    invoke-direct {p0, v0}, LN1/a;-><init>(LN1/g;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final u(LN1/h;Ljava/lang/Throwable;)V
    .locals 4

    .line 1
    new-instance v0, LA1/c;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    iget-object v2, p0, LI/I0;->e:LV/e;

    .line 6
    .line 7
    iget-object v3, p0, LI/I0;->f:LI/J0;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2, v3}, LA1/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-static {p2, v0}, LT0/g;->P(Ljava/lang/Throwable;LU1/a;)Z

    .line 13
    .line 14
    .line 15
    sget-object v0, Lc2/p;->d:Lc2/p;

    .line 16
    .line 17
    iget-object v1, v3, LI/J0;->d:LN1/h;

    .line 18
    .line 19
    invoke-interface {v1, v0}, LN1/h;->r(LN1/g;)LN1/f;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lc2/q;

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-interface {v0, p1, p2}, Lc2/q;->u(LN1/h;Ljava/lang/Throwable;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_0
    throw p2
.end method
