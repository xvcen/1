.class public abstract LI/N;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/ArrayList;


# virtual methods
.method public abstract a(LI/a;)Z
.end method

.method public abstract b()LI/N;
.end method

.method public abstract c(LI/a;)Z
.end method
