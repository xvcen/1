.class public final LI/U;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LI/U;->d:I

    iput-object p2, p0, LI/U;->e:Ljava/lang/Object;

    iput-object p3, p0, LI/U;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LI/U;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lo0/b;

    .line 7
    .line 8
    iget-object p1, p1, Lo0/b;->a:Landroid/view/KeyEvent;

    .line 9
    .line 10
    iget-object v0, p0, LI/U;->e:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lb0/l;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/view/InputEvent;->getDevice()Landroid/view/InputDevice;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v2, 0x0

    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    goto/16 :goto_0

    .line 22
    .line 23
    :cond_0
    const/16 v3, 0x201

    .line 24
    .line 25
    invoke-virtual {v1, v3}, Landroid/view/InputDevice;->supportsSource(I)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-nez v3, :cond_1

    .line 30
    .line 31
    goto/16 :goto_0

    .line 32
    .line 33
    :cond_1
    invoke-virtual {v1}, Landroid/view/InputDevice;->isVirtual()Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_2

    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getSource()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    const v3, 0x2000001

    .line 44
    .line 45
    .line 46
    if-eq v1, v3, :cond_2

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_2
    invoke-static {p1}, Lo0/c;->c(Landroid/view/KeyEvent;)I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    const/4 v3, 0x2

    .line 54
    if-ne v1, v3, :cond_9

    .line 55
    .line 56
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getSource()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const/16 v3, 0x101

    .line 61
    .line 62
    if-ne v1, v3, :cond_3

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    const/16 v1, 0x13

    .line 66
    .line 67
    invoke-static {p1, v1}, Lw/O;->i(Landroid/view/KeyEvent;I)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    const/4 v3, 0x1

    .line 72
    if-eqz v1, :cond_4

    .line 73
    .line 74
    const/4 p1, 0x5

    .line 75
    check-cast v0, Lb0/p;

    .line 76
    .line 77
    invoke-virtual {v0, p1, v3}, Lb0/p;->g(IZ)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    goto :goto_0

    .line 82
    :cond_4
    const/16 v1, 0x14

    .line 83
    .line 84
    invoke-static {p1, v1}, Lw/O;->i(Landroid/view/KeyEvent;I)Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    if-eqz v1, :cond_5

    .line 89
    .line 90
    const/4 p1, 0x6

    .line 91
    check-cast v0, Lb0/p;

    .line 92
    .line 93
    invoke-virtual {v0, p1, v3}, Lb0/p;->g(IZ)Z

    .line 94
    .line 95
    .line 96
    move-result v2

    .line 97
    goto :goto_0

    .line 98
    :cond_5
    const/16 v1, 0x15

    .line 99
    .line 100
    invoke-static {p1, v1}, Lw/O;->i(Landroid/view/KeyEvent;I)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-eqz v1, :cond_6

    .line 105
    .line 106
    const/4 p1, 0x3

    .line 107
    check-cast v0, Lb0/p;

    .line 108
    .line 109
    invoke-virtual {v0, p1, v3}, Lb0/p;->g(IZ)Z

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    goto :goto_0

    .line 114
    :cond_6
    const/16 v1, 0x16

    .line 115
    .line 116
    invoke-static {p1, v1}, Lw/O;->i(Landroid/view/KeyEvent;I)Z

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    if-eqz v1, :cond_7

    .line 121
    .line 122
    const/4 p1, 0x4

    .line 123
    check-cast v0, Lb0/p;

    .line 124
    .line 125
    invoke-virtual {v0, p1, v3}, Lb0/p;->g(IZ)Z

    .line 126
    .line 127
    .line 128
    move-result v2

    .line 129
    goto :goto_0

    .line 130
    :cond_7
    const/16 v0, 0x17

    .line 131
    .line 132
    invoke-static {p1, v0}, Lw/O;->i(Landroid/view/KeyEvent;I)Z

    .line 133
    .line 134
    .line 135
    move-result p1

    .line 136
    if-eqz p1, :cond_9

    .line 137
    .line 138
    iget-object p1, p0, LI/U;->f:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast p1, Lw/S;

    .line 141
    .line 142
    iget-object p1, p1, Lw/S;->c:Lx0/F0;

    .line 143
    .line 144
    if-eqz p1, :cond_8

    .line 145
    .line 146
    check-cast p1, Lx0/j0;

    .line 147
    .line 148
    invoke-virtual {p1}, Lx0/j0;->b()V

    .line 149
    .line 150
    .line 151
    :cond_8
    move v2, v3

    .line 152
    :cond_9
    :goto_0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    return-object p1

    .line 157
    :pswitch_0
    check-cast p1, Lo0/b;

    .line 158
    .line 159
    iget-object p1, p1, Lo0/b;->a:Landroid/view/KeyEvent;

    .line 160
    .line 161
    iget-object v0, p0, LI/U;->e:Ljava/lang/Object;

    .line 162
    .line 163
    check-cast v0, Lw/S;

    .line 164
    .line 165
    invoke-virtual {v0}, Lw/S;->a()Lw/H;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    sget-object v1, Lw/H;->e:Lw/H;

    .line 170
    .line 171
    if-ne v0, v1, :cond_a

    .line 172
    .line 173
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    const/4 v1, 0x4

    .line 178
    if-ne v0, v1, :cond_a

    .line 179
    .line 180
    invoke-static {p1}, Lo0/c;->c(Landroid/view/KeyEvent;)I

    .line 181
    .line 182
    .line 183
    move-result p1

    .line 184
    const/4 v0, 0x1

    .line 185
    if-ne p1, v0, :cond_a

    .line 186
    .line 187
    iget-object p1, p0, LI/U;->f:Ljava/lang/Object;

    .line 188
    .line 189
    check-cast p1, LH/m0;

    .line 190
    .line 191
    const/4 v1, 0x0

    .line 192
    invoke-virtual {p1, v1}, LH/m0;->g(Lc0/b;)V

    .line 193
    .line 194
    .line 195
    goto :goto_1

    .line 196
    :cond_a
    const/4 v0, 0x0

    .line 197
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    return-object p1

    .line 202
    :pswitch_1
    move-object v3, p1

    .line 203
    check-cast v3, LU/m;

    .line 204
    .line 205
    sget-object p1, LU/p;->c:Ljava/lang/Object;

    .line 206
    .line 207
    monitor-enter p1

    .line 208
    :try_start_0
    sget-wide v1, LU/p;->e:J

    .line 209
    .line 210
    const/4 v0, 0x1

    .line 211
    int-to-long v4, v0

    .line 212
    add-long/2addr v4, v1

    .line 213
    sput-wide v4, LU/p;->e:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 214
    .line 215
    monitor-exit p1

    .line 216
    iget-object p1, p0, LI/U;->e:Ljava/lang/Object;

    .line 217
    .line 218
    move-object v4, p1

    .line 219
    check-cast v4, LU1/c;

    .line 220
    .line 221
    iget-object p1, p0, LI/U;->f:Ljava/lang/Object;

    .line 222
    .line 223
    move-object v5, p1

    .line 224
    check-cast v5, LU1/c;

    .line 225
    .line 226
    new-instance v0, LU/b;

    .line 227
    .line 228
    invoke-direct/range {v0 .. v5}, LU/b;-><init>(JLU/m;LU1/c;LU1/c;)V

    .line 229
    .line 230
    .line 231
    return-object v0

    .line 232
    :catchall_0
    move-exception v0

    .line 233
    monitor-exit p1

    .line 234
    throw v0

    .line 235
    :pswitch_2
    check-cast p1, Ljava/lang/Throwable;

    .line 236
    .line 237
    iget-object p1, p0, LI/U;->e:Ljava/lang/Object;

    .line 238
    .line 239
    check-cast p1, LI/V;

    .line 240
    .line 241
    iget-object v1, p1, LI/V;->a:Ljava/lang/Object;

    .line 242
    .line 243
    iget-object v0, p0, LI/U;->f:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast v0, Lc2/g;

    .line 246
    .line 247
    monitor-enter v1

    .line 248
    :try_start_1
    iget-object p1, p1, LI/V;->b:Ljava/util/ArrayList;

    .line 249
    .line 250
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 251
    .line 252
    .line 253
    monitor-exit v1

    .line 254
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 255
    .line 256
    return-object p1

    .line 257
    :catchall_1
    move-exception v0

    .line 258
    move-object p1, v0

    .line 259
    monitor-exit v1

    .line 260
    throw p1

    .line 261
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
