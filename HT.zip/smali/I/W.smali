.class public final LI/W;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI/G0;
.implements Lc2/q;


# instance fields
.field public final d:LN1/h;

.field public final e:LU1/e;

.field public final f:Lh2/c;

.field public g:Lc2/e0;


# direct methods
.method public constructor <init>(LN1/h;LU1/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LI/W;->d:LN1/h;

    .line 5
    .line 6
    iput-object p2, p0, LI/W;->e:LU1/e;

    .line 7
    .line 8
    invoke-interface {p1, p0}, LN1/h;->i(LN1/h;)LN1/h;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-static {p1}, Lc2/u;->a(LN1/h;)Lh2/c;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, LI/W;->f:Lh2/c;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final c()V
    .locals 4

    .line 1
    iget-object v0, p0, LI/W;->g:Lc2/e0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    new-instance v2, Ljava/util/concurrent/CancellationException;

    .line 7
    .line 8
    const-string v3, "Old job was still running!"

    .line 9
    .line 10
    invoke-direct {v2, v3}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, v2}, Lc2/X;->a(Ljava/util/concurrent/CancellationException;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v0, p0, LI/W;->e:LU1/e;

    .line 20
    .line 21
    const/4 v2, 0x3

    .line 22
    iget-object v3, p0, LI/W;->f:Lh2/c;

    .line 23
    .line 24
    invoke-static {v3, v1, v0, v2}, Lc2/u;->p(Lc2/s;LN1/h;LU1/e;I)Lc2/e0;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, LI/W;->g:Lc2/e0;

    .line 29
    .line 30
    return-void
.end method

.method public final d()V
    .locals 3

    .line 1
    iget-object v0, p0, LI/W;->g:Lc2/e0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LI/K;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    invoke-direct {v1, v2}, LI/K;-><init>(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v1}, Lc2/X;->B(Ljava/util/concurrent/CancellationException;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    iput-object v0, p0, LI/W;->g:Lc2/e0;

    .line 16
    .line 17
    return-void
.end method

.method public final g()V
    .locals 3

    .line 1
    iget-object v0, p0, LI/W;->g:Lc2/e0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, LI/K;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    invoke-direct {v1, v2}, LI/K;-><init>(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v1}, Lc2/X;->B(Ljava/util/concurrent/CancellationException;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    iput-object v0, p0, LI/W;->g:Lc2/e0;

    .line 16
    .line 17
    return-void
.end method

.method public final getKey()LN1/g;
    .locals 1

    .line 1
    sget-object v0, Lc2/p;->d:Lc2/p;

    .line 2
    .line 3
    return-object v0
.end method

.method public final i(LN1/h;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->H(LN1/f;LN1/h;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final k(LN1/g;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->E(LN1/f;LN1/g;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final n(LU1/e;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final r(LN1/g;)LN1/f;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->u(LN1/f;LN1/g;)LN1/f;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final u(LN1/h;Ljava/lang/Throwable;)V
    .locals 3

    .line 1
    sget-object v0, LV/e;->e:LA1/i;

    .line 2
    .line 3
    invoke-interface {p1, v0}, LN1/h;->r(LN1/g;)LN1/f;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LV/e;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    new-instance v1, LA1/c;

    .line 12
    .line 13
    const/16 v2, 0xa

    .line 14
    .line 15
    invoke-direct {v1, v2, v0, p0}, LA1/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-static {p2, v1}, LT0/g;->P(Ljava/lang/Throwable;LU1/a;)Z

    .line 19
    .line 20
    .line 21
    :cond_0
    iget-object v0, p0, LI/W;->d:LN1/h;

    .line 22
    .line 23
    sget-object v1, Lc2/p;->d:Lc2/p;

    .line 24
    .line 25
    invoke-interface {v0, v1}, LN1/h;->r(LN1/g;)LN1/f;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lc2/q;

    .line 30
    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    invoke-interface {v0, p1, p2}, Lc2/q;->u(LN1/h;Ljava/lang/Throwable;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    throw p2
.end method
