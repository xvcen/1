.class public final LI/X;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI/d1;


# instance fields
.field public final a:LJ1/k;


# direct methods
.method public constructor <init>(LU1/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, La/a;->C(LU1/a;)LJ1/k;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, LI/X;->a:LJ1/k;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(LI/q0;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p1, p0, LI/X;->a:LJ1/k;

    .line 2
    .line 3
    invoke-virtual {p1}, LJ1/k;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
