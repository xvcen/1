.class public final LI/X0;
.super LP1/i;
.source "SourceFile"

# interfaces
.implements LU1/e;


# instance fields
.field public h:Li/F;

.field public i:LU1/c;

.field public j:Le2/g;

.field public k:LU/f;

.field public l:Ljava/lang/Object;

.field public m:I

.field public synthetic n:Ljava/lang/Object;

.field public final synthetic o:LU1/a;


# direct methods
.method public constructor <init>(LU1/a;LN1/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LI/X0;->o:LU1/a;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LP1/i;-><init>(ILN1/c;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lf2/e;

    .line 2
    .line 3
    check-cast p2, LN1/c;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LI/X0;->m(LN1/c;Ljava/lang/Object;)LN1/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LI/X0;

    .line 10
    .line 11
    sget-object p2, LJ1/m;->a:LJ1/m;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LI/X0;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    sget-object p1, LO1/a;->d:LO1/a;

    .line 17
    .line 18
    return-object p1
.end method

.method public final m(LN1/c;Ljava/lang/Object;)LN1/c;
    .locals 2

    .line 1
    new-instance v0, LI/X0;

    .line 2
    .line 3
    iget-object v1, p0, LI/X0;->o:LU1/a;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LI/X0;-><init>(LU1/a;LN1/c;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, LI/X0;->n:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    sget-object v0, LO1/a;->d:LO1/a;

    .line 4
    .line 5
    iget v2, v1, LI/X0;->m:I

    .line 6
    .line 7
    const/4 v3, 0x3

    .line 8
    const/4 v4, 0x2

    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v6, 0x1

    .line 11
    if-eqz v2, :cond_3

    .line 12
    .line 13
    if-eq v2, v6, :cond_2

    .line 14
    .line 15
    if-eq v2, v4, :cond_1

    .line 16
    .line 17
    if-ne v2, v3, :cond_0

    .line 18
    .line 19
    iget-object v2, v1, LI/X0;->l:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v7, v1, LI/X0;->k:LU/f;

    .line 22
    .line 23
    iget-object v8, v1, LI/X0;->j:Le2/g;

    .line 24
    .line 25
    iget-object v9, v1, LI/X0;->i:LU1/c;

    .line 26
    .line 27
    iget-object v10, v1, LI/X0;->h:Li/F;

    .line 28
    .line 29
    iget-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v11, Lf2/e;

    .line 32
    .line 33
    :try_start_0
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    .line 35
    .line 36
    move/from16 v16, v4

    .line 37
    .line 38
    goto/16 :goto_a

    .line 39
    .line 40
    :catchall_0
    move-exception v0

    .line 41
    goto/16 :goto_d

    .line 42
    .line 43
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 44
    .line 45
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v0

    .line 51
    :cond_1
    iget-object v2, v1, LI/X0;->l:Ljava/lang/Object;

    .line 52
    .line 53
    iget-object v7, v1, LI/X0;->k:LU/f;

    .line 54
    .line 55
    iget-object v8, v1, LI/X0;->j:Le2/g;

    .line 56
    .line 57
    iget-object v9, v1, LI/X0;->i:LU1/c;

    .line 58
    .line 59
    iget-object v10, v1, LI/X0;->h:Li/F;

    .line 60
    .line 61
    iget-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v11, Lf2/e;

    .line 64
    .line 65
    :try_start_1
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    .line 67
    .line 68
    move-object/from16 v12, p1

    .line 69
    .line 70
    goto/16 :goto_1

    .line 71
    .line 72
    :cond_2
    iget-object v2, v1, LI/X0;->l:Ljava/lang/Object;

    .line 73
    .line 74
    iget-object v7, v1, LI/X0;->k:LU/f;

    .line 75
    .line 76
    iget-object v8, v1, LI/X0;->j:Le2/g;

    .line 77
    .line 78
    iget-object v9, v1, LI/X0;->i:LU1/c;

    .line 79
    .line 80
    iget-object v10, v1, LI/X0;->h:Li/F;

    .line 81
    .line 82
    iget-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v11, Lf2/e;

    .line 85
    .line 86
    :try_start_2
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 87
    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_3
    invoke-static/range {p1 .. p1}, LX1/a;->k0(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    iget-object v2, v1, LI/X0;->n:Ljava/lang/Object;

    .line 94
    .line 95
    move-object v11, v2

    .line 96
    check-cast v11, Lf2/e;

    .line 97
    .line 98
    new-instance v10, Li/F;

    .line 99
    .line 100
    invoke-direct {v10}, Li/F;-><init>()V

    .line 101
    .line 102
    .line 103
    new-instance v9, LB/y;

    .line 104
    .line 105
    const/16 v2, 0xb

    .line 106
    .line 107
    invoke-direct {v9, v2, v10}, LB/y;-><init>(ILjava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    const v2, 0x7fffffff

    .line 111
    .line 112
    .line 113
    const/4 v7, 0x6

    .line 114
    invoke-static {v2, v7, v5}, Le2/j;->a(IILe2/a;)Le2/c;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    new-instance v2, LA1/e;

    .line 119
    .line 120
    const/16 v7, 0xb

    .line 121
    .line 122
    invoke-direct {v2, v7, v8}, LA1/e;-><init>(ILjava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    sget-object v7, LU/p;->a:LH0/z;

    .line 126
    .line 127
    invoke-static {v7}, LU/p;->e(LU1/c;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    sget-object v7, LU/p;->c:Ljava/lang/Object;

    .line 131
    .line 132
    monitor-enter v7

    .line 133
    :try_start_3
    sget-object v12, LU/p;->h:Ljava/lang/Object;

    .line 134
    .line 135
    invoke-static {v12, v2}, LK1/m;->z0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 136
    .line 137
    .line 138
    move-result-object v12

    .line 139
    sput-object v12, LU/p;->h:Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_8

    .line 140
    .line 141
    monitor-exit v7

    .line 142
    new-instance v7, LU/f;

    .line 143
    .line 144
    invoke-direct {v7, v2}, LU/f;-><init>(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :try_start_4
    invoke-static {}, LU/p;->j()LU/g;

    .line 148
    .line 149
    .line 150
    move-result-object v2

    .line 151
    invoke-virtual {v2, v9}, LU/g;->u(LU1/c;)LU/g;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    iget-object v12, v1, LI/X0;->o:LU1/a;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 156
    .line 157
    :try_start_5
    invoke-virtual {v2}, LU/g;->j()LU/g;

    .line 158
    .line 159
    .line 160
    move-result-object v13
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_6

    .line 161
    :try_start_6
    invoke-interface {v12}, LU1/a;->a()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v12
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_7

    .line 165
    :try_start_7
    invoke-static {v13}, LU/g;->q(LU/g;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    .line 166
    .line 167
    .line 168
    :try_start_8
    invoke-virtual {v2}, LU/g;->c()V

    .line 169
    .line 170
    .line 171
    iput-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 172
    .line 173
    iput-object v10, v1, LI/X0;->h:Li/F;

    .line 174
    .line 175
    iput-object v9, v1, LI/X0;->i:LU1/c;

    .line 176
    .line 177
    iput-object v8, v1, LI/X0;->j:Le2/g;

    .line 178
    .line 179
    iput-object v7, v1, LI/X0;->k:LU/f;

    .line 180
    .line 181
    iput-object v12, v1, LI/X0;->l:Ljava/lang/Object;

    .line 182
    .line 183
    iput v6, v1, LI/X0;->m:I

    .line 184
    .line 185
    invoke-interface {v11, v12, v1}, Lf2/e;->e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    if-ne v2, v0, :cond_4

    .line 190
    .line 191
    goto/16 :goto_9

    .line 192
    .line 193
    :cond_4
    move-object v2, v12

    .line 194
    :goto_0
    iput-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 195
    .line 196
    iput-object v10, v1, LI/X0;->h:Li/F;

    .line 197
    .line 198
    iput-object v9, v1, LI/X0;->i:LU1/c;

    .line 199
    .line 200
    iput-object v8, v1, LI/X0;->j:Le2/g;

    .line 201
    .line 202
    iput-object v7, v1, LI/X0;->k:LU/f;

    .line 203
    .line 204
    iput-object v2, v1, LI/X0;->l:Ljava/lang/Object;

    .line 205
    .line 206
    iput v4, v1, LI/X0;->m:I

    .line 207
    .line 208
    invoke-interface {v8, v1}, Le2/q;->p(LN1/c;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v12

    .line 212
    if-ne v12, v0, :cond_5

    .line 213
    .line 214
    goto/16 :goto_9

    .line 215
    .line 216
    :cond_5
    :goto_1
    check-cast v12, Ljava/util/Set;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 217
    .line 218
    const/4 v14, 0x0

    .line 219
    :goto_2
    if-nez v14, :cond_c

    .line 220
    .line 221
    :try_start_9
    iget-object v14, v10, Li/F;->b:[Ljava/lang/Object;

    .line 222
    .line 223
    iget-object v15, v10, Li/F;->a:[J

    .line 224
    .line 225
    move/from16 v16, v4

    .line 226
    .line 227
    array-length v4, v15

    .line 228
    add-int/lit8 v4, v4, -0x2

    .line 229
    .line 230
    if-ltz v4, :cond_a

    .line 231
    .line 232
    move-object/from16 v17, v14

    .line 233
    .line 234
    const/4 v5, 0x0

    .line 235
    :goto_3
    aget-wide v13, v15, v5
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 236
    .line 237
    move-object/from16 v18, v7

    .line 238
    .line 239
    not-long v6, v13

    .line 240
    const/16 v19, 0x7

    .line 241
    .line 242
    shl-long v6, v6, v19

    .line 243
    .line 244
    and-long/2addr v6, v13

    .line 245
    const-wide v19, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    and-long v6, v6, v19

    .line 251
    .line 252
    cmp-long v6, v6, v19

    .line 253
    .line 254
    if-eqz v6, :cond_9

    .line 255
    .line 256
    sub-int v6, v5, v4

    .line 257
    .line 258
    not-int v6, v6

    .line 259
    ushr-int/lit8 v6, v6, 0x1f

    .line 260
    .line 261
    const/16 v7, 0x8

    .line 262
    .line 263
    rsub-int/lit8 v6, v6, 0x8

    .line 264
    .line 265
    const/4 v3, 0x0

    .line 266
    :goto_4
    if-ge v3, v6, :cond_8

    .line 267
    .line 268
    const-wide/16 v20, 0xff

    .line 269
    .line 270
    and-long v20, v13, v20

    .line 271
    .line 272
    const-wide/16 v22, 0x80

    .line 273
    .line 274
    cmp-long v20, v20, v22

    .line 275
    .line 276
    if-gez v20, :cond_6

    .line 277
    .line 278
    shl-int/lit8 v20, v5, 0x3

    .line 279
    .line 280
    add-int v20, v20, v3

    .line 281
    .line 282
    move/from16 v21, v7

    .line 283
    .line 284
    :try_start_a
    aget-object v7, v17, v20

    .line 285
    .line 286
    invoke-interface {v12, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v7

    .line 290
    if-eqz v7, :cond_7

    .line 291
    .line 292
    goto :goto_6

    .line 293
    :cond_6
    move/from16 v21, v7

    .line 294
    .line 295
    :cond_7
    shr-long v13, v13, v21

    .line 296
    .line 297
    add-int/lit8 v3, v3, 0x1

    .line 298
    .line 299
    move/from16 v7, v21

    .line 300
    .line 301
    goto :goto_4

    .line 302
    :cond_8
    move v3, v7

    .line 303
    if-ne v6, v3, :cond_b

    .line 304
    .line 305
    :cond_9
    if-eq v5, v4, :cond_b

    .line 306
    .line 307
    add-int/lit8 v5, v5, 0x1

    .line 308
    .line 309
    move-object/from16 v7, v18

    .line 310
    .line 311
    const/4 v3, 0x3

    .line 312
    const/4 v6, 0x1

    .line 313
    goto :goto_3

    .line 314
    :cond_a
    move-object/from16 v18, v7

    .line 315
    .line 316
    :cond_b
    const/4 v14, 0x0

    .line 317
    goto :goto_7

    .line 318
    :catchall_1
    move-exception v0

    .line 319
    move-object/from16 v18, v7

    .line 320
    .line 321
    :goto_5
    move-object/from16 v7, v18

    .line 322
    .line 323
    goto/16 :goto_d

    .line 324
    .line 325
    :cond_c
    move/from16 v16, v4

    .line 326
    .line 327
    move-object/from16 v18, v7

    .line 328
    .line 329
    :goto_6
    const/4 v14, 0x1

    .line 330
    :goto_7
    invoke-interface {v8}, Le2/q;->o()Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v3

    .line 334
    instance-of v4, v3, Le2/i;

    .line 335
    .line 336
    if-nez v4, :cond_d

    .line 337
    .line 338
    goto :goto_8

    .line 339
    :cond_d
    const/4 v3, 0x0

    .line 340
    :goto_8
    move-object v12, v3

    .line 341
    check-cast v12, Ljava/util/Set;

    .line 342
    .line 343
    if-nez v12, :cond_10

    .line 344
    .line 345
    if-eqz v14, :cond_f

    .line 346
    .line 347
    invoke-virtual {v10}, Li/F;->b()V

    .line 348
    .line 349
    .line 350
    invoke-static {}, LU/p;->j()LU/g;

    .line 351
    .line 352
    .line 353
    move-result-object v3

    .line 354
    invoke-virtual {v3, v9}, LU/g;->u(LU1/c;)LU/g;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    iget-object v4, v1, LI/X0;->o:LU1/a;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 359
    .line 360
    :try_start_b
    invoke-virtual {v3}, LU/g;->j()LU/g;

    .line 361
    .line 362
    .line 363
    move-result-object v5
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    .line 364
    :try_start_c
    invoke-interface {v4}, LU1/a;->a()Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v4
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 368
    :try_start_d
    invoke-static {v5}, LU/g;->q(LU/g;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    .line 369
    .line 370
    .line 371
    :try_start_e
    invoke-virtual {v3}, LU/g;->c()V

    .line 372
    .line 373
    .line 374
    invoke-static {v4, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    move-result v3

    .line 378
    if-nez v3, :cond_f

    .line 379
    .line 380
    iput-object v11, v1, LI/X0;->n:Ljava/lang/Object;

    .line 381
    .line 382
    iput-object v10, v1, LI/X0;->h:Li/F;

    .line 383
    .line 384
    iput-object v9, v1, LI/X0;->i:LU1/c;

    .line 385
    .line 386
    iput-object v8, v1, LI/X0;->j:Le2/g;
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    .line 387
    .line 388
    move-object/from16 v7, v18

    .line 389
    .line 390
    :try_start_f
    iput-object v7, v1, LI/X0;->k:LU/f;

    .line 391
    .line 392
    iput-object v4, v1, LI/X0;->l:Ljava/lang/Object;

    .line 393
    .line 394
    const/4 v3, 0x3

    .line 395
    iput v3, v1, LI/X0;->m:I

    .line 396
    .line 397
    invoke-interface {v11, v4, v1}, Lf2/e;->e(Ljava/lang/Object;LN1/c;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v2
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_0

    .line 401
    if-ne v2, v0, :cond_e

    .line 402
    .line 403
    :goto_9
    return-object v0

    .line 404
    :cond_e
    move-object v2, v4

    .line 405
    :goto_a
    move/from16 v4, v16

    .line 406
    .line 407
    const/4 v5, 0x0

    .line 408
    const/4 v6, 0x1

    .line 409
    goto/16 :goto_0

    .line 410
    .line 411
    :catchall_2
    move-exception v0

    .line 412
    goto :goto_5

    .line 413
    :cond_f
    move-object/from16 v7, v18

    .line 414
    .line 415
    const/4 v3, 0x3

    .line 416
    goto :goto_a

    .line 417
    :catchall_3
    move-exception v0

    .line 418
    move-object/from16 v7, v18

    .line 419
    .line 420
    goto :goto_b

    .line 421
    :catchall_4
    move-exception v0

    .line 422
    move-object/from16 v7, v18

    .line 423
    .line 424
    :try_start_10
    invoke-static {v5}, LU/g;->q(LU/g;)V

    .line 425
    .line 426
    .line 427
    throw v0
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    .line 428
    :catchall_5
    move-exception v0

    .line 429
    :goto_b
    :try_start_11
    invoke-virtual {v3}, LU/g;->c()V

    .line 430
    .line 431
    .line 432
    throw v0
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_0

    .line 433
    :cond_10
    move/from16 v4, v16

    .line 434
    .line 435
    move-object/from16 v7, v18

    .line 436
    .line 437
    const/4 v3, 0x3

    .line 438
    const/4 v5, 0x0

    .line 439
    const/4 v6, 0x1

    .line 440
    goto/16 :goto_2

    .line 441
    .line 442
    :catchall_6
    move-exception v0

    .line 443
    goto :goto_c

    .line 444
    :catchall_7
    move-exception v0

    .line 445
    :try_start_12
    invoke-static {v13}, LU/g;->q(LU/g;)V

    .line 446
    .line 447
    .line 448
    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_6

    .line 449
    :goto_c
    :try_start_13
    invoke-virtual {v2}, LU/g;->c()V

    .line 450
    .line 451
    .line 452
    throw v0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_0

    .line 453
    :goto_d
    invoke-virtual {v7}, LU/f;->a()V

    .line 454
    .line 455
    .line 456
    throw v0

    .line 457
    :catchall_8
    move-exception v0

    .line 458
    monitor-exit v7

    .line 459
    throw v0
.end method
