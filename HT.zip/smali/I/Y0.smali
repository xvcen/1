.class public final LI/Y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;
.implements LW1/a;


# instance fields
.field public final d:LI/M0;

.field public final e:I

.field public final f:LI/k;

.field public final g:I

.field public h:I


# direct methods
.method public constructor <init>(LI/M0;ILI/N;LI/k;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LI/Y0;->d:LI/M0;

    .line 5
    .line 6
    iput p2, p0, LI/Y0;->e:I

    .line 7
    .line 8
    iput-object p4, p0, LI/Y0;->f:LI/k;

    .line 9
    .line 10
    iget p1, p1, LI/M0;->k:I

    .line 11
    .line 12
    iput p1, p0, LI/Y0;->g:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    throw v0
.end method

.method public final next()Ljava/lang/Object;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    throw v0
.end method

.method public final remove()V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    const-string v1, "Operation is not supported for read-only collection"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method
