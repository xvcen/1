.class public abstract LI/Z;
.super Ljava/lang/Object;
.source "SourceFile"
