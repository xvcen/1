.class public abstract LI/a0;
.super Ljava/lang/Object;
.source "SourceFile"
