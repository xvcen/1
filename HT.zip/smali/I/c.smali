.class public interface abstract LI/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d(ILjava/lang/Object;)V
.end method

.method public abstract g(Ljava/lang/Object;)V
.end method

.method public abstract h()V
.end method

.method public abstract i(ILjava/lang/Object;)V
.end method

.method public abstract j(III)V
.end method

.method public abstract k()Ljava/lang/Object;
.end method

.method public abstract l(II)V
.end method

.method public abstract o()V
.end method

.method public p(LU1/e;Ljava/lang/Object;)V
    .locals 1

    .line 1
    invoke-interface {p0}, LI/c;->k()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {p1, v0, p2}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method
