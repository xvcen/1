.class public abstract LI/c0;
.super Ljava/lang/Object;
.source "SourceFile"
