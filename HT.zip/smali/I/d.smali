.class public final synthetic LI/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LU1/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(JI)V
    .locals 0

    .line 1
    iput p3, p0, LI/d;->d:I

    iput-wide p1, p0, LI/d;->e:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LI/d;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LE0/v;

    .line 7
    .line 8
    sget-object v0, LH/N;->c:LE0/u;

    .line 9
    .line 10
    new-instance v1, LH/M;

    .line 11
    .line 12
    sget-object v5, LH/L;->e:LH/L;

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    sget-object v2, Lw/G;->d:Lw/G;

    .line 16
    .line 17
    iget-wide v3, p0, LI/d;->e:J

    .line 18
    .line 19
    invoke-direct/range {v1 .. v6}, LH/M;-><init>(Lw/G;JLH/L;Z)V

    .line 20
    .line 21
    .line 22
    invoke-interface {p1, v0, v1}, LE0/v;->a(LE0/u;Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 26
    .line 27
    return-object p1

    .line 28
    :pswitch_0
    check-cast p1, La0/c;

    .line 29
    .line 30
    iget-object v0, p1, La0/c;->d:La0/a;

    .line 31
    .line 32
    invoke-interface {v0}, La0/a;->a()J

    .line 33
    .line 34
    .line 35
    move-result-wide v0

    .line 36
    const/16 v2, 0x20

    .line 37
    .line 38
    shr-long/2addr v0, v2

    .line 39
    long-to-int v0, v0

    .line 40
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    const/high16 v1, 0x40000000    # 2.0f

    .line 45
    .line 46
    div-float/2addr v0, v1

    .line 47
    invoke-static {p1, v0}, La/a;->q(La0/c;F)Ld0/g;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    new-instance v2, Ld0/o;

    .line 52
    .line 53
    iget-wide v3, p0, LI/d;->e:J

    .line 54
    .line 55
    const/4 v5, 0x5

    .line 56
    invoke-direct {v2, v3, v4, v5}, Ld0/o;-><init>(JI)V

    .line 57
    .line 58
    .line 59
    new-instance v3, Lp/r1;

    .line 60
    .line 61
    invoke-direct {v3, v0, v1, v2}, Lp/r1;-><init>(FLd0/g;Ld0/o;)V

    .line 62
    .line 63
    .line 64
    new-instance v0, LA0/h;

    .line 65
    .line 66
    const/16 v1, 0xb

    .line 67
    .line 68
    const/4 v2, 0x0

    .line 69
    invoke-direct {v0, v1, v2}, LA0/h;-><init>(IZ)V

    .line 70
    .line 71
    .line 72
    iput-object v3, v0, LA0/h;->e:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v0, p1, La0/c;->e:LA0/h;

    .line 75
    .line 76
    return-object v0

    .line 77
    :pswitch_1
    iget-wide v0, p0, LI/d;->e:J

    .line 78
    .line 79
    check-cast p1, LI/e;

    .line 80
    .line 81
    iget-object v2, p1, LI/e;->b:LU1/c;

    .line 82
    .line 83
    if-nez v2, :cond_0

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_0
    iget-object p1, p1, LI/e;->a:Lc2/g;

    .line 87
    .line 88
    if-eqz p1, :cond_1

    .line 89
    .line 90
    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-interface {v2, v0}, LU1/c;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 98
    goto :goto_0

    .line 99
    :catchall_0
    move-exception v0

    .line 100
    invoke-static {v0}, LX1/a;->J(Ljava/lang/Throwable;)LJ1/i;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    :goto_0
    invoke-virtual {p1, v0}, Lc2/g;->v(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    :cond_1
    :goto_1
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 108
    .line 109
    return-object p1

    .line 110
    nop

    .line 111
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
