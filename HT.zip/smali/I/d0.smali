.class public final LI/d0;
.super LQ/b;
.source "SourceFile"


# instance fields
.field public a:LF0/b;


# virtual methods
.method public final a()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, LI/d0;->a:LF0/b;

    .line 3
    .line 4
    return-void
.end method

.method public final b(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    throw p1
.end method
