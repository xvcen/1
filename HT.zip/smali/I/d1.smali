.class public interface abstract LI/d1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LI/q0;)Ljava/lang/Object;
.end method
