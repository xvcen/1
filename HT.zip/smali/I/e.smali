.class public final LI/e;
.super LQ/b;
.source "SourceFile"


# instance fields
.field public a:Lc2/g;

.field public b:LU1/c;


# virtual methods
.method public final a()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, LI/e;->b:LU1/c;

    .line 3
    .line 4
    iput-object v0, p0, LI/e;->a:Lc2/g;

    .line 5
    .line 6
    return-void
.end method

.method public final b(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LI/e;->a:Lc2/g;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, LX1/a;->J(Ljava/lang/Throwable;)LJ1/i;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {v0, p1}, Lc2/g;->v(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method
