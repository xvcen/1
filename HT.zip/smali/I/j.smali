.class public final LI/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN1/f;


# static fields
.field public static final d:LI/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LI/h;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1}, LI/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LI/j;->d:LI/h;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getKey()LN1/g;
    .locals 1

    .line 1
    sget-object v0, LI/j;->d:LI/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public final bridge i(LN1/h;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->H(LN1/f;LN1/h;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final bridge k(LN1/g;)LN1/h;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->E(LN1/f;LN1/g;)LN1/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final n(LU1/e;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final bridge r(LN1/g;)LN1/f;
    .locals 0

    .line 1
    invoke-static {p0, p1}, La/a;->u(LN1/f;LN1/g;)LN1/f;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method
