.class public abstract LI/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LQ/f;

.field public static final b:LQ/f;

.field public static final c:LI/s;

.field public static final d:Ljava/lang/Object;

.field public static final e:LI/I;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LH0/A;

    .line 2
    .line 3
    const/16 v1, 0x9

    .line 4
    .line 5
    invoke-direct {v0, v1}, LH0/A;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, LQ/f;

    .line 9
    .line 10
    const v2, 0x38ea4dba

    .line 11
    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    invoke-direct {v1, v2, v3, v0}, LQ/f;-><init>(IZLJ1/c;)V

    .line 15
    .line 16
    .line 17
    sput-object v1, LI/k;->a:LQ/f;

    .line 18
    .line 19
    new-instance v0, LH0/A;

    .line 20
    .line 21
    const/16 v1, 0xa

    .line 22
    .line 23
    invoke-direct {v0, v1}, LH0/A;-><init>(I)V

    .line 24
    .line 25
    .line 26
    new-instance v1, LQ/f;

    .line 27
    .line 28
    const v2, 0x72535ae8

    .line 29
    .line 30
    .line 31
    invoke-direct {v1, v2, v3, v0}, LQ/f;-><init>(IZLJ1/c;)V

    .line 32
    .line 33
    .line 34
    sput-object v1, LI/k;->b:LQ/f;

    .line 35
    .line 36
    new-instance v0, LI/s;

    .line 37
    .line 38
    const/4 v1, 0x0

    .line 39
    invoke-direct {v0, v1}, LI/s;-><init>(I)V

    .line 40
    .line 41
    .line 42
    sput-object v0, LI/k;->c:LI/s;

    .line 43
    .line 44
    new-instance v0, Ljava/lang/Object;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 47
    .line 48
    .line 49
    sput-object v0, LI/k;->d:Ljava/lang/Object;

    .line 50
    .line 51
    new-instance v0, LI/I;

    .line 52
    .line 53
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 54
    .line 55
    .line 56
    sput-object v0, LI/k;->e:LI/I;

    .line 57
    .line 58
    return-void
.end method

.method public static final a(LI/u0;LQ/f;LI/r;I)V
    .locals 11

    .line 1
    const v0, -0x8ed3d8b

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, LI/r;->V(I)LI/r;

    .line 5
    .line 6
    .line 7
    iget-object v0, p2, LI/r;->w:LI/O;

    .line 8
    .line 9
    invoke-virtual {p2}, LI/r;->k()LI/q0;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/16 v2, 0xc9

    .line 14
    .line 15
    sget-object v3, LI/t;->b:LI/g0;

    .line 16
    .line 17
    invoke-virtual {p2, v2, v3}, LI/r;->S(ILI/g0;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    sget-object v3, LI/m;->a:LI/h;

    .line 25
    .line 26
    invoke-static {v2, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    const/4 v4, 0x0

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    move-object v2, v4

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    const-string v3, "null cannot be cast to non-null type androidx.compose.runtime.ValueHolder<kotlin.Any?>"

    .line 36
    .line 37
    invoke-static {v2, v3}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    check-cast v2, LI/d1;

    .line 41
    .line 42
    :goto_0
    iget-object v3, p0, LI/u0;->a:LI/t0;

    .line 43
    .line 44
    invoke-virtual {v3, p0, v2}, LI/t0;->c(LI/u0;LI/d1;)LI/d1;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    invoke-virtual {v5, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-nez v2, :cond_1

    .line 53
    .line 54
    invoke-virtual {p2, v5}, LI/r;->d0(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_1
    iget-boolean v6, p2, LI/r;->Q:Z

    .line 58
    .line 59
    const/4 v7, 0x1

    .line 60
    const/4 v8, 0x0

    .line 61
    if-eqz v6, :cond_5

    .line 62
    .line 63
    iget-boolean v2, p0, LI/u0;->f:Z

    .line 64
    .line 65
    if-nez v2, :cond_2

    .line 66
    .line 67
    move-object v2, v1

    .line 68
    check-cast v2, LQ/j;

    .line 69
    .line 70
    invoke-virtual {v2, v3}, LQ/j;->containsKey(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-nez v2, :cond_3

    .line 75
    .line 76
    :cond_2
    check-cast v1, LQ/j;

    .line 77
    .line 78
    invoke-virtual {v1, v3, v5}, LQ/j;->b(LI/t0;LI/d1;)LQ/j;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    :cond_3
    iput-boolean v7, p2, LI/r;->I:Z

    .line 83
    .line 84
    :cond_4
    move v2, v8

    .line 85
    goto :goto_4

    .line 86
    :cond_5
    iget-object v6, p2, LI/r;->F:LI/L0;

    .line 87
    .line 88
    iget v9, v6, LI/L0;->g:I

    .line 89
    .line 90
    iget-object v10, v6, LI/L0;->b:[I

    .line 91
    .line 92
    invoke-virtual {v6, v10, v9}, LI/L0;->b([II)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    const-string v9, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    .line 97
    .line 98
    invoke-static {v6, v9}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    check-cast v6, LI/q0;

    .line 102
    .line 103
    invoke-virtual {p2}, LI/r;->z()Z

    .line 104
    .line 105
    .line 106
    move-result v9

    .line 107
    if-eqz v9, :cond_6

    .line 108
    .line 109
    if-nez v2, :cond_7

    .line 110
    .line 111
    :cond_6
    iget-boolean v9, p0, LI/u0;->f:Z

    .line 112
    .line 113
    if-nez v9, :cond_a

    .line 114
    .line 115
    move-object v9, v1

    .line 116
    check-cast v9, LQ/j;

    .line 117
    .line 118
    invoke-virtual {v9, v3}, LQ/j;->containsKey(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v9

    .line 122
    if-nez v9, :cond_7

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_7
    if-eqz v2, :cond_8

    .line 126
    .line 127
    iget-boolean v2, p2, LI/r;->v:Z

    .line 128
    .line 129
    if-nez v2, :cond_8

    .line 130
    .line 131
    goto :goto_1

    .line 132
    :cond_8
    iget-boolean v2, p2, LI/r;->v:Z

    .line 133
    .line 134
    if-eqz v2, :cond_9

    .line 135
    .line 136
    goto :goto_3

    .line 137
    :cond_9
    :goto_1
    move-object v1, v6

    .line 138
    goto :goto_3

    .line 139
    :cond_a
    :goto_2
    check-cast v1, LQ/j;

    .line 140
    .line 141
    invoke-virtual {v1, v3, v5}, LQ/j;->b(LI/t0;LI/d1;)LQ/j;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    :goto_3
    iget-boolean v2, p2, LI/r;->x:Z

    .line 146
    .line 147
    if-nez v2, :cond_b

    .line 148
    .line 149
    if-eq v6, v1, :cond_4

    .line 150
    .line 151
    :cond_b
    move v2, v7

    .line 152
    :goto_4
    if-eqz v2, :cond_c

    .line 153
    .line 154
    iget-boolean v3, p2, LI/r;->Q:Z

    .line 155
    .line 156
    if-nez v3, :cond_c

    .line 157
    .line 158
    invoke-virtual {p2, v1}, LI/r;->I(LI/q0;)V

    .line 159
    .line 160
    .line 161
    :cond_c
    iget-boolean v3, p2, LI/r;->v:Z

    .line 162
    .line 163
    invoke-virtual {v0, v3}, LI/O;->c(I)V

    .line 164
    .line 165
    .line 166
    iput-boolean v2, p2, LI/r;->v:Z

    .line 167
    .line 168
    iput-object v1, p2, LI/r;->J:LI/q0;

    .line 169
    .line 170
    const/16 v2, 0xca

    .line 171
    .line 172
    sget-object v3, LI/t;->c:LI/g0;

    .line 173
    .line 174
    invoke-virtual {p2, v2, v3, v8, v1}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 175
    .line 176
    .line 177
    const/4 v1, 0x6

    .line 178
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    invoke-virtual {p1, p2, v1}, LQ/f;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    invoke-virtual {p2, v8}, LI/r;->p(Z)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p2, v8}, LI/r;->p(Z)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0}, LI/O;->b()I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-eqz v0, :cond_d

    .line 196
    .line 197
    goto :goto_5

    .line 198
    :cond_d
    move v7, v8

    .line 199
    :goto_5
    iput-boolean v7, p2, LI/r;->v:Z

    .line 200
    .line 201
    iput-object v4, p2, LI/r;->J:LI/q0;

    .line 202
    .line 203
    invoke-virtual {p2}, LI/r;->r()LI/w0;

    .line 204
    .line 205
    .line 206
    move-result-object p2

    .line 207
    if-eqz p2, :cond_e

    .line 208
    .line 209
    new-instance v0, LB/p;

    .line 210
    .line 211
    const/4 v1, 0x6

    .line 212
    invoke-direct {v0, p3, v1, p0, p1}, LB/p;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    iput-object v0, p2, LI/w0;->d:LU1/e;

    .line 216
    .line 217
    :cond_e
    return-void
.end method

.method public static final b([LI/u0;LU1/e;LI/r;I)V
    .locals 8

    .line 1
    const v0, 0x18bf8a0a

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, LI/r;->V(I)LI/r;

    .line 5
    .line 6
    .line 7
    iget-object v0, p2, LI/r;->w:LI/O;

    .line 8
    .line 9
    invoke-virtual {p2}, LI/r;->k()LI/q0;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/16 v2, 0xc9

    .line 14
    .line 15
    sget-object v3, LI/t;->b:LI/g0;

    .line 16
    .line 17
    invoke-virtual {p2, v2, v3}, LI/r;->S(ILI/g0;)V

    .line 18
    .line 19
    .line 20
    iget-boolean v2, p2, LI/r;->Q:Z

    .line 21
    .line 22
    const/4 v3, 0x1

    .line 23
    const/4 v4, 0x0

    .line 24
    if-eqz v2, :cond_1

    .line 25
    .line 26
    sget-object v2, LQ/j;->g:LQ/j;

    .line 27
    .line 28
    invoke-static {p0, v1, v2}, LI/k;->y([LI/u0;LI/q0;LI/q0;)LQ/j;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {p2, v1, v2}, LI/r;->c0(LI/q0;LQ/j;)LQ/j;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iput-boolean v3, p2, LI/r;->I:Z

    .line 37
    .line 38
    :cond_0
    :goto_0
    move v2, v4

    .line 39
    goto :goto_2

    .line 40
    :cond_1
    iget-object v2, p2, LI/r;->F:LI/L0;

    .line 41
    .line 42
    iget v5, v2, LI/L0;->g:I

    .line 43
    .line 44
    invoke-virtual {v2, v5, v4}, LI/L0;->h(II)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    const-string v5, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    .line 49
    .line 50
    invoke-static {v2, v5}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    check-cast v2, LI/q0;

    .line 54
    .line 55
    iget-object v6, p2, LI/r;->F:LI/L0;

    .line 56
    .line 57
    iget v7, v6, LI/L0;->g:I

    .line 58
    .line 59
    invoke-virtual {v6, v7, v3}, LI/L0;->h(II)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    invoke-static {v6, v5}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    check-cast v6, LI/q0;

    .line 67
    .line 68
    invoke-static {p0, v1, v6}, LI/k;->y([LI/u0;LI/q0;LI/q0;)LQ/j;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    invoke-virtual {p2}, LI/r;->z()Z

    .line 73
    .line 74
    .line 75
    move-result v7

    .line 76
    if-eqz v7, :cond_3

    .line 77
    .line 78
    iget-boolean v7, p2, LI/r;->x:Z

    .line 79
    .line 80
    if-nez v7, :cond_3

    .line 81
    .line 82
    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    if-nez v6, :cond_2

    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_2
    iget v1, p2, LI/r;->k:I

    .line 90
    .line 91
    iget-object v5, p2, LI/r;->F:LI/L0;

    .line 92
    .line 93
    invoke-virtual {v5}, LI/L0;->s()I

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    add-int/2addr v5, v1

    .line 98
    iput v5, p2, LI/r;->k:I

    .line 99
    .line 100
    move-object v1, v2

    .line 101
    goto :goto_0

    .line 102
    :cond_3
    :goto_1
    invoke-virtual {p2, v1, v5}, LI/r;->c0(LI/q0;LQ/j;)LQ/j;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    iget-boolean v5, p2, LI/r;->x:Z

    .line 107
    .line 108
    if-nez v5, :cond_4

    .line 109
    .line 110
    invoke-static {v1, v2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    if-nez v2, :cond_0

    .line 115
    .line 116
    :cond_4
    move v2, v3

    .line 117
    :goto_2
    if-eqz v2, :cond_5

    .line 118
    .line 119
    iget-boolean v5, p2, LI/r;->Q:Z

    .line 120
    .line 121
    if-nez v5, :cond_5

    .line 122
    .line 123
    invoke-virtual {p2, v1}, LI/r;->I(LI/q0;)V

    .line 124
    .line 125
    .line 126
    :cond_5
    iget-boolean v5, p2, LI/r;->v:Z

    .line 127
    .line 128
    invoke-virtual {v0, v5}, LI/O;->c(I)V

    .line 129
    .line 130
    .line 131
    iput-boolean v2, p2, LI/r;->v:Z

    .line 132
    .line 133
    iput-object v1, p2, LI/r;->J:LI/q0;

    .line 134
    .line 135
    const/16 v2, 0xca

    .line 136
    .line 137
    sget-object v5, LI/t;->c:LI/g0;

    .line 138
    .line 139
    invoke-virtual {p2, v2, v5, v4, v1}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 140
    .line 141
    .line 142
    shr-int/lit8 v1, p3, 0x3

    .line 143
    .line 144
    and-int/lit8 v1, v1, 0xe

    .line 145
    .line 146
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    invoke-interface {p1, p2, v1}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    invoke-virtual {p2, v4}, LI/r;->p(Z)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p2, v4}, LI/r;->p(Z)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0}, LI/O;->b()I

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_6

    .line 164
    .line 165
    goto :goto_3

    .line 166
    :cond_6
    move v3, v4

    .line 167
    :goto_3
    iput-boolean v3, p2, LI/r;->v:Z

    .line 168
    .line 169
    const/4 v0, 0x0

    .line 170
    iput-object v0, p2, LI/r;->J:LI/q0;

    .line 171
    .line 172
    invoke-virtual {p2}, LI/r;->r()LI/w0;

    .line 173
    .line 174
    .line 175
    move-result-object p2

    .line 176
    if-eqz p2, :cond_7

    .line 177
    .line 178
    new-instance v0, LA1/x;

    .line 179
    .line 180
    const/4 v1, 0x2

    .line 181
    invoke-direct {v0, p3, v1, p0, p1}, LA1/x;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    iput-object v0, p2, LI/w0;->d:LU1/e;

    .line 185
    .line 186
    :cond_7
    return-void
.end method

.method public static final c(Ljava/lang/Object;LU1/c;LI/r;)V
    .locals 1

    .line 1
    invoke-virtual {p2, p0}, LI/r;->e(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    invoke-virtual {p2}, LI/r;->K()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-nez p0, :cond_0

    .line 10
    .line 11
    sget-object p0, LI/m;->a:LI/h;

    .line 12
    .line 13
    if-ne v0, p0, :cond_1

    .line 14
    .line 15
    :cond_0
    new-instance v0, LI/G;

    .line 16
    .line 17
    invoke-direct {v0, p1}, LI/G;-><init>(LU1/c;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2, v0}, LI/r;->d0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :cond_1
    check-cast v0, LI/G;

    .line 24
    .line 25
    return-void
.end method

.method public static final d(LI/r;LU1/e;Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LI/r;->P:LN1/h;

    .line 2
    .line 3
    invoke-virtual {p0, p2}, LI/r;->e(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    invoke-virtual {p0}, LI/r;->K()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-nez p2, :cond_0

    .line 12
    .line 13
    sget-object p2, LI/m;->a:LI/h;

    .line 14
    .line 15
    if-ne v1, p2, :cond_1

    .line 16
    .line 17
    :cond_0
    new-instance v1, LI/W;

    .line 18
    .line 19
    invoke-direct {v1, v0, p1}, LI/W;-><init>(LN1/h;LU1/e;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v1}, LI/r;->d0(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_1
    check-cast v1, LI/W;

    .line 26
    .line 27
    return-void
.end method

.method public static final e(LU1/a;LI/r;)V
    .locals 1

    .line 1
    iget-object p1, p1, LI/r;->L:LJ/b;

    .line 2
    .line 3
    iget-object p1, p1, LJ/b;->b:LJ/a;

    .line 4
    .line 5
    iget-object p1, p1, LJ/a;->a:LJ/J;

    .line 6
    .line 7
    sget-object v0, LJ/z;->c:LJ/z;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, LJ/J;->T(LJ/H;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0, p0}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static final f(Ljava/util/ArrayList;II)V
    .locals 1

    .line 1
    invoke-static {p1, p0}, LI/k;->m(ILjava/util/List;)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-gez p1, :cond_0

    .line 6
    .line 7
    add-int/lit8 p1, p1, 0x1

    .line 8
    .line 9
    neg-int p1, p1

    .line 10
    :cond_0
    :goto_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-ge p1, v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, LI/P;

    .line 21
    .line 22
    iget v0, v0, LI/P;->b:I

    .line 23
    .line 24
    if-ge v0, p2, :cond_1

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, LI/P;

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    return-void
.end method

.method public static final g(Li/w;I)V
    .locals 3

    .line 1
    iget v0, p0, Li/w;->b:I

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-virtual {p0, v0}, Li/w;->b(I)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eq v0, p1, :cond_0

    .line 11
    .line 12
    iget v0, p0, Li/w;->b:I

    .line 13
    .line 14
    add-int/lit8 v0, v0, -0x1

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Li/w;->b(I)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-ne v0, p1, :cond_1

    .line 21
    .line 22
    :cond_0
    return-void

    .line 23
    :cond_1
    iget v0, p0, Li/w;->b:I

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Li/w;->a(I)V

    .line 26
    .line 27
    .line 28
    :goto_0
    if-lez v0, :cond_2

    .line 29
    .line 30
    add-int/lit8 v1, v0, 0x1

    .line 31
    .line 32
    ushr-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    add-int/lit8 v1, v1, -0x1

    .line 35
    .line 36
    invoke-virtual {p0, v1}, Li/w;->b(I)I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-le p1, v2, :cond_2

    .line 41
    .line 42
    invoke-virtual {p0, v0, v2}, Li/w;->d(II)V

    .line 43
    .line 44
    .line 45
    move v0, v1

    .line 46
    goto :goto_0

    .line 47
    :cond_2
    invoke-virtual {p0, v0, p1}, Li/w;->d(II)V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public static h(LI/P0;Ljava/util/List;LI/y;)V
    .locals 5

    .line 1
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_3

    .line 6
    .line 7
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x0

    .line 12
    :goto_0
    if-ge v1, v0, :cond_3

    .line 13
    .line 14
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    check-cast v2, LI/a;

    .line 19
    .line 20
    invoke-virtual {p0, v2}, LI/P0;->c(LI/a;)I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    invoke-virtual {p0, v2}, LI/P0;->q(I)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    iget-object v4, p0, LI/P0;->b:[I

    .line 29
    .line 30
    invoke-virtual {p0, v4, v3}, LI/P0;->M([II)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    iget-object v4, p0, LI/P0;->b:[I

    .line 35
    .line 36
    add-int/lit8 v2, v2, 0x1

    .line 37
    .line 38
    invoke-virtual {p0, v2}, LI/P0;->q(I)I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    invoke-virtual {p0, v4, v2}, LI/P0;->g([II)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-ge v3, v2, :cond_0

    .line 47
    .line 48
    invoke-virtual {p0, v3}, LI/P0;->h(I)I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    iget-object v3, p0, LI/P0;->c:[Ljava/lang/Object;

    .line 53
    .line 54
    aget-object v2, v3, v2

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_0
    sget-object v2, LI/m;->a:LI/h;

    .line 58
    .line 59
    :goto_1
    instance-of v3, v2, LI/w0;

    .line 60
    .line 61
    if-eqz v3, :cond_1

    .line 62
    .line 63
    check-cast v2, LI/w0;

    .line 64
    .line 65
    goto :goto_2

    .line 66
    :cond_1
    const/4 v2, 0x0

    .line 67
    :goto_2
    if-eqz v2, :cond_2

    .line 68
    .line 69
    iput-object p2, v2, LI/w0;->a:LI/y;

    .line 70
    .line 71
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_3
    return-void
.end method

.method public static final i(LI/L0;Ljava/util/ArrayList;I)V
    .locals 3

    .line 1
    invoke-virtual {p0, p2}, LI/L0;->l(I)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, LI/L0;->b:[I

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0, p2}, LI/L0;->n(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    add-int/lit8 v0, p2, 0x1

    .line 18
    .line 19
    mul-int/lit8 v2, p2, 0x5

    .line 20
    .line 21
    add-int/lit8 v2, v2, 0x3

    .line 22
    .line 23
    aget v2, v1, v2

    .line 24
    .line 25
    add-int/2addr v2, p2

    .line 26
    :goto_0
    if-ge v0, v2, :cond_1

    .line 27
    .line 28
    invoke-static {p0, p1, v0}, LI/k;->i(LI/L0;Ljava/util/ArrayList;I)V

    .line 29
    .line 30
    .line 31
    mul-int/lit8 p2, v0, 0x5

    .line 32
    .line 33
    add-int/lit8 p2, p2, 0x3

    .line 34
    .line 35
    aget p2, v1, p2

    .line 36
    .line 37
    add-int/2addr v0, p2

    .line 38
    goto :goto_0

    .line 39
    :cond_1
    return-void
.end method

.method public static final j(LI/r;)Lc2/s;
    .locals 1

    .line 1
    iget-object p0, p0, LI/r;->P:LN1/h;

    .line 2
    .line 3
    new-instance v0, LI/J0;

    .line 4
    .line 5
    invoke-direct {v0, p0}, LI/J0;-><init>(LN1/h;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public static final k()LK/e;
    .locals 3

    .line 1
    sget-object v0, LI/V0;->b:LI/e0;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/e0;->f()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, LK/e;

    .line 8
    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    new-instance v1, LK/e;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    new-array v2, v2, [LI/q;

    .line 15
    .line 16
    invoke-direct {v1, v2}, LK/e;-><init>([Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v1}, LI/e0;->A(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-object v1
.end method

.method public static final l(LU1/a;)LI/F;
    .locals 1

    .line 1
    sget-object v0, LI/V0;->a:LI/e0;

    .line 2
    .line 3
    new-instance v0, LI/F;

    .line 4
    .line 5
    invoke-direct {v0, p0}, LI/F;-><init>(LU1/a;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public static final m(ILjava/util/List;)I
    .locals 4

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    add-int/lit8 v0, v0, -0x1

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    :goto_0
    if-gt v1, v0, :cond_2

    .line 9
    .line 10
    add-int v2, v1, v0

    .line 11
    .line 12
    ushr-int/lit8 v2, v2, 0x1

    .line 13
    .line 14
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    check-cast v3, LI/P;

    .line 19
    .line 20
    iget v3, v3, LI/P;->b:I

    .line 21
    .line 22
    invoke-static {v3, p0}, LV1/i;->g(II)I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-gez v3, :cond_0

    .line 27
    .line 28
    add-int/lit8 v1, v2, 0x1

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    if-lez v3, :cond_1

    .line 32
    .line 33
    add-int/lit8 v0, v2, -0x1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    return v2

    .line 37
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 38
    .line 39
    neg-int p0, v1

    .line 40
    return p0
.end method

.method public static final n(LN1/h;)LI/g;
    .locals 1

    .line 1
    sget-object v0, LI/h;->f:LI/h;

    .line 2
    .line 3
    invoke-interface {p0, v0}, LN1/h;->r(LN1/g;)LN1/f;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LI/g;

    .line 8
    .line 9
    if-eqz p0, :cond_0

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "A MonotonicFrameClock is not available in this CoroutineContext. Callers should supply an appropriate MonotonicFrameClock using withContext."

    .line 15
    .line 16
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p0
.end method

.method public static final o(LI/r;Ljava/lang/Integer;LU1/e;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, LI/r;->b(LU1/e;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public static p(LI/P0;ILI/P0;ZZZ)Ljava/util/List;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-virtual/range {p0 .. p1}, LI/P0;->t(I)I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    add-int v4, v1, v3

    .line 12
    .line 13
    invoke-virtual/range {p0 .. p1}, LI/P0;->f(I)I

    .line 14
    .line 15
    .line 16
    move-result v5

    .line 17
    invoke-virtual {v0, v4}, LI/P0;->f(I)I

    .line 18
    .line 19
    .line 20
    move-result v6

    .line 21
    sub-int v7, v6, v5

    .line 22
    .line 23
    const/4 v9, 0x1

    .line 24
    if-ltz v1, :cond_0

    .line 25
    .line 26
    iget-object v10, v0, LI/P0;->b:[I

    .line 27
    .line 28
    invoke-virtual/range {p0 .. p1}, LI/P0;->q(I)I

    .line 29
    .line 30
    .line 31
    move-result v11

    .line 32
    mul-int/lit8 v11, v11, 0x5

    .line 33
    .line 34
    add-int/2addr v11, v9

    .line 35
    aget v10, v10, v11

    .line 36
    .line 37
    const/high16 v11, 0xc000000

    .line 38
    .line 39
    and-int/2addr v10, v11

    .line 40
    if-eqz v10, :cond_0

    .line 41
    .line 42
    move v10, v9

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    const/4 v10, 0x0

    .line 45
    :goto_0
    invoke-virtual {v2, v3}, LI/P0;->v(I)V

    .line 46
    .line 47
    .line 48
    iget v11, v2, LI/P0;->t:I

    .line 49
    .line 50
    invoke-virtual {v2, v7, v11}, LI/P0;->w(II)V

    .line 51
    .line 52
    .line 53
    iget v11, v0, LI/P0;->g:I

    .line 54
    .line 55
    if-ge v11, v4, :cond_1

    .line 56
    .line 57
    invoke-virtual {v0, v4}, LI/P0;->A(I)V

    .line 58
    .line 59
    .line 60
    :cond_1
    iget v11, v0, LI/P0;->k:I

    .line 61
    .line 62
    if-ge v11, v6, :cond_2

    .line 63
    .line 64
    invoke-virtual {v0, v6, v4}, LI/P0;->B(II)V

    .line 65
    .line 66
    .line 67
    :cond_2
    iget-object v6, v2, LI/P0;->b:[I

    .line 68
    .line 69
    iget v11, v2, LI/P0;->t:I

    .line 70
    .line 71
    iget-object v12, v0, LI/P0;->b:[I

    .line 72
    .line 73
    mul-int/lit8 v13, v11, 0x5

    .line 74
    .line 75
    mul-int/lit8 v14, v1, 0x5

    .line 76
    .line 77
    mul-int/lit8 v15, v4, 0x5

    .line 78
    .line 79
    invoke-static {v12, v6, v13, v14, v15}, LK1/l;->R([I[IIII)V

    .line 80
    .line 81
    .line 82
    iget-object v12, v2, LI/P0;->c:[Ljava/lang/Object;

    .line 83
    .line 84
    iget v14, v2, LI/P0;->i:I

    .line 85
    .line 86
    iget-object v15, v0, LI/P0;->c:[Ljava/lang/Object;

    .line 87
    .line 88
    invoke-static {v15, v5, v12, v14, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 89
    .line 90
    .line 91
    iget v15, v2, LI/P0;->v:I

    .line 92
    .line 93
    add-int/lit8 v16, v13, 0x2

    .line 94
    .line 95
    aput v15, v6, v16

    .line 96
    .line 97
    sub-int v16, v11, v1

    .line 98
    .line 99
    add-int v8, v11, v3

    .line 100
    .line 101
    invoke-virtual {v2, v6, v11}, LI/P0;->g([II)I

    .line 102
    .line 103
    .line 104
    move-result v18

    .line 105
    sub-int v18, v14, v18

    .line 106
    .line 107
    move/from16 v19, v9

    .line 108
    .line 109
    iget v9, v2, LI/P0;->m:I

    .line 110
    .line 111
    move/from16 v20, v9

    .line 112
    .line 113
    iget v9, v2, LI/P0;->l:I

    .line 114
    .line 115
    array-length v12, v12

    .line 116
    move/from16 v21, v10

    .line 117
    .line 118
    move/from16 v10, v20

    .line 119
    .line 120
    move/from16 v20, v13

    .line 121
    .line 122
    move v13, v11

    .line 123
    :goto_1
    if-ge v13, v8, :cond_6

    .line 124
    .line 125
    if-eq v13, v11, :cond_3

    .line 126
    .line 127
    mul-int/lit8 v22, v13, 0x5

    .line 128
    .line 129
    add-int/lit8 v22, v22, 0x2

    .line 130
    .line 131
    aget v23, v6, v22

    .line 132
    .line 133
    add-int v23, v23, v16

    .line 134
    .line 135
    aput v23, v6, v22

    .line 136
    .line 137
    :cond_3
    invoke-virtual {v2, v6, v13}, LI/P0;->g([II)I

    .line 138
    .line 139
    .line 140
    move-result v22

    .line 141
    move-object/from16 v23, v6

    .line 142
    .line 143
    add-int v6, v22, v18

    .line 144
    .line 145
    if-ge v10, v13, :cond_4

    .line 146
    .line 147
    move/from16 v22, v11

    .line 148
    .line 149
    const/4 v11, 0x0

    .line 150
    goto :goto_2

    .line 151
    :cond_4
    move/from16 v22, v11

    .line 152
    .line 153
    iget v11, v2, LI/P0;->k:I

    .line 154
    .line 155
    :goto_2
    invoke-static {v6, v11, v9, v12}, LI/P0;->i(IIII)I

    .line 156
    .line 157
    .line 158
    move-result v6

    .line 159
    mul-int/lit8 v11, v13, 0x5

    .line 160
    .line 161
    add-int/lit8 v11, v11, 0x4

    .line 162
    .line 163
    aput v6, v23, v11

    .line 164
    .line 165
    if-ne v13, v10, :cond_5

    .line 166
    .line 167
    add-int/lit8 v10, v10, 0x1

    .line 168
    .line 169
    :cond_5
    add-int/lit8 v13, v13, 0x1

    .line 170
    .line 171
    move/from16 v11, v22

    .line 172
    .line 173
    move-object/from16 v6, v23

    .line 174
    .line 175
    goto :goto_1

    .line 176
    :cond_6
    move-object/from16 v23, v6

    .line 177
    .line 178
    iput v10, v2, LI/P0;->m:I

    .line 179
    .line 180
    iget-object v6, v0, LI/P0;->d:Ljava/util/ArrayList;

    .line 181
    .line 182
    invoke-virtual {v0}, LI/P0;->o()I

    .line 183
    .line 184
    .line 185
    move-result v9

    .line 186
    invoke-static {v6, v1, v9}, LI/O0;->b(Ljava/util/ArrayList;II)I

    .line 187
    .line 188
    .line 189
    move-result v6

    .line 190
    iget-object v9, v0, LI/P0;->d:Ljava/util/ArrayList;

    .line 191
    .line 192
    invoke-virtual {v0}, LI/P0;->o()I

    .line 193
    .line 194
    .line 195
    move-result v10

    .line 196
    invoke-static {v9, v4, v10}, LI/O0;->b(Ljava/util/ArrayList;II)I

    .line 197
    .line 198
    .line 199
    move-result v4

    .line 200
    if-ge v6, v4, :cond_8

    .line 201
    .line 202
    iget-object v9, v0, LI/P0;->d:Ljava/util/ArrayList;

    .line 203
    .line 204
    new-instance v10, Ljava/util/ArrayList;

    .line 205
    .line 206
    sub-int v11, v4, v6

    .line 207
    .line 208
    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    .line 209
    .line 210
    .line 211
    move v11, v6

    .line 212
    :goto_3
    if-ge v11, v4, :cond_7

    .line 213
    .line 214
    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v12

    .line 218
    check-cast v12, LI/a;

    .line 219
    .line 220
    iget v13, v12, LI/a;->a:I

    .line 221
    .line 222
    add-int v13, v13, v16

    .line 223
    .line 224
    iput v13, v12, LI/a;->a:I

    .line 225
    .line 226
    invoke-virtual {v10, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    add-int/lit8 v11, v11, 0x1

    .line 230
    .line 231
    goto :goto_3

    .line 232
    :cond_7
    iget-object v11, v2, LI/P0;->d:Ljava/util/ArrayList;

    .line 233
    .line 234
    iget v12, v2, LI/P0;->t:I

    .line 235
    .line 236
    invoke-virtual {v2}, LI/P0;->o()I

    .line 237
    .line 238
    .line 239
    move-result v13

    .line 240
    invoke-static {v11, v12, v13}, LI/O0;->b(Ljava/util/ArrayList;II)I

    .line 241
    .line 242
    .line 243
    move-result v11

    .line 244
    iget-object v12, v2, LI/P0;->d:Ljava/util/ArrayList;

    .line 245
    .line 246
    invoke-virtual {v12, v11, v10}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    .line 247
    .line 248
    .line 249
    invoke-virtual {v9, v6, v4}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 250
    .line 251
    .line 252
    move-result-object v4

    .line 253
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 254
    .line 255
    .line 256
    goto :goto_4

    .line 257
    :cond_8
    sget-object v10, LK1/t;->d:LK1/t;

    .line 258
    .line 259
    :goto_4
    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    .line 260
    .line 261
    .line 262
    move-result v4

    .line 263
    if-nez v4, :cond_9

    .line 264
    .line 265
    iget-object v4, v0, LI/P0;->e:Ljava/util/HashMap;

    .line 266
    .line 267
    iget-object v6, v2, LI/P0;->e:Ljava/util/HashMap;

    .line 268
    .line 269
    if-eqz v4, :cond_9

    .line 270
    .line 271
    if-eqz v6, :cond_9

    .line 272
    .line 273
    invoke-interface {v10}, Ljava/util/Collection;->size()I

    .line 274
    .line 275
    .line 276
    move-result v6

    .line 277
    const/4 v9, 0x0

    .line 278
    :goto_5
    if-ge v9, v6, :cond_9

    .line 279
    .line 280
    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v11

    .line 284
    check-cast v11, LI/a;

    .line 285
    .line 286
    invoke-virtual {v4, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v11

    .line 290
    check-cast v11, LI/N;

    .line 291
    .line 292
    add-int/lit8 v9, v9, 0x1

    .line 293
    .line 294
    goto :goto_5

    .line 295
    :cond_9
    iget v4, v2, LI/P0;->v:I

    .line 296
    .line 297
    invoke-virtual {v2, v15}, LI/P0;->N(I)LI/N;

    .line 298
    .line 299
    .line 300
    iget-object v4, v0, LI/P0;->b:[I

    .line 301
    .line 302
    invoke-virtual {v0, v4, v1}, LI/P0;->D([II)I

    .line 303
    .line 304
    .line 305
    move-result v4

    .line 306
    if-nez p5, :cond_a

    .line 307
    .line 308
    const/16 v17, 0x0

    .line 309
    .line 310
    goto :goto_7

    .line 311
    :cond_a
    if-eqz p3, :cond_e

    .line 312
    .line 313
    if-ltz v4, :cond_b

    .line 314
    .line 315
    move/from16 v17, v19

    .line 316
    .line 317
    goto :goto_6

    .line 318
    :cond_b
    const/16 v17, 0x0

    .line 319
    .line 320
    :goto_6
    if-eqz v17, :cond_c

    .line 321
    .line 322
    invoke-virtual {v0}, LI/P0;->O()V

    .line 323
    .line 324
    .line 325
    iget v3, v0, LI/P0;->t:I

    .line 326
    .line 327
    sub-int/2addr v4, v3

    .line 328
    invoke-virtual {v0, v4}, LI/P0;->a(I)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v0}, LI/P0;->O()V

    .line 332
    .line 333
    .line 334
    :cond_c
    iget v3, v0, LI/P0;->t:I

    .line 335
    .line 336
    sub-int/2addr v1, v3

    .line 337
    invoke-virtual {v0, v1}, LI/P0;->a(I)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v0}, LI/P0;->G()Z

    .line 341
    .line 342
    .line 343
    move-result v1

    .line 344
    if-eqz v17, :cond_d

    .line 345
    .line 346
    invoke-virtual {v0}, LI/P0;->L()V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v0}, LI/P0;->j()V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v0}, LI/P0;->L()V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v0}, LI/P0;->j()V

    .line 356
    .line 357
    .line 358
    :cond_d
    move/from16 v17, v1

    .line 359
    .line 360
    goto :goto_7

    .line 361
    :cond_e
    invoke-virtual {v0, v1, v3}, LI/P0;->H(II)Z

    .line 362
    .line 363
    .line 364
    move-result v3

    .line 365
    add-int/lit8 v1, v1, -0x1

    .line 366
    .line 367
    invoke-virtual {v0, v5, v7, v1}, LI/P0;->I(III)V

    .line 368
    .line 369
    .line 370
    move/from16 v17, v3

    .line 371
    .line 372
    :goto_7
    if-eqz v17, :cond_f

    .line 373
    .line 374
    const-string v0, "Unexpectedly removed anchors"

    .line 375
    .line 376
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    :cond_f
    iget v0, v2, LI/P0;->o:I

    .line 380
    .line 381
    add-int/lit8 v13, v20, 0x1

    .line 382
    .line 383
    aget v1, v23, v13

    .line 384
    .line 385
    const/high16 v3, 0x40000000    # 2.0f

    .line 386
    .line 387
    and-int/2addr v3, v1

    .line 388
    if-eqz v3, :cond_10

    .line 389
    .line 390
    move/from16 v9, v19

    .line 391
    .line 392
    goto :goto_8

    .line 393
    :cond_10
    const v3, 0x3ffffff

    .line 394
    .line 395
    .line 396
    and-int v9, v1, v3

    .line 397
    .line 398
    :goto_8
    add-int/2addr v0, v9

    .line 399
    iput v0, v2, LI/P0;->o:I

    .line 400
    .line 401
    if-eqz p4, :cond_11

    .line 402
    .line 403
    iput v8, v2, LI/P0;->t:I

    .line 404
    .line 405
    add-int/2addr v14, v7

    .line 406
    iput v14, v2, LI/P0;->i:I

    .line 407
    .line 408
    :cond_11
    if-eqz v21, :cond_12

    .line 409
    .line 410
    invoke-virtual {v2, v15}, LI/P0;->S(I)V

    .line 411
    .line 412
    .line 413
    :cond_12
    return-object v10
.end method

.method public static q(Ljava/lang/Object;)LI/m0;
    .locals 2

    .line 1
    sget-object v0, LI/h;->j:LI/h;

    .line 2
    .line 3
    new-instance v1, LI/m0;

    .line 4
    .line 5
    invoke-direct {v1, p0, v0}, LI/m0;-><init>(Ljava/lang/Object;LI/U0;)V

    .line 6
    .line 7
    .line 8
    return-object v1
.end method

.method public static final r(LI/q0;LI/t0;)Ljava/lang/Object;
    .locals 1

    .line 1
    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.CompositionLocal<kotlin.Any?>"

    .line 2
    .line 3
    invoke-static {p1, v0}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    check-cast p0, LQ/j;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, LQ/j;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {p1}, LI/t0;->b()LI/d1;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :cond_0
    check-cast v0, LI/d1;

    .line 19
    .line 20
    invoke-interface {v0, p0}, LI/d1;->a(LI/q0;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

.method public static final s(LI/r;LU1/c;)V
    .locals 2

    .line 1
    new-instance v0, LA1/e;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LA1/e;-><init>(ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    sget-object p1, LJ1/m;->a:LJ1/m;

    .line 9
    .line 10
    invoke-virtual {p0, v0, p1}, LI/r;->b(LU1/e;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static final t(Ljava/lang/Object;LI/r;)LI/b0;
    .locals 2

    .line 1
    invoke-virtual {p1}, LI/r;->K()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, LI/m;->a:LI/h;

    .line 6
    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    invoke-static {p0}, LI/k;->q(Ljava/lang/Object;)LI/m0;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, LI/r;->d0(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    check-cast v0, LI/b0;

    .line 17
    .line 18
    invoke-interface {v0, p0}, LI/b0;->setValue(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public static final u(LI/r;LU1/e;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    invoke-virtual {p0}, LI/r;->K()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {v0, p2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    return-void

    .line 17
    :cond_1
    :goto_0
    invoke-virtual {p0, p2}, LI/r;->d0(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, p1, p2}, LI/r;->b(LU1/e;Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public static final v(LU1/a;)LA0/h;
    .locals 2

    .line 1
    new-instance v0, LI/X0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, v1}, LI/X0;-><init>(LU1/a;LN1/c;)V

    .line 5
    .line 6
    .line 7
    new-instance p0, LA0/h;

    .line 8
    .line 9
    invoke-direct {p0, v0}, LA0/h;-><init>(LU1/e;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public static final w(Li/w;)I
    .locals 10

    .line 1
    iget v0, p0, Li/w;->b:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p0, v0}, Li/w;->b(I)I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    :cond_0
    iget v2, p0, Li/w;->b:I

    .line 9
    .line 10
    if-eqz v2, :cond_3

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Li/w;->b(I)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-ne v2, v1, :cond_3

    .line 17
    .line 18
    iget v2, p0, Li/w;->b:I

    .line 19
    .line 20
    if-eqz v2, :cond_2

    .line 21
    .line 22
    iget-object v3, p0, Li/w;->a:[I

    .line 23
    .line 24
    add-int/lit8 v2, v2, -0x1

    .line 25
    .line 26
    aget v2, v3, v2

    .line 27
    .line 28
    invoke-virtual {p0, v0, v2}, Li/w;->d(II)V

    .line 29
    .line 30
    .line 31
    iget v2, p0, Li/w;->b:I

    .line 32
    .line 33
    add-int/lit8 v2, v2, -0x1

    .line 34
    .line 35
    invoke-virtual {p0, v2}, Li/w;->c(I)V

    .line 36
    .line 37
    .line 38
    iget v2, p0, Li/w;->b:I

    .line 39
    .line 40
    ushr-int/lit8 v3, v2, 0x1

    .line 41
    .line 42
    move v4, v0

    .line 43
    :goto_0
    if-ge v4, v3, :cond_0

    .line 44
    .line 45
    invoke-virtual {p0, v4}, Li/w;->b(I)I

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    add-int/lit8 v6, v4, 0x1

    .line 50
    .line 51
    mul-int/lit8 v6, v6, 0x2

    .line 52
    .line 53
    add-int/lit8 v7, v6, -0x1

    .line 54
    .line 55
    invoke-virtual {p0, v7}, Li/w;->b(I)I

    .line 56
    .line 57
    .line 58
    move-result v8

    .line 59
    if-ge v6, v2, :cond_1

    .line 60
    .line 61
    invoke-virtual {p0, v6}, Li/w;->b(I)I

    .line 62
    .line 63
    .line 64
    move-result v9

    .line 65
    if-le v9, v8, :cond_1

    .line 66
    .line 67
    if-le v9, v5, :cond_0

    .line 68
    .line 69
    invoke-virtual {p0, v4, v9}, Li/w;->d(II)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p0, v6, v5}, Li/w;->d(II)V

    .line 73
    .line 74
    .line 75
    move v4, v6

    .line 76
    goto :goto_0

    .line 77
    :cond_1
    if-le v8, v5, :cond_0

    .line 78
    .line 79
    invoke-virtual {p0, v4, v8}, Li/w;->d(II)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0, v7, v5}, Li/w;->d(II)V

    .line 83
    .line 84
    .line 85
    move v4, v7

    .line 86
    goto :goto_0

    .line 87
    :cond_2
    const-string p0, "IntList is empty."

    .line 88
    .line 89
    invoke-static {p0}, Lj/a;->e(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    const/4 p0, 0x0

    .line 93
    throw p0

    .line 94
    :cond_3
    return v1
.end method

.method public static final x(I)I
    .locals 3

    .line 1
    const v0, 0x12492492

    .line 2
    .line 3
    .line 4
    and-int/2addr v0, p0

    .line 5
    const v1, 0x24924924

    .line 6
    .line 7
    .line 8
    and-int/2addr v1, p0

    .line 9
    const v2, -0x36db6db7

    .line 10
    .line 11
    .line 12
    and-int/2addr p0, v2

    .line 13
    shr-int/lit8 v2, v1, 0x1

    .line 14
    .line 15
    or-int/2addr v2, v0

    .line 16
    or-int/2addr p0, v2

    .line 17
    shl-int/lit8 v0, v0, 0x1

    .line 18
    .line 19
    and-int/2addr v0, v1

    .line 20
    or-int/2addr p0, v0

    .line 21
    return p0
.end method

.method public static final y([LI/u0;LI/q0;LI/q0;)LQ/j;
    .locals 6

    .line 1
    sget-object v0, LQ/j;->g:LQ/j;

    .line 2
    .line 3
    new-instance v1, LQ/i;

    .line 4
    .line 5
    invoke-direct {v1, v0}, LQ/i;-><init>(LQ/j;)V

    .line 6
    .line 7
    .line 8
    array-length v0, p0

    .line 9
    const/4 v2, 0x0

    .line 10
    :goto_0
    if-ge v2, v0, :cond_2

    .line 11
    .line 12
    aget-object v3, p0, v2

    .line 13
    .line 14
    iget-object v4, v3, LI/u0;->a:LI/t0;

    .line 15
    .line 16
    iget-boolean v5, v3, LI/u0;->f:Z

    .line 17
    .line 18
    if-nez v5, :cond_0

    .line 19
    .line 20
    move-object v5, p1

    .line 21
    check-cast v5, LQ/j;

    .line 22
    .line 23
    invoke-virtual {v5, v4}, LQ/j;->containsKey(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    if-nez v5, :cond_1

    .line 28
    .line 29
    :cond_0
    move-object v5, p2

    .line 30
    check-cast v5, LQ/j;

    .line 31
    .line 32
    invoke-virtual {v5, v4}, LQ/j;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    check-cast v5, LI/d1;

    .line 37
    .line 38
    invoke-virtual {v4, v3, v5}, LI/t0;->c(LI/u0;LI/d1;)LI/d1;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-virtual {v1, v4, v3}, LQ/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    invoke-virtual {v1}, LQ/i;->a()LQ/j;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0
.end method
