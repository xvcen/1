.class public final LI/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LI/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LI/h;

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    invoke-direct {v0, v1}, LI/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LI/m;->a:LI/h;

    .line 8
    .line 9
    return-void
.end method
