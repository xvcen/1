.class public final LI/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI/G0;


# instance fields
.field public final d:LI/p;


# direct methods
.method public constructor <init>(LI/p;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LI/o;->d:LI/p;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c()V
    .locals 0

    .line 1
    return-void
.end method

.method public final d()V
    .locals 1

    .line 1
    iget-object v0, p0, LI/o;->d:LI/p;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/p;->t()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final g()V
    .locals 1

    .line 1
    iget-object v0, p0, LI/o;->d:LI/p;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/p;->t()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
