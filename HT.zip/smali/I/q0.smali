.class public interface abstract LI/q0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Map;
.implements LW1/a;
.implements LI/A;
