.class public final LI/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public A:I

.field public B:Z

.field public final C:LI/q;

.field public final D:Ljava/util/ArrayList;

.field public E:Z

.field public F:LI/L0;

.field public G:LI/M0;

.field public H:LI/P0;

.field public I:Z

.field public J:LI/q0;

.field public K:LJ/a;

.field public final L:LJ/b;

.field public M:LI/a;

.field public N:LJ/c;

.field public final O:LV/e;

.field public final P:LN1/h;

.field public Q:Z

.field public R:J

.field public S:LI/x;

.field public final a:LI/e0;

.field public final b:LI/v;

.field public final c:LI/M0;

.field public final d:Li/H;

.field public final e:LJ/a;

.field public final f:LJ/a;

.field public final g:LI/y;

.field public final h:Ljava/util/ArrayList;

.field public i:LI/p0;

.field public j:I

.field public k:I

.field public l:I

.field public final m:LI/O;

.field public n:[I

.field public o:Li/v;

.field public p:Z

.field public q:Z

.field public final r:Ljava/util/ArrayList;

.field public final s:LI/O;

.field public t:LI/q0;

.field public u:Li/x;

.field public v:Z

.field public final w:LI/O;

.field public x:Z

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>(LI/e0;LI/v;LI/M0;Li/H;LJ/a;LJ/a;LI/h;LI/y;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LI/r;->a:LI/e0;

    .line 5
    .line 6
    iput-object p2, p0, LI/r;->b:LI/v;

    .line 7
    .line 8
    iput-object p3, p0, LI/r;->c:LI/M0;

    .line 9
    .line 10
    iput-object p4, p0, LI/r;->d:Li/H;

    .line 11
    .line 12
    iput-object p5, p0, LI/r;->e:LJ/a;

    .line 13
    .line 14
    iput-object p6, p0, LI/r;->f:LJ/a;

    .line 15
    .line 16
    iput-object p8, p0, LI/r;->g:LI/y;

    .line 17
    .line 18
    new-instance p1, Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, LI/r;->h:Ljava/util/ArrayList;

    .line 24
    .line 25
    new-instance p1, LI/O;

    .line 26
    .line 27
    invoke-direct {p1}, LI/O;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, LI/r;->m:LI/O;

    .line 31
    .line 32
    new-instance p1, Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 38
    .line 39
    new-instance p1, LI/O;

    .line 40
    .line 41
    invoke-direct {p1}, LI/O;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, LI/r;->s:LI/O;

    .line 45
    .line 46
    sget-object p1, LQ/j;->g:LQ/j;

    .line 47
    .line 48
    iput-object p1, p0, LI/r;->t:LI/q0;

    .line 49
    .line 50
    new-instance p1, LI/O;

    .line 51
    .line 52
    invoke-direct {p1}, LI/O;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object p1, p0, LI/r;->w:LI/O;

    .line 56
    .line 57
    const/4 p1, -0x1

    .line 58
    iput p1, p0, LI/r;->y:I

    .line 59
    .line 60
    invoke-virtual {p2}, LI/v;->e()Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    const/4 p4, 0x0

    .line 65
    const/4 p6, 0x1

    .line 66
    if-nez p1, :cond_1

    .line 67
    .line 68
    invoke-virtual {p2}, LI/v;->c()Z

    .line 69
    .line 70
    .line 71
    move-result p1

    .line 72
    if-eqz p1, :cond_0

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_0
    move p1, p4

    .line 76
    goto :goto_1

    .line 77
    :cond_1
    :goto_0
    move p1, p6

    .line 78
    :goto_1
    iput-boolean p1, p0, LI/r;->B:Z

    .line 79
    .line 80
    new-instance p1, LI/q;

    .line 81
    .line 82
    const/4 p7, 0x0

    .line 83
    invoke-direct {p1, p7, p0}, LI/q;-><init>(ILjava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    iput-object p1, p0, LI/r;->C:LI/q;

    .line 87
    .line 88
    new-instance p1, Ljava/util/ArrayList;

    .line 89
    .line 90
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 91
    .line 92
    .line 93
    iput-object p1, p0, LI/r;->D:Ljava/util/ArrayList;

    .line 94
    .line 95
    invoke-virtual {p3}, LI/M0;->c()LI/L0;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    invoke-virtual {p1}, LI/L0;->c()V

    .line 100
    .line 101
    .line 102
    iput-object p1, p0, LI/r;->F:LI/L0;

    .line 103
    .line 104
    new-instance p1, LI/M0;

    .line 105
    .line 106
    invoke-direct {p1}, LI/M0;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2}, LI/v;->e()Z

    .line 110
    .line 111
    .line 112
    move-result p3

    .line 113
    if-eqz p3, :cond_2

    .line 114
    .line 115
    invoke-virtual {p1}, LI/M0;->b()V

    .line 116
    .line 117
    .line 118
    :cond_2
    invoke-virtual {p2}, LI/v;->c()Z

    .line 119
    .line 120
    .line 121
    move-result p3

    .line 122
    if-eqz p3, :cond_3

    .line 123
    .line 124
    new-instance p3, Li/x;

    .line 125
    .line 126
    invoke-direct {p3}, Li/x;-><init>()V

    .line 127
    .line 128
    .line 129
    iput-object p3, p1, LI/M0;->n:Li/x;

    .line 130
    .line 131
    :cond_3
    iput-object p1, p0, LI/r;->G:LI/M0;

    .line 132
    .line 133
    invoke-virtual {p1}, LI/M0;->d()LI/P0;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    invoke-virtual {p1, p6}, LI/P0;->e(Z)V

    .line 138
    .line 139
    .line 140
    iput-object p1, p0, LI/r;->H:LI/P0;

    .line 141
    .line 142
    new-instance p1, LJ/b;

    .line 143
    .line 144
    invoke-direct {p1, p0, p5}, LJ/b;-><init>(LI/r;LJ/a;)V

    .line 145
    .line 146
    .line 147
    iput-object p1, p0, LI/r;->L:LJ/b;

    .line 148
    .line 149
    iget-object p1, p0, LI/r;->G:LI/M0;

    .line 150
    .line 151
    invoke-virtual {p1}, LI/M0;->c()LI/L0;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    :try_start_0
    invoke-virtual {p1, p4}, LI/L0;->a(I)LI/a;

    .line 156
    .line 157
    .line 158
    move-result-object p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 159
    invoke-virtual {p1}, LI/L0;->c()V

    .line 160
    .line 161
    .line 162
    iput-object p3, p0, LI/r;->M:LI/a;

    .line 163
    .line 164
    new-instance p1, LJ/c;

    .line 165
    .line 166
    invoke-direct {p1}, LJ/c;-><init>()V

    .line 167
    .line 168
    .line 169
    iput-object p1, p0, LI/r;->N:LJ/c;

    .line 170
    .line 171
    new-instance p1, LV/e;

    .line 172
    .line 173
    invoke-direct {p1, p0}, LV/e;-><init>(LI/r;)V

    .line 174
    .line 175
    .line 176
    iput-object p1, p0, LI/r;->O:LV/e;

    .line 177
    .line 178
    invoke-virtual {p2}, LI/v;->i()LN1/h;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    invoke-virtual {p0}, LI/r;->y()LV/e;

    .line 183
    .line 184
    .line 185
    move-result-object p2

    .line 186
    if-eqz p2, :cond_4

    .line 187
    .line 188
    goto :goto_2

    .line 189
    :cond_4
    sget-object p2, LN1/i;->d:LN1/i;

    .line 190
    .line 191
    :goto_2
    invoke-interface {p1, p2}, LN1/h;->i(LN1/h;)LN1/h;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    iput-object p1, p0, LI/r;->P:LN1/h;

    .line 196
    .line 197
    return-void

    .line 198
    :catchall_0
    move-exception p2

    .line 199
    invoke-virtual {p1}, LI/L0;->c()V

    .line 200
    .line 201
    .line 202
    throw p2
.end method

.method public static final M(LI/r;IZI)I
    .locals 9

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LI/L0;->j(I)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v1, :cond_8

    .line 10
    .line 11
    invoke-virtual {v0, p1}, LI/L0;->i(I)I

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    iget-object p3, v0, LI/L0;->b:[I

    .line 16
    .line 17
    invoke-virtual {v0, p3, p1}, LI/L0;->p([II)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p3

    .line 21
    const/16 v1, 0xce

    .line 22
    .line 23
    if-ne p2, v1, :cond_6

    .line 24
    .line 25
    sget-object p2, LI/t;->e:LI/g0;

    .line 26
    .line 27
    invoke-static {p3, p2}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    if-eqz p2, :cond_6

    .line 32
    .line 33
    invoke-virtual {v0, p1, v2}, LI/L0;->h(II)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    instance-of p3, p2, LI/H0;

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    if-eqz p3, :cond_0

    .line 41
    .line 42
    check-cast p2, LI/H0;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move-object p2, v1

    .line 46
    :goto_0
    if-eqz p2, :cond_1

    .line 47
    .line 48
    iget-object p2, p2, LI/H0;->a:LI/G0;

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    move-object p2, v1

    .line 52
    :goto_1
    instance-of p3, p2, LI/o;

    .line 53
    .line 54
    if-eqz p3, :cond_2

    .line 55
    .line 56
    move-object v1, p2

    .line 57
    check-cast v1, LI/o;

    .line 58
    .line 59
    :cond_2
    if-eqz v1, :cond_5

    .line 60
    .line 61
    iget-object p2, v1, LI/o;->d:LI/p;

    .line 62
    .line 63
    iget-object p2, p2, LI/p;->e:Ljava/util/LinkedHashSet;

    .line 64
    .line 65
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result p3

    .line 73
    if-eqz p3, :cond_5

    .line 74
    .line 75
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p3

    .line 79
    check-cast p3, LI/r;

    .line 80
    .line 81
    iget-object v1, p3, LI/r;->c:LI/M0;

    .line 82
    .line 83
    iget v4, v1, LI/M0;->e:I

    .line 84
    .line 85
    if-lez v4, :cond_4

    .line 86
    .line 87
    iget-object v1, v1, LI/M0;->d:[I

    .line 88
    .line 89
    aget v1, v1, v3

    .line 90
    .line 91
    const/high16 v4, 0x4000000

    .line 92
    .line 93
    and-int/2addr v1, v4

    .line 94
    if-eqz v1, :cond_4

    .line 95
    .line 96
    iget-object v1, p3, LI/r;->g:LI/y;

    .line 97
    .line 98
    iget-object v4, v1, LI/y;->g:Ljava/lang/Object;

    .line 99
    .line 100
    monitor-enter v4

    .line 101
    :try_start_0
    invoke-virtual {v1}, LI/y;->l()V

    .line 102
    .line 103
    .line 104
    iget-object v5, v1, LI/y;->q:Li/E;

    .line 105
    .line 106
    invoke-static {}, LX1/a;->H()Li/E;

    .line 107
    .line 108
    .line 109
    move-result-object v6

    .line 110
    iput-object v6, v1, LI/y;->q:Li/E;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 111
    .line 112
    :try_start_1
    iget-object v6, v1, LI/y;->w:LI/r;

    .line 113
    .line 114
    invoke-virtual {v6, v5}, LI/r;->Z(Li/E;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 115
    .line 116
    .line 117
    monitor-exit v4

    .line 118
    new-instance v1, LJ/a;

    .line 119
    .line 120
    invoke-direct {v1}, LJ/a;-><init>()V

    .line 121
    .line 122
    .line 123
    iput-object v1, p3, LI/r;->K:LJ/a;

    .line 124
    .line 125
    iget-object v4, p3, LI/r;->c:LI/M0;

    .line 126
    .line 127
    invoke-virtual {v4}, LI/M0;->c()LI/L0;

    .line 128
    .line 129
    .line 130
    move-result-object v4

    .line 131
    :try_start_2
    iput-object v4, p3, LI/r;->F:LI/L0;

    .line 132
    .line 133
    iget-object v5, p3, LI/r;->L:LJ/b;

    .line 134
    .line 135
    iget-object v6, v5, LJ/b;->b:LJ/a;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 136
    .line 137
    :try_start_3
    iput-object v1, v5, LJ/b;->b:LJ/a;

    .line 138
    .line 139
    invoke-virtual {p3, v2}, LI/r;->L(I)V

    .line 140
    .line 141
    .line 142
    iget-object v1, p3, LI/r;->L:LJ/b;

    .line 143
    .line 144
    invoke-virtual {v1}, LJ/b;->b()V

    .line 145
    .line 146
    .line 147
    iget-boolean v7, v1, LJ/b;->c:Z

    .line 148
    .line 149
    if-eqz v7, :cond_3

    .line 150
    .line 151
    iget-object v7, v1, LJ/b;->b:LJ/a;

    .line 152
    .line 153
    iget-object v7, v7, LJ/a;->a:LJ/J;

    .line 154
    .line 155
    sget-object v8, LJ/A;->c:LJ/A;

    .line 156
    .line 157
    invoke-virtual {v7, v8}, LJ/J;->T(LJ/H;)V

    .line 158
    .line 159
    .line 160
    iget-boolean v7, v1, LJ/b;->c:Z

    .line 161
    .line 162
    if-eqz v7, :cond_3

    .line 163
    .line 164
    invoke-virtual {v1, v2}, LJ/b;->d(Z)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v1, v2}, LJ/b;->d(Z)V

    .line 168
    .line 169
    .line 170
    iget-object v7, v1, LJ/b;->b:LJ/a;

    .line 171
    .line 172
    iget-object v7, v7, LJ/a;->a:LJ/J;

    .line 173
    .line 174
    sget-object v8, LJ/l;->c:LJ/l;

    .line 175
    .line 176
    invoke-virtual {v7, v8}, LJ/J;->T(LJ/H;)V

    .line 177
    .line 178
    .line 179
    iput-boolean v2, v1, LJ/b;->c:Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 180
    .line 181
    :cond_3
    :try_start_4
    iput-object v6, v5, LJ/b;->b:LJ/a;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 182
    .line 183
    invoke-virtual {v4}, LI/L0;->c()V

    .line 184
    .line 185
    .line 186
    goto :goto_4

    .line 187
    :catchall_0
    move-exception p0

    .line 188
    goto :goto_3

    .line 189
    :catchall_1
    move-exception p0

    .line 190
    :try_start_5
    iput-object v6, v5, LJ/b;->b:LJ/a;

    .line 191
    .line 192
    throw p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 193
    :goto_3
    invoke-virtual {v4}, LI/L0;->c()V

    .line 194
    .line 195
    .line 196
    throw p0

    .line 197
    :catchall_2
    move-exception p0

    .line 198
    :try_start_6
    iput-object v5, v1, LI/y;->q:Li/E;

    .line 199
    .line 200
    throw p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 201
    :catchall_3
    move-exception p0

    .line 202
    monitor-exit v4

    .line 203
    throw p0

    .line 204
    :cond_4
    :goto_4
    iget-object v1, p0, LI/r;->b:LI/v;

    .line 205
    .line 206
    iget-object p3, p3, LI/r;->g:LI/y;

    .line 207
    .line 208
    invoke-virtual {v1, p3}, LI/v;->o(LI/y;)V

    .line 209
    .line 210
    .line 211
    goto/16 :goto_2

    .line 212
    .line 213
    :cond_5
    invoke-virtual {v0, p1}, LI/L0;->o(I)I

    .line 214
    .line 215
    .line 216
    move-result p0

    .line 217
    return p0

    .line 218
    :cond_6
    invoke-virtual {v0, p1}, LI/L0;->l(I)Z

    .line 219
    .line 220
    .line 221
    move-result p0

    .line 222
    if-eqz p0, :cond_7

    .line 223
    .line 224
    goto/16 :goto_9

    .line 225
    .line 226
    :cond_7
    invoke-virtual {v0, p1}, LI/L0;->o(I)I

    .line 227
    .line 228
    .line 229
    move-result p0

    .line 230
    return p0

    .line 231
    :cond_8
    invoke-virtual {v0, p1}, LI/L0;->d(I)Z

    .line 232
    .line 233
    .line 234
    move-result v1

    .line 235
    if-eqz v1, :cond_10

    .line 236
    .line 237
    iget-object v1, v0, LI/L0;->b:[I

    .line 238
    .line 239
    mul-int/lit8 v4, p1, 0x5

    .line 240
    .line 241
    add-int/lit8 v4, v4, 0x3

    .line 242
    .line 243
    aget v1, v1, v4

    .line 244
    .line 245
    add-int/2addr v1, p1

    .line 246
    add-int/lit8 v4, p1, 0x1

    .line 247
    .line 248
    move v5, v2

    .line 249
    :goto_5
    if-ge v4, v1, :cond_e

    .line 250
    .line 251
    invoke-virtual {v0, v4}, LI/L0;->l(I)Z

    .line 252
    .line 253
    .line 254
    move-result v6

    .line 255
    if-eqz v6, :cond_9

    .line 256
    .line 257
    iget-object v7, p0, LI/r;->L:LJ/b;

    .line 258
    .line 259
    invoke-virtual {v7}, LJ/b;->c()V

    .line 260
    .line 261
    .line 262
    iget-object v7, p0, LI/r;->L:LJ/b;

    .line 263
    .line 264
    invoke-virtual {v0, v4}, LI/L0;->n(I)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v8

    .line 268
    invoke-virtual {v7}, LJ/b;->c()V

    .line 269
    .line 270
    .line 271
    iget-object v7, v7, LJ/b;->h:Ljava/util/ArrayList;

    .line 272
    .line 273
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 274
    .line 275
    .line 276
    :cond_9
    if-nez v6, :cond_b

    .line 277
    .line 278
    if-eqz p2, :cond_a

    .line 279
    .line 280
    goto :goto_6

    .line 281
    :cond_a
    move v7, v2

    .line 282
    goto :goto_7

    .line 283
    :cond_b
    :goto_6
    move v7, v3

    .line 284
    :goto_7
    if-eqz v6, :cond_c

    .line 285
    .line 286
    move v8, v2

    .line 287
    goto :goto_8

    .line 288
    :cond_c
    add-int v8, p3, v5

    .line 289
    .line 290
    :goto_8
    invoke-static {p0, v4, v7, v8}, LI/r;->M(LI/r;IZI)I

    .line 291
    .line 292
    .line 293
    move-result v7

    .line 294
    add-int/2addr v5, v7

    .line 295
    if-eqz v6, :cond_d

    .line 296
    .line 297
    iget-object v6, p0, LI/r;->L:LJ/b;

    .line 298
    .line 299
    invoke-virtual {v6}, LJ/b;->c()V

    .line 300
    .line 301
    .line 302
    iget-object v6, p0, LI/r;->L:LJ/b;

    .line 303
    .line 304
    invoke-virtual {v6}, LJ/b;->a()V

    .line 305
    .line 306
    .line 307
    :cond_d
    iget-object v6, v0, LI/L0;->b:[I

    .line 308
    .line 309
    mul-int/lit8 v7, v4, 0x5

    .line 310
    .line 311
    add-int/lit8 v7, v7, 0x3

    .line 312
    .line 313
    aget v6, v6, v7

    .line 314
    .line 315
    add-int/2addr v4, v6

    .line 316
    goto :goto_5

    .line 317
    :cond_e
    invoke-virtual {v0, p1}, LI/L0;->l(I)Z

    .line 318
    .line 319
    .line 320
    move-result p0

    .line 321
    if-eqz p0, :cond_f

    .line 322
    .line 323
    goto :goto_9

    .line 324
    :cond_f
    return v5

    .line 325
    :cond_10
    invoke-virtual {v0, p1}, LI/L0;->l(I)Z

    .line 326
    .line 327
    .line 328
    move-result p0

    .line 329
    if-eqz p0, :cond_11

    .line 330
    .line 331
    :goto_9
    return v3

    .line 332
    :cond_11
    invoke-virtual {v0, p1}, LI/L0;->o(I)I

    .line 333
    .line 334
    .line 335
    move-result p0

    .line 336
    return p0
.end method


# virtual methods
.method public final A(Ljava/util/ArrayList;)V
    .locals 4

    .line 1
    iget-object v0, p0, LI/r;->f:LJ/a;

    .line 2
    .line 3
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 4
    .line 5
    iget-object v2, v1, LJ/b;->b:LJ/a;

    .line 6
    .line 7
    :try_start_0
    iput-object v0, v1, LJ/b;->b:LJ/a;

    .line 8
    .line 9
    iget-object v0, v0, LJ/a;->a:LJ/J;

    .line 10
    .line 11
    sget-object v3, LJ/y;->c:LJ/y;

    .line 12
    .line 13
    invoke-virtual {v0, v3}, LJ/J;->T(LJ/H;)V

    .line 14
    .line 15
    .line 16
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    const/4 v3, 0x0

    .line 21
    if-gtz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v1}, LJ/b;->b()V

    .line 24
    .line 25
    .line 26
    iget-object p1, v1, LJ/b;->b:LJ/a;

    .line 27
    .line 28
    iget-object p1, p1, LJ/a;->a:LJ/J;

    .line 29
    .line 30
    sget-object v0, LJ/m;->c:LJ/m;

    .line 31
    .line 32
    invoke-virtual {p1, v0}, LJ/J;->T(LJ/H;)V

    .line 33
    .line 34
    .line 35
    iput v3, v1, LJ/b;->f:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    .line 37
    iput-object v2, v1, LJ/b;->b:LJ/a;

    .line 38
    .line 39
    return-void

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    :try_start_1
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    check-cast p1, LJ1/g;

    .line 47
    .line 48
    iget-object v0, p1, LJ1/g;->d:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v0, LI/a0;

    .line 51
    .line 52
    iget-object p1, p1, LJ1/g;->e:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p1, LI/a0;

    .line 55
    .line 56
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    const/4 p1, 0x0

    .line 60
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 61
    :goto_0
    iput-object v2, v1, LJ/b;->b:LJ/a;

    .line 62
    .line 63
    throw p1
.end method

.method public final B(LI/q0;Ljava/lang/Object;)V
    .locals 7

    .line 1
    const v0, 0x78cc281

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {p0, v0, v1, v2, v1}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2}, LI/r;->e0(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-wide v3, p0, LI/r;->R:J

    .line 16
    .line 17
    int-to-long v5, v0

    .line 18
    :try_start_0
    iput-wide v5, p0, LI/r;->R:J

    .line 19
    .line 20
    iget-boolean p2, p0, LI/r;->Q:Z

    .line 21
    .line 22
    if-eqz p2, :cond_0

    .line 23
    .line 24
    iget-object p2, p0, LI/r;->H:LI/P0;

    .line 25
    .line 26
    invoke-static {p2}, LI/P0;->y(LI/P0;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_2

    .line 32
    :cond_0
    :goto_0
    iget-boolean p2, p0, LI/r;->Q:Z

    .line 33
    .line 34
    if-eqz p2, :cond_2

    .line 35
    .line 36
    :cond_1
    move p2, v2

    .line 37
    goto :goto_1

    .line 38
    :cond_2
    iget-object p2, p0, LI/r;->F:LI/L0;

    .line 39
    .line 40
    invoke-virtual {p2}, LI/L0;->f()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p2

    .line 44
    invoke-static {p2, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result p2

    .line 48
    if-nez p2, :cond_1

    .line 49
    .line 50
    const/4 p2, 0x1

    .line 51
    :goto_1
    if-eqz p2, :cond_3

    .line 52
    .line 53
    invoke-virtual {p0, p1}, LI/r;->I(LI/q0;)V

    .line 54
    .line 55
    .line 56
    :cond_3
    sget-object v0, LI/t;->c:LI/g0;

    .line 57
    .line 58
    const/16 v5, 0xca

    .line 59
    .line 60
    invoke-virtual {p0, v5, v0, v2, p1}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 61
    .line 62
    .line 63
    iput-object v1, p0, LI/r;->J:LI/q0;

    .line 64
    .line 65
    iput-boolean p2, p0, LI/r;->v:Z

    .line 66
    .line 67
    throw v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    :goto_2
    :try_start_1
    new-instance p2, LI/n;

    .line 69
    .line 70
    const/4 v0, 0x2

    .line 71
    invoke-direct {p2, v0, p0}, LI/n;-><init>(ILI/r;)V

    .line 72
    .line 73
    .line 74
    invoke-static {p1, p2}, LT0/g;->P(Ljava/lang/Throwable;LU1/a;)Z

    .line 75
    .line 76
    .line 77
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 78
    :catchall_1
    move-exception p1

    .line 79
    invoke-virtual {p0, v2}, LI/r;->p(Z)V

    .line 80
    .line 81
    .line 82
    iput-object v1, p0, LI/r;->J:LI/q0;

    .line 83
    .line 84
    iput-wide v3, p0, LI/r;->R:J

    .line 85
    .line 86
    invoke-virtual {p0, v2}, LI/r;->p(Z)V

    .line 87
    .line 88
    .line 89
    throw p1
.end method

.method public final C()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    sget-object v1, LI/m;->a:LI/h;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-boolean v0, p0, LI/r;->q:Z

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    .line 12
    .line 13
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_0
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 18
    .line 19
    invoke-virtual {v0}, LI/L0;->m()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-boolean v2, p0, LI/r;->x:Z

    .line 24
    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    instance-of v2, v0, LI/K0;

    .line 28
    .line 29
    if-nez v2, :cond_2

    .line 30
    .line 31
    :cond_1
    return-object v1

    .line 32
    :cond_2
    return-object v0
.end method

.method public final D()Ljava/util/List;
    .locals 6

    .line 1
    iget-object v0, p0, LI/r;->b:LI/v;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/v;->g()LI/u;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v1, LI/y;

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-nez v1, :cond_1

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_1
    iget-object v2, v1, LI/y;->i:LI/M0;

    .line 17
    .line 18
    invoke-virtual {v2}, LI/M0;->c()LI/L0;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    :try_start_0
    iget v4, v3, LI/L0;->c:I

    .line 23
    .line 24
    const/4 v5, 0x0

    .line 25
    invoke-static {v3, v0, v5, v4}, LT0/l;->v(LI/L0;LI/v;II)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 29
    invoke-virtual {v3}, LI/L0;->c()V

    .line 30
    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-virtual {v2}, LI/M0;->c()LI/L0;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    :try_start_1
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-static {v2, v0, v3}, LT0/l;->R(LI/L0;ILjava/lang/Integer;)Ljava/util/ArrayList;

    .line 47
    .line 48
    .line 49
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 50
    invoke-virtual {v2}, LI/L0;->c()V

    .line 51
    .line 52
    .line 53
    iget-object v1, v1, LI/y;->w:LI/r;

    .line 54
    .line 55
    invoke-virtual {v1}, LI/r;->D()Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-static {v0, v1}, LK1/m;->A0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    return-object v0

    .line 64
    :catchall_0
    move-exception v0

    .line 65
    invoke-virtual {v2}, LI/L0;->c()V

    .line 66
    .line 67
    .line 68
    throw v0

    .line 69
    :cond_2
    :goto_1
    sget-object v0, LK1/t;->d:LK1/t;

    .line 70
    .line 71
    return-object v0

    .line 72
    :catchall_1
    move-exception v0

    .line 73
    invoke-virtual {v3}, LI/L0;->c()V

    .line 74
    .line 75
    .line 76
    throw v0
.end method

.method public final E(I)I
    .locals 3

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    add-int/lit8 v0, v0, 0x1

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_0
    if-ge v0, p1, :cond_1

    .line 11
    .line 12
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 13
    .line 14
    invoke-virtual {v2, v0}, LI/L0;->k(I)Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-nez v2, :cond_0

    .line 19
    .line 20
    add-int/lit8 v1, v1, 0x1

    .line 21
    .line 22
    :cond_0
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 23
    .line 24
    iget-object v2, v2, LI/L0;->b:[I

    .line 25
    .line 26
    invoke-static {v2, v0}, LI/O0;->a([II)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    add-int/2addr v0, v2

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    return v1
.end method

.method public final F(LI/y;LI/y;Ljava/lang/Integer;Ljava/util/List;LU1/a;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-boolean v0, p0, LI/r;->E:Z

    .line 2
    .line 3
    iget v1, p0, LI/r;->j:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    :try_start_0
    iput-boolean v2, p0, LI/r;->E:Z

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    iput v2, p0, LI/r;->j:I

    .line 10
    .line 11
    invoke-interface {p4}, Ljava/util/Collection;->size()I

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    move v4, v2

    .line 16
    :goto_0
    const/4 v5, 0x0

    .line 17
    if-ge v4, v3, :cond_1

    .line 18
    .line 19
    invoke-interface {p4, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    check-cast v6, LJ1/g;

    .line 24
    .line 25
    iget-object v7, v6, LJ1/g;->d:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v7, LI/w0;

    .line 28
    .line 29
    iget-object v6, v6, LJ1/g;->e:Ljava/lang/Object;

    .line 30
    .line 31
    if-eqz v6, :cond_0

    .line 32
    .line 33
    invoke-virtual {p0, v7, v6}, LI/r;->Y(LI/w0;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    goto :goto_1

    .line 37
    :catchall_0
    move-exception p1

    .line 38
    goto :goto_4

    .line 39
    :cond_0
    invoke-virtual {p0, v7, v5}, LI/r;->Y(LI/w0;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    :goto_1
    add-int/lit8 v4, v4, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    if-eqz p1, :cond_4

    .line 46
    .line 47
    if-eqz p3, :cond_2

    .line 48
    .line 49
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    goto :goto_2

    .line 54
    :cond_2
    const/4 p3, -0x1

    .line 55
    :goto_2
    if-eqz p2, :cond_3

    .line 56
    .line 57
    invoke-virtual {p2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result p4

    .line 61
    if-nez p4, :cond_3

    .line 62
    .line 63
    if-ltz p3, :cond_3

    .line 64
    .line 65
    iput-object p2, p1, LI/y;->s:LI/y;

    .line 66
    .line 67
    iput p3, p1, LI/y;->t:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    .line 69
    :try_start_1
    invoke-interface {p5}, LU1/a;->a()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 73
    :try_start_2
    iput-object v5, p1, LI/y;->s:LI/y;

    .line 74
    .line 75
    iput v2, p1, LI/y;->t:I

    .line 76
    .line 77
    goto :goto_3

    .line 78
    :catchall_1
    move-exception p2

    .line 79
    iput-object v5, p1, LI/y;->s:LI/y;

    .line 80
    .line 81
    iput v2, p1, LI/y;->t:I

    .line 82
    .line 83
    throw p2

    .line 84
    :cond_3
    invoke-interface {p5}, LU1/a;->a()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object p2

    .line 88
    :goto_3
    if-nez p2, :cond_5

    .line 89
    .line 90
    :cond_4
    invoke-interface {p5}, LU1/a;->a()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 94
    :cond_5
    iput-boolean v0, p0, LI/r;->E:Z

    .line 95
    .line 96
    iput v1, p0, LI/r;->j:I

    .line 97
    .line 98
    return-object p2

    .line 99
    :goto_4
    iput-boolean v0, p0, LI/r;->E:Z

    .line 100
    .line 101
    iput v1, p0, LI/r;->j:I

    .line 102
    .line 103
    throw p1
.end method

.method public final G()V
    .locals 37

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-boolean v0, v1, LI/r;->E:Z

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    iput-boolean v2, v1, LI/r;->E:Z

    .line 7
    .line 8
    iget-object v3, v1, LI/r;->F:LI/L0;

    .line 9
    .line 10
    iget v4, v3, LI/L0;->i:I

    .line 11
    .line 12
    iget-object v5, v3, LI/L0;->b:[I

    .line 13
    .line 14
    mul-int/lit8 v6, v4, 0x5

    .line 15
    .line 16
    const/4 v7, 0x3

    .line 17
    add-int/2addr v6, v7

    .line 18
    aget v5, v5, v6

    .line 19
    .line 20
    add-int/2addr v5, v4

    .line 21
    iget v8, v1, LI/r;->j:I

    .line 22
    .line 23
    iget-wide v9, v1, LI/r;->R:J

    .line 24
    .line 25
    iget v11, v1, LI/r;->k:I

    .line 26
    .line 27
    iget v12, v1, LI/r;->l:I

    .line 28
    .line 29
    iget v3, v3, LI/L0;->g:I

    .line 30
    .line 31
    iget-object v13, v1, LI/r;->r:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-static {v3, v13}, LI/k;->m(ILjava/util/List;)I

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-gez v3, :cond_0

    .line 38
    .line 39
    add-int/lit8 v3, v3, 0x1

    .line 40
    .line 41
    neg-int v3, v3

    .line 42
    :cond_0
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 43
    .line 44
    .line 45
    move-result v14

    .line 46
    if-ge v3, v14, :cond_1

    .line 47
    .line 48
    invoke-virtual {v13, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    check-cast v3, LI/P;

    .line 53
    .line 54
    iget v14, v3, LI/P;->b:I

    .line 55
    .line 56
    if-ge v14, v5, :cond_1

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_1
    const/4 v3, 0x0

    .line 60
    :goto_0
    move/from16 v17, v7

    .line 61
    .line 62
    const/16 v16, 0x0

    .line 63
    .line 64
    move v7, v4

    .line 65
    :goto_1
    if-eqz v3, :cond_2a

    .line 66
    .line 67
    move/from16 v18, v2

    .line 68
    .line 69
    iget-object v2, v3, LI/P;->a:LI/w0;

    .line 70
    .line 71
    iget v15, v3, LI/P;->b:I

    .line 72
    .line 73
    invoke-static {v15, v13}, LI/k;->m(ILjava/util/List;)I

    .line 74
    .line 75
    .line 76
    move-result v14

    .line 77
    if-ltz v14, :cond_2

    .line 78
    .line 79
    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v14

    .line 83
    check-cast v14, LI/P;

    .line 84
    .line 85
    :cond_2
    iget-object v3, v3, LI/P;->c:Ljava/lang/Object;

    .line 86
    .line 87
    const-wide/16 v19, 0x80

    .line 88
    .line 89
    const-wide/16 v21, 0xff

    .line 90
    .line 91
    const/16 v23, 0x7

    .line 92
    .line 93
    const-wide v24, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    if-nez v3, :cond_5

    .line 99
    .line 100
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    move/from16 v27, v6

    .line 104
    .line 105
    :cond_3
    :goto_2
    move/from16 v32, v8

    .line 106
    .line 107
    move-wide/from16 v33, v9

    .line 108
    .line 109
    move/from16 v30, v11

    .line 110
    .line 111
    move/from16 v31, v12

    .line 112
    .line 113
    :cond_4
    :goto_3
    move/from16 v3, v18

    .line 114
    .line 115
    goto/16 :goto_6

    .line 116
    .line 117
    :cond_5
    const/16 v26, 0x8

    .line 118
    .line 119
    iget-object v14, v2, LI/w0;->g:Li/E;

    .line 120
    .line 121
    if-nez v14, :cond_6

    .line 122
    .line 123
    move/from16 v27, v6

    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_6
    move/from16 v27, v6

    .line 127
    .line 128
    instance-of v6, v3, LI/F;

    .line 129
    .line 130
    if-eqz v6, :cond_7

    .line 131
    .line 132
    check-cast v3, LI/F;

    .line 133
    .line 134
    invoke-static {v3, v14}, LI/w0;->a(LI/F;Li/E;)Z

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    move/from16 v32, v8

    .line 139
    .line 140
    move-wide/from16 v33, v9

    .line 141
    .line 142
    move/from16 v30, v11

    .line 143
    .line 144
    move/from16 v31, v12

    .line 145
    .line 146
    goto/16 :goto_6

    .line 147
    .line 148
    :cond_7
    instance-of v6, v3, Li/F;

    .line 149
    .line 150
    if-eqz v6, :cond_3

    .line 151
    .line 152
    check-cast v3, Li/F;

    .line 153
    .line 154
    invoke-virtual {v3}, Li/F;->h()Z

    .line 155
    .line 156
    .line 157
    move-result v6

    .line 158
    if-eqz v6, :cond_c

    .line 159
    .line 160
    iget-object v6, v3, Li/F;->b:[Ljava/lang/Object;

    .line 161
    .line 162
    iget-object v3, v3, Li/F;->a:[J

    .line 163
    .line 164
    move-object/from16 v28, v6

    .line 165
    .line 166
    array-length v6, v3

    .line 167
    add-int/lit8 v6, v6, -0x2

    .line 168
    .line 169
    if-ltz v6, :cond_c

    .line 170
    .line 171
    move-object/from16 v29, v3

    .line 172
    .line 173
    move/from16 v30, v11

    .line 174
    .line 175
    move/from16 v31, v12

    .line 176
    .line 177
    const/4 v3, 0x0

    .line 178
    :goto_4
    aget-wide v11, v29, v3

    .line 179
    .line 180
    move/from16 v32, v8

    .line 181
    .line 182
    move-wide/from16 v33, v9

    .line 183
    .line 184
    not-long v8, v11

    .line 185
    shl-long v8, v8, v23

    .line 186
    .line 187
    and-long/2addr v8, v11

    .line 188
    and-long v8, v8, v24

    .line 189
    .line 190
    cmp-long v8, v8, v24

    .line 191
    .line 192
    if-eqz v8, :cond_b

    .line 193
    .line 194
    sub-int v8, v3, v6

    .line 195
    .line 196
    not-int v8, v8

    .line 197
    ushr-int/lit8 v8, v8, 0x1f

    .line 198
    .line 199
    rsub-int/lit8 v8, v8, 0x8

    .line 200
    .line 201
    const/4 v9, 0x0

    .line 202
    :goto_5
    if-ge v9, v8, :cond_a

    .line 203
    .line 204
    and-long v35, v11, v21

    .line 205
    .line 206
    cmp-long v10, v35, v19

    .line 207
    .line 208
    if-gez v10, :cond_8

    .line 209
    .line 210
    shl-int/lit8 v10, v3, 0x3

    .line 211
    .line 212
    add-int/2addr v10, v9

    .line 213
    aget-object v10, v28, v10

    .line 214
    .line 215
    move/from16 v35, v9

    .line 216
    .line 217
    instance-of v9, v10, LI/F;

    .line 218
    .line 219
    if-eqz v9, :cond_4

    .line 220
    .line 221
    check-cast v10, LI/F;

    .line 222
    .line 223
    invoke-static {v10, v14}, LI/w0;->a(LI/F;Li/E;)Z

    .line 224
    .line 225
    .line 226
    move-result v9

    .line 227
    if-eqz v9, :cond_9

    .line 228
    .line 229
    goto :goto_3

    .line 230
    :cond_8
    move/from16 v35, v9

    .line 231
    .line 232
    :cond_9
    shr-long v11, v11, v26

    .line 233
    .line 234
    add-int/lit8 v9, v35, 0x1

    .line 235
    .line 236
    goto :goto_5

    .line 237
    :cond_a
    move/from16 v9, v26

    .line 238
    .line 239
    if-ne v8, v9, :cond_d

    .line 240
    .line 241
    :cond_b
    if-eq v3, v6, :cond_d

    .line 242
    .line 243
    add-int/lit8 v3, v3, 0x1

    .line 244
    .line 245
    move/from16 v8, v32

    .line 246
    .line 247
    move-wide/from16 v9, v33

    .line 248
    .line 249
    const/16 v26, 0x8

    .line 250
    .line 251
    goto :goto_4

    .line 252
    :cond_c
    move/from16 v32, v8

    .line 253
    .line 254
    move-wide/from16 v33, v9

    .line 255
    .line 256
    move/from16 v30, v11

    .line 257
    .line 258
    move/from16 v31, v12

    .line 259
    .line 260
    :cond_d
    const/4 v3, 0x0

    .line 261
    :goto_6
    if-eqz v3, :cond_20

    .line 262
    .line 263
    iget-object v3, v1, LI/r;->F:LI/L0;

    .line 264
    .line 265
    invoke-virtual {v3, v15}, LI/L0;->r(I)V

    .line 266
    .line 267
    .line 268
    iget-object v3, v1, LI/r;->F:LI/L0;

    .line 269
    .line 270
    iget v3, v3, LI/L0;->g:I

    .line 271
    .line 272
    invoke-virtual {v1, v7, v3, v4}, LI/r;->J(III)V

    .line 273
    .line 274
    .line 275
    iget-object v6, v1, LI/r;->F:LI/L0;

    .line 276
    .line 277
    invoke-virtual {v6, v3}, LI/L0;->q(I)I

    .line 278
    .line 279
    .line 280
    move-result v6

    .line 281
    :goto_7
    if-eq v6, v4, :cond_e

    .line 282
    .line 283
    iget-object v7, v1, LI/r;->F:LI/L0;

    .line 284
    .line 285
    invoke-virtual {v7, v6}, LI/L0;->l(I)Z

    .line 286
    .line 287
    .line 288
    move-result v7

    .line 289
    if-nez v7, :cond_e

    .line 290
    .line 291
    iget-object v7, v1, LI/r;->F:LI/L0;

    .line 292
    .line 293
    invoke-virtual {v7, v6}, LI/L0;->q(I)I

    .line 294
    .line 295
    .line 296
    move-result v6

    .line 297
    goto :goto_7

    .line 298
    :cond_e
    iget-object v7, v1, LI/r;->F:LI/L0;

    .line 299
    .line 300
    invoke-virtual {v7, v6}, LI/L0;->l(I)Z

    .line 301
    .line 302
    .line 303
    move-result v7

    .line 304
    if-eqz v7, :cond_f

    .line 305
    .line 306
    const/4 v7, 0x0

    .line 307
    goto :goto_8

    .line 308
    :cond_f
    move/from16 v7, v32

    .line 309
    .line 310
    :goto_8
    if-ne v6, v3, :cond_10

    .line 311
    .line 312
    goto :goto_b

    .line 313
    :cond_10
    invoke-virtual {v1, v6}, LI/r;->f0(I)I

    .line 314
    .line 315
    .line 316
    move-result v8

    .line 317
    iget-object v9, v1, LI/r;->F:LI/L0;

    .line 318
    .line 319
    invoke-virtual {v9, v3}, LI/L0;->o(I)I

    .line 320
    .line 321
    .line 322
    move-result v9

    .line 323
    sub-int/2addr v8, v9

    .line 324
    add-int/2addr v8, v7

    .line 325
    :cond_11
    if-ge v7, v8, :cond_13

    .line 326
    .line 327
    if-eq v6, v15, :cond_13

    .line 328
    .line 329
    add-int/lit8 v6, v6, 0x1

    .line 330
    .line 331
    :goto_9
    if-ge v6, v15, :cond_13

    .line 332
    .line 333
    iget-object v9, v1, LI/r;->F:LI/L0;

    .line 334
    .line 335
    iget-object v10, v9, LI/L0;->b:[I

    .line 336
    .line 337
    mul-int/lit8 v11, v6, 0x5

    .line 338
    .line 339
    add-int/lit8 v11, v11, 0x3

    .line 340
    .line 341
    aget v10, v10, v11

    .line 342
    .line 343
    add-int/2addr v10, v6

    .line 344
    if-lt v15, v10, :cond_11

    .line 345
    .line 346
    invoke-virtual {v9, v6}, LI/L0;->l(I)Z

    .line 347
    .line 348
    .line 349
    move-result v9

    .line 350
    if-eqz v9, :cond_12

    .line 351
    .line 352
    move/from16 v6, v18

    .line 353
    .line 354
    goto :goto_a

    .line 355
    :cond_12
    invoke-virtual {v1, v6}, LI/r;->f0(I)I

    .line 356
    .line 357
    .line 358
    move-result v6

    .line 359
    :goto_a
    add-int/2addr v7, v6

    .line 360
    move v6, v10

    .line 361
    goto :goto_9

    .line 362
    :cond_13
    :goto_b
    iput v7, v1, LI/r;->j:I

    .line 363
    .line 364
    invoke-virtual {v1, v3}, LI/r;->E(I)I

    .line 365
    .line 366
    .line 367
    move-result v6

    .line 368
    iput v6, v1, LI/r;->l:I

    .line 369
    .line 370
    iget-object v6, v1, LI/r;->F:LI/L0;

    .line 371
    .line 372
    invoke-virtual {v6, v3}, LI/L0;->q(I)I

    .line 373
    .line 374
    .line 375
    move-result v6

    .line 376
    const/4 v7, 0x0

    .line 377
    int-to-long v8, v7

    .line 378
    move/from16 v10, v17

    .line 379
    .line 380
    const/4 v7, 0x0

    .line 381
    :goto_c
    if-ltz v6, :cond_1c

    .line 382
    .line 383
    if-ne v6, v4, :cond_14

    .line 384
    .line 385
    move-wide/from16 v11, v33

    .line 386
    .line 387
    invoke-static {v11, v12, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 388
    .line 389
    .line 390
    move-result-wide v6

    .line 391
    xor-long/2addr v8, v6

    .line 392
    move/from16 v16, v3

    .line 393
    .line 394
    goto/16 :goto_11

    .line 395
    .line 396
    :cond_14
    move-wide/from16 v11, v33

    .line 397
    .line 398
    iget-object v14, v1, LI/r;->F:LI/L0;

    .line 399
    .line 400
    invoke-virtual {v14, v6}, LI/L0;->k(I)Z

    .line 401
    .line 402
    .line 403
    move-result v15

    .line 404
    move/from16 v16, v3

    .line 405
    .line 406
    iget-object v3, v14, LI/L0;->b:[I

    .line 407
    .line 408
    if-eqz v15, :cond_17

    .line 409
    .line 410
    invoke-virtual {v14, v3, v6}, LI/L0;->p([II)Ljava/lang/Object;

    .line 411
    .line 412
    .line 413
    move-result-object v3

    .line 414
    if-eqz v3, :cond_16

    .line 415
    .line 416
    instance-of v14, v3, Ljava/lang/Enum;

    .line 417
    .line 418
    if-eqz v14, :cond_15

    .line 419
    .line 420
    check-cast v3, Ljava/lang/Enum;

    .line 421
    .line 422
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 423
    .line 424
    .line 425
    move-result v3

    .line 426
    :goto_d
    move-wide/from16 v19, v8

    .line 427
    .line 428
    goto :goto_f

    .line 429
    :cond_15
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 430
    .line 431
    .line 432
    move-result v3

    .line 433
    goto :goto_d

    .line 434
    :cond_16
    move-wide/from16 v19, v8

    .line 435
    .line 436
    const/4 v3, 0x0

    .line 437
    goto :goto_f

    .line 438
    :cond_17
    invoke-virtual {v14, v6}, LI/L0;->i(I)I

    .line 439
    .line 440
    .line 441
    move-result v15

    .line 442
    move-wide/from16 v19, v8

    .line 443
    .line 444
    const/16 v8, 0xcf

    .line 445
    .line 446
    if-ne v15, v8, :cond_19

    .line 447
    .line 448
    invoke-virtual {v14, v3, v6}, LI/L0;->b([II)Ljava/lang/Object;

    .line 449
    .line 450
    .line 451
    move-result-object v3

    .line 452
    if-eqz v3, :cond_19

    .line 453
    .line 454
    sget-object v8, LI/m;->a:LI/h;

    .line 455
    .line 456
    invoke-virtual {v3, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 457
    .line 458
    .line 459
    move-result v8

    .line 460
    if-eqz v8, :cond_18

    .line 461
    .line 462
    goto :goto_e

    .line 463
    :cond_18
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 464
    .line 465
    .line 466
    move-result v3

    .line 467
    goto :goto_f

    .line 468
    :cond_19
    :goto_e
    move v3, v15

    .line 469
    :goto_f
    const v8, 0x78cc281

    .line 470
    .line 471
    .line 472
    if-ne v3, v8, :cond_1a

    .line 473
    .line 474
    int-to-long v8, v3

    .line 475
    invoke-static {v8, v9, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 476
    .line 477
    .line 478
    move-result-wide v6

    .line 479
    xor-long v8, v19, v6

    .line 480
    .line 481
    goto :goto_11

    .line 482
    :cond_1a
    iget-object v8, v1, LI/r;->F:LI/L0;

    .line 483
    .line 484
    invoke-virtual {v8, v6}, LI/L0;->k(I)Z

    .line 485
    .line 486
    .line 487
    move-result v8

    .line 488
    if-eqz v8, :cond_1b

    .line 489
    .line 490
    const/4 v8, 0x0

    .line 491
    goto :goto_10

    .line 492
    :cond_1b
    invoke-virtual {v1, v6}, LI/r;->E(I)I

    .line 493
    .line 494
    .line 495
    move-result v8

    .line 496
    :goto_10
    int-to-long v14, v3

    .line 497
    invoke-static {v14, v15, v10}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 498
    .line 499
    .line 500
    move-result-wide v14

    .line 501
    xor-long v14, v19, v14

    .line 502
    .line 503
    int-to-long v8, v8

    .line 504
    invoke-static {v8, v9, v7}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 505
    .line 506
    .line 507
    move-result-wide v8

    .line 508
    xor-long/2addr v8, v14

    .line 509
    add-int/lit8 v10, v10, 0x6

    .line 510
    .line 511
    rem-int/lit8 v10, v10, 0x40

    .line 512
    .line 513
    add-int/lit8 v7, v7, 0x6

    .line 514
    .line 515
    rem-int/lit8 v7, v7, 0x40

    .line 516
    .line 517
    iget-object v3, v1, LI/r;->F:LI/L0;

    .line 518
    .line 519
    invoke-virtual {v3, v6}, LI/L0;->q(I)I

    .line 520
    .line 521
    .line 522
    move-result v6

    .line 523
    move-wide/from16 v33, v11

    .line 524
    .line 525
    move/from16 v3, v16

    .line 526
    .line 527
    goto/16 :goto_c

    .line 528
    .line 529
    :cond_1c
    move/from16 v16, v3

    .line 530
    .line 531
    move-wide/from16 v19, v8

    .line 532
    .line 533
    move-wide/from16 v11, v33

    .line 534
    .line 535
    :goto_11
    iput-wide v8, v1, LI/r;->R:J

    .line 536
    .line 537
    const/4 v3, 0x0

    .line 538
    iput-object v3, v1, LI/r;->J:LI/q0;

    .line 539
    .line 540
    iget-object v2, v2, LI/w0;->d:LU1/e;

    .line 541
    .line 542
    if-eqz v2, :cond_1f

    .line 543
    .line 544
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 545
    .line 546
    .line 547
    move-result-object v6

    .line 548
    invoke-interface {v2, v1, v6}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 549
    .line 550
    .line 551
    iput-object v3, v1, LI/r;->J:LI/q0;

    .line 552
    .line 553
    iget-object v2, v1, LI/r;->F:LI/L0;

    .line 554
    .line 555
    iget-object v6, v2, LI/L0;->b:[I

    .line 556
    .line 557
    aget v6, v6, v27

    .line 558
    .line 559
    add-int/2addr v6, v4

    .line 560
    iget v7, v2, LI/L0;->g:I

    .line 561
    .line 562
    if-lt v7, v4, :cond_1d

    .line 563
    .line 564
    if-gt v7, v6, :cond_1d

    .line 565
    .line 566
    move/from16 v8, v18

    .line 567
    .line 568
    goto :goto_12

    .line 569
    :cond_1d
    const/4 v8, 0x0

    .line 570
    :goto_12
    if-nez v8, :cond_1e

    .line 571
    .line 572
    new-instance v8, Ljava/lang/StringBuilder;

    .line 573
    .line 574
    const-string v9, "Index "

    .line 575
    .line 576
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 580
    .line 581
    .line 582
    const-string v9, " is not a parent of "

    .line 583
    .line 584
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 585
    .line 586
    .line 587
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 588
    .line 589
    .line 590
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object v7

    .line 594
    invoke-static {v7}, LI/t;->a(Ljava/lang/String;)V

    .line 595
    .line 596
    .line 597
    :cond_1e
    iput v4, v2, LI/L0;->i:I

    .line 598
    .line 599
    iput v6, v2, LI/L0;->h:I

    .line 600
    .line 601
    const/4 v7, 0x0

    .line 602
    iput v7, v2, LI/L0;->l:I

    .line 603
    .line 604
    iput v7, v2, LI/L0;->m:I

    .line 605
    .line 606
    move/from16 v28, v4

    .line 607
    .line 608
    move/from16 v29, v5

    .line 609
    .line 610
    move v3, v7

    .line 611
    move-wide/from16 v33, v11

    .line 612
    .line 613
    move/from16 v7, v16

    .line 614
    .line 615
    move/from16 v16, v18

    .line 616
    .line 617
    goto/16 :goto_1c

    .line 618
    .line 619
    :cond_1f
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 620
    .line 621
    const-string v2, "Invalid restart scope"

    .line 622
    .line 623
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 624
    .line 625
    .line 626
    throw v0

    .line 627
    :cond_20
    move-wide/from16 v11, v33

    .line 628
    .line 629
    const/4 v3, 0x0

    .line 630
    iget-object v6, v1, LI/r;->D:Ljava/util/ArrayList;

    .line 631
    .line 632
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 633
    .line 634
    .line 635
    iget-object v8, v2, LI/w0;->a:LI/y;

    .line 636
    .line 637
    if-eqz v8, :cond_26

    .line 638
    .line 639
    iget-object v9, v2, LI/w0;->f:Li/C;

    .line 640
    .line 641
    if-eqz v9, :cond_26

    .line 642
    .line 643
    move/from16 v10, v18

    .line 644
    .line 645
    invoke-virtual {v2, v10}, LI/w0;->e(Z)V

    .line 646
    .line 647
    .line 648
    :try_start_0
    iget-object v10, v9, Li/C;->b:[Ljava/lang/Object;

    .line 649
    .line 650
    iget-object v14, v9, Li/C;->c:[I

    .line 651
    .line 652
    iget-object v9, v9, Li/C;->a:[J

    .line 653
    .line 654
    array-length v15, v9

    .line 655
    add-int/lit8 v15, v15, -0x2

    .line 656
    .line 657
    if-ltz v15, :cond_25

    .line 658
    .line 659
    move-wide/from16 v33, v11

    .line 660
    .line 661
    const/4 v3, 0x0

    .line 662
    move-object v12, v10

    .line 663
    :goto_13
    aget-wide v10, v9, v3

    .line 664
    .line 665
    move/from16 v28, v4

    .line 666
    .line 667
    move/from16 v29, v5

    .line 668
    .line 669
    not-long v4, v10

    .line 670
    shl-long v4, v4, v23

    .line 671
    .line 672
    and-long/2addr v4, v10

    .line 673
    and-long v4, v4, v24

    .line 674
    .line 675
    cmp-long v4, v4, v24

    .line 676
    .line 677
    if-eqz v4, :cond_24

    .line 678
    .line 679
    sub-int v4, v3, v15

    .line 680
    .line 681
    not-int v4, v4

    .line 682
    ushr-int/lit8 v4, v4, 0x1f

    .line 683
    .line 684
    const/16 v26, 0x8

    .line 685
    .line 686
    rsub-int/lit8 v4, v4, 0x8

    .line 687
    .line 688
    const/4 v5, 0x0

    .line 689
    :goto_14
    if-ge v5, v4, :cond_22

    .line 690
    .line 691
    and-long v35, v10, v21

    .line 692
    .line 693
    cmp-long v35, v35, v19

    .line 694
    .line 695
    if-gez v35, :cond_21

    .line 696
    .line 697
    shl-int/lit8 v35, v3, 0x3

    .line 698
    .line 699
    add-int v35, v35, v5

    .line 700
    .line 701
    move/from16 v36, v5

    .line 702
    .line 703
    aget-object v5, v12, v35

    .line 704
    .line 705
    aget v35, v14, v35

    .line 706
    .line 707
    invoke-virtual {v8, v5}, LI/y;->u(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 708
    .line 709
    .line 710
    :goto_15
    const/16 v5, 0x8

    .line 711
    .line 712
    goto :goto_16

    .line 713
    :catchall_0
    move-exception v0

    .line 714
    const/4 v3, 0x0

    .line 715
    goto :goto_1a

    .line 716
    :cond_21
    move/from16 v36, v5

    .line 717
    .line 718
    goto :goto_15

    .line 719
    :goto_16
    shr-long/2addr v10, v5

    .line 720
    add-int/lit8 v26, v36, 0x1

    .line 721
    .line 722
    move/from16 v5, v26

    .line 723
    .line 724
    goto :goto_14

    .line 725
    :cond_22
    const/16 v5, 0x8

    .line 726
    .line 727
    if-ne v4, v5, :cond_23

    .line 728
    .line 729
    goto :goto_18

    .line 730
    :cond_23
    :goto_17
    const/4 v3, 0x0

    .line 731
    goto :goto_19

    .line 732
    :cond_24
    const/16 v5, 0x8

    .line 733
    .line 734
    :goto_18
    if-eq v3, v15, :cond_23

    .line 735
    .line 736
    add-int/lit8 v3, v3, 0x1

    .line 737
    .line 738
    move/from16 v4, v28

    .line 739
    .line 740
    move/from16 v5, v29

    .line 741
    .line 742
    goto :goto_13

    .line 743
    :cond_25
    move/from16 v28, v4

    .line 744
    .line 745
    move/from16 v29, v5

    .line 746
    .line 747
    move-wide/from16 v33, v11

    .line 748
    .line 749
    goto :goto_17

    .line 750
    :goto_19
    invoke-virtual {v2, v3}, LI/w0;->e(Z)V

    .line 751
    .line 752
    .line 753
    goto :goto_1b

    .line 754
    :goto_1a
    invoke-virtual {v2, v3}, LI/w0;->e(Z)V

    .line 755
    .line 756
    .line 757
    throw v0

    .line 758
    :cond_26
    move/from16 v28, v4

    .line 759
    .line 760
    move/from16 v29, v5

    .line 761
    .line 762
    move-wide/from16 v33, v11

    .line 763
    .line 764
    const/4 v3, 0x0

    .line 765
    :goto_1b
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 766
    .line 767
    .line 768
    move-result v2

    .line 769
    const/16 v18, 0x1

    .line 770
    .line 771
    add-int/lit8 v2, v2, -0x1

    .line 772
    .line 773
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 774
    .line 775
    .line 776
    :goto_1c
    iget-object v2, v1, LI/r;->F:LI/L0;

    .line 777
    .line 778
    iget v2, v2, LI/L0;->g:I

    .line 779
    .line 780
    invoke-static {v2, v13}, LI/k;->m(ILjava/util/List;)I

    .line 781
    .line 782
    .line 783
    move-result v2

    .line 784
    if-gez v2, :cond_27

    .line 785
    .line 786
    add-int/lit8 v2, v2, 0x1

    .line 787
    .line 788
    neg-int v2, v2

    .line 789
    :cond_27
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 790
    .line 791
    .line 792
    move-result v4

    .line 793
    if-ge v2, v4, :cond_28

    .line 794
    .line 795
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 796
    .line 797
    .line 798
    move-result-object v2

    .line 799
    check-cast v2, LI/P;

    .line 800
    .line 801
    iget v4, v2, LI/P;->b:I

    .line 802
    .line 803
    move/from16 v5, v29

    .line 804
    .line 805
    if-ge v4, v5, :cond_29

    .line 806
    .line 807
    goto :goto_1d

    .line 808
    :cond_28
    move/from16 v5, v29

    .line 809
    .line 810
    :cond_29
    const/4 v2, 0x0

    .line 811
    :goto_1d
    move-object v3, v2

    .line 812
    move/from16 v2, v18

    .line 813
    .line 814
    move/from16 v6, v27

    .line 815
    .line 816
    move/from16 v4, v28

    .line 817
    .line 818
    move/from16 v11, v30

    .line 819
    .line 820
    move/from16 v12, v31

    .line 821
    .line 822
    move/from16 v8, v32

    .line 823
    .line 824
    move-wide/from16 v9, v33

    .line 825
    .line 826
    goto/16 :goto_1

    .line 827
    .line 828
    :cond_2a
    move/from16 v28, v4

    .line 829
    .line 830
    move/from16 v32, v8

    .line 831
    .line 832
    move-wide/from16 v33, v9

    .line 833
    .line 834
    move/from16 v30, v11

    .line 835
    .line 836
    move/from16 v31, v12

    .line 837
    .line 838
    if-eqz v16, :cond_2b

    .line 839
    .line 840
    move/from16 v2, v28

    .line 841
    .line 842
    invoke-virtual {v1, v7, v2, v2}, LI/r;->J(III)V

    .line 843
    .line 844
    .line 845
    iget-object v3, v1, LI/r;->F:LI/L0;

    .line 846
    .line 847
    invoke-virtual {v3}, LI/L0;->t()V

    .line 848
    .line 849
    .line 850
    invoke-virtual {v1, v2}, LI/r;->f0(I)I

    .line 851
    .line 852
    .line 853
    move-result v2

    .line 854
    add-int v8, v32, v2

    .line 855
    .line 856
    iput v8, v1, LI/r;->j:I

    .line 857
    .line 858
    add-int v11, v30, v2

    .line 859
    .line 860
    iput v11, v1, LI/r;->k:I

    .line 861
    .line 862
    move/from16 v2, v31

    .line 863
    .line 864
    iput v2, v1, LI/r;->l:I

    .line 865
    .line 866
    :goto_1e
    move-wide/from16 v11, v33

    .line 867
    .line 868
    goto :goto_1f

    .line 869
    :cond_2b
    invoke-virtual {v1}, LI/r;->P()V

    .line 870
    .line 871
    .line 872
    goto :goto_1e

    .line 873
    :goto_1f
    iput-wide v11, v1, LI/r;->R:J

    .line 874
    .line 875
    iput-boolean v0, v1, LI/r;->E:Z

    .line 876
    .line 877
    return-void
.end method

.method public final H()V
    .locals 9

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    iget v0, v0, LI/L0;->g:I

    .line 4
    .line 5
    invoke-virtual {p0, v0}, LI/r;->L(I)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LI/r;->L:LJ/b;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v0, v1}, LJ/b;->d(Z)V

    .line 12
    .line 13
    .line 14
    iget-object v2, v0, LJ/b;->d:LI/O;

    .line 15
    .line 16
    iget-object v3, v0, LJ/b;->a:LI/r;

    .line 17
    .line 18
    iget-object v4, v3, LI/r;->F:LI/L0;

    .line 19
    .line 20
    iget v5, v4, LI/L0;->c:I

    .line 21
    .line 22
    if-lez v5, :cond_1

    .line 23
    .line 24
    iget v5, v4, LI/L0;->i:I

    .line 25
    .line 26
    const/4 v6, -0x2

    .line 27
    invoke-virtual {v2, v6}, LI/O;->a(I)I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    if-eq v6, v5, :cond_1

    .line 32
    .line 33
    iget-boolean v6, v0, LJ/b;->c:Z

    .line 34
    .line 35
    const/4 v7, 0x1

    .line 36
    if-nez v6, :cond_0

    .line 37
    .line 38
    iget-boolean v6, v0, LJ/b;->e:Z

    .line 39
    .line 40
    if-eqz v6, :cond_0

    .line 41
    .line 42
    invoke-virtual {v0, v1}, LJ/b;->d(Z)V

    .line 43
    .line 44
    .line 45
    iget-object v6, v0, LJ/b;->b:LJ/a;

    .line 46
    .line 47
    iget-object v6, v6, LJ/a;->a:LJ/J;

    .line 48
    .line 49
    sget-object v8, LJ/p;->c:LJ/p;

    .line 50
    .line 51
    invoke-virtual {v6, v8}, LJ/J;->T(LJ/H;)V

    .line 52
    .line 53
    .line 54
    iput-boolean v7, v0, LJ/b;->c:Z

    .line 55
    .line 56
    :cond_0
    if-lez v5, :cond_1

    .line 57
    .line 58
    invoke-virtual {v4, v5}, LI/L0;->a(I)LI/a;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    invoke-virtual {v2, v5}, LI/O;->c(I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0, v1}, LJ/b;->d(Z)V

    .line 66
    .line 67
    .line 68
    iget-object v2, v0, LJ/b;->b:LJ/a;

    .line 69
    .line 70
    iget-object v2, v2, LJ/a;->a:LJ/J;

    .line 71
    .line 72
    sget-object v5, LJ/o;->c:LJ/o;

    .line 73
    .line 74
    invoke-virtual {v2, v5}, LJ/J;->T(LJ/H;)V

    .line 75
    .line 76
    .line 77
    invoke-static {v2, v1, v4}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    iput-boolean v7, v0, LJ/b;->c:Z

    .line 81
    .line 82
    :cond_1
    iget-object v1, v0, LJ/b;->b:LJ/a;

    .line 83
    .line 84
    iget-object v1, v1, LJ/a;->a:LJ/J;

    .line 85
    .line 86
    sget-object v2, LJ/w;->c:LJ/w;

    .line 87
    .line 88
    invoke-virtual {v1, v2}, LJ/J;->T(LJ/H;)V

    .line 89
    .line 90
    .line 91
    iget v1, v0, LJ/b;->f:I

    .line 92
    .line 93
    iget-object v2, v3, LI/r;->F:LI/L0;

    .line 94
    .line 95
    iget-object v3, v2, LI/L0;->b:[I

    .line 96
    .line 97
    iget v2, v2, LI/L0;->g:I

    .line 98
    .line 99
    mul-int/lit8 v2, v2, 0x5

    .line 100
    .line 101
    add-int/lit8 v2, v2, 0x3

    .line 102
    .line 103
    aget v2, v3, v2

    .line 104
    .line 105
    add-int/2addr v2, v1

    .line 106
    iput v2, v0, LJ/b;->f:I

    .line 107
    .line 108
    return-void
.end method

.method public final I(LI/q0;)V
    .locals 2

    .line 1
    iget-object v0, p0, LI/r;->u:Li/x;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Li/x;

    .line 6
    .line 7
    invoke-direct {v0}, Li/x;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, LI/r;->u:Li/x;

    .line 11
    .line 12
    :cond_0
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 13
    .line 14
    iget v1, v1, LI/L0;->g:I

    .line 15
    .line 16
    invoke-virtual {v0, v1, p1}, Li/x;->h(ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final J(III)V
    .locals 6

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    if-ne p1, p2, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    if-eq p1, p3, :cond_9

    .line 7
    .line 8
    if-ne p2, p3, :cond_1

    .line 9
    .line 10
    goto/16 :goto_6

    .line 11
    .line 12
    :cond_1
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-ne v1, p2, :cond_2

    .line 17
    .line 18
    move p3, p2

    .line 19
    goto/16 :goto_6

    .line 20
    .line 21
    :cond_2
    invoke-virtual {v0, p2}, LI/L0;->q(I)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-ne v1, p1, :cond_3

    .line 26
    .line 27
    :goto_0
    move p3, p1

    .line 28
    goto :goto_6

    .line 29
    :cond_3
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-virtual {v0, p2}, LI/L0;->q(I)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-ne v1, v2, :cond_4

    .line 38
    .line 39
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 40
    .line 41
    .line 42
    move-result p3

    .line 43
    goto :goto_6

    .line 44
    :cond_4
    const/4 v1, 0x0

    .line 45
    move v2, p1

    .line 46
    move v3, v1

    .line 47
    :goto_1
    if-lez v2, :cond_5

    .line 48
    .line 49
    if-eq v2, p3, :cond_5

    .line 50
    .line 51
    invoke-virtual {v0, v2}, LI/L0;->q(I)I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    add-int/lit8 v3, v3, 0x1

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_5
    move v2, p2

    .line 59
    move v4, v1

    .line 60
    :goto_2
    if-lez v2, :cond_6

    .line 61
    .line 62
    if-eq v2, p3, :cond_6

    .line 63
    .line 64
    invoke-virtual {v0, v2}, LI/L0;->q(I)I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    add-int/lit8 v4, v4, 0x1

    .line 69
    .line 70
    goto :goto_2

    .line 71
    :cond_6
    sub-int p3, v3, v4

    .line 72
    .line 73
    move v5, p1

    .line 74
    move v2, v1

    .line 75
    :goto_3
    if-ge v2, p3, :cond_7

    .line 76
    .line 77
    invoke-virtual {v0, v5}, LI/L0;->q(I)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    add-int/lit8 v2, v2, 0x1

    .line 82
    .line 83
    goto :goto_3

    .line 84
    :cond_7
    sub-int/2addr v4, v3

    .line 85
    move p3, p2

    .line 86
    :goto_4
    if-ge v1, v4, :cond_8

    .line 87
    .line 88
    invoke-virtual {v0, p3}, LI/L0;->q(I)I

    .line 89
    .line 90
    .line 91
    move-result p3

    .line 92
    add-int/lit8 v1, v1, 0x1

    .line 93
    .line 94
    goto :goto_4

    .line 95
    :cond_8
    move v1, p3

    .line 96
    move p3, v5

    .line 97
    :goto_5
    if-eq p3, v1, :cond_9

    .line 98
    .line 99
    invoke-virtual {v0, p3}, LI/L0;->q(I)I

    .line 100
    .line 101
    .line 102
    move-result p3

    .line 103
    invoke-virtual {v0, v1}, LI/L0;->q(I)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    goto :goto_5

    .line 108
    :cond_9
    :goto_6
    if-lez p1, :cond_b

    .line 109
    .line 110
    if-eq p1, p3, :cond_b

    .line 111
    .line 112
    invoke-virtual {v0, p1}, LI/L0;->l(I)Z

    .line 113
    .line 114
    .line 115
    move-result v1

    .line 116
    if-eqz v1, :cond_a

    .line 117
    .line 118
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 119
    .line 120
    invoke-virtual {v1}, LJ/b;->a()V

    .line 121
    .line 122
    .line 123
    :cond_a
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 124
    .line 125
    .line 126
    move-result p1

    .line 127
    goto :goto_6

    .line 128
    :cond_b
    invoke-virtual {p0, p2, p3}, LI/r;->o(II)V

    .line 129
    .line 130
    .line 131
    return-void
.end method

.method public final K()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    sget-object v1, LI/m;->a:LI/h;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-boolean v0, p0, LI/r;->q:Z

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    .line 12
    .line 13
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_0
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 18
    .line 19
    invoke-virtual {v0}, LI/L0;->m()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-boolean v2, p0, LI/r;->x:Z

    .line 24
    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    instance-of v2, v0, LI/K0;

    .line 28
    .line 29
    if-nez v2, :cond_2

    .line 30
    .line 31
    :cond_1
    return-object v1

    .line 32
    :cond_2
    instance-of v1, v0, LI/H0;

    .line 33
    .line 34
    if-eqz v1, :cond_3

    .line 35
    .line 36
    check-cast v0, LI/H0;

    .line 37
    .line 38
    iget-object v0, v0, LI/H0;->a:LI/G0;

    .line 39
    .line 40
    :cond_3
    return-object v0
.end method

.method public final L(I)V
    .locals 4

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LI/L0;->l(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1}, LJ/b;->c()V

    .line 12
    .line 13
    .line 14
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 15
    .line 16
    invoke-virtual {v2, p1}, LI/L0;->n(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v1}, LJ/b;->c()V

    .line 21
    .line 22
    .line 23
    iget-object v3, v1, LJ/b;->h:Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    :cond_0
    const/4 v2, 0x0

    .line 29
    invoke-static {p0, p1, v0, v2}, LI/r;->M(LI/r;IZI)I

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, LJ/b;->c()V

    .line 33
    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    invoke-virtual {v1}, LJ/b;->a()V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
.end method

.method public final N(IZ)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    and-int/2addr p1, v0

    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    iget-boolean p1, p0, LI/r;->Q:Z

    .line 6
    .line 7
    if-nez p1, :cond_2

    .line 8
    .line 9
    iget-boolean p1, p0, LI/r;->x:Z

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    if-nez p2, :cond_2

    .line 15
    .line 16
    invoke-virtual {p0}, LI/r;->z()Z

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    if-nez p1, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    const/4 p1, 0x0

    .line 24
    return p1

    .line 25
    :cond_2
    :goto_0
    return v0
.end method

.method public final O()V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LI/r;->r:Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    iget v1, v0, LI/r;->k:I

    .line 12
    .line 13
    iget-object v2, v0, LI/r;->F:LI/L0;

    .line 14
    .line 15
    invoke-virtual {v2}, LI/L0;->s()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    add-int/2addr v2, v1

    .line 20
    iput v2, v0, LI/r;->k:I

    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    iget-object v1, v0, LI/r;->F:LI/L0;

    .line 24
    .line 25
    invoke-virtual {v1}, LI/L0;->g()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    iget-object v3, v1, LI/L0;->b:[I

    .line 30
    .line 31
    iget v4, v1, LI/L0;->g:I

    .line 32
    .line 33
    iget v5, v1, LI/L0;->h:I

    .line 34
    .line 35
    const/4 v6, 0x0

    .line 36
    if-ge v4, v5, :cond_1

    .line 37
    .line 38
    invoke-virtual {v1, v3, v4}, LI/L0;->p([II)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    move-object v4, v6

    .line 44
    :goto_0
    invoke-virtual {v1}, LI/L0;->f()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    iget v7, v0, LI/r;->l:I

    .line 49
    .line 50
    sget-object v8, LI/m;->a:LI/h;

    .line 51
    .line 52
    const/16 v9, 0xcf

    .line 53
    .line 54
    const/4 v11, 0x3

    .line 55
    if-nez v4, :cond_3

    .line 56
    .line 57
    if-eqz v5, :cond_2

    .line 58
    .line 59
    if-ne v2, v9, :cond_2

    .line 60
    .line 61
    invoke-virtual {v5, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v12

    .line 65
    if-nez v12, :cond_2

    .line 66
    .line 67
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    .line 68
    .line 69
    .line 70
    move-result v12

    .line 71
    iget-wide v13, v0, LI/r;->R:J

    .line 72
    .line 73
    invoke-static {v13, v14, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 74
    .line 75
    .line 76
    move-result-wide v13

    .line 77
    int-to-long v9, v12

    .line 78
    xor-long/2addr v9, v13

    .line 79
    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 80
    .line 81
    .line 82
    move-result-wide v9

    .line 83
    int-to-long v12, v7

    .line 84
    xor-long/2addr v9, v12

    .line 85
    iput-wide v9, v0, LI/r;->R:J

    .line 86
    .line 87
    goto :goto_3

    .line 88
    :cond_2
    iget-wide v9, v0, LI/r;->R:J

    .line 89
    .line 90
    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 91
    .line 92
    .line 93
    move-result-wide v9

    .line 94
    int-to-long v12, v2

    .line 95
    xor-long/2addr v9, v12

    .line 96
    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 97
    .line 98
    .line 99
    move-result-wide v9

    .line 100
    int-to-long v12, v7

    .line 101
    xor-long/2addr v9, v12

    .line 102
    :goto_1
    iput-wide v9, v0, LI/r;->R:J

    .line 103
    .line 104
    goto :goto_3

    .line 105
    :cond_3
    instance-of v9, v4, Ljava/lang/Enum;

    .line 106
    .line 107
    if-eqz v9, :cond_4

    .line 108
    .line 109
    move-object v9, v4

    .line 110
    check-cast v9, Ljava/lang/Enum;

    .line 111
    .line 112
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 113
    .line 114
    .line 115
    move-result v9

    .line 116
    iget-wide v12, v0, LI/r;->R:J

    .line 117
    .line 118
    invoke-static {v12, v13, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 119
    .line 120
    .line 121
    move-result-wide v12

    .line 122
    int-to-long v9, v9

    .line 123
    xor-long/2addr v9, v12

    .line 124
    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 125
    .line 126
    .line 127
    move-result-wide v9

    .line 128
    const/4 v12, 0x0

    .line 129
    :goto_2
    int-to-long v13, v12

    .line 130
    xor-long/2addr v9, v13

    .line 131
    goto :goto_1

    .line 132
    :cond_4
    const/4 v12, 0x0

    .line 133
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 134
    .line 135
    .line 136
    move-result v9

    .line 137
    iget-wide v13, v0, LI/r;->R:J

    .line 138
    .line 139
    invoke-static {v13, v14, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 140
    .line 141
    .line 142
    move-result-wide v13

    .line 143
    int-to-long v9, v9

    .line 144
    xor-long/2addr v9, v13

    .line 145
    invoke-static {v9, v10, v11}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 146
    .line 147
    .line 148
    move-result-wide v9

    .line 149
    goto :goto_2

    .line 150
    :goto_3
    iget v9, v1, LI/L0;->g:I

    .line 151
    .line 152
    mul-int/lit8 v9, v9, 0x5

    .line 153
    .line 154
    const/4 v12, 0x1

    .line 155
    add-int/2addr v9, v12

    .line 156
    aget v3, v3, v9

    .line 157
    .line 158
    const/high16 v9, 0x40000000    # 2.0f

    .line 159
    .line 160
    and-int/2addr v3, v9

    .line 161
    if-eqz v3, :cond_5

    .line 162
    .line 163
    goto :goto_4

    .line 164
    :cond_5
    const/4 v12, 0x0

    .line 165
    :goto_4
    invoke-virtual {v0, v6, v12}, LI/r;->T(Ljava/lang/Object;Z)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v0}, LI/r;->G()V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v1}, LI/L0;->e()V

    .line 172
    .line 173
    .line 174
    if-nez v4, :cond_7

    .line 175
    .line 176
    if-eqz v5, :cond_6

    .line 177
    .line 178
    const/16 v15, 0xcf

    .line 179
    .line 180
    if-ne v2, v15, :cond_6

    .line 181
    .line 182
    invoke-virtual {v5, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    move-result v1

    .line 186
    if-nez v1, :cond_6

    .line 187
    .line 188
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    .line 189
    .line 190
    .line 191
    move-result v1

    .line 192
    iget-wide v2, v0, LI/r;->R:J

    .line 193
    .line 194
    int-to-long v4, v7

    .line 195
    xor-long/2addr v2, v4

    .line 196
    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 197
    .line 198
    .line 199
    move-result-wide v2

    .line 200
    int-to-long v4, v1

    .line 201
    xor-long v1, v2, v4

    .line 202
    .line 203
    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 204
    .line 205
    .line 206
    move-result-wide v1

    .line 207
    iput-wide v1, v0, LI/r;->R:J

    .line 208
    .line 209
    return-void

    .line 210
    :cond_6
    iget-wide v3, v0, LI/r;->R:J

    .line 211
    .line 212
    int-to-long v5, v7

    .line 213
    xor-long/2addr v3, v5

    .line 214
    invoke-static {v3, v4, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 215
    .line 216
    .line 217
    move-result-wide v3

    .line 218
    int-to-long v1, v2

    .line 219
    xor-long/2addr v1, v3

    .line 220
    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 221
    .line 222
    .line 223
    move-result-wide v1

    .line 224
    iput-wide v1, v0, LI/r;->R:J

    .line 225
    .line 226
    return-void

    .line 227
    :cond_7
    instance-of v1, v4, Ljava/lang/Enum;

    .line 228
    .line 229
    if-eqz v1, :cond_8

    .line 230
    .line 231
    check-cast v4, Ljava/lang/Enum;

    .line 232
    .line 233
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    iget-wide v2, v0, LI/r;->R:J

    .line 238
    .line 239
    const/4 v12, 0x0

    .line 240
    int-to-long v4, v12

    .line 241
    xor-long/2addr v2, v4

    .line 242
    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 243
    .line 244
    .line 245
    move-result-wide v2

    .line 246
    int-to-long v4, v1

    .line 247
    xor-long v1, v2, v4

    .line 248
    .line 249
    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 250
    .line 251
    .line 252
    move-result-wide v1

    .line 253
    iput-wide v1, v0, LI/r;->R:J

    .line 254
    .line 255
    return-void

    .line 256
    :cond_8
    const/4 v12, 0x0

    .line 257
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 258
    .line 259
    .line 260
    move-result v1

    .line 261
    iget-wide v2, v0, LI/r;->R:J

    .line 262
    .line 263
    int-to-long v4, v12

    .line 264
    xor-long/2addr v2, v4

    .line 265
    invoke-static {v2, v3, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 266
    .line 267
    .line 268
    move-result-wide v2

    .line 269
    int-to-long v4, v1

    .line 270
    xor-long v1, v2, v4

    .line 271
    .line 272
    invoke-static {v1, v2, v11}, Ljava/lang/Long;->rotateRight(JI)J

    .line 273
    .line 274
    .line 275
    move-result-wide v1

    .line 276
    iput-wide v1, v0, LI/r;->R:J

    .line 277
    .line 278
    return-void
.end method

.method public final P()V
    .locals 3

    .line 1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 2
    .line 3
    iget v1, v0, LI/L0;->i:I

    .line 4
    .line 5
    if-ltz v1, :cond_0

    .line 6
    .line 7
    iget-object v2, v0, LI/L0;->b:[I

    .line 8
    .line 9
    mul-int/lit8 v1, v1, 0x5

    .line 10
    .line 11
    add-int/lit8 v1, v1, 0x1

    .line 12
    .line 13
    aget v1, v2, v1

    .line 14
    .line 15
    const v2, 0x3ffffff

    .line 16
    .line 17
    .line 18
    and-int/2addr v1, v2

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    iput v1, p0, LI/r;->k:I

    .line 22
    .line 23
    invoke-virtual {v0}, LI/L0;->t()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final Q()V
    .locals 3

    .line 1
    iget v0, p0, LI/r;->k:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const-string v0, "No nodes can be emitted before calling skipAndEndGroup"

    .line 7
    .line 8
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :goto_0
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 12
    .line 13
    if-nez v0, :cond_4

    .line 14
    .line 15
    invoke-virtual {p0}, LI/r;->w()LI/w0;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    iget v1, v0, LI/w0;->b:I

    .line 22
    .line 23
    and-int/lit16 v2, v1, 0x80

    .line 24
    .line 25
    if-eqz v2, :cond_1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1
    or-int/lit8 v1, v1, 0x10

    .line 29
    .line 30
    iput v1, v0, LI/w0;->b:I

    .line 31
    .line 32
    :cond_2
    :goto_1
    iget-object v0, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    invoke-virtual {p0}, LI/r;->P()V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_3
    invoke-virtual {p0}, LI/r;->G()V

    .line 45
    .line 46
    .line 47
    :cond_4
    return-void
.end method

.method public final R(ILjava/lang/Object;ILI/q0;)V
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    move-object/from16 v4, p4

    .line 10
    .line 11
    const/4 v5, -0x1

    .line 12
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    iget-boolean v7, v0, LI/r;->q:Z

    .line 17
    .line 18
    if-eqz v7, :cond_0

    .line 19
    .line 20
    const-string v7, "A call to createNode(), emitNode() or useNode() expected"

    .line 21
    .line 22
    invoke-static {v7}, LI/t;->a(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    iget v7, v0, LI/r;->l:I

    .line 26
    .line 27
    sget-object v8, LI/m;->a:LI/h;

    .line 28
    .line 29
    const/4 v9, 0x3

    .line 30
    const/4 v10, 0x0

    .line 31
    if-nez v2, :cond_2

    .line 32
    .line 33
    if-eqz v4, :cond_1

    .line 34
    .line 35
    const/16 v11, 0xcf

    .line 36
    .line 37
    if-ne v1, v11, :cond_1

    .line 38
    .line 39
    invoke-virtual {v4, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v11

    .line 43
    if-nez v11, :cond_1

    .line 44
    .line 45
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 46
    .line 47
    .line 48
    move-result v11

    .line 49
    iget-wide v12, v0, LI/r;->R:J

    .line 50
    .line 51
    invoke-static {v12, v13, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 52
    .line 53
    .line 54
    move-result-wide v12

    .line 55
    int-to-long v14, v11

    .line 56
    xor-long v11, v12, v14

    .line 57
    .line 58
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 59
    .line 60
    .line 61
    move-result-wide v11

    .line 62
    int-to-long v13, v7

    .line 63
    xor-long/2addr v11, v13

    .line 64
    iput-wide v11, v0, LI/r;->R:J

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_1
    iget-wide v11, v0, LI/r;->R:J

    .line 68
    .line 69
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 70
    .line 71
    .line 72
    move-result-wide v11

    .line 73
    int-to-long v13, v1

    .line 74
    xor-long/2addr v11, v13

    .line 75
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 76
    .line 77
    .line 78
    move-result-wide v11

    .line 79
    int-to-long v13, v7

    .line 80
    :goto_0
    xor-long/2addr v11, v13

    .line 81
    iput-wide v11, v0, LI/r;->R:J

    .line 82
    .line 83
    goto :goto_2

    .line 84
    :cond_2
    instance-of v7, v2, Ljava/lang/Enum;

    .line 85
    .line 86
    if-eqz v7, :cond_3

    .line 87
    .line 88
    move-object v7, v2

    .line 89
    check-cast v7, Ljava/lang/Enum;

    .line 90
    .line 91
    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    .line 92
    .line 93
    .line 94
    move-result v7

    .line 95
    :goto_1
    iget-wide v11, v0, LI/r;->R:J

    .line 96
    .line 97
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 98
    .line 99
    .line 100
    move-result-wide v11

    .line 101
    int-to-long v13, v7

    .line 102
    xor-long/2addr v11, v13

    .line 103
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 104
    .line 105
    .line 106
    move-result-wide v11

    .line 107
    int-to-long v13, v10

    .line 108
    goto :goto_0

    .line 109
    :cond_3
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 110
    .line 111
    .line 112
    move-result v7

    .line 113
    goto :goto_1

    .line 114
    :goto_2
    const/4 v7, 0x1

    .line 115
    if-nez v2, :cond_4

    .line 116
    .line 117
    iget v9, v0, LI/r;->l:I

    .line 118
    .line 119
    add-int/2addr v9, v7

    .line 120
    iput v9, v0, LI/r;->l:I

    .line 121
    .line 122
    :cond_4
    if-eqz v3, :cond_5

    .line 123
    .line 124
    move v9, v7

    .line 125
    goto :goto_3

    .line 126
    :cond_5
    move v9, v10

    .line 127
    :goto_3
    iget-boolean v11, v0, LI/r;->Q:Z

    .line 128
    .line 129
    const/4 v12, -0x2

    .line 130
    const/4 v13, 0x0

    .line 131
    if-eqz v11, :cond_b

    .line 132
    .line 133
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 134
    .line 135
    iget v11, v3, LI/L0;->k:I

    .line 136
    .line 137
    add-int/2addr v11, v7

    .line 138
    iput v11, v3, LI/L0;->k:I

    .line 139
    .line 140
    iget-object v3, v0, LI/r;->H:LI/P0;

    .line 141
    .line 142
    iget v11, v3, LI/P0;->t:I

    .line 143
    .line 144
    if-eqz v9, :cond_6

    .line 145
    .line 146
    invoke-virtual {v3, v1, v8, v7, v8}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    goto :goto_4

    .line 150
    :cond_6
    if-eqz v4, :cond_8

    .line 151
    .line 152
    if-nez v2, :cond_7

    .line 153
    .line 154
    move-object v2, v8

    .line 155
    :cond_7
    invoke-virtual {v3, v1, v2, v10, v4}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_4

    .line 159
    :cond_8
    if-nez v2, :cond_9

    .line 160
    .line 161
    move-object v2, v8

    .line 162
    :cond_9
    invoke-virtual {v3, v1, v2, v10, v8}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    :goto_4
    iget-object v2, v0, LI/r;->i:LI/p0;

    .line 166
    .line 167
    if-eqz v2, :cond_a

    .line 168
    .line 169
    new-instance v3, LI/T;

    .line 170
    .line 171
    sub-int/2addr v12, v11

    .line 172
    invoke-direct {v3, v6, v1, v12, v5}, LI/T;-><init>(Ljava/lang/Object;III)V

    .line 173
    .line 174
    .line 175
    iget v1, v0, LI/r;->j:I

    .line 176
    .line 177
    iget v4, v2, LI/p0;->b:I

    .line 178
    .line 179
    sub-int/2addr v1, v4

    .line 180
    iget-object v4, v2, LI/p0;->e:Li/x;

    .line 181
    .line 182
    new-instance v6, LI/L;

    .line 183
    .line 184
    invoke-direct {v6, v5, v1, v10}, LI/L;-><init>(III)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v4, v12, v6}, Li/x;->h(ILjava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    iget-object v1, v2, LI/p0;->d:Ljava/util/ArrayList;

    .line 191
    .line 192
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    :cond_a
    invoke-virtual {v0, v9, v13}, LI/r;->t(ZLI/p0;)V

    .line 196
    .line 197
    .line 198
    return-void

    .line 199
    :cond_b
    if-eq v3, v7, :cond_c

    .line 200
    .line 201
    goto :goto_5

    .line 202
    :cond_c
    iget-boolean v3, v0, LI/r;->x:Z

    .line 203
    .line 204
    if-eqz v3, :cond_d

    .line 205
    .line 206
    move v3, v7

    .line 207
    goto :goto_6

    .line 208
    :cond_d
    :goto_5
    move v3, v10

    .line 209
    :goto_6
    iget-object v11, v0, LI/r;->i:LI/p0;

    .line 210
    .line 211
    if-nez v11, :cond_f

    .line 212
    .line 213
    iget-object v11, v0, LI/r;->F:LI/L0;

    .line 214
    .line 215
    invoke-virtual {v11}, LI/L0;->g()I

    .line 216
    .line 217
    .line 218
    move-result v11

    .line 219
    if-nez v3, :cond_10

    .line 220
    .line 221
    if-ne v11, v1, :cond_10

    .line 222
    .line 223
    iget-object v11, v0, LI/r;->F:LI/L0;

    .line 224
    .line 225
    iget v14, v11, LI/L0;->g:I

    .line 226
    .line 227
    iget v15, v11, LI/L0;->h:I

    .line 228
    .line 229
    if-ge v14, v15, :cond_e

    .line 230
    .line 231
    iget-object v15, v11, LI/L0;->b:[I

    .line 232
    .line 233
    invoke-virtual {v11, v15, v14}, LI/L0;->p([II)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v11

    .line 237
    goto :goto_7

    .line 238
    :cond_e
    move-object v11, v13

    .line 239
    :goto_7
    invoke-static {v2, v11}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    move-result v11

    .line 243
    if-eqz v11, :cond_10

    .line 244
    .line 245
    invoke-virtual {v0, v4, v9}, LI/r;->T(Ljava/lang/Object;Z)V

    .line 246
    .line 247
    .line 248
    :cond_f
    move/from16 p3, v3

    .line 249
    .line 250
    goto :goto_b

    .line 251
    :cond_10
    new-instance v11, LI/p0;

    .line 252
    .line 253
    iget-object v14, v0, LI/r;->F:LI/L0;

    .line 254
    .line 255
    iget-object v15, v14, LI/L0;->b:[I

    .line 256
    .line 257
    new-instance v5, Ljava/util/ArrayList;

    .line 258
    .line 259
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 260
    .line 261
    .line 262
    iget v13, v14, LI/L0;->k:I

    .line 263
    .line 264
    if-lez v13, :cond_12

    .line 265
    .line 266
    :cond_11
    move/from16 p3, v3

    .line 267
    .line 268
    goto :goto_a

    .line 269
    :cond_12
    iget v13, v14, LI/L0;->g:I

    .line 270
    .line 271
    :goto_8
    iget v12, v14, LI/L0;->h:I

    .line 272
    .line 273
    if-ge v13, v12, :cond_11

    .line 274
    .line 275
    new-instance v12, LI/T;

    .line 276
    .line 277
    mul-int/lit8 v18, v13, 0x5

    .line 278
    .line 279
    aget v7, v15, v18

    .line 280
    .line 281
    invoke-virtual {v14, v15, v13}, LI/L0;->p([II)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v10

    .line 285
    add-int/lit8 v20, v18, 0x1

    .line 286
    .line 287
    aget v20, v15, v20

    .line 288
    .line 289
    const/high16 v21, 0x40000000    # 2.0f

    .line 290
    .line 291
    and-int v21, v20, v21

    .line 292
    .line 293
    if-eqz v21, :cond_13

    .line 294
    .line 295
    move/from16 p3, v3

    .line 296
    .line 297
    const/4 v3, 0x1

    .line 298
    goto :goto_9

    .line 299
    :cond_13
    const v21, 0x3ffffff

    .line 300
    .line 301
    .line 302
    and-int v20, v20, v21

    .line 303
    .line 304
    move/from16 p3, v3

    .line 305
    .line 306
    move/from16 v3, v20

    .line 307
    .line 308
    :goto_9
    invoke-direct {v12, v10, v7, v13, v3}, LI/T;-><init>(Ljava/lang/Object;III)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    add-int/lit8 v18, v18, 0x3

    .line 315
    .line 316
    aget v3, v15, v18

    .line 317
    .line 318
    add-int/2addr v13, v3

    .line 319
    move/from16 v3, p3

    .line 320
    .line 321
    const/4 v7, 0x1

    .line 322
    const/4 v10, 0x0

    .line 323
    goto :goto_8

    .line 324
    :goto_a
    iget v3, v0, LI/r;->j:I

    .line 325
    .line 326
    invoke-direct {v11, v3, v5}, LI/p0;-><init>(ILjava/util/ArrayList;)V

    .line 327
    .line 328
    .line 329
    iput-object v11, v0, LI/r;->i:LI/p0;

    .line 330
    .line 331
    :goto_b
    iget-object v3, v0, LI/r;->i:LI/p0;

    .line 332
    .line 333
    if-eqz v3, :cond_2b

    .line 334
    .line 335
    iget-object v5, v3, LI/p0;->d:Ljava/util/ArrayList;

    .line 336
    .line 337
    iget-object v7, v3, LI/p0;->e:Li/x;

    .line 338
    .line 339
    iget v10, v3, LI/p0;->b:I

    .line 340
    .line 341
    if-eqz v2, :cond_14

    .line 342
    .line 343
    new-instance v11, LI/S;

    .line 344
    .line 345
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 346
    .line 347
    .line 348
    move-result-object v12

    .line 349
    invoke-direct {v11, v12, v2}, LI/S;-><init>(Ljava/lang/Integer;Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    goto :goto_c

    .line 353
    :cond_14
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 354
    .line 355
    .line 356
    move-result-object v11

    .line 357
    :goto_c
    iget-object v12, v3, LI/p0;->f:LJ1/k;

    .line 358
    .line 359
    invoke-virtual {v12}, LJ1/k;->getValue()Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v12

    .line 363
    check-cast v12, LK/a;

    .line 364
    .line 365
    iget-object v12, v12, LK/a;->a:Li/E;

    .line 366
    .line 367
    invoke-virtual {v12, v11}, Li/E;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v13

    .line 371
    if-nez v13, :cond_15

    .line 372
    .line 373
    const/4 v13, 0x0

    .line 374
    goto :goto_d

    .line 375
    :cond_15
    instance-of v14, v13, Li/D;

    .line 376
    .line 377
    if-eqz v14, :cond_18

    .line 378
    .line 379
    check-cast v13, Li/D;

    .line 380
    .line 381
    const/4 v14, 0x0

    .line 382
    invoke-virtual {v13, v14}, Li/D;->k(I)Ljava/lang/Object;

    .line 383
    .line 384
    .line 385
    move-result-object v15

    .line 386
    invoke-virtual {v13}, Li/D;->h()Z

    .line 387
    .line 388
    .line 389
    move-result v14

    .line 390
    if-eqz v14, :cond_16

    .line 391
    .line 392
    invoke-virtual {v12, v11}, Li/E;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    :cond_16
    iget v14, v13, Li/D;->b:I

    .line 396
    .line 397
    const/4 v2, 0x1

    .line 398
    if-ne v14, v2, :cond_17

    .line 399
    .line 400
    invoke-virtual {v13}, Li/D;->e()Ljava/lang/Object;

    .line 401
    .line 402
    .line 403
    move-result-object v2

    .line 404
    invoke-virtual {v12, v11, v2}, Li/E;->l(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    :cond_17
    move-object v13, v15

    .line 408
    goto :goto_d

    .line 409
    :cond_18
    invoke-virtual {v12, v11}, Li/E;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    :goto_d
    check-cast v13, LI/T;

    .line 413
    .line 414
    if-nez p3, :cond_2c

    .line 415
    .line 416
    if-eqz v13, :cond_2c

    .line 417
    .line 418
    iget v1, v13, LI/T;->c:I

    .line 419
    .line 420
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 421
    .line 422
    .line 423
    invoke-virtual {v7, v1}, Li/l;->b(I)Ljava/lang/Object;

    .line 424
    .line 425
    .line 426
    move-result-object v2

    .line 427
    check-cast v2, LI/L;

    .line 428
    .line 429
    if-eqz v2, :cond_19

    .line 430
    .line 431
    iget v2, v2, LI/L;->b:I

    .line 432
    .line 433
    goto :goto_e

    .line 434
    :cond_19
    const/4 v2, -0x1

    .line 435
    :goto_e
    add-int/2addr v2, v10

    .line 436
    iput v2, v0, LI/r;->j:I

    .line 437
    .line 438
    invoke-virtual {v7, v1}, Li/l;->b(I)Ljava/lang/Object;

    .line 439
    .line 440
    .line 441
    move-result-object v2

    .line 442
    check-cast v2, LI/L;

    .line 443
    .line 444
    if-eqz v2, :cond_1a

    .line 445
    .line 446
    iget v5, v2, LI/L;->a:I

    .line 447
    .line 448
    goto :goto_f

    .line 449
    :cond_1a
    const/4 v5, -0x1

    .line 450
    :goto_f
    iget v2, v3, LI/p0;->c:I

    .line 451
    .line 452
    sub-int v3, v5, v2

    .line 453
    .line 454
    const/16 v8, 0x8

    .line 455
    .line 456
    if-le v5, v2, :cond_21

    .line 457
    .line 458
    const/16 p1, 0x7

    .line 459
    .line 460
    iget-object v6, v7, Li/l;->c:[Ljava/lang/Object;

    .line 461
    .line 462
    iget-object v7, v7, Li/l;->a:[J

    .line 463
    .line 464
    const-wide/16 p2, 0x80

    .line 465
    .line 466
    array-length v10, v7

    .line 467
    add-int/lit8 v10, v10, -0x2

    .line 468
    .line 469
    if-ltz v10, :cond_20

    .line 470
    .line 471
    const/4 v11, 0x0

    .line 472
    const-wide/16 v20, 0xff

    .line 473
    .line 474
    :goto_10
    aget-wide v12, v7, v11

    .line 475
    .line 476
    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    not-long v14, v12

    .line 482
    shl-long v14, v14, p1

    .line 483
    .line 484
    and-long/2addr v14, v12

    .line 485
    and-long v14, v14, v22

    .line 486
    .line 487
    cmp-long v14, v14, v22

    .line 488
    .line 489
    if-eqz v14, :cond_1f

    .line 490
    .line 491
    sub-int v14, v11, v10

    .line 492
    .line 493
    not-int v14, v14

    .line 494
    ushr-int/lit8 v14, v14, 0x1f

    .line 495
    .line 496
    rsub-int/lit8 v14, v14, 0x8

    .line 497
    .line 498
    const/4 v15, 0x0

    .line 499
    :goto_11
    if-ge v15, v14, :cond_1e

    .line 500
    .line 501
    and-long v24, v12, v20

    .line 502
    .line 503
    cmp-long v16, v24, p2

    .line 504
    .line 505
    if-gez v16, :cond_1c

    .line 506
    .line 507
    shl-int/lit8 v16, v11, 0x3

    .line 508
    .line 509
    add-int v16, v16, v15

    .line 510
    .line 511
    aget-object v16, v6, v16

    .line 512
    .line 513
    move/from16 v18, v8

    .line 514
    .line 515
    move-object/from16 v8, v16

    .line 516
    .line 517
    check-cast v8, LI/L;

    .line 518
    .line 519
    move/from16 v16, v3

    .line 520
    .line 521
    iget v3, v8, LI/L;->a:I

    .line 522
    .line 523
    if-ne v3, v5, :cond_1b

    .line 524
    .line 525
    iput v2, v8, LI/L;->a:I

    .line 526
    .line 527
    goto :goto_12

    .line 528
    :cond_1b
    if-gt v2, v3, :cond_1d

    .line 529
    .line 530
    if-ge v3, v5, :cond_1d

    .line 531
    .line 532
    add-int/lit8 v3, v3, 0x1

    .line 533
    .line 534
    iput v3, v8, LI/L;->a:I

    .line 535
    .line 536
    goto :goto_12

    .line 537
    :cond_1c
    move/from16 v16, v3

    .line 538
    .line 539
    move/from16 v18, v8

    .line 540
    .line 541
    :cond_1d
    :goto_12
    shr-long v12, v12, v18

    .line 542
    .line 543
    add-int/lit8 v15, v15, 0x1

    .line 544
    .line 545
    move/from16 v3, v16

    .line 546
    .line 547
    move/from16 v8, v18

    .line 548
    .line 549
    goto :goto_11

    .line 550
    :cond_1e
    move/from16 v16, v3

    .line 551
    .line 552
    move v3, v8

    .line 553
    if-ne v14, v3, :cond_27

    .line 554
    .line 555
    goto :goto_13

    .line 556
    :cond_1f
    move/from16 v16, v3

    .line 557
    .line 558
    :goto_13
    if-eq v11, v10, :cond_27

    .line 559
    .line 560
    add-int/lit8 v11, v11, 0x1

    .line 561
    .line 562
    move/from16 v3, v16

    .line 563
    .line 564
    const/16 v8, 0x8

    .line 565
    .line 566
    goto :goto_10

    .line 567
    :cond_20
    move/from16 v16, v3

    .line 568
    .line 569
    goto/16 :goto_1a

    .line 570
    .line 571
    :cond_21
    move/from16 v16, v3

    .line 572
    .line 573
    const/16 p1, 0x7

    .line 574
    .line 575
    const-wide/16 p2, 0x80

    .line 576
    .line 577
    const-wide/16 v20, 0xff

    .line 578
    .line 579
    const-wide v22, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    if-le v2, v5, :cond_27

    .line 585
    .line 586
    iget-object v3, v7, Li/l;->c:[Ljava/lang/Object;

    .line 587
    .line 588
    iget-object v6, v7, Li/l;->a:[J

    .line 589
    .line 590
    array-length v7, v6

    .line 591
    add-int/lit8 v7, v7, -0x2

    .line 592
    .line 593
    if-ltz v7, :cond_27

    .line 594
    .line 595
    const/4 v8, 0x0

    .line 596
    :goto_14
    aget-wide v10, v6, v8

    .line 597
    .line 598
    not-long v12, v10

    .line 599
    shl-long v12, v12, p1

    .line 600
    .line 601
    and-long/2addr v12, v10

    .line 602
    and-long v12, v12, v22

    .line 603
    .line 604
    cmp-long v12, v12, v22

    .line 605
    .line 606
    if-eqz v12, :cond_26

    .line 607
    .line 608
    sub-int v12, v8, v7

    .line 609
    .line 610
    not-int v12, v12

    .line 611
    ushr-int/lit8 v12, v12, 0x1f

    .line 612
    .line 613
    const/16 v18, 0x8

    .line 614
    .line 615
    rsub-int/lit8 v12, v12, 0x8

    .line 616
    .line 617
    const/4 v13, 0x0

    .line 618
    :goto_15
    if-ge v13, v12, :cond_25

    .line 619
    .line 620
    and-long v14, v10, v20

    .line 621
    .line 622
    cmp-long v14, v14, p2

    .line 623
    .line 624
    if-gez v14, :cond_24

    .line 625
    .line 626
    shl-int/lit8 v14, v8, 0x3

    .line 627
    .line 628
    add-int/2addr v14, v13

    .line 629
    aget-object v14, v3, v14

    .line 630
    .line 631
    check-cast v14, LI/L;

    .line 632
    .line 633
    iget v15, v14, LI/L;->a:I

    .line 634
    .line 635
    if-ne v15, v5, :cond_22

    .line 636
    .line 637
    iput v2, v14, LI/L;->a:I

    .line 638
    .line 639
    goto :goto_17

    .line 640
    :cond_22
    move-object/from16 v24, v3

    .line 641
    .line 642
    add-int/lit8 v3, v5, 0x1

    .line 643
    .line 644
    if-gt v3, v15, :cond_23

    .line 645
    .line 646
    if-ge v15, v2, :cond_23

    .line 647
    .line 648
    add-int/lit8 v15, v15, -0x1

    .line 649
    .line 650
    iput v15, v14, LI/L;->a:I

    .line 651
    .line 652
    :cond_23
    :goto_16
    const/16 v3, 0x8

    .line 653
    .line 654
    goto :goto_18

    .line 655
    :cond_24
    :goto_17
    move-object/from16 v24, v3

    .line 656
    .line 657
    goto :goto_16

    .line 658
    :goto_18
    shr-long/2addr v10, v3

    .line 659
    add-int/lit8 v13, v13, 0x1

    .line 660
    .line 661
    move-object/from16 v3, v24

    .line 662
    .line 663
    goto :goto_15

    .line 664
    :cond_25
    move-object/from16 v24, v3

    .line 665
    .line 666
    const/16 v3, 0x8

    .line 667
    .line 668
    if-ne v12, v3, :cond_27

    .line 669
    .line 670
    goto :goto_19

    .line 671
    :cond_26
    move-object/from16 v24, v3

    .line 672
    .line 673
    const/16 v3, 0x8

    .line 674
    .line 675
    :goto_19
    if-eq v8, v7, :cond_27

    .line 676
    .line 677
    add-int/lit8 v8, v8, 0x1

    .line 678
    .line 679
    move-object/from16 v3, v24

    .line 680
    .line 681
    goto :goto_14

    .line 682
    :cond_27
    :goto_1a
    iget-object v2, v0, LI/r;->L:LJ/b;

    .line 683
    .line 684
    iget v3, v2, LJ/b;->f:I

    .line 685
    .line 686
    iget-object v5, v2, LJ/b;->a:LI/r;

    .line 687
    .line 688
    iget-object v6, v5, LI/r;->F:LI/L0;

    .line 689
    .line 690
    iget v6, v6, LI/L0;->g:I

    .line 691
    .line 692
    sub-int v6, v1, v6

    .line 693
    .line 694
    add-int/2addr v6, v3

    .line 695
    iput v6, v2, LJ/b;->f:I

    .line 696
    .line 697
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 698
    .line 699
    invoke-virtual {v3, v1}, LI/L0;->r(I)V

    .line 700
    .line 701
    .line 702
    if-lez v16, :cond_2a

    .line 703
    .line 704
    const/4 v14, 0x0

    .line 705
    invoke-virtual {v2, v14}, LJ/b;->d(Z)V

    .line 706
    .line 707
    .line 708
    iget-object v1, v2, LJ/b;->d:LI/O;

    .line 709
    .line 710
    iget-object v3, v5, LI/r;->F:LI/L0;

    .line 711
    .line 712
    iget v5, v3, LI/L0;->c:I

    .line 713
    .line 714
    if-lez v5, :cond_29

    .line 715
    .line 716
    iget v5, v3, LI/L0;->i:I

    .line 717
    .line 718
    const/4 v6, -0x2

    .line 719
    invoke-virtual {v1, v6}, LI/O;->a(I)I

    .line 720
    .line 721
    .line 722
    move-result v6

    .line 723
    if-eq v6, v5, :cond_29

    .line 724
    .line 725
    iget-boolean v6, v2, LJ/b;->c:Z

    .line 726
    .line 727
    if-nez v6, :cond_28

    .line 728
    .line 729
    iget-boolean v6, v2, LJ/b;->e:Z

    .line 730
    .line 731
    if-eqz v6, :cond_28

    .line 732
    .line 733
    const/4 v14, 0x0

    .line 734
    invoke-virtual {v2, v14}, LJ/b;->d(Z)V

    .line 735
    .line 736
    .line 737
    iget-object v6, v2, LJ/b;->b:LJ/a;

    .line 738
    .line 739
    iget-object v6, v6, LJ/a;->a:LJ/J;

    .line 740
    .line 741
    sget-object v7, LJ/p;->c:LJ/p;

    .line 742
    .line 743
    invoke-virtual {v6, v7}, LJ/J;->T(LJ/H;)V

    .line 744
    .line 745
    .line 746
    const/4 v6, 0x1

    .line 747
    iput-boolean v6, v2, LJ/b;->c:Z

    .line 748
    .line 749
    :cond_28
    if-lez v5, :cond_29

    .line 750
    .line 751
    invoke-virtual {v3, v5}, LI/L0;->a(I)LI/a;

    .line 752
    .line 753
    .line 754
    move-result-object v3

    .line 755
    invoke-virtual {v1, v5}, LI/O;->c(I)V

    .line 756
    .line 757
    .line 758
    const/4 v14, 0x0

    .line 759
    invoke-virtual {v2, v14}, LJ/b;->d(Z)V

    .line 760
    .line 761
    .line 762
    iget-object v1, v2, LJ/b;->b:LJ/a;

    .line 763
    .line 764
    iget-object v1, v1, LJ/a;->a:LJ/J;

    .line 765
    .line 766
    sget-object v5, LJ/o;->c:LJ/o;

    .line 767
    .line 768
    invoke-virtual {v1, v5}, LJ/J;->T(LJ/H;)V

    .line 769
    .line 770
    .line 771
    invoke-static {v1, v14, v3}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 772
    .line 773
    .line 774
    const/4 v6, 0x1

    .line 775
    iput-boolean v6, v2, LJ/b;->c:Z

    .line 776
    .line 777
    :cond_29
    iget-object v1, v2, LJ/b;->b:LJ/a;

    .line 778
    .line 779
    iget-object v1, v1, LJ/a;->a:LJ/J;

    .line 780
    .line 781
    sget-object v2, LJ/t;->c:LJ/t;

    .line 782
    .line 783
    invoke-virtual {v1, v2}, LJ/J;->T(LJ/H;)V

    .line 784
    .line 785
    .line 786
    iget-object v2, v1, LJ/J;->c:[I

    .line 787
    .line 788
    iget v3, v1, LJ/J;->d:I

    .line 789
    .line 790
    iget-object v5, v1, LJ/J;->a:[LJ/H;

    .line 791
    .line 792
    iget v1, v1, LJ/J;->b:I

    .line 793
    .line 794
    const/16 v19, 0x1

    .line 795
    .line 796
    add-int/lit8 v1, v1, -0x1

    .line 797
    .line 798
    aget-object v1, v5, v1

    .line 799
    .line 800
    iget v1, v1, LJ/H;->a:I

    .line 801
    .line 802
    sub-int/2addr v3, v1

    .line 803
    aput v16, v2, v3

    .line 804
    .line 805
    :cond_2a
    invoke-virtual {v0, v4, v9}, LI/r;->T(Ljava/lang/Object;Z)V

    .line 806
    .line 807
    .line 808
    :cond_2b
    const/4 v2, 0x0

    .line 809
    goto/16 :goto_20

    .line 810
    .line 811
    :cond_2c
    iget-object v2, v0, LI/r;->F:LI/L0;

    .line 812
    .line 813
    iget v3, v2, LI/L0;->k:I

    .line 814
    .line 815
    const/4 v11, 0x1

    .line 816
    add-int/2addr v3, v11

    .line 817
    iput v3, v2, LI/L0;->k:I

    .line 818
    .line 819
    iput-boolean v11, v0, LI/r;->Q:Z

    .line 820
    .line 821
    const/4 v2, 0x0

    .line 822
    iput-object v2, v0, LI/r;->J:LI/q0;

    .line 823
    .line 824
    iget-object v3, v0, LI/r;->H:LI/P0;

    .line 825
    .line 826
    iget-boolean v3, v3, LI/P0;->w:Z

    .line 827
    .line 828
    if-eqz v3, :cond_2d

    .line 829
    .line 830
    iget-object v3, v0, LI/r;->G:LI/M0;

    .line 831
    .line 832
    invoke-virtual {v3}, LI/M0;->d()LI/P0;

    .line 833
    .line 834
    .line 835
    move-result-object v3

    .line 836
    iput-object v3, v0, LI/r;->H:LI/P0;

    .line 837
    .line 838
    invoke-virtual {v3}, LI/P0;->L()V

    .line 839
    .line 840
    .line 841
    const/4 v14, 0x0

    .line 842
    iput-boolean v14, v0, LI/r;->I:Z

    .line 843
    .line 844
    iput-object v2, v0, LI/r;->J:LI/q0;

    .line 845
    .line 846
    :cond_2d
    iget-object v2, v0, LI/r;->H:LI/P0;

    .line 847
    .line 848
    invoke-virtual {v2}, LI/P0;->d()V

    .line 849
    .line 850
    .line 851
    iget-object v2, v0, LI/r;->H:LI/P0;

    .line 852
    .line 853
    iget v3, v2, LI/P0;->t:I

    .line 854
    .line 855
    if-eqz v9, :cond_2e

    .line 856
    .line 857
    const/4 v11, 0x1

    .line 858
    invoke-virtual {v2, v1, v8, v11, v8}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 859
    .line 860
    .line 861
    const/4 v14, 0x0

    .line 862
    goto :goto_1e

    .line 863
    :cond_2e
    if-eqz v4, :cond_30

    .line 864
    .line 865
    if-nez p2, :cond_2f

    .line 866
    .line 867
    :goto_1b
    const/4 v14, 0x0

    .line 868
    goto :goto_1c

    .line 869
    :cond_2f
    move-object/from16 v8, p2

    .line 870
    .line 871
    goto :goto_1b

    .line 872
    :goto_1c
    invoke-virtual {v2, v1, v8, v14, v4}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 873
    .line 874
    .line 875
    goto :goto_1e

    .line 876
    :cond_30
    const/4 v14, 0x0

    .line 877
    if-nez p2, :cond_31

    .line 878
    .line 879
    move-object v4, v8

    .line 880
    goto :goto_1d

    .line 881
    :cond_31
    move-object/from16 v4, p2

    .line 882
    .line 883
    :goto_1d
    invoke-virtual {v2, v1, v4, v14, v8}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 884
    .line 885
    .line 886
    :goto_1e
    iget-object v2, v0, LI/r;->H:LI/P0;

    .line 887
    .line 888
    invoke-virtual {v2, v3}, LI/P0;->b(I)LI/a;

    .line 889
    .line 890
    .line 891
    move-result-object v2

    .line 892
    iput-object v2, v0, LI/r;->M:LI/a;

    .line 893
    .line 894
    new-instance v2, LI/T;

    .line 895
    .line 896
    const/16 v17, -0x2

    .line 897
    .line 898
    rsub-int/lit8 v12, v3, -0x2

    .line 899
    .line 900
    const/4 v3, -0x1

    .line 901
    invoke-direct {v2, v6, v1, v12, v3}, LI/T;-><init>(Ljava/lang/Object;III)V

    .line 902
    .line 903
    .line 904
    iget v1, v0, LI/r;->j:I

    .line 905
    .line 906
    sub-int/2addr v1, v10

    .line 907
    new-instance v4, LI/L;

    .line 908
    .line 909
    invoke-direct {v4, v3, v1, v14}, LI/L;-><init>(III)V

    .line 910
    .line 911
    .line 912
    invoke-virtual {v7, v12, v4}, Li/x;->h(ILjava/lang/Object;)V

    .line 913
    .line 914
    .line 915
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 916
    .line 917
    .line 918
    new-instance v13, LI/p0;

    .line 919
    .line 920
    new-instance v1, Ljava/util/ArrayList;

    .line 921
    .line 922
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 923
    .line 924
    .line 925
    if-eqz v9, :cond_32

    .line 926
    .line 927
    move v10, v14

    .line 928
    goto :goto_1f

    .line 929
    :cond_32
    iget v10, v0, LI/r;->j:I

    .line 930
    .line 931
    :goto_1f
    invoke-direct {v13, v10, v1}, LI/p0;-><init>(ILjava/util/ArrayList;)V

    .line 932
    .line 933
    .line 934
    goto :goto_21

    .line 935
    :goto_20
    move-object v13, v2

    .line 936
    :goto_21
    invoke-virtual {v0, v9, v13}, LI/r;->t(ZLI/p0;)V

    .line 937
    .line 938
    .line 939
    return-void
.end method

.method public final S(ILI/g0;)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-virtual {p0, p1, p2, v0, v1}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final T(Ljava/lang/Object;Z)V
    .locals 2

    .line 1
    if-eqz p2, :cond_2

    .line 2
    .line 3
    iget-object p1, p0, LI/r;->F:LI/L0;

    .line 4
    .line 5
    iget p2, p1, LI/L0;->k:I

    .line 6
    .line 7
    if-gtz p2, :cond_1

    .line 8
    .line 9
    iget-object p2, p1, LI/L0;->b:[I

    .line 10
    .line 11
    iget v0, p1, LI/L0;->g:I

    .line 12
    .line 13
    mul-int/lit8 v0, v0, 0x5

    .line 14
    .line 15
    add-int/lit8 v0, v0, 0x1

    .line 16
    .line 17
    aget p2, p2, v0

    .line 18
    .line 19
    const/high16 v0, 0x40000000    # 2.0f

    .line 20
    .line 21
    and-int/2addr p2, v0

    .line 22
    if-eqz p2, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const-string p2, "Expected a node group"

    .line 26
    .line 27
    invoke-static {p2}, LI/r0;->a(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    invoke-virtual {p1}, LI/L0;->u()V

    .line 31
    .line 32
    .line 33
    :cond_1
    return-void

    .line 34
    :cond_2
    if-eqz p1, :cond_3

    .line 35
    .line 36
    iget-object p2, p0, LI/r;->F:LI/L0;

    .line 37
    .line 38
    invoke-virtual {p2}, LI/L0;->f()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    if-eq p2, p1, :cond_3

    .line 43
    .line 44
    iget-object p2, p0, LI/r;->L:LJ/b;

    .line 45
    .line 46
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-virtual {p2, v0}, LJ/b;->d(Z)V

    .line 51
    .line 52
    .line 53
    iget-object p2, p2, LJ/b;->b:LJ/a;

    .line 54
    .line 55
    iget-object p2, p2, LJ/a;->a:LJ/J;

    .line 56
    .line 57
    sget-object v1, LJ/D;->c:LJ/D;

    .line 58
    .line 59
    invoke-virtual {p2, v1}, LJ/J;->T(LJ/H;)V

    .line 60
    .line 61
    .line 62
    invoke-static {p2, v0, p1}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_3
    iget-object p1, p0, LI/r;->F:LI/L0;

    .line 66
    .line 67
    invoke-virtual {p1}, LI/L0;->u()V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final U(I)V
    .locals 9

    .line 1
    iget-object v0, p0, LI/r;->i:LI/p0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0, p1, v2, v1, v2}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    iget-boolean v0, p0, LI/r;->q:Z

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    .line 16
    .line 17
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    :cond_1
    iget v0, p0, LI/r;->l:I

    .line 21
    .line 22
    iget-wide v3, p0, LI/r;->R:J

    .line 23
    .line 24
    const/4 v5, 0x3

    .line 25
    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 26
    .line 27
    .line 28
    move-result-wide v3

    .line 29
    int-to-long v6, p1

    .line 30
    xor-long/2addr v3, v6

    .line 31
    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 32
    .line 33
    .line 34
    move-result-wide v3

    .line 35
    int-to-long v5, v0

    .line 36
    xor-long/2addr v3, v5

    .line 37
    iput-wide v3, p0, LI/r;->R:J

    .line 38
    .line 39
    iget v0, p0, LI/r;->l:I

    .line 40
    .line 41
    const/4 v3, 0x1

    .line 42
    add-int/2addr v0, v3

    .line 43
    iput v0, p0, LI/r;->l:I

    .line 44
    .line 45
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 46
    .line 47
    iget-boolean v4, p0, LI/r;->Q:Z

    .line 48
    .line 49
    sget-object v5, LI/m;->a:LI/h;

    .line 50
    .line 51
    if-eqz v4, :cond_2

    .line 52
    .line 53
    iget v4, v0, LI/L0;->k:I

    .line 54
    .line 55
    add-int/2addr v4, v3

    .line 56
    iput v4, v0, LI/L0;->k:I

    .line 57
    .line 58
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 59
    .line 60
    invoke-virtual {v0, p1, v5, v1, v5}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p0, v1, v2}, LI/r;->t(ZLI/p0;)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_2
    invoke-virtual {v0}, LI/L0;->g()I

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-ne v4, p1, :cond_4

    .line 72
    .line 73
    iget v4, v0, LI/L0;->g:I

    .line 74
    .line 75
    iget v6, v0, LI/L0;->h:I

    .line 76
    .line 77
    if-ge v4, v6, :cond_3

    .line 78
    .line 79
    iget-object v6, v0, LI/L0;->b:[I

    .line 80
    .line 81
    mul-int/lit8 v4, v4, 0x5

    .line 82
    .line 83
    add-int/2addr v4, v3

    .line 84
    aget v4, v6, v4

    .line 85
    .line 86
    const/high16 v6, 0x20000000

    .line 87
    .line 88
    and-int/2addr v4, v6

    .line 89
    if-eqz v4, :cond_3

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_3
    invoke-virtual {v0}, LI/L0;->u()V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v1, v2}, LI/r;->t(ZLI/p0;)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :cond_4
    :goto_0
    iget v4, v0, LI/L0;->k:I

    .line 100
    .line 101
    if-lez v4, :cond_5

    .line 102
    .line 103
    goto :goto_1

    .line 104
    :cond_5
    iget v4, v0, LI/L0;->g:I

    .line 105
    .line 106
    iget v6, v0, LI/L0;->h:I

    .line 107
    .line 108
    if-ne v4, v6, :cond_6

    .line 109
    .line 110
    goto :goto_1

    .line 111
    :cond_6
    iget v6, p0, LI/r;->j:I

    .line 112
    .line 113
    invoke-virtual {p0}, LI/r;->H()V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0}, LI/L0;->s()I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    iget-object v8, p0, LI/r;->L:LJ/b;

    .line 121
    .line 122
    invoke-virtual {v8, v6, v7}, LJ/b;->e(II)V

    .line 123
    .line 124
    .line 125
    iget-object v6, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 126
    .line 127
    iget v7, v0, LI/L0;->g:I

    .line 128
    .line 129
    invoke-static {v6, v4, v7}, LI/k;->f(Ljava/util/ArrayList;II)V

    .line 130
    .line 131
    .line 132
    :goto_1
    iget v4, v0, LI/L0;->k:I

    .line 133
    .line 134
    add-int/2addr v4, v3

    .line 135
    iput v4, v0, LI/L0;->k:I

    .line 136
    .line 137
    iput-boolean v3, p0, LI/r;->Q:Z

    .line 138
    .line 139
    iput-object v2, p0, LI/r;->J:LI/q0;

    .line 140
    .line 141
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 142
    .line 143
    iget-boolean v0, v0, LI/P0;->w:Z

    .line 144
    .line 145
    if-eqz v0, :cond_7

    .line 146
    .line 147
    iget-object v0, p0, LI/r;->G:LI/M0;

    .line 148
    .line 149
    invoke-virtual {v0}, LI/M0;->d()LI/P0;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    iput-object v0, p0, LI/r;->H:LI/P0;

    .line 154
    .line 155
    invoke-virtual {v0}, LI/P0;->L()V

    .line 156
    .line 157
    .line 158
    iput-boolean v1, p0, LI/r;->I:Z

    .line 159
    .line 160
    iput-object v2, p0, LI/r;->J:LI/q0;

    .line 161
    .line 162
    :cond_7
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 163
    .line 164
    invoke-virtual {v0}, LI/P0;->d()V

    .line 165
    .line 166
    .line 167
    iget v3, v0, LI/P0;->t:I

    .line 168
    .line 169
    invoke-virtual {v0, p1, v5, v1, v5}, LI/P0;->P(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v0, v3}, LI/P0;->b(I)LI/a;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    iput-object p1, p0, LI/r;->M:LI/a;

    .line 177
    .line 178
    invoke-virtual {p0, v1, v2}, LI/r;->t(ZLI/p0;)V

    .line 179
    .line 180
    .line 181
    return-void
.end method

.method public final V(I)LI/r;
    .locals 5

    .line 1
    invoke-virtual {p0, p1}, LI/r;->U(I)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, LI/r;->Q:Z

    .line 5
    .line 6
    iget-object v0, p0, LI/r;->D:Ljava/util/ArrayList;

    .line 7
    .line 8
    iget-object v1, p0, LI/r;->g:LI/y;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    new-instance p1, LI/w0;

    .line 13
    .line 14
    invoke-direct {p1, v1}, LI/w0;-><init>(LI/y;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget v0, p0, LI/r;->A:I

    .line 24
    .line 25
    iput v0, p1, LI/w0;->e:I

    .line 26
    .line 27
    iget v0, p1, LI/w0;->b:I

    .line 28
    .line 29
    and-int/lit8 v0, v0, -0x11

    .line 30
    .line 31
    iput v0, p1, LI/w0;->b:I

    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_0
    iget-object p1, p0, LI/r;->F:LI/L0;

    .line 35
    .line 36
    iget p1, p1, LI/L0;->i:I

    .line 37
    .line 38
    iget-object v2, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-static {p1, v2}, LI/k;->m(ILjava/util/List;)I

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    if-ltz p1, :cond_1

    .line 45
    .line 46
    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, LI/P;

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_1
    const/4 p1, 0x0

    .line 54
    :goto_0
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 55
    .line 56
    invoke-virtual {v2}, LI/L0;->m()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    sget-object v3, LI/m;->a:LI/h;

    .line 61
    .line 62
    invoke-static {v2, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    if-eqz v3, :cond_2

    .line 67
    .line 68
    new-instance v2, LI/w0;

    .line 69
    .line 70
    invoke-direct {v2, v1}, LI/w0;-><init>(LI/y;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0, v2}, LI/r;->e0(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_2
    const-string v1, "null cannot be cast to non-null type androidx.compose.runtime.RecomposeScopeImpl"

    .line 78
    .line 79
    invoke-static {v2, v1}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    check-cast v2, LI/w0;

    .line 83
    .line 84
    :goto_1
    const/4 v1, 0x0

    .line 85
    const/4 v3, 0x1

    .line 86
    if-nez p1, :cond_6

    .line 87
    .line 88
    iget p1, v2, LI/w0;->b:I

    .line 89
    .line 90
    and-int/lit8 v4, p1, 0x40

    .line 91
    .line 92
    if-eqz v4, :cond_3

    .line 93
    .line 94
    move v4, v3

    .line 95
    goto :goto_2

    .line 96
    :cond_3
    move v4, v1

    .line 97
    :goto_2
    if-eqz v4, :cond_4

    .line 98
    .line 99
    and-int/lit8 p1, p1, -0x41

    .line 100
    .line 101
    iput p1, v2, LI/w0;->b:I

    .line 102
    .line 103
    :cond_4
    if-eqz v4, :cond_5

    .line 104
    .line 105
    goto :goto_3

    .line 106
    :cond_5
    move p1, v1

    .line 107
    goto :goto_4

    .line 108
    :cond_6
    :goto_3
    move p1, v3

    .line 109
    :goto_4
    iget v4, v2, LI/w0;->b:I

    .line 110
    .line 111
    if-eqz p1, :cond_7

    .line 112
    .line 113
    or-int/lit8 p1, v4, 0x8

    .line 114
    .line 115
    goto :goto_5

    .line 116
    :cond_7
    and-int/lit8 p1, v4, -0x9

    .line 117
    .line 118
    :goto_5
    iput p1, v2, LI/w0;->b:I

    .line 119
    .line 120
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    iget p1, p0, LI/r;->A:I

    .line 124
    .line 125
    iput p1, v2, LI/w0;->e:I

    .line 126
    .line 127
    iget p1, v2, LI/w0;->b:I

    .line 128
    .line 129
    and-int/lit8 v0, p1, -0x11

    .line 130
    .line 131
    iput v0, v2, LI/w0;->b:I

    .line 132
    .line 133
    and-int/lit16 v0, p1, 0x100

    .line 134
    .line 135
    if-eqz v0, :cond_8

    .line 136
    .line 137
    and-int/lit16 p1, p1, -0x111

    .line 138
    .line 139
    or-int/lit16 p1, p1, 0x200

    .line 140
    .line 141
    iput p1, v2, LI/w0;->b:I

    .line 142
    .line 143
    iget-object p1, p0, LI/r;->L:LJ/b;

    .line 144
    .line 145
    iget-object p1, p1, LJ/b;->b:LJ/a;

    .line 146
    .line 147
    iget-object p1, p1, LJ/a;->a:LJ/J;

    .line 148
    .line 149
    sget-object v0, LJ/B;->c:LJ/B;

    .line 150
    .line 151
    invoke-virtual {p1, v0}, LJ/J;->T(LJ/H;)V

    .line 152
    .line 153
    .line 154
    invoke-static {p1, v1, v2}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    iget-boolean p1, p0, LI/r;->x:Z

    .line 158
    .line 159
    if-nez p1, :cond_8

    .line 160
    .line 161
    iget p1, v2, LI/w0;->b:I

    .line 162
    .line 163
    and-int/lit16 v0, p1, 0x80

    .line 164
    .line 165
    if-eqz v0, :cond_8

    .line 166
    .line 167
    iput-boolean v3, p0, LI/r;->x:Z

    .line 168
    .line 169
    or-int/lit16 p1, p1, 0x400

    .line 170
    .line 171
    iput p1, v2, LI/w0;->b:I

    .line 172
    .line 173
    :cond_8
    return-object p0
.end method

.method public final W()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x2

    .line 3
    const/16 v2, 0x7d

    .line 4
    .line 5
    invoke-virtual {p0, v2, v0, v1, v0}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, LI/r;->q:Z

    .line 10
    .line 11
    return-void
.end method

.method public final X()V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, LI/r;->l:I

    .line 3
    .line 4
    iget-object v1, p0, LI/r;->c:LI/M0;

    .line 5
    .line 6
    invoke-virtual {v1}, LI/M0;->c()LI/L0;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iput-object v1, p0, LI/r;->F:LI/L0;

    .line 11
    .line 12
    const/16 v1, 0x64

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {p0, v1, v2, v0, v2}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LI/r;->b:LI/v;

    .line 19
    .line 20
    invoke-virtual {v1}, LI/v;->q()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1}, LI/v;->h()LI/q0;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    iget-object v4, p0, LI/r;->w:LI/O;

    .line 28
    .line 29
    iget-boolean v5, p0, LI/r;->v:Z

    .line 30
    .line 31
    invoke-virtual {v4, v5}, LI/O;->c(I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, v3}, LI/r;->e(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    iput-boolean v4, p0, LI/r;->v:Z

    .line 39
    .line 40
    iput-object v2, p0, LI/r;->J:LI/q0;

    .line 41
    .line 42
    iget-boolean v4, p0, LI/r;->p:Z

    .line 43
    .line 44
    if-nez v4, :cond_0

    .line 45
    .line 46
    invoke-virtual {v1}, LI/v;->d()Z

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    iput-boolean v4, p0, LI/r;->p:Z

    .line 51
    .line 52
    :cond_0
    iget-boolean v4, p0, LI/r;->B:Z

    .line 53
    .line 54
    if-nez v4, :cond_1

    .line 55
    .line 56
    invoke-virtual {v1}, LI/v;->e()Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    iput-boolean v4, p0, LI/r;->B:Z

    .line 61
    .line 62
    :cond_1
    iget-boolean v4, p0, LI/r;->B:Z

    .line 63
    .line 64
    if-eqz v4, :cond_2

    .line 65
    .line 66
    sget-object v4, LV/f;->a:LI/b1;

    .line 67
    .line 68
    const-string v5, "null cannot be cast to non-null type androidx.compose.runtime.CompositionLocal<kotlin.Any?>"

    .line 69
    .line 70
    invoke-static {v4, v5}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    new-instance v5, LI/c1;

    .line 74
    .line 75
    invoke-virtual {p0}, LI/r;->y()LV/e;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    invoke-direct {v5, v6}, LI/c1;-><init>(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    check-cast v3, LQ/j;

    .line 83
    .line 84
    invoke-virtual {v3, v4, v5}, LQ/j;->b(LI/t0;LI/d1;)LQ/j;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    :cond_2
    iput-object v3, p0, LI/r;->t:LI/q0;

    .line 89
    .line 90
    sget-object v4, LV/h;->a:LI/b1;

    .line 91
    .line 92
    invoke-static {v3, v4}, LI/k;->r(LI/q0;LI/t0;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    check-cast v3, Ljava/util/Set;

    .line 97
    .line 98
    if-eqz v3, :cond_3

    .line 99
    .line 100
    invoke-virtual {p0}, LI/r;->v()LV/d;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    invoke-virtual {v1, v3}, LI/v;->m(Ljava/util/Set;)V

    .line 108
    .line 109
    .line 110
    :cond_3
    invoke-virtual {v1}, LI/v;->f()J

    .line 111
    .line 112
    .line 113
    move-result-wide v3

    .line 114
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    invoke-virtual {p0, v1, v2, v0, v2}, LI/r;->R(ILjava/lang/Object;ILI/q0;)V

    .line 119
    .line 120
    .line 121
    return-void
.end method

.method public final Y(LI/w0;Ljava/lang/Object;)Z
    .locals 6

    .line 1
    iget-object v0, p1, LI/w0;->c:LI/a;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_1

    .line 6
    :cond_0
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 7
    .line 8
    iget-object v1, v1, LI/L0;->a:LI/M0;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, LI/M0;->a(LI/a;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iget-boolean v1, p0, LI/r;->E:Z

    .line 15
    .line 16
    if-eqz v1, :cond_6

    .line 17
    .line 18
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 19
    .line 20
    iget v1, v1, LI/L0;->g:I

    .line 21
    .line 22
    if-lt v0, v1, :cond_6

    .line 23
    .line 24
    iget-object v1, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-static {v0, v1}, LI/k;->m(ILjava/util/List;)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    const/4 v3, 0x1

    .line 31
    const/4 v4, 0x0

    .line 32
    if-gez v2, :cond_2

    .line 33
    .line 34
    add-int/2addr v2, v3

    .line 35
    neg-int v2, v2

    .line 36
    instance-of v5, p2, LI/F;

    .line 37
    .line 38
    if-eqz v5, :cond_1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    move-object p2, v4

    .line 42
    :goto_0
    new-instance v4, LI/P;

    .line 43
    .line 44
    invoke-direct {v4, p1, v0, p2}, LI/P;-><init>(LI/w0;ILjava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1, v2, v4}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    return v3

    .line 51
    :cond_2
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, LI/P;

    .line 56
    .line 57
    instance-of v0, p2, LI/F;

    .line 58
    .line 59
    if-eqz v0, :cond_5

    .line 60
    .line 61
    iget-object v0, p1, LI/P;->c:Ljava/lang/Object;

    .line 62
    .line 63
    if-nez v0, :cond_3

    .line 64
    .line 65
    iput-object p2, p1, LI/P;->c:Ljava/lang/Object;

    .line 66
    .line 67
    return v3

    .line 68
    :cond_3
    instance-of v1, v0, Li/F;

    .line 69
    .line 70
    if-eqz v1, :cond_4

    .line 71
    .line 72
    check-cast v0, Li/F;

    .line 73
    .line 74
    invoke-virtual {v0, p2}, Li/F;->a(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    return v3

    .line 78
    :cond_4
    sget v1, Li/L;->a:I

    .line 79
    .line 80
    new-instance v1, Li/F;

    .line 81
    .line 82
    const/4 v2, 0x2

    .line 83
    invoke-direct {v1, v2}, Li/F;-><init>(I)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1, v0}, Li/F;->j(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1, p2}, Li/F;->j(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    iput-object v1, p1, LI/P;->c:Ljava/lang/Object;

    .line 93
    .line 94
    return v3

    .line 95
    :cond_5
    iput-object v4, p1, LI/P;->c:Ljava/lang/Object;

    .line 96
    .line 97
    return v3

    .line 98
    :cond_6
    :goto_1
    const/4 p1, 0x0

    .line 99
    return p1
.end method

.method public final Z(Li/E;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, LI/r;->r:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-static {v2}, LX1/a;->L(Ljava/util/List;)I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    :goto_0
    const/4 v4, -0x1

    .line 12
    if-ge v4, v3, :cond_2

    .line 13
    .line 14
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    check-cast v4, LI/P;

    .line 19
    .line 20
    iget-object v5, v4, LI/P;->a:LI/w0;

    .line 21
    .line 22
    iget-object v5, v5, LI/w0;->c:LI/a;

    .line 23
    .line 24
    if-eqz v5, :cond_0

    .line 25
    .line 26
    invoke-virtual {v5}, LI/a;->a()Z

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    if-eqz v6, :cond_0

    .line 31
    .line 32
    iget v6, v4, LI/P;->b:I

    .line 33
    .line 34
    iget v5, v5, LI/a;->a:I

    .line 35
    .line 36
    if-eq v6, v5, :cond_1

    .line 37
    .line 38
    iput v5, v4, LI/P;->b:I

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_0
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    :cond_1
    :goto_1
    add-int/lit8 v3, v3, -0x1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_2
    iget-object v3, v1, Li/E;->b:[Ljava/lang/Object;

    .line 48
    .line 49
    iget-object v4, v1, Li/E;->c:[Ljava/lang/Object;

    .line 50
    .line 51
    iget-object v1, v1, Li/E;->a:[J

    .line 52
    .line 53
    array-length v5, v1

    .line 54
    add-int/lit8 v5, v5, -0x2

    .line 55
    .line 56
    if-ltz v5, :cond_7

    .line 57
    .line 58
    const/4 v7, 0x0

    .line 59
    :goto_2
    aget-wide v8, v1, v7

    .line 60
    .line 61
    not-long v10, v8

    .line 62
    const/4 v12, 0x7

    .line 63
    shl-long/2addr v10, v12

    .line 64
    and-long/2addr v10, v8

    .line 65
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    and-long/2addr v10, v12

    .line 71
    cmp-long v10, v10, v12

    .line 72
    .line 73
    if-eqz v10, :cond_6

    .line 74
    .line 75
    sub-int v10, v7, v5

    .line 76
    .line 77
    not-int v10, v10

    .line 78
    ushr-int/lit8 v10, v10, 0x1f

    .line 79
    .line 80
    const/16 v11, 0x8

    .line 81
    .line 82
    rsub-int/lit8 v10, v10, 0x8

    .line 83
    .line 84
    const/4 v12, 0x0

    .line 85
    :goto_3
    if-ge v12, v10, :cond_5

    .line 86
    .line 87
    const-wide/16 v13, 0xff

    .line 88
    .line 89
    and-long/2addr v13, v8

    .line 90
    const-wide/16 v15, 0x80

    .line 91
    .line 92
    cmp-long v13, v13, v15

    .line 93
    .line 94
    if-gez v13, :cond_4

    .line 95
    .line 96
    shl-int/lit8 v13, v7, 0x3

    .line 97
    .line 98
    add-int/2addr v13, v12

    .line 99
    aget-object v14, v3, v13

    .line 100
    .line 101
    aget-object v13, v4, v13

    .line 102
    .line 103
    const-string v15, "null cannot be cast to non-null type androidx.compose.runtime.RecomposeScopeImpl"

    .line 104
    .line 105
    invoke-static {v14, v15}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    check-cast v14, LI/w0;

    .line 109
    .line 110
    iget-object v15, v14, LI/w0;->c:LI/a;

    .line 111
    .line 112
    if-eqz v15, :cond_4

    .line 113
    .line 114
    iget v15, v15, LI/a;->a:I

    .line 115
    .line 116
    sget-object v6, LI/h;->i:LI/h;

    .line 117
    .line 118
    if-ne v13, v6, :cond_3

    .line 119
    .line 120
    const/4 v13, 0x0

    .line 121
    :cond_3
    new-instance v6, LI/P;

    .line 122
    .line 123
    invoke-direct {v6, v14, v15, v13}, LI/P;-><init>(LI/w0;ILjava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    :cond_4
    shr-long/2addr v8, v11

    .line 130
    add-int/lit8 v12, v12, 0x1

    .line 131
    .line 132
    goto :goto_3

    .line 133
    :cond_5
    if-ne v10, v11, :cond_7

    .line 134
    .line 135
    :cond_6
    if-eq v7, v5, :cond_7

    .line 136
    .line 137
    add-int/lit8 v7, v7, 0x1

    .line 138
    .line 139
    goto :goto_2

    .line 140
    :cond_7
    sget-object v1, LI/k;->c:LI/s;

    .line 141
    .line 142
    invoke-static {v2, v1}, LK1/q;->p0(Ljava/util/List;Ljava/util/Comparator;)V

    .line 143
    .line 144
    .line 145
    return-void
.end method

.method public final a()V
    .locals 4

    .line 1
    invoke-virtual {p0}, LI/r;->h()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LI/r;->h:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LI/r;->m:LI/O;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    iput v1, v0, LI/O;->b:I

    .line 13
    .line 14
    iget-object v0, p0, LI/r;->s:LI/O;

    .line 15
    .line 16
    iput v1, v0, LI/O;->b:I

    .line 17
    .line 18
    iget-object v0, p0, LI/r;->w:LI/O;

    .line 19
    .line 20
    iput v1, v0, LI/O;->b:I

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    iput-object v0, p0, LI/r;->u:Li/x;

    .line 24
    .line 25
    iget-object v0, p0, LI/r;->N:LJ/c;

    .line 26
    .line 27
    iget-object v2, v0, LJ/c;->b:LJ/J;

    .line 28
    .line 29
    invoke-virtual {v2}, LJ/J;->P()V

    .line 30
    .line 31
    .line 32
    iget-object v0, v0, LJ/c;->a:LJ/J;

    .line 33
    .line 34
    invoke-virtual {v0}, LJ/J;->P()V

    .line 35
    .line 36
    .line 37
    int-to-long v2, v1

    .line 38
    iput-wide v2, p0, LI/r;->R:J

    .line 39
    .line 40
    iput v1, p0, LI/r;->z:I

    .line 41
    .line 42
    iput-boolean v1, p0, LI/r;->q:Z

    .line 43
    .line 44
    iput-boolean v1, p0, LI/r;->Q:Z

    .line 45
    .line 46
    iput-boolean v1, p0, LI/r;->x:Z

    .line 47
    .line 48
    iput-boolean v1, p0, LI/r;->E:Z

    .line 49
    .line 50
    const/4 v0, -0x1

    .line 51
    iput v0, p0, LI/r;->y:I

    .line 52
    .line 53
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 54
    .line 55
    iget-boolean v1, v0, LI/L0;->f:Z

    .line 56
    .line 57
    if-nez v1, :cond_0

    .line 58
    .line 59
    invoke-virtual {v0}, LI/L0;->c()V

    .line 60
    .line 61
    .line 62
    :cond_0
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 63
    .line 64
    iget-boolean v0, v0, LI/P0;->w:Z

    .line 65
    .line 66
    if-nez v0, :cond_1

    .line 67
    .line 68
    invoke-virtual {p0}, LI/r;->u()V

    .line 69
    .line 70
    .line 71
    :cond_1
    return-void
.end method

.method public final a0(II)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LI/r;->f0(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eq v0, p2, :cond_3

    .line 6
    .line 7
    if-gez p1, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, LI/r;->o:Li/v;

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    new-instance v0, Li/v;

    .line 14
    .line 15
    invoke-direct {v0}, Li/v;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, LI/r;->o:Li/v;

    .line 19
    .line 20
    :cond_0
    invoke-virtual {v0, p1, p2}, Li/v;->f(II)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_1
    iget-object v0, p0, LI/r;->n:[I

    .line 25
    .line 26
    if-nez v0, :cond_2

    .line 27
    .line 28
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 29
    .line 30
    iget v0, v0, LI/L0;->c:I

    .line 31
    .line 32
    new-array v1, v0, [I

    .line 33
    .line 34
    const/4 v2, -0x1

    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {v1, v3, v0, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 37
    .line 38
    .line 39
    iput-object v1, p0, LI/r;->n:[I

    .line 40
    .line 41
    move-object v0, v1

    .line 42
    :cond_2
    aput p2, v0, p1

    .line 43
    .line 44
    :cond_3
    return-void
.end method

.method public final b(LU1/e;Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const-string v2, "null cannot be cast to non-null type @[ExtensionFunctionType] kotlin.Function2<kotlin.Any?, kotlin.Any?, kotlin.Unit>"

    .line 5
    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, LI/r;->N:LJ/c;

    .line 11
    .line 12
    iget-object v0, v0, LJ/c;->a:LJ/J;

    .line 13
    .line 14
    sget-object v5, LJ/E;->c:LJ/E;

    .line 15
    .line 16
    invoke-virtual {v0, v5}, LJ/J;->T(LJ/H;)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0, v4, p2}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    invoke-static {p1, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v1, p1}, LV1/v;->b(ILjava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-static {v0, v3, p1}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    iget-object v0, p0, LI/r;->L:LJ/b;

    .line 33
    .line 34
    invoke-virtual {v0}, LJ/b;->b()V

    .line 35
    .line 36
    .line 37
    iget-object v0, v0, LJ/b;->b:LJ/a;

    .line 38
    .line 39
    iget-object v0, v0, LJ/a;->a:LJ/J;

    .line 40
    .line 41
    sget-object v5, LJ/E;->c:LJ/E;

    .line 42
    .line 43
    invoke-virtual {v0, v5}, LJ/J;->T(LJ/H;)V

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-static {v1, p1}, LV1/v;->b(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-static {v0, v4, p2, v3, p1}, LX1/a;->j0(LJ/J;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    return-void
.end method

.method public final b0(II)V
    .locals 6

    .line 1
    invoke-virtual {p0, p1}, LI/r;->f0(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eq v0, p2, :cond_3

    .line 6
    .line 7
    sub-int/2addr p2, v0

    .line 8
    iget-object v0, p0, LI/r;->h:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    add-int/lit8 v1, v1, -0x1

    .line 15
    .line 16
    :goto_0
    const/4 v2, -0x1

    .line 17
    if-eq p1, v2, :cond_3

    .line 18
    .line 19
    invoke-virtual {p0, p1}, LI/r;->f0(I)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    add-int/2addr v3, p2

    .line 24
    invoke-virtual {p0, p1, v3}, LI/r;->a0(II)V

    .line 25
    .line 26
    .line 27
    move v4, v1

    .line 28
    :goto_1
    if-ge v2, v4, :cond_1

    .line 29
    .line 30
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    check-cast v5, LI/p0;

    .line 35
    .line 36
    if-eqz v5, :cond_0

    .line 37
    .line 38
    invoke-virtual {v5, p1, v3}, LI/p0;->a(II)Z

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-eqz v5, :cond_0

    .line 43
    .line 44
    add-int/lit8 v4, v4, -0x1

    .line 45
    .line 46
    move v1, v4

    .line 47
    goto :goto_2

    .line 48
    :cond_0
    add-int/lit8 v4, v4, -0x1

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    :goto_2
    if-gez p1, :cond_2

    .line 52
    .line 53
    iget-object p1, p0, LI/r;->F:LI/L0;

    .line 54
    .line 55
    iget p1, p1, LI/L0;->i:I

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 59
    .line 60
    invoke-virtual {v2, p1}, LI/L0;->l(I)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-nez v2, :cond_3

    .line 65
    .line 66
    iget-object v2, p0, LI/r;->F:LI/L0;

    .line 67
    .line 68
    invoke-virtual {v2, p1}, LI/L0;->q(I)I

    .line 69
    .line 70
    .line 71
    move-result p1

    .line 72
    goto :goto_0

    .line 73
    :cond_3
    return-void
.end method

.method public final c(I)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Integer;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Number;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-ne p1, v0, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    return p1

    .line 19
    :cond_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    const/4 p1, 0x1

    .line 27
    return p1
.end method

.method public final c0(LI/q0;LQ/j;)LQ/j;
    .locals 2

    .line 1
    check-cast p1, LQ/j;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    new-instance v0, LQ/i;

    .line 7
    .line 8
    invoke-direct {v0, p1}, LQ/i;-><init>(LQ/j;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p2}, LQ/i;->putAll(Ljava/util/Map;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, LQ/i;->a()LQ/j;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    const/16 v0, 0xcc

    .line 19
    .line 20
    sget-object v1, LI/t;->d:LI/g0;

    .line 21
    .line 22
    invoke-virtual {p0, v0, v1}, LI/r;->S(ILI/g0;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, p2}, LI/r;->e0(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    const/4 p2, 0x0

    .line 38
    invoke-virtual {p0, p2}, LI/r;->p(Z)V

    .line 39
    .line 40
    .line 41
    return-object p1
.end method

.method public final d(J)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Long;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Number;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    cmp-long v0, p1, v0

    .line 16
    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    return p1

    .line 21
    :cond_0
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    const/4 p1, 0x1

    .line 29
    return p1
.end method

.method public final d0(Ljava/lang/Object;)V
    .locals 3

    .line 1
    instance-of v0, p1, LI/G0;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    new-instance v0, LI/H0;

    .line 6
    .line 7
    move-object v1, p1

    .line 8
    check-cast v1, LI/G0;

    .line 9
    .line 10
    iget v2, p0, LI/r;->l:I

    .line 11
    .line 12
    add-int/lit8 v2, v2, -0x1

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, LI/H0;-><init>(LI/G0;I)V

    .line 15
    .line 16
    .line 17
    iget-boolean v1, p0, LI/r;->Q:Z

    .line 18
    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 22
    .line 23
    iget-object v1, v1, LJ/b;->b:LJ/a;

    .line 24
    .line 25
    iget-object v1, v1, LJ/a;->a:LJ/J;

    .line 26
    .line 27
    sget-object v2, LJ/v;->c:LJ/v;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, LJ/J;->T(LJ/H;)V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-static {v1, v2, v0}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    iget-object v1, p0, LI/r;->d:Li/H;

    .line 37
    .line 38
    invoke-virtual {v1, p1}, Li/H;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-object p1, v0

    .line 42
    :cond_1
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public final e(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    const/4 p1, 0x1

    .line 15
    return p1

    .line 16
    :cond_0
    const/4 p1, 0x0

    .line 17
    return p1
.end method

.method public final e0(Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 6
    .line 7
    iget v1, v0, LI/P0;->n:I

    .line 8
    .line 9
    if-lez v1, :cond_2

    .line 10
    .line 11
    iget v1, v0, LI/P0;->i:I

    .line 12
    .line 13
    iget v2, v0, LI/P0;->k:I

    .line 14
    .line 15
    if-eq v1, v2, :cond_2

    .line 16
    .line 17
    iget-object v1, v0, LI/P0;->s:Li/x;

    .line 18
    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    new-instance v1, Li/x;

    .line 22
    .line 23
    invoke-direct {v1}, Li/x;-><init>()V

    .line 24
    .line 25
    .line 26
    :cond_0
    iput-object v1, v0, LI/P0;->s:Li/x;

    .line 27
    .line 28
    iget v0, v0, LI/P0;->v:I

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Li/l;->b(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    if-nez v2, :cond_1

    .line 35
    .line 36
    new-instance v2, Li/D;

    .line 37
    .line 38
    invoke-direct {v2}, Li/D;-><init>()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, v0, v2}, Li/x;->h(ILjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_1
    check-cast v2, Li/D;

    .line 45
    .line 46
    invoke-virtual {v2, p1}, Li/D;->a(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    invoke-virtual {v0, p1}, LI/P0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    :goto_0
    return-void

    .line 54
    :cond_3
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 55
    .line 56
    iget-boolean v1, v0, LI/L0;->n:Z

    .line 57
    .line 58
    iget-object v2, p0, LI/r;->L:LJ/b;

    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    const/4 v4, 0x1

    .line 62
    if-eqz v1, :cond_5

    .line 63
    .line 64
    iget v1, v0, LI/L0;->l:I

    .line 65
    .line 66
    iget-object v5, v0, LI/L0;->b:[I

    .line 67
    .line 68
    iget v0, v0, LI/L0;->i:I

    .line 69
    .line 70
    invoke-static {v5, v0}, LI/O0;->c([II)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    sub-int/2addr v1, v0

    .line 75
    sub-int/2addr v1, v4

    .line 76
    iget-object v0, v2, LJ/b;->a:LI/r;

    .line 77
    .line 78
    iget-object v0, v0, LI/r;->F:LI/L0;

    .line 79
    .line 80
    iget v0, v0, LI/L0;->i:I

    .line 81
    .line 82
    iget v5, v2, LJ/b;->f:I

    .line 83
    .line 84
    sub-int/2addr v0, v5

    .line 85
    if-gez v0, :cond_4

    .line 86
    .line 87
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 88
    .line 89
    iget v5, v0, LI/L0;->i:I

    .line 90
    .line 91
    invoke-virtual {v0, v5}, LI/L0;->a(I)LI/a;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    iget-object v2, v2, LJ/b;->b:LJ/a;

    .line 96
    .line 97
    iget-object v2, v2, LJ/a;->a:LJ/J;

    .line 98
    .line 99
    sget-object v5, LJ/q;->f:LJ/q;

    .line 100
    .line 101
    invoke-virtual {v2, v5}, LJ/J;->T(LJ/H;)V

    .line 102
    .line 103
    .line 104
    invoke-static {v2, v3, p1, v4, v0}, LX1/a;->j0(LJ/J;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    iget-object p1, v2, LJ/J;->c:[I

    .line 108
    .line 109
    iget v0, v2, LJ/J;->d:I

    .line 110
    .line 111
    iget-object v3, v2, LJ/J;->a:[LJ/H;

    .line 112
    .line 113
    iget v2, v2, LJ/J;->b:I

    .line 114
    .line 115
    sub-int/2addr v2, v4

    .line 116
    aget-object v2, v3, v2

    .line 117
    .line 118
    iget v2, v2, LJ/H;->a:I

    .line 119
    .line 120
    sub-int/2addr v0, v2

    .line 121
    aput v1, p1, v0

    .line 122
    .line 123
    return-void

    .line 124
    :cond_4
    invoke-virtual {v2, v4}, LJ/b;->d(Z)V

    .line 125
    .line 126
    .line 127
    iget-object v0, v2, LJ/b;->b:LJ/a;

    .line 128
    .line 129
    iget-object v0, v0, LJ/a;->a:LJ/J;

    .line 130
    .line 131
    sget-object v2, LJ/q;->g:LJ/q;

    .line 132
    .line 133
    invoke-virtual {v0, v2}, LJ/J;->T(LJ/H;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v3, p1}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    iget-object p1, v0, LJ/J;->c:[I

    .line 140
    .line 141
    iget v2, v0, LJ/J;->d:I

    .line 142
    .line 143
    iget-object v3, v0, LJ/J;->a:[LJ/H;

    .line 144
    .line 145
    iget v0, v0, LJ/J;->b:I

    .line 146
    .line 147
    sub-int/2addr v0, v4

    .line 148
    aget-object v0, v3, v0

    .line 149
    .line 150
    iget v0, v0, LJ/H;->a:I

    .line 151
    .line 152
    sub-int/2addr v2, v0

    .line 153
    aput v1, p1, v2

    .line 154
    .line 155
    return-void

    .line 156
    :cond_5
    iget v1, v0, LI/L0;->i:I

    .line 157
    .line 158
    invoke-virtual {v0, v1}, LI/L0;->a(I)LI/a;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    iget-object v1, v2, LJ/b;->b:LJ/a;

    .line 163
    .line 164
    iget-object v1, v1, LJ/a;->a:LJ/J;

    .line 165
    .line 166
    sget-object v2, LJ/e;->c:LJ/e;

    .line 167
    .line 168
    invoke-virtual {v1, v2}, LJ/J;->T(LJ/H;)V

    .line 169
    .line 170
    .line 171
    invoke-static {v1, v3, v0, v4, p1}, LX1/a;->j0(LJ/J;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    return-void
.end method

.method public final f(Z)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Boolean;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Boolean;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-ne p1, v0, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    return p1

    .line 19
    :cond_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    const/4 p1, 0x1

    .line 27
    return p1
.end method

.method public final f0(I)I
    .locals 3

    .line 1
    if-gez p1, :cond_2

    .line 2
    .line 3
    iget-object v0, p0, LI/r;->o:Li/v;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Li/v;->c(I)I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    if-ltz v2, :cond_1

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Li/v;->c(I)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-ltz v1, :cond_0

    .line 19
    .line 20
    iget-object p1, v0, Li/v;->c:[I

    .line 21
    .line 22
    aget p1, p1, v1

    .line 23
    .line 24
    return p1

    .line 25
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 26
    .line 27
    const-string v1, "Cannot find value for key "

    .line 28
    .line 29
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-static {p1}, Lj/a;->e(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const/4 p1, 0x0

    .line 43
    throw p1

    .line 44
    :cond_1
    return v1

    .line 45
    :cond_2
    iget-object v0, p0, LI/r;->n:[I

    .line 46
    .line 47
    if-eqz v0, :cond_3

    .line 48
    .line 49
    aget v0, v0, p1

    .line 50
    .line 51
    if-ltz v0, :cond_3

    .line 52
    .line 53
    return v0

    .line 54
    :cond_3
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 55
    .line 56
    invoke-virtual {v0, p1}, LI/L0;->o(I)I

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    return p1
.end method

.method public final g(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eq v0, p1, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0, p1}, LI/r;->e0(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    return p1

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    return p1
.end method

.method public final g0()V
    .locals 3

    .line 1
    iget-boolean v0, p0, LI/r;->q:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    .line 6
    .line 7
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, LI/r;->q:Z

    .line 12
    .line 13
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    const-string v0, "useNode() called while inserting"

    .line 18
    .line 19
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 23
    .line 24
    iget v1, v0, LI/L0;->i:I

    .line 25
    .line 26
    invoke-virtual {v0, v1}, LI/L0;->n(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 31
    .line 32
    invoke-virtual {v1}, LJ/b;->c()V

    .line 33
    .line 34
    .line 35
    iget-object v2, v1, LJ/b;->h:Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    iget-boolean v2, p0, LI/r;->x:Z

    .line 41
    .line 42
    if-eqz v2, :cond_3

    .line 43
    .line 44
    instance-of v2, v0, Lw0/E;

    .line 45
    .line 46
    if-eqz v2, :cond_3

    .line 47
    .line 48
    invoke-virtual {v1}, LJ/b;->b()V

    .line 49
    .line 50
    .line 51
    iget-object v1, v1, LJ/b;->b:LJ/a;

    .line 52
    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    iget-object v0, v1, LJ/a;->a:LJ/J;

    .line 56
    .line 57
    sget-object v1, LJ/G;->c:LJ/G;

    .line 58
    .line 59
    invoke-virtual {v0, v1}, LJ/J;->T(LJ/H;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    :cond_3
    return-void
.end method

.method public final h()V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, LI/r;->i:LI/p0;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    iput v1, p0, LI/r;->j:I

    .line 6
    .line 7
    iput v1, p0, LI/r;->k:I

    .line 8
    .line 9
    const-wide/16 v2, 0x0

    .line 10
    .line 11
    iput-wide v2, p0, LI/r;->R:J

    .line 12
    .line 13
    iput-boolean v1, p0, LI/r;->q:Z

    .line 14
    .line 15
    iget-object v2, p0, LI/r;->L:LJ/b;

    .line 16
    .line 17
    iput-boolean v1, v2, LJ/b;->c:Z

    .line 18
    .line 19
    iget-object v3, v2, LJ/b;->d:LI/O;

    .line 20
    .line 21
    iput v1, v3, LI/O;->b:I

    .line 22
    .line 23
    iput v1, v2, LJ/b;->f:I

    .line 24
    .line 25
    const/4 v3, 0x1

    .line 26
    iput-boolean v3, v2, LJ/b;->e:Z

    .line 27
    .line 28
    iput v1, v2, LJ/b;->g:I

    .line 29
    .line 30
    iget-object v3, v2, LJ/b;->h:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 33
    .line 34
    .line 35
    const/4 v3, -0x1

    .line 36
    iput v3, v2, LJ/b;->i:I

    .line 37
    .line 38
    iput v3, v2, LJ/b;->j:I

    .line 39
    .line 40
    iput v3, v2, LJ/b;->k:I

    .line 41
    .line 42
    iput v1, v2, LJ/b;->l:I

    .line 43
    .line 44
    iget-object v1, p0, LI/r;->D:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, LI/r;->n:[I

    .line 50
    .line 51
    iput-object v0, p0, LI/r;->o:Li/v;

    .line 52
    .line 53
    return-void
.end method

.method public final i(LI/t0;)Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LI/r;->k()LI/q0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, LI/k;->r(LI/q0;LI/t0;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public final j(LU1/a;)V
    .locals 9

    .line 1
    iget-boolean v0, p0, LI/r;->q:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    .line 6
    .line 7
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, LI/r;->q:Z

    .line 12
    .line 13
    iget-boolean v1, p0, LI/r;->Q:Z

    .line 14
    .line 15
    if-nez v1, :cond_1

    .line 16
    .line 17
    const-string v1, "createNode() can only be called when inserting"

    .line 18
    .line 19
    invoke-static {v1}, LI/t;->a(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    iget-object v1, p0, LI/r;->m:LI/O;

    .line 23
    .line 24
    iget-object v2, v1, LI/O;->a:[I

    .line 25
    .line 26
    iget v1, v1, LI/O;->b:I

    .line 27
    .line 28
    const/4 v3, 0x1

    .line 29
    sub-int/2addr v1, v3

    .line 30
    aget v1, v2, v1

    .line 31
    .line 32
    iget-object v2, p0, LI/r;->H:LI/P0;

    .line 33
    .line 34
    iget v4, v2, LI/P0;->v:I

    .line 35
    .line 36
    invoke-virtual {v2, v4}, LI/P0;->b(I)LI/a;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    iget v4, p0, LI/r;->k:I

    .line 41
    .line 42
    add-int/2addr v4, v3

    .line 43
    iput v4, p0, LI/r;->k:I

    .line 44
    .line 45
    iget-object v4, p0, LI/r;->N:LJ/c;

    .line 46
    .line 47
    iget-object v5, v4, LJ/c;->a:LJ/J;

    .line 48
    .line 49
    sget-object v6, LJ/q;->d:LJ/q;

    .line 50
    .line 51
    invoke-virtual {v5, v6}, LJ/J;->T(LJ/H;)V

    .line 52
    .line 53
    .line 54
    invoke-static {v5, v0, p1}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, v5, LJ/J;->c:[I

    .line 58
    .line 59
    iget v6, v5, LJ/J;->d:I

    .line 60
    .line 61
    iget-object v7, v5, LJ/J;->a:[LJ/H;

    .line 62
    .line 63
    iget v8, v5, LJ/J;->b:I

    .line 64
    .line 65
    sub-int/2addr v8, v3

    .line 66
    aget-object v7, v7, v8

    .line 67
    .line 68
    iget v7, v7, LJ/H;->a:I

    .line 69
    .line 70
    sub-int/2addr v6, v7

    .line 71
    aput v1, p1, v6

    .line 72
    .line 73
    invoke-static {v5, v3, v2}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    iget-object p1, v4, LJ/c;->b:LJ/J;

    .line 77
    .line 78
    sget-object v4, LJ/q;->e:LJ/q;

    .line 79
    .line 80
    invoke-virtual {p1, v4}, LJ/J;->T(LJ/H;)V

    .line 81
    .line 82
    .line 83
    iget-object v4, p1, LJ/J;->c:[I

    .line 84
    .line 85
    iget v5, p1, LJ/J;->d:I

    .line 86
    .line 87
    iget-object v6, p1, LJ/J;->a:[LJ/H;

    .line 88
    .line 89
    iget v7, p1, LJ/J;->b:I

    .line 90
    .line 91
    sub-int/2addr v7, v3

    .line 92
    aget-object v3, v6, v7

    .line 93
    .line 94
    iget v3, v3, LJ/H;->a:I

    .line 95
    .line 96
    sub-int/2addr v5, v3

    .line 97
    aput v1, v4, v5

    .line 98
    .line 99
    invoke-static {p1, v0, v2}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    return-void
.end method

.method public final k()LI/q0;
    .locals 7

    .line 1
    iget-object v0, p0, LI/r;->J:LI/q0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 7
    .line 8
    iget v0, v0, LI/L0;->i:I

    .line 9
    .line 10
    iget-boolean v1, p0, LI/r;->Q:Z

    .line 11
    .line 12
    const-string v2, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    .line 13
    .line 14
    sget-object v3, LI/t;->c:LI/g0;

    .line 15
    .line 16
    const/16 v4, 0xca

    .line 17
    .line 18
    if-eqz v1, :cond_2

    .line 19
    .line 20
    iget-boolean v1, p0, LI/r;->I:Z

    .line 21
    .line 22
    if-eqz v1, :cond_2

    .line 23
    .line 24
    iget-object v1, p0, LI/r;->H:LI/P0;

    .line 25
    .line 26
    iget v1, v1, LI/P0;->v:I

    .line 27
    .line 28
    :goto_0
    if-lez v1, :cond_2

    .line 29
    .line 30
    iget-object v5, p0, LI/r;->H:LI/P0;

    .line 31
    .line 32
    invoke-virtual {v5, v1}, LI/P0;->r(I)I

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-ne v5, v4, :cond_1

    .line 37
    .line 38
    iget-object v5, p0, LI/r;->H:LI/P0;

    .line 39
    .line 40
    invoke-virtual {v5, v1}, LI/P0;->s(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    invoke-static {v5, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v5

    .line 48
    if-eqz v5, :cond_1

    .line 49
    .line 50
    iget-object v0, p0, LI/r;->H:LI/P0;

    .line 51
    .line 52
    invoke-virtual {v0, v1}, LI/P0;->p(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    check-cast v0, LI/q0;

    .line 60
    .line 61
    iput-object v0, p0, LI/r;->J:LI/q0;

    .line 62
    .line 63
    return-object v0

    .line 64
    :cond_1
    iget-object v5, p0, LI/r;->H:LI/P0;

    .line 65
    .line 66
    iget-object v6, v5, LI/P0;->b:[I

    .line 67
    .line 68
    invoke-virtual {v5, v6, v1}, LI/P0;->D([II)I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    goto :goto_0

    .line 73
    :cond_2
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 74
    .line 75
    iget v1, v1, LI/L0;->c:I

    .line 76
    .line 77
    if-lez v1, :cond_6

    .line 78
    .line 79
    :goto_1
    if-lez v0, :cond_6

    .line 80
    .line 81
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 82
    .line 83
    invoke-virtual {v1, v0}, LI/L0;->i(I)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    if-ne v1, v4, :cond_5

    .line 88
    .line 89
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 90
    .line 91
    iget-object v5, v1, LI/L0;->b:[I

    .line 92
    .line 93
    invoke-virtual {v1, v5, v0}, LI/L0;->p([II)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    invoke-static {v1, v3}, LV1/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    if-eqz v1, :cond_5

    .line 102
    .line 103
    iget-object v1, p0, LI/r;->u:Li/x;

    .line 104
    .line 105
    if-eqz v1, :cond_3

    .line 106
    .line 107
    invoke-virtual {v1, v0}, Li/l;->b(I)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    check-cast v1, LI/q0;

    .line 112
    .line 113
    if-nez v1, :cond_4

    .line 114
    .line 115
    :cond_3
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 116
    .line 117
    iget-object v3, v1, LI/L0;->b:[I

    .line 118
    .line 119
    invoke-virtual {v1, v3, v0}, LI/L0;->b([II)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-static {v0, v2}, LV1/i;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    move-object v1, v0

    .line 127
    check-cast v1, LI/q0;

    .line 128
    .line 129
    :cond_4
    iput-object v1, p0, LI/r;->J:LI/q0;

    .line 130
    .line 131
    return-object v1

    .line 132
    :cond_5
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 133
    .line 134
    invoke-virtual {v1, v0}, LI/L0;->q(I)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    goto :goto_1

    .line 139
    :cond_6
    iget-object v0, p0, LI/r;->t:LI/q0;

    .line 140
    .line 141
    iput-object v0, p0, LI/r;->J:LI/q0;

    .line 142
    .line 143
    return-object v0
.end method

.method public final l()LV/a;
    .locals 9

    .line 1
    iget-object v0, p0, LI/r;->b:LI/v;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/v;->j()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_3

    .line 9
    .line 10
    new-instance v0, LL1/c;

    .line 11
    .line 12
    const/16 v2, 0xa

    .line 13
    .line 14
    invoke-direct {v0, v2}, LL1/c;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iget-object v2, p0, LI/r;->H:LI/P0;

    .line 18
    .line 19
    iget v3, v2, LI/P0;->t:I

    .line 20
    .line 21
    invoke-static {v2, v1, v3, v1}, LT0/l;->f(LI/P0;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, LL1/c;->addAll(Ljava/util/Collection;)Z

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 29
    .line 30
    iget-boolean v2, v1, LI/L0;->f:Z

    .line 31
    .line 32
    iget-object v3, v1, LI/L0;->b:[I

    .line 33
    .line 34
    if-nez v2, :cond_2

    .line 35
    .line 36
    iget v2, v1, LI/L0;->c:I

    .line 37
    .line 38
    if-eqz v2, :cond_2

    .line 39
    .line 40
    new-instance v2, LV/k;

    .line 41
    .line 42
    invoke-direct {v2, v1}, LV/k;-><init>(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget v4, v1, LI/L0;->i:I

    .line 46
    .line 47
    iget v5, v1, LI/L0;->l:I

    .line 48
    .line 49
    invoke-static {v3, v4}, LI/O0;->c([II)I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    sub-int/2addr v5, v6

    .line 54
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    :goto_0
    if-ltz v4, :cond_1

    .line 59
    .line 60
    invoke-virtual {v1, v4}, LI/L0;->k(I)Z

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    if-eqz v6, :cond_0

    .line 65
    .line 66
    invoke-virtual {v1, v3, v4}, LI/L0;->p([II)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v6

    .line 70
    goto :goto_1

    .line 71
    :cond_0
    sget-object v6, LI/m;->a:LI/h;

    .line 72
    .line 73
    :goto_1
    invoke-virtual {v1, v4}, LI/L0;->i(I)I

    .line 74
    .line 75
    .line 76
    move-result v7

    .line 77
    iget-object v8, v1, LI/L0;->a:LI/M0;

    .line 78
    .line 79
    invoke-virtual {v8, v4}, LI/M0;->f(I)LI/N;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    invoke-virtual {v2, v7, v6, v8, v5}, LV/b;->e(ILjava/lang/Object;LI/N;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1, v4}, LI/L0;->a(I)LI/a;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    invoke-virtual {v1, v4}, LI/L0;->q(I)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    goto :goto_0

    .line 95
    :cond_1
    iget-object v1, v2, LV/b;->a:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v1, Ljava/util/ArrayList;

    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_2
    sget-object v1, LK1/t;->d:LK1/t;

    .line 101
    .line 102
    :goto_2
    invoke-virtual {v0, v1}, LL1/c;->addAll(Ljava/util/Collection;)Z

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, LI/r;->D()Ljava/util/List;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {v0, v1}, LL1/c;->addAll(Ljava/util/Collection;)Z

    .line 110
    .line 111
    .line 112
    invoke-static {v0}, LX1/a;->F(LL1/c;)LL1/c;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    new-instance v1, LV/a;

    .line 117
    .line 118
    invoke-direct {v1, v0}, LV/a;-><init>(Ljava/util/List;)V

    .line 119
    .line 120
    .line 121
    :cond_3
    return-object v1
.end method

.method public final m()V
    .locals 1

    .line 1
    const-string v0, "Compose:Composer.dispose"

    .line 2
    .line 3
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    :try_start_0
    iget-object v0, p0, LI/r;->b:LI/v;

    .line 7
    .line 8
    invoke-virtual {v0, p0}, LI/v;->r(LI/r;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LI/r;->D:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, LI/r;->e:LJ/a;

    .line 22
    .line 23
    iget-object v0, v0, LJ/a;->a:LJ/J;

    .line 24
    .line 25
    invoke-virtual {v0}, LJ/J;->P()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    iput-object v0, p0, LI/r;->u:Li/x;

    .line 30
    .line 31
    iget-object v0, p0, LI/r;->a:LI/e0;

    .line 32
    .line 33
    invoke-virtual {v0}, LI/e0;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    .line 35
    .line 36
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :catchall_0
    move-exception v0

    .line 41
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 42
    .line 43
    .line 44
    throw v0
.end method

.method public final n(Li/E;LQ/f;)V
    .locals 9

    .line 1
    const-string v0, "Check failed"

    .line 2
    .line 3
    iget-object v1, p0, LI/r;->r:Ljava/util/ArrayList;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    iget-boolean v4, p0, LI/r;->E:Z

    .line 11
    .line 12
    if-eqz v4, :cond_0

    .line 13
    .line 14
    const-string v4, "Reentrant composition is not supported"

    .line 15
    .line 16
    invoke-static {v4}, LI/t;->a(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    const-string v4, "Compose:recompose"

    .line 20
    .line 21
    invoke-static {v4}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :try_start_0
    invoke-static {}, LU/p;->j()LU/g;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    invoke-virtual {v4}, LU/g;->g()J

    .line 29
    .line 30
    .line 31
    move-result-wide v4

    .line 32
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    iput v4, p0, LI/r;->A:I

    .line 37
    .line 38
    const/4 v4, 0x0

    .line 39
    iput-object v4, p0, LI/r;->u:Li/x;

    .line 40
    .line 41
    invoke-virtual {p0, p1}, LI/r;->Z(Li/E;)V

    .line 42
    .line 43
    .line 44
    const/4 p1, 0x0

    .line 45
    iput p1, p0, LI/r;->j:I

    .line 46
    .line 47
    iput-boolean v2, p0, LI/r;->E:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 48
    .line 49
    :try_start_1
    invoke-virtual {p0}, LI/r;->X()V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, LI/r;->C()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    if-eq v4, p2, :cond_1

    .line 57
    .line 58
    if-eqz p2, :cond_1

    .line 59
    .line 60
    invoke-virtual {p0, p2}, LI/r;->e0(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :catchall_0
    move-exception p2

    .line 65
    goto :goto_3

    .line 66
    :cond_1
    :goto_0
    iget-object v5, p0, LI/r;->C:LI/q;

    .line 67
    .line 68
    invoke-static {}, LI/k;->k()LK/e;

    .line 69
    .line 70
    .line 71
    move-result-object v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 72
    :try_start_2
    invoke-virtual {v6, v5}, LK/e;->b(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 73
    .line 74
    .line 75
    const/4 v5, 0x2

    .line 76
    sget-object v7, LI/t;->a:LI/g0;

    .line 77
    .line 78
    const/16 v8, 0xc8

    .line 79
    .line 80
    if-eqz p2, :cond_2

    .line 81
    .line 82
    :try_start_3
    invoke-virtual {p0, v8, v7}, LI/r;->S(ILI/g0;)V

    .line 83
    .line 84
    .line 85
    invoke-static {v5, p2}, LV1/v;->b(ILjava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p2, p0, v3}, LQ/f;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0, p1}, LI/r;->p(Z)V

    .line 92
    .line 93
    .line 94
    goto :goto_1

    .line 95
    :catchall_1
    move-exception p2

    .line 96
    goto :goto_2

    .line 97
    :cond_2
    iget-boolean p2, p0, LI/r;->v:Z

    .line 98
    .line 99
    if-eqz p2, :cond_3

    .line 100
    .line 101
    if-eqz v4, :cond_3

    .line 102
    .line 103
    sget-object p2, LI/m;->a:LI/h;

    .line 104
    .line 105
    invoke-virtual {v4, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result p2

    .line 109
    if-nez p2, :cond_3

    .line 110
    .line 111
    invoke-virtual {p0, v8, v7}, LI/r;->S(ILI/g0;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v5, v4}, LV1/v;->b(ILjava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    check-cast v4, LU1/e;

    .line 118
    .line 119
    invoke-static {v5, v4}, LV1/v;->b(ILjava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-interface {v4, p0, v3}, LU1/e;->g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    invoke-virtual {p0, p1}, LI/r;->p(Z)V

    .line 126
    .line 127
    .line 128
    goto :goto_1

    .line 129
    :cond_3
    invoke-virtual {p0}, LI/r;->O()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 130
    .line 131
    .line 132
    :goto_1
    :try_start_4
    iget p2, v6, LK/e;->f:I

    .line 133
    .line 134
    sub-int/2addr p2, v2

    .line 135
    invoke-virtual {v6, p2}, LK/e;->j(I)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    invoke-virtual {p0}, LI/r;->s()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 139
    .line 140
    .line 141
    :try_start_5
    iput-boolean p1, p0, LI/r;->E:Z

    .line 142
    .line 143
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 144
    .line 145
    .line 146
    iget-object p1, p0, LI/r;->H:LI/P0;

    .line 147
    .line 148
    iget-boolean p1, p1, LI/P0;->w:Z

    .line 149
    .line 150
    if-nez p1, :cond_4

    .line 151
    .line 152
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    :cond_4
    invoke-virtual {p0}, LI/r;->u()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 156
    .line 157
    .line 158
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 159
    .line 160
    .line 161
    return-void

    .line 162
    :catchall_2
    move-exception p1

    .line 163
    goto :goto_4

    .line 164
    :goto_2
    :try_start_6
    iget v3, v6, LK/e;->f:I

    .line 165
    .line 166
    sub-int/2addr v3, v2

    .line 167
    invoke-virtual {v6, v3}, LK/e;->j(I)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 171
    :goto_3
    :try_start_7
    new-instance v2, LI/n;

    .line 172
    .line 173
    const/4 v3, 0x1

    .line 174
    invoke-direct {v2, v3, p0}, LI/n;-><init>(ILI/r;)V

    .line 175
    .line 176
    .line 177
    invoke-static {p2, v2}, LT0/g;->P(Ljava/lang/Throwable;LU1/a;)Z

    .line 178
    .line 179
    .line 180
    throw p2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 181
    :catchall_3
    move-exception p2

    .line 182
    :try_start_8
    iput-boolean p1, p0, LI/r;->E:Z

    .line 183
    .line 184
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 185
    .line 186
    .line 187
    invoke-virtual {p0}, LI/r;->a()V

    .line 188
    .line 189
    .line 190
    iget-object p1, p0, LI/r;->H:LI/P0;

    .line 191
    .line 192
    iget-boolean p1, p1, LI/P0;->w:Z

    .line 193
    .line 194
    if-nez p1, :cond_5

    .line 195
    .line 196
    invoke-static {v0}, LI/t;->a(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    :cond_5
    invoke-virtual {p0}, LI/r;->u()V

    .line 200
    .line 201
    .line 202
    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 203
    :goto_4
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 204
    .line 205
    .line 206
    throw p1
.end method

.method public final o(II)V
    .locals 1

    .line 1
    if-lez p1, :cond_0

    .line 2
    .line 3
    if-eq p1, p2, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, LI/r;->F:LI/L0;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, LI/L0;->q(I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0, v0, p2}, LI/r;->o(II)V

    .line 12
    .line 13
    .line 14
    iget-object p2, p0, LI/r;->F:LI/L0;

    .line 15
    .line 16
    invoke-virtual {p2, p1}, LI/L0;->l(I)Z

    .line 17
    .line 18
    .line 19
    move-result p2

    .line 20
    if-eqz p2, :cond_0

    .line 21
    .line 22
    iget-object p2, p0, LI/r;->F:LI/L0;

    .line 23
    .line 24
    invoke-virtual {p2, p1}, LI/L0;->n(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iget-object p2, p0, LI/r;->L:LJ/b;

    .line 29
    .line 30
    invoke-virtual {p2}, LJ/b;->c()V

    .line 31
    .line 32
    .line 33
    iget-object p2, p2, LJ/b;->h:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void
.end method

.method public final p(Z)V
    .locals 42

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LI/r;->m:LI/O;

    .line 4
    .line 5
    iget-object v2, v1, LI/O;->a:[I

    .line 6
    .line 7
    iget v3, v1, LI/O;->b:I

    .line 8
    .line 9
    add-int/lit8 v3, v3, -0x2

    .line 10
    .line 11
    aget v2, v2, v3

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    sub-int/2addr v2, v3

    .line 15
    iget-boolean v4, v0, LI/r;->Q:Z

    .line 16
    .line 17
    sget-object v5, LI/m;->a:LI/h;

    .line 18
    .line 19
    const/16 v6, 0xcf

    .line 20
    .line 21
    const/4 v7, 0x0

    .line 22
    const/4 v8, 0x3

    .line 23
    if-eqz v4, :cond_3

    .line 24
    .line 25
    iget-object v4, v0, LI/r;->H:LI/P0;

    .line 26
    .line 27
    iget v9, v4, LI/P0;->v:I

    .line 28
    .line 29
    invoke-virtual {v4, v9}, LI/P0;->r(I)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    iget-object v10, v0, LI/r;->H:LI/P0;

    .line 34
    .line 35
    invoke-virtual {v10, v9}, LI/P0;->s(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v10

    .line 39
    iget-object v11, v0, LI/r;->H:LI/P0;

    .line 40
    .line 41
    invoke-virtual {v11, v9}, LI/P0;->p(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v9

    .line 45
    if-nez v10, :cond_1

    .line 46
    .line 47
    if-eqz v9, :cond_0

    .line 48
    .line 49
    if-ne v4, v6, :cond_0

    .line 50
    .line 51
    invoke-virtual {v9, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v5

    .line 55
    if-nez v5, :cond_0

    .line 56
    .line 57
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 58
    .line 59
    .line 60
    move-result v4

    .line 61
    iget-wide v5, v0, LI/r;->R:J

    .line 62
    .line 63
    int-to-long v9, v2

    .line 64
    xor-long/2addr v5, v9

    .line 65
    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 66
    .line 67
    .line 68
    move-result-wide v5

    .line 69
    int-to-long v9, v4

    .line 70
    xor-long v4, v5, v9

    .line 71
    .line 72
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 73
    .line 74
    .line 75
    move-result-wide v4

    .line 76
    iput-wide v4, v0, LI/r;->R:J

    .line 77
    .line 78
    goto/16 :goto_4

    .line 79
    .line 80
    :cond_0
    iget-wide v5, v0, LI/r;->R:J

    .line 81
    .line 82
    int-to-long v9, v2

    .line 83
    xor-long/2addr v5, v9

    .line 84
    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 85
    .line 86
    .line 87
    move-result-wide v5

    .line 88
    int-to-long v9, v4

    .line 89
    xor-long v4, v5, v9

    .line 90
    .line 91
    :goto_0
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 92
    .line 93
    .line 94
    move-result-wide v4

    .line 95
    iput-wide v4, v0, LI/r;->R:J

    .line 96
    .line 97
    goto/16 :goto_4

    .line 98
    .line 99
    :cond_1
    instance-of v2, v10, Ljava/lang/Enum;

    .line 100
    .line 101
    if-eqz v2, :cond_2

    .line 102
    .line 103
    check-cast v10, Ljava/lang/Enum;

    .line 104
    .line 105
    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    :goto_1
    iget-wide v4, v0, LI/r;->R:J

    .line 110
    .line 111
    int-to-long v9, v7

    .line 112
    xor-long/2addr v4, v9

    .line 113
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 114
    .line 115
    .line 116
    move-result-wide v4

    .line 117
    int-to-long v9, v2

    .line 118
    xor-long/2addr v4, v9

    .line 119
    goto :goto_0

    .line 120
    :cond_2
    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    .line 121
    .line 122
    .line 123
    move-result v2

    .line 124
    goto :goto_1

    .line 125
    :cond_3
    iget-object v4, v0, LI/r;->F:LI/L0;

    .line 126
    .line 127
    iget v9, v4, LI/L0;->i:I

    .line 128
    .line 129
    invoke-virtual {v4, v9}, LI/L0;->i(I)I

    .line 130
    .line 131
    .line 132
    move-result v4

    .line 133
    iget-object v10, v0, LI/r;->F:LI/L0;

    .line 134
    .line 135
    iget-object v11, v10, LI/L0;->b:[I

    .line 136
    .line 137
    invoke-virtual {v10, v11, v9}, LI/L0;->p([II)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v10

    .line 141
    iget-object v11, v0, LI/r;->F:LI/L0;

    .line 142
    .line 143
    iget-object v12, v11, LI/L0;->b:[I

    .line 144
    .line 145
    invoke-virtual {v11, v12, v9}, LI/L0;->b([II)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v9

    .line 149
    if-nez v10, :cond_5

    .line 150
    .line 151
    if-eqz v9, :cond_4

    .line 152
    .line 153
    if-ne v4, v6, :cond_4

    .line 154
    .line 155
    invoke-virtual {v9, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v5

    .line 159
    if-nez v5, :cond_4

    .line 160
    .line 161
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 162
    .line 163
    .line 164
    move-result v4

    .line 165
    iget-wide v5, v0, LI/r;->R:J

    .line 166
    .line 167
    int-to-long v9, v2

    .line 168
    xor-long/2addr v5, v9

    .line 169
    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 170
    .line 171
    .line 172
    move-result-wide v5

    .line 173
    int-to-long v9, v4

    .line 174
    xor-long v4, v5, v9

    .line 175
    .line 176
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 177
    .line 178
    .line 179
    move-result-wide v4

    .line 180
    iput-wide v4, v0, LI/r;->R:J

    .line 181
    .line 182
    goto :goto_4

    .line 183
    :cond_4
    iget-wide v5, v0, LI/r;->R:J

    .line 184
    .line 185
    int-to-long v9, v2

    .line 186
    xor-long/2addr v5, v9

    .line 187
    invoke-static {v5, v6, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 188
    .line 189
    .line 190
    move-result-wide v5

    .line 191
    int-to-long v9, v4

    .line 192
    xor-long v4, v5, v9

    .line 193
    .line 194
    :goto_2
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 195
    .line 196
    .line 197
    move-result-wide v4

    .line 198
    iput-wide v4, v0, LI/r;->R:J

    .line 199
    .line 200
    goto :goto_4

    .line 201
    :cond_5
    instance-of v2, v10, Ljava/lang/Enum;

    .line 202
    .line 203
    if-eqz v2, :cond_6

    .line 204
    .line 205
    check-cast v10, Ljava/lang/Enum;

    .line 206
    .line 207
    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    .line 208
    .line 209
    .line 210
    move-result v2

    .line 211
    :goto_3
    iget-wide v4, v0, LI/r;->R:J

    .line 212
    .line 213
    int-to-long v9, v7

    .line 214
    xor-long/2addr v4, v9

    .line 215
    invoke-static {v4, v5, v8}, Ljava/lang/Long;->rotateRight(JI)J

    .line 216
    .line 217
    .line 218
    move-result-wide v4

    .line 219
    int-to-long v9, v2

    .line 220
    xor-long/2addr v4, v9

    .line 221
    goto :goto_2

    .line 222
    :cond_6
    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    .line 223
    .line 224
    .line 225
    move-result v2

    .line 226
    goto :goto_3

    .line 227
    :goto_4
    iget v2, v0, LI/r;->k:I

    .line 228
    .line 229
    iget-object v4, v0, LI/r;->i:LI/p0;

    .line 230
    .line 231
    iget-object v5, v0, LI/r;->r:Ljava/util/ArrayList;

    .line 232
    .line 233
    iget-object v9, v0, LI/r;->L:LJ/b;

    .line 234
    .line 235
    if-eqz v4, :cond_22

    .line 236
    .line 237
    iget-object v10, v4, LI/p0;->e:Li/x;

    .line 238
    .line 239
    iget v11, v4, LI/p0;->b:I

    .line 240
    .line 241
    iget-object v12, v4, LI/p0;->a:Ljava/util/ArrayList;

    .line 242
    .line 243
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 244
    .line 245
    .line 246
    move-result v13

    .line 247
    if-lez v13, :cond_22

    .line 248
    .line 249
    iget-object v13, v4, LI/p0;->d:Ljava/util/ArrayList;

    .line 250
    .line 251
    new-instance v14, Ljava/util/HashSet;

    .line 252
    .line 253
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 254
    .line 255
    .line 256
    move-result v15

    .line 257
    invoke-direct {v14, v15}, Ljava/util/HashSet;-><init>(I)V

    .line 258
    .line 259
    .line 260
    invoke-interface {v13}, Ljava/util/Collection;->size()I

    .line 261
    .line 262
    .line 263
    move-result v15

    .line 264
    move/from16 v16, v8

    .line 265
    .line 266
    move v8, v7

    .line 267
    :goto_5
    if-ge v8, v15, :cond_7

    .line 268
    .line 269
    const/16 v17, -0x1

    .line 270
    .line 271
    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object v6

    .line 275
    invoke-virtual {v14, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 276
    .line 277
    .line 278
    add-int/lit8 v8, v8, 0x1

    .line 279
    .line 280
    goto :goto_5

    .line 281
    :cond_7
    const/16 v17, -0x1

    .line 282
    .line 283
    new-instance v6, Ljava/util/LinkedHashSet;

    .line 284
    .line 285
    invoke-direct {v6}, Ljava/util/LinkedHashSet;-><init>()V

    .line 286
    .line 287
    .line 288
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 289
    .line 290
    .line 291
    move-result v8

    .line 292
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 293
    .line 294
    .line 295
    move-result v15

    .line 296
    move v3, v7

    .line 297
    move/from16 v19, v3

    .line 298
    .line 299
    move/from16 v20, v19

    .line 300
    .line 301
    :goto_6
    if-ge v3, v15, :cond_21

    .line 302
    .line 303
    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v21

    .line 307
    move-object/from16 v7, v21

    .line 308
    .line 309
    check-cast v7, LI/T;

    .line 310
    .line 311
    invoke-virtual {v14, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    move-result v21

    .line 315
    if-nez v21, :cond_9

    .line 316
    .line 317
    move-object/from16 v21, v1

    .line 318
    .line 319
    iget v1, v7, LI/T;->c:I

    .line 320
    .line 321
    invoke-virtual {v10, v1}, Li/l;->b(I)Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    check-cast v1, LI/L;

    .line 326
    .line 327
    if-eqz v1, :cond_8

    .line 328
    .line 329
    iget v1, v1, LI/L;->b:I

    .line 330
    .line 331
    move/from16 v22, v1

    .line 332
    .line 333
    goto :goto_7

    .line 334
    :cond_8
    move/from16 v22, v17

    .line 335
    .line 336
    :goto_7
    iget v1, v7, LI/T;->c:I

    .line 337
    .line 338
    move/from16 v23, v3

    .line 339
    .line 340
    add-int v3, v22, v11

    .line 341
    .line 342
    iget v7, v7, LI/T;->d:I

    .line 343
    .line 344
    invoke-virtual {v9, v3, v7}, LJ/b;->e(II)V

    .line 345
    .line 346
    .line 347
    const/4 v3, 0x0

    .line 348
    invoke-virtual {v4, v1, v3}, LI/p0;->a(II)Z

    .line 349
    .line 350
    .line 351
    iget v3, v9, LJ/b;->f:I

    .line 352
    .line 353
    iget-object v7, v9, LJ/b;->a:LI/r;

    .line 354
    .line 355
    iget-object v7, v7, LI/r;->F:LI/L0;

    .line 356
    .line 357
    iget v7, v7, LI/L0;->g:I

    .line 358
    .line 359
    sub-int v7, v1, v7

    .line 360
    .line 361
    add-int/2addr v7, v3

    .line 362
    iput v7, v9, LJ/b;->f:I

    .line 363
    .line 364
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 365
    .line 366
    invoke-virtual {v3, v1}, LI/L0;->r(I)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v0}, LI/r;->H()V

    .line 370
    .line 371
    .line 372
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 373
    .line 374
    invoke-virtual {v3}, LI/L0;->s()I

    .line 375
    .line 376
    .line 377
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 378
    .line 379
    iget-object v3, v3, LI/L0;->b:[I

    .line 380
    .line 381
    mul-int/lit8 v7, v1, 0x5

    .line 382
    .line 383
    add-int/lit8 v7, v7, 0x3

    .line 384
    .line 385
    aget v3, v3, v7

    .line 386
    .line 387
    add-int/2addr v3, v1

    .line 388
    invoke-static {v5, v1, v3}, LI/k;->f(Ljava/util/ArrayList;II)V

    .line 389
    .line 390
    .line 391
    :goto_8
    add-int/lit8 v3, v23, 0x1

    .line 392
    .line 393
    move-object/from16 v1, v21

    .line 394
    .line 395
    :goto_9
    const/4 v7, 0x0

    .line 396
    goto :goto_6

    .line 397
    :cond_9
    move-object/from16 v21, v1

    .line 398
    .line 399
    move/from16 v23, v3

    .line 400
    .line 401
    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 402
    .line 403
    .line 404
    move-result v1

    .line 405
    if-eqz v1, :cond_a

    .line 406
    .line 407
    goto :goto_8

    .line 408
    :cond_a
    move/from16 v1, v19

    .line 409
    .line 410
    if-ge v1, v8, :cond_20

    .line 411
    .line 412
    invoke-virtual {v13, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v3

    .line 416
    check-cast v3, LI/T;

    .line 417
    .line 418
    if-eq v3, v7, :cond_1e

    .line 419
    .line 420
    iget v7, v3, LI/T;->c:I

    .line 421
    .line 422
    invoke-virtual {v10, v7}, Li/l;->b(I)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v7

    .line 426
    check-cast v7, LI/L;

    .line 427
    .line 428
    if-eqz v7, :cond_b

    .line 429
    .line 430
    iget v7, v7, LI/L;->b:I

    .line 431
    .line 432
    goto :goto_a

    .line 433
    :cond_b
    move/from16 v7, v17

    .line 434
    .line 435
    :goto_a
    invoke-interface {v6, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 436
    .line 437
    .line 438
    move/from16 v19, v1

    .line 439
    .line 440
    move/from16 v1, v20

    .line 441
    .line 442
    move-object/from16 v20, v4

    .line 443
    .line 444
    if-eq v7, v1, :cond_1c

    .line 445
    .line 446
    iget v4, v3, LI/T;->c:I

    .line 447
    .line 448
    invoke-virtual {v10, v4}, Li/l;->b(I)Ljava/lang/Object;

    .line 449
    .line 450
    .line 451
    move-result-object v4

    .line 452
    check-cast v4, LI/L;

    .line 453
    .line 454
    if-eqz v4, :cond_c

    .line 455
    .line 456
    iget v4, v4, LI/L;->c:I

    .line 457
    .line 458
    :goto_b
    move-object/from16 v22, v6

    .line 459
    .line 460
    goto :goto_c

    .line 461
    :cond_c
    iget v4, v3, LI/T;->d:I

    .line 462
    .line 463
    goto :goto_b

    .line 464
    :goto_c
    add-int v6, v7, v11

    .line 465
    .line 466
    move/from16 v24, v8

    .line 467
    .line 468
    add-int v8, v1, v11

    .line 469
    .line 470
    if-lez v4, :cond_f

    .line 471
    .line 472
    move/from16 v25, v11

    .line 473
    .line 474
    iget v11, v9, LJ/b;->l:I

    .line 475
    .line 476
    if-lez v11, :cond_d

    .line 477
    .line 478
    move/from16 v26, v11

    .line 479
    .line 480
    iget v11, v9, LJ/b;->j:I

    .line 481
    .line 482
    move-object/from16 v27, v12

    .line 483
    .line 484
    sub-int v12, v6, v26

    .line 485
    .line 486
    if-ne v11, v12, :cond_e

    .line 487
    .line 488
    iget v11, v9, LJ/b;->k:I

    .line 489
    .line 490
    sub-int v12, v8, v26

    .line 491
    .line 492
    if-ne v11, v12, :cond_e

    .line 493
    .line 494
    add-int v11, v26, v4

    .line 495
    .line 496
    iput v11, v9, LJ/b;->l:I

    .line 497
    .line 498
    goto :goto_d

    .line 499
    :cond_d
    move-object/from16 v27, v12

    .line 500
    .line 501
    :cond_e
    invoke-virtual {v9}, LJ/b;->c()V

    .line 502
    .line 503
    .line 504
    iput v6, v9, LJ/b;->j:I

    .line 505
    .line 506
    iput v8, v9, LJ/b;->k:I

    .line 507
    .line 508
    iput v4, v9, LJ/b;->l:I

    .line 509
    .line 510
    goto :goto_d

    .line 511
    :cond_f
    move/from16 v25, v11

    .line 512
    .line 513
    move-object/from16 v27, v12

    .line 514
    .line 515
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 516
    .line 517
    .line 518
    :goto_d
    const-wide/16 v28, 0xff

    .line 519
    .line 520
    const-wide v30, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    if-le v7, v1, :cond_16

    .line 526
    .line 527
    const/16 v26, 0x7

    .line 528
    .line 529
    iget-object v6, v10, Li/l;->c:[Ljava/lang/Object;

    .line 530
    .line 531
    const-wide/16 v32, 0x80

    .line 532
    .line 533
    iget-object v11, v10, Li/l;->a:[J

    .line 534
    .line 535
    array-length v12, v11

    .line 536
    add-int/lit8 v12, v12, -0x2

    .line 537
    .line 538
    if-ltz v12, :cond_15

    .line 539
    .line 540
    move-object/from16 v35, v13

    .line 541
    .line 542
    move-object/from16 v36, v14

    .line 543
    .line 544
    const/4 v8, 0x0

    .line 545
    :goto_e
    const/16 v34, 0x8

    .line 546
    .line 547
    aget-wide v13, v11, v8

    .line 548
    .line 549
    move/from16 v38, v4

    .line 550
    .line 551
    move-object/from16 v37, v5

    .line 552
    .line 553
    not-long v4, v13

    .line 554
    shl-long v4, v4, v26

    .line 555
    .line 556
    and-long/2addr v4, v13

    .line 557
    and-long v4, v4, v30

    .line 558
    .line 559
    cmp-long v4, v4, v30

    .line 560
    .line 561
    if-eqz v4, :cond_14

    .line 562
    .line 563
    sub-int v4, v8, v12

    .line 564
    .line 565
    not-int v4, v4

    .line 566
    ushr-int/lit8 v4, v4, 0x1f

    .line 567
    .line 568
    rsub-int/lit8 v4, v4, 0x8

    .line 569
    .line 570
    const/4 v5, 0x0

    .line 571
    :goto_f
    if-ge v5, v4, :cond_13

    .line 572
    .line 573
    and-long v39, v13, v28

    .line 574
    .line 575
    cmp-long v39, v39, v32

    .line 576
    .line 577
    if-gez v39, :cond_11

    .line 578
    .line 579
    shl-int/lit8 v39, v8, 0x3

    .line 580
    .line 581
    add-int v39, v39, v5

    .line 582
    .line 583
    aget-object v39, v6, v39

    .line 584
    .line 585
    move/from16 v40, v5

    .line 586
    .line 587
    move-object/from16 v5, v39

    .line 588
    .line 589
    check-cast v5, LI/L;

    .line 590
    .line 591
    move-object/from16 v39, v6

    .line 592
    .line 593
    iget v6, v5, LI/L;->b:I

    .line 594
    .line 595
    move-object/from16 v41, v11

    .line 596
    .line 597
    if-gt v7, v6, :cond_10

    .line 598
    .line 599
    add-int v11, v7, v38

    .line 600
    .line 601
    if-ge v6, v11, :cond_10

    .line 602
    .line 603
    sub-int/2addr v6, v7

    .line 604
    add-int/2addr v6, v1

    .line 605
    iput v6, v5, LI/L;->b:I

    .line 606
    .line 607
    goto :goto_10

    .line 608
    :cond_10
    if-gt v1, v6, :cond_12

    .line 609
    .line 610
    if-ge v6, v7, :cond_12

    .line 611
    .line 612
    add-int v6, v6, v38

    .line 613
    .line 614
    iput v6, v5, LI/L;->b:I

    .line 615
    .line 616
    goto :goto_10

    .line 617
    :cond_11
    move/from16 v40, v5

    .line 618
    .line 619
    move-object/from16 v39, v6

    .line 620
    .line 621
    move-object/from16 v41, v11

    .line 622
    .line 623
    :cond_12
    :goto_10
    shr-long v13, v13, v34

    .line 624
    .line 625
    add-int/lit8 v5, v40, 0x1

    .line 626
    .line 627
    move-object/from16 v6, v39

    .line 628
    .line 629
    move-object/from16 v11, v41

    .line 630
    .line 631
    goto :goto_f

    .line 632
    :cond_13
    move-object/from16 v39, v6

    .line 633
    .line 634
    move-object/from16 v41, v11

    .line 635
    .line 636
    move/from16 v5, v34

    .line 637
    .line 638
    if-ne v4, v5, :cond_1d

    .line 639
    .line 640
    goto :goto_11

    .line 641
    :cond_14
    move-object/from16 v39, v6

    .line 642
    .line 643
    move-object/from16 v41, v11

    .line 644
    .line 645
    :goto_11
    if-eq v8, v12, :cond_1d

    .line 646
    .line 647
    add-int/lit8 v8, v8, 0x1

    .line 648
    .line 649
    move-object/from16 v5, v37

    .line 650
    .line 651
    move/from16 v4, v38

    .line 652
    .line 653
    move-object/from16 v6, v39

    .line 654
    .line 655
    move-object/from16 v11, v41

    .line 656
    .line 657
    goto :goto_e

    .line 658
    :cond_15
    move-object/from16 v37, v5

    .line 659
    .line 660
    goto/16 :goto_17

    .line 661
    .line 662
    :cond_16
    move/from16 v38, v4

    .line 663
    .line 664
    move-object/from16 v37, v5

    .line 665
    .line 666
    move-object/from16 v35, v13

    .line 667
    .line 668
    move-object/from16 v36, v14

    .line 669
    .line 670
    const/16 v26, 0x7

    .line 671
    .line 672
    const-wide/16 v32, 0x80

    .line 673
    .line 674
    if-le v1, v7, :cond_1d

    .line 675
    .line 676
    iget-object v4, v10, Li/l;->c:[Ljava/lang/Object;

    .line 677
    .line 678
    iget-object v5, v10, Li/l;->a:[J

    .line 679
    .line 680
    array-length v6, v5

    .line 681
    add-int/lit8 v6, v6, -0x2

    .line 682
    .line 683
    if-ltz v6, :cond_1d

    .line 684
    .line 685
    const/4 v8, 0x0

    .line 686
    :goto_12
    aget-wide v11, v5, v8

    .line 687
    .line 688
    not-long v13, v11

    .line 689
    shl-long v13, v13, v26

    .line 690
    .line 691
    and-long/2addr v13, v11

    .line 692
    and-long v13, v13, v30

    .line 693
    .line 694
    cmp-long v13, v13, v30

    .line 695
    .line 696
    if-eqz v13, :cond_1b

    .line 697
    .line 698
    sub-int v13, v8, v6

    .line 699
    .line 700
    not-int v13, v13

    .line 701
    ushr-int/lit8 v13, v13, 0x1f

    .line 702
    .line 703
    const/16 v34, 0x8

    .line 704
    .line 705
    rsub-int/lit8 v13, v13, 0x8

    .line 706
    .line 707
    const/4 v14, 0x0

    .line 708
    :goto_13
    if-ge v14, v13, :cond_1a

    .line 709
    .line 710
    and-long v39, v11, v28

    .line 711
    .line 712
    cmp-long v39, v39, v32

    .line 713
    .line 714
    if-gez v39, :cond_19

    .line 715
    .line 716
    shl-int/lit8 v39, v8, 0x3

    .line 717
    .line 718
    add-int v39, v39, v14

    .line 719
    .line 720
    aget-object v39, v4, v39

    .line 721
    .line 722
    move-object/from16 v40, v4

    .line 723
    .line 724
    move-object/from16 v4, v39

    .line 725
    .line 726
    check-cast v4, LI/L;

    .line 727
    .line 728
    move-object/from16 v39, v5

    .line 729
    .line 730
    iget v5, v4, LI/L;->b:I

    .line 731
    .line 732
    move/from16 v41, v7

    .line 733
    .line 734
    if-gt v7, v5, :cond_17

    .line 735
    .line 736
    add-int v7, v41, v38

    .line 737
    .line 738
    if-ge v5, v7, :cond_17

    .line 739
    .line 740
    sub-int v5, v5, v41

    .line 741
    .line 742
    add-int/2addr v5, v1

    .line 743
    iput v5, v4, LI/L;->b:I

    .line 744
    .line 745
    goto :goto_14

    .line 746
    :cond_17
    add-int/lit8 v7, v41, 0x1

    .line 747
    .line 748
    if-gt v7, v5, :cond_18

    .line 749
    .line 750
    if-ge v5, v1, :cond_18

    .line 751
    .line 752
    sub-int v5, v5, v38

    .line 753
    .line 754
    iput v5, v4, LI/L;->b:I

    .line 755
    .line 756
    :cond_18
    :goto_14
    const/16 v5, 0x8

    .line 757
    .line 758
    goto :goto_15

    .line 759
    :cond_19
    move-object/from16 v40, v4

    .line 760
    .line 761
    move-object/from16 v39, v5

    .line 762
    .line 763
    move/from16 v41, v7

    .line 764
    .line 765
    goto :goto_14

    .line 766
    :goto_15
    shr-long/2addr v11, v5

    .line 767
    add-int/lit8 v14, v14, 0x1

    .line 768
    .line 769
    move-object/from16 v5, v39

    .line 770
    .line 771
    move-object/from16 v4, v40

    .line 772
    .line 773
    move/from16 v7, v41

    .line 774
    .line 775
    goto :goto_13

    .line 776
    :cond_1a
    move-object/from16 v40, v4

    .line 777
    .line 778
    move-object/from16 v39, v5

    .line 779
    .line 780
    move/from16 v41, v7

    .line 781
    .line 782
    const/16 v5, 0x8

    .line 783
    .line 784
    if-ne v13, v5, :cond_1d

    .line 785
    .line 786
    goto :goto_16

    .line 787
    :cond_1b
    move-object/from16 v40, v4

    .line 788
    .line 789
    move-object/from16 v39, v5

    .line 790
    .line 791
    move/from16 v41, v7

    .line 792
    .line 793
    const/16 v5, 0x8

    .line 794
    .line 795
    :goto_16
    if-eq v8, v6, :cond_1d

    .line 796
    .line 797
    add-int/lit8 v8, v8, 0x1

    .line 798
    .line 799
    move-object/from16 v5, v39

    .line 800
    .line 801
    move-object/from16 v4, v40

    .line 802
    .line 803
    move/from16 v7, v41

    .line 804
    .line 805
    goto :goto_12

    .line 806
    :cond_1c
    move-object/from16 v37, v5

    .line 807
    .line 808
    move-object/from16 v22, v6

    .line 809
    .line 810
    move/from16 v24, v8

    .line 811
    .line 812
    move/from16 v25, v11

    .line 813
    .line 814
    move-object/from16 v27, v12

    .line 815
    .line 816
    :goto_17
    move-object/from16 v35, v13

    .line 817
    .line 818
    move-object/from16 v36, v14

    .line 819
    .line 820
    :cond_1d
    move/from16 v4, v23

    .line 821
    .line 822
    goto :goto_18

    .line 823
    :cond_1e
    move/from16 v19, v1

    .line 824
    .line 825
    move-object/from16 v37, v5

    .line 826
    .line 827
    move-object/from16 v22, v6

    .line 828
    .line 829
    move/from16 v24, v8

    .line 830
    .line 831
    move/from16 v25, v11

    .line 832
    .line 833
    move-object/from16 v27, v12

    .line 834
    .line 835
    move-object/from16 v35, v13

    .line 836
    .line 837
    move-object/from16 v36, v14

    .line 838
    .line 839
    move/from16 v1, v20

    .line 840
    .line 841
    move-object/from16 v20, v4

    .line 842
    .line 843
    add-int/lit8 v4, v23, 0x1

    .line 844
    .line 845
    :goto_18
    add-int/lit8 v19, v19, 0x1

    .line 846
    .line 847
    iget v5, v3, LI/T;->c:I

    .line 848
    .line 849
    invoke-virtual {v10, v5}, Li/l;->b(I)Ljava/lang/Object;

    .line 850
    .line 851
    .line 852
    move-result-object v5

    .line 853
    check-cast v5, LI/L;

    .line 854
    .line 855
    if-eqz v5, :cond_1f

    .line 856
    .line 857
    iget v3, v5, LI/L;->c:I

    .line 858
    .line 859
    goto :goto_19

    .line 860
    :cond_1f
    iget v3, v3, LI/T;->d:I

    .line 861
    .line 862
    :goto_19
    add-int/2addr v1, v3

    .line 863
    move v3, v4

    .line 864
    move-object/from16 v4, v20

    .line 865
    .line 866
    move-object/from16 v6, v22

    .line 867
    .line 868
    move/from16 v8, v24

    .line 869
    .line 870
    move/from16 v11, v25

    .line 871
    .line 872
    move-object/from16 v12, v27

    .line 873
    .line 874
    move-object/from16 v13, v35

    .line 875
    .line 876
    move-object/from16 v14, v36

    .line 877
    .line 878
    move-object/from16 v5, v37

    .line 879
    .line 880
    const/4 v7, 0x0

    .line 881
    move/from16 v20, v1

    .line 882
    .line 883
    move-object/from16 v1, v21

    .line 884
    .line 885
    goto/16 :goto_6

    .line 886
    .line 887
    :cond_20
    move/from16 v19, v1

    .line 888
    .line 889
    move/from16 v1, v20

    .line 890
    .line 891
    move-object/from16 v1, v21

    .line 892
    .line 893
    move/from16 v3, v23

    .line 894
    .line 895
    goto/16 :goto_9

    .line 896
    .line 897
    :cond_21
    move-object/from16 v21, v1

    .line 898
    .line 899
    move-object/from16 v37, v5

    .line 900
    .line 901
    move-object/from16 v27, v12

    .line 902
    .line 903
    invoke-virtual {v9}, LJ/b;->c()V

    .line 904
    .line 905
    .line 906
    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    .line 907
    .line 908
    .line 909
    move-result v1

    .line 910
    if-lez v1, :cond_23

    .line 911
    .line 912
    iget-object v1, v0, LI/r;->F:LI/L0;

    .line 913
    .line 914
    iget v3, v1, LI/L0;->h:I

    .line 915
    .line 916
    iget v4, v9, LJ/b;->f:I

    .line 917
    .line 918
    iget-object v5, v9, LJ/b;->a:LI/r;

    .line 919
    .line 920
    iget-object v5, v5, LI/r;->F:LI/L0;

    .line 921
    .line 922
    iget v5, v5, LI/L0;->g:I

    .line 923
    .line 924
    sub-int/2addr v3, v5

    .line 925
    add-int/2addr v3, v4

    .line 926
    iput v3, v9, LJ/b;->f:I

    .line 927
    .line 928
    invoke-virtual {v1}, LI/L0;->t()V

    .line 929
    .line 930
    .line 931
    goto :goto_1a

    .line 932
    :cond_22
    move-object/from16 v21, v1

    .line 933
    .line 934
    move-object/from16 v37, v5

    .line 935
    .line 936
    const/16 v17, -0x1

    .line 937
    .line 938
    :cond_23
    :goto_1a
    iget-boolean v1, v0, LI/r;->Q:Z

    .line 939
    .line 940
    const/4 v3, -0x2

    .line 941
    if-nez v1, :cond_27

    .line 942
    .line 943
    iget-object v4, v0, LI/r;->F:LI/L0;

    .line 944
    .line 945
    iget v5, v4, LI/L0;->m:I

    .line 946
    .line 947
    iget v4, v4, LI/L0;->l:I

    .line 948
    .line 949
    sub-int/2addr v5, v4

    .line 950
    if-lez v5, :cond_27

    .line 951
    .line 952
    if-lez v5, :cond_26

    .line 953
    .line 954
    const/4 v4, 0x0

    .line 955
    invoke-virtual {v9, v4}, LJ/b;->d(Z)V

    .line 956
    .line 957
    .line 958
    iget-object v4, v9, LJ/b;->d:LI/O;

    .line 959
    .line 960
    iget-object v6, v9, LJ/b;->a:LI/r;

    .line 961
    .line 962
    iget-object v6, v6, LI/r;->F:LI/L0;

    .line 963
    .line 964
    iget v7, v6, LI/L0;->c:I

    .line 965
    .line 966
    if-lez v7, :cond_25

    .line 967
    .line 968
    iget v7, v6, LI/L0;->i:I

    .line 969
    .line 970
    invoke-virtual {v4, v3}, LI/O;->a(I)I

    .line 971
    .line 972
    .line 973
    move-result v8

    .line 974
    if-eq v8, v7, :cond_25

    .line 975
    .line 976
    iget-boolean v8, v9, LJ/b;->c:Z

    .line 977
    .line 978
    if-nez v8, :cond_24

    .line 979
    .line 980
    iget-boolean v8, v9, LJ/b;->e:Z

    .line 981
    .line 982
    if-eqz v8, :cond_24

    .line 983
    .line 984
    const/4 v8, 0x0

    .line 985
    invoke-virtual {v9, v8}, LJ/b;->d(Z)V

    .line 986
    .line 987
    .line 988
    iget-object v8, v9, LJ/b;->b:LJ/a;

    .line 989
    .line 990
    iget-object v8, v8, LJ/a;->a:LJ/J;

    .line 991
    .line 992
    sget-object v10, LJ/p;->c:LJ/p;

    .line 993
    .line 994
    invoke-virtual {v8, v10}, LJ/J;->T(LJ/H;)V

    .line 995
    .line 996
    .line 997
    const/4 v8, 0x1

    .line 998
    iput-boolean v8, v9, LJ/b;->c:Z

    .line 999
    .line 1000
    :cond_24
    if-lez v7, :cond_25

    .line 1001
    .line 1002
    invoke-virtual {v6, v7}, LI/L0;->a(I)LI/a;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v6

    .line 1006
    invoke-virtual {v4, v7}, LI/O;->c(I)V

    .line 1007
    .line 1008
    .line 1009
    const/4 v4, 0x0

    .line 1010
    invoke-virtual {v9, v4}, LJ/b;->d(Z)V

    .line 1011
    .line 1012
    .line 1013
    iget-object v7, v9, LJ/b;->b:LJ/a;

    .line 1014
    .line 1015
    iget-object v7, v7, LJ/a;->a:LJ/J;

    .line 1016
    .line 1017
    sget-object v8, LJ/o;->c:LJ/o;

    .line 1018
    .line 1019
    invoke-virtual {v7, v8}, LJ/J;->T(LJ/H;)V

    .line 1020
    .line 1021
    .line 1022
    invoke-static {v7, v4, v6}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 1023
    .line 1024
    .line 1025
    const/4 v8, 0x1

    .line 1026
    iput-boolean v8, v9, LJ/b;->c:Z

    .line 1027
    .line 1028
    :cond_25
    iget-object v4, v9, LJ/b;->b:LJ/a;

    .line 1029
    .line 1030
    iget-object v4, v4, LJ/a;->a:LJ/J;

    .line 1031
    .line 1032
    sget-object v6, LJ/C;->c:LJ/C;

    .line 1033
    .line 1034
    invoke-virtual {v4, v6}, LJ/J;->T(LJ/H;)V

    .line 1035
    .line 1036
    .line 1037
    iget-object v6, v4, LJ/J;->c:[I

    .line 1038
    .line 1039
    iget v7, v4, LJ/J;->d:I

    .line 1040
    .line 1041
    iget-object v8, v4, LJ/J;->a:[LJ/H;

    .line 1042
    .line 1043
    iget v4, v4, LJ/J;->b:I

    .line 1044
    .line 1045
    const/16 v18, 0x1

    .line 1046
    .line 1047
    add-int/lit8 v4, v4, -0x1

    .line 1048
    .line 1049
    aget-object v4, v8, v4

    .line 1050
    .line 1051
    iget v4, v4, LJ/H;->a:I

    .line 1052
    .line 1053
    sub-int/2addr v7, v4

    .line 1054
    aput v5, v6, v7

    .line 1055
    .line 1056
    goto :goto_1b

    .line 1057
    :cond_26
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1058
    .line 1059
    .line 1060
    :cond_27
    :goto_1b
    iget v4, v0, LI/r;->j:I

    .line 1061
    .line 1062
    :goto_1c
    iget-object v5, v0, LI/r;->F:LI/L0;

    .line 1063
    .line 1064
    iget v6, v5, LI/L0;->k:I

    .line 1065
    .line 1066
    if-lez v6, :cond_28

    .line 1067
    .line 1068
    goto :goto_1d

    .line 1069
    :cond_28
    iget v6, v5, LI/L0;->g:I

    .line 1070
    .line 1071
    iget v5, v5, LI/L0;->h:I

    .line 1072
    .line 1073
    if-ne v6, v5, :cond_3a

    .line 1074
    .line 1075
    :goto_1d
    if-eqz v1, :cond_33

    .line 1076
    .line 1077
    if-eqz p1, :cond_2a

    .line 1078
    .line 1079
    iget-object v2, v0, LI/r;->N:LJ/c;

    .line 1080
    .line 1081
    iget-object v4, v2, LJ/c;->b:LJ/J;

    .line 1082
    .line 1083
    invoke-virtual {v4}, LJ/J;->S()Z

    .line 1084
    .line 1085
    .line 1086
    move-result v5

    .line 1087
    if-nez v5, :cond_29

    .line 1088
    .line 1089
    const-string v5, "Cannot end node insertion, there are no pending operations that can be realized."

    .line 1090
    .line 1091
    invoke-static {v5}, LI/t;->a(Ljava/lang/String;)V

    .line 1092
    .line 1093
    .line 1094
    :cond_29
    iget-object v2, v2, LJ/c;->a:LJ/J;

    .line 1095
    .line 1096
    iget-object v5, v4, LJ/J;->a:[LJ/H;

    .line 1097
    .line 1098
    iget v6, v4, LJ/J;->b:I

    .line 1099
    .line 1100
    add-int/lit8 v6, v6, -0x1

    .line 1101
    .line 1102
    iput v6, v4, LJ/J;->b:I

    .line 1103
    .line 1104
    aget-object v7, v5, v6

    .line 1105
    .line 1106
    const/4 v8, 0x0

    .line 1107
    aput-object v8, v5, v6

    .line 1108
    .line 1109
    invoke-virtual {v2, v7}, LJ/J;->T(LJ/H;)V

    .line 1110
    .line 1111
    .line 1112
    iget-object v5, v4, LJ/J;->e:[Ljava/lang/Object;

    .line 1113
    .line 1114
    iget-object v6, v2, LJ/J;->e:[Ljava/lang/Object;

    .line 1115
    .line 1116
    iget v8, v2, LJ/J;->f:I

    .line 1117
    .line 1118
    iget v10, v7, LJ/H;->b:I

    .line 1119
    .line 1120
    sub-int/2addr v8, v10

    .line 1121
    iget v11, v4, LJ/J;->f:I

    .line 1122
    .line 1123
    sub-int v12, v11, v10

    .line 1124
    .line 1125
    sub-int/2addr v11, v12

    .line 1126
    invoke-static {v5, v12, v6, v8, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1127
    .line 1128
    .line 1129
    iget-object v5, v4, LJ/J;->e:[Ljava/lang/Object;

    .line 1130
    .line 1131
    iget v6, v4, LJ/J;->f:I

    .line 1132
    .line 1133
    sub-int v8, v6, v10

    .line 1134
    .line 1135
    invoke-static {v5, v8, v6}, LK1/l;->X([Ljava/lang/Object;II)V

    .line 1136
    .line 1137
    .line 1138
    iget-object v5, v4, LJ/J;->c:[I

    .line 1139
    .line 1140
    iget-object v6, v2, LJ/J;->c:[I

    .line 1141
    .line 1142
    iget v2, v2, LJ/J;->d:I

    .line 1143
    .line 1144
    iget v7, v7, LJ/H;->a:I

    .line 1145
    .line 1146
    sub-int/2addr v2, v7

    .line 1147
    iget v8, v4, LJ/J;->d:I

    .line 1148
    .line 1149
    sub-int v11, v8, v7

    .line 1150
    .line 1151
    invoke-static {v5, v6, v2, v11, v8}, LK1/l;->R([I[IIII)V

    .line 1152
    .line 1153
    .line 1154
    iget v2, v4, LJ/J;->f:I

    .line 1155
    .line 1156
    sub-int/2addr v2, v10

    .line 1157
    iput v2, v4, LJ/J;->f:I

    .line 1158
    .line 1159
    iget v2, v4, LJ/J;->d:I

    .line 1160
    .line 1161
    sub-int/2addr v2, v7

    .line 1162
    iput v2, v4, LJ/J;->d:I

    .line 1163
    .line 1164
    const/4 v2, 0x1

    .line 1165
    :cond_2a
    iget-object v4, v0, LI/r;->F:LI/L0;

    .line 1166
    .line 1167
    iget v5, v4, LI/L0;->k:I

    .line 1168
    .line 1169
    if-lez v5, :cond_2b

    .line 1170
    .line 1171
    goto :goto_1e

    .line 1172
    :cond_2b
    const-string v5, "Unbalanced begin/end empty"

    .line 1173
    .line 1174
    invoke-static {v5}, LI/r0;->a(Ljava/lang/String;)V

    .line 1175
    .line 1176
    .line 1177
    :goto_1e
    iget v5, v4, LI/L0;->k:I

    .line 1178
    .line 1179
    add-int/lit8 v5, v5, -0x1

    .line 1180
    .line 1181
    iput v5, v4, LI/L0;->k:I

    .line 1182
    .line 1183
    iget-object v4, v0, LI/r;->H:LI/P0;

    .line 1184
    .line 1185
    iget v5, v4, LI/P0;->v:I

    .line 1186
    .line 1187
    invoke-virtual {v4}, LI/P0;->j()V

    .line 1188
    .line 1189
    .line 1190
    iget-object v4, v0, LI/r;->F:LI/L0;

    .line 1191
    .line 1192
    iget v4, v4, LI/L0;->k:I

    .line 1193
    .line 1194
    if-lez v4, :cond_2c

    .line 1195
    .line 1196
    goto/16 :goto_22

    .line 1197
    .line 1198
    :cond_2c
    rsub-int/lit8 v4, v5, -0x2

    .line 1199
    .line 1200
    iget-object v5, v0, LI/r;->H:LI/P0;

    .line 1201
    .line 1202
    invoke-virtual {v5}, LI/P0;->k()V

    .line 1203
    .line 1204
    .line 1205
    iget-object v5, v0, LI/r;->H:LI/P0;

    .line 1206
    .line 1207
    const/4 v8, 0x1

    .line 1208
    invoke-virtual {v5, v8}, LI/P0;->e(Z)V

    .line 1209
    .line 1210
    .line 1211
    iget-object v5, v0, LI/r;->M:LI/a;

    .line 1212
    .line 1213
    iget-object v6, v0, LI/r;->N:LJ/c;

    .line 1214
    .line 1215
    iget-object v6, v6, LJ/c;->a:LJ/J;

    .line 1216
    .line 1217
    invoke-virtual {v6}, LJ/J;->R()Z

    .line 1218
    .line 1219
    .line 1220
    move-result v6

    .line 1221
    if-eqz v6, :cond_2f

    .line 1222
    .line 1223
    iget-object v6, v0, LI/r;->G:LI/M0;

    .line 1224
    .line 1225
    invoke-virtual {v9}, LJ/b;->b()V

    .line 1226
    .line 1227
    .line 1228
    const/4 v8, 0x0

    .line 1229
    invoke-virtual {v9, v8}, LJ/b;->d(Z)V

    .line 1230
    .line 1231
    .line 1232
    iget-object v7, v9, LJ/b;->d:LI/O;

    .line 1233
    .line 1234
    iget-object v8, v9, LJ/b;->a:LI/r;

    .line 1235
    .line 1236
    iget-object v8, v8, LI/r;->F:LI/L0;

    .line 1237
    .line 1238
    iget v10, v8, LI/L0;->c:I

    .line 1239
    .line 1240
    if-lez v10, :cond_2e

    .line 1241
    .line 1242
    iget v10, v8, LI/L0;->i:I

    .line 1243
    .line 1244
    invoke-virtual {v7, v3}, LI/O;->a(I)I

    .line 1245
    .line 1246
    .line 1247
    move-result v3

    .line 1248
    if-eq v3, v10, :cond_2e

    .line 1249
    .line 1250
    iget-boolean v3, v9, LJ/b;->c:Z

    .line 1251
    .line 1252
    if-nez v3, :cond_2d

    .line 1253
    .line 1254
    iget-boolean v3, v9, LJ/b;->e:Z

    .line 1255
    .line 1256
    if-eqz v3, :cond_2d

    .line 1257
    .line 1258
    const/4 v3, 0x0

    .line 1259
    invoke-virtual {v9, v3}, LJ/b;->d(Z)V

    .line 1260
    .line 1261
    .line 1262
    iget-object v3, v9, LJ/b;->b:LJ/a;

    .line 1263
    .line 1264
    iget-object v3, v3, LJ/a;->a:LJ/J;

    .line 1265
    .line 1266
    sget-object v11, LJ/p;->c:LJ/p;

    .line 1267
    .line 1268
    invoke-virtual {v3, v11}, LJ/J;->T(LJ/H;)V

    .line 1269
    .line 1270
    .line 1271
    const/4 v3, 0x1

    .line 1272
    iput-boolean v3, v9, LJ/b;->c:Z

    .line 1273
    .line 1274
    :cond_2d
    if-lez v10, :cond_2e

    .line 1275
    .line 1276
    invoke-virtual {v8, v10}, LI/L0;->a(I)LI/a;

    .line 1277
    .line 1278
    .line 1279
    move-result-object v3

    .line 1280
    invoke-virtual {v7, v10}, LI/O;->c(I)V

    .line 1281
    .line 1282
    .line 1283
    const/4 v8, 0x0

    .line 1284
    invoke-virtual {v9, v8}, LJ/b;->d(Z)V

    .line 1285
    .line 1286
    .line 1287
    iget-object v7, v9, LJ/b;->b:LJ/a;

    .line 1288
    .line 1289
    iget-object v7, v7, LJ/a;->a:LJ/J;

    .line 1290
    .line 1291
    sget-object v10, LJ/o;->c:LJ/o;

    .line 1292
    .line 1293
    invoke-virtual {v7, v10}, LJ/J;->T(LJ/H;)V

    .line 1294
    .line 1295
    .line 1296
    invoke-static {v7, v8, v3}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 1297
    .line 1298
    .line 1299
    const/4 v8, 0x1

    .line 1300
    iput-boolean v8, v9, LJ/b;->c:Z

    .line 1301
    .line 1302
    goto :goto_1f

    .line 1303
    :cond_2e
    const/4 v8, 0x1

    .line 1304
    :goto_1f
    invoke-virtual {v9}, LJ/b;->c()V

    .line 1305
    .line 1306
    .line 1307
    iget-object v3, v9, LJ/b;->b:LJ/a;

    .line 1308
    .line 1309
    iget-object v3, v3, LJ/a;->a:LJ/J;

    .line 1310
    .line 1311
    sget-object v7, LJ/r;->c:LJ/r;

    .line 1312
    .line 1313
    invoke-virtual {v3, v7}, LJ/J;->T(LJ/H;)V

    .line 1314
    .line 1315
    .line 1316
    const/4 v7, 0x0

    .line 1317
    invoke-static {v3, v7, v5, v8, v6}, LX1/a;->j0(LJ/J;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 1318
    .line 1319
    .line 1320
    move v3, v7

    .line 1321
    goto/16 :goto_20

    .line 1322
    .line 1323
    :cond_2f
    const/4 v7, 0x0

    .line 1324
    iget-object v6, v0, LI/r;->G:LI/M0;

    .line 1325
    .line 1326
    iget-object v8, v0, LI/r;->N:LJ/c;

    .line 1327
    .line 1328
    invoke-virtual {v9}, LJ/b;->b()V

    .line 1329
    .line 1330
    .line 1331
    invoke-virtual {v9, v7}, LJ/b;->d(Z)V

    .line 1332
    .line 1333
    .line 1334
    iget-object v7, v9, LJ/b;->d:LI/O;

    .line 1335
    .line 1336
    iget-object v10, v9, LJ/b;->a:LI/r;

    .line 1337
    .line 1338
    iget-object v10, v10, LI/r;->F:LI/L0;

    .line 1339
    .line 1340
    iget v11, v10, LI/L0;->c:I

    .line 1341
    .line 1342
    if-lez v11, :cond_31

    .line 1343
    .line 1344
    iget v11, v10, LI/L0;->i:I

    .line 1345
    .line 1346
    invoke-virtual {v7, v3}, LI/O;->a(I)I

    .line 1347
    .line 1348
    .line 1349
    move-result v3

    .line 1350
    if-eq v3, v11, :cond_31

    .line 1351
    .line 1352
    iget-boolean v3, v9, LJ/b;->c:Z

    .line 1353
    .line 1354
    if-nez v3, :cond_30

    .line 1355
    .line 1356
    iget-boolean v3, v9, LJ/b;->e:Z

    .line 1357
    .line 1358
    if-eqz v3, :cond_30

    .line 1359
    .line 1360
    const/4 v3, 0x0

    .line 1361
    invoke-virtual {v9, v3}, LJ/b;->d(Z)V

    .line 1362
    .line 1363
    .line 1364
    iget-object v3, v9, LJ/b;->b:LJ/a;

    .line 1365
    .line 1366
    iget-object v3, v3, LJ/a;->a:LJ/J;

    .line 1367
    .line 1368
    sget-object v12, LJ/p;->c:LJ/p;

    .line 1369
    .line 1370
    invoke-virtual {v3, v12}, LJ/J;->T(LJ/H;)V

    .line 1371
    .line 1372
    .line 1373
    const/4 v3, 0x1

    .line 1374
    iput-boolean v3, v9, LJ/b;->c:Z

    .line 1375
    .line 1376
    :cond_30
    if-lez v11, :cond_31

    .line 1377
    .line 1378
    invoke-virtual {v10, v11}, LI/L0;->a(I)LI/a;

    .line 1379
    .line 1380
    .line 1381
    move-result-object v3

    .line 1382
    invoke-virtual {v7, v11}, LI/O;->c(I)V

    .line 1383
    .line 1384
    .line 1385
    const/4 v7, 0x0

    .line 1386
    invoke-virtual {v9, v7}, LJ/b;->d(Z)V

    .line 1387
    .line 1388
    .line 1389
    iget-object v10, v9, LJ/b;->b:LJ/a;

    .line 1390
    .line 1391
    iget-object v10, v10, LJ/a;->a:LJ/J;

    .line 1392
    .line 1393
    sget-object v11, LJ/o;->c:LJ/o;

    .line 1394
    .line 1395
    invoke-virtual {v10, v11}, LJ/J;->T(LJ/H;)V

    .line 1396
    .line 1397
    .line 1398
    invoke-static {v10, v7, v3}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 1399
    .line 1400
    .line 1401
    const/4 v3, 0x1

    .line 1402
    iput-boolean v3, v9, LJ/b;->c:Z

    .line 1403
    .line 1404
    :cond_31
    invoke-virtual {v9}, LJ/b;->c()V

    .line 1405
    .line 1406
    .line 1407
    iget-object v3, v9, LJ/b;->b:LJ/a;

    .line 1408
    .line 1409
    iget-object v3, v3, LJ/a;->a:LJ/J;

    .line 1410
    .line 1411
    sget-object v7, LJ/s;->c:LJ/s;

    .line 1412
    .line 1413
    invoke-virtual {v3, v7}, LJ/J;->T(LJ/H;)V

    .line 1414
    .line 1415
    .line 1416
    iget v7, v3, LJ/J;->f:I

    .line 1417
    .line 1418
    iget-object v9, v3, LJ/J;->a:[LJ/H;

    .line 1419
    .line 1420
    iget v10, v3, LJ/J;->b:I

    .line 1421
    .line 1422
    const/16 v18, 0x1

    .line 1423
    .line 1424
    add-int/lit8 v10, v10, -0x1

    .line 1425
    .line 1426
    aget-object v9, v9, v10

    .line 1427
    .line 1428
    iget v9, v9, LJ/H;->b:I

    .line 1429
    .line 1430
    sub-int/2addr v7, v9

    .line 1431
    iget-object v3, v3, LJ/J;->e:[Ljava/lang/Object;

    .line 1432
    .line 1433
    aput-object v5, v3, v7

    .line 1434
    .line 1435
    add-int/lit8 v5, v7, 0x1

    .line 1436
    .line 1437
    aput-object v6, v3, v5

    .line 1438
    .line 1439
    add-int/lit8 v7, v7, 0x2

    .line 1440
    .line 1441
    aput-object v8, v3, v7

    .line 1442
    .line 1443
    new-instance v3, LJ/c;

    .line 1444
    .line 1445
    invoke-direct {v3}, LJ/c;-><init>()V

    .line 1446
    .line 1447
    .line 1448
    iput-object v3, v0, LI/r;->N:LJ/c;

    .line 1449
    .line 1450
    const/4 v3, 0x0

    .line 1451
    :goto_20
    iput-boolean v3, v0, LI/r;->Q:Z

    .line 1452
    .line 1453
    iget-object v5, v0, LI/r;->c:LI/M0;

    .line 1454
    .line 1455
    iget v5, v5, LI/M0;->e:I

    .line 1456
    .line 1457
    if-nez v5, :cond_32

    .line 1458
    .line 1459
    goto :goto_22

    .line 1460
    :cond_32
    invoke-virtual {v0, v4, v3}, LI/r;->a0(II)V

    .line 1461
    .line 1462
    .line 1463
    invoke-virtual {v0, v4, v2}, LI/r;->b0(II)V

    .line 1464
    .line 1465
    .line 1466
    goto :goto_22

    .line 1467
    :cond_33
    if-eqz p1, :cond_34

    .line 1468
    .line 1469
    invoke-virtual {v9}, LJ/b;->a()V

    .line 1470
    .line 1471
    .line 1472
    :cond_34
    iget-object v3, v9, LJ/b;->a:LI/r;

    .line 1473
    .line 1474
    iget-object v3, v3, LI/r;->F:LI/L0;

    .line 1475
    .line 1476
    iget v3, v3, LI/L0;->i:I

    .line 1477
    .line 1478
    iget-object v4, v9, LJ/b;->d:LI/O;

    .line 1479
    .line 1480
    move/from16 v5, v17

    .line 1481
    .line 1482
    invoke-virtual {v4, v5}, LI/O;->a(I)I

    .line 1483
    .line 1484
    .line 1485
    move-result v6

    .line 1486
    if-gt v6, v3, :cond_35

    .line 1487
    .line 1488
    goto :goto_21

    .line 1489
    :cond_35
    const-string v6, "Missed recording an endGroup"

    .line 1490
    .line 1491
    invoke-static {v6}, LI/t;->a(Ljava/lang/String;)V

    .line 1492
    .line 1493
    .line 1494
    :goto_21
    invoke-virtual {v4, v5}, LI/O;->a(I)I

    .line 1495
    .line 1496
    .line 1497
    move-result v5

    .line 1498
    if-ne v5, v3, :cond_36

    .line 1499
    .line 1500
    const/4 v8, 0x0

    .line 1501
    invoke-virtual {v9, v8}, LJ/b;->d(Z)V

    .line 1502
    .line 1503
    .line 1504
    invoke-virtual {v4}, LI/O;->b()I

    .line 1505
    .line 1506
    .line 1507
    iget-object v3, v9, LJ/b;->b:LJ/a;

    .line 1508
    .line 1509
    iget-object v3, v3, LJ/a;->a:LJ/J;

    .line 1510
    .line 1511
    sget-object v4, LJ/l;->c:LJ/l;

    .line 1512
    .line 1513
    invoke-virtual {v3, v4}, LJ/J;->T(LJ/H;)V

    .line 1514
    .line 1515
    .line 1516
    :cond_36
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 1517
    .line 1518
    iget v3, v3, LI/L0;->i:I

    .line 1519
    .line 1520
    invoke-virtual {v0, v3}, LI/r;->f0(I)I

    .line 1521
    .line 1522
    .line 1523
    move-result v4

    .line 1524
    if-eq v2, v4, :cond_37

    .line 1525
    .line 1526
    invoke-virtual {v0, v3, v2}, LI/r;->b0(II)V

    .line 1527
    .line 1528
    .line 1529
    :cond_37
    if-eqz p1, :cond_38

    .line 1530
    .line 1531
    const/4 v2, 0x1

    .line 1532
    :cond_38
    iget-object v3, v0, LI/r;->F:LI/L0;

    .line 1533
    .line 1534
    invoke-virtual {v3}, LI/L0;->e()V

    .line 1535
    .line 1536
    .line 1537
    invoke-virtual {v9}, LJ/b;->c()V

    .line 1538
    .line 1539
    .line 1540
    :goto_22
    iget-object v3, v0, LI/r;->h:Ljava/util/ArrayList;

    .line 1541
    .line 1542
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 1543
    .line 1544
    .line 1545
    move-result v4

    .line 1546
    const/16 v18, 0x1

    .line 1547
    .line 1548
    add-int/lit8 v4, v4, -0x1

    .line 1549
    .line 1550
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 1551
    .line 1552
    .line 1553
    move-result-object v3

    .line 1554
    check-cast v3, LI/p0;

    .line 1555
    .line 1556
    if-eqz v3, :cond_39

    .line 1557
    .line 1558
    if-nez v1, :cond_39

    .line 1559
    .line 1560
    iget v1, v3, LI/p0;->c:I

    .line 1561
    .line 1562
    add-int/lit8 v1, v1, 0x1

    .line 1563
    .line 1564
    iput v1, v3, LI/p0;->c:I

    .line 1565
    .line 1566
    :cond_39
    iput-object v3, v0, LI/r;->i:LI/p0;

    .line 1567
    .line 1568
    invoke-virtual/range {v21 .. v21}, LI/O;->b()I

    .line 1569
    .line 1570
    .line 1571
    move-result v1

    .line 1572
    add-int/2addr v1, v2

    .line 1573
    iput v1, v0, LI/r;->j:I

    .line 1574
    .line 1575
    invoke-virtual/range {v21 .. v21}, LI/O;->b()I

    .line 1576
    .line 1577
    .line 1578
    move-result v1

    .line 1579
    iput v1, v0, LI/r;->l:I

    .line 1580
    .line 1581
    invoke-virtual/range {v21 .. v21}, LI/O;->b()I

    .line 1582
    .line 1583
    .line 1584
    move-result v1

    .line 1585
    add-int/2addr v1, v2

    .line 1586
    iput v1, v0, LI/r;->k:I

    .line 1587
    .line 1588
    return-void

    .line 1589
    :cond_3a
    move/from16 v5, v17

    .line 1590
    .line 1591
    const/4 v8, 0x0

    .line 1592
    const/16 v18, 0x1

    .line 1593
    .line 1594
    invoke-virtual {v0}, LI/r;->H()V

    .line 1595
    .line 1596
    .line 1597
    iget-object v7, v0, LI/r;->F:LI/L0;

    .line 1598
    .line 1599
    invoke-virtual {v7}, LI/L0;->s()I

    .line 1600
    .line 1601
    .line 1602
    move-result v7

    .line 1603
    invoke-virtual {v9, v4, v7}, LJ/b;->e(II)V

    .line 1604
    .line 1605
    .line 1606
    iget-object v7, v0, LI/r;->F:LI/L0;

    .line 1607
    .line 1608
    iget v7, v7, LI/L0;->g:I

    .line 1609
    .line 1610
    move-object/from16 v10, v37

    .line 1611
    .line 1612
    invoke-static {v10, v6, v7}, LI/k;->f(Ljava/util/ArrayList;II)V

    .line 1613
    .line 1614
    .line 1615
    goto/16 :goto_1c
.end method

.method public final q()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, LI/r;->p(Z)V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0}, LI/r;->w()LI/w0;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget v1, v0, LI/w0;->b:I

    .line 12
    .line 13
    and-int/lit8 v2, v1, 0x1

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    or-int/lit8 v1, v1, 0x2

    .line 18
    .line 19
    iput v1, v0, LI/w0;->b:I

    .line 20
    .line 21
    :cond_0
    return-void
.end method

.method public final r()LI/w0;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LI/r;->D:Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x1

    .line 10
    if-nez v2, :cond_0

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    sub-int/2addr v2, v3

    .line 17
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, LI/w0;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v1, 0x0

    .line 25
    :goto_0
    if-eqz v1, :cond_7

    .line 26
    .line 27
    iget v5, v1, LI/w0;->b:I

    .line 28
    .line 29
    and-int/lit8 v6, v5, -0x9

    .line 30
    .line 31
    iput v6, v1, LI/w0;->b:I

    .line 32
    .line 33
    iget v6, v0, LI/r;->A:I

    .line 34
    .line 35
    iget-object v7, v1, LI/w0;->f:Li/C;

    .line 36
    .line 37
    if-eqz v7, :cond_5

    .line 38
    .line 39
    and-int/lit8 v5, v5, 0x10

    .line 40
    .line 41
    if-eqz v5, :cond_1

    .line 42
    .line 43
    goto :goto_3

    .line 44
    :cond_1
    iget-object v5, v7, Li/C;->b:[Ljava/lang/Object;

    .line 45
    .line 46
    iget-object v8, v7, Li/C;->c:[I

    .line 47
    .line 48
    iget-object v9, v7, Li/C;->a:[J

    .line 49
    .line 50
    array-length v10, v9

    .line 51
    add-int/lit8 v10, v10, -0x2

    .line 52
    .line 53
    if-ltz v10, :cond_5

    .line 54
    .line 55
    const/4 v11, 0x0

    .line 56
    :goto_1
    aget-wide v12, v9, v11

    .line 57
    .line 58
    not-long v14, v12

    .line 59
    const/16 v16, 0x7

    .line 60
    .line 61
    shl-long v14, v14, v16

    .line 62
    .line 63
    and-long/2addr v14, v12

    .line 64
    const-wide v16, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    and-long v14, v14, v16

    .line 70
    .line 71
    cmp-long v14, v14, v16

    .line 72
    .line 73
    if-eqz v14, :cond_4

    .line 74
    .line 75
    sub-int v14, v11, v10

    .line 76
    .line 77
    not-int v14, v14

    .line 78
    ushr-int/lit8 v14, v14, 0x1f

    .line 79
    .line 80
    const/16 v15, 0x8

    .line 81
    .line 82
    rsub-int/lit8 v14, v14, 0x8

    .line 83
    .line 84
    const/4 v4, 0x0

    .line 85
    :goto_2
    if-ge v4, v14, :cond_3

    .line 86
    .line 87
    const-wide/16 v17, 0xff

    .line 88
    .line 89
    and-long v17, v12, v17

    .line 90
    .line 91
    const-wide/16 v19, 0x80

    .line 92
    .line 93
    cmp-long v17, v17, v19

    .line 94
    .line 95
    if-gez v17, :cond_2

    .line 96
    .line 97
    shl-int/lit8 v17, v11, 0x3

    .line 98
    .line 99
    add-int v17, v17, v4

    .line 100
    .line 101
    aget-object v18, v5, v17

    .line 102
    .line 103
    aget v2, v8, v17

    .line 104
    .line 105
    if-eq v2, v6, :cond_2

    .line 106
    .line 107
    new-instance v2, LI/v0;

    .line 108
    .line 109
    const/4 v4, 0x0

    .line 110
    invoke-direct {v2, v6, v4, v1, v7}, LI/v0;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    goto :goto_4

    .line 114
    :cond_2
    shr-long/2addr v12, v15

    .line 115
    add-int/lit8 v4, v4, 0x1

    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_3
    if-ne v14, v15, :cond_5

    .line 119
    .line 120
    :cond_4
    if-eq v11, v10, :cond_5

    .line 121
    .line 122
    add-int/lit8 v11, v11, 0x1

    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_5
    :goto_3
    const/4 v2, 0x0

    .line 126
    :goto_4
    iget-object v4, v0, LI/r;->L:LJ/b;

    .line 127
    .line 128
    if-eqz v2, :cond_6

    .line 129
    .line 130
    iget-object v5, v4, LJ/b;->b:LJ/a;

    .line 131
    .line 132
    iget-object v5, v5, LJ/a;->a:LJ/J;

    .line 133
    .line 134
    sget-object v6, LJ/k;->c:LJ/k;

    .line 135
    .line 136
    invoke-virtual {v5, v6}, LJ/J;->T(LJ/H;)V

    .line 137
    .line 138
    .line 139
    iget-object v6, v0, LI/r;->g:LI/y;

    .line 140
    .line 141
    const/4 v7, 0x0

    .line 142
    invoke-static {v5, v7, v2, v3, v6}, LX1/a;->j0(LJ/J;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    :cond_6
    iget v2, v1, LI/w0;->b:I

    .line 146
    .line 147
    and-int/lit16 v5, v2, 0x200

    .line 148
    .line 149
    if-eqz v5, :cond_7

    .line 150
    .line 151
    and-int/lit16 v2, v2, -0x201

    .line 152
    .line 153
    iput v2, v1, LI/w0;->b:I

    .line 154
    .line 155
    iget-object v2, v4, LJ/b;->b:LJ/a;

    .line 156
    .line 157
    iget-object v2, v2, LJ/a;->a:LJ/J;

    .line 158
    .line 159
    sget-object v4, LJ/n;->c:LJ/n;

    .line 160
    .line 161
    invoke-virtual {v2, v4}, LJ/J;->T(LJ/H;)V

    .line 162
    .line 163
    .line 164
    const/4 v7, 0x0

    .line 165
    invoke-static {v2, v7, v1}, LX1/a;->i0(LJ/J;ILjava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    iget v2, v1, LI/w0;->b:I

    .line 169
    .line 170
    and-int/lit16 v4, v2, -0x81

    .line 171
    .line 172
    iput v4, v1, LI/w0;->b:I

    .line 173
    .line 174
    and-int/lit16 v4, v2, 0x400

    .line 175
    .line 176
    if-eqz v4, :cond_7

    .line 177
    .line 178
    and-int/lit16 v2, v2, -0x481

    .line 179
    .line 180
    iput v2, v1, LI/w0;->b:I

    .line 181
    .line 182
    iput-boolean v7, v0, LI/r;->x:Z

    .line 183
    .line 184
    :cond_7
    if-eqz v1, :cond_c

    .line 185
    .line 186
    iget v2, v1, LI/w0;->b:I

    .line 187
    .line 188
    and-int/lit8 v4, v2, 0x10

    .line 189
    .line 190
    if-eqz v4, :cond_8

    .line 191
    .line 192
    goto :goto_8

    .line 193
    :cond_8
    and-int/2addr v2, v3

    .line 194
    if-eqz v2, :cond_9

    .line 195
    .line 196
    goto :goto_5

    .line 197
    :cond_9
    iget-boolean v2, v0, LI/r;->p:Z

    .line 198
    .line 199
    if-eqz v2, :cond_c

    .line 200
    .line 201
    :goto_5
    iget-object v2, v1, LI/w0;->c:LI/a;

    .line 202
    .line 203
    if-nez v2, :cond_b

    .line 204
    .line 205
    iget-boolean v2, v0, LI/r;->Q:Z

    .line 206
    .line 207
    if-eqz v2, :cond_a

    .line 208
    .line 209
    iget-object v2, v0, LI/r;->H:LI/P0;

    .line 210
    .line 211
    iget v3, v2, LI/P0;->v:I

    .line 212
    .line 213
    invoke-virtual {v2, v3}, LI/P0;->b(I)LI/a;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    goto :goto_6

    .line 218
    :cond_a
    iget-object v2, v0, LI/r;->F:LI/L0;

    .line 219
    .line 220
    iget v3, v2, LI/L0;->i:I

    .line 221
    .line 222
    invoke-virtual {v2, v3}, LI/L0;->a(I)LI/a;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    :goto_6
    iput-object v2, v1, LI/w0;->c:LI/a;

    .line 227
    .line 228
    :cond_b
    iget v2, v1, LI/w0;->b:I

    .line 229
    .line 230
    and-int/lit8 v2, v2, -0x5

    .line 231
    .line 232
    iput v2, v1, LI/w0;->b:I

    .line 233
    .line 234
    move-object v4, v1

    .line 235
    :goto_7
    const/4 v7, 0x0

    .line 236
    goto :goto_9

    .line 237
    :cond_c
    :goto_8
    const/4 v4, 0x0

    .line 238
    goto :goto_7

    .line 239
    :goto_9
    invoke-virtual {v0, v7}, LI/r;->p(Z)V

    .line 240
    .line 241
    .line 242
    return-object v4
.end method

.method public final s()V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, LI/r;->p(Z)V

    .line 3
    .line 4
    .line 5
    iget-object v1, p0, LI/r;->b:LI/v;

    .line 6
    .line 7
    invoke-virtual {v1}, LI/v;->b()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, LI/r;->p(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, LI/r;->L:LJ/b;

    .line 14
    .line 15
    iget-boolean v2, v1, LJ/b;->c:Z

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    invoke-virtual {v1, v0}, LJ/b;->d(Z)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, v0}, LJ/b;->d(Z)V

    .line 23
    .line 24
    .line 25
    iget-object v2, v1, LJ/b;->b:LJ/a;

    .line 26
    .line 27
    iget-object v2, v2, LJ/a;->a:LJ/J;

    .line 28
    .line 29
    sget-object v3, LJ/l;->c:LJ/l;

    .line 30
    .line 31
    invoke-virtual {v2, v3}, LJ/J;->T(LJ/H;)V

    .line 32
    .line 33
    .line 34
    iput-boolean v0, v1, LJ/b;->c:Z

    .line 35
    .line 36
    :cond_0
    invoke-virtual {v1}, LJ/b;->b()V

    .line 37
    .line 38
    .line 39
    iget-object v1, v1, LJ/b;->d:LI/O;

    .line 40
    .line 41
    iget v1, v1, LI/O;->b:I

    .line 42
    .line 43
    if-nez v1, :cond_1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    const-string v1, "Missed recording an endGroup()"

    .line 47
    .line 48
    invoke-static {v1}, LI/t;->a(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    :goto_0
    iget-object v1, p0, LI/r;->h:Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-nez v1, :cond_2

    .line 58
    .line 59
    const-string v1, "Start/end imbalance"

    .line 60
    .line 61
    invoke-static {v1}, LI/t;->a(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    :cond_2
    invoke-virtual {p0}, LI/r;->h()V

    .line 65
    .line 66
    .line 67
    iget-object v1, p0, LI/r;->F:LI/L0;

    .line 68
    .line 69
    invoke-virtual {v1}, LI/L0;->c()V

    .line 70
    .line 71
    .line 72
    iget-object v1, p0, LI/r;->w:LI/O;

    .line 73
    .line 74
    invoke-virtual {v1}, LI/O;->b()I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-eqz v1, :cond_3

    .line 79
    .line 80
    const/4 v0, 0x1

    .line 81
    :cond_3
    iput-boolean v0, p0, LI/r;->v:Z

    .line 82
    .line 83
    return-void
.end method

.method public final t(ZLI/p0;)V
    .locals 2

    .line 1
    iget-object v0, p0, LI/r;->h:Ljava/util/ArrayList;

    .line 2
    .line 3
    iget-object v1, p0, LI/r;->i:LI/p0;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, LI/r;->i:LI/p0;

    .line 9
    .line 10
    iget p2, p0, LI/r;->k:I

    .line 11
    .line 12
    iget-object v0, p0, LI/r;->m:LI/O;

    .line 13
    .line 14
    invoke-virtual {v0, p2}, LI/O;->c(I)V

    .line 15
    .line 16
    .line 17
    iget p2, p0, LI/r;->l:I

    .line 18
    .line 19
    invoke-virtual {v0, p2}, LI/O;->c(I)V

    .line 20
    .line 21
    .line 22
    iget p2, p0, LI/r;->j:I

    .line 23
    .line 24
    invoke-virtual {v0, p2}, LI/O;->c(I)V

    .line 25
    .line 26
    .line 27
    const/4 p2, 0x0

    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    iput p2, p0, LI/r;->j:I

    .line 31
    .line 32
    :cond_0
    iput p2, p0, LI/r;->k:I

    .line 33
    .line 34
    iput p2, p0, LI/r;->l:I

    .line 35
    .line 36
    return-void
.end method

.method public final u()V
    .locals 2

    .line 1
    new-instance v0, LI/M0;

    .line 2
    .line 3
    invoke-direct {v0}, LI/M0;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-boolean v1, p0, LI/r;->B:Z

    .line 7
    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {v0}, LI/M0;->b()V

    .line 11
    .line 12
    .line 13
    :cond_0
    iget-object v1, p0, LI/r;->b:LI/v;

    .line 14
    .line 15
    invoke-virtual {v1}, LI/v;->c()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    new-instance v1, Li/x;

    .line 22
    .line 23
    invoke-direct {v1}, Li/x;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v1, v0, LI/M0;->n:Li/x;

    .line 27
    .line 28
    :cond_1
    iput-object v0, p0, LI/r;->G:LI/M0;

    .line 29
    .line 30
    invoke-virtual {v0}, LI/M0;->d()LI/P0;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v1, 0x1

    .line 35
    invoke-virtual {v0, v1}, LI/P0;->e(Z)V

    .line 36
    .line 37
    .line 38
    iput-object v0, p0, LI/r;->H:LI/P0;

    .line 39
    .line 40
    return-void
.end method

.method public final v()LV/d;
    .locals 2

    .line 1
    iget-object v0, p0, LI/r;->S:LI/x;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LI/x;

    .line 6
    .line 7
    iget-object v1, p0, LI/r;->g:LI/y;

    .line 8
    .line 9
    invoke-direct {v0, v1}, LI/x;-><init>(LI/u;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, LI/r;->S:LI/x;

    .line 13
    .line 14
    :cond_0
    return-object v0
.end method

.method public final w()LI/w0;
    .locals 2

    .line 1
    iget v0, p0, LI/r;->z:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, LI/r;->D:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    add-int/lit8 v1, v1, -0x1

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, LI/w0;

    .line 24
    .line 25
    return-object v0

    .line 26
    :cond_0
    const/4 v0, 0x0

    .line 27
    return-object v0
.end method

.method public final x()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, LI/r;->z()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget-boolean v0, p0, LI/r;->v:Z

    .line 8
    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    invoke-virtual {p0}, LI/r;->w()LI/w0;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget v0, v0, LI/w0;->b:I

    .line 18
    .line 19
    and-int/lit8 v0, v0, 0x4

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 v0, 0x0

    .line 25
    return v0

    .line 26
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 27
    return v0
.end method

.method public final y()LV/e;
    .locals 1

    .line 1
    iget-object v0, p0, LI/r;->b:LI/v;

    .line 2
    .line 3
    invoke-virtual {v0}, LI/v;->j()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, LI/r;->O:LV/e;

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    const/4 v0, 0x0

    .line 13
    return-object v0
.end method

.method public final z()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LI/r;->Q:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-boolean v0, p0, LI/r;->x:Z

    .line 6
    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    iget-boolean v0, p0, LI/r;->v:Z

    .line 10
    .line 11
    if-nez v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, LI/r;->w()LI/w0;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget v0, v0, LI/w0;->b:I

    .line 20
    .line 21
    and-int/lit8 v0, v0, 0x8

    .line 22
    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v0, 0x1

    .line 27
    return v0

    .line 28
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 29
    return v0
.end method
