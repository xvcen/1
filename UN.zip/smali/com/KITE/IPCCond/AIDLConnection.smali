.class public Lcom/KITE/IPCCond/AIDLConnection;
.super Ljava/lang/Object;
.source "AIDLConnection.java"

# interfaces
.implements Landroid/content/ServiceConnection;


# static fields
.field public static iTestService:Lcom/KITE/IPCCond/IMutual;


# instance fields
.field private final isDaemon:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    iput-boolean p1, p0, Lcom/KITE/IPCCond/AIDLConnection;->isDaemon:Z

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/ComponentName;",
            "Landroid/os/IBinder;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 20
    invoke-static {p2}, Lcom/KITE/IPCCond/IMutual$Stub;->asInterface(Landroid/os/IBinder;)Lcom/KITE/IPCCond/IMutual;

    move-result-object p1

    sput-object p1, Lcom/KITE/IPCCond/AIDLConnection;->iTestService:Lcom/KITE/IPCCond/IMutual;

    .line 21
    invoke-static {p1}, Lcom/KITE/IPCCond/IPCService;->InItIPC(Lcom/KITE/IPCCond/IMutual;)V

    .line 22
    const-string p1, "Shocker"

    const-string p2, "Connected"

    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/ComponentName;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 27
    const-string p1, "Shocker"

    const-string v0, "Disconnected"

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
