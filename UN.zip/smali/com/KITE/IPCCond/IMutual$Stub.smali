.class public abstract Lcom/KITE/IPCCond/IMutual$Stub;
.super Landroid/os/Binder;
.source "IMutual.java"

# interfaces
.implements Lcom/KITE/IPCCond/IMutual;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/IPCCond/IMutual;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x429
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/IPCCond/IMutual$Stub$Proxy;
    }
.end annotation


# static fields
.field static final TRANSACTION_GetImGuiwinsize:I = 0x4

.field static final TRANSACTION_MotionEventClick:I = 0x3

.field static final TRANSACTION_setKey:I = 0x6

.field static final TRANSACTION_setPid:I = 0x5

.field static final TRANSACTION_setSurface:I = 0x1

.field static final TRANSACTION_setUUid:I = 0x7

.field static final TRANSACTION_start:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 43
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 44
    const-string v0, "com.KITE.IPCCond.IMutual"

    invoke-virtual {p0, p0, v0}, Lcom/KITE/IPCCond/IMutual$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/KITE/IPCCond/IMutual;
    .locals 2

    .line 52
    if-nez p0, :cond_0

    .line 53
    const/4 p0, 0x0

    move-object v0, p0

    check-cast v0, Lcom/KITE/IPCCond/IMutual;

    return-object p0

    .line 55
    :cond_0
    const-string v0, "com.KITE.IPCCond.IMutual"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    .line 56
    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/KITE/IPCCond/IMutual;

    if-eqz v1, :cond_1

    .line 57
    check-cast v0, Lcom/KITE/IPCCond/IMutual;

    return-object v0

    .line 59
    :cond_1
    new-instance v0, Lcom/KITE/IPCCond/IMutual$Stub$Proxy;

    invoke-direct {v0, p0}, Lcom/KITE/IPCCond/IMutual$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 63
    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 67
    nop

    .line 68
    const-string v0, "com.KITE.IPCCond.IMutual"

    const/4 v1, 0x1

    if-lt p1, v1, :cond_0

    const v2, 0xffffff

    if-gt p1, v2, :cond_0

    .line 69
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 71
    :cond_0
    packed-switch p1, :pswitch_data_0

    .line 79
    packed-switch p1, :pswitch_data_1

    .line 145
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    .line 75
    :pswitch_0
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 76
    return v1

    .line 137
    :pswitch_1
    nop

    .line 138
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    .line 139
    invoke-virtual {p0, p1}, Lcom/KITE/IPCCond/IMutual$Stub;->setUUid(Ljava/lang/String;)V

    .line 140
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 141
    goto :goto_0

    .line 129
    :pswitch_2
    nop

    .line 130
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    .line 131
    invoke-virtual {p0, p1}, Lcom/KITE/IPCCond/IMutual$Stub;->setKey(Ljava/lang/String;)V

    .line 132
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 133
    goto :goto_0

    .line 121
    :pswitch_3
    nop

    .line 122
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    .line 123
    invoke-virtual {p0, p1}, Lcom/KITE/IPCCond/IMutual$Stub;->setPid(I)V

    .line 124
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 125
    goto :goto_0

    .line 114
    :pswitch_4
    invoke-virtual {p0}, Lcom/KITE/IPCCond/IMutual$Stub;->GetImGuiwinsize()[F

    move-result-object p1

    .line 115
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 116
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeFloatArray([F)V

    .line 117
    goto :goto_0

    .line 102
    :pswitch_5
    nop

    .line 103
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    .line 104
    nop

    .line 105
    invoke-virtual {p2}, Landroid/os/Parcel;->readFloat()F

    move-result p4

    .line 106
    nop

    .line 107
    invoke-virtual {p2}, Landroid/os/Parcel;->readFloat()F

    move-result p2

    .line 108
    invoke-virtual {p0, p1, p4, p2}, Lcom/KITE/IPCCond/IMutual$Stub;->MotionEventClick(IFF)V

    .line 109
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 110
    goto :goto_0

    .line 91
    :pswitch_6
    nop

    .line 92
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    .line 93
    nop

    .line 94
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    .line 95
    invoke-virtual {p0, p1, p2}, Lcom/KITE/IPCCond/IMutual$Stub;->start(II)Ljava/lang/String;

    move-result-object p1

    .line 96
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 97
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 98
    goto :goto_0

    .line 83
    :pswitch_7
    nop

    .line 84
    sget-object p1, Landroid/view/Surface;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p2, p1}, Lcom/KITE/IPCCond/IMutual$_Parcel;->access$1000001(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/Surface;

    .line 85
    invoke-virtual {p0, p1}, Lcom/KITE/IPCCond/IMutual$Stub;->setSurface(Landroid/view/Surface;)V

    .line 86
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 87
    nop

    .line 148
    :goto_0
    return v1

    :pswitch_data_0
    .packed-switch 0x5f4e5446
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
