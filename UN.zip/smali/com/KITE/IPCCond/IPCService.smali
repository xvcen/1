.class public Lcom/KITE/IPCCond/IPCService;
.super Ljava/lang/Object;
.source "IPCService.java"


# static fields
.field private static ipc:Lcom/KITE/IPCCond/IMutual;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static GetIPC()Lcom/KITE/IPCCond/IMutual;
    .locals 1

    .line 17
    sget-object v0, Lcom/KITE/IPCCond/IPCService;->ipc:Lcom/KITE/IPCCond/IMutual;

    return-object v0
.end method

.method public static InItIPC(Lcom/KITE/IPCCond/IMutual;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/KITE/IPCCond/IMutual;",
            ")V"
        }
    .end annotation

    .line 13
    sput-object p0, Lcom/KITE/IPCCond/IPCService;->ipc:Lcom/KITE/IPCCond/IMutual;

    return-void
.end method

.method public static isConnect()Z
    .locals 1

    .line 9
    sget-object v0, Lcom/KITE/IPCCond/IPCService;->ipc:Lcom/KITE/IPCCond/IMutual;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    return v0
.end method
