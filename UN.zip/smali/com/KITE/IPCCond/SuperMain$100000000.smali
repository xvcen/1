.class Lcom/KITE/IPCCond/SuperMain$100000000;
.super Lcom/KITE/IPCCond/IMutual$Stub;
.source "SuperMain.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/IPCCond/SuperMain;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/IPCCond/SuperMain;


# direct methods
.method constructor <init>(Lcom/KITE/IPCCond/SuperMain;)V
    .locals 0

    invoke-direct {p0}, Lcom/KITE/IPCCond/IMutual$Stub;-><init>()V

    iput-object p1, p0, Lcom/KITE/IPCCond/SuperMain$100000000;->this$0:Lcom/KITE/IPCCond/SuperMain;

    return-void
.end method

.method static access$0(Lcom/KITE/IPCCond/SuperMain$100000000;)Lcom/KITE/IPCCond/SuperMain;
    .locals 0

    iget-object p0, p0, Lcom/KITE/IPCCond/SuperMain$100000000;->this$0:Lcom/KITE/IPCCond/SuperMain;

    return-object p0
.end method


# virtual methods
.method public GetImGuiwinsize()[F
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 41
    invoke-static {}, Lcom/KITE/SuperJNI;->GetImGuiwinsize()[F

    move-result-object v0

    return-object v0
.end method

.method public MotionEventClick(IFF)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V^",
            "Landroid/os/RemoteException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 36
    invoke-static {p1, p2, p3}, Lcom/KITE/SuperJNI;->MotionEventClick(IFF)V

    return-void
.end method

.method public setKey(Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 49
    invoke-static {p1}, Lcom/KITE/SuperJNI;->setKey(Ljava/lang/String;)V

    return-void
.end method

.method public setPid(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V^",
            "Landroid/os/RemoteException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 45
    invoke-static {p1}, Lcom/KITE/SuperJNI;->setPid(I)V

    return-void
.end method

.method public setSurface(Landroid/view/Surface;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/Surface;",
            ")V^",
            "Landroid/os/RemoteException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 28
    invoke-static {p1}, Lcom/KITE/SuperJNI;->setSurface(Landroid/view/Surface;)V

    return-void
.end method

.method public setUUid(Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 54
    invoke-static {p1}, Lcom/KITE/SuperJNI;->setUUid(Ljava/lang/String;)V

    return-void
.end method

.method public start(II)Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 32
    invoke-static {p1, p2}, Lcom/KITE/SuperJNI;->start(II)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
