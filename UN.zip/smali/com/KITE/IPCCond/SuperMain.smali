.class public Lcom/KITE/IPCCond/SuperMain;
.super Lcom/topjohnwu/superuser/ipc/RootService;
.source "SuperMain.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/IPCCond/SuperMain$100000000;
    }
.end annotation


# direct methods
.method static final constructor <clinit>()V
    .locals 1

    .line 17
    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v0

    if-nez v0, :cond_0

    .line 18
    const-string v0, "main"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 58
    invoke-direct {p0}, Lcom/topjohnwu/superuser/ipc/RootService;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 25
    new-instance p1, Lcom/KITE/IPCCond/SuperMain$100000000;

    invoke-direct {p1, p0}, Lcom/KITE/IPCCond/SuperMain$100000000;-><init>(Lcom/KITE/IPCCond/SuperMain;)V

    return-object p1
.end method
