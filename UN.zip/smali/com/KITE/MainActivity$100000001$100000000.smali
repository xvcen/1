.class Lcom/KITE/MainActivity$100000001$100000000;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000001;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000001;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000001;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000001$100000000;->this$0:Lcom/KITE/MainActivity$100000001;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000001$100000000;)Lcom/KITE/MainActivity$100000001;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000001$100000000;->this$0:Lcom/KITE/MainActivity$100000001;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 105
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000009()Landroid/app/AlertDialog;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000009()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 106
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000009()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    :cond_0
    return-void
.end method
