.class Lcom/KITE/MainActivity$100000004$100000002;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000004;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000004;

.field private final synthetic val$input:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000004;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000004$100000002;->this$0:Lcom/KITE/MainActivity$100000004;

    iput-object p2, p0, Lcom/KITE/MainActivity$100000004$100000002;->val$input:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000004$100000002;)Lcom/KITE/MainActivity$100000004;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000004$100000002;->this$0:Lcom/KITE/MainActivity$100000004;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 136
    iget-object p1, p0, Lcom/KITE/MainActivity$100000004$100000002;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 137
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_0

    .line 138
    invoke-static {p1}, Lcom/KITE/SuperJNI;->sendKamiToCpp(Ljava/lang/String;)V

    .line 139
    sget-object p1, Lcom/KITE/MainActivity;->instance:Lcom/KITE/MainActivity;

    const-string p2, "\u5361\u5bc6\u8bbe\u7f6e\u6210\u529f\uff01"

    const/4 v0, 0x0

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method
