.class Lcom/KITE/MainActivity$100000004$100000003;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000004;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000004;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000004;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000004$100000003;->this$0:Lcom/KITE/MainActivity$100000004;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000004$100000003;)Lcom/KITE/MainActivity$100000004;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000004$100000003;->this$0:Lcom/KITE/MainActivity$100000004;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 147
    invoke-interface {p1}, Landroid/content/DialogInterface;->cancel()V

    return-void
.end method
