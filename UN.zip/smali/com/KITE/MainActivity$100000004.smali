.class Lcom/KITE/MainActivity$100000004;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000004"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000004$100000002;,
        Lcom/KITE/MainActivity$100000004$100000003;
    }
.end annotation


# instance fields
.field private final synthetic val$defaultText:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000004;->val$defaultText:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 122
    :try_start_0
    new-instance v0, Landroid/app/AlertDialog$Builder;

    sget-object v1, Lcom/KITE/MainActivity;->instance:Lcom/KITE/MainActivity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 123
    const-string v1, "\u8bf7\u8f93\u5165\u5361\u5bc6"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 125
    new-instance v1, Landroid/widget/EditText;

    sget-object v2, Lcom/KITE/MainActivity;->instance:Lcom/KITE/MainActivity;

    invoke-direct {v1, v2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 126
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 127
    iget-object v2, p0, Lcom/KITE/MainActivity$100000004;->val$defaultText:Ljava/lang/String;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_0

    .line 128
    iget-object v2, p0, Lcom/KITE/MainActivity$100000004;->val$defaultText:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 129
    iget-object v2, p0, Lcom/KITE/MainActivity$100000004;->val$defaultText:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 131
    :cond_0
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 133
    const-string v2, "\u786e\u5b9a"

    new-instance v3, Lcom/KITE/MainActivity$100000004$100000002;

    invoke-direct {v3, p0, v1}, Lcom/KITE/MainActivity$100000004$100000002;-><init>(Lcom/KITE/MainActivity$100000004;Landroid/widget/EditText;)V

    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 144
    const-string v1, "\u53d6\u6d88"

    new-instance v2, Lcom/KITE/MainActivity$100000004$100000003;

    invoke-direct {v2, p0}, Lcom/KITE/MainActivity$100000004$100000003;-><init>(Lcom/KITE/MainActivity$100000004;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 151
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    .line 152
    sget-object v1, Lcom/KITE/MainActivity;->instance:Lcom/KITE/MainActivity;

    invoke-virtual {v1}, Lcom/KITE/MainActivity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_1

    .line 153
    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    goto :goto_0

    :catch_0
    move-exception v0

    .line 156
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    return-void
.end method
