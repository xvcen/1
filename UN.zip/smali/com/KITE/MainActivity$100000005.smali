.class Lcom/KITE/MainActivity$100000005;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000005;->this$0:Lcom/KITE/MainActivity;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000005;)Lcom/KITE/MainActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000005;->this$0:Lcom/KITE/MainActivity;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 213
    :try_start_0
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000000()Z

    move-result p1

    if-nez p1, :cond_1

    .line 214
    const/4 p1, 0x1

    invoke-static {p1}, Lcom/KITE/MainActivity;->access$S1000000(Z)V

    .line 215
    sget-boolean p1, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    if-eqz p1, :cond_0

    .line 216
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->GetIPC()Lcom/KITE/IPCCond/IMutual;

    move-result-object p1

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-interface {p1, v0}, Lcom/KITE/IPCCond/IMutual;->setPid(I)V

    .line 217
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->GetIPC()Lcom/KITE/IPCCond/IMutual;

    move-result-object p1

    invoke-static {}, Lcom/KITE/Util;->getAndroidID()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lcom/KITE/IPCCond/IMutual;->setUUid(Ljava/lang/String;)V

    goto :goto_0

    .line 219
    :cond_0
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result p1

    invoke-static {p1}, Lcom/KITE/SuperJNI;->setPid(I)V

    .line 220
    invoke-static {}, Lcom/KITE/Util;->getAndroidID()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/KITE/SuperJNI;->setUUid(Ljava/lang/String;)V

    .line 222
    :goto_0
    iget-object p1, p0, Lcom/KITE/MainActivity$100000005;->this$0:Lcom/KITE/MainActivity;

    invoke-static {p1}, Lcom/KITE/StartGame;->showFloatWindow(Landroid/app/Activity;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    goto :goto_1

    :catch_0
    move-exception p1

    .line 225
    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_1
    return-void
.end method
