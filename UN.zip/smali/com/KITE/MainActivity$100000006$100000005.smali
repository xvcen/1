.class Lcom/KITE/MainActivity$100000006$100000005;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000006;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000006$100000005$100000004;
    }
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000006;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000006;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000006$100000005;->this$0:Lcom/KITE/MainActivity$100000006;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000006$100000005;)Lcom/KITE/MainActivity$100000006;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000006$100000005;->this$0:Lcom/KITE/MainActivity$100000006;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 250
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lcom/KITE/MainActivity$100000006$100000005;->this$0:Lcom/KITE/MainActivity$100000006;

    invoke-static {v1}, Lcom/KITE/MainActivity$100000006;->access$0(Lcom/KITE/MainActivity$100000006;)Lcom/KITE/MainActivity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 251
    const-string v1, "\u63d0\u793a"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 252
    const-string v1, "\u65e0\u6cd5\u83b7\u53d6ROOT\u6743\u9650\uff0c\u8bf7\u68c0\u67e5\u60a8\u7684\u8bbe\u5907\u662f\u5426\u5df2ROOT\uff1f"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 253
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 254
    new-instance v1, Lcom/KITE/MainActivity$100000006$100000005$100000004;

    invoke-direct {v1, p0}, Lcom/KITE/MainActivity$100000006$100000005$100000004;-><init>(Lcom/KITE/MainActivity$100000006$100000005;)V

    const-string v2, "\u786e\u5b9a"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 262
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    .line 263
    nop

    .line 264
    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/16 v2, 0x7f6

    invoke-virtual {v1, v2}, Landroid/view/Window;->setType(I)V

    .line 265
    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    return-void
.end method
