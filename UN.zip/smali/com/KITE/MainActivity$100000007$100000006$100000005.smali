.class Lcom/KITE/MainActivity$100000007$100000006$100000005;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000007$100000006;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000007$100000006;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000007$100000006;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000007$100000006$100000005;->this$0:Lcom/KITE/MainActivity$100000007$100000006;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000007$100000006$100000005;)Lcom/KITE/MainActivity$100000007$100000006;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000007$100000006$100000005;->this$0:Lcom/KITE/MainActivity$100000007$100000006;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 242
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 243
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result p1

    invoke-static {p1}, Landroid/os/Process;->killProcess(I)V

    .line 244
    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/System;->exit(I)V

    return-void
.end method
