.class Lcom/KITE/MainActivity$100000008$100000007;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000008;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000007"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000008;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000008;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000008$100000007;->this$0:Lcom/KITE/MainActivity$100000008;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000008$100000007;)Lcom/KITE/MainActivity$100000008;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000008$100000007;->this$0:Lcom/KITE/MainActivity$100000008;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 260
    iget-object v0, p0, Lcom/KITE/MainActivity$100000008$100000007;->this$0:Lcom/KITE/MainActivity$100000008;

    invoke-static {v0}, Lcom/KITE/MainActivity$100000008;->access$0(Lcom/KITE/MainActivity$100000008;)Lcom/KITE/MainActivity;

    move-result-object v0

    const-string v1, "\u672a\u83b7\u53d6\u5230 ROOT \u6743\u9650\uff01"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
