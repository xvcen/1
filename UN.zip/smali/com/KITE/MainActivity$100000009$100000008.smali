.class Lcom/KITE/MainActivity$100000009$100000008;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000009;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000008"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000009;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000009;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000009$100000008;->this$0:Lcom/KITE/MainActivity$100000009;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000009$100000008;)Lcom/KITE/MainActivity$100000009;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000009$100000008;->this$0:Lcom/KITE/MainActivity$100000009;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 319
    iget-object v0, p0, Lcom/KITE/MainActivity$100000009$100000008;->this$0:Lcom/KITE/MainActivity$100000009;

    invoke-static {v0}, Lcom/KITE/MainActivity$100000009;->access$0(Lcom/KITE/MainActivity$100000009;)Lcom/KITE/MainActivity;

    move-result-object v0

    invoke-static {v0}, Lcom/KITE/MainActivity;->access$L1000032(Lcom/KITE/MainActivity;)Landroid/os/Handler;

    move-result-object v0

    const/16 v1, 0x3e8

    int-to-long v1, v1

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1, v2}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    .line 320
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000010()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f070003

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
