.class Lcom/KITE/MainActivity$100000009;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000009"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000009$100000008;
    }
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000009;->this$0:Lcom/KITE/MainActivity;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000009;)Lcom/KITE/MainActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000009;->this$0:Lcom/KITE/MainActivity;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 309
    :goto_0
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->isConnect()Z

    move-result v0

    if-nez v0, :cond_1

    sget-boolean v0, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    if-nez v0, :cond_0

    goto :goto_1

    .line 311
    :cond_0
    const/16 v0, 0x1f4

    int-to-long v0, v0

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 313
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_0

    .line 316
    :cond_1
    :goto_1
    iget-object v0, p0, Lcom/KITE/MainActivity$100000009;->this$0:Lcom/KITE/MainActivity;

    new-instance v1, Lcom/KITE/MainActivity$100000009$100000008;

    invoke-direct {v1, p0}, Lcom/KITE/MainActivity$100000009$100000008;-><init>(Lcom/KITE/MainActivity$100000009;)V

    invoke-virtual {v0, v1}, Lcom/KITE/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
