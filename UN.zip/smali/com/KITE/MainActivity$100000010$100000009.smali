.class Lcom/KITE/MainActivity$100000010$100000009;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000010;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000009"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000010;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000010;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000010$100000009;->this$0:Lcom/KITE/MainActivity$100000010;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000010$100000009;)Lcom/KITE/MainActivity$100000010;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000010$100000009;->this$0:Lcom/KITE/MainActivity$100000010;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 306
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000008()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f070003

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 307
    iget-object v0, p0, Lcom/KITE/MainActivity$100000010$100000009;->this$0:Lcom/KITE/MainActivity$100000010;

    invoke-static {v0}, Lcom/KITE/MainActivity$100000010;->access$0(Lcom/KITE/MainActivity$100000010;)Lcom/KITE/MainActivity;

    move-result-object v0

    invoke-static {v0}, Lcom/KITE/MainActivity;->access$1000025(Lcom/KITE/MainActivity;)V

    return-void
.end method
