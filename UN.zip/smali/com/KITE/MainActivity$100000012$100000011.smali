.class Lcom/KITE/MainActivity$100000012$100000011;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000012;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000011"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000012;

.field private final synthetic val$finalI:I

.field private final synthetic val$map:Ljava/util/HashMap;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000012;Ljava/util/HashMap;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000012$100000011;->this$0:Lcom/KITE/MainActivity$100000012;

    iput-object p2, p0, Lcom/KITE/MainActivity$100000012$100000011;->val$map:Ljava/util/HashMap;

    iput p3, p0, Lcom/KITE/MainActivity$100000012$100000011;->val$finalI:I

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000012$100000011;)Lcom/KITE/MainActivity$100000012;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000012$100000011;->this$0:Lcom/KITE/MainActivity$100000012;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 352
    iget-object v0, p0, Lcom/KITE/MainActivity$100000012$100000011;->val$map:Ljava/util/HashMap;

    new-instance v1, Ljava/lang/Boolean;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v3, "success"

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->replace(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 353
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000006()Lcom/KITE/MainActivity$MyAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/KITE/MainActivity$MyAdapter;->notifyDataSetChanged()V

    .line 354
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000004()Landroid/widget/ListView;

    move-result-object v0

    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000004()Landroid/widget/ListView;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/ListView;->getBottom()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setSelection(I)V

    .line 355
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000007()Landroid/widget/ProgressBar;

    move-result-object v0

    iget v1, p0, Lcom/KITE/MainActivity$100000012$100000011;->val$finalI:I

    add-int/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    return-void
.end method
