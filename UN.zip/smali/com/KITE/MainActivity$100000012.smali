.class Lcom/KITE/MainActivity$100000012;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000012"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000012$100000010;,
        Lcom/KITE/MainActivity$100000012$100000011;
    }
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity;

.field private final synthetic val$funs:[[Ljava/lang/Object;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity;[[Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000012;->this$0:Lcom/KITE/MainActivity;

    iput-object p2, p0, Lcom/KITE/MainActivity$100000012;->val$funs:[[Ljava/lang/Object;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000012;)Lcom/KITE/MainActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000012;->this$0:Lcom/KITE/MainActivity;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 332
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000007()Landroid/widget/ProgressBar;

    move-result-object v0

    iget-object v1, p0, Lcom/KITE/MainActivity$100000012;->val$funs:[[Ljava/lang/Object;

    array-length v1, v1

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 333
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lcom/KITE/MainActivity$100000012;->val$funs:[[Ljava/lang/Object;

    array-length v1, v1

    if-lt v0, v1, :cond_0

    return-void

    .line 334
    :cond_0
    nop

    .line 335
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 336
    iget-object v2, p0, Lcom/KITE/MainActivity$100000012;->this$0:Lcom/KITE/MainActivity;

    new-instance v3, Lcom/KITE/MainActivity$100000012$100000010;

    iget-object v4, p0, Lcom/KITE/MainActivity$100000012;->val$funs:[[Ljava/lang/Object;

    invoke-direct {v3, p0, v0, v4, v1}, Lcom/KITE/MainActivity$100000012$100000010;-><init>(Lcom/KITE/MainActivity$100000012;I[[Ljava/lang/Object;Ljava/util/HashMap;)V

    invoke-virtual {v2, v3}, Lcom/KITE/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 347
    iget-object v2, p0, Lcom/KITE/MainActivity$100000012;->val$funs:[[Ljava/lang/Object;

    aget-object v2, v2, v0

    const/4 v3, 0x1

    aget-object v2, v2, v3

    check-cast v2, Ljava/lang/Runnable;

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    .line 349
    iget-object v2, p0, Lcom/KITE/MainActivity$100000012;->this$0:Lcom/KITE/MainActivity;

    new-instance v3, Lcom/KITE/MainActivity$100000012$100000011;

    invoke-direct {v3, p0, v1, v0}, Lcom/KITE/MainActivity$100000012$100000011;-><init>(Lcom/KITE/MainActivity$100000012;Ljava/util/HashMap;I)V

    invoke-virtual {v2, v3}, Lcom/KITE/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 333
    add-int/lit8 v0, v0, 0x1

    goto :goto_0
.end method
