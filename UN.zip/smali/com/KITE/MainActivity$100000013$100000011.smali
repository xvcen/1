.class Lcom/KITE/MainActivity$100000013$100000011;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000013;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000011"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000013;

.field private final synthetic val$finalI:I

.field private final synthetic val$funs:[[Ljava/lang/Object;

.field private final synthetic val$map:Ljava/util/HashMap;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000013;I[[Ljava/lang/Object;Ljava/util/HashMap;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000013$100000011;->this$0:Lcom/KITE/MainActivity$100000013;

    iput p2, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$finalI:I

    iput-object p3, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$funs:[[Ljava/lang/Object;

    iput-object p4, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$map:Ljava/util/HashMap;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000013$100000011;)Lcom/KITE/MainActivity$100000013;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000013$100000011;->this$0:Lcom/KITE/MainActivity$100000013;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 296
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000006()Landroid/widget/TextView;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    iget v2, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$finalI:I

    const/4 v3, 0x1

    add-int/2addr v2, v3

    new-instance v4, Ljava/lang/Integer;

    invoke-direct {v4, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v2, 0x0

    aput-object v4, v1, v2

    iget-object v4, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$funs:[[Ljava/lang/Object;

    array-length v4, v4

    new-instance v5, Ljava/lang/Integer;

    invoke-direct {v5, v4}, Ljava/lang/Integer;-><init>(I)V

    aput-object v5, v1, v3

    const-string v3, "(%d/%d)"

    invoke-static {v3, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 297
    iget-object v0, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$map:Ljava/util/HashMap;

    iget-object v1, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$funs:[[Ljava/lang/Object;

    iget v3, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$finalI:I

    aget-object v1, v1, v3

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "msg"

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 298
    iget-object v0, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$map:Ljava/util/HashMap;

    new-instance v1, Ljava/lang/Boolean;

    invoke-direct {v1, v2}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v2, "success"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 299
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000003()Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, Lcom/KITE/MainActivity$100000013$100000011;->val$map:Ljava/util/HashMap;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 300
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000004()Lcom/KITE/MainActivity$MyAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/KITE/MainActivity$MyAdapter;->notifyDataSetChanged()V

    return-void
.end method
