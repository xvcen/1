.class Lcom/KITE/MainActivity$100000014;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000014"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000014;->this$0:Lcom/KITE/MainActivity;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000014;)Lcom/KITE/MainActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000014;->this$0:Lcom/KITE/MainActivity;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 466
    iget-object p1, p0, Lcom/KITE/MainActivity$100000014;->this$0:Lcom/KITE/MainActivity;

    invoke-static {p1}, Lcom/KITE/MainActivity;->access$1000019(Lcom/KITE/MainActivity;)V

    return-void
.end method
