.class Lcom/KITE/MainActivity$100000020$100000019;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000020;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000019"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000020;

.field private final synthetic val$app_update_url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000020;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000020$100000019;->this$0:Lcom/KITE/MainActivity$100000020;

    iput-object p2, p0, Lcom/KITE/MainActivity$100000020$100000019;->val$app_update_url:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000020$100000019;)Lcom/KITE/MainActivity$100000020;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000020$100000019;->this$0:Lcom/KITE/MainActivity$100000020;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 617
    sget-object p1, Lcom/KITE/MainActivity;->alertDialogs:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 619
    iget-object p1, p0, Lcom/KITE/MainActivity$100000020$100000019;->val$app_update_url:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 620
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 621
    iget-object p1, p0, Lcom/KITE/MainActivity$100000020$100000019;->this$0:Lcom/KITE/MainActivity$100000020;

    invoke-static {p1}, Lcom/KITE/MainActivity$100000020;->access$0(Lcom/KITE/MainActivity$100000020;)Lcom/KITE/MainActivity;

    move-result-object p1

    invoke-virtual {p1, v0}, Lcom/KITE/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
