.class Lcom/KITE/MainActivity$100000022$100000021;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000022;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000021"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000022;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000022;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000022$100000021;->this$0:Lcom/KITE/MainActivity$100000022;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000022$100000021;)Lcom/KITE/MainActivity$100000022;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000022$100000021;->this$0:Lcom/KITE/MainActivity$100000022;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 679
    sget-object p1, Lcom/KITE/MainActivity;->alertDialogs:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    .line 680
    sget-object p1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v0, "\u5df2\u786e\u5b9a\u516c\u544a"

    invoke-virtual {p1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    return-void
.end method
