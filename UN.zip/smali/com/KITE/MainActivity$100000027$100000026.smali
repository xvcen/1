.class Lcom/KITE/MainActivity$100000027$100000026;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$100000027;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000026"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/MainActivity$100000027;

.field private final synthetic val$edit:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/KITE/MainActivity$100000027;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000027$100000026;->this$0:Lcom/KITE/MainActivity$100000027;

    iput-object p2, p0, Lcom/KITE/MainActivity$100000027$100000026;->val$edit:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$100000027$100000026;)Lcom/KITE/MainActivity$100000027;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$100000027$100000026;->this$0:Lcom/KITE/MainActivity$100000027;

    return-object p0
.end method


# virtual methods
.method public run()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 796
    iget-object v0, p0, Lcom/KITE/MainActivity$100000027$100000026;->val$edit:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 797
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000015()Landroid/app/Activity;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 799
    if-eqz v0, :cond_0

    .line 800
    iget-object v1, p0, Lcom/KITE/MainActivity$100000027$100000026;->val$edit:Landroid/widget/EditText;

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    :cond_0
    return-void
.end method
