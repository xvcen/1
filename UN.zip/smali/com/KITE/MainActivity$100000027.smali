.class Lcom/KITE/MainActivity$100000027;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000027"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000027$100000025;,
        Lcom/KITE/MainActivity$100000027$100000026;
    }
.end annotation


# instance fields
.field private final synthetic val$initialText:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$100000027;->val$initialText:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 753
    :try_start_0
    new-instance v0, Landroid/widget/EditText;

    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000015()Landroid/app/Activity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 754
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setInputType(I)V

    .line 756
    iget-object v2, p0, Lcom/KITE/MainActivity$100000027;->val$initialText:Ljava/lang/String;

    if-eqz v2, :cond_0

    .line 757
    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 758
    iget-object v2, p0, Lcom/KITE/MainActivity$100000027;->val$initialText:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/EditText;->setSelection(I)V

    .line 761
    :cond_0
    new-instance v2, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v2}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    .line 762
    iput v1, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    iput v1, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 763
    const/16 v1, -0x2710

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 764
    const/4 v1, 0x2

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->type:I

    .line 765
    const/16 v1, 0x90

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 767
    const/4 v1, -0x2

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->format:I

    .line 769
    invoke-static {}, Lcom/KITE/MainActivity;->access$L1000015()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v1

    invoke-interface {v1, v0, v2}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 771
    new-instance v1, Lcom/KITE/MainActivity$100000027$100000025;

    invoke-direct {v1, p0, v0}, Lcom/KITE/MainActivity$100000027$100000025;-><init>(Lcom/KITE/MainActivity$100000027;Landroid/widget/EditText;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 791
    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 793
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    new-instance v2, Lcom/KITE/MainActivity$100000027$100000026;

    invoke-direct {v2, p0, v0}, Lcom/KITE/MainActivity$100000027$100000026;-><init>(Lcom/KITE/MainActivity$100000027;Landroid/widget/EditText;)V

    const/16 v0, 0x64

    int-to-long v3, v0

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 805
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    return-void
.end method
