.class public final Lcom/KITE/MainActivity$MyAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity$MyAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x31
    name = "ViewHolder"
.end annotation


# instance fields
.field public msg:Landroid/widget/TextView;

.field public progressBar:Landroid/widget/ProgressBar;

.field public success:Landroid/widget/ImageView;

.field private final this$0:Lcom/KITE/MainActivity$MyAdapter;


# direct methods
.method public constructor <init>(Lcom/KITE/MainActivity$MyAdapter;)V
    .locals 0

    .line 427
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->this$0:Lcom/KITE/MainActivity$MyAdapter;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$MyAdapter$ViewHolder;)Lcom/KITE/MainActivity$MyAdapter;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->this$0:Lcom/KITE/MainActivity$MyAdapter;

    return-object p0
.end method
