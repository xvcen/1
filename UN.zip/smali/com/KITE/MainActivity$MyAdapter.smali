.class Lcom/KITE/MainActivity$MyAdapter;
.super Landroid/widget/BaseAdapter;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "MyAdapter"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$MyAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private list:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private mInflater:Landroid/view/LayoutInflater;

.field private final this$0:Lcom/KITE/MainActivity;


# direct methods
.method public constructor <init>(Lcom/KITE/MainActivity;Landroid/content/Context;Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/KITE/MainActivity;",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;)V"
        }
    .end annotation

    .line 381
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    iput-object p1, p0, Lcom/KITE/MainActivity$MyAdapter;->this$0:Lcom/KITE/MainActivity;

    .line 382
    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Lcom/KITE/MainActivity$MyAdapter;->mInflater:Landroid/view/LayoutInflater;

    .line 383
    iput-object p3, p0, Lcom/KITE/MainActivity$MyAdapter;->list:Ljava/util/List;

    return-void
.end method

.method static access$0(Lcom/KITE/MainActivity$MyAdapter;)Lcom/KITE/MainActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity$MyAdapter;->this$0:Lcom/KITE/MainActivity;

    return-object p0
.end method


# virtual methods
.method public getCount()I
    .locals 1
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 388
    iget-object v0, p0, Lcom/KITE/MainActivity$MyAdapter;->list:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 393
    iget-object v0, p0, Lcom/KITE/MainActivity$MyAdapter;->list:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    return-object p1
.end method

.method public getItemId(I)J
    .locals 2
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 398
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 403
    const/4 p3, 0x0

    move-object v0, p3

    check-cast v0, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;

    .line 405
    if-nez p2, :cond_0

    .line 406
    new-instance p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;

    invoke-direct {p2, p0}, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;-><init>(Lcom/KITE/MainActivity$MyAdapter;)V

    .line 407
    iget-object v0, p0, Lcom/KITE/MainActivity$MyAdapter;->mInflater:Landroid/view/LayoutInflater;

    move-object v1, p3

    check-cast v1, Landroid/view/ViewGroup;

    const v1, 0x7f030001

    invoke-virtual {v0, v1, p3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p3

    .line 408
    const v0, 0x7f070004

    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->msg:Landroid/widget/TextView;

    .line 409
    const v0, 0x7f070006

    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->success:Landroid/widget/ImageView;

    .line 410
    const v0, 0x7f070005

    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    iput-object v0, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->progressBar:Landroid/widget/ProgressBar;

    .line 412
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 414
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;

    move-object v4, p3

    move-object p3, p2

    move-object p2, v4

    .line 416
    :goto_0
    iget-object v0, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->msg:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/KITE/MainActivity$MyAdapter;->list:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    const-string v2, "msg"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 417
    iget-object v0, p0, Lcom/KITE/MainActivity$MyAdapter;->list:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    const-string v0, "success"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    .line 418
    iget-object v0, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->success:Landroid/widget/ImageView;

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    const/16 v3, 0x8

    :goto_1
    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 419
    iget-object p2, p2, Lcom/KITE/MainActivity$MyAdapter$ViewHolder;->progressBar:Landroid/widget/ProgressBar;

    if-eqz p1, :cond_2

    const/16 v1, 0x8

    :cond_2
    invoke-virtual {p2, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 420
    return-object p3
.end method
