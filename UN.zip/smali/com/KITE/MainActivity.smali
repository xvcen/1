.class public Lcom/KITE/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/MainActivity$100000000;,
        Lcom/KITE/MainActivity$100000001;,
        Lcom/KITE/MainActivity$100000002;,
        Lcom/KITE/MainActivity$100000003;,
        Lcom/KITE/MainActivity$100000006;,
        Lcom/KITE/MainActivity$100000007;,
        Lcom/KITE/MainActivity$100000009;,
        Lcom/KITE/MainActivity$100000012;,
        Lcom/KITE/MainActivity$MyAdapter;,
        Lcom/KITE/MainActivity$100000014;,
        Lcom/KITE/MainActivity$100000015;,
        Lcom/KITE/MainActivity$100000016;,
        Lcom/KITE/MainActivity$100000017;,
        Lcom/KITE/MainActivity$100000018;,
        Lcom/KITE/MainActivity$100000020;,
        Lcom/KITE/MainActivity$100000022;,
        Lcom/KITE/MainActivity$100000023;,
        Lcom/KITE/MainActivity$100000024;,
        Lcom/KITE/MainActivity$100000013;
    }
.end annotation


# static fields
.field static WY_APPID:Ljava/lang/String;

.field static WY_APPKEY:Ljava/lang/String;

.field static WY_RC4KEY:Ljava/lang/String;

.field private static adapter:Lcom/KITE/MainActivity$MyAdapter;

.field static alertDialogs:Landroid/app/AlertDialog;

.field static alertDialogs1:Landroid/app/AlertDialog;

.field private static alertDialogss:Landroid/app/AlertDialog;

.field public static app_Operation_mode_root:Z

.field public static app_init_mode:Z

.field private static dialog:Landroid/app/AlertDialog;

.field static dialogs:Landroid/app/AlertDialog$Builder;

.field static dialogs1:Landroid/app/AlertDialog$Builder;

.field public static getContext:Landroid/content/Context;

.field private static init_win:Z

.field static linearLayouts:Landroid/widget/LinearLayout;

.field private static list:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private static listView:Landroid/widget/ListView;

.field private static m_activity:Landroid/app/Activity;

.field private static prog_text:Landroid/widget/TextView;

.field private static progressBar:Landroid/widget/ProgressBar;

.field private static time:I

.field static wy_url:Ljava/lang/String;

.field private static 倒计时:Landroid/widget/TextView;

.field static 当前版本号:Ljava/lang/String;

.field static 登录判断:Z

.field private static 窗口:Landroid/view/View;

.field private static 读:Landroid/widget/EditText;


# instance fields
.field private handler:Landroid/os/Handler;

.field public intent:Landroid/content/Intent;

.field private 卡密:Ljava/lang/String;

.field private 卡密内容:Ljava/lang/String;


# direct methods
.method static final constructor <clinit>()V
    .locals 2

    const-string v0, "wy.llua.cn"

    sput-object v0, Lcom/KITE/MainActivity;->wy_url:Ljava/lang/String;

    const-string v0, "77425"

    sput-object v0, Lcom/KITE/MainActivity;->WY_APPID:Ljava/lang/String;

    const-string v0, "fBIXJ8IoxV4D9d1Q"

    sput-object v0, Lcom/KITE/MainActivity;->WY_APPKEY:Ljava/lang/String;

    const-string v0, "BafXNBJ4j7PDt5W"

    sput-object v0, Lcom/KITE/MainActivity;->WY_RC4KEY:Ljava/lang/String;

    const-string v0, "1.1"

    sput-object v0, Lcom/KITE/MainActivity;->当前版本号:Ljava/lang/String;

    const/4 v0, 0x0

    sput-boolean v0, Lcom/KITE/MainActivity;->登录判断:Z

    sput-boolean v0, Lcom/KITE/MainActivity;->init_win:Z

    const/4 v1, 0x1

    sput v1, Lcom/KITE/MainActivity;->time:I

    sput-boolean v0, Lcom/KITE/MainActivity;->app_init_mode:Z

    sput-boolean v0, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 815
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    new-instance v0, Lcom/KITE/MainActivity$100000013;

    invoke-direct {v0, p0}, Lcom/KITE/MainActivity$100000013;-><init>(Lcom/KITE/MainActivity;)V

    iput-object v0, p0, Lcom/KITE/MainActivity;->handler:Landroid/os/Handler;

    return-void
.end method

.method private ActivityMain()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 435
    sget-boolean v0, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    .line 436
    new-instance v0, Landroid/content/Intent;

    :try_start_0
    const-string v3, "com.KITE.IPCCond.SuperMain"

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v3, Lcom/KITE/IPCCond/AIDLConnection;

    invoke-direct {v3, v1}, Lcom/KITE/IPCCond/AIDLConnection;-><init>(Z)V

    invoke-static {v0, v3}, Lcom/topjohnwu/superuser/ipc/RootService;->bind(Landroid/content/Intent;Landroid/content/ServiceConnection;)V

    .line 437
    sget-object v0, Lcom/KITE/MainActivity;->m_activity:Landroid/app/Activity;

    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 438
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v3, Ljava/lang/StringBuffer;

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    const-string v4, "appops set --uid "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    sget-object v4, Lcom/KITE/MainActivity;->m_activity:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v3, " android:system_alert_window allow"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lcom/KITE/ToolClass/FloatTool;->RunShell(Ljava/lang/String;Z)[B

    :cond_0
    goto :goto_0

    .line 436
    :catch_0
    move-exception v0

    new-instance v1, Ljava/lang/NoClassDefFoundError;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 441
    :cond_1
    const-string v0, "main"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 442
    invoke-direct {p0}, Lcom/KITE/MainActivity;->RequestPermission()V

    .line 445
    :goto_0
    sput-boolean v2, Lcom/KITE/MainActivity;->app_init_mode:Z

    .line 446
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-boolean v2, Lcom/KITE/MainActivity;->app_init_mode:Z

    new-instance v3, Ljava/lang/Boolean;

    invoke-direct {v3, v2}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v2, "app_init_mode"

    invoke-static {v0, v2, v3}, Lcom/KITE/ToolClass/SPUtils;->setParam(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)V

    .line 447
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    sget-boolean v2, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    new-instance v3, Ljava/lang/Boolean;

    invoke-direct {v3, v2}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v2, "app_Operation_mode_root"

    invoke-static {v0, v2, v3}, Lcom/KITE/ToolClass/SPUtils;->setParam(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)V

    .line 449
    const v0, 0x7f030002

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->setContentView(I)V

    .line 450
    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v2, 0x0

    move-object v3, v2

    check-cast v3, Landroid/view/ViewGroup;

    const/high16 v3, 0x7f030000

    invoke-virtual {v0, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    sput-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    .line 451
    const v2, 0x7f070002

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    sput-object v0, Lcom/KITE/MainActivity;->listView:Landroid/widget/ListView;

    .line 452
    sget-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    const v2, 0x7f070001

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ProgressBar;

    sput-object v0, Lcom/KITE/MainActivity;->progressBar:Landroid/widget/ProgressBar;

    .line 453
    sget-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    const/high16 v2, 0x7f070000

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sput-object v0, Lcom/KITE/MainActivity;->prog_text:Landroid/widget/TextView;

    .line 454
    sget-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    const v2, 0x7f070003

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    sput-object v0, Lcom/KITE/MainActivity;->倒计时:Landroid/widget/TextView;

    .line 456
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 457
    new-instance v0, Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const-string v3, "package:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v0, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 458
    const/16 v2, 0x115c

    invoke-virtual {p0, v0, v2}, Lcom/KITE/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 460
    :cond_2
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->更新()V

    .line 461
    const v0, 0x7f070009

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcom/KITE/MainActivity$100000014;

    invoke-direct {v2, p0}, Lcom/KITE/MainActivity$100000014;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 468
    const v0, 0x7f07000a

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcom/KITE/MainActivity$100000015;

    invoke-direct {v2, p0}, Lcom/KITE/MainActivity$100000015;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 480
    const v0, 0x7f070008

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcom/KITE/MainActivity$100000016;

    invoke-direct {v2, p0}, Lcom/KITE/MainActivity$100000016;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 510
    const v0, 0x7f07000b

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 511
    new-instance v2, Lcom/KITE/MainActivity$100000017;

    invoke-direct {v2, p0}, Lcom/KITE/MainActivity$100000017;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 520
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/KITE/MainActivity;->list:Ljava/util/List;

    .line 521
    new-instance v0, Lcom/KITE/MainActivity$MyAdapter;

    sget-object v2, Lcom/KITE/MainActivity;->list:Ljava/util/List;

    invoke-direct {v0, p0, p0, v2}, Lcom/KITE/MainActivity$MyAdapter;-><init>(Lcom/KITE/MainActivity;Landroid/content/Context;Ljava/util/List;)V

    sput-object v0, Lcom/KITE/MainActivity;->adapter:Lcom/KITE/MainActivity$MyAdapter;

    .line 522
    sget-object v2, Lcom/KITE/MainActivity;->listView:Landroid/widget/ListView;

    invoke-virtual {v2, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 523
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget-object v2, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    sput-object v0, Lcom/KITE/MainActivity;->dialog:Landroid/app/AlertDialog;

    .line 524
    sget-boolean v1, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    if-eqz v1, :cond_3

    .line 525
    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    .line 526
    invoke-direct {p0}, Lcom/KITE/MainActivity;->initMain()V

    :cond_3
    return-void
.end method

.method private RequestPermission()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 753
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 754
    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const-string v2, "package:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 755
    const/16 v1, 0x115c

    invoke-virtual {p0, v0, v1}, Lcom/KITE/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_0
    return-void
.end method

.method private SelectModeBox(Landroid/app/Activity;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 695
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    new-instance v0, Ljava/lang/Boolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v2, "app_Operation_mode_root"

    invoke-static {p1, v2, v0}, Lcom/KITE/ToolClass/SPUtils;->getParam(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sput-boolean p1, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    .line 696
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    new-instance v0, Ljava/lang/Boolean;

    invoke-direct {v0, v1}, Ljava/lang/Boolean;-><init>(Z)V

    const-string v2, "app_init_mode"

    invoke-static {p1, v2, v0}, Lcom/KITE/ToolClass/SPUtils;->getParam(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sput-boolean p1, Lcom/KITE/MainActivity;->app_init_mode:Z

    .line 697
    if-nez p1, :cond_0

    .line 701
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    sput-object p1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    .line 702
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 703
    sget-object p1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v0, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 704
    sget-object p1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    const/16 v0, 0x28

    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 705
    new-instance p1, Landroid/app/AlertDialog$Builder;

    const/4 v0, 0x5

    invoke-direct {p1, p0, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    sput-object p1, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    .line 706
    new-instance p1, Landroid/widget/TextView;

    invoke-direct {p1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 707
    const/high16 v3, -0x1000000

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 708
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v3, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 709
    const-string v3, "\u8fd0\u884c\u73af\u5883"

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 710
    const/high16 v3, 0x41980000    # 19.0f

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 711
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 712
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 713
    const-string v3, "ROOT"

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 714
    const/high16 v3, 0x41200000    # 10.0f

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 715
    invoke-virtual {v0, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 716
    const v4, -0xff3f01

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 717
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v5, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 718
    invoke-virtual {v0}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 719
    new-instance v6, Lcom/KITE/MainActivity$100000023;

    invoke-direct {v6, p0}, Lcom/KITE/MainActivity$100000023;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v0, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 727
    const/16 v6, 0x64

    iput v6, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 728
    new-instance v5, Landroid/widget/Button;

    invoke-direct {v5, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 729
    const-string v6, "\u6846\u67b6"

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 730
    invoke-virtual {v5, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 731
    invoke-virtual {v5, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 732
    invoke-virtual {v5, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 733
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v3}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 734
    invoke-virtual {v5}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 735
    new-instance v3, Lcom/KITE/MainActivity$100000024;

    invoke-direct {v3, p0}, Lcom/KITE/MainActivity$100000024;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v5, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 743
    const/16 v3, 0x19

    iput v3, v2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 744
    sget-object v2, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 745
    sget-object p1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 746
    sget-object p1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 747
    sget-object p1, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 748
    sget-object p1, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 749
    sget-object p1, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object p1

    sput-object p1, Lcom/KITE/MainActivity;->alertDialogs:Landroid/app/AlertDialog;

    return-void

    .line 698
    :cond_0
    invoke-direct {p0}, Lcom/KITE/MainActivity;->ActivityMain()V

    .line 699
    return-void
.end method

.method static synthetic access$1000019(Lcom/KITE/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/KITE/MainActivity;->频道Main()V

    return-void
.end method

.method static synthetic access$1000039(Lcom/KITE/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/KITE/MainActivity;->ActivityMain()V

    return-void
.end method

.method static synthetic access$L1000002()Z
    .locals 1

    sget-boolean v0, Lcom/KITE/MainActivity;->init_win:Z

    return v0
.end method

.method static synthetic access$L1000004()Landroid/widget/ListView;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->listView:Landroid/widget/ListView;

    return-object v0
.end method

.method static synthetic access$L1000005()Ljava/util/List;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->list:Ljava/util/List;

    return-object v0
.end method

.method static synthetic access$L1000006()Lcom/KITE/MainActivity$MyAdapter;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->adapter:Lcom/KITE/MainActivity$MyAdapter;

    return-object v0
.end method

.method static synthetic access$L1000007()Landroid/widget/ProgressBar;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->progressBar:Landroid/widget/ProgressBar;

    return-object v0
.end method

.method static synthetic access$L1000008()Landroid/widget/TextView;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->prog_text:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$L1000009()Landroid/widget/TextView;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->倒计时:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$L1000010()Landroid/view/View;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    return-object v0
.end method

.method static synthetic access$L1000011()Landroid/app/AlertDialog;
    .locals 1

    sget-object v0, Lcom/KITE/MainActivity;->dialog:Landroid/app/AlertDialog;

    return-object v0
.end method

.method static synthetic access$L1000012()I
    .locals 1

    sget v0, Lcom/KITE/MainActivity;->time:I

    return v0
.end method

.method static synthetic access$L1000032(Lcom/KITE/MainActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/KITE/MainActivity;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$S1000002(Z)V
    .locals 0

    sput-boolean p0, Lcom/KITE/MainActivity;->init_win:Z

    return-void
.end method

.method static synthetic access$S1000004(Landroid/widget/ListView;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->listView:Landroid/widget/ListView;

    return-void
.end method

.method static synthetic access$S1000005(Ljava/util/List;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->list:Ljava/util/List;

    return-void
.end method

.method static synthetic access$S1000006(Lcom/KITE/MainActivity$MyAdapter;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->adapter:Lcom/KITE/MainActivity$MyAdapter;

    return-void
.end method

.method static synthetic access$S1000007(Landroid/widget/ProgressBar;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->progressBar:Landroid/widget/ProgressBar;

    return-void
.end method

.method static synthetic access$S1000008(Landroid/widget/TextView;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->prog_text:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000009(Landroid/widget/TextView;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->倒计时:Landroid/widget/TextView;

    return-void
.end method

.method static synthetic access$S1000010(Landroid/view/View;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    return-void
.end method

.method static synthetic access$S1000011(Landroid/app/AlertDialog;)V
    .locals 0

    sput-object p0, Lcom/KITE/MainActivity;->dialog:Landroid/app/AlertDialog;

    return-void
.end method

.method static synthetic access$S1000012(I)V
    .locals 0

    sput p0, Lcom/KITE/MainActivity;->time:I

    return-void
.end method

.method static synthetic access$S1000032(Lcom/KITE/MainActivity;Landroid/os/Handler;)V
    .locals 0

    iput-object p1, p0, Lcom/KITE/MainActivity;->handler:Landroid/os/Handler;

    return-void
.end method

.method private initMain()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 242
    sget-object v0, Lcom/KITE/MainActivity;->窗口:Landroid/view/View;

    const v1, 0x7f070003

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 243
    const/4 v0, 0x3

    new-array v0, v0, [[Ljava/lang/Object;

    const/4 v1, 0x2

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "\u83b7\u53d6ROOT\u6743\u9650"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    new-instance v3, Lcom/KITE/MainActivity$100000006;

    invoke-direct {v3, p0}, Lcom/KITE/MainActivity$100000006;-><init>(Lcom/KITE/MainActivity;)V

    const/4 v5, 0x1

    aput-object v3, v2, v5

    aput-object v2, v0, v4

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "\u83b7\u53d6\u60ac\u6d6e\u7a97\u6743\u9650"

    aput-object v3, v2, v4

    new-instance v3, Lcom/KITE/MainActivity$100000007;

    invoke-direct {v3, p0}, Lcom/KITE/MainActivity$100000007;-><init>(Lcom/KITE/MainActivity;)V

    aput-object v3, v2, v5

    aput-object v2, v0, v5

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "\u8fde\u63a5\u670d\u52a1"

    aput-object v3, v2, v4

    new-instance v3, Lcom/KITE/MainActivity$100000009;

    invoke-direct {v3, p0}, Lcom/KITE/MainActivity$100000009;-><init>(Lcom/KITE/MainActivity;)V

    aput-object v3, v2, v5

    aput-object v2, v0, v1

    invoke-direct {p0, v0}, Lcom/KITE/MainActivity;->loadDeploy([[Ljava/lang/Object;)V

    return-void
.end method

.method private loadDeploy([[Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([[",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    .line 329
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/KITE/MainActivity$100000012;

    invoke-direct {v1, p0, p1}, Lcom/KITE/MainActivity$100000012;-><init>(Lcom/KITE/MainActivity;[[Ljava/lang/Object;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public static 读取文件(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 121
    const-string v0, ""

    .line 123
    :try_start_0
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 124
    new-instance p0, Ljava/io/InputStreamReader;

    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const-string v1, "UTF-8"

    invoke-direct {p0, v2, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 125
    new-instance v1, Ljava/io/BufferedReader;

    invoke-direct {v1, p0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 126
    const/4 p0, 0x0

    check-cast p0, Ljava/lang/String;

    .line 127
    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_0

    goto :goto_1

    .line 128
    :cond_0
    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 127
    :catch_0
    move-exception p0

    .line 131
    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    .line 133
    :goto_1
    return-object v0
.end method

.method private 频道Main()V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 158
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    .line 159
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 160
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 161
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    const/16 v1, 0x28

    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 162
    new-instance v0, Landroid/app/AlertDialog$Builder;

    const/4 v1, 0x5

    invoke-direct {v0, p0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    sput-object v0, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    .line 163
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 164
    const/high16 v3, -0x1000000

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 165
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v3, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 166
    const-string v3, "\u52a0\u5165\u9891\u9053"

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 167
    const/high16 v3, 0x41980000    # 19.0f

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 168
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 169
    new-instance v1, Landroid/widget/Button;

    invoke-direct {v1, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 170
    const-string v3, "TG\u9891\u9053"

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 171
    const/high16 v3, 0x41200000    # 10.0f

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 172
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 173
    const v4, -0xff3f01

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 174
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v5, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 175
    invoke-virtual {v1}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 176
    new-instance v6, Lcom/KITE/MainActivity$100000000;

    invoke-direct {v6, p0}, Lcom/KITE/MainActivity$100000000;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v1, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 184
    const/16 v6, 0x64

    iput v6, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 185
    new-instance v5, Landroid/widget/Button;

    invoke-direct {v5, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 186
    const-string v6, "Potato\u9891\u9053"

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 187
    invoke-virtual {v5, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 188
    invoke-virtual {v5, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 189
    invoke-virtual {v5, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 190
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 191
    invoke-virtual {v5}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 192
    new-instance v7, Lcom/KITE/MainActivity$100000001;

    invoke-direct {v7, p0}, Lcom/KITE/MainActivity$100000001;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v5, v7}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 200
    const/16 v7, 0x19

    iput v7, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 202
    new-instance v6, Landroid/widget/Button;

    invoke-direct {v6, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 203
    const-string v7, "\u521d\u604b\u60c5\u4eba\u5b98\u65b9QQ\u7fa4\u804a"

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 204
    invoke-virtual {v6, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 205
    invoke-virtual {v6, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 206
    invoke-virtual {v6, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 207
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 208
    invoke-virtual {v6}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 209
    new-instance v8, Lcom/KITE/MainActivity$100000002;

    invoke-direct {v8, p0}, Lcom/KITE/MainActivity$100000002;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v6, v8}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 217
    const/16 v8, 0x1e

    iput v8, v7, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 219
    new-instance v7, Landroid/widget/Button;

    invoke-direct {v7, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 220
    const-string v8, "\u53d6\u6d88"

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 221
    invoke-virtual {v7, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 222
    invoke-virtual {v7, v2}, Landroid/widget/Button;->setTextColor(I)V

    .line 223
    invoke-virtual {v7, v4}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 224
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v3}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 225
    invoke-virtual {v7}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 226
    new-instance v3, Lcom/KITE/MainActivity$100000003;

    invoke-direct {v3, p0}, Lcom/KITE/MainActivity$100000003;-><init>(Lcom/KITE/MainActivity;)V

    invoke-virtual {v7, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 231
    const/16 v3, 0x37

    iput v3, v2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 232
    sget-object v2, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 233
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 234
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 235
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 236
    sget-object v0, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 237
    sget-object v0, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 238
    sget-object v0, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    sget-object v1, Lcom/KITE/MainActivity;->linearLayouts:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 239
    sget-object v0, Lcom/KITE/MainActivity;->dialogs:Landroid/app/AlertDialog$Builder;

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v0

    sput-object v0, Lcom/KITE/MainActivity;->alertDialogs:Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 105
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 106
    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lcom/KITE/MainActivity;->requestWindowFeature(I)Z

    .line 107
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x17

    if-lt p1, v0, :cond_0

    .line 108
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0x2000

    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 110
    :cond_0
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const-string v0, "#E1F0F0F0"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 111
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->requestPermission()V

    .line 112
    invoke-virtual {p0}, Lcom/KITE/MainActivity;->储存权限()V

    .line 114
    sput-object p0, Lcom/KITE/MainActivity;->m_activity:Landroid/app/Activity;

    .line 115
    sput-object p0, Lcom/KITE/MainActivity;->getContext:Landroid/content/Context;

    .line 116
    invoke-direct {p0, p0}, Lcom/KITE/MainActivity;->SelectModeBox(Landroid/app/Activity;)V

    return-void
.end method

.method public requestPermission()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 761
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    const-string v2, "package:"

    if-lt v0, v1, :cond_0

    .line 762
    invoke-static {}, Landroid/os/Environment;->isExternalStorageManager()Z

    move-result v0

    if-nez v0, :cond_0

    .line 763
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 764
    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 765
    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->startActivity(Landroid/content/Intent;)V

    .line 769
    :cond_0
    nop

    .line 771
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_8

    .line 772
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    .line 773
    const/4 v0, 0x0

    goto :goto_0

    .line 772
    :cond_1
    const/4 v0, 0x1

    .line 775
    :goto_0
    const-string v4, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_2

    .line 776
    const/4 v0, 0x0

    .line 778
    :cond_2
    const-string v4, "android.permission.RECORD_AUDIO"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_3

    .line 779
    const/4 v0, 0x0

    .line 781
    :cond_3
    const-string v4, "android.permission.RESTART_PACKAGES"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_4

    .line 782
    const/4 v0, 0x0

    .line 784
    :cond_4
    const-string v4, "android.permission.REQUEST_COMPANION_RUN_IN_BACKGROUND"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_5

    .line 785
    const/4 v0, 0x0

    .line 787
    :cond_5
    const-string v4, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_6

    .line 788
    const/4 v0, 0x0

    .line 790
    :cond_6
    const-string v4, "android.permission.SYSTEM_ALERT_WINDOW"

    invoke-virtual {p0, v4}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_7

    .line 791
    goto :goto_1

    .line 790
    :cond_7
    move v3, v0

    .line 794
    :goto_1
    if-nez v3, :cond_8

    .line 795
    const-string v4, "android.permission.ACCESS_COARSE_LOCATION"

    const-string v5, "android.permission.ACCESS_FINE_LOCATION"

    const-string v6, "android.permission.READ_EXTERNAL_STORAGE"

    const-string v7, "android.permission.RECORD_AUDIO"

    const-string v8, "android.permission.RESTART_PACKAGES"

    const-string v9, "android.permission.REQUEST_COMPANION_RUN_IN_BACKGROUND"

    const-string v10, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const-string v11, "android.permission.SYSTEM_ALERT_WINDOW"

    const-string v12, "android.permission.WRITE_EXTERNAL_STORAGE"

    filled-new-array/range {v4 .. v12}, [Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x66

    invoke-virtual {p0, v0, v3}, Lcom/KITE/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 808
    :cond_8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v1, :cond_9

    .line 809
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_9

    .line 810
    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {p0}, Lcom/KITE/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 812
    const/16 v1, 0x6f

    invoke-virtual {p0, v0, v1}, Lcom/KITE/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_9
    return-void
.end method

.method public 储存权限()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 139
    nop

    .line 140
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_2

    .line 141
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-virtual {p0, v0}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 142
    const/4 v1, 0x0

    goto :goto_0

    .line 141
    :cond_0
    const/4 v1, 0x1

    .line 144
    :goto_0
    const-string v3, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-virtual {p0, v3}, Lcom/KITE/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_1

    .line 145
    goto :goto_1

    .line 144
    :cond_1
    move v2, v1

    .line 147
    :goto_1
    if-nez v2, :cond_2

    .line 148
    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    const-string v2, "android.permission.ACCESS_FINE_LOCATION"

    filled-new-array {v1, v2, v3, v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x66

    invoke-virtual {p0, v0, v1}, Lcom/KITE/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    :cond_2
    return-void
.end method

.method 公告()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 643
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/KITE/MainActivity$100000022;

    invoke-direct {v1, p0}, Lcom/KITE/MainActivity$100000022;-><init>(Lcom/KITE/MainActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method 更新()V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 575
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/KITE/MainActivity$100000020;

    invoke-direct {v1, p0}, Lcom/KITE/MainActivity$100000020;-><init>(Lcom/KITE/MainActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method 解绑(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 532
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/KITE/MainActivity$100000018;

    invoke-direct {v1, p0, p1}, Lcom/KITE/MainActivity$100000018;-><init>(Lcom/KITE/MainActivity;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method
