.class Lcom/KITE/PasteActivity$100000000;
.super Ljava/lang/Object;
.source "PasteActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/PasteActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/PasteActivity;

.field private final synthetic val$input:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/KITE/PasteActivity;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/PasteActivity$100000000;->this$0:Lcom/KITE/PasteActivity;

    iput-object p2, p0, Lcom/KITE/PasteActivity$100000000;->val$input:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lcom/KITE/PasteActivity$100000000;)Lcom/KITE/PasteActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/PasteActivity$100000000;->this$0:Lcom/KITE/PasteActivity;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 40
    iget-object p1, p0, Lcom/KITE/PasteActivity$100000000;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 41
    iget-object p1, p0, Lcom/KITE/PasteActivity$100000000;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 42
    sput-object p1, Lcom/KITE/SuperJNI;->lastPastedText:Ljava/lang/String;

    .line 44
    :try_start_0
    invoke-static {p1}, Lcom/KITE/SuperJNI;->sendKamiToCpp(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    .line 47
    :cond_0
    :goto_0
    iget-object p1, p0, Lcom/KITE/PasteActivity$100000000;->this$0:Lcom/KITE/PasteActivity;

    invoke-virtual {p1}, Lcom/KITE/PasteActivity;->finish()V

    return-void
.end method
