.class Lcom/KITE/PasteActivity$100000002;
.super Ljava/lang/Object;
.source "PasteActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/PasteActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/PasteActivity;


# direct methods
.method constructor <init>(Lcom/KITE/PasteActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/PasteActivity$100000002;->this$0:Lcom/KITE/PasteActivity;

    return-void
.end method

.method static access$0(Lcom/KITE/PasteActivity$100000002;)Lcom/KITE/PasteActivity;
    .locals 0

    iget-object p0, p0, Lcom/KITE/PasteActivity$100000002;->this$0:Lcom/KITE/PasteActivity;

    return-object p0
.end method


# virtual methods
.method public onCancel(Landroid/content/DialogInterface;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 59
    iget-object p1, p0, Lcom/KITE/PasteActivity$100000002;->this$0:Lcom/KITE/PasteActivity;

    invoke-virtual {p1}, Lcom/KITE/PasteActivity;->finish()V

    return-void
.end method
