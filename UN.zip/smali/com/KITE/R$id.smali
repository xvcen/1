.class public final Lcom/KITE/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "id"
.end annotation


# static fields
.field public static final Main_Hello:I = 0x7f070007

.field public static final go_app:I = 0x7f070003

.field public static final kaiqi:I = 0x7f070008

.field public static final list_start_info:I = 0x7f070002

.field public static final main_item_msg:I = 0x7f070004

.field public static final main_item_success:I = 0x7f070006

.field public static final prog_text:I = 0x7f070000

.field public static final progressBar:I = 0x7f070001

.field public static final progressBar2:I = 0x7f070005

.field public static final reset_im:I = 0x7f07000b

.field public static final 网盘:I = 0x7f07000a

.field public static final 群聊:I = 0x7f070009


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
