.class public final Lcom/KITE/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/R$attr;,
        Lcom/KITE/R$color;,
        Lcom/KITE/R$drawable;,
        Lcom/KITE/R$id;,
        Lcom/KITE/R$layout;,
        Lcom/KITE/R$string;,
        Lcom/KITE/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 58
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
