.class public Lcom/KITE/RC4Util;
.super Ljava/lang/Object;
.source "RC4Util.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 157
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static RC4Base([BLjava/lang/String;)[B
    .locals 6

    .line 142
    nop

    .line 143
    nop

    .line 144
    invoke-static {p1}, Lcom/KITE/RC4Util;->initKey(Ljava/lang/String;)[B

    move-result-object p1

    .line 145
    nop

    .line 146
    array-length v0, p0

    new-array v0, v0, [B

    .line 147
    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    array-length v4, p0

    if-lt v1, v4, :cond_0

    .line 156
    return-object v0

    .line 148
    :cond_0
    add-int/lit8 v2, v2, 0x1

    and-int/lit16 v2, v2, 0xff

    .line 149
    aget-byte v4, p1, v2

    and-int/lit16 v5, v4, 0xff

    add-int/2addr v5, v3

    and-int/lit16 v3, v5, 0xff

    .line 150
    nop

    .line 151
    aget-byte v5, p1, v3

    aput-byte v5, p1, v2

    .line 152
    aput-byte v4, p1, v3

    .line 153
    aget-byte v5, p1, v2

    and-int/lit16 v5, v5, 0xff

    and-int/lit16 v4, v4, 0xff

    add-int/2addr v5, v4

    and-int/lit16 v4, v5, 0xff

    .line 154
    aget-byte v5, p0, v1

    aget-byte v4, p1, v4

    xor-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, v0, v1

    .line 147
    add-int/lit8 v1, v1, 0x1

    goto :goto_0
.end method

.method public static bytesToHex([B)Ljava/lang/String;
    .locals 6

    .line 99
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    .line 100
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    array-length v3, p0

    if-lt v2, v3, :cond_0

    .line 107
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 101
    :cond_0
    aget-byte v3, p0, v2

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    .line 102
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x2

    if-ge v4, v5, :cond_1

    .line 103
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    .line 105
    :cond_1
    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 100
    add-int/lit8 v2, v2, 0x1

    goto :goto_0
.end method

.method public static decryRC4(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    .line 57
    if-eqz p0, :cond_1

    if-nez p1, :cond_0

    goto :goto_0

    .line 60
    :cond_0
    new-instance v0, Ljava/lang/String;

    invoke-static {p0}, Lcom/KITE/RC4Util;->hexToByte(Ljava/lang/String;)[B

    move-result-object p0

    invoke-static {p0, p1}, Lcom/KITE/RC4Util;->RC4Base([BLjava/lang/String;)[B

    move-result-object p0

    invoke-direct {v0, p0, p2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    return-object v0

    .line 58
    :cond_1
    :goto_0
    const/4 p0, 0x0

    move-object p1, p0

    check-cast p1, Ljava/lang/String;

    return-object p0
.end method

.method public static encryRC4Byte(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    .line 35
    if-eqz p0, :cond_3

    if-nez p1, :cond_0

    goto :goto_1

    .line 38
    :cond_0
    if-eqz p2, :cond_2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    .line 42
    :cond_1
    invoke-virtual {p0, p2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    .line 43
    invoke-static {p0, p1}, Lcom/KITE/RC4Util;->RC4Base([BLjava/lang/String;)[B

    move-result-object p0

    return-object p0

    .line 39
    :cond_2
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    .line 40
    invoke-static {p0, p1}, Lcom/KITE/RC4Util;->RC4Base([BLjava/lang/String;)[B

    move-result-object p0

    return-object p0

    .line 36
    :cond_3
    :goto_1
    const/4 p0, 0x0

    move-object p1, p0

    check-cast p1, [B

    return-object p0
.end method

.method public static encryRC4String(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    .line 19
    if-eqz p0, :cond_1

    if-nez p1, :cond_0

    goto :goto_0

    .line 22
    :cond_0
    invoke-static {p0, p1, p2}, Lcom/KITE/RC4Util;->encryRC4Byte(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p0

    invoke-static {p0}, Lcom/KITE/RC4Util;->bytesToHex([B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 20
    :cond_1
    :goto_0
    const/4 p0, 0x0

    move-object p1, p0

    check-cast p1, Ljava/lang/String;

    return-object p0
.end method

.method public static hexToByte(Ljava/lang/String;)[B
    .locals 7

    .line 117
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    .line 118
    nop

    .line 119
    rem-int/lit8 v1, v0, 0x2

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    .line 120
    add-int/lit8 v0, v0, 0x1

    .line 121
    div-int/lit8 v1, v0, 0x2

    new-array v1, v1, [B

    .line 122
    new-instance v3, Ljava/lang/StringBuffer;

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    const-string v4, "0"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    .line 124
    :cond_0
    div-int/lit8 v1, v0, 0x2

    new-array v1, v1, [B

    .line 126
    :goto_0
    nop

    .line 127
    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_1
    if-lt v3, v0, :cond_1

    .line 131
    return-object v1

    .line 128
    :cond_1
    add-int/lit8 v5, v3, 0x2

    invoke-virtual {p0, v3, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/16 v6, 0x10

    invoke-static {v3, v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    int-to-byte v3, v3

    aput-byte v3, v1, v4

    .line 129
    add-int/2addr v4, v2

    .line 127
    move v3, v5

    goto :goto_1
.end method

.method private static initKey(Ljava/lang/String;)[B
    .locals 8

    .line 70
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    .line 71
    const/16 v0, 0x100

    new-array v1, v0, [B

    .line 73
    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-lt v3, v0, :cond_2

    .line 76
    nop

    .line 77
    nop

    .line 78
    array-length v3, p0

    if-nez v3, :cond_0

    .line 79
    const/4 p0, 0x0

    move-object v0, p0

    check-cast v0, [B

    return-object p0

    .line 81
    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_1
    if-lt v2, v0, :cond_1

    .line 88
    return-object v1

    .line 82
    :cond_1
    aget-byte v5, p0, v3

    and-int/lit16 v5, v5, 0xff

    aget-byte v6, v1, v2

    and-int/lit16 v7, v6, 0xff

    add-int/2addr v5, v7

    add-int/2addr v5, v4

    and-int/lit16 v4, v5, 0xff

    .line 83
    nop

    .line 84
    aget-byte v5, v1, v4

    aput-byte v5, v1, v2

    .line 85
    aput-byte v6, v1, v4

    .line 86
    add-int/lit8 v3, v3, 0x1

    array-length v5, p0

    rem-int/2addr v3, v5

    .line 81
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 74
    :cond_2
    int-to-byte v4, v3

    aput-byte v4, v1, v3

    .line 73
    add-int/lit8 v3, v3, 0x1

    goto :goto_0
.end method
