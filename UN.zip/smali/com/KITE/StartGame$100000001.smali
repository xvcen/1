.class Lcom/KITE/StartGame$100000001;
.super Ljava/lang/Object;
.source "StartGame.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/StartGame;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final synthetic val$handler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/os/Handler;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/StartGame$100000001;->val$handler:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 124
    :try_start_0
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->GetIPC()Lcom/KITE/IPCCond/IMutual;

    move-result-object v0

    invoke-interface {v0}, Lcom/KITE/IPCCond/IMutual;->GetImGuiwinsize()[F

    move-result-object v0

    .line 125
    invoke-static {}, Lcom/KITE/StartGame;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v2, 0x0

    aget v2, v0, v2

    float-to-int v2, v2

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 126
    invoke-static {}, Lcom/KITE/StartGame;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v2, 0x1

    aget v2, v0, v2

    float-to-int v2, v2

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 127
    invoke-static {}, Lcom/KITE/StartGame;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v2, 0x2

    aget v2, v0, v2

    float-to-int v2, v2

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 128
    invoke-static {}, Lcom/KITE/StartGame;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v2, 0x3

    aget v0, v0, v2

    float-to-int v0, v0

    iput v0, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 129
    invoke-static {}, Lcom/KITE/StartGame;->access$L1000000()Landroid/view/WindowManager;

    move-result-object v0

    invoke-static {}, Lcom/KITE/StartGame;->access$L1000001()Landroid/view/View;

    move-result-object v1

    invoke-static {}, Lcom/KITE/StartGame;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 131
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    .line 133
    :goto_0
    iget-object v0, p0, Lcom/KITE/StartGame$100000001;->val$handler:Landroid/os/Handler;

    const/16 v1, 0x11

    int-to-long v1, v1

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
