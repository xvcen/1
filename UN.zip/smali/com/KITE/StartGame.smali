.class public Lcom/KITE/StartGame;
.super Ljava/lang/Object;
.source "StartGame.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/StartGame$100000000;,
        Lcom/KITE/StartGame$100000001;,
        Lcom/KITE/StartGame$100000002;
    }
.end annotation


# static fields
.field private static Touch_Params:Landroid/view/WindowManager$LayoutParams;

.field private static Touch_View:Landroid/view/View;

.field private static manager:Landroid/view/WindowManager;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 153
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$L1000000()Landroid/view/WindowManager;
    .locals 1

    sget-object v0, Lcom/KITE/StartGame;->manager:Landroid/view/WindowManager;

    return-object v0
.end method

.method static synthetic access$L1000001()Landroid/view/View;
    .locals 1

    sget-object v0, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    return-object v0
.end method

.method static synthetic access$L1000002()Landroid/view/WindowManager$LayoutParams;
    .locals 1

    sget-object v0, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    return-object v0
.end method

.method static synthetic access$S1000000(Landroid/view/WindowManager;)V
    .locals 0

    sput-object p0, Lcom/KITE/StartGame;->manager:Landroid/view/WindowManager;

    return-void
.end method

.method static synthetic access$S1000001(Landroid/view/View;)V
    .locals 0

    sput-object p0, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    return-void
.end method

.method static synthetic access$S1000002(Landroid/view/WindowManager$LayoutParams;)V
    .locals 0

    sput-object p0, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    return-void
.end method

.method public static showFloatWindow(Landroid/app/Activity;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 31
    const-string v0, "window"

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    sput-object v0, Lcom/KITE/StartGame;->manager:Landroid/view/WindowManager;

    .line 33
    new-instance v0, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v0}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    .line 34
    const/16 v1, 0x1706

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->systemUiVisibility:I

    .line 40
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x7f6

    const/16 v3, 0x7d3

    const/16 v4, 0x1a

    if-lt v1, v4, :cond_0

    const/16 v1, 0x7f6

    goto :goto_0

    :cond_0
    const/16 v1, 0x7d3

    :goto_0
    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    .line 41
    const/16 v1, 0x33

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 42
    const/4 v5, -0x2

    iput v5, v0, Landroid/view/WindowManager$LayoutParams;->format:I

    .line 43
    const/4 v6, -0x1

    iput v6, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 44
    iput v6, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 45
    const v6, 0x41000738

    iput v6, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 57
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x1

    const/16 v8, 0x1c

    if-lt v6, v8, :cond_1

    .line 58
    iput v7, v0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    .line 61
    :cond_1
    new-instance v6, Landroid/view/View;

    invoke-direct {v6, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    sput-object v6, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    .line 64
    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v6}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    sput-object v6, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    .line 65
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v9, v4, :cond_2

    goto :goto_1

    :cond_2
    const/16 v2, 0x7d3

    :goto_1
    iput v2, v6, Landroid/view/WindowManager$LayoutParams;->type:I

    .line 66
    sget-object v2, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 67
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    iput v5, v1, Landroid/view/WindowManager$LayoutParams;->format:I

    .line 68
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    const/16 v2, 0x302

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 69
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    const/16 v2, 0x30c

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 70
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    const/16 v2, 0x3c

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 71
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 72
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v1, v8, :cond_3

    .line 73
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    iput v7, v1, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    .line 76
    :cond_3
    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    const v2, 0x41000728

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 85
    sget-object v1, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    new-instance v2, Lcom/KITE/StartGame$100000000;

    invoke-direct {v2}, Lcom/KITE/StartGame$100000000;-><init>()V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 103
    new-instance v1, Lcom/KITE/TV;

    invoke-direct {v1, p0}, Lcom/KITE/TV;-><init>(Landroid/content/Context;)V

    .line 105
    invoke-virtual {v1}, Lcom/KITE/TV;->getApplicationWindowToken()Landroid/os/IBinder;

    move-result-object p0

    iput-object p0, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 106
    sget-object p0, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    sget-object v2, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getApplicationWindowToken()Landroid/os/IBinder;

    move-result-object v2

    iput-object v2, p0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 108
    sget-object p0, Lcom/KITE/StartGame;->manager:Landroid/view/WindowManager;

    invoke-interface {p0, v1, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 109
    sget-object p0, Lcom/KITE/StartGame;->manager:Landroid/view/WindowManager;

    sget-object v0, Lcom/KITE/StartGame;->Touch_View:Landroid/view/View;

    sget-object v1, Lcom/KITE/StartGame;->Touch_Params:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {p0, v0, v1}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 110
    sget-boolean p0, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    if-eqz p0, :cond_4

    .line 111
    invoke-static {}, Lcom/KITE/StartGame;->updateTouchWinSize()V

    goto :goto_2

    .line 113
    :cond_4
    invoke-static {}, Lcom/KITE/StartGame;->updateTouchWinSize_not_root()V

    :goto_2
    return-void
.end method

.method public static updateTouchWinSize()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 119
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 120
    new-instance v1, Lcom/KITE/StartGame$100000001;

    invoke-direct {v1, v0}, Lcom/KITE/StartGame$100000001;-><init>(Landroid/os/Handler;)V

    const/16 v2, 0x11

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static updateTouchWinSize_not_root()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 140
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 141
    new-instance v1, Lcom/KITE/StartGame$100000002;

    invoke-direct {v1, v0}, Lcom/KITE/StartGame$100000002;-><init>(Landroid/os/Handler;)V

    const/16 v2, 0x11

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
