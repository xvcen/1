.class Lcom/KITE/SuperJNI$100000001$100000000;
.super Ljava/lang/Object;
.source "SuperJNI.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/SuperJNI$100000001;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/SuperJNI$100000001;

.field private final synthetic val$input:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/KITE/SuperJNI$100000001;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/SuperJNI$100000001$100000000;->this$0:Lcom/KITE/SuperJNI$100000001;

    iput-object p2, p0, Lcom/KITE/SuperJNI$100000001$100000000;->val$input:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lcom/KITE/SuperJNI$100000001$100000000;)Lcom/KITE/SuperJNI$100000001;
    .locals 0

    iget-object p0, p0, Lcom/KITE/SuperJNI$100000001$100000000;->this$0:Lcom/KITE/SuperJNI$100000001;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 44
    iget-object p1, p0, Lcom/KITE/SuperJNI$100000001$100000000;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 45
    iget-object p1, p0, Lcom/KITE/SuperJNI$100000001$100000000;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    sput-object p1, Lcom/KITE/SuperJNI;->lastPastedText:Ljava/lang/String;

    :cond_0
    return-void
.end method
