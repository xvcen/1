.class Lcom/KITE/SuperJNI$100000002$100000001;
.super Ljava/lang/Object;
.source "SuperJNI.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/SuperJNI$100000002;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/SuperJNI$100000002;

.field private final synthetic val$input:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lcom/KITE/SuperJNI$100000002;Landroid/widget/EditText;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/SuperJNI$100000002$100000001;->this$0:Lcom/KITE/SuperJNI$100000002;

    iput-object p2, p0, Lcom/KITE/SuperJNI$100000002$100000001;->val$input:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lcom/KITE/SuperJNI$100000002$100000001;)Lcom/KITE/SuperJNI$100000002;
    .locals 0

    iget-object p0, p0, Lcom/KITE/SuperJNI$100000002$100000001;->this$0:Lcom/KITE/SuperJNI$100000002;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 76
    iget-object p1, p0, Lcom/KITE/SuperJNI$100000002$100000001;->val$input:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 77
    sput-object p1, Lcom/KITE/SuperJNI;->lastPastedText:Ljava/lang/String;

    .line 79
    :try_start_0
    invoke-static {p1}, Lcom/KITE/SuperJNI;->sendKamiToCpp(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    :goto_0
    return-void
.end method
