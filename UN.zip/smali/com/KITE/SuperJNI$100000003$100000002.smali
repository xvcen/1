.class Lcom/KITE/SuperJNI$100000003$100000002;
.super Ljava/lang/Object;
.source "SuperJNI.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/SuperJNI$100000003;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/KITE/SuperJNI$100000003;

.field private final synthetic val$layout:Landroid/widget/LinearLayout;

.field private final synthetic val$wm:Landroid/view/WindowManager;


# direct methods
.method constructor <init>(Lcom/KITE/SuperJNI$100000003;Landroid/view/WindowManager;Landroid/widget/LinearLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/SuperJNI$100000003$100000002;->this$0:Lcom/KITE/SuperJNI$100000003;

    iput-object p2, p0, Lcom/KITE/SuperJNI$100000003$100000002;->val$wm:Landroid/view/WindowManager;

    iput-object p3, p0, Lcom/KITE/SuperJNI$100000003$100000002;->val$layout:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$0(Lcom/KITE/SuperJNI$100000003$100000002;)Lcom/KITE/SuperJNI$100000003;
    .locals 0

    iget-object p0, p0, Lcom/KITE/SuperJNI$100000003$100000002;->this$0:Lcom/KITE/SuperJNI$100000003;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 140
    :try_start_0
    iget-object p1, p0, Lcom/KITE/SuperJNI$100000003$100000002;->val$wm:Landroid/view/WindowManager;

    iget-object v0, p0, Lcom/KITE/SuperJNI$100000003$100000002;->val$layout:Landroid/widget/LinearLayout;

    invoke-interface {p1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    :goto_0
    return-void
.end method
