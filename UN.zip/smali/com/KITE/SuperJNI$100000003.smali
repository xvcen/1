.class Lcom/KITE/SuperJNI$100000003;
.super Ljava/lang/Object;
.source "SuperJNI.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/SuperJNI;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/KITE/SuperJNI$100000003$100000001;,
        Lcom/KITE/SuperJNI$100000003$100000002;
    }
.end annotation


# instance fields
.field private final synthetic val$ctx:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 65
    :try_start_0
    iget-object v0, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    const-string v1, "window"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    .line 66
    if-nez v0, :cond_0

    return-void

    .line 69
    :cond_0
    new-instance v1, Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 70
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 71
    const v2, -0xddddde

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 72
    const/16 v2, 0x28

    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 75
    new-instance v2, Landroid/widget/EditText;

    iget-object v3, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 76
    const-string v3, "\u957f\u6309\u6b64\u5904\u7c98\u8d34\u5361\u5bc6"

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 77
    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setTextColor(I)V

    .line 78
    const v3, -0x77000001

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setHintTextColor(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 82
    const/4 v3, 0x0

    :try_start_1
    iget-object v4, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    const-string v5, "clipboard"

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/ClipboardManager;

    .line 83
    if-eqz v4, :cond_1

    invoke-virtual {v4}, Landroid/content/ClipboardManager;->hasPrimaryClip()Z

    move-result v5

    if-eqz v5, :cond_1

    .line 84
    invoke-virtual {v4}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    move-result-object v4

    .line 85
    if-eqz v4, :cond_1

    invoke-virtual {v4}, Landroid/content/ClipData;->getItemCount()I

    move-result v5

    if-lez v5, :cond_1

    .line 86
    invoke-virtual {v4, v3}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object v4

    iget-object v5, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-virtual {v4, v5}, Landroid/content/ClipData$Item;->coerceToText(Landroid/content/Context;)Ljava/lang/CharSequence;

    move-result-object v4

    .line 87
    if-eqz v4, :cond_1

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_1

    .line 88
    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 89
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/EditText;->setSelection(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :cond_1
    goto :goto_0

    :catch_0
    move-exception v4

    .line 94
    :try_start_2
    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V

    .line 98
    :goto_0
    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v5, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 99
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 100
    const v3, 0x800005

    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 102
    new-instance v3, Landroid/widget/Button;

    iget-object v5, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-direct {v3, v5}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 103
    const-string v5, "\u53d6\u6d88"

    invoke-virtual {v3, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 105
    new-instance v5, Landroid/widget/Button;

    iget-object v6, p0, Lcom/KITE/SuperJNI$100000003;->val$ctx:Landroid/content/Context;

    invoke-direct {v5, v6}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 106
    const-string v6, "\u786e\u5b9a"

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 108
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 109
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 111
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 112
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 115
    new-instance v4, Landroid/view/WindowManager$LayoutParams;

    const/4 v8, -0x1

    const/4 v9, -0x2

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1a

    if-lt v6, v7, :cond_2

    const/16 v6, 0x7f6

    const/16 v10, 0x7f6

    goto :goto_1

    :cond_2
    const/16 v6, 0x7d2

    const/16 v10, 0x7d2

    :goto_1
    const/16 v11, 0x20

    const/4 v12, -0x3

    move-object v7, v4

    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 124
    const/16 v6, 0x11

    iput v6, v4, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 127
    new-instance v6, Lcom/KITE/SuperJNI$100000003$100000001;

    invoke-direct {v6, p0, v2, v0, v1}, Lcom/KITE/SuperJNI$100000003$100000001;-><init>(Lcom/KITE/SuperJNI$100000003;Landroid/widget/EditText;Landroid/view/WindowManager;Landroid/widget/LinearLayout;)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 137
    new-instance v2, Lcom/KITE/SuperJNI$100000003$100000002;

    invoke-direct {v2, p0, v0, v1}, Lcom/KITE/SuperJNI$100000003$100000002;-><init>(Lcom/KITE/SuperJNI$100000003;Landroid/view/WindowManager;Landroid/widget/LinearLayout;)V

    invoke-virtual {v3, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 145
    invoke-interface {v0, v1, v4}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_2

    :catch_1
    move-exception v0

    .line 148
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_2
    return-void
.end method
