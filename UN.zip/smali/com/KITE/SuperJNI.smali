.class public Lcom/KITE/SuperJNI;
.super Ljava/lang/Object;
.source "SuperJNI.java"


# static fields
.field private static appContext:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native GetImGuiwinsize()[F
.end method

.method public static native MotionEventClick(IFF)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation
.end method

.method public static getContext()Landroid/content/Context;
    .locals 1

    .line 8
    sget-object v0, Lcom/KITE/SuperJNI;->appContext:Landroid/content/Context;

    return-object v0
.end method

.method public static native setKey(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native setPid(I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation
.end method

.method public static native setSurface(Landroid/view/Surface;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/Surface;",
            ")V"
        }
    .end annotation
.end method

.method public static native setUUid(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation
.end method

.method public static native start(II)Ljava/lang/String;
.end method
