.class public Lcom/KITE/TV;
.super Landroid/view/TextureView;
.source "TV.java"

# interfaces
.implements Landroid/view/TextureView$SurfaceTextureListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 20
    invoke-direct {p0, p1}, Landroid/view/TextureView;-><init>(Landroid/content/Context;)V

    .line 21
    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lcom/KITE/TV;->setOpaque(Z)V

    .line 22
    invoke-virtual {p0, p0}, Lcom/KITE/TV;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    return-void
.end method


# virtual methods
.method public onSurfaceTextureAvailable(Landroid/graphics/SurfaceTexture;II)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/SurfaceTexture;",
            "II)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 28
    :try_start_0
    sget-boolean v0, Lcom/KITE/MainActivity;->app_Operation_mode_root:Z

    if-eqz v0, :cond_0

    .line 29
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->GetIPC()Lcom/KITE/IPCCond/IMutual;

    move-result-object v0

    invoke-interface {v0, p2, p3}, Lcom/KITE/IPCCond/IMutual;->start(II)Ljava/lang/String;

    .line 30
    invoke-static {}, Lcom/KITE/IPCCond/IPCService;->GetIPC()Lcom/KITE/IPCCond/IMutual;

    move-result-object p2

    new-instance p3, Landroid/view/Surface;

    invoke-direct {p3, p1}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    invoke-interface {p2, p3}, Lcom/KITE/IPCCond/IMutual;->setSurface(Landroid/view/Surface;)V

    goto :goto_0

    .line 32
    :cond_0
    invoke-static {p2, p3}, Lcom/KITE/SuperJNI;->start(II)Ljava/lang/String;

    .line 33
    new-instance p2, Landroid/view/Surface;

    invoke-direct {p2, p1}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    invoke-static {p2}, Lcom/KITE/SuperJNI;->setSurface(Landroid/view/Surface;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    goto :goto_1

    :catch_0
    move-exception p1

    .line 36
    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    .line 38
    :goto_1
    const-string p1, "TV"

    const-string p2, "surfaceCreated_"

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public onSurfaceTextureDestroyed(Landroid/graphics/SurfaceTexture;)Z
    .locals 1
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 47
    const-string p1, "NDK-java"

    const-string v0, "onSurfaceTextureDestroyed"

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 48
    const/4 p1, 0x0

    return p1
.end method

.method public onSurfaceTextureSizeChanged(Landroid/graphics/SurfaceTexture;II)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/SurfaceTexture;",
            "II)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onSurfaceTextureUpdated(Landroid/graphics/SurfaceTexture;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/SurfaceTexture;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method
