.class Lcom/KITE/Util$100000001;
.super Ljava/lang/Object;
.source "Util.java"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/KITE/Util;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Landroid/media/MediaPlayer;II)Z
    .locals 0
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 324
    invoke-static {}, Lcom/KITE/Util;->stopPlay()V

    .line 326
    const/4 p1, 0x1

    return p1
.end method
