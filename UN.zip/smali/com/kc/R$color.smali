.class public final Lcom/kc/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/kc/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "color"
.end annotation


# static fields
.field public static final black:I = 0x7f040008

.field public static final colorAccent:I = 0x7f040002

.field public static final colorPrimary:I = 0x7f040000

.field public static final colorPrimaryDark:I = 0x7f040001

.field public static final purple_200:I = 0x7f040003

.field public static final purple_500:I = 0x7f040004

.field public static final purple_700:I = 0x7f040005

.field public static final teal_200:I = 0x7f040006

.field public static final teal_700:I = 0x7f040007

.field public static final white:I = 0x7f040009


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
