.class public final Lcom/kc/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/kc/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "drawable"
.end annotation


# static fields
.field public static final box_input:I = 0x7f020000

.field public static final box_input1:I = 0x7f020001

.field public static final box_save:I = 0x7f020002

.field public static final box_save2:I = 0x7f020003

.field public static final ic_alert_octagram:I = 0x7f020004

.field public static final ic_success:I = 0x7f020005

.field public static final icon:I = 0x7f020006


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
