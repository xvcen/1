.class public final Lcom/kc/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/kc/R$attr;,
        Lcom/kc/R$color;,
        Lcom/kc/R$drawable;,
        Lcom/kc/R$id;,
        Lcom/kc/R$layout;,
        Lcom/kc/R$string;,
        Lcom/kc/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 58
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
