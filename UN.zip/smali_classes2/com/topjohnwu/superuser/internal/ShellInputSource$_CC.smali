.class public final synthetic Lcom/topjohnwu/superuser/internal/ShellInputSource$_CC;
.super Ljava/lang/Object;
.source "ShellInputSource.java"


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    kind = 0x8
    versionHash = "b33e07cc0d03f9f0e6c4c883743d0373fd130388f5a551bfa15ea60a927a2ecb"
.end annotation


# direct methods
.method public static $default$close(Lcom/topjohnwu/superuser/internal/ShellInputSource;)V
    .locals 0

    .line 0
    return-void
.end method
