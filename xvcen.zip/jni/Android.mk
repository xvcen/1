LOCAL_PATH := $(call my-dir)

_XV_SEED_RESULT := $(shell python3 "$(LOCAL_PATH)/tools/generate_build.py" "$(LOCAL_PATH)/include/Auth/xvbuild.h" >/dev/null 2>&1 || printf failed)
ifneq ($(_XV_SEED_RESULT),)
$(error build seed generation failed)
endif

include $(CLEAR_VARS)

LOCAL_MODULE := xvcen.sh

_PB     := $(LOCAL_PATH)/libs
_ABI    := $(TARGET_ARCH_ABI)
_CURL   := $(_PB)/curl/$(_ABI)
_SSL    := $(_PB)/openssl/$(_ABI)
_SODIUM := $(_PB)/sodium/$(_ABI)

ifneq ($(wildcard $(_SODIUM)/lib/libsodium.a),)
_XV_SODIUM_LIB := $(_SODIUM)/lib/libsodium.a
else
$(error libsodium static library missing for $(_ABI): expected $(_SODIUM)/lib/libsodium.a)
endif

_CF := -O3 -ffast-math -march=armv8-a+simd -mtune=cortex-a76 \
       -fomit-frame-pointer -ffunction-sections -fdata-sections \
       -fvisibility=hidden -fvisibility-inlines-hidden \
       -DUSE_OPENGL -DNDEBUG -w \
       -fstack-protector-strong \
       -fPIE \
       -fno-ident \
       -fno-jump-tables \
       -fstrict-aliasing \
       -fno-delete-null-pointer-checks \
       -fno-strict-overflow \
       -fno-builtin-memcpy \
       -fno-builtin-memset \
       -fno-builtin-strlen \
       -fno-builtin-strcmp \
       -funwind-tables \
       -fasynchronous-unwind-tables \
       -fmerge-all-constants \
       -fno-math-errno \
       -DIMGUI_DISABLE_DEBUG_TOOLS \
       -DIMGUI_DISABLE_DEMO_WINDOWS \

LOCAL_CPPFLAGS := $(_CF) -std=c++20 -fexceptions -fno-rtti -fpermissive -Wno-error=format-security -Wno-error=c++11-narrowing
LOCAL_CFLAGS   := $(_CF) -std=c99

LOCAL_LDFLAGS := -Wl,--gc-sections,-s,--strip-all -Wl,-x -Wl,--build-id=none -Wl,--exclude-libs,ALL -pie -fPIE \
                 -Wl,--as-needed -Wl,-O2 -Wl,--icf=safe -Wl,--hash-style=gnu

LOCAL_C_INCLUDES += $(LOCAL_PATH)/include $(LOCAL_PATH)/include/Auth $(LOCAL_PATH)/include/ImGui $(LOCAL_PATH)/include/ImGui/backends $(LOCAL_PATH)/src $(LOCAL_PATH)/src/Auth $(LOCAL_PATH)/gen
LOCAL_C_INCLUDES += $(_CURL)/include $(_SSL)/include $(_SODIUM)/include

LOCAL_SRC_FILES := \
    src/main.cpp src/game.cpp src/Android_draw/draw.cpp src/Android_touch/TouchHelperA.cpp \
    src/Blur/Blur.cpp \
    src/animations.cpp src/Auth/auth.cpp src/Auth/integrity.cpp src/Auth/statefile.cpp \
    src/Auth/xvseal.cpp \
    src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp src/ImGui/imgui_tables.cpp \
    src/ImGui/imgui_widgets.cpp src/ImGui/backends/imgui_impl_android.cpp \
    src/ImGui/backends/imgui_impl_opengl3.cpp

LOCAL_LDLIBS := -landroid -lEGL -lGLESv3 -lOpenSLES \
    $(_XV_SODIUM_LIB) \
    $(_CURL)/lib/libcurl.a $(_SSL)/lib/libssl.a $(_SSL)/lib/libcrypto.a \
    -lz -ldl

include $(BUILD_EXECUTABLE)
