APP_ABI      := arm64-v8a
APP_PLATFORM := android-24
APP_STL      := c++_static
APP_OPTIM    := release
APP_PIE      := true
