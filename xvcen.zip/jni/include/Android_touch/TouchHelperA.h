#pragma once

#include <cstdint>

bool Touch_Init(int w, int h, uint32_t orientation_, bool readOnly);
void UpdateScreenData(int w, int h, uint32_t orientation_);

void Touch_Close();
void Touch_Down(float x, float y);
void Touch_Move(float x, float y);
void Touch_Up();
void Touch_Down_N(int finger, float x, float y);
void Touch_Up_N(int finger);
void Touch_Down_B(float x, float y);
void Touch_Move_B(float x, float y);
void Touch_Up_B();
bool Touch_CanInject();
float Touch_DeviceUnitsPerPixel();

void Touch_SetGamePassthrough(bool enabled);
int  Touch_GetPointers(int* out_ids, float* out_x, float* out_y, int max_count);
