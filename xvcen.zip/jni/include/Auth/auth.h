#pragma once

#include <cstdint>
#include <string>
#include <vector>

enum AuthState {
    AUTH_NONE = 0,
    AUTH_CHECKING,
    AUTH_OK,
    AUTH_FAIL,
    AUTH_NET_ERROR
};

void AuthInit();
void AuthCheck(const std::string& key);
AuthState AuthGetState();
std::string AuthGetSavedKey();
std::uint64_t AuthGetPlayerManagerRva();
std::uint64_t AuthGetPlayerManagerRvaBeta();
int AuthGetOnlineCount();
void AuthPresenceStop();
void AuthPresenceSetLocalName(const std::string& name);
std::vector<std::uint64_t> AuthPresenceGetPeerHashes();
std::uint64_t AuthPresenceNameHash(const std::string& name);
std::string AuthGetDeviceId();
std::uint64_t AuthGetTokenExpires();
