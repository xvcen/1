#pragma once

#include <cstdint>

bool IntegrityVerifyInitial();
std::uint64_t IntegrityToken();
bool IntegrityCheckpoint(std::uint64_t domain);
bool IntegrityRevalidate(std::uint64_t domain);
bool IntegrityRevalidateRegion(std::uint32_t region);
