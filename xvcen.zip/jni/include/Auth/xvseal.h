#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

#include <sodium.h>

#define XV_SEAL_MAGIC 0x4c535658u
#define XV_SEAL_VERSION 4u
#define XV_SEAL_SLOT_SIZE 65536u
#define XV_SEAL_REGIONS 4u
#define XV_SEAL_WINDOWS 16u
#define XV_SEAL_WINDOW_BYTES 16384u
#define XV_SEAL_HEADER_BYTES 32u
#define XV_SEAL_REGION_TABLE_OFF 32u
#define XV_SEAL_WINDOW_TABLE_OFF 224u
#define XV_SEAL_DATA_OFF 1536u
#define XV_SEAL_REGION_ENTRY_BYTES 48u
#define XV_SEAL_WINDOW_ENTRY_BYTES 80u
#define XV_SEAL_WINDOW_ITEM_BYTES 32u
#define XV_SEAL_WINDOW_CT_BYTES 48u

#define XV_CTX_MAC "XVMAC%u__"
#define XV_CTX_WINDOW_KEY "XVWINKEY"
#define XV_CTX_REGION "XVREG%u__"
#define XV_CTX_WINDOW_ITEM "XVWSEL__"
#define XV_CTX_MASK "XVMASK__"
#define XV_CTX_STREAM "XVSTREAM"

#if defined(__clang__) || defined(__GNUC__)
#define XV_GUARD(...) __attribute__((noinline, used)) __VA_ARGS__
#define XV_NOINLINE __attribute__((noinline))
#else
#define XV_GUARD(...) __VA_ARGS__
#define XV_NOINLINE
#endif

namespace xv {

enum Region : std::uint32_t {
    kRegionOffsets = 0,
    kRegionStrings = 1,
    kRegionKeys = 2,
    kRegionPolicy = 3
};

bool Init();
bool Ready();
std::uint32_t BuildId();
std::uint64_t Token();

std::uint64_t Offset(std::uint32_t id);
std::uint64_t Policy(std::uint32_t id);
std::size_t OffsetCount();
std::size_t PolicyCount();

std::string Str(std::uint32_t id);
const char* StrC(std::uint32_t id);
const char* StrStable(std::uint32_t id);
std::size_t StrCount();

bool Key(std::uint32_t id, unsigned char* out, std::size_t len);
std::size_t KeyLen(std::uint32_t id);

bool Checkpoint(std::uint64_t domain);
bool Revalidate(std::uint64_t domain);
bool RevalidateRegion(std::uint32_t region);

void Memzero(void* ptr, std::size_t len);
void* Locked(std::size_t len);
void Release(void* ptr);

}
