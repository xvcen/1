#pragma once

#define IMGENIE_VERSION "0.1.0"

#ifndef IMGENIE_API
#define IMGENIE_API
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef int ImGenieSide;
enum ImGenieSide_ {
    ImGenieSide_Auto = 0,
    ImGenieSide_Top,
    ImGenieSide_Bottom,
    ImGenieSide_Left,
    ImGenieSide_Right,
};

typedef struct ImGenie_Rect {
    float minX;
    float minY;
    float maxX;
    float maxY;
} ImGenie_Rect;

typedef struct ImGenieGenieParams {
    int32_t cellsV;
    int32_t cellsH;
    ImGenieSide side;
    ImGenie_Rect destRect;
#ifdef __cplusplus
    ImGenieGenieParams() : cellsV(20), cellsH(1), side(ImGenieSide_Auto), destRect{} {}
#endif
} ImGenieGenieParams;

typedef struct ImGenieSpringParams {
    float stiffness;
    float damping;
    int32_t substeps;
    int32_t cellsH;
    int32_t cellsV;
#ifdef __cplusplus
    ImGenieSpringParams() : stiffness(160.0f), damping(14.0f), substeps(2), cellsH(6), cellsV(6) {}
#endif
} ImGenieSpringParams;

typedef struct ImGenieWobblyParams {
    ImGenieSpringParams spring;
    float maxStiffness;
    float settleDuration;
#ifdef __cplusplus
    ImGenieWobblyParams() : spring(), maxStiffness(220.0f), settleDuration(0.18f) {}
#endif
} ImGenieWobblyParams;

typedef struct ImGenieTransitions {
    float animDuration;
    ImGenieGenieParams genie;
#ifdef __cplusplus
    ImGenieTransitions() : animDuration(0.4f), genie() {}
#endif
} ImGenieTransitions;

typedef struct ImGenieEffects {
    ImGenieWobblyParams wobbly;
#ifdef __cplusplus
    ImGenieEffects() : wobbly() {}
#endif
} ImGenieEffects;

typedef struct ImGenieParams {
    bool drawDebug;
    ImGenieTransitions transitions;
    ImGenieEffects effects;
#ifdef __cplusplus
    ImGenieParams() : drawDebug(false), transitions(), effects() {}
#endif
} ImGenieParams;

#ifdef __cplusplus

#include <functional>
#include <unordered_map>

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#ifdef IMGUI_INCLUDE
#include IMGUI_INCLUDE
#else
#include <imgui_internal.h>
#endif

typedef std::function<ImTextureRef(int32_t aWidth, int32_t aHeight, ImDrawData* apDrawData)> CreateCaptureFunctor;
typedef std::function<void(const ImTextureRef&)> DestroyCaptureFunctor;

struct ImGenieEffect {
    enum class State {
        PendingCapture,
        Captured,
        Animating,
        AppearingCapture,
        AppearingAnimating,
        MovingCapture,
        MovingActive,
        MovingSettle
    };
    State state{State::PendingCapture};
    ImRect sourceRect{};
    ImRect destRect{};
    ImTextureRef capturedTex{};
    ImVec2 capturedSize{};
    float animT{0.0f};

    struct SpringCorner {
        ImVec2 current{};
        ImVec2 velocity{};
    } springs[4]{};
    float springWeights[4]{};
    ImVec2 grabUV{};
    ImVec2 settleStart[4]{};

    ImGenieSide resolvedSide{ImGenieSide_Top};

    ImGenieParams params{};
};

struct ImGenieContext {
    std::unordered_map<ImGuiID, ImGenieEffect> effects{};
    std::unordered_map<ImGuiID, bool> openStates{};
    std::unordered_map<ImGuiID, const char*> effectNames{};
    std::unordered_map<ImGuiID, ImVec2> dragStartPos{};
    CreateCaptureFunctor createCaptureFunc{};
    DestroyCaptureFunctor destroyCaptureFunc{};
    bool captureFlipV{false};
    std::unordered_map<ImGuiID, bool> externalDragStates{};
};

#define IMGENIE_CHECKVERSION() ImGenie::DebugCheckVersion(IMGENIE_VERSION, sizeof(ImGenieParams), sizeof(ImGenieEffect), sizeof(ImGenieContext))

namespace ImGenie {

IMGENIE_API bool DebugCheckVersion(const char* aVersion, size_t aParamsSize, size_t aEffectSize, size_t aContextSize);

IMGENIE_API ImGenieContext* CreateContext();
IMGENIE_API void DestroyContext(ImGenieContext* apCtx = nullptr);
IMGENIE_API ImGenieContext* GetCurrentContext();
IMGENIE_API void SetCurrentContext(ImGenieContext* apCtx);

IMGENIE_API void SetCreateCaptureFunc(const CreateCaptureFunctor& arFunc);
IMGENIE_API void SetDestroyCaptureFunc(const DestroyCaptureFunctor& arFunc);
IMGENIE_API void SetCaptureFlipV(bool aFlipV);

IMGENIE_API void Capture();

IMGENIE_API bool IsEffectActive(const char* aWindowName);

IMGENIE_API void SetExternalDragging(const char* aWindowName, bool aDragging);

IMGENIE_API bool Allow(const char* aWindowName, bool* apoOpen, const ImGenieParams* apParams);

}

#endif
