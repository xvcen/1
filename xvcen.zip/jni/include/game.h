#pragma once
#include <sys/types.h>
#include <string>
#include <vector>

void game_set_beta(bool is_beta);
bool game_driver_attach(int kind);
bool game_driver_mode();

struct EspSkelSeg {
    float x1, y1, x2, y2;
};

struct EspBox {
    float x1, y1, x2, y2;
    float distance;
    float health = -1.0f;
    float max_health = -1.0f;
    bool  teammate = false;
    bool  xvcen_user = false;
    std::string name;
    std::vector<EspSkelSeg> bones;

    std::string weapon_name;
    std::string weapon_name_ru;

    unsigned long long id = 0;
    float cam_yaw_at = 0.f;
    float cam_pitch_at = 0.f;
    bool  aim_valid[3] = {false, false, false};
    float aim_yaw[3] = {0.f, 0.f, 0.f};
    float aim_pitch[3] = {0.f, 0.f, 0.f};
    float aim_pts[3][2] = {{0.f, 0.f}, {0.f, 0.f}, {0.f, 0.f}};
};

struct AimFrame {
    bool  has_target = false;
    float target_x = 0.0f;
    float target_y = 0.0f;
};

struct OffscreenDir {
    uint64_t player = 0;
    float radians  = 0.0f;
    float distance = 0.0f;
    bool  teammate = false;
    float health_fraction = -1.0f;
};

enum class OreKind : int {
    Stone = 0,
    Iron = 1,
    Sulfur = 2,
    Tree = 3
};

enum class WorldKind : int {
    Bear = 0, Boar, Deer, Rabbit, Chicken, Cannibal, Hare,
    Lootbox, Bot, Wolf, EliteBox, MilitaryBox, ToolBox,
    Fish, Cupboard, Turret
};

struct WorldEspPoint {
    float x = 0.0f;
    float y = 0.0f;
    float distance = 0.0f;
    WorldKind kind = WorldKind::Lootbox;
    float health = -1.0f;
    float max_health = -1.0f;
    std::string name;

    float height = 0.0f;

    float top_offset = 0.0f;
};

const char* world_kind_label(WorldKind kind);
bool        world_kind_is_animal(WorldKind kind);

struct OreEspPoint {
    float x = 0.0f;
    float y = 0.0f;
    float distance = 0.0f;
    OreKind kind = OreKind::Stone;
};

struct OreTargetPoint {
    float x = 0.0f, y = 0.0f, z = 0.0f;
    float distance = 0.0f;
    float hdist = 0.0f;
    OreKind kind = OreKind::Stone;
    uint64_t key = 0;
    float rel_yaw = 0.0f;
    float look_x = 0.0f, look_y = 0.0f;
    bool look_valid = false;
    float fraction = 1.0f;
    bool has_marker = false;
    bool trunk_aim = false;
};

bool        esp_init(pid_t pid);
bool        esp_local_is_dead(bool* out_valid);
void        esp_set_tree_scan(bool enabled);
void        farm_set_tree_marker_pin(bool enabled);
void        esp_request_fast_scan();
void        esp_reset();
void        esp_begin_overlay_frame(int screen_width, int screen_height);
void        memory_no_recoil_update(bool enabled);
void        memory_no_spread_update(bool enabled);
void        memory_hands_fov_update(bool enabled, float fov);
void        memory_black_sky_update(bool enabled);
void        memory_always_day_update(bool enabled);
void        memory_crosshair_update(bool enabled);
void        memory_freecam_update(bool enabled, float* position, float* yaw,
                                 float* pitch);
void        memory_xray_update(bool enabled, float distance);
void        memory_aspect_update(bool enabled, float ratio);
std::vector<EspBox> esp_get_boxes(int screen_width, int screen_height,
                                  bool include_names, bool include_health,
                                  int* nearby_enemy_count = nullptr,
                                  bool include_skeleton = false,
                                  bool ignore_teammates = false,
                                  int* nearby_teammate_count = nullptr,
                                  int* nearby_bot_count = nullptr,
                                  bool include_weapons = true);
std::vector<OreEspPoint> esp_get_ores(int screen_width, int screen_height,
                                     bool sulfur, bool iron, bool stone,
                                     bool tree);
float       esp_max_distance();
std::vector<OreTargetPoint> esp_get_ore_targets(int screen_width,
                                                int screen_height,
                                                float max_distance,
                                                bool sulfur, bool iron,
                                                bool stone, bool tree);
std::vector<WorldEspPoint> esp_get_world(int screen_width, int screen_height,
                                         bool animals, bool crates,
                                         bool humanoids);
AimFrame aim_update(int screen_width, int screen_height,
                    bool enabled, int bone,
                    bool allow_ads, bool allow_hipfire,
                    float fov_radius,
                    bool ignore_teammates = false,
                    bool memory_mode = false,
                    float smooth = 5.0f,
                    bool allow_bots = true);
int   esp_get_bot_aims(float sw, float sh, unsigned long long* ids,
                       float* sx, float* sy, float* dist, int maxn);
bool  esp_camera_angles(float& yaw, float& pitch);
float esp_camera_fov_deg();
bool  esp_local_player_is_aiming();
std::vector<OffscreenDir> esp_get_offscreen_dirs(int screen_width,
                                                 int screen_height,
                                                 bool ignore_teammates);
