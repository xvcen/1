#pragma once

#include "xvseal.h"
#include "xvstrings.h"

#include "imgui.h"
#include <string>
#include <cstdio>
#include <cstring>

namespace Keyboard {

struct State { bool shift = true; bool sym = false; };
inline State g_kb;

inline float Height(float W) {
    const float kh = W * 0.085f;
    const float vg = kh * 0.16f;
    return 4.f * kh + 3.f * vg;
}

inline void Render(ImDrawList* dl, ImFont* fn, float fs,
                   float x, float y, float W,
                   std::string& text, bool& keyTap, bool& enterTap) {
    const float gap = 7.f;
    const float kh  = W * 0.085f;
    const float vg  = kh * 0.16f;
    const float kfs = fs * 0.82f;

    ImU32 fill  = C::U(C::Card());
    ImU32 tcol  = C::U(C::Txt());
    ImU32 acc   = C::U(C::Acc());
    ImU32 white = IM_COL32(255,255,255,255);
    ImU32 red   = C::U(C::Red());

    int uid = 0;

    auto key = [&](float kx, float ky, float kw, float khh, const char* label,
                   ImU32 bg, ImU32 fg, float lscale, const char* id) -> bool {
        ImVec2 p0={kx,ky}, p1={kx+kw,ky+khh};
        bool held = ImGui::GetIO().MouseDown[0] &&
                    ImGui::GetIO().MousePos.x>=p0.x && ImGui::GetIO().MousePos.x<=p1.x &&
                    ImGui::GetIO().MousePos.y>=p0.y && ImGui::GetIO().MousePos.y<=p1.y;
        float rr = khh*0.30f;
        dl->AddRectFilled({p0.x,p0.y+2.f},{p1.x,p1.y+2.f}, IM_COL32(0,0,0,28), rr);
        dl->AddRectFilled(p0,p1,bg,rr);
        if (held) dl->AddRectFilled(p0,p1, IM_COL32(255,255,255,34), rr);
        float lfs = kfs*lscale;
        if (label && label[0]) {
            ImVec2 ts = fn->CalcTextSizeA(lfs, FLT_MAX, 0.f, label);
            dl->AddText(fn,lfs,{(p0.x+p1.x-ts.x)*0.5f,(p0.y+p1.y-ts.y)*0.5f-1.f},fg,label);
        }
        ImGui::SetCursorScreenPos(p0);
        ImGui::InvisibleButton(id,{kw,khh});
        bool released = ImGui::GetIO().MouseReleased[0];
        if (!released) return false;
        ImVec2 cp = ImGui::GetIO().MouseClickedPos[0];
        ImVec2 mp = ImGui::GetIO().MousePos;
        bool s = cp.x>=p0.x && cp.x<=p1.x && cp.y>=p0.y && cp.y<=p1.y;
        bool e = mp.x>=p0.x-10 && mp.x<=p1.x+10 && mp.y>=p0.y-10 && mp.y<=p1.y+10;
        float dx=mp.x-cp.x, dy=mp.y-cp.y;
        return s && e && (dx*dx+dy*dy) <= 34.f*34.f;
    };

    auto typeCh = [&](char c){ if (text.size()<63) text.push_back(c); };

    auto drawArrow = [&](float ccx, float ccy, ImU32 col){
        float iw=kh*0.19f, ih=kh*0.21f, th=3.6f;
        dl->AddLine({ccx-iw, ccy+ih*0.45f},{ccx, ccy-ih*0.85f},col,th);
        dl->AddLine({ccx, ccy-ih*0.85f},{ccx+iw, ccy+ih*0.45f},col,th);
        dl->AddLine({ccx-iw*0.9f, ccy+ih},{ccx+iw*0.9f, ccy+ih},col,th);
    };
    auto drawBack = [&](float ccx, float ccy, ImU32 col){
        float w=kh*0.27f, h=kh*0.20f, th=3.4f;
        ImVec2 pts[5] = {
            {ccx - w,         ccy},
            {ccx - w*0.32f,   ccy - h},
            {ccx + w*0.95f,   ccy - h},
            {ccx + w*0.95f,   ccy + h},
            {ccx - w*0.32f,   ccy + h}
        };
        dl->AddPolyline(pts, 5, col, ImDrawFlags_Closed, th);
        float xc=ccx + w*0.30f;
        dl->AddLine({xc-w*0.26f, ccy-h*0.42f},{xc+w*0.26f, ccy+h*0.42f},col,th);
        dl->AddLine({xc+w*0.26f, ccy-h*0.42f},{xc-w*0.26f, ccy+h*0.42f},col,th);
    };
    auto drawCheck = [&](float ccx, float ccy, ImU32 col){
        float s=kh*0.27f;
        dl->AddLine({ccx-s*0.85f,ccy+s*0.05f},{ccx-s*0.15f,ccy+s*0.7f},col,3.8f);
        dl->AddLine({ccx-s*0.15f,ccy+s*0.7f},{ccx+s*0.9f,ccy-s*0.65f},col,3.8f);
    };
    auto drawSpace = [&](float ccx, float ccy, float bw){
        dl->AddLine({ccx-bw,ccy},{ccx+bw,ccy},C::UA(C::Dim(),0.55f),4.f);
    };

    auto row10 = [&](float ky, const char* chs, bool letters) {
        float kw = (W - gap*9)/10.f;
        float kx = x;
        for (int i=0;i<10;i++){
            char lb[2] = { (char)(letters && g_kb.shift ? chs[i]-32 : chs[i]), 0 };
            char id[24]; snprintf(id,24,xv::StrStable(xv::sid::kKbKcD),uid++);
            if (key(kx,ky,kw,kh,lb,fill,tcol,1.f,id)){
                typeCh(lb[0]);
                if (letters) g_kb.shift=false;
                keyTap=true;
            }
            kx += kw+gap;
        }
    };

    float cy = y;
    float u = (W - gap*9)/10.f;
    float side  = u*1.5f;
    float enterW = u*1.75f;

    if (!g_kb.sym) {
        row10(cy, xv::StrStable(xv::sid::kKbQwertyuiop), true); cy += kh+vg;
        {
            const char* chs=xv::StrStable(xv::sid::kKbAsdfghjkl); int n=9;
            float inset=W*0.05f, rw=W-inset*2.f;
            float kw=(rw-gap*(n-1))/n, kx=x+inset;
            for (int i=0;i<n;i++){
                char lb[2]={ (char)(g_kb.shift? chs[i]-32:chs[i]),0};
                char id[24]; snprintf(id,24,xv::StrStable(xv::sid::kKbKaD),uid++);
                if (key(kx,cy,kw,kh,lb,fill,tcol,1.f,id)){ typeCh(lb[0]); g_kb.shift=false; keyTap=true; }
                kx+=kw+gap;
            }
        }
        cy += kh+vg;

        {
            float kx = x;
            ImU32 shBg = g_kb.shift ? acc : C::Mix(C::Card(),C::Acc(),0.12f);
            ImU32 shFg = g_kb.shift ? white : tcol;
            if (key(kx,cy,side,kh,"",shBg,shFg,1.f,xv::StrStable(xv::sid::kKbKshift))){ g_kb.shift=!g_kb.shift; keyTap=true; }
            drawArrow(kx+side*0.5f, cy+kh*0.5f, shFg);
            kx += side+gap;

            const char* chs=xv::StrStable(xv::sid::kKbZxcvbnm); int n=7;
            float lkw = (W - 2.f*side - 8.f*gap)/n;
            for (int i=0;i<n;i++){
                char lb[2]={ (char)(g_kb.shift? chs[i]-32:chs[i]),0};
                char id[24]; snprintf(id,24,xv::StrStable(xv::sid::kKbKzD),uid++);
                if (key(kx,cy,lkw,kh,lb,fill,tcol,1.f,id)){ typeCh(lb[0]); g_kb.shift=false; keyTap=true; }
                kx+=lkw+gap;
            }

            float bkx = x+W-side;
            if (key(bkx,cy,side,kh,"",fill,red,1.f,xv::StrStable(xv::sid::kKbKback))){ if(!text.empty()) text.pop_back(); keyTap=true; }
            drawBack(bkx+side*0.5f, cy+kh*0.5f, red);
        }
        cy += kh+vg;

        {
            float kx = x;
            if (key(kx,cy,side,kh,xv::StrStable(xv::sid::kKb123),acc,white,0.92f,xv::StrStable(xv::sid::kKbKsym))){ g_kb.sym=true; keyTap=true; }
            kx += side+gap;
            float spaceW = W - side - enterW - 2.f*gap;
            if (key(kx,cy,spaceW,kh,"",fill,tcol,1.f,xv::StrStable(xv::sid::kKbKspace))){ typeCh(' '); keyTap=true; }
            drawSpace(kx+spaceW*0.5f, cy+kh*0.5f, spaceW*0.22f);
            kx += spaceW+gap;

            bool canEnter = !text.empty();
            ImU32 eBg = canEnter ? acc : C::UA(C::Card(),0.7f);
            ImU32 eFg = canEnter ? white : C::UA(C::Dim(),0.7f);
            if (key(kx,cy,enterW,kh,"",eBg,eFg,1.f,xv::StrStable(xv::sid::kKbKenter))){ if(canEnter) enterTap=true; }
            drawCheck(kx+enterW*0.5f, cy+kh*0.5f, eFg);
        }
    } else {
        row10(cy, xv::StrStable(xv::sid::kKb1234567890), false); cy += kh+vg;
        row10(cy, xv::StrStable(xv::sid::kKbX), false); cy += kh+vg;

        {
            float kx = x;
            const char* chs=xv::StrStable(xv::sid::kKbX_2); int n=8;
            for (int i=0;i<n;i++){
                char lb[2]={chs[i],0};
                char id[24]; snprintf(id,24,xv::StrStable(xv::sid::kKbKsD),uid++);
                if (key(kx,cy,u,kh,lb,fill,tcol,1.f,id)){ typeCh(lb[0]); keyTap=true; }
                kx += u+gap;
            }
            float bkx = x+W-side;
            if (key(bkx,cy,side,kh,"",fill,red,1.f,xv::StrStable(xv::sid::kKbKback2))){ if(!text.empty()) text.pop_back(); keyTap=true; }
            drawBack(bkx+side*0.5f, cy+kh*0.5f, red);
        }
        cy += kh+vg;

        {
            float kx = x;
            if (key(kx,cy,side,kh,xv::StrStable(xv::sid::kKbABC),acc,white,0.92f,xv::StrStable(xv::sid::kKbKabc))){ g_kb.sym=false; keyTap=true; }
            kx += side+gap;
            float spaceW = W - side - enterW - 2.f*gap;
            if (key(kx,cy,spaceW,kh,"",fill,tcol,1.f,xv::StrStable(xv::sid::kKbKspace2))){ typeCh(' '); keyTap=true; }
            drawSpace(kx+spaceW*0.5f, cy+kh*0.5f, spaceW*0.22f);
            kx += spaceW+gap;

            bool canEnter = !text.empty();
            ImU32 eBg = canEnter ? acc : C::UA(C::Card(),0.7f);
            ImU32 eFg = canEnter ? white : C::UA(C::Dim(),0.7f);
            if (key(kx,cy,enterW,kh,"",eBg,eFg,1.f,xv::StrStable(xv::sid::kKbKenter2))){ if(canEnter) enterTap=true; }
            drawCheck(kx+enterW*0.5f, cy+kh*0.5f, eFg);
        }
    }
}

}
