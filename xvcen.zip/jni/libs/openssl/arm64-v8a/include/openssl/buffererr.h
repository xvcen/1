









#ifndef OPENSSL_BUFFERERR_H
# define OPENSSL_BUFFERERR_H
# pragma once

# include <openssl/opensslconf.h>
# include <openssl/symhacks.h>
# include <openssl/cryptoerr_legacy.h>







#endif
