










#ifndef OPENSSL_CMP_UTIL_H
# define OPENSSL_CMP_UTIL_H
# pragma once

# include <openssl/opensslconf.h>
# ifndef OPENSSL_NO_CMP

#  include <openssl/macros.h>
#  include <openssl/trace.h>

#  ifdef __cplusplus
extern "C" {
#  endif

int  OSSL_CMP_log_open(void);
void OSSL_CMP_log_close(void);
#  define OSSL_CMP_LOG_PREFIX "CMP "




typedef int OSSL_CMP_severity;
#  define OSSL_CMP_LOG_EMERG   0
#  define OSSL_CMP_LOG_ALERT   1
#  define OSSL_CMP_LOG_CRIT    2
#  define OSSL_CMP_LOG_ERR     3
#  define OSSL_CMP_LOG_WARNING 4
#  define OSSL_CMP_LOG_NOTICE  5
#  define OSSL_CMP_LOG_INFO    6
#  define OSSL_CMP_LOG_DEBUG   7
#  define OSSL_CMP_LOG_TRACE   8
#  define OSSL_CMP_LOG_MAX     OSSL_CMP_LOG_TRACE
typedef int (*OSSL_CMP_log_cb_t)(const char *func, const char *file, int line,
                                 OSSL_CMP_severity level, const char *msg);

int OSSL_CMP_print_to_bio(BIO *bio, const char *component, const char *file,
                          int line, OSSL_CMP_severity level, const char *msg);

void OSSL_CMP_print_errors_cb(OSSL_CMP_log_cb_t log_fn);

#  ifdef  __cplusplus
}
#  endif
# endif 
#endif 
