









#ifndef OPENSSL_DECODERERR_H
# define OPENSSL_DECODERERR_H
# pragma once

# include <openssl/opensslconf.h>
# include <openssl/symhacks.h>
# include <openssl/cryptoerr_legacy.h>






# define OSSL_DECODER_R_COULD_NOT_DECODE_OBJECT           101
# define OSSL_DECODER_R_DECODER_NOT_FOUND                 102
# define OSSL_DECODER_R_MISSING_GET_PARAMS                100

#endif
