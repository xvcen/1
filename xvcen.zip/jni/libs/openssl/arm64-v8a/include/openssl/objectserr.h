









#ifndef OPENSSL_OBJECTSERR_H
# define OPENSSL_OBJECTSERR_H
# pragma once

# include <openssl/opensslconf.h>
# include <openssl/symhacks.h>
# include <openssl/cryptoerr_legacy.h>






# define OBJ_R_OID_EXISTS                                 102
# define OBJ_R_UNKNOWN_NID                                101
# define OBJ_R_UNKNOWN_OBJECT_NAME                        103

#endif
