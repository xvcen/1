








#ifndef OPENSSL_OPENSSLCONF_H
# define OPENSSL_OPENSSLCONF_H
# pragma once

# include <openssl/configuration.h>
# include <openssl/macros.h>

#endif  
