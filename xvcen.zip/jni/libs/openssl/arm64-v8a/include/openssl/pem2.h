








#ifndef OPENSSL_PEM2_H
# define OPENSSL_PEM2_H
# pragma once

# include <openssl/macros.h>
# ifndef OPENSSL_NO_DEPRECATED_3_0
#  define HEADER_PEM2_H
# endif
# include <openssl/pemerr.h>
#endif
