#include "Android_draw/draw.h"
#include "ImGui/Font/Font.h"
#include "animations.h"

#include <time.h>
#include <vector>
#include <unordered_map>

EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig  config;
EGLSurface surface = EGL_NO_SURFACE;
EGLContext context = EGL_NO_CONTEXT;

ANativeWindow *native_window;

ImTextureRef GlGenie_CreateCapture(int32_t width, int32_t height, ImDrawData* draw_data);
void GlGenie_DestroyCapture(const ImTextureRef& tex);

struct GlTexture {
    GLuint id = 0;
    int width = 0;
    int height = 0;
};

static std::unordered_map<ImTextureID, GlTexture> g_textures;

static double g_prev_swap = 0.0;
static float  g_overlay_fps = 60.f;

int native_window_screen_x = 0;
int native_window_screen_y = 0;
anwc::ANativeWindowCreator::DisplayInfo displayInfo{0};
uint32_t orientation  = 0;
bool     g_Initialized = false;
ImGuiWindow *g_window  = nullptr;

bool initGUI_draw(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    orientation = displayInfo.orientation;
    if (!init_egl(_screen_x, _screen_y, log)) return false;
    if (!ImGui_init()) return false;
    return true;
}

bool init_egl(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    static const char wn[] = {0x53,0x75,0x72,0x66,0x61,0x63,0x65,0x00};
    ::native_window = anwc::ANativeWindowCreator::Create(wn, _screen_x, _screen_y, false);
    ANativeWindow_acquire(native_window);

    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) return false;
    if (eglInitialize(display, 0, 0) != EGL_TRUE) return false;

    EGLint num_config = 0;
    const EGLint attribList[] = {
        EGL_SURFACE_TYPE,      EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE,   EGL_OPENGL_ES2_BIT,
        EGL_BLUE_SIZE,  5,
        EGL_GREEN_SIZE, 6,
        EGL_RED_SIZE,   5,
        EGL_BUFFER_SIZE, 32,
        EGL_DEPTH_SIZE,  16,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    const EGLint attrib_list[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };

    if (eglChooseConfig(display, attribList, &config, 1, &num_config) != EGL_TRUE) return false;

    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);

    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) return false;

    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) return false;

    if (!eglMakeCurrent(display, surface, surface, context)) return false;

    eglSwapInterval(display, 1);

    return true;
}

void screen_config() {
    displayInfo = anwc::ANativeWindowCreator::GetDisplayInfo();
}

bool ImGui_init() {
    if (g_Initialized) return true;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();

    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;
    io.DisplaySize = ImVec2((float)native_window_screen_x, (float)native_window_screen_y);

    io.Fonts->AddFontFromMemoryTTF(
        (void*)RobotoFont,
        (int)RobotoFont_size,
        28.0f
    );

    ImGui::GetStyle().ScaleAllSizes(1.5f);
    ImGui::GetStyle().WindowRounding = 14.0f;

    if (ImGenie::GetCurrentContext() != nullptr) {
        ImGenie::SetCreateCaptureFunc(
            [](int32_t aWidth, int32_t aHeight, ImDrawData* apDrawData) {
                return GlGenie_CreateCapture(aWidth, aHeight, apDrawData);
            });
        ImGenie::SetDestroyCaptureFunc([](const ImTextureRef& aTex) {
            GlGenie_DestroyCapture(aTex);
        });
        ImGenie::SetCaptureFlipV(true);
    }

    g_Initialized = true;
    return true;
}

void drawBegin() {
    screen_config();

    if (::orientation != displayInfo.orientation) {
        ::orientation = displayInfo.orientation;
        UpdateScreenData(displayInfo.width, displayInfo.height, displayInfo.orientation);
    }

    ImGui::GetIO().DisplaySize = ImVec2((float)native_window_screen_x, (float)native_window_screen_y);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
}

ImTextureRef GlGenie_CreateCapture(int32_t width, int32_t height,
                                   ImDrawData* draw_data) {
    if (width <= 0 || height <= 0 || !draw_data) return ImTextureRef();

    GLint prev_fbo = 0;
    GLint prev_viewport[4]{};
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prev_fbo);
    glGetIntegerv(GL_VIEWPORT, prev_viewport);

    GLuint tex = 0;
    glGenTextures(1, &tex);
    if (!tex) return ImTextureRef();
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, nullptr);

    GLuint fbo = 0;
    glGenFramebuffers(1, &fbo);
    if (!fbo) {
        glDeleteTextures(1, &tex);
        return ImTextureRef();
    }
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                           GL_TEXTURE_2D, tex, 0);

    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)prev_fbo);
        glDeleteFramebuffers(1, &fbo);
        glDeleteTextures(1, &tex);
        return ImTextureRef();
    }

    glViewport(0, 0, width, height);
    glClearColor(0.f, 0.f, 0.f, 0.f);
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    ImGui_ImplOpenGL3_RenderDrawData(draw_data);

    glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)prev_fbo);
    glViewport(prev_viewport[0], prev_viewport[1],
               prev_viewport[2], prev_viewport[3]);
    glDeleteFramebuffers(1, &fbo);

    ImTextureID handle = (ImTextureID)(intptr_t)tex;
    GlTexture entry;
    entry.id = tex;
    entry.width = width;
    entry.height = height;
    g_textures[handle] = entry;
    return ImTextureRef(handle);
}

void GlGenie_DestroyCapture(const ImTextureRef& tex) {
    VkTex_Remove(tex.GetTexID());
}

void drawEnd() {
    ImGui::Render();

    if (ImGenie::GetCurrentContext() != nullptr)
        ImGenie::Capture();

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.f, 0.f, 0.f, 0.f);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);

    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    double now = (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
    if (g_prev_swap > 0.0) {
        float d = (float)(now - g_prev_swap);
        if (d > 0.0002f && d < 0.25f)
            g_overlay_fps += (1.f / d - g_overlay_fps) * 0.12f;
    }
    g_prev_swap = now;
}

float overlay_fps() {
    return g_overlay_fps;
}

ImTextureID VkTex_UploadRGBA(const void* rgba_pixels, int width, int height) {
    if (!rgba_pixels || width <= 0 || height <= 0) return (ImTextureID)0;

    GLuint tex = 0;
    glGenTextures(1, &tex);
    if (!tex) return (ImTextureID)0;

    GLint previous = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, rgba_pixels);
    glBindTexture(GL_TEXTURE_2D, (GLuint)previous);

    ImTextureID handle = (ImTextureID)(intptr_t)tex;
    GlTexture entry;
    entry.id = tex;
    entry.width = width;
    entry.height = height;
    g_textures[handle] = entry;
    return handle;
}

void VkTex_Remove(ImTextureID tex) {
    if (!tex) return;
    auto it = g_textures.find(tex);
    if (it == g_textures.end()) return;
    GLuint id = it->second.id;
    if (id) glDeleteTextures(1, &id);
    g_textures.erase(it);
}


void shutdown() {
    if (!g_Initialized) return;

    if (ImGenie::GetCurrentContext() != nullptr) ImGenie::DestroyContext();

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();

    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;

    ANativeWindow_release(native_window);
    anwc::ANativeWindowCreator::Destroy(native_window);
    g_Initialized = false;
}