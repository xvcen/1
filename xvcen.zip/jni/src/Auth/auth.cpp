#include "auth.h"
#include "cacert_bundle.h"
#include "integrity.h"
#include "statefile.h"
#include "xvkeys.h"
#include "xvpolicy.h"
#include "xvseal.h"
#include "xvstrings.h"

#include <sodium.h>
#include <curl/curl.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <poll.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

namespace {

constexpr std::uint64_t DomainGrant     = 0xc13a5e709b2486dfULL;
constexpr std::uint64_t DomainChallenge = 0x8f31c6a279d4e50bULL;
constexpr std::uint64_t DomainSign      = 0x42e7b19d35c86af3ULL;
constexpr std::uint64_t DomainFinish    = 0xb6c409f27a1d538eULL;
constexpr std::uint64_t DomainDecrypt   = 0x71ad3e58c294f60bULL;
constexpr std::uint64_t DomainSession   = 0x7b2e94d16f30ac85ULL;
constexpr std::uint64_t DomainRva       = 0x4ea197c82d5b603fULL;
constexpr std::uint64_t DomainDevice    = 0x91d3c74a0b8e52f6ULL;
constexpr std::uint64_t DomainLicense   = 0x2e8b57a1c9d04f63ULL;
constexpr std::uint64_t DomainPresence  = 0x5a2f9c18d74b0e63ULL;
constexpr std::uint64_t DomainFrame     = 0x37c0be49a2d61f85ULL;
constexpr std::uint64_t DomainName      = 0x6c0f3a9d51e8b724ULL;

constexpr std::uint32_t DeviceFileMagic = 0x31445658u;
constexpr std::uint32_t TokenFileMagic = 0x314b5458u;
constexpr std::size_t TokenBodyBytes = 64;
constexpr std::size_t TokenBytes = TokenBodyBytes + crypto_auth_BYTES;

std::string SV(std::uint32_t id) { return xv::Str(id); }
const char* SC(std::uint32_t id) { return xv::StrC(id); }
std::uint64_t PV(std::uint32_t id) { return xv::Policy(id); }

void CleanseString(std::string& value) {
    if (!value.empty()) sodium_memzero(&value[0], value.size());
    value.clear();
}

void CleanseVector(std::vector<unsigned char>& value) {
    if (!value.empty()) sodium_memzero(value.data(), value.size());
    value.clear();
}

class SensitiveCleanup {
public:
    void Add(std::string& value) { strings_.push_back(&value); }
    void Add(std::vector<unsigned char>& value) { buffers_.push_back(&value); }
    ~SensitiveCleanup() {
        for (std::string* item : strings_) CleanseString(*item);
        for (std::vector<unsigned char>* item : buffers_) CleanseVector(*item);
    }

private:
    std::vector<std::string*> strings_;
    std::vector<std::vector<unsigned char>*> buffers_;
};

struct DeviceKeys {
    std::vector<unsigned char> pk;
    std::vector<unsigned char> sk;

    DeviceKeys() = default;
    DeviceKeys(DeviceKeys&&) = default;
    DeviceKeys& operator=(DeviceKeys&&) = default;
    DeviceKeys(const DeviceKeys&) = delete;
    DeviceKeys& operator=(const DeviceKeys&) = delete;
    ~DeviceKeys() { Wipe(); }

    void Wipe() {
        CleanseVector(sk);
        CleanseVector(pk);
    }
    DeviceKeys Clone() const {
        DeviceKeys out;
        out.pk = pk;
        out.sk = sk;
        return out;
    }
};

std::mutex g_mtx;
std::atomic<AuthState> g_state{AUTH_NONE};
std::atomic<std::uint64_t> g_attempt{0};
std::string g_savedKey;
std::string g_deviceId;
std::atomic<std::uint64_t> g_tokenExpires{0};

std::mutex g_sessionMutex;
std::atomic<std::uint64_t> g_rvaEncoded{0};
std::atomic<std::uint64_t> g_rvaMask{0};
std::atomic<std::uint64_t> g_sessionEncoded{0};
std::atomic<std::uint64_t> g_sessionCheck{0};
std::atomic<std::uint64_t> g_remaskCounter{0};
std::atomic<std::uint64_t> g_rvaBetaEncoded{0};
std::atomic<std::uint64_t> g_rvaBetaMask{0};
std::atomic<std::uint64_t> g_rvaBetaSessionEncoded{0};
std::atomic<std::uint64_t> g_rvaBetaSessionCheck{0};
std::atomic<std::uint64_t> g_rvaBetaRemaskCounter{0};

std::atomic<int> g_onlineCount{0};
std::atomic<bool> g_presenceStop{false};
std::atomic<bool> g_presenceRunning{false};
std::mutex g_presenceMutex;
std::vector<std::uint64_t> g_presencePeerHashes;
std::string g_presenceLocalName;
std::string g_presenceLocalHash;

std::uint64_t Now() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(
                                          std::chrono::system_clock::now().time_since_epoch())
                                          .count());
}

void Store64(unsigned char* out, std::uint64_t value) {
    for (int i = 0; i < 8; ++i) out[i] = static_cast<unsigned char>((value >> (8 * i)) & 0xFF);
}

std::uint64_t Load64(const unsigned char* in) {
    std::uint64_t value = 0;
    for (int i = 0; i < 8; ++i) value |= static_cast<std::uint64_t>(in[i]) << (8 * i);
    return value;
}

void Store32Be(unsigned char* out, std::uint32_t value) {
    for (int i = 0; i < 4; ++i)
        out[i] = static_cast<unsigned char>((value >> (8 * (3 - i))) & 0xFF);
}

std::uint32_t Load32(const unsigned char* in) {
    std::uint32_t value = 0;
    for (int i = 0; i < 4; ++i) value |= static_cast<std::uint32_t>(in[i]) << (8 * i);
    return value;
}

int HexValue(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

std::string BytesToHex(const unsigned char* data, std::size_t size) {
    const char* digits = xv::StrStable(xv::sid::kAu0123456789abcdef);
    std::string out;
    out.resize(size * 2);
    for (std::size_t i = 0; i < size; ++i) {
        out[2 * i] = digits[(data[i] >> 4) & 0xF];
        out[2 * i + 1] = digits[data[i] & 0xF];
    }
    return out;
}

bool HexToBytes(const std::string& hex, std::vector<unsigned char>& out) {
    if (hex.size() % 2 != 0) return false;
    out.clear();
    out.reserve(hex.size() / 2);
    for (std::size_t i = 0; i < hex.size(); i += 2) {
        int hi = HexValue(hex[i]);
        int lo = HexValue(hex[i + 1]);
        if (hi < 0 || lo < 0) return false;
        out.push_back(static_cast<unsigned char>((hi << 4) | lo));
    }
    return true;
}

std::uint64_t HexToU64(const std::string& value) {
    if (value.size() != 16) return 0;
    std::uint64_t out = 0;
    for (char c : value) {
        int digit = HexValue(c);
        if (digit < 0) return 0;
        out = (out << 4) | static_cast<std::uint64_t>(digit);
    }
    return out;
}

bool IsHex(const std::string& value, std::size_t expected) {
    if (expected != 0 && value.size() != expected) return false;
    for (char c : value) {
        if (HexValue(c) < 0) return false;
    }
    return true;
}

std::string RandomHex(std::size_t bytes) {
    std::vector<unsigned char> raw(bytes);
    randombytes_buf(raw.data(), raw.size());
    std::string out = BytesToHex(raw.data(), raw.size());
    sodium_memzero(raw.data(), raw.size());
    return out;
}

std::string LowerCopy(const std::string& value) {
    std::string out = value;
    for (char& c : out) {
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c + 32);
    }
    return out;
}

void TrimWs(std::string& value) {
    std::size_t begin = 0;
    std::size_t end = value.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(value[begin]))) ++begin;
    while (end > begin && std::isspace(static_cast<unsigned char>(value[end - 1]))) --end;
    if (begin != 0 || end != value.size()) value = value.substr(begin, end - begin);
}

std::string DomainContext(std::uint32_t stringId) {
    std::string value = SV(stringId);
    std::string out(8, '\0');
    for (std::size_t i = 0; i < 8; ++i) {
        std::size_t index = i + 8;
        out[i] = index < value.size() ? value[index] : '\0';
    }
    CleanseString(value);
    return out;
}

bool DomainKey(std::uint32_t keyId, unsigned char* out) {
    return xv::Key(keyId, out, 32);
}

bool IntegrityMixKey(unsigned char* out32, std::uint32_t keyId, std::uint64_t domain) {
    unsigned char domainKey[32];
    if (!DomainKey(keyId, domainKey)) return false;
    unsigned char seed[16];
    Store64(seed, IntegrityToken());
    Store64(seed + 8, domain);
    int rc = crypto_generichash(out32, 32, seed, sizeof(seed), domainKey, sizeof(domainKey));
    sodium_memzero(domainKey, sizeof(domainKey));
    sodium_memzero(seed, sizeof(seed));
    return rc == 0;
}

std::size_t WriteCallback(char* ptr, std::size_t size, std::size_t nmemb, void* userdata) {
    std::string* out = static_cast<std::string*>(userdata);
    std::size_t len = size * nmemb;
    if (out->size() + len > static_cast<std::size_t>(PV(xv::pid::kHttpResponseMax)) * 8) return 0;
    out->append(ptr, len);
    return len;
}

std::string SyncHeader() {
    return SV(xv::sid::kHeaderSync) + SV(xv::sid::kHeaderSyncSep) + SV(xv::sid::kSyncValue);
}

bool Post(const std::string& path, const std::string& body, std::string& response, long& status) {
    response.clear();
    std::string url = SV(xv::sid::kUrlBase) + path;
    if (url.size() <= SV(xv::sid::kUrlBase).size()) return false;

    CURL* curl = curl_easy_init();
    if (!curl) return false;

    struct curl_slist* headers = nullptr;
    std::string contentType = SV(xv::sid::kHeaderContentType);
    std::string sync = SyncHeader();
    headers = curl_slist_append(headers, contentType.c_str());
    headers = curl_slist_append(headers, sync.c_str());

    struct curl_blob caBlob;
    caBlob.data = const_cast<char*>(kCaBundlePem);
    caBlob.len = std::strlen(kCaBundlePem);
    caBlob.flags = CURL_BLOB_COPY;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, static_cast<long>(PV(xv::pid::kHttpTimeoutSeconds)));
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT,
                     static_cast<long>(PV(xv::pid::kHttpConnectTimeoutSeconds)));
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 0L);
    curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, static_cast<long>(CURL_HTTP_VERSION_1_1));
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    curl_easy_setopt(curl, CURLOPT_CAINFO_BLOB, &caBlob);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, SC(xv::sid::kUserAgent));

    CURLcode rc = curl_easy_perform(curl);
    if (rc == CURLE_OK) curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    CleanseString(url);
    CleanseString(contentType);
    CleanseString(sync);
    return rc == CURLE_OK;
}

bool ReadWholeFile(const std::string& path, std::vector<unsigned char>& out) {
    std::FILE* file = std::fopen(path.c_str(), SC(xv::sid::kModeRead));
    if (!file) return false;
    out.clear();
    unsigned char buffer[512];
    std::size_t read = 0;
    while ((read = std::fread(buffer, 1, sizeof(buffer), file)) > 0 && out.size() < (1u << 20)) {
        out.insert(out.end(), buffer, buffer + read);
    }
    std::fclose(file);
    sodium_memzero(buffer, sizeof(buffer));
    return !out.empty();
}

void ForgetFiles() {
    xvstate::EraseAuth();
}

void MigrateLegacyLastConfig() {
    std::vector<unsigned char> current;
    if (xvstate::Read(xvstate::kLastCfg, current)) {
        CleanseVector(current);
        return;
    }
    std::vector<unsigned char> blob;
    if (!ReadWholeFile(SV(xv::sid::kCfgLast), blob) || blob.empty()) {
        CleanseVector(blob);
        return;
    }
    xvstate::Write(xvstate::kLastCfg, blob.data(), blob.size());
    CleanseVector(blob);
    std::remove(SV(xv::sid::kCfgLast).c_str());
}

void PurgeLegacyFiles() {
    std::remove(SV(xv::sid::kFileSession).c_str());
    std::remove(SV(xv::sid::kFileDevice).c_str());
    std::remove(SV(xv::sid::kFileLicVer).c_str());
    std::remove(SV(xv::sid::kFileAuthKey).c_str());
}

void StateInit() {
    xvstate::Init(SV(xv::sid::kFileState));
    if (!xvstate::Ready()) return;
    MigrateLegacyLastConfig();
    PurgeLegacyFiles();
}

struct PwhashProfile {
    unsigned long long ops;
    std::size_t mem;
};

PwhashProfile SelectProfile() {
    PwhashProfile profile;
    profile.ops = static_cast<unsigned long long>(PV(xv::pid::kPwhashOpsInteractive));
    profile.mem = static_cast<std::size_t>(PV(xv::pid::kPwhashMemInteractive));

    long pages = sysconf(_SC_PHYS_PAGES);
    long pageSize = sysconf(_SC_PAGESIZE);
    if (pages > 0 && pageSize > 0) {
        std::uint64_t ram = static_cast<std::uint64_t>(pages) * static_cast<std::uint64_t>(pageSize);
        if (ram >= PV(xv::pid::kRamThresholdSensitive)) {
            profile.ops = static_cast<unsigned long long>(PV(xv::pid::kPwhashOpsSensitive));
            profile.mem = static_cast<std::size_t>(PV(xv::pid::kPwhashMemSensitive));
        } else if (ram >= PV(xv::pid::kRamThresholdModerate)) {
            profile.ops = static_cast<unsigned long long>(PV(xv::pid::kPwhashOpsModerate));
            profile.mem = static_cast<std::size_t>(PV(xv::pid::kPwhashMemModerate));
        }
    }
    if (profile.mem < crypto_pwhash_MEMLIMIT_MIN) profile.mem = crypto_pwhash_MEMLIMIT_MIN;
    if (profile.mem > crypto_pwhash_MEMLIMIT_MAX) profile.mem = crypto_pwhash_MEMLIMIT_MAX;
    if (profile.ops < crypto_pwhash_OPSLIMIT_MIN) profile.ops = crypto_pwhash_OPSLIMIT_MIN;
    if (profile.ops > crypto_pwhash_OPSLIMIT_MAX) profile.ops = crypto_pwhash_OPSLIMIT_MAX;
    return profile;
}

bool StretchLicense(const std::string& license, const unsigned char* salt, const PwhashProfile& profile,
                    unsigned char* out32) {
    if (license.empty()) return false;
    return crypto_pwhash(out32, 32, license.data(), license.size(), salt, profile.ops, profile.mem,
                         static_cast<int>(PV(xv::pid::kPwhashAlg))) == 0;
}

bool DeviceWrapKey(const std::string& license, const unsigned char* salt,
                   const PwhashProfile& profile, unsigned char* out32) {
    unsigned char stretched[32];
    if (!StretchLicense(license, salt, profile, stretched)) return false;
    unsigned char seed[32];
    std::memcpy(seed, stretched, 32);
    unsigned char deviceDomain[32];
    bool ok = DomainKey(xv::kid::kDeviceDomain, deviceDomain);
    if (ok) {
        ok = crypto_generichash(out32, 32, seed, sizeof(seed), deviceDomain, sizeof(deviceDomain)) == 0;
    }
    sodium_memzero(stretched, sizeof(stretched));
    sodium_memzero(seed, sizeof(seed));
    sodium_memzero(deviceDomain, sizeof(deviceDomain));
    return ok;
}

constexpr std::size_t kDeviceHeader = 4 + 4 + 8 + 8 + crypto_pwhash_SALTBYTES;
constexpr std::size_t kDeviceBody = crypto_sign_SECRETKEYBYTES + crypto_sign_PUBLICKEYBYTES;
constexpr std::size_t kDeviceFileSize =
    kDeviceHeader + crypto_aead_xchacha20poly1305_ietf_NPUBBYTES + kDeviceBody +
    crypto_aead_xchacha20poly1305_ietf_ABYTES;

bool LoadDevice(const std::string& license, DeviceKeys& keys) {
    std::vector<unsigned char> blob;
    if (!xvstate::Read(xvstate::kDevice, blob)) return false;
    if (blob.size() != kDeviceFileSize) return false;

    std::uint32_t magic = 0;
    std::uint32_t version = 0;
    std::memcpy(&magic, blob.data(), 4);
    std::memcpy(&version, blob.data() + 4, 4);
    if (magic != DeviceFileMagic || version != static_cast<std::uint32_t>(PV(xv::pid::kProtocolVersion))) {
        return false;
    }

    PwhashProfile profile;
    std::uint64_t mem = 0;
    std::memcpy(&profile.ops, blob.data() + 8, 8);
    std::memcpy(&mem, blob.data() + 16, 8);
    profile.mem = static_cast<std::size_t>(mem);

    unsigned char wrap[32];
    if (!DeviceWrapKey(license, blob.data() + 24, profile, wrap)) return false;

    const unsigned char* npub = blob.data() + kDeviceHeader;
    const unsigned char* ct = npub + crypto_aead_xchacha20poly1305_ietf_NPUBBYTES;
    std::vector<unsigned char> plain(kDeviceBody);
    unsigned long long plainLen = 0;
    std::string ad = SV(xv::sid::kDomainDevice);
    int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
        plain.data(), &plainLen, nullptr, ct,
        kDeviceBody + crypto_aead_xchacha20poly1305_ietf_ABYTES,
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), npub, wrap);
    sodium_memzero(wrap, sizeof(wrap));
    CleanseString(ad);
    CleanseVector(blob);
    if (rc != 0 || plainLen != kDeviceBody) {
        CleanseVector(plain);
        return false;
    }

    keys.sk.assign(plain.begin(), plain.begin() + crypto_sign_SECRETKEYBYTES);
    keys.pk.assign(plain.begin() + crypto_sign_SECRETKEYBYTES, plain.end());
    CleanseVector(plain);
    return keys.sk.size() == crypto_sign_SECRETKEYBYTES && keys.pk.size() == crypto_sign_PUBLICKEYBYTES;
}

bool CreateDevice(const std::string& license, DeviceKeys& keys) {
    unsigned char seed[crypto_sign_SEEDBYTES];
    randombytes_buf(seed, sizeof(seed));
    keys.pk.resize(crypto_sign_PUBLICKEYBYTES);
    keys.sk.resize(crypto_sign_SECRETKEYBYTES);
    int rc = crypto_sign_seed_keypair(keys.pk.data(), keys.sk.data(), seed);
    sodium_memzero(seed, sizeof(seed));
    if (rc != 0) {
        keys.Wipe();
        return false;
    }

    PwhashProfile profile = SelectProfile();
    unsigned char salt[crypto_pwhash_SALTBYTES];
    randombytes_buf(salt, sizeof(salt));
    unsigned char wrap[32];
    if (!DeviceWrapKey(license, salt, profile, wrap)) {
        sodium_memzero(salt, sizeof(salt));
        keys.Wipe();
        return false;
    }

    std::vector<unsigned char> blob(kDeviceFileSize);
    std::uint32_t magic = DeviceFileMagic;
    std::uint32_t version = static_cast<std::uint32_t>(PV(xv::pid::kProtocolVersion));
    std::uint64_t mem = profile.mem;
    std::memcpy(blob.data(), &magic, 4);
    std::memcpy(blob.data() + 4, &version, 4);
    std::memcpy(blob.data() + 8, &profile.ops, 8);
    std::memcpy(blob.data() + 16, &mem, 8);
    std::memcpy(blob.data() + 24, salt, sizeof(salt));

    std::vector<unsigned char> plain(kDeviceBody);
    std::memcpy(plain.data(), keys.sk.data(), crypto_sign_SECRETKEYBYTES);
    std::memcpy(plain.data() + crypto_sign_SECRETKEYBYTES, keys.pk.data(), crypto_sign_PUBLICKEYBYTES);

    unsigned char* npub = blob.data() + kDeviceHeader;
    randombytes_buf(npub, crypto_aead_xchacha20poly1305_ietf_NPUBBYTES);
    std::string ad = SV(xv::sid::kDomainDevice);
    unsigned long long ctLen = 0;
    rc = crypto_aead_xchacha20poly1305_ietf_encrypt(
        npub + crypto_aead_xchacha20poly1305_ietf_NPUBBYTES, &ctLen, plain.data(), plain.size(),
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), nullptr, npub, wrap);
    sodium_memzero(wrap, sizeof(wrap));
    sodium_memzero(salt, sizeof(salt));
    CleanseString(ad);
    CleanseVector(plain);
    if (rc != 0 || ctLen != kDeviceBody + crypto_aead_xchacha20poly1305_ietf_ABYTES) {
        keys.Wipe();
        CleanseVector(blob);
        return false;
    }

    bool ok = xvstate::Write(xvstate::kDevice, blob.data(), blob.size());
    CleanseVector(blob);
    if (!ok) keys.Wipe();
    return ok;
}

bool VerifyLicenseVersion(const std::string& license) {
    std::vector<unsigned char> blob;
    if (!xvstate::Read(xvstate::kLicVer, blob)) return false;
    if (blob.size() < 20 || blob.size() >= crypto_pwhash_STRBYTES) return false;
    if (blob.back() != 0) return false;
    return crypto_pwhash_str_verify(reinterpret_cast<const char*>(blob.data()), license.data(),
                                    license.size()) == 0;
}

void StoreLicenseVersion(const std::string& license) {
    PwhashProfile profile = SelectProfile();
    std::vector<unsigned char> blob(crypto_pwhash_STRBYTES, 0);
    if (crypto_pwhash_str(reinterpret_cast<char*>(blob.data()), license.data(), license.size(),
                          profile.ops, profile.mem) != 0) {
        CleanseVector(blob);
        return;
    }
    std::size_t len = std::strlen(reinterpret_cast<const char*>(blob.data())) + 1;
    blob.resize(len);
    xvstate::Write(xvstate::kLicVer, blob.data(), blob.size());
    CleanseVector(blob);
}

bool LicenseFileKey(unsigned char* out32) {
    unsigned char domainKey[32];
    if (!DomainKey(xv::kid::kLicenseDomain, domainKey)) return false;
    unsigned char seed[8];
    Store64(seed, DomainLicense);
    int rc = crypto_generichash(out32, 32, seed, sizeof(seed), domainKey, sizeof(domainKey));
    sodium_memzero(domainKey, sizeof(domainKey));
    sodium_memzero(seed, sizeof(seed));
    return rc == 0;
}

void SaveLicense(const std::string& license) {
    unsigned char key[32];
    if (!LicenseFileKey(key)) return;
    unsigned char npub[crypto_aead_xchacha20poly1305_ietf_NPUBBYTES];
    randombytes_buf(npub, sizeof(npub));
    std::vector<unsigned char> blob(sizeof(npub) + license.size() +
                                    crypto_aead_xchacha20poly1305_ietf_ABYTES);
    std::memcpy(blob.data(), npub, sizeof(npub));
    std::string ad = SV(xv::sid::kDomainLic);
    unsigned long long ctLen = 0;
    int rc = crypto_aead_xchacha20poly1305_ietf_encrypt(
        blob.data() + sizeof(npub), &ctLen,
        reinterpret_cast<const unsigned char*>(license.data()), license.size(),
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), nullptr, npub, key);
    sodium_memzero(key, sizeof(key));
    CleanseString(ad);
    if (rc != 0) {
        CleanseVector(blob);
        return;
    }
    xvstate::Write(xvstate::kAuthKey, blob.data(), sizeof(npub) + ctLen);
    CleanseVector(blob);
}

std::string LoadLicense() {
    std::vector<unsigned char> blob;
    if (!xvstate::Read(xvstate::kAuthKey, blob)) return std::string();
    constexpr std::size_t kNpub = crypto_aead_xchacha20poly1305_ietf_NPUBBYTES;
    if (blob.size() <= kNpub + crypto_aead_xchacha20poly1305_ietf_ABYTES) return std::string();

    unsigned char key[32];
    if (!LicenseFileKey(key)) return std::string();
    std::vector<unsigned char> plain(blob.size() - kNpub -
                                     crypto_aead_xchacha20poly1305_ietf_ABYTES);
    unsigned long long plainLen = 0;
    std::string ad = SV(xv::sid::kDomainLic);
    int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
        plain.data(), &plainLen, nullptr, blob.data() + kNpub, blob.size() - kNpub,
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), blob.data(), key);
    sodium_memzero(key, sizeof(key));
    CleanseString(ad);
    CleanseVector(blob);
    if (rc != 0) {
        CleanseVector(plain);
        return std::string();
    }
    std::string out(reinterpret_cast<char*>(plain.data()), static_cast<std::size_t>(plainLen));
    CleanseVector(plain);
    TrimWs(out);
    return out;
}

bool TokenFileKey(unsigned char* out32) {
    return IntegrityMixKey(out32, xv::kid::kStreamDomain, DomainSession);
}

void SaveToken(const std::string& tokenHex) {
    std::vector<unsigned char> raw;
    if (!HexToBytes(tokenHex, raw) || raw.size() != TokenBytes) return;

    unsigned char key[32];
    if (!TokenFileKey(key)) {
        CleanseVector(raw);
        return;
    }
    unsigned char npub[crypto_aead_xchacha20poly1305_ietf_NPUBBYTES];
    randombytes_buf(npub, sizeof(npub));
    std::vector<unsigned char> blob(4 + sizeof(npub) + raw.size() +
                                    crypto_aead_xchacha20poly1305_ietf_ABYTES);
    std::uint32_t magic = TokenFileMagic;
    std::memcpy(blob.data(), &magic, 4);
    std::memcpy(blob.data() + 4, npub, sizeof(npub));
    std::string ad = SV(xv::sid::kDomainToken);
    unsigned long long ctLen = 0;
    int rc = crypto_aead_xchacha20poly1305_ietf_encrypt(
        blob.data() + 4 + sizeof(npub), &ctLen, raw.data(), raw.size(),
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), nullptr, npub, key);
    sodium_memzero(key, sizeof(key));
    CleanseString(ad);
    CleanseVector(raw);
    if (rc != 0) {
        CleanseVector(blob);
        return;
    }
    xvstate::Write(xvstate::kSession, blob.data(), 4 + sizeof(npub) + ctLen);
    CleanseVector(blob);
}

std::string LoadToken() {
    std::vector<unsigned char> blob;
    if (!xvstate::Read(xvstate::kSession, blob)) return std::string();
    constexpr std::size_t kNpub = crypto_aead_xchacha20poly1305_ietf_NPUBBYTES;
    if (blob.size() != 4 + kNpub + TokenBytes + crypto_aead_xchacha20poly1305_ietf_ABYTES) {
        return std::string();
    }
    std::uint32_t magic = 0;
    std::memcpy(&magic, blob.data(), 4);
    if (magic != TokenFileMagic) return std::string();

    unsigned char key[32];
    if (!TokenFileKey(key)) return std::string();
    std::vector<unsigned char> plain(TokenBytes);
    unsigned long long plainLen = 0;
    std::string ad = SV(xv::sid::kDomainToken);
    int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
        plain.data(), &plainLen, nullptr, blob.data() + 4 + kNpub, blob.size() - 4 - kNpub,
        reinterpret_cast<const unsigned char*>(ad.data()), ad.size(), blob.data() + 4, key);
    sodium_memzero(key, sizeof(key));
    CleanseString(ad);
    CleanseVector(blob);
    if (rc != 0 || plainLen != TokenBytes) {
        CleanseVector(plain);
        return std::string();
    }
    std::string out = BytesToHex(plain.data(), plain.size());
    CleanseVector(plain);
    return out;
}

bool TokenUsable(const std::string& tokenHex, const std::string& devicePubHex, std::uint64_t& expires) {
    std::vector<unsigned char> raw;
    if (!HexToBytes(tokenHex, raw) || raw.size() != TokenBytes) return false;
    std::vector<unsigned char> expected;
    bool sameDevice = HexToBytes(devicePubHex, expected) &&
                      expected.size() == crypto_sign_PUBLICKEYBYTES &&
                      crypto_verify_32(raw.data(), expected.data()) == 0;
    CleanseVector(expected);
    expires = Load64(raw.data() + 40);
    std::uint64_t issued = Load64(raw.data() + 32);
    std::uint64_t margin = PV(xv::pid::kTokenMinRemaining);
    CleanseVector(raw);
    return sameDevice && issued != 0 && expires > Now() + margin;
}

bool LicenseTag(unsigned char* out32, const std::string& license, const std::string& message) {
    unsigned char licenseDomain[32];
    if (!DomainKey(xv::kid::kLicenseDomain, licenseDomain)) return false;
    unsigned char licKey[32];
    bool ok = crypto_generichash(licKey, sizeof(licKey),
                                 reinterpret_cast<const unsigned char*>(license.data()),
                                 license.size(), licenseDomain, sizeof(licenseDomain)) == 0;
    sodium_memzero(licenseDomain, sizeof(licenseDomain));
    if (!ok) {
        sodium_memzero(licKey, sizeof(licKey));
        return false;
    }
    ok = crypto_auth(out32, reinterpret_cast<const unsigned char*>(message.data()), message.size(),
                     licKey) == 0;
    sodium_memzero(licKey, sizeof(licKey));
    return ok;
}

bool SessionMix(unsigned char* out8, const unsigned char* in, std::size_t inLen) {
    unsigned char key[32];
    if (!IntegrityMixKey(key, xv::kid::kStreamDomain, DomainRva)) return false;
    int rc = crypto_generichash(out8, 8, in, inLen, key, sizeof(key));
    sodium_memzero(key, sizeof(key));
    return rc == 0;
}

std::uint64_t SessionMixValue(std::uint64_t value) {
    unsigned char in[8];
    unsigned char out[8];
    Store64(in, value);
    if (!SessionMix(out, in, sizeof(in))) return 0;
    return Load64(out);
}

void ClearRva() {
    std::lock_guard<std::mutex> lock(g_sessionMutex);
    g_rvaEncoded.store(0, std::memory_order_release);
    g_rvaMask.store(0, std::memory_order_release);
    g_sessionEncoded.store(0, std::memory_order_release);
    g_sessionCheck.store(0, std::memory_order_release);
    g_rvaBetaEncoded.store(0, std::memory_order_release);
    g_rvaBetaMask.store(0, std::memory_order_release);
    g_rvaBetaSessionEncoded.store(0, std::memory_order_release);
    g_rvaBetaSessionCheck.store(0, std::memory_order_release);
}

bool StoreRva(std::uint64_t rva, std::uint64_t seal) {
    if (rva == 0 || rva > PV(xv::pid::kRvaMax) || seal == 0) return false;
    std::uint64_t integrity = IntegrityToken();
    if (integrity == 0) return false;
    std::uint64_t mask = 0;
    randombytes_buf(&mask, sizeof(mask));
    if (mask == 0) return false;

    std::uint64_t encoded = rva ^ mask;
    std::uint64_t sessionEncoded = seal ^ SessionMixValue(mask ^ integrity);
    std::uint64_t check = SessionMixValue(rva ^ seal ^ mask ^ integrity ^ xv::BuildId());
    if (sessionEncoded == 0 || check == 0) return false;

    std::lock_guard<std::mutex> lock(g_sessionMutex);
    g_rvaMask.store(mask, std::memory_order_release);
    g_rvaEncoded.store(encoded, std::memory_order_release);
    g_sessionEncoded.store(sessionEncoded, std::memory_order_release);
    g_sessionCheck.store(check, std::memory_order_release);
    return true;
}

bool StoreRvaBeta(std::uint64_t rva, std::uint64_t seal) {
    if (rva == 0 || rva > PV(xv::pid::kRvaMax) || seal == 0) return false;
    std::uint64_t integrity = IntegrityToken();
    if (integrity == 0) return false;
    std::uint64_t mask = 0;
    randombytes_buf(&mask, sizeof(mask));
    if (mask == 0) return false;

    std::uint64_t encoded = rva ^ mask;
    std::uint64_t sessionEncoded = seal ^ SessionMixValue(mask ^ integrity);
    std::uint64_t check = SessionMixValue(rva ^ seal ^ mask ^ integrity ^ xv::BuildId());
    if (sessionEncoded == 0 || check == 0) return false;

    std::lock_guard<std::mutex> lock(g_sessionMutex);
    g_rvaBetaMask.store(mask, std::memory_order_release);
    g_rvaBetaEncoded.store(encoded, std::memory_order_release);
    g_rvaBetaSessionEncoded.store(sessionEncoded, std::memory_order_release);
    g_rvaBetaSessionCheck.store(check, std::memory_order_release);
    return true;
}

bool FlowGate(std::uint64_t domain) {
    return IntegrityCheckpoint(domain);
}

struct GrantResult {
    std::uint64_t rva = 0;
    std::uint64_t seal = 0;
    std::uint64_t rvaBeta = 0;
    std::uint64_t sealBeta = 0;
    std::string token;
};

struct ChunkReader {
    const std::vector<unsigned char>& raw;
    std::size_t pos = 0;

    explicit ChunkReader(const std::vector<unsigned char>& data, std::size_t start = 0)
        : raw(data), pos(start) {}

    bool Next(std::vector<unsigned char>& chunk) {
        if (pos + 2 > raw.size()) return false;
        std::size_t len = static_cast<std::size_t>(raw[pos]) |
                          (static_cast<std::size_t>(raw[pos + 1]) << 8);
        pos += 2;
        if (len < crypto_secretstream_xchacha20poly1305_ABYTES) return false;
        if (len > static_cast<std::size_t>(PV(xv::pid::kStreamChunkMax))) return false;
        if (pos + len > raw.size()) return false;
        chunk.assign(raw.begin() + static_cast<long>(pos),
                     raw.begin() + static_cast<long>(pos + len));
        pos += len;
        return true;
    }
};

bool RequestGrant(const std::string& license, const DeviceKeys& device, GrantResult& grant,
                  bool& networkFailure) {
    networkFailure = false;
    if (!xv::Ready() || !IntegrityRevalidate(DomainGrant) || !FlowGate(DomainChallenge)) return false;

    SensitiveCleanup cleanup;
    std::string nonce = RandomHex(static_cast<std::size_t>(PV(xv::pid::kSessionIdBytes)));
    cleanup.Add(nonce);
    if (nonce.size() != PV(xv::pid::kSessionIdBytes) * 2) return false;

    unsigned char clientPk[crypto_kx_PUBLICKEYBYTES];
    unsigned char clientSk[crypto_kx_SECRETKEYBYTES];
    if (crypto_kx_keypair(clientPk, clientSk) != 0) return false;
    std::string clientHex = BytesToHex(clientPk, sizeof(clientPk));
    std::string deviceHex = BytesToHex(device.pk.data(), device.pk.size());
    cleanup.Add(clientHex);
    cleanup.Add(deviceHex);

    std::string startBody = SV(xv::sid::kFieldNonce) + nonce + SV(xv::sid::kFieldAmpClient) +
                            clientHex + SV(xv::sid::kFieldAmpDevice) + deviceHex;
    cleanup.Add(startBody);
    std::string challenge;
    cleanup.Add(challenge);
    long status = 0;
    if (!Post(SV(xv::sid::kPathStart), startBody, challenge, status)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        networkFailure = true;
        return false;
    }
    TrimWs(challenge);
    if (status != 200 || !IsHex(challenge, 64)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        networkFailure = status != 200;
        return false;
    }
    if (!FlowGate(DomainSign)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }

    std::string signMessage = SV(xv::sid::kDomainSig) + nonce + SV(xv::sid::kColon) + challenge +
                              SV(xv::sid::kColon) + clientHex + SV(xv::sid::kColon) + deviceHex;
    cleanup.Add(signMessage);
    unsigned char signature[crypto_sign_BYTES];
    unsigned long long signatureLen = 0;
    if (crypto_sign_detached(signature, &signatureLen,
                             reinterpret_cast<const unsigned char*>(signMessage.data()),
                             signMessage.size(), device.sk.data()) != 0) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::string signatureHex = BytesToHex(signature, static_cast<std::size_t>(signatureLen));
    sodium_memzero(signature, sizeof(signature));
    cleanup.Add(signatureHex);

    std::string licenseMessage = SV(xv::sid::kDomainLic) + nonce + SV(xv::sid::kColon) + challenge +
                                 SV(xv::sid::kColon) + clientHex + SV(xv::sid::kColon) + deviceHex;
    cleanup.Add(licenseMessage);

    std::string cachedToken = LoadToken();
    cleanup.Add(cachedToken);
    std::uint64_t cachedExpires = 0;
    bool haveToken = TokenUsable(cachedToken, deviceHex, cachedExpires);

    std::string finishBody = SV(xv::sid::kFieldNonce) + nonce + SV(xv::sid::kFieldAmpChallenge) +
                             challenge + SV(xv::sid::kFieldAmpClient) + clientHex +
                             SV(xv::sid::kFieldAmpDevice) + deviceHex + SV(xv::sid::kFieldAmpSig) +
                             signatureHex;
    if (haveToken) {
        finishBody += SV(xv::sid::kFieldAmpToken) + cachedToken;
    } else {
        unsigned char tag[crypto_auth_BYTES];
        if (!LicenseTag(tag, license, licenseMessage)) {
            sodium_memzero(clientSk, sizeof(clientSk));
            return false;
        }
        finishBody += SV(xv::sid::kFieldAmpLic) + BytesToHex(tag, sizeof(tag));
        sodium_memzero(tag, sizeof(tag));
    }
    cleanup.Add(finishBody);

    std::string response;
    cleanup.Add(response);
    status = 0;
    if (!Post(SV(xv::sid::kPathFinish), finishBody, response, status)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        networkFailure = true;
        return false;
    }
    TrimWs(response);
    if (status != 200 || !IsHex(response, 0) || response.size() % 2 != 0) {
        sodium_memzero(clientSk, sizeof(clientSk));
        networkFailure = status != 200;
        return false;
    }
    if (!FlowGate(DomainFinish)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }

    std::vector<unsigned char> raw;
    cleanup.Add(raw);
    if (!HexToBytes(response, raw)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    constexpr std::size_t kHeader = crypto_secretstream_xchacha20poly1305_HEADERBYTES;
    if (raw.size() < kHeader + 3 * (2 + crypto_secretstream_xchacha20poly1305_ABYTES)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }

    unsigned char serverPk[crypto_kx_PUBLICKEYBYTES];
    if (!DomainKey(xv::kid::kServerKxPublic, serverPk)) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    unsigned char rx[crypto_kx_SESSIONKEYBYTES];
    unsigned char tx[crypto_kx_SESSIONKEYBYTES];
    if (crypto_kx_client_session_keys(rx, tx, clientPk, clientSk, serverPk) != 0) {
        sodium_memzero(clientSk, sizeof(clientSk));
        sodium_memzero(serverPk, sizeof(serverPk));
        return false;
    }
    sodium_memzero(clientSk, sizeof(clientSk));
    sodium_memzero(serverPk, sizeof(serverPk));

    crypto_secretstream_xchacha20poly1305_state stream;
    if (crypto_secretstream_xchacha20poly1305_init_pull(&stream, raw.data(), rx) != 0) {
        sodium_memzero(rx, sizeof(rx));
        sodium_memzero(tx, sizeof(tx));
        sodium_memzero(&stream, sizeof(stream));
        return false;
    }
    sodium_memzero(rx, sizeof(rx));
    sodium_memzero(tx, sizeof(tx));

    std::string ad = SV(xv::sid::kDomainStream) + nonce + SV(xv::sid::kColon) + challenge +
                     SV(xv::sid::kColon) + clientHex;
    cleanup.Add(ad);

    std::vector<unsigned char> sessionId;
    if (!HexToBytes(nonce, sessionId) || sessionId.size() != PV(xv::pid::kSessionIdBytes)) {
        sodium_memzero(&stream, sizeof(stream));
        return false;
    }

    ChunkReader reader(raw, kHeader);
    std::vector<unsigned char> chunk;
    std::vector<unsigned char> plain;
    cleanup.Add(chunk);
    cleanup.Add(plain);
    cleanup.Add(sessionId);

    std::uint64_t expectedCounter = PV(xv::pid::kCounterFirst);
    std::uint64_t issued = 0;
    std::uint64_t expires = 0;
    std::uint32_t licenseId = 0;
    std::string tokenHex;
    cleanup.Add(tokenHex);
    std::uint64_t rva = 0;
    std::uint64_t rvaBeta = 0;
    std::uint32_t flags = 0;
    bool completed = false;

    while (reader.Next(chunk)) {
        unsigned char tag = 0;
        unsigned long long plainLen = 0;
        std::size_t expected = chunk.size() - crypto_secretstream_xchacha20poly1305_ABYTES;
        plain.assign(expected, 0);
        if (crypto_secretstream_xchacha20poly1305_pull(
                &stream, plain.data(), &plainLen, &tag, chunk.data(), chunk.size(),
                reinterpret_cast<const unsigned char*>(ad.data()), ad.size()) != 0) {
            break;
        }
        if (plainLen < PV(xv::pid::kSessionIdBytes) + 8) break;
        if (sodium_memcmp(plain.data(), sessionId.data(), sessionId.size()) != 0) break;
        std::uint64_t counter = Load64(plain.data() + PV(xv::pid::kSessionIdBytes));
        if (counter != expectedCounter) break;
        ++expectedCounter;

        std::size_t offset = static_cast<std::size_t>(PV(xv::pid::kSessionIdBytes)) + 8;
        if (tag == crypto_secretstream_xchacha20poly1305_TAG_MESSAGE && plainLen == offset + 8 + 8 + 4 + TokenBytes) {
            issued = Load64(plain.data() + offset);
            expires = Load64(plain.data() + offset + 8);
            licenseId = Load32(plain.data() + offset + 16);
            tokenHex = BytesToHex(plain.data() + offset + 20, TokenBytes);
        } else if (tag == crypto_secretstream_xchacha20poly1305_TAG_PUSH && plainLen == offset + 8 + 4) {
            rva = Load64(plain.data() + offset);
            flags = Load32(plain.data() + offset + 8);
        } else if (tag == crypto_secretstream_xchacha20poly1305_TAG_MESSAGE && plainLen == offset + 8) {
            rvaBeta = Load64(plain.data() + offset);
        } else if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL && plainLen == offset + 1) {
            completed = plain[offset] == 1;
            break;
        } else {
            break;
        }
        if (expectedCounter > PV(xv::pid::kStreamChunkCountMax) + PV(xv::pid::kCounterFirst)) break;
    }
    sodium_memzero(&stream, sizeof(stream));

    bool valid = completed && issued != 0 && expires > Now() + PV(xv::pid::kTokenSkewSeconds) &&
                 licenseId != 0 && tokenHex.size() == TokenBytes * 2 && rva != 0 &&
                 rva <= PV(xv::pid::kRvaMax) && (flags & 1u) != 0;
    if (!valid || !FlowGate(DomainDecrypt)) {
        CleanseString(tokenHex);
        return false;
    }

    std::vector<unsigned char> tokenRaw;
    if (!HexToBytes(tokenHex, tokenRaw)) return false;
    std::vector<unsigned char> sealInput(8 + tokenRaw.size());
    Store64(sealInput.data(), rva);
    std::memcpy(sealInput.data() + 8, tokenRaw.data(), tokenRaw.size());
    unsigned char seal[8];
    bool sealed = SessionMix(seal, sealInput.data(), sealInput.size());
    unsigned char sealBeta[8] = {};
    Store64(sealInput.data(), rvaBeta);
    bool sealedBeta = rvaBeta != 0 && rvaBeta <= PV(xv::pid::kRvaMax) &&
                      SessionMix(sealBeta, sealInput.data(), sealInput.size());
    CleanseVector(sealInput);
    CleanseVector(tokenRaw);
    if (!sealed || Load64(seal) == 0) {
        sodium_memzero(sealBeta, sizeof(sealBeta));
        CleanseString(tokenHex);
        return false;
    }
    if (!IntegrityRevalidate(DomainSession ^ rva ^ Load64(seal))) {
        sodium_memzero(sealBeta, sizeof(sealBeta));
        CleanseString(tokenHex);
        return false;
    }

    grant.rva = rva;
    grant.seal = Load64(seal);
    if (sealedBeta && Load64(sealBeta) != 0) {
        grant.rvaBeta = rvaBeta;
        grant.sealBeta = Load64(sealBeta);
    }
    sodium_memzero(sealBeta, sizeof(sealBeta));
    grant.token = tokenHex;
    g_tokenExpires.store(expires, std::memory_order_release);
    SaveToken(tokenHex);
    return true;
}

std::string NormalizeName(const std::string& name) {
    std::string out;
    out.reserve(name.size());
    for (unsigned char ch : name) {
        if (ch == ' ' || ch == '\t') continue;
        if (ch >= 'A' && ch <= 'Z') ch = static_cast<unsigned char>(ch + 32);
        out.push_back(static_cast<char>(ch));
    }
    return out;
}

std::string NameHashHex(const std::string& name) {
    std::string normalized = NormalizeName(name);
    if (normalized.empty()) return std::string();
    std::string message = SV(xv::sid::kDomainName) + normalized;
    unsigned char licenseDomain[32];
    if (!DomainKey(xv::kid::kLicenseDomain, licenseDomain)) {
        CleanseString(message);
        CleanseString(normalized);
        return std::string();
    }
    unsigned char digest[32];
    crypto_generichash(digest, sizeof(digest),
                       reinterpret_cast<const unsigned char*>(message.data()), message.size(),
                       licenseDomain, sizeof(licenseDomain));
    sodium_memzero(licenseDomain, sizeof(licenseDomain));
    std::string hex = BytesToHex(digest, 8);
    sodium_memzero(digest, sizeof(digest));
    CleanseString(message);
    CleanseString(normalized);
    return hex;
}

std::string LocalNameHash() {
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    return g_presenceLocalHash;
}

bool ParseCount(const std::string& text, int& value) {
    if (text.empty() || text.size() > 6) return false;
    for (char c : text) {
        if (c < '0' || c > '9') return false;
    }
    value = std::atoi(text.c_str());
    return value >= 0;
}

void PresenceApplyFull(int count, const std::string& list, const std::string& localHash) {
    std::vector<std::uint64_t> peers;
    peers.reserve(64);
    std::size_t begin = 0;
    while (begin <= list.size() && !list.empty()) {
        std::size_t end = list.find(',', begin);
        if (end == std::string::npos) end = list.size();
        std::string item = list.substr(begin, end - begin);
        std::uint64_t parsed = HexToU64(item);
        if (parsed != 0 && item != localHash) peers.push_back(parsed);
        if (end >= list.size()) break;
        begin = end + 1;
    }
    g_onlineCount.store(count, std::memory_order_release);
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    g_presencePeerHashes.swap(peers);
}

void PresenceApplyDelta(char sign, const std::string& item, const std::string& localHash) {
    std::uint64_t parsed = HexToU64(item);
    if (parsed == 0 || item == localHash) return;
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    auto it = std::find(g_presencePeerHashes.begin(), g_presencePeerHashes.end(), parsed);
    if (sign == '+') {
        if (it == g_presencePeerHashes.end()) g_presencePeerHashes.push_back(parsed);
    } else if (it != g_presencePeerHashes.end()) {
        g_presencePeerHashes.erase(it);
    }
}

void PresenceHandleText(const std::string& text) {
    std::string localHash = LocalNameHash();
    std::size_t begin = 0;
    while (begin < text.size()) {
        std::size_t end = text.find('\n', begin);
        if (end == std::string::npos) end = text.size();
        std::string line = text.substr(begin, end - begin);
        begin = end + 1;
        if (line.empty()) continue;
        if (line.size() >= 2 && line[0] == 'f' && line[1] == ':') {
            std::size_t sep = line.find(':', 2);
            std::string countText = sep == std::string::npos ? line.substr(2) : line.substr(2, sep - 2);
            std::string list = sep == std::string::npos ? std::string() : line.substr(sep + 1);
            int count = 0;
            if (ParseCount(countText, count)) PresenceApplyFull(count, list, localHash);
        } else if (line.size() >= 2 && line[0] == 'n' && line[1] == ':') {
            int count = 0;
            if (ParseCount(line.substr(2), count)) g_onlineCount.store(count, std::memory_order_release);
        } else if (line[0] == '+' || line[0] == '-') {
            PresenceApplyDelta(line[0], line.substr(1), localHash);
        }
    }
}

bool WsSendRaw(CURL* curl, const unsigned char* data, std::size_t size) {
    std::size_t offset = 0;
    int spins = 0;
    while (offset < size) {
        std::size_t sent = 0;
        CURLcode rc = curl_easy_send(curl, data + offset, size - offset, &sent);
        if (rc == CURLE_AGAIN) {
            if (++spins > 500 || g_presenceStop.load(std::memory_order_acquire)) return false;
            usleep(10000);
            continue;
        }
        if (rc != CURLE_OK) return false;
        offset += sent;
        spins = 0;
    }
    return true;
}

bool WsSendFrame(CURL* curl, int opcode, const std::string& payload) {
    if (payload.size() >= 65536) return false;
    std::vector<unsigned char> frame;
    frame.reserve(payload.size() + 8);
    frame.push_back(static_cast<unsigned char>(0x80 | (opcode & 0x0F)));
    std::size_t size = payload.size();
    if (size < 126) {
        frame.push_back(static_cast<unsigned char>(0x80 | size));
    } else {
        frame.push_back(static_cast<unsigned char>(0x80 | 126));
        frame.push_back(static_cast<unsigned char>(size >> 8));
        frame.push_back(static_cast<unsigned char>(size & 0xFF));
    }
    unsigned char mask[4];
    randombytes_buf(mask, sizeof(mask));
    frame.insert(frame.end(), mask, mask + 4);
    for (std::size_t i = 0; i < size; ++i) {
        frame.push_back(static_cast<unsigned char>(
            static_cast<unsigned char>(payload[i]) ^ mask[i & 3]));
    }
    return WsSendRaw(curl, frame.data(), frame.size());
}

int WsRecvSome(CURL* curl, std::string& buffer) {
    unsigned char chunk[4096];
    std::size_t received = 0;
    CURLcode rc = curl_easy_recv(curl, chunk, sizeof(chunk), &received);
    if (rc == CURLE_AGAIN) return 0;
    if (rc != CURLE_OK) return -1;
    if (received == 0) return -1;
    buffer.append(reinterpret_cast<const char*>(chunk), received);
    sodium_memzero(chunk, sizeof(chunk));
    if (buffer.size() > 262144) return -1;
    return 1;
}

bool WsWaitReadable(curl_socket_t fd, int timeoutMs) {
    if (fd == CURL_SOCKET_BAD) {
        usleep(static_cast<useconds_t>(timeoutMs) * 1000);
        return false;
    }
    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    int rc = poll(&pfd, 1, timeoutMs);
    return rc > 0 && (pfd.revents & (POLLIN | POLLHUP | POLLERR)) != 0;
}

void Sha1(const unsigned char* data, std::size_t len, unsigned char out[20]) {
    std::uint32_t h0 = 0x67452301u;
    std::uint32_t h1 = 0xEFCDAB89u;
    std::uint32_t h2 = 0x98BADCFEu;
    std::uint32_t h3 = 0x10325476u;
    std::uint32_t h4 = 0xC3D2E1F0u;

    std::vector<unsigned char> msg(data, data + len);
    std::uint64_t bits = static_cast<std::uint64_t>(len) * 8;
    msg.push_back(0x80);
    while (msg.size() % 64 != 56) msg.push_back(0x00);
    for (int i = 7; i >= 0; --i) msg.push_back(static_cast<unsigned char>((bits >> (8 * i)) & 0xFF));

    for (std::size_t block = 0; block < msg.size(); block += 64) {
        std::uint32_t w[80];
        for (int i = 0; i < 16; ++i) {
            w[i] = (static_cast<std::uint32_t>(msg[block + 4 * i]) << 24) |
                   (static_cast<std::uint32_t>(msg[block + 4 * i + 1]) << 16) |
                   (static_cast<std::uint32_t>(msg[block + 4 * i + 2]) << 8) |
                   static_cast<std::uint32_t>(msg[block + 4 * i + 3]);
        }
        for (int i = 16; i < 80; ++i) {
            std::uint32_t v = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16];
            w[i] = (v << 1) | (v >> 31);
        }
        std::uint32_t a = h0;
        std::uint32_t b = h1;
        std::uint32_t c = h2;
        std::uint32_t d = h3;
        std::uint32_t e = h4;
        for (int i = 0; i < 80; ++i) {
            std::uint32_t f = 0;
            std::uint32_t k = 0;
            if (i < 20) {
                f = (b & c) | ((~b) & d);
                k = 0x5A827999u;
            } else if (i < 40) {
                f = b ^ c ^ d;
                k = 0x6ED9EBA1u;
            } else if (i < 60) {
                f = (b & c) | (b & d) | (c & d);
                k = 0x8F1BBCDCu;
            } else {
                f = b ^ c ^ d;
                k = 0xCA62C1D6u;
            }
            std::uint32_t temp = ((a << 5) | (a >> 27)) + f + e + k + w[i];
            e = d;
            d = c;
            c = (b << 30) | (b >> 2);
            b = a;
            a = temp;
        }
        h0 += a;
        h1 += b;
        h2 += c;
        h3 += d;
        h4 += e;
    }
    Store32Be(out, h0);
    Store32Be(out + 4, h1);
    Store32Be(out + 8, h2);
    Store32Be(out + 12, h3);
    Store32Be(out + 16, h4);
    CleanseVector(msg);
}

std::string Base64Encode(const unsigned char* data, std::size_t size) {
    std::size_t capacity = sodium_base64_ENCODED_LEN(size, sodium_base64_VARIANT_ORIGINAL);
    std::vector<char> out(capacity + 1, 0);
    if (sodium_bin2base64(out.data(), capacity, data, size, sodium_base64_VARIANT_ORIGINAL) == nullptr) {
        return std::string();
    }
    return std::string(out.data());
}

struct WsChannel {
    CURL* curl = nullptr;
    curl_socket_t fd = CURL_SOCKET_BAD;
    std::string buffer;
    crypto_secretstream_xchacha20poly1305_state pull{};
    crypto_secretstream_xchacha20poly1305_state push{};
    std::uint64_t sent = 0;
    std::uint64_t lastRekey = 0;

    void Wipe() {
        sodium_memzero(&pull, sizeof(pull));
        sodium_memzero(&push, sizeof(push));
        CleanseString(buffer);
    }
};

bool StreamPush(WsChannel& channel, const std::string& message, unsigned char tag) {
    if (message.size() > static_cast<std::size_t>(PV(xv::pid::kStreamChunkMax))) return false;
    std::vector<unsigned char> ct(message.size() + crypto_secretstream_xchacha20poly1305_ABYTES);
    unsigned long long ctLen = 0;
    if (crypto_secretstream_xchacha20poly1305_push(
            &channel.push, ct.data(), &ctLen,
            reinterpret_cast<const unsigned char*>(message.data()), message.size(), nullptr, 0,
            tag) != 0) {
        CleanseVector(ct);
        return false;
    }
    std::string frame(2, '\0');
    frame[0] = static_cast<char>(ctLen & 0xFF);
    frame[1] = static_cast<char>((ctLen >> 8) & 0xFF);
    frame.append(reinterpret_cast<const char*>(ct.data()), static_cast<std::size_t>(ctLen));
    CleanseVector(ct);
    bool ok = WsSendFrame(channel.curl, 2, frame);
    CleanseString(frame);
    if (ok) ++channel.sent;
    return ok;
}

bool StreamPull(WsChannel& channel, const std::string& frame, std::string& message) {
    if (frame.size() < 2 + crypto_secretstream_xchacha20poly1305_ABYTES) return false;
    std::size_t len = static_cast<std::size_t>(static_cast<unsigned char>(frame[0])) |
                      (static_cast<std::size_t>(static_cast<unsigned char>(frame[1])) << 8);
    if (len != frame.size() - 2) return false;
    if (len > static_cast<std::size_t>(PV(xv::pid::kStreamChunkMax)) +
                  crypto_secretstream_xchacha20poly1305_ABYTES) {
        return false;
    }
    std::vector<unsigned char> plain(len - crypto_secretstream_xchacha20poly1305_ABYTES);
    unsigned long long plainLen = 0;
    unsigned char tag = 0;
    if (crypto_secretstream_xchacha20poly1305_pull(
            &channel.pull, plain.data(), &plainLen, &tag,
            reinterpret_cast<const unsigned char*>(frame.data() + 2), len, nullptr, 0) != 0) {
        CleanseVector(plain);
        return false;
    }
    message.assign(reinterpret_cast<const char*>(plain.data()), static_cast<std::size_t>(plainLen));
    CleanseVector(plain);
    return true;
}

int WsParseFrames(WsChannel& channel, bool& gotAny) {
    std::string& buffer = channel.buffer;
    for (;;) {
        if (buffer.size() < 2) return 1;
        const unsigned char b0 = static_cast<unsigned char>(buffer[0]);
        const unsigned char b1 = static_cast<unsigned char>(buffer[1]);
        const int opcode = b0 & 0x0F;
        const bool masked = (b1 & 0x80) != 0;
        std::uint64_t length = b1 & 0x7F;
        std::size_t header = 2;
        if (length == 126) {
            if (buffer.size() < 4) return 1;
            length = (static_cast<std::uint64_t>(static_cast<unsigned char>(buffer[2])) << 8) |
                     static_cast<unsigned char>(buffer[3]);
            header = 4;
        } else if (length == 127) {
            if (buffer.size() < 10) return 1;
            length = 0;
            for (int i = 0; i < 8; ++i) {
                length = (length << 8) | static_cast<unsigned char>(buffer[2 + i]);
            }
            header = 10;
        }
        if (masked) header += 4;
        if (length > 131072) return -1;
        if (buffer.size() < header + length) return 1;
        std::string payload = buffer.substr(header, static_cast<std::size_t>(length));
        if (masked) {
            const unsigned char* mask =
                reinterpret_cast<const unsigned char*>(buffer.data() + header - 4);
            for (std::size_t i = 0; i < payload.size(); ++i) {
                payload[i] = static_cast<char>(
                    static_cast<unsigned char>(payload[i]) ^ mask[i & 3]);
            }
        }
        buffer.erase(0, header + static_cast<std::size_t>(length));
        gotAny = true;
        if (opcode == 8) {
            CleanseString(payload);
            return -1;
        }
        if (opcode == 9) {
            bool ok = WsSendFrame(channel.curl, 10, payload);
            CleanseString(payload);
            if (!ok) return -1;
            continue;
        }
        if (opcode == 2) {
            std::string message;
            bool ok = StreamPull(channel, payload, message);
            CleanseString(payload);
            if (!ok) return -1;
            if (!message.empty()) PresenceHandleText(message);
            CleanseString(message);
            if (!FlowGate(DomainFrame)) return -1;
            continue;
        }
        CleanseString(payload);
    }
}

bool WsConnect(WsChannel& channel, const DeviceKeys& device, const std::string& tokenHex) {
    SensitiveCleanup cleanup;
    std::string session = RandomHex(static_cast<std::size_t>(PV(xv::pid::kSessionIdBytes)));
    cleanup.Add(session);
    if (session.size() != PV(xv::pid::kSessionIdBytes) * 2) return false;

    char stampBuffer[24];
    std::snprintf(stampBuffer, sizeof(stampBuffer), xv::StrStable(xv::sid::kAuLlu), static_cast<unsigned long long>(Now()));
    std::string stamp = stampBuffer;
    cleanup.Add(stamp);

    unsigned char clientPk[crypto_kx_PUBLICKEYBYTES];
    unsigned char clientSk[crypto_kx_SECRETKEYBYTES];
    if (crypto_kx_keypair(clientPk, clientSk) != 0) return false;
    std::string clientHex = BytesToHex(clientPk, sizeof(clientPk));
    std::string deviceHex = BytesToHex(device.pk.data(), device.pk.size());
    cleanup.Add(clientHex);
    cleanup.Add(deviceHex);

    std::string message = SV(xv::sid::kDomainWs) + session + SV(xv::sid::kColon) + stamp +
                          SV(xv::sid::kColon) + deviceHex + SV(xv::sid::kColon) + clientHex;
    cleanup.Add(message);
    unsigned char signature[crypto_sign_BYTES];
    unsigned long long signatureLen = 0;
    if (crypto_sign_detached(signature, &signatureLen,
                             reinterpret_cast<const unsigned char*>(message.data()), message.size(),
                             device.sk.data()) != 0) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::string signatureHex = BytesToHex(signature, static_cast<std::size_t>(signatureLen));
    sodium_memzero(signature, sizeof(signature));
    cleanup.Add(signatureHex);

    std::string host = SV(xv::sid::kWsHost);
    std::string path = SV(xv::sid::kWsPath) + session + SV(xv::sid::kWsQueryStamp) + stamp +
                       SV(xv::sid::kWsQueryDevice) + deviceHex + SV(xv::sid::kWsQueryClient) +
                       clientHex + SV(xv::sid::kWsQuerySig) + signatureHex +
                       SV(xv::sid::kWsQueryToken) + tokenHex;
    std::string url = SV(xv::sid::kWsScheme) + host + path;
    cleanup.Add(host);
    cleanup.Add(path);
    cleanup.Add(url);

    unsigned char wsKeyBytes[16];
    randombytes_buf(wsKeyBytes, sizeof(wsKeyBytes));
    std::string wsKey = Base64Encode(wsKeyBytes, sizeof(wsKeyBytes));
    sodium_memzero(wsKeyBytes, sizeof(wsKeyBytes));
    cleanup.Add(wsKey);
    if (wsKey.empty()) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::string acceptSource = wsKey + SV(xv::sid::kWsGuid);
    cleanup.Add(acceptSource);
    unsigned char acceptDigest[20];
    Sha1(reinterpret_cast<const unsigned char*>(acceptSource.data()), acceptSource.size(),
         acceptDigest);
    std::string expectedAccept = LowerCopy(Base64Encode(acceptDigest, sizeof(acceptDigest)));
    sodium_memzero(acceptDigest, sizeof(acceptDigest));
    cleanup.Add(expectedAccept);

    channel.curl = curl_easy_init();
    if (!channel.curl) {
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    struct curl_blob caBlob;
    caBlob.data = const_cast<char*>(kCaBundlePem);
    caBlob.len = std::strlen(kCaBundlePem);
    caBlob.flags = CURL_BLOB_COPY;

    curl_easy_setopt(channel.curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(channel.curl, CURLOPT_CONNECT_ONLY, 1L);
    curl_easy_setopt(channel.curl, CURLOPT_HTTP_VERSION, static_cast<long>(CURL_HTTP_VERSION_1_1));
    curl_easy_setopt(channel.curl, CURLOPT_SSL_ENABLE_ALPN, 0L);
    curl_easy_setopt(channel.curl, CURLOPT_FRESH_CONNECT, 1L);
    curl_easy_setopt(channel.curl, CURLOPT_CONNECTTIMEOUT,
                     static_cast<long>(PV(xv::pid::kHttpConnectTimeoutSeconds)));
    curl_easy_setopt(channel.curl, CURLOPT_TIMEOUT,
                     static_cast<long>(PV(xv::pid::kHttpTimeoutSeconds)));
    curl_easy_setopt(channel.curl, CURLOPT_FOLLOWLOCATION, 0L);
    curl_easy_setopt(channel.curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(channel.curl, CURLOPT_SSL_VERIFYHOST, 2L);
    curl_easy_setopt(channel.curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(channel.curl, CURLOPT_CAINFO_BLOB, &caBlob);
    curl_easy_setopt(channel.curl, CURLOPT_TCP_KEEPALIVE, 1L);
    curl_easy_setopt(channel.curl, CURLOPT_TCP_KEEPIDLE, 45L);
    curl_easy_setopt(channel.curl, CURLOPT_TCP_KEEPINTVL, 15L);
    if (curl_easy_perform(channel.curl) != CURLE_OK) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }

    std::string sync = SyncHeader();
    std::string request = SV(xv::sid::kWsRequestHead) + path + SV(xv::sid::kWsRequestLine) + host +
                          SV(xv::sid::kWsRequestUpgrade) + wsKey + SV(xv::sid::kWsRequestTail) +
                          sync + SV(xv::sid::kWsRequestEnd);
    CleanseString(sync);
    cleanup.Add(request);
    if (!WsSendRaw(channel.curl, reinterpret_cast<const unsigned char*>(request.data()),
                   request.size())) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }

    curl_easy_getinfo(channel.curl, CURLINFO_ACTIVESOCKET, &channel.fd);
    std::string response;
    cleanup.Add(response);
    std::uint64_t deadline = Now() + PV(xv::pid::kHttpTimeoutSeconds);
    std::size_t headerEnd = std::string::npos;
    std::string headerTerminator = SV(xv::sid::kWsHeaderEnd);
    cleanup.Add(headerTerminator);
    while (Now() < deadline && !g_presenceStop.load(std::memory_order_acquire)) {
        int rc = WsRecvSome(channel.curl, response);
        if (rc < 0) break;
        if (rc == 0) {
            WsWaitReadable(channel.fd, 200);
            continue;
        }
        headerEnd = response.find(headerTerminator);
        if (headerEnd != std::string::npos) break;
        if (response.size() > 16384) break;
    }
    if (headerEnd == std::string::npos) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::string head = LowerCopy(response.substr(0, headerEnd));
    cleanup.Add(head);
    std::string statusMarker = SV(xv::sid::kWsStatusOk);
    std::string acceptHeader = SV(xv::sid::kWsAcceptHeader);
    std::string lineEnd = SV(xv::sid::kWsLineEnd);
    cleanup.Add(statusMarker);
    cleanup.Add(acceptHeader);
    cleanup.Add(lineEnd);
    if (head.find(statusMarker) == std::string::npos) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::size_t acceptPos = head.find(acceptHeader);
    if (acceptPos == std::string::npos) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    std::size_t valueBegin = acceptPos + acceptHeader.size();
    std::size_t valueEnd = head.find(lineEnd, valueBegin);
    std::string acceptValue =
        head.substr(valueBegin, valueEnd == std::string::npos ? std::string::npos : valueEnd - valueBegin);
    TrimWs(acceptValue);
    cleanup.Add(acceptValue);
    if (acceptValue != expectedAccept) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    channel.buffer = response.substr(headerEnd + headerTerminator.size());

    unsigned char serverPk[crypto_kx_PUBLICKEYBYTES];
    if (!DomainKey(xv::kid::kServerKxPublic, serverPk)) {
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        sodium_memzero(clientSk, sizeof(clientSk));
        return false;
    }
    unsigned char rx[crypto_kx_SESSIONKEYBYTES];
    unsigned char tx[crypto_kx_SESSIONKEYBYTES];
    if (crypto_kx_client_session_keys(rx, tx, clientPk, clientSk, serverPk) != 0) {
        sodium_memzero(clientSk, sizeof(clientSk));
        sodium_memzero(serverPk, sizeof(serverPk));
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        return false;
    }
    sodium_memzero(clientSk, sizeof(clientSk));
    sodium_memzero(serverPk, sizeof(serverPk));

    bool haveHeader = false;
    std::uint64_t streamDeadline = Now() + PV(xv::pid::kHttpTimeoutSeconds);
    while (Now() < streamDeadline && !g_presenceStop.load(std::memory_order_acquire)) {
        std::size_t pos = 0;
        while (pos + 2 <= channel.buffer.size()) {
            const unsigned char b0 = static_cast<unsigned char>(channel.buffer[pos]);
            const unsigned char b1 = static_cast<unsigned char>(channel.buffer[pos + 1]);
            const int opcode = b0 & 0x0F;
            const bool masked = (b1 & 0x80) != 0;
            std::uint64_t length = b1 & 0x7F;
            std::size_t header = 2;
            if (length == 126) {
                if (pos + 4 > channel.buffer.size()) break;
                length = (static_cast<std::uint64_t>(static_cast<unsigned char>(channel.buffer[pos + 2])) << 8) |
                         static_cast<unsigned char>(channel.buffer[pos + 3]);
                header = 4;
            } else if (length == 127) {
                if (pos + 10 > channel.buffer.size()) break;
                length = 0;
                for (int i = 0; i < 8; ++i) {
                    length = (length << 8) |
                             static_cast<unsigned char>(channel.buffer[pos + 2 + i]);
                }
                header = 10;
            }
            if (masked) header += 4;
            if (pos + header + length > channel.buffer.size()) break;
            std::string payload = channel.buffer.substr(pos + header, static_cast<std::size_t>(length));
            pos += header + static_cast<std::size_t>(length);
            if (opcode == 8) {
                CleanseString(payload);
                channel.buffer.erase(0, pos);
                curl_easy_cleanup(channel.curl);
                channel.curl = nullptr;
                return false;
            }
            if (opcode != 2) {
                CleanseString(payload);
                continue;
            }
            if (payload.size() != crypto_secretstream_xchacha20poly1305_HEADERBYTES) {
                CleanseString(payload);
                channel.buffer.erase(0, pos);
                curl_easy_cleanup(channel.curl);
                channel.curl = nullptr;
                return false;
            }
            if (crypto_secretstream_xchacha20poly1305_init_pull(
                    &channel.pull,
                    reinterpret_cast<const unsigned char*>(payload.data()), rx) != 0) {
                CleanseString(payload);
                sodium_memzero(rx, sizeof(rx));
                sodium_memzero(tx, sizeof(tx));
                channel.buffer.erase(0, pos);
                curl_easy_cleanup(channel.curl);
                channel.curl = nullptr;
                return false;
            }
            CleanseString(payload);
            haveHeader = true;
            break;
        }
        channel.buffer.erase(0, pos);
        if (haveHeader) break;
        int rc = WsRecvSome(channel.curl, channel.buffer);
        if (rc < 0) {
            sodium_memzero(rx, sizeof(rx));
            sodium_memzero(tx, sizeof(tx));
            curl_easy_cleanup(channel.curl);
            channel.curl = nullptr;
            return false;
        }
        if (rc == 0) WsWaitReadable(channel.fd, 200);
    }

    sodium_memzero(rx, sizeof(rx));
    if (!haveHeader) {
        sodium_memzero(tx, sizeof(tx));
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        return false;
    }

    unsigned char pushHeader[crypto_secretstream_xchacha20poly1305_HEADERBYTES];
    if (crypto_secretstream_xchacha20poly1305_init_push(&channel.push, pushHeader, tx) != 0) {
        sodium_memzero(tx, sizeof(tx));
        sodium_memzero(pushHeader, sizeof(pushHeader));
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        return false;
    }
    sodium_memzero(tx, sizeof(tx));
    if (!WsSendFrame(channel.curl, 2, std::string(reinterpret_cast<const char*>(pushHeader),
                                                 sizeof(pushHeader)))) {
        sodium_memzero(pushHeader, sizeof(pushHeader));
        curl_easy_cleanup(channel.curl);
        channel.curl = nullptr;
        return false;
    }
    sodium_memzero(pushHeader, sizeof(pushHeader));

    channel.lastRekey = Now();
    channel.sent = 0;
    std::string hello = SV(xv::sid::kWsHello) + session + SV(xv::sid::kColon) + stamp;
    cleanup.Add(hello);
    if (!StreamPush(channel, hello, crypto_secretstream_xchacha20poly1305_TAG_MESSAGE)) return false;

    std::string localHash = LocalNameHash();
    cleanup.Add(localHash);
    if (!localHash.empty()) {
        std::string update = SV(xv::sid::kWsHashUpdate) + localHash;
        cleanup.Add(update);
        if (!StreamPush(channel, update, crypto_secretstream_xchacha20poly1305_TAG_MESSAGE)) return false;
    }
    return true;
}

void WsSession(WsChannel& channel) {
    std::string sentHash = LocalNameHash();
    std::uint64_t lastKeepalive = Now();
    std::uint64_t lastHeartbeat = lastKeepalive;
    std::uint64_t lastActivity = lastKeepalive;
    std::uint64_t nextRevalidate = lastKeepalive + PV(xv::pid::kPresenceRevalidateSeconds);
    std::string heartbeat = SV(xv::sid::kWsHeartbeat);

    for (;;) {
        if (g_presenceStop.load(std::memory_order_acquire)) {
            WsSendFrame(channel.curl, 8, std::string("\x03\xe8", 2));
            CleanseString(heartbeat);
            return;
        }
        std::string currentHash = LocalNameHash();
        if (currentHash != sentHash) {
            std::string update = SV(xv::sid::kWsHashUpdate) + currentHash;
            bool ok = StreamPush(channel, update, crypto_secretstream_xchacha20poly1305_TAG_MESSAGE);
            CleanseString(update);
            if (!ok) {
                CleanseString(currentHash);
                CleanseString(heartbeat);
                return;
            }
            sentHash = currentHash;
        }
        CleanseString(currentHash);

        std::uint64_t now = Now();
        if (now - lastKeepalive >= PV(xv::pid::kPresenceKeepaliveSeconds)) {
            if (!WsSendFrame(channel.curl, 9, std::string())) {
                CleanseString(heartbeat);
                return;
            }
            lastKeepalive = now;
        }
        if (now - lastHeartbeat >= PV(xv::pid::kPresenceHeartbeatSeconds)) {
            if (!StreamPush(channel, heartbeat, crypto_secretstream_xchacha20poly1305_TAG_MESSAGE)) {
                CleanseString(heartbeat);
                return;
            }
            lastHeartbeat = now;
        }
        if (channel.sent >= PV(xv::pid::kRekeyMessages) ||
            now - channel.lastRekey >= PV(xv::pid::kRekeySeconds)) {
            if (!StreamPush(channel, std::string(), crypto_secretstream_xchacha20poly1305_TAG_REKEY)) {
                CleanseString(heartbeat);
                return;
            }
            channel.sent = 0;
            channel.lastRekey = now;
        }
        if (now >= nextRevalidate) {
            if (!IntegrityRevalidate(DomainPresence)) {
                CleanseString(heartbeat);
                return;
            }
            nextRevalidate = now + PV(xv::pid::kPresenceRevalidateSeconds);
        }
        if (now - lastActivity > PV(xv::pid::kPresenceIdleSeconds)) {
            CleanseString(heartbeat);
            return;
        }

        bool gotAny = false;
        int rc = WsRecvSome(channel.curl, channel.buffer);
        if (rc < 0) {
            CleanseString(heartbeat);
            return;
        }
        if (rc == 0) {
            WsWaitReadable(channel.fd, 250);
            rc = WsRecvSome(channel.curl, channel.buffer);
            if (rc < 0) {
                CleanseString(heartbeat);
                return;
            }
        }
        if (!channel.buffer.empty()) {
            if (WsParseFrames(channel, gotAny) < 0) {
                CleanseString(heartbeat);
                return;
            }
        }
        if (gotAny) lastActivity = Now();
        if (!FlowGate(DomainPresence)) {
            CleanseString(heartbeat);
            return;
        }
    }
}

void PresenceThread(DeviceKeys device, std::string tokenHex) {
    SensitiveCleanup cleanup;
    cleanup.Add(tokenHex);
    int failures = 0;
    int backoffMs = static_cast<int>(PV(xv::pid::kPresenceReconnectMs));
    int backoffMax = static_cast<int>(PV(xv::pid::kPresenceBackoffMaxMs));

    while (!g_presenceStop.load(std::memory_order_acquire)) {
        if (g_state.load(std::memory_order_acquire) != AUTH_OK) {
            usleep(500000);
            continue;
        }
        WsChannel channel;
        bool connected = WsConnect(channel, device, tokenHex);
        if (!connected) {
            channel.Wipe();
            if (channel.curl) {
                curl_easy_cleanup(channel.curl);
                channel.curl = nullptr;
            }
            ++failures;
            if (failures >= 3) {
                g_onlineCount.store(-1, std::memory_order_release);
                std::lock_guard<std::mutex> lock(g_presenceMutex);
                g_presencePeerHashes.clear();
            }
            int waited = 0;
            while (waited < backoffMs && !g_presenceStop.load(std::memory_order_acquire)) {
                usleep(100000);
                waited += 100;
            }
            backoffMs = std::min(backoffMs * 2, backoffMax);
            continue;
        }
        failures = 0;
        backoffMs = static_cast<int>(PV(xv::pid::kPresenceReconnectMs));
        WsSession(channel);
        channel.Wipe();
        if (channel.curl) {
            curl_easy_cleanup(channel.curl);
            channel.curl = nullptr;
        }
        int waited = 0;
        while (waited < 1000 && !g_presenceStop.load(std::memory_order_acquire)) {
            usleep(100000);
            waited += 100;
        }
    }

    device.Wipe();
    g_presenceRunning.store(false, std::memory_order_release);
}

void PresenceStart(DeviceKeys device, std::string tokenHex) {
    bool expected = false;
    if (!g_presenceRunning.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return;
    g_presenceStop.store(false, std::memory_order_release);
    std::thread(PresenceThread, std::move(device), std::move(tokenHex)).detach();
}

void CheckThread(std::string license, DeviceKeys device, std::uint64_t attempt) {
    SensitiveCleanup cleanup;
    cleanup.Add(license);
    ClearRva();

    bool networkFailure = false;
    GrantResult grant;
    bool granted = !license.empty() && RequestGrant(license, device, grant, networkFailure);
    if (attempt != g_attempt.load(std::memory_order_acquire)) {
        device.Wipe();
        CleanseString(grant.token);
        return;
    }

    if (granted && StoreRva(grant.rva, grant.seal)) {
        if (grant.rvaBeta != 0 && grant.sealBeta != 0) StoreRvaBeta(grant.rvaBeta, grant.sealBeta);
        SaveLicense(license);
        StoreLicenseVersion(license);
        {
            std::lock_guard<std::mutex> lock(g_mtx);
            g_savedKey = license;
            g_deviceId = BytesToHex(device.pk.data(), device.pk.size());
        }
        g_state.store(AUTH_OK, std::memory_order_release);
        PresenceStart(std::move(device), std::move(grant.token));
        CleanseString(license);
        return;
    }

    device.Wipe();
    CleanseString(grant.token);
    ClearRva();
    if (!networkFailure) ForgetFiles();
    g_state.store(networkFailure ? AUTH_NET_ERROR : AUTH_FAIL, std::memory_order_release);
}

void AuthThread(std::string license, std::uint64_t attempt, bool prefill) {
    SensitiveCleanup cleanup;
    cleanup.Add(license);

    if (!VerifyLicenseVersion(license)) {
        ForgetFiles();
        if (prefill) return;
    }

    DeviceKeys device;
    if (!LoadDevice(license, device)) {
        device.Wipe();
        if (!CreateDevice(license, device)) {
            device.Wipe();
            ClearRva();
            if (attempt == g_attempt.load(std::memory_order_acquire)) {
                g_state.store(AUTH_FAIL, std::memory_order_release);
            }
            return;
        }
    }

    if (attempt != g_attempt.load(std::memory_order_acquire)) {
        device.Wipe();
        return;
    }

    if (prefill) {
        std::lock_guard<std::mutex> lock(g_mtx);
        g_deviceId = BytesToHex(device.pk.data(), device.pk.size());
    }

    CheckThread(license, std::move(device), attempt);
}

}  // namespace

void AuthInit() {
    static bool initialized = false;
    if (!initialized) {
        sodium_init();
        curl_global_init(CURL_GLOBAL_ALL);
        std::signal(SIGPIPE, SIG_IGN);
        initialized = true;
    }
    if (!xv::Init() || !IntegrityVerifyInitial()) {
        g_state.store(AUTH_FAIL, std::memory_order_release);
        return;
    }
    StateInit();

    std::string license = LoadLicense();
    if (license.empty()) {
        CleanseString(license);
        return;
    }

    {
        std::lock_guard<std::mutex> lock(g_mtx);
        g_savedKey = license;
    }
    std::uint64_t attempt = g_attempt.fetch_add(1, std::memory_order_acq_rel) + 1;
    std::thread(AuthThread, license, attempt, true).detach();
    CleanseString(license);
}

void AuthCheck(const std::string& key) {
    std::string license = key;
    TrimWs(license);
    if (license.empty() || license.size() > 4096 || !xv::Ready()) {
        CleanseString(license);
        ClearRva();
        g_state.store(AUTH_FAIL, std::memory_order_release);
        return;
    }

    std::uint64_t attempt = g_attempt.fetch_add(1, std::memory_order_acq_rel) + 1;
    ClearRva();
    g_state.store(AUTH_CHECKING, std::memory_order_release);
    std::thread(AuthThread, license, attempt, false).detach();
    CleanseString(license);
}

AuthState AuthGetState() {
    if (g_state.load(std::memory_order_acquire) == AUTH_OK && AuthGetPlayerManagerRva() == 0) {
        return AUTH_FAIL;
    }
    return static_cast<AuthState>(g_state.load(std::memory_order_acquire));
}

std::string AuthGetSavedKey() {
    std::lock_guard<std::mutex> lock(g_mtx);
    return g_savedKey;
}

std::string AuthGetDeviceId() {
    std::lock_guard<std::mutex> lock(g_mtx);
    return g_deviceId;
}

std::uint64_t AuthGetTokenExpires() {
    return g_tokenExpires.load(std::memory_order_acquire);
}

std::uint64_t AuthGetPlayerManagerRva() {
    std::lock_guard<std::mutex> lock(g_sessionMutex);
    std::uint64_t integrity = IntegrityToken();
    std::uint64_t mask = g_rvaMask.load(std::memory_order_acquire);
    std::uint64_t encoded = g_rvaEncoded.load(std::memory_order_acquire);
    std::uint64_t sessionEncoded = g_sessionEncoded.load(std::memory_order_acquire);
    std::uint64_t storedCheck = g_sessionCheck.load(std::memory_order_acquire);
    if (integrity == 0 || mask == 0 || encoded == 0 || sessionEncoded == 0 || storedCheck == 0 ||
        !IntegrityCheckpoint(DomainRva ^ encoded ^ sessionEncoded)) {
        return 0;
    }
    std::uint64_t value = encoded ^ mask;
    std::uint64_t seal = sessionEncoded ^ SessionMixValue(mask ^ integrity);
    std::uint64_t expected = SessionMixValue(value ^ seal ^ mask ^ integrity ^ xv::BuildId());
    if (value == 0 || value > PV(xv::pid::kRvaMax) || seal == 0 || expected != storedCheck) return 0;

    std::uint64_t count = g_remaskCounter.fetch_add(1, std::memory_order_relaxed) + 1;
    if ((count & 255ULL) == 0) {
        std::uint64_t nextMask = 0;
        randombytes_buf(&nextMask, sizeof(nextMask));
        if (nextMask != 0) {
            g_rvaMask.store(nextMask, std::memory_order_release);
            g_rvaEncoded.store(value ^ nextMask, std::memory_order_release);
            g_sessionEncoded.store(seal ^ SessionMixValue(nextMask ^ integrity),
                                   std::memory_order_release);
            g_sessionCheck.store(SessionMixValue(value ^ seal ^ nextMask ^ integrity ^ xv::BuildId()),
                                 std::memory_order_release);
        }
    }
    return value;
}

std::uint64_t AuthGetPlayerManagerRvaBeta() {
    std::lock_guard<std::mutex> lock(g_sessionMutex);
    std::uint64_t integrity = IntegrityToken();
    std::uint64_t mask = g_rvaBetaMask.load(std::memory_order_acquire);
    std::uint64_t encoded = g_rvaBetaEncoded.load(std::memory_order_acquire);
    std::uint64_t sessionEncoded = g_rvaBetaSessionEncoded.load(std::memory_order_acquire);
    std::uint64_t storedCheck = g_rvaBetaSessionCheck.load(std::memory_order_acquire);
    if (integrity == 0 || mask == 0 || encoded == 0 || sessionEncoded == 0 || storedCheck == 0 ||
        !IntegrityCheckpoint(DomainRva ^ encoded ^ sessionEncoded)) {
        return 0;
    }
    std::uint64_t value = encoded ^ mask;
    std::uint64_t seal = sessionEncoded ^ SessionMixValue(mask ^ integrity);
    std::uint64_t expected = SessionMixValue(value ^ seal ^ mask ^ integrity ^ xv::BuildId());
    if (value == 0 || value > PV(xv::pid::kRvaMax) || seal == 0 || expected != storedCheck) return 0;

    std::uint64_t count = g_rvaBetaRemaskCounter.fetch_add(1, std::memory_order_relaxed) + 1;
    if ((count & 255ULL) == 0) {
        std::uint64_t nextMask = 0;
        randombytes_buf(&nextMask, sizeof(nextMask));
        if (nextMask != 0) {
            g_rvaBetaMask.store(nextMask, std::memory_order_release);
            g_rvaBetaEncoded.store(value ^ nextMask, std::memory_order_release);
            g_rvaBetaSessionEncoded.store(seal ^ SessionMixValue(nextMask ^ integrity),
                                          std::memory_order_release);
            g_rvaBetaSessionCheck.store(SessionMixValue(value ^ seal ^ nextMask ^ integrity ^ xv::BuildId()),
                                        std::memory_order_release);
        }
    }
    return value;
}

int AuthGetOnlineCount() {
    return g_onlineCount.load(std::memory_order_acquire);
}

void AuthPresenceStop() {
    if (!g_presenceRunning.load(std::memory_order_acquire)) return;
    g_presenceStop.store(true, std::memory_order_release);
    for (int i = 0; i < 15 && g_presenceRunning.load(std::memory_order_acquire); ++i) usleep(100000);
    g_onlineCount.store(-1, std::memory_order_release);
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    g_presencePeerHashes.clear();
}

void AuthPresenceSetLocalName(const std::string& name) {
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    if (name == g_presenceLocalName) return;
    g_presenceLocalName = name;
    g_presenceLocalHash = NameHashHex(name);
}

std::vector<std::uint64_t> AuthPresenceGetPeerHashes() {
    std::lock_guard<std::mutex> lock(g_presenceMutex);
    return g_presencePeerHashes;
}

std::uint64_t AuthPresenceNameHash(const std::string& name) {
    return HexToU64(NameHashHex(name));
}
