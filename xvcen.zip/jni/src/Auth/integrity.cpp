#include "integrity.h"
#include "xvseal.h"

XV_GUARD(bool IntegrityVerifyInitial()) {
    return xv::Init();
}

XV_GUARD(std::uint64_t IntegrityToken()) {
    return xv::Token();
}

XV_GUARD(bool IntegrityCheckpoint(std::uint64_t domain)) {
    return xv::Checkpoint(domain);
}

XV_GUARD(bool IntegrityRevalidate(std::uint64_t domain)) {
    return xv::Revalidate(domain);
}

XV_GUARD(bool IntegrityRevalidateRegion(std::uint32_t region)) {
    return xv::RevalidateRegion(region);
}
