#include "statefile.h"

#include <cstdio>
#include <cstring>
#include <mutex>
#include <sys/stat.h>
#include <sys/types.h>

namespace xvstate {
namespace {

constexpr std::uint32_t kMagic = 0x54535658u;
constexpr std::uint32_t kVersion = 1u;
constexpr std::size_t kHeaderBytes = 12;
constexpr std::size_t kRecordHeaderBytes = 8;
constexpr std::size_t kMaxRecordBytes = 1u << 20;
constexpr std::size_t kMaxRecords = 32;
constexpr std::size_t kMaxFileBytes = 8u << 20;

struct Entry {
    std::uint32_t id;
    std::size_t off;
    std::size_t len;
};

std::mutex g_lock;
std::string g_path;

void Wipe(std::vector<unsigned char>& data) {
    volatile unsigned char* cursor = data.data();
    for (std::size_t index = 0; index < data.size(); ++index) cursor[index] = 0;
    data.clear();
    data.shrink_to_fit();
}

void Put32(std::vector<unsigned char>& out, std::uint32_t value) {
    out.push_back(static_cast<unsigned char>(value & 0xffu));
    out.push_back(static_cast<unsigned char>((value >> 8) & 0xffu));
    out.push_back(static_cast<unsigned char>((value >> 16) & 0xffu));
    out.push_back(static_cast<unsigned char>((value >> 24) & 0xffu));
}

std::uint32_t Get32(const unsigned char* data) {
    return static_cast<std::uint32_t>(data[0]) | (static_cast<std::uint32_t>(data[1]) << 8) |
           (static_cast<std::uint32_t>(data[2]) << 16) | (static_cast<std::uint32_t>(data[3]) << 24);
}

bool Parse(const std::vector<unsigned char>& blob, std::vector<Entry>& entries) {
    entries.clear();
    if (blob.size() < kHeaderBytes) return false;
    if (Get32(blob.data()) != kMagic) return false;
    if (Get32(blob.data() + 4) != kVersion) return false;
    const std::uint32_t count = Get32(blob.data() + 8);
    if (count == 0 || count > kMaxRecords) return false;
    std::size_t pos = kHeaderBytes;
    for (std::uint32_t index = 0; index < count; ++index) {
        if (pos + kRecordHeaderBytes > blob.size()) return false;
        Entry entry;
        entry.id = Get32(blob.data() + pos);
        const std::uint32_t len = Get32(blob.data() + pos + 4);
        pos += kRecordHeaderBytes;
        if (entry.id == 0 || len > kMaxRecordBytes || pos + len > blob.size()) return false;
        entry.off = pos;
        entry.len = len;
        entries.push_back(entry);
        pos += len;
    }
    return pos == blob.size();
}

bool LoadLocked(std::vector<unsigned char>& blob, std::vector<Entry>& entries) {
    blob.clear();
    if (g_path.empty()) return false;
    std::FILE* file = std::fopen(g_path.c_str(), "rb");
    if (!file) return false;
    unsigned char buffer[4096];
    std::size_t read = 0;
    while ((read = std::fread(buffer, 1, sizeof(buffer), file)) > 0 && blob.size() < kMaxFileBytes) {
        blob.insert(blob.end(), buffer, buffer + read);
    }
    std::fclose(file);
    if (blob.empty()) return false;
    return Parse(blob, entries);
}

bool StoreLocked(const std::vector<std::pair<std::uint32_t, std::vector<unsigned char>>>& records) {
    if (g_path.empty() || records.size() > kMaxRecords) return false;
    std::vector<unsigned char> blob;
    Put32(blob, kMagic);
    Put32(blob, kVersion);
    Put32(blob, static_cast<std::uint32_t>(records.size()));
    for (const auto& record : records) {
        Put32(blob, record.first);
        Put32(blob, static_cast<std::uint32_t>(record.second.size()));
        blob.insert(blob.end(), record.second.begin(), record.second.end());
    }
    std::string tmp = g_path;
    tmp.push_back(static_cast<char>(0x7e));
    std::FILE* file = std::fopen(tmp.c_str(), "wb");
    if (!file) {
        Wipe(blob);
        return false;
    }
    const std::size_t total = blob.size();
    const std::size_t written = std::fwrite(blob.data(), 1, total, file);
    std::fflush(file);
    std::fclose(file);
    Wipe(blob);
    if (written != total) {
        std::remove(tmp.c_str());
        return false;
    }
    if (std::rename(tmp.c_str(), g_path.c_str()) != 0) {
        std::remove(tmp.c_str());
        return false;
    }
    chmod(g_path.c_str(), 0600);
    return true;
}

bool RewriteLocked(std::uint32_t dropId, std::uint32_t addId, const unsigned char* data, std::size_t len) {
    std::vector<unsigned char> blob;
    std::vector<Entry> entries;
    std::vector<std::pair<std::uint32_t, std::vector<unsigned char>>> records;
    const bool have = LoadLocked(blob, entries);
    if (have) {
        for (const Entry& entry : entries) {
            if (entry.id == dropId || entry.id == addId) continue;
            records.emplace_back(entry.id,
                                 std::vector<unsigned char>(blob.begin() + entry.off,
                                                            blob.begin() + entry.off + entry.len));
        }
    }
    Wipe(blob);
    if (addId != 0) {
        if (records.size() + 1 > kMaxRecords) return false;
        records.emplace_back(addId, std::vector<unsigned char>(data, data + len));
    }
    const bool ok = StoreLocked(records);
    for (auto& record : records) Wipe(record.second);
    return ok;
}

}

void Init(const std::string& path) {
    std::lock_guard<std::mutex> guard(g_lock);
    if (!g_path.empty() && g_path == path) return;
    g_path = path;
    if (g_path.empty()) return;
    const std::size_t slash = g_path.find_last_of(static_cast<char>(0x2f));
    if (slash != std::string::npos && slash > 0) {
        const std::string dir = g_path.substr(0, slash);
        mkdir(dir.c_str(), 0777);
    }
}

bool Ready() {
    std::lock_guard<std::mutex> guard(g_lock);
    return !g_path.empty();
}

bool Read(unsigned id, std::vector<unsigned char>& out) {
    std::lock_guard<std::mutex> guard(g_lock);
    out.clear();
    if (id == 0 || g_path.empty()) return false;
    std::vector<unsigned char> blob;
    std::vector<Entry> entries;
    if (!LoadLocked(blob, entries)) {
        Wipe(blob);
        return false;
    }
    bool found = false;
    for (const Entry& entry : entries) {
        if (entry.id != id) continue;
        out.assign(blob.begin() + entry.off, blob.begin() + entry.off + entry.len);
        found = true;
        break;
    }
    Wipe(blob);
    return found;
}

bool Write(unsigned id, const unsigned char* data, std::size_t len) {
    if (id == 0 || (data == nullptr && len != 0) || len > kMaxRecordBytes) return false;
    std::lock_guard<std::mutex> guard(g_lock);
    return RewriteLocked(id, id, data, len);
}

bool Erase(unsigned id) {
    if (id == 0) return false;
    std::lock_guard<std::mutex> guard(g_lock);
    return RewriteLocked(id, 0, nullptr, 0);
}

void EraseAuth() {
    std::lock_guard<std::mutex> guard(g_lock);
    std::vector<unsigned char> blob;
    std::vector<Entry> entries;
    std::vector<std::pair<std::uint32_t, std::vector<unsigned char>>> records;
    if (LoadLocked(blob, entries)) {
        for (const Entry& entry : entries) {
            if (entry.id == kAuthKey || entry.id == kDevice || entry.id == kLicVer ||
                entry.id == kSession) {
                continue;
            }
            records.emplace_back(entry.id,
                                 std::vector<unsigned char>(blob.begin() + entry.off,
                                                            blob.begin() + entry.off + entry.len));
        }
    }
    Wipe(blob);
    if (records.empty()) {
        if (!g_path.empty()) std::remove(g_path.c_str());
        return;
    }
    StoreLocked(records);
    for (auto& record : records) Wipe(record.second);
}

}
