#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace xvstate {

enum Record : unsigned {
    kAuthKey = 1,
    kDevice = 2,
    kLicVer = 3,
    kSession = 4,
    kLastCfg = 5
};

void Init(const std::string& path);
bool Ready();
bool Read(unsigned id, std::vector<unsigned char>& out);
bool Write(unsigned id, const unsigned char* data, std::size_t len);
bool Erase(unsigned id);
void EraseAuth();

}
