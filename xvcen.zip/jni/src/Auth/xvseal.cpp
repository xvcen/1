#include "xvseal.h"
#include "xvbuild.h"

#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include <link.h>
#include <unistd.h>

extern "C" {
__attribute__((used, aligned(64))) unsigned char xv_seal_slot[XV_SEAL_SLOT_SIZE] = XV_SEAL_MAGIC_INIT;
}

namespace {

struct RegionEntry {
    std::uint32_t ct_len;
    std::uint32_t rx_off;
    std::uint32_t rx_len;
    std::uint32_t data_off;
    unsigned char nonce[crypto_aead_xchacha20poly1305_ietf_NPUBBYTES];
};

struct WindowEntry {
    std::uint32_t rx_off;
    std::uint32_t rx_len;
    unsigned char nonce[crypto_aead_xchacha20poly1305_ietf_NPUBBYTES];
    unsigned char ct[XV_SEAL_WINDOW_CT_BYTES];
};

struct SlotHeader {
    std::uint32_t magic;
    std::uint32_t version;
    std::uint32_t build_id;
    std::uint32_t rx_len;
    std::uint32_t region_count;
    std::uint32_t window_count;
    std::uint32_t window_bytes;
    std::uint32_t total_len;
};

std::mutex g_lock;
std::once_flag g_once;
std::atomic<bool> g_ready{false};
std::uint32_t g_buildId = 0;
std::uint64_t g_token = 0;

unsigned char* g_master = nullptr;
unsigned char* g_pad = nullptr;
std::uint64_t g_tableMask = 0;

std::uint64_t* g_offsets = nullptr;
std::size_t g_offsetCount = 0;
std::uint64_t* g_policy = nullptr;
std::size_t g_policyCount = 0;

std::uint64_t* g_strIndex = nullptr;
unsigned char* g_strData = nullptr;
std::size_t g_strCount = 0;
std::size_t g_strBytes = 0;

std::uint64_t* g_keyIndex = nullptr;
unsigned char* g_keyData = nullptr;
std::size_t g_keyCount = 0;
std::size_t g_keyBytes = 0;

unsigned char* g_windowItems = nullptr;
unsigned char* g_regionDigests = nullptr;

SlotHeader g_header{};
RegionEntry g_regions[XV_SEAL_REGIONS]{};
WindowEntry g_windows[XV_SEAL_WINDOWS]{};

std::uintptr_t g_rxBase = 0;
std::size_t g_rxLen = 0;

void RebuildMaster(unsigned char out[32]) {
    static const unsigned char seedA[16] = XV_SEED_A_INIT;
    static const unsigned char seedB[16] = XV_SEED_B_INIT;
    static const unsigned char seedC[16] = XV_SEED_C_INIT;
    volatile std::uint64_t mix = XV_SEED_MIX;
    for (std::size_t i = 0; i < 32; ++i) {
        unsigned char part = static_cast<unsigned char>((static_cast<std::uint64_t>(mix) >> ((i & 7U) * 8U)) & 0xffU);
        out[i] = static_cast<unsigned char>(
            seedA[i & 15U] ^ seedB[(i * 5U + 3U) & 15U] ^ seedC[(i * 7U + 11U) & 15U] ^
            part ^ static_cast<unsigned char>(i * 0x9eU + 0x3bU));
    }
}

int SegmentProbe(struct dl_phdr_info* info, size_t, void* data) {
    std::uintptr_t* out = static_cast<std::uintptr_t*>(data);
    std::uintptr_t probe = reinterpret_cast<std::uintptr_t>(&RebuildMaster);
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        const ElfW(Phdr)* ph = &info->dlpi_phdr[i];
        if (ph->p_type != PT_LOAD) continue;
        std::uintptr_t start = static_cast<std::uintptr_t>(info->dlpi_addr) + static_cast<std::uintptr_t>(ph->p_vaddr);
        if (probe < start || probe >= start + ph->p_memsz) continue;
        for (int j = 0; j < info->dlpi_phnum; ++j) {
            const ElfW(Phdr)* rx = &info->dlpi_phdr[j];
            if (rx->p_type != PT_LOAD) continue;
            if ((rx->p_flags & PF_X) == 0 || (rx->p_flags & PF_W) != 0) continue;
            out[0] = static_cast<std::uintptr_t>(info->dlpi_addr) + static_cast<std::uintptr_t>(rx->p_vaddr);
            out[1] = static_cast<std::uintptr_t>(rx->p_filesz);
            out[2] = 1;
            return 1;
        }
        return 1;
    }
    return 0;
}

void MakeCtx(char* out, std::size_t cap, const char* format, std::uint32_t index) {
    snprintf(out, cap, format, index);
}

bool Derive(unsigned char* out, std::size_t len, std::uint64_t id, const char* ctx, const unsigned char* key) {
    return crypto_kdf_derive_from_key(out, len, id, ctx, key) == 0;
}

bool OpenArena(void* arena) {
    return arena != nullptr && sodium_mprotect_readonly(arena) == 0;
}

void CloseArena(void* arena) {
    if (arena != nullptr) sodium_mprotect_noaccess(arena);
}

bool MasterCopy(unsigned char out[32]) {
    if (g_master == nullptr) return false;
    if (!OpenArena(g_master)) return false;
    memcpy(out, g_master, 32);
    CloseArena(g_master);
    return true;
}

std::size_t MakeAd(char* out, std::size_t cap, const char* kind, std::uint32_t index, std::uint32_t buildId) {
    int written = snprintf(out, cap, "xvcen-v4-seal-%s-%u-%u", kind, index, buildId);
    if (written <= 0 || static_cast<std::size_t>(written) >= cap) return 0;
    return static_cast<std::size_t>(written);
}

bool CodeMac(unsigned char out[32], std::uint32_t rxOff, std::uint32_t rxLen, const unsigned char* macKey) {
    if (rxLen == 0 || static_cast<std::size_t>(rxOff) + rxLen > g_rxLen) return false;
    const unsigned char* begin = reinterpret_cast<const unsigned char*>(g_rxBase) + rxOff;
    return crypto_generichash(out, 32, begin, rxLen, macKey, 32) == 0;
}

std::uint64_t Load64(const unsigned char* ptr) {
    std::uint64_t value = 0;
    memcpy(&value, ptr, sizeof(value));
    return value;
}

std::uint32_t Load32(const unsigned char* ptr) {
    std::uint32_t value = 0;
    memcpy(&value, ptr, sizeof(value));
    return value;
}

unsigned char* MakeArena(std::size_t bytes) {
    if (bytes == 0) bytes = 8;
    unsigned char* arena = static_cast<unsigned char*>(sodium_malloc(bytes));
    if (arena == nullptr) return nullptr;
    sodium_mlock(arena, bytes);
    sodium_memzero(arena, bytes);
    return arena;
}

void DropArena(unsigned char* arena, std::size_t bytes) {
    if (arena == nullptr) return;
    sodium_mprotect_readwrite(arena);
    if (bytes != 0) sodium_memzero(arena, bytes);
    sodium_free(arena);
}

bool ParseValueRegion(const std::vector<unsigned char>& plain, std::uint64_t*& values, std::size_t& count) {
    if (plain.size() < 4) return false;
    std::uint32_t entries = Load32(plain.data());
    if (entries == 0 || plain.size() < 4 + static_cast<std::size_t>(entries) * 8) return false;
    unsigned char* arena = MakeArena(static_cast<std::size_t>(entries) * 8);
    if (arena == nullptr) return false;
    std::uint64_t* table = reinterpret_cast<std::uint64_t*>(arena);
    for (std::uint32_t i = 0; i < entries; ++i) {
        table[i] = Load64(plain.data() + 4 + static_cast<std::size_t>(i) * 8) ^ g_tableMask;
    }
    values = table;
    count = entries;
    return true;
}

bool ParseBlobRegion(std::vector<unsigned char>& plain, std::uint64_t*& index, unsigned char*& data,
                     std::size_t& count, std::size_t& bytes, const unsigned char* padKey,
                     const unsigned char* padNonce, std::uint32_t padBlock) {
    if (plain.size() < 4) return false;
    std::uint32_t entries = Load32(plain.data());
    if (entries == 0) return false;
    std::size_t tableBytes = static_cast<std::size_t>(entries) * 8;
    if (plain.size() < 4 + tableBytes) return false;
    std::size_t dataBytes = 0;
    for (std::uint32_t i = 0; i < entries; ++i) {
        std::uint32_t off = Load32(plain.data() + 4 + static_cast<std::size_t>(i) * 8);
        std::uint32_t len = Load32(plain.data() + 4 + static_cast<std::size_t>(i) * 8 + 4);
        if (off % 64 != 0) return false;
        if (plain.size() < 4 + tableBytes + static_cast<std::size_t>(off) + len) return false;
        if (static_cast<std::size_t>(off) + len > dataBytes) dataBytes = static_cast<std::size_t>(off) + len;
    }
    dataBytes = (dataBytes + 63) & ~static_cast<std::size_t>(63);
    plain.resize(4 + tableBytes + dataBytes, 0);
    unsigned char* indexArena = MakeArena(tableBytes);
    unsigned char* dataArena = MakeArena(dataBytes);
    if (indexArena == nullptr || dataArena == nullptr) {
        DropArena(indexArena, tableBytes);
        DropArena(dataArena, dataBytes);
        return false;
    }
    std::uint64_t* table = reinterpret_cast<std::uint64_t*>(indexArena);
    for (std::uint32_t i = 0; i < entries; ++i) {
        std::uint64_t packed = (static_cast<std::uint64_t>(Load32(plain.data() + 4 + static_cast<std::size_t>(i) * 8 + 4)) << 32) |
                               Load32(plain.data() + 4 + static_cast<std::size_t>(i) * 8);
        table[i] = packed ^ g_tableMask;
    }
    if (crypto_stream_chacha20_ietf_xor_ic(dataArena, plain.data() + 4 + tableBytes, dataBytes,
                                           padNonce, padBlock, padKey) != 0) {
        DropArena(indexArena, tableBytes);
        DropArena(dataArena, dataBytes);
        return false;
    }
    index = table;
    data = dataArena;
    count = entries;
    bytes = dataBytes;
    return true;
}

bool LoadRegion(std::uint32_t region, std::vector<unsigned char>& plain) {
    const RegionEntry& entry = g_regions[region];
    if (entry.ct_len <= crypto_aead_xchacha20poly1305_ietf_ABYTES) return false;
    if (static_cast<std::size_t>(entry.data_off) + entry.ct_len > XV_SEAL_SLOT_SIZE) return false;
    unsigned char master[32];
    unsigned char macKey[32];
    unsigned char codeMac[32];
    unsigned char regionKey[crypto_kdf_KEYBYTES];
    char ctx[12];
    char ad[64];
    if (!MasterCopy(master)) return false;
    MakeCtx(ctx, sizeof(ctx), XV_CTX_MAC, region);
    bool ok = Derive(macKey, sizeof(macKey), 0x10ULL + region, ctx, master);
    if (ok) ok = CodeMac(codeMac, entry.rx_off, entry.rx_len, macKey);
    MakeCtx(ctx, sizeof(ctx), XV_CTX_REGION, region);
    if (ok) ok = Derive(regionKey, sizeof(regionKey), 0x40ULL + region, ctx, codeMac);
    std::size_t adLen = MakeAd(ad, sizeof(ad), "region", region, g_buildId);
    if (ok && adLen == 0) ok = false;
    if (ok) {
        std::vector<unsigned char> buffer(entry.ct_len - crypto_aead_xchacha20poly1305_ietf_ABYTES);
        unsigned long long plainLen = 0;
        int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
            buffer.data(), &plainLen, nullptr,
            xv_seal_slot + entry.data_off, entry.ct_len,
            reinterpret_cast<const unsigned char*>(ad), adLen,
            entry.nonce, regionKey);
        if (rc == 0) {
            buffer.resize(static_cast<std::size_t>(plainLen));
            plain.swap(buffer);
        } else {
            ok = false;
        }
        sodium_memzero(buffer.data(), buffer.size());
    }
    sodium_memzero(regionKey, sizeof(regionKey));
    sodium_memzero(codeMac, sizeof(codeMac));
    sodium_memzero(macKey, sizeof(macKey));
    sodium_memzero(master, sizeof(master));
    sodium_memzero(ad, sizeof(ad));
    return ok;
}

bool LoadWindow(std::uint32_t window, unsigned char out[XV_SEAL_WINDOW_ITEM_BYTES]) {
    const WindowEntry& entry = g_windows[window];
    unsigned char master[32];
    unsigned char macKey[32];
    unsigned char codeMac[32];
    unsigned char itemKey[crypto_kdf_KEYBYTES];
    char ad[64];
    if (!MasterCopy(master)) return false;
    bool ok = Derive(macKey, sizeof(macKey), 0x200ULL + window, XV_CTX_WINDOW_KEY, master);
    if (ok) ok = CodeMac(codeMac, entry.rx_off, entry.rx_len, macKey);
    if (ok) ok = Derive(itemKey, sizeof(itemKey), 0x60ULL + window, XV_CTX_WINDOW_ITEM, codeMac);
    std::size_t adLen = MakeAd(ad, sizeof(ad), "window", window, g_buildId);
    if (ok && adLen == 0) ok = false;
    if (ok) {
        unsigned long long plainLen = 0;
        int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
            out, &plainLen, nullptr, entry.ct, sizeof(entry.ct),
            reinterpret_cast<const unsigned char*>(ad), adLen,
            entry.nonce, itemKey);
        ok = rc == 0 && plainLen == XV_SEAL_WINDOW_ITEM_BYTES;
    }
    sodium_memzero(itemKey, sizeof(itemKey));
    sodium_memzero(codeMac, sizeof(codeMac));
    sodium_memzero(macKey, sizeof(macKey));
    sodium_memzero(master, sizeof(master));
    sodium_memzero(ad, sizeof(ad));
    return ok;
}

bool ReadSlot() {
    memcpy(&g_header, xv_seal_slot, sizeof(g_header));
    for (std::uint32_t i = 0; i < XV_SEAL_REGIONS; ++i) {
        memcpy(&g_regions[i], xv_seal_slot + XV_SEAL_REGION_TABLE_OFF + i * XV_SEAL_REGION_ENTRY_BYTES, sizeof(RegionEntry));
    }
    for (std::uint32_t i = 0; i < XV_SEAL_WINDOWS; ++i) {
        memcpy(&g_windows[i], xv_seal_slot + XV_SEAL_WINDOW_TABLE_OFF + i * XV_SEAL_WINDOW_ENTRY_BYTES, sizeof(WindowEntry));
    }
    if (g_header.magic != XV_SEAL_MAGIC) return false;
    if (g_header.version != XV_SEAL_VERSION) return false;
    if (g_header.region_count != XV_SEAL_REGIONS) return false;
    if (g_header.window_count != XV_SEAL_WINDOWS) return false;
    if (g_header.window_bytes != XV_SEAL_WINDOW_BYTES) return false;
    if (g_header.total_len > XV_SEAL_SLOT_SIZE || g_header.total_len <= XV_SEAL_DATA_OFF) return false;
    if (g_header.rx_len == 0 || g_header.rx_len != g_rxLen) return false;
    g_buildId = g_header.build_id;
    for (std::uint32_t i = 0; i < XV_SEAL_REGIONS; ++i) {
        const RegionEntry& entry = g_regions[i];
        if (entry.rx_len == 0 || entry.rx_len > g_header.rx_len) return false;
        if (entry.rx_off > g_header.rx_len - entry.rx_len) return false;
        if (entry.data_off < XV_SEAL_DATA_OFF || entry.data_off + entry.ct_len > g_header.total_len) return false;
    }
    for (std::uint32_t i = 0; i < XV_SEAL_WINDOWS; ++i) {
        const WindowEntry& entry = g_windows[i];
        if (entry.rx_len == 0 || entry.rx_len > g_header.rx_len) return false;
        if (entry.rx_off > g_header.rx_len - entry.rx_len) return false;
    }
    return true;
}

void WipeLocked() {
    DropArena(reinterpret_cast<unsigned char*>(g_offsets), g_offsetCount * 8);
    DropArena(reinterpret_cast<unsigned char*>(g_policy), g_policyCount * 8);
    DropArena(reinterpret_cast<unsigned char*>(g_strIndex), g_strCount * 8);
    DropArena(g_strData, g_strBytes);
    DropArena(reinterpret_cast<unsigned char*>(g_keyIndex), g_keyCount * 8);
    DropArena(g_keyData, g_keyBytes);
    DropArena(g_windowItems, XV_SEAL_WINDOWS * XV_SEAL_WINDOW_ITEM_BYTES);
    DropArena(g_regionDigests, XV_SEAL_REGIONS * 32);
    DropArena(g_pad, 64);
    g_offsets = nullptr;
    g_policy = nullptr;
    g_strIndex = nullptr;
    g_strData = nullptr;
    g_keyIndex = nullptr;
    g_keyData = nullptr;
    g_windowItems = nullptr;
    g_regionDigests = nullptr;
    g_pad = nullptr;
    g_offsetCount = 0;
    g_policyCount = 0;
    g_strCount = 0;
    g_strBytes = 0;
    g_keyCount = 0;
    g_keyBytes = 0;
    g_tableMask = 0;
    g_token = 0;
    g_ready.store(false, std::memory_order_release);
}

bool InitLocked() {
    if (sodium_init() < 0) return false;
    std::uintptr_t segment[3] = {0, 0, 0};
    dl_iterate_phdr(SegmentProbe, segment);
    if (segment[2] == 0 || segment[0] == 0 || segment[1] == 0) return false;
    g_rxBase = segment[0];
    g_rxLen = segment[1];

    g_master = MakeArena(32);
    if (g_master == nullptr) return false;
    RebuildMaster(g_master);
    if (!ReadSlot()) return false;

    unsigned char items[XV_SEAL_WINDOWS * XV_SEAL_WINDOW_ITEM_BYTES];
    sodium_memzero(items, sizeof(items));
    for (std::uint32_t window = 0; window < XV_SEAL_WINDOWS; ++window) {
        if (!LoadWindow(window, items + window * XV_SEAL_WINDOW_ITEM_BYTES)) return false;
    }

    g_windowItems = MakeArena(sizeof(items));
    if (g_windowItems == nullptr) return false;
    memcpy(g_windowItems, items, sizeof(items));

    unsigned char master[32];
    if (!MasterCopy(master)) return false;
    unsigned char maskKey[32];
    if (!Derive(maskKey, sizeof(maskKey), 0x300ULL, XV_CTX_MASK, master)) return false;
    unsigned char mask[32];
    if (crypto_generichash(mask, sizeof(mask), items, sizeof(items), maskKey, sizeof(maskKey)) != 0) return false;
    sodium_memzero(items, sizeof(items));
    sodium_memzero(master, sizeof(master));

    g_tableMask = Load64(mask);
    if (g_tableMask == 0) g_tableMask = 0xa5a5a5a55a5a5a5aULL;

    g_pad = MakeArena(64);
    if (g_pad == nullptr) return false;
    if (crypto_generichash(g_pad, 32, reinterpret_cast<const unsigned char*>("xvcen-v4-pad"), 12, mask, sizeof(mask)) != 0) return false;
    if (crypto_generichash(g_pad + 32, 12, reinterpret_cast<const unsigned char*>("xvcen-v4-nonce"), 14, mask, sizeof(mask)) != 0) return false;
    if (crypto_generichash(g_pad + 44, 20, reinterpret_cast<const unsigned char*>("xvcen-v4-keypad"), 15, mask, sizeof(mask)) != 0) return false;

    g_regionDigests = MakeArena(XV_SEAL_REGIONS * 32);
    if (g_regionDigests == nullptr) return false;

    std::vector<unsigned char> plain;
    if (!LoadRegion(xv::kRegionOffsets, plain)) return false;
    if (crypto_generichash(g_regionDigests, 32, plain.data(), plain.size(), maskKey, sizeof(maskKey)) != 0) return false;
    if (!ParseValueRegion(plain, g_offsets, g_offsetCount)) return false;
    sodium_memzero(plain.data(), plain.size());
    plain.clear();

    if (!LoadRegion(xv::kRegionStrings, plain)) return false;
    if (crypto_generichash(g_regionDigests + 32, 32, plain.data(), plain.size(), maskKey, sizeof(maskKey)) != 0) return false;
    if (!ParseBlobRegion(plain, g_strIndex, g_strData, g_strCount, g_strBytes, g_pad, g_pad + 32, 0)) return false;
    sodium_memzero(plain.data(), plain.size());
    plain.clear();

    if (!LoadRegion(xv::kRegionKeys, plain)) return false;
    if (crypto_generichash(g_regionDigests + 64, 32, plain.data(), plain.size(), maskKey, sizeof(maskKey)) != 0) return false;
    if (!ParseBlobRegion(plain, g_keyIndex, g_keyData, g_keyCount, g_keyBytes, g_pad + 32, g_pad + 44, 0x0100u)) return false;
    sodium_memzero(plain.data(), plain.size());
    plain.clear();

    if (!LoadRegion(xv::kRegionPolicy, plain)) return false;
    if (crypto_generichash(g_regionDigests + 96, 32, plain.data(), plain.size(), maskKey, sizeof(maskKey)) != 0) return false;
    if (!ParseValueRegion(plain, g_policy, g_policyCount)) return false;
    sodium_memzero(plain.data(), plain.size());
    plain.clear();

    unsigned char tokenMac[32];
    if (crypto_generichash(tokenMac, sizeof(tokenMac), g_windowItems, sizeof(items), mask, sizeof(mask)) != 0) return false;
    g_token = Load64(tokenMac) | 1ULL;

    sodium_memzero(tokenMac, sizeof(tokenMac));
    sodium_memzero(mask, sizeof(mask));
    sodium_memzero(maskKey, sizeof(maskKey));
    CloseArena(g_master);
    CloseArena(g_pad);
    CloseArena(g_windowItems);
    CloseArena(g_regionDigests);
    CloseArena(reinterpret_cast<unsigned char*>(g_offsets));
    CloseArena(reinterpret_cast<unsigned char*>(g_policy));
    CloseArena(reinterpret_cast<unsigned char*>(g_strIndex));
    CloseArena(g_strData);
    CloseArena(reinterpret_cast<unsigned char*>(g_keyIndex));
    CloseArena(g_keyData);
    g_ready.store(true, std::memory_order_release);
    return true;
}

void InitOnce() {
    bool ok = false;
    try {
        ok = InitLocked();
    } catch (...) {
        ok = false;
    }
    if (!ok) {
        WipeLocked();
        DropArena(g_master, 32);
        g_master = nullptr;
        sodium_memzero(&g_header, sizeof(g_header));
        sodium_memzero(g_regions, sizeof(g_regions));
        sodium_memzero(g_windows, sizeof(g_windows));
    }
}

bool BlobEntry(std::uint64_t* index, std::size_t count, std::uint32_t id, std::uint32_t& off, std::uint32_t& len) {
    if (index == nullptr || id >= count) return false;
    std::uint64_t packed = index[id] ^ g_tableMask;
    off = static_cast<std::uint32_t>(packed & 0xffffffffULL);
    len = static_cast<std::uint32_t>(packed >> 32);
    return len != 0 && len <= 4096;
}

}

namespace xv {

bool Init() {
    std::call_once(g_once, InitOnce);
    return g_ready.load(std::memory_order_acquire);
}

bool Ready() {
    return Init() && g_ready.load(std::memory_order_acquire);
}

std::uint32_t BuildId() {
    return g_buildId;
}

std::uint64_t Token() {
    if (!Ready()) return 0;
    return g_token;
}

std::size_t OffsetCount() {
    return Ready() ? g_offsetCount : 0;
}

std::size_t PolicyCount() {
    return Ready() ? g_policyCount : 0;
}

std::size_t StrCount() {
    return Ready() ? g_strCount : 0;
}

std::uint64_t Offset(std::uint32_t id) {
    if (!Ready()) return 0;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire) || id >= g_offsetCount) return 0;
    unsigned char* arena = reinterpret_cast<unsigned char*>(g_offsets);
    if (!OpenArena(arena)) return 0;
    std::uint64_t value = g_offsets[id] ^ g_tableMask;
    CloseArena(arena);
    return value;
}

std::uint64_t Policy(std::uint32_t id) {
    if (!Ready()) return 0;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire) || id >= g_policyCount) return 0;
    unsigned char* arena = reinterpret_cast<unsigned char*>(g_policy);
    if (!OpenArena(arena)) return 0;
    std::uint64_t value = g_policy[id] ^ g_tableMask;
    CloseArena(arena);
    return value;
}

std::string Str(std::uint32_t id) {
    if (!Ready()) return {};
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire)) return {};
    std::uint32_t off = 0;
    std::uint32_t len = 0;
    unsigned char* indexArena = reinterpret_cast<unsigned char*>(g_strIndex);
    if (!OpenArena(indexArena)) return {};
    bool found = BlobEntry(g_strIndex, g_strCount, id, off, len);
    CloseArena(indexArena);
    if (!found) return {};
    std::vector<unsigned char> buffer(len + 1, 0);
    if (!OpenArena(g_pad)) return {};
    if (!OpenArena(g_strData)) {
        CloseArena(g_pad);
        return {};
    }
    crypto_stream_chacha20_ietf_xor_ic(buffer.data(), g_strData + off, len, g_pad + 32, off / 64, g_pad);
    CloseArena(g_strData);
    CloseArena(g_pad);
    std::string out(reinterpret_cast<const char*>(buffer.data()), len);
    sodium_memzero(buffer.data(), buffer.size());
    return out;
}

const char* StrC(std::uint32_t id) {
    constexpr std::size_t kSlots = 12;
    constexpr std::size_t kSlotBytes = 256;
    thread_local unsigned char buffers[kSlots][kSlotBytes];
    thread_local std::size_t cursor = 0;
    std::string value = Str(id);
    if (value.empty() || value.size() + 1 > kSlotBytes) return "";
    std::size_t slot = cursor;
    cursor = (cursor + 1) % kSlots;
    sodium_memzero(buffers[slot], kSlotBytes);
    memcpy(buffers[slot], value.data(), value.size());
    buffers[slot][value.size()] = 0;
    sodium_memzero(&value[0], value.size());
    return reinterpret_cast<const char*>(buffers[slot]);
}

const char* StrStable(std::uint32_t id) {
    static std::mutex cacheLock;
    static std::vector<char*> cache;
    std::lock_guard<std::mutex> guard(cacheLock);
    std::size_t total = StrCount();
    if (cache.size() < total) cache.resize(total, nullptr);
    if (cache.size() <= id) cache.resize(id + 1, nullptr);
    if (cache[id] == nullptr) {
        std::string value = Str(id);
        if (value.empty()) return "";
        char* block = static_cast<char*>(sodium_malloc(value.size() + 1));
        if (block == nullptr) return "";
        std::memcpy(block, value.data(), value.size());
        block[value.size()] = 0;
        sodium_memzero(&value[0], value.size());
        cache[id] = block;
    }
    return cache[id];
}

std::size_t KeyLen(std::uint32_t id) {
    if (!Ready()) return 0;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire)) return 0;
    std::uint32_t off = 0;
    std::uint32_t len = 0;
    unsigned char* indexArena = reinterpret_cast<unsigned char*>(g_keyIndex);
    if (!OpenArena(indexArena)) return 0;
    bool found = BlobEntry(g_keyIndex, g_keyCount, id, off, len);
    CloseArena(indexArena);
    return found ? len : 0;
}

bool Key(std::uint32_t id, unsigned char* out, std::size_t len) {
    if (out == nullptr || !Ready()) return false;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire)) return false;
    std::uint32_t off = 0;
    std::uint32_t size = 0;
    unsigned char* indexArena = reinterpret_cast<unsigned char*>(g_keyIndex);
    if (!OpenArena(indexArena)) return false;
    bool found = BlobEntry(g_keyIndex, g_keyCount, id, off, size);
    CloseArena(indexArena);
    if (!found || size != len) return false;
    if (!OpenArena(g_pad)) return false;
    if (!OpenArena(g_keyData)) {
        CloseArena(g_pad);
        return false;
    }
    crypto_stream_chacha20_ietf_xor_ic(out, g_keyData + off, len, g_pad + 44, 0x0100u + off / 64, g_pad + 32);
    CloseArena(g_keyData);
    CloseArena(g_pad);
    return true;
}

bool Checkpoint(std::uint64_t domain) {
    if (!Ready()) return false;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire)) return false;
    std::uint32_t window = static_cast<std::uint32_t>(domain % XV_SEAL_WINDOWS);
    unsigned char item[XV_SEAL_WINDOW_ITEM_BYTES];
    if (!LoadWindow(window, item)) return false;
    if (!OpenArena(g_windowItems)) {
        sodium_memzero(item, sizeof(item));
        return false;
    }
    int rc = sodium_memcmp(g_windowItems + window * XV_SEAL_WINDOW_ITEM_BYTES, item, XV_SEAL_WINDOW_ITEM_BYTES);
    CloseArena(g_windowItems);
    sodium_memzero(item, sizeof(item));
    return rc == 0;
}

bool RevalidateRegion(std::uint32_t region) {
    if (region >= XV_SEAL_REGIONS) return false;
    if (!Ready()) return false;
    std::lock_guard<std::mutex> lock(g_lock);
    if (!g_ready.load(std::memory_order_acquire)) return false;
    std::vector<unsigned char> plain;
    if (!LoadRegion(region, plain)) {
        WipeLocked();
        return false;
    }
    unsigned char master[32];
    unsigned char macKey[32];
    unsigned char digest[32];
    bool ok = MasterCopy(master);
    if (ok) ok = Derive(macKey, sizeof(macKey), 0x300ULL, XV_CTX_MASK, master);
    if (ok) ok = crypto_generichash(digest, sizeof(digest), plain.data(), plain.size(), macKey, sizeof(macKey)) == 0;
    if (ok) {
        if (!OpenArena(g_regionDigests)) {
            ok = false;
        } else {
            ok = sodium_memcmp(g_regionDigests + region * 32, digest, 32) == 0;
            CloseArena(g_regionDigests);
        }
    }
    sodium_memzero(digest, sizeof(digest));
    sodium_memzero(macKey, sizeof(macKey));
    sodium_memzero(master, sizeof(master));
    sodium_memzero(plain.data(), plain.size());
    if (!ok) WipeLocked();
    return ok;
}

bool Revalidate(std::uint64_t domain) {
    if (!Ready()) return false;
    return RevalidateRegion(static_cast<std::uint32_t>(domain % XV_SEAL_REGIONS));
}

void Memzero(void* ptr, std::size_t len) {
    if (ptr != nullptr && len != 0) sodium_memzero(ptr, len);
}

void* Locked(std::size_t len) {
    if (len == 0) return nullptr;
    return MakeArena(len);
}

void Release(void* ptr) {
    if (ptr == nullptr) return;
    sodium_free(ptr);
}

}
