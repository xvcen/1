#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#include "xvseal.h"
#include "xvstrings.h"

#include "animations.h"

#include <cfloat>
#include <cmath>
#include <cstring>

static ImGenieContext* s_ctx = nullptr;

static ImVec2 s_tg(const ImVec2& arV0, const ImVec2& arV1, float aPercent) { return (arV1 - arV0) * ImVec2(0.0f, aPercent) + arV0; }

static float s_bezierCubicCalc(float aP1, float aP2, float aP3, float aP4, float aT) {
    const auto u = 1.0 - static_cast<double>(aT);
    const auto w1 = u * u * u;
    const auto w2 = 3.0 * u * u * aT;
    const auto w3 = 3.0 * u * aT * aT;
    const auto w4 = static_cast<double>(aT) * aT * aT;
    return static_cast<float>(w1 * aP1 + w2 * aP2 + w3 * aP3 + w4 * aP4);
}

static void s_drawTexturedCoonsMeshPrimAnim(ImDrawList* apDrawList,
                                            const ImTextureRef& arTexture,
                                            const ImVec2& arP00,
                                            const ImVec2& arP10,
                                            const ImVec2& arP01,
                                            const ImVec2& arP11,
                                            int32_t aCellsH,
                                            int32_t aCellsV,
                                            float aStartAnimT,
                                            float aEndAnimT,
                                            bool aHorizontal = false,
                                            bool aFlipPrimaryUv = false,
                                            bool aFlipV = false) {
    if ((!apDrawList) || (aCellsV < 1) || (aCellsH < 1) || (aStartAnimT > aEndAnimT)) { return; }
    const auto tint = IM_COL32(255, 255, 255, 255);

    if (aHorizontal) {
        const auto visibleCols = static_cast<uint32_t>(ImMax(std::ceil((aEndAnimT - aStartAnimT) * static_cast<float>(aCellsH)), 1.0f));
        const auto vertsPerCol = static_cast<uint32_t>(aCellsV + 1);
        const auto colCount = visibleCols + 1U;
        const auto vertexCount = colCount * vertsPerCol;
        const auto indexCount = visibleCols * static_cast<uint32_t>(aCellsV) * 6U;
        apDrawList->PushTexture(arTexture);
        apDrawList->PrimReserve(indexCount, vertexCount);
        ImDrawIdx prevColStart = 0;
        auto currColStart = static_cast<ImDrawIdx>(apDrawList->_VtxCurrentIdx);
        for (uint32_t colIdx = 0; colIdx < colCount; ++colIdx) {
            const auto colFactor = (colCount > 1) ? (static_cast<float>(colIdx) / static_cast<float>(colCount - 1)) : 0.0f;
            const auto patchParam = aStartAnimT + (aEndAnimT - aStartAnimT) * colFactor;

            const auto tpt = s_bezierCubicCalc(arP00.y, arP00.y, arP10.y, arP10.y, patchParam);
            const auto bpt = s_bezierCubicCalc(arP01.y, arP01.y, arP11.y, arP11.y, patchParam);
            auto uvPrimary = (patchParam - aStartAnimT) /
                             (aEndAnimT - aStartAnimT);
            if (aFlipPrimaryUv) { uvPrimary = 1.0f - uvPrimary; }
            for (uint32_t rowIdx = 0; rowIdx < vertsPerCol; ++rowIdx) {
                const auto v = (vertsPerCol > 1) ? (static_cast<float>(rowIdx) / static_cast<float>(vertsPerCol - 1)) : 0.0f;
                const auto y = tpt + (bpt - tpt) * v;

                const auto leftX = s_bezierCubicCalc(arP00.x, arP00.x, arP01.x, arP01.x, v);
                const auto rightX = s_bezierCubicCalc(arP10.x, arP10.x, arP11.x, arP11.x, v);
                const auto x = leftX + (rightX - leftX) * patchParam;
                const auto finalV = aFlipV ? (1.0f - v) : v;
                apDrawList->PrimWriteVtx(ImVec2(x, y), ImVec2(uvPrimary, finalV), tint);
            }

            if (colIdx > 0) {
                for (int32_t rowIdx = 0; rowIdx < aCellsV; ++rowIdx) {
                    const auto tl = prevColStart + static_cast<ImDrawIdx>(rowIdx);
                    const auto bl = tl + 1;
                    const auto tr = currColStart + static_cast<ImDrawIdx>(rowIdx);
                    const auto br = tr + 1;
                    apDrawList->PrimWriteIdx(tl);
                    apDrawList->PrimWriteIdx(tr);
                    apDrawList->PrimWriteIdx(br);
                    apDrawList->PrimWriteIdx(tl);
                    apDrawList->PrimWriteIdx(br);
                    apDrawList->PrimWriteIdx(bl);
                }
            }
            prevColStart = currColStart;
            currColStart = static_cast<ImDrawIdx>(currColStart + vertsPerCol);
        }
        apDrawList->PopTexture();
        return;
    }

    const auto visibleCellsV = static_cast<uint32_t>(ImMax(std::ceil((aEndAnimT - aStartAnimT) * static_cast<float>(aCellsV)), 1.0f));
    const auto vertsPerRow = static_cast<uint32_t>(aCellsH + 1);
    const auto vertsPerCol = visibleCellsV + 1U;
    const auto vertexCount = vertsPerRow * vertsPerCol;
    const auto indexCount = visibleCellsV * static_cast<uint32_t>(aCellsH) * 6U;
    apDrawList->PushTexture(arTexture);
    apDrawList->PrimReserve(indexCount, vertexCount);

    const auto bezierTangentPercent = 0.52f;
    const auto lxC1 = s_tg(arP00, arP01, bezierTangentPercent).x;
    const auto lxC2 = s_tg(arP01, arP00, bezierTangentPercent).x;
    const auto rxC1 = s_tg(arP10, arP11, bezierTangentPercent).x;
    const auto rxC2 = s_tg(arP11, arP10, bezierTangentPercent).x;
    const auto tyC1 = arP00.y, tyC2 = arP10.y;
    const auto byC1 = arP01.y, byC2 = arP11.y;
    ImDrawIdx prevRowStart = 0;
    auto currRowStart = static_cast<ImDrawIdx>(apDrawList->_VtxCurrentIdx);
    for (uint32_t rowIdx = 0; rowIdx < vertsPerCol; ++rowIdx) {
        const auto rowFactor = (vertsPerCol > 1) ? (static_cast<float>(rowIdx) / static_cast<float>(vertsPerCol - 1)) : 0.0f;
        const auto patchParam = aStartAnimT + (aEndAnimT - aStartAnimT) * rowFactor;

        const auto lpt = s_bezierCubicCalc(arP00.x, lxC1, lxC2, arP01.x, patchParam);
        const auto rpt = s_bezierCubicCalc(arP10.x, rxC1, rxC2, arP11.x, patchParam);
        auto uvY = (patchParam - aStartAnimT) /
                   (aEndAnimT - aStartAnimT);
        if (aFlipPrimaryUv) { uvY = 1.0f - uvY; }
        for (uint32_t colIdx = 0; colIdx < vertsPerRow; ++colIdx) {
            const auto u = (vertsPerRow > 1) ? (static_cast<float>(colIdx) / static_cast<float>(vertsPerRow - 1)) : 0.0f;

            const auto x = lpt + (rpt - lpt) * u;
            const auto topY = s_bezierCubicCalc(arP00.y, tyC1, tyC2, arP10.y, u);
            const auto botY = s_bezierCubicCalc(arP01.y, byC1, byC2, arP11.y, u);
            const auto y = topY + (botY - topY) * patchParam;
            const auto finalUvY = aFlipV ? (1.0f - uvY) : uvY;
            apDrawList->PrimWriteVtx(ImVec2(x, y), ImVec2(u, finalUvY), tint);
        }

        if (rowIdx > 0) {
            for (int32_t colIdx = 0; colIdx < aCellsH; ++colIdx) {
                const auto tl = prevRowStart + static_cast<ImDrawIdx>(colIdx);
                const auto tr = tl + 1;
                const auto bl = currRowStart + static_cast<ImDrawIdx>(colIdx);
                const auto br = bl + 1;
                apDrawList->PrimWriteIdx(tl);
                apDrawList->PrimWriteIdx(tr);
                apDrawList->PrimWriteIdx(br);
                apDrawList->PrimWriteIdx(tl);
                apDrawList->PrimWriteIdx(br);
                apDrawList->PrimWriteIdx(bl);
            }
        }
        prevRowStart = currRowStart;
        currRowStart = static_cast<ImDrawIdx>(currRowStart + vertsPerRow);
    }
    apDrawList->PopTexture();
}

static void s_latticeDraw(ImDrawList* apDrawList,
                          const ImTextureRef& arTexture,
                          const ImVec2& arP00,
                          const ImVec2& arP10,
                          const ImVec2& arP01,
                          const ImVec2& arP11,
                          int32_t aCellsH,
                          int32_t aCellsV,
                          bool aFlipV = false) {
    if ((!apDrawList) || (arTexture._TexID == 0)) { return; }
    s_drawTexturedCoonsMeshPrimAnim(apDrawList, arTexture, arP00, arP10, arP01, arP11, aCellsH, aCellsV, 0.0f, 1.0f, false, false, aFlipV);
}

static ImGenieSide s_autoDetectSide(const ImRect& arSource, const ImRect& arTarget) {
    const auto delta = arSource.GetCenter() - arTarget.GetCenter();
    if (fabsf(delta.x) > fabsf(delta.y)) { return (delta.x > 0) ? ImGenieSide_Right : ImGenieSide_Left; }
    return (delta.y > 0) ? ImGenieSide_Bottom : ImGenieSide_Top;
}

static void s_latticeAnimate(ImDrawList* apDrawList,
                             const ImTextureRef& arTexture,
                             float aAnimT,
                             const ImRect& arSource,
                             const ImRect& arTarget,
                             int32_t aCellsH,
                             int32_t aCellsV,
                             ImGenieSide aSide,
                             bool aFlipV = false) {
    if ((!apDrawList) || (arTexture._TexID == 0) || (aAnimT < 0.0f) || (aAnimT > 1.0f)) { return; }
    const auto side = (aSide == ImGenieSide_Auto) ? s_autoDetectSide(arSource, arTarget) : aSide;
    const auto horizontal = (side == ImGenieSide_Left || side == ImGenieSide_Right);

    const auto flipPrimaryUv = (side == ImGenieSide_Bottom || side == ImGenieSide_Right);

    ImVec2 p00, p10, p01, p11;
    ImVec2 convSrc0, convSrc1, convTgt0, convTgt1;
    float totalDist{}, sourceDim{};
    switch (side) {
        case ImGenieSide_Top: {
            p00 = arSource.Min;
            p10 = ImVec2(arSource.Max.x, arSource.Min.y);
            convSrc0 = ImVec2(arSource.Min.x, arTarget.Min.y);
            convSrc1 = ImVec2(arSource.Max.x, arTarget.Min.y);
            convTgt0 = arTarget.Min;
            convTgt1 = ImVec2(arTarget.Max.x, arTarget.Min.y);
            totalDist = arTarget.Min.y - arSource.Min.y;
            sourceDim = arSource.GetHeight();
        } break;
        case ImGenieSide_Bottom: {
            p00 = ImVec2(arSource.Min.x, arSource.Max.y);
            p10 = arSource.Max;
            convSrc0 = ImVec2(arSource.Min.x, arTarget.Max.y);
            convSrc1 = ImVec2(arSource.Max.x, arTarget.Max.y);
            convTgt0 = ImVec2(arTarget.Min.x, arTarget.Max.y);
            convTgt1 = arTarget.Max;
            totalDist = arSource.Max.y - arTarget.Max.y;
            sourceDim = arSource.GetHeight();
        } break;
        case ImGenieSide_Left: {
            p00 = arSource.Min;
            p01 = ImVec2(arSource.Min.x, arSource.Max.y);
            convSrc0 = ImVec2(arTarget.Min.x, arSource.Min.y);
            convSrc1 = ImVec2(arTarget.Min.x, arSource.Max.y);
            convTgt0 = arTarget.Min;
            convTgt1 = ImVec2(arTarget.Min.x, arTarget.Max.y);
            totalDist = arTarget.Min.x - arSource.Min.x;
            sourceDim = arSource.GetWidth();
        } break;
        case ImGenieSide_Right:
        default: {
            p00 = ImVec2(arSource.Max.x, arSource.Min.y);
            p01 = arSource.Max;
            convSrc0 = ImVec2(arTarget.Max.x, arSource.Min.y);
            convSrc1 = ImVec2(arTarget.Max.x, arSource.Max.y);
            convTgt0 = ImVec2(arTarget.Max.x, arTarget.Min.y);
            convTgt1 = arTarget.Max;
            totalDist = arSource.Max.x - arTarget.Max.x;
            sourceDim = arSource.GetWidth();
        } break;
    }
    if (horizontal) {
        p10 = convSrc0;
        p11 = convSrc1;
    } else {
        p01 = convSrc0;
        p11 = convSrc1;
    }

    const auto sourceRatio = (totalDist > 0.0f) ? (sourceDim / totalDist) : 1.0f;
    auto startRatio = 0.0f;
    auto endRatio = sourceRatio;
    if (aAnimT > 0.0f) {

        const auto ratio = (aAnimT < 0.3f) ? (aAnimT / 0.3f) : 1.0f;

        if (aAnimT > 0.25f) { startRatio = (aAnimT - 0.25f) / (1.0f - 0.25f); }
        const auto conv0 = ImLerp(convSrc0, convTgt0, ratio);
        const auto conv1 = ImLerp(convSrc1, convTgt1, ratio);
        if (horizontal) {
            p10 = conv0;
            p11 = conv1;
        } else {
            p01 = conv0;
            p11 = conv1;
        }
        endRatio = ImLerp(sourceRatio, 1.0f, ratio);
    }
    s_drawTexturedCoonsMeshPrimAnim(apDrawList, arTexture, p00, p10, p01, p11, aCellsH, aCellsV, startRatio, endRatio, horizontal, flipPrimaryUv, aFlipV);
}

static void s_drawDebug(ImDrawList* apDrawList, const ImGenieEffect& arEffect) {
    if (arEffect.params.drawDebug && !apDrawList->CmdBuffer.empty()) {
        auto* pCmd = &apDrawList->CmdBuffer.front();
        ImGui::DebugNodeDrawCmdShowMeshAndBoundingBox(apDrawList, apDrawList, pCmd, true, true);
    }
}

static void s_addChildDrawLists(const ImGuiWindow* apWin, ImDrawData* apDrawData) {
    for (int i = 0; i < apWin->DC.ChildWindows.Size; ++i) {
        const ImGuiWindow* child = apWin->DC.ChildWindows[i];
        if (child != nullptr && child->DrawList != nullptr && child->DrawList->CmdBuffer.Size > 0) {
            apDrawData->AddDrawList(child->DrawList);
            s_addChildDrawLists(child, apDrawData);
        }
    }
}

static ImTextureRef s_captureWindow(const ImGuiWindow* apWin, ImDrawData* apMainDrawData) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    IM_ASSERT(s_ctx->createCaptureFunc && xv::StrStable(xv::sid::kAnTheCaptureCreationFunctionIsNotDefined));
    ImTextureRef ret{};
    if (apWin == nullptr || apWin->DrawList == nullptr) { return ret; }
    const auto w = static_cast<int32_t>(apWin->Size.x);
    const auto h = static_cast<int32_t>(apWin->Size.y);
    if (w <= 0 || h <= 0) { return ret; }
    ImDrawData offscreenData;
    offscreenData.Valid = true;
    offscreenData.DisplayPos = apWin->Pos;
    offscreenData.DisplaySize = apWin->Size;
    offscreenData.FramebufferScale = ImGui::GetIO().DisplayFramebufferScale;
    offscreenData.OwnerViewport = ImGui::GetMainViewport();
    offscreenData.Textures = (apMainDrawData != nullptr) ? apMainDrawData->Textures : nullptr;
    offscreenData.AddDrawList(apWin->DrawList);
    s_addChildDrawLists(apWin, &offscreenData);
    return s_ctx->createCaptureFunc(w, h, &offscreenData);
}

static void s_deleteEffectTexture(ImGenieEffect& aorEffect) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    IM_ASSERT(s_ctx->destroyCaptureFunc && xv::StrStable(xv::sid::kAnTheCaptureDestructionFunctionIsNotDefined));
    if (aorEffect.capturedTex._TexID != 0) {
        s_ctx->destroyCaptureFunc(aorEffect.capturedTex);
        aorEffect.capturedTex._TexID = 0;
    }
}

static void s_removeDrawListFromDrawData(ImDrawData* apDrawData, ImDrawList* apDrawList) {
    if (apDrawData == nullptr || apDrawList == nullptr) { return; }
    for (int32_t i = 0; i < apDrawData->CmdLists.Size; ++i) {
        if (apDrawData->CmdLists[i] == apDrawList) {
            apDrawData->TotalVtxCount -= apDrawList->VtxBuffer.Size;
            apDrawData->TotalIdxCount -= apDrawList->IdxBuffer.Size;
            apDrawData->CmdLists.erase(apDrawData->CmdLists.Data + i);
            apDrawData->CmdListsCount--;
            break;
        }
    }
}

static void s_removeChildDrawListsFromDrawData(ImDrawData* apDrawData, const ImGuiWindow* apWin) {
    for (int i = 0; i < apWin->DC.ChildWindows.Size; ++i) {
        const ImGuiWindow* child = apWin->DC.ChildWindows[i];
        if (child != nullptr && child->DrawList != nullptr) {
            s_removeDrawListFromDrawData(apDrawData, child->DrawList);
            s_removeChildDrawListsFromDrawData(apDrawData, child);
        }
    }
}

static void s_cornersFromRect(const ImRect& arRect, ImVec2 aoCorners[4]) {
    aoCorners[0] = arRect.Min;
    aoCorners[1] = ImVec2(arRect.Max.x, arRect.Min.y);
    aoCorners[2] = ImVec2(arRect.Min.x, arRect.Max.y);
    aoCorners[3] = arRect.Max;
}

static void s_initSprings(ImGenieEffect& aorEffect, const ImRect& arWinRect, const ImVec2& arGrabPos) {
    ImVec2 corners[4];
    s_cornersFromRect(arWinRect, corners);
    for (int32_t i = 0; i < 4; ++i) {
        aorEffect.springs[i].current = corners[i];
        aorEffect.springs[i].velocity = ImVec2(0, 0);
    }

    const auto gx = ImClamp((arWinRect.GetWidth() > 0.0f) ? (arGrabPos.x - arWinRect.Min.x) / arWinRect.GetWidth() : 0.5f, 0.0f, 1.0f);
    const auto gy = ImClamp((arWinRect.GetHeight() > 0.0f) ? (arGrabPos.y - arWinRect.Min.y) / arWinRect.GetHeight() : 0.5f, 0.0f, 1.0f);
    aorEffect.grabUV = ImVec2(gx, gy);

    aorEffect.springWeights[0] = (1.0f - gx) * (1.0f - gy);
    aorEffect.springWeights[1] = gx * (1.0f - gy);
    aorEffect.springWeights[2] = (1.0f - gx) * gy;
    aorEffect.springWeights[3] = gx * gy;
}

static void s_updateSprings(ImGenieEffect& aorEffect, const ImRect& arWinRect, float aDt) {
    const auto& rParams = aorEffect.params;
    ImVec2 targets[4];
    s_cornersFromRect(arWinRect, targets);
    const auto& spring = rParams.effects.wobbly.spring;
    const auto subDt = aDt / spring.substeps;
    for (int32_t step = 0; step < spring.substeps; ++step) {
        for (int32_t i = 0; i < 4; ++i) {
            const auto stiffness = spring.stiffness +
                (rParams.effects.wobbly.maxStiffness - spring.stiffness) * aorEffect.springWeights[i];
            auto force = (targets[i] - aorEffect.springs[i].current) * stiffness;
            force = force - aorEffect.springs[i].velocity * spring.damping;
            aorEffect.springs[i].velocity = aorEffect.springs[i].velocity + force * subDt;
            aorEffect.springs[i].current = aorEffect.springs[i].current + aorEffect.springs[i].velocity * subDt;
        }
    }
}

ImGenieContext* ImGenie::CreateContext() {
    auto* ctx = IM_NEW(ImGenieContext);
    if (s_ctx == nullptr) { SetCurrentContext(ctx); }
    return ctx;
}

void ImGenie::DestroyContext(ImGenieContext* apCtx) {
    if (apCtx == nullptr) { apCtx = s_ctx; }
    if (apCtx == nullptr) { return; }
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    for (auto it = apCtx->effects.begin(); it != apCtx->effects.end(); ++it) { s_deleteEffectTexture(it->second); }
    if (s_ctx == apCtx) { s_ctx = nullptr; }
    IM_DELETE(apCtx);
}

ImGenieContext* ImGenie::GetCurrentContext() { return s_ctx; }

bool ImGenie::IsEffectActive(const char* aWindowName) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    if (s_ctx == nullptr) { return false; }
    const auto id = ImHashStr(aWindowName);
    auto it = s_ctx->effects.find(id);
    return it != s_ctx->effects.end();
}

void ImGenie::SetCurrentContext(ImGenieContext* apCtx) { s_ctx = apCtx; }

void ImGenie::SetExternalDragging(const char* aWindowName, bool aDragging) {
    if (!s_ctx || !aWindowName) return;
    auto& ctx = *s_ctx;
    const auto id = ImHashStr(aWindowName);
    ctx.externalDragStates[id] = aDragging;
}

void ImGenie::SetCreateCaptureFunc(const CreateCaptureFunctor& arFunc) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    s_ctx->createCaptureFunc = arFunc;
}

void ImGenie::SetDestroyCaptureFunc(const DestroyCaptureFunctor& arFunc) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    s_ctx->destroyCaptureFunc = arFunc;
}

void ImGenie::SetCaptureFlipV(bool aFlipV) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    s_ctx->captureFlipV = aFlipV;
}

bool ImGenie::Allow(const char* aWindowName, bool* apoOpen, const ImGenieParams* apParams) {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    if (aWindowName == nullptr || apoOpen == nullptr || apParams == nullptr) { return true; }
    auto& ctx = *s_ctx;
    const auto& params = *apParams;
    const auto id = ImHashStr(aWindowName);
    bool* pOpen = apoOpen;
    auto it = ctx.effects.find(id);

    if (it != ctx.effects.end()) {
        auto& effect = it->second;

        effect.params = params;
        const auto& dr = params.transitions.genie.destRect;
        effect.destRect = ImRect(dr.minX, dr.minY, dr.maxX, dr.maxY);

        if (effect.state == ImGenieEffect::State::Animating && effect.animT > 0.0f && *pOpen) {
            effect.state = ImGenieEffect::State::AppearingAnimating;
            effect.animT = 1.0f - effect.animT;
        } else if (effect.state == ImGenieEffect::State::AppearingAnimating && effect.animT > 0.0f && !*pOpen) {
            effect.state = ImGenieEffect::State::Animating;
            effect.animT = 1.0f - effect.animT;
        }

        if (effect.state == ImGenieEffect::State::PendingCapture) {
            *pOpen = true;
            return true;
        }

        if (effect.state == ImGenieEffect::State::Captured) {
            effect.state = ImGenieEffect::State::Animating;
            effect.animT = 0.0f;
        }

        if (effect.state == ImGenieEffect::State::Animating) {
            const auto dt = ImGui::GetIO().DeltaTime;
            effect.animT += dt / effect.params.transitions.animDuration;
            if (effect.animT >= 1.0f) {
                s_deleteEffectTexture(effect);
                ctx.effectNames.erase(id);
                ctx.effects.erase(it);
                *pOpen = false;
                return true;
            }
            auto* pDrawList = ImGui::GetForegroundDrawList();
            const auto horizontal = (effect.resolvedSide == ImGenieSide_Left || effect.resolvedSide == ImGenieSide_Right);
            const auto cellsH = horizontal ? effect.params.transitions.genie.cellsV : effect.params.transitions.genie.cellsH;
            const auto cellsV = horizontal ? effect.params.transitions.genie.cellsH : effect.params.transitions.genie.cellsV;
            const auto visualT = effect.animT * effect.animT * (3.0f - 2.0f * effect.animT);
            s_latticeAnimate(pDrawList,
                             effect.capturedTex,
                             visualT,
                             effect.sourceRect,
                             effect.destRect,
                             cellsH,
                             cellsV,
                             effect.resolvedSide,
                             ctx.captureFlipV);
            s_drawDebug(pDrawList, effect);
            *pOpen = false;
            return false;
        }

        if (effect.state == ImGenieEffect::State::AppearingCapture) {
            *pOpen = true;
            return true;
        }

        if (effect.state == ImGenieEffect::State::AppearingAnimating) {
            const auto dt = ImGui::GetIO().DeltaTime;
            effect.animT += dt / effect.params.transitions.animDuration;
            if (effect.animT >= 1.0f) {
                s_deleteEffectTexture(effect);
                ctx.effectNames.erase(id);
                ctx.effects.erase(it);
                *pOpen = true;
                ctx.openStates[id] = true;
                return true;
            }
            auto* pDrawList = ImGui::GetForegroundDrawList();
            const auto horizontal = (effect.resolvedSide == ImGenieSide_Left || effect.resolvedSide == ImGenieSide_Right);
            const auto cellsH = horizontal ? effect.params.transitions.genie.cellsV : effect.params.transitions.genie.cellsH;
            const auto cellsV = horizontal ? effect.params.transitions.genie.cellsH : effect.params.transitions.genie.cellsV;
            const auto visualT = effect.animT * effect.animT * (3.0f - 2.0f * effect.animT);
            s_latticeAnimate(pDrawList,
                             effect.capturedTex,
                             1.0f - visualT,
                             effect.sourceRect,
                             effect.destRect,
                             cellsH,
                             cellsV,
                             effect.resolvedSide,
                             ctx.captureFlipV);
            s_drawDebug(pDrawList, effect);
            *pOpen = true;
            return false;
        }

        if (effect.state == ImGenieEffect::State::MovingCapture) { return true; }

        if (effect.state == ImGenieEffect::State::MovingActive || effect.state == ImGenieEffect::State::MovingSettle) {
            if (effect.capturedTex._TexID == 0) {
                ctx.effectNames.erase(id);
                ctx.effects.erase(it);
                return true;
            }
            auto* pWin = ImGui::FindWindowByName(aWindowName);
            if (pWin == nullptr) {
                s_deleteEffectTexture(effect);
                ctx.effectNames.erase(id);
                ctx.effects.erase(it);
                return true;
            }
            const auto winRect = pWin->Rect();
            const auto dt = ImGui::GetIO().DeltaTime;

            if (effect.state == ImGenieEffect::State::MovingActive) {
                const auto& g = *GImGui;
                auto stillDragging = false;
                const auto extIt = ctx.externalDragStates.find(id);
                if (extIt != ctx.externalDragStates.end() && extIt->second) {
                    stillDragging = true;
                } else if (g.MovingWindow != nullptr) {
                    stillDragging = (g.MovingWindow == pWin);
                    if (!stillDragging && g.MovingWindow->RootWindow != nullptr) { stillDragging = (g.MovingWindow->RootWindow == pWin); }
                }
                if (!stillDragging) {
                    effect.state = ImGenieEffect::State::MovingSettle;
                    effect.animT = 0.0f;
                    for (int32_t i = 0; i < 4; ++i) { effect.settleStart[i] = effect.springs[i].current; }
                }
            }

            if (effect.state == ImGenieEffect::State::MovingActive) {
                s_updateSprings(effect, winRect, dt);

                ImVec2 targets[4];
                s_cornersFromRect(winRect, targets);
                const auto targetGrab =
                    targets[0] * effect.springWeights[0]
                    + targets[1] * effect.springWeights[1]
                    + targets[2] * effect.springWeights[2]
                    + targets[3] * effect.springWeights[3];
                const auto currentGrab =
                    effect.springs[0].current * effect.springWeights[0]
                    + effect.springs[1].current * effect.springWeights[1]
                    + effect.springs[2].current * effect.springWeights[2]
                    + effect.springs[3].current * effect.springWeights[3];
                const auto correction = targetGrab - currentGrab;
                auto wSqSum = 0.0f;
                for (int32_t i = 0; i < 4; ++i) { wSqSum += effect.springWeights[i] * effect.springWeights[i]; }
                if (wSqSum > 0.0f) {
                    for (int32_t i = 0; i < 4; ++i) {
                        const auto factor = effect.springWeights[i] / wSqSum;
                        effect.springs[i].current = effect.springs[i].current + correction * factor;
                    }
                }
            } else {
                effect.animT += dt / effect.params.effects.wobbly.settleDuration;
                if (effect.animT >= 1.0f) {
                    s_deleteEffectTexture(effect);
                    ctx.effectNames.erase(id);
                    ctx.effects.erase(it);
                    return true;
                }
                const auto t = effect.animT;
                const auto eased = 1.0f - (1.0f - t) * (1.0f - t);
                ImVec2 targets[4];
                s_cornersFromRect(winRect, targets);
                for (int32_t i = 0; i < 4; ++i) { effect.springs[i].current = ImLerp(effect.settleStart[i], targets[i], eased); }
            }
            auto* pDrawList = ImGui::GetForegroundDrawList();
            s_latticeDraw(pDrawList,
                          effect.capturedTex,
                          effect.springs[0].current,
                          effect.springs[1].current,
                          effect.springs[2].current,
                          effect.springs[3].current,
                          6,
                          6,
                          ctx.captureFlipV);
            s_drawDebug(pDrawList, effect);
            return true;
        }

        return true;
    }

    auto wasOpen = false;
    const auto stateIt = ctx.openStates.find(id);
    if (stateIt != ctx.openStates.end()) { wasOpen = stateIt->second; }
    ctx.openStates[id] = *pOpen;

    if (wasOpen && !(*pOpen)) {
        auto* pWin = ImGui::FindWindowByName(aWindowName);
        if (pWin != nullptr) {
            ImGenieEffect effect;
            effect.state = ImGenieEffect::State::PendingCapture;
            effect.sourceRect = pWin->Rect();
            const auto& dr2 = params.transitions.genie.destRect;
            effect.destRect = ImRect(dr2.minX, dr2.minY, dr2.maxX, dr2.maxY);
            effect.capturedSize = effect.sourceRect.GetSize();
            effect.params = params;

            effect.resolvedSide = (params.transitions.genie.side == ImGenieSide_Auto)
                ? s_autoDetectSide(effect.sourceRect, effect.destRect)
                : params.transitions.genie.side;
            ctx.effects[id] = effect;
            ctx.effectNames[id] = aWindowName;

            *pOpen = true;
            return true;
        }
    }

    if (!wasOpen && *pOpen) {
        ImGenieEffect effect;
        effect.state = ImGenieEffect::State::AppearingCapture;
        const auto& dr3 = params.transitions.genie.destRect;
        effect.destRect = ImRect(dr3.minX, dr3.minY, dr3.maxX, dr3.maxY);
        effect.params = params;
        auto* pWin = ImGui::FindWindowByName(aWindowName);
        if (pWin != nullptr) { pWin->HiddenFramesCannotSkipItems = 1; }
        ctx.effects[id] = effect;
        ctx.effectNames[id] = aWindowName;
        *pOpen = true;
        return true;
    }

    if (*pOpen) {
        const auto extIt = ctx.externalDragStates.find(id);
        if (extIt != ctx.externalDragStates.end() && extIt->second) {
            auto* pWin = ImGui::FindWindowByName(aWindowName);
            if (pWin != nullptr) {
                ImGenieEffect effect;
                effect.state = ImGenieEffect::State::MovingCapture;
                effect.sourceRect = pWin->Rect();
                effect.capturedSize = pWin->Size;
                effect.params = params;
                ctx.effects[id] = effect;
                ctx.effectNames[id] = aWindowName;
                return true;
            }
        }
        const auto& g = *GImGui;
        auto* pWin = ImGui::FindWindowByName(aWindowName);
        if (pWin != nullptr && g.MovingWindow != nullptr) {
            auto isMoving = (g.MovingWindow == pWin);
            if (!isMoving && g.MovingWindow->RootWindow != nullptr) { isMoving = (g.MovingWindow->RootWindow == pWin); }
            if (isMoving) {
                const auto startIt = ctx.dragStartPos.find(id);
                if (startIt == ctx.dragStartPos.end()) {
                    ctx.dragStartPos[id] = pWin->Pos;
                } else {
                    const auto delta = pWin->Pos - startIt->second;
                    if (delta.x != 0.0f || delta.y != 0.0f) {
                        ctx.dragStartPos.erase(startIt);
                        ImGenieEffect effect;
                        effect.state = ImGenieEffect::State::MovingCapture;
                        effect.sourceRect = pWin->Rect();
                        effect.capturedSize = pWin->Size;
                        effect.params = params;
                        ctx.effects[id] = effect;
                        ctx.effectNames[id] = aWindowName;
                        return true;
                    }
                }
            }
        } else {
            ctx.dragStartPos.erase(id);
        }
    }

    return true;
}

void ImGenie::Capture() {
    IM_ASSERT(s_ctx && xv::StrStable(xv::sid::kAnTheContextIsNull));
    IM_ASSERT(s_ctx->createCaptureFunc && xv::StrStable(xv::sid::kAnTheCaptureCreationFunctionIsNotDefined));
    auto& ctx = *s_ctx;
    auto* pMainDrawData = ImGui::GetDrawData();
    if (pMainDrawData == nullptr) { return; }
    for (auto it = ctx.effects.begin(); it != ctx.effects.end(); ++it) {
        auto& effect = it->second;
        const auto id = it->first;
        const auto nameIt = ctx.effectNames.find(id);
        if (nameIt == ctx.effectNames.end()) { continue; }

        if (effect.state == ImGenieEffect::State::AppearingCapture) {
            auto* pWin = ImGui::FindWindowByName(nameIt->second);
            if (pWin == nullptr || pWin->DrawList == nullptr || pWin->DrawList->CmdBuffer.Size == 0) {
                effect.state = ImGenieEffect::State::AppearingAnimating;
                effect.animT = 1.0f;
                continue;
            }
            effect.sourceRect = pWin->Rect();
            effect.capturedSize = pWin->Size;

            effect.resolvedSide =
                (effect.params.transitions.genie.side == ImGenieSide_Auto) ? s_autoDetectSide(effect.sourceRect, effect.destRect) : effect.params.transitions.genie.side;

            effect.capturedTex = s_captureWindow(pWin, pMainDrawData);
            if (effect.capturedTex._TexID != 0) {
                effect.state = ImGenieEffect::State::AppearingAnimating;
                effect.animT = 0.0f;
            } else {
                effect.state = ImGenieEffect::State::AppearingAnimating;
                effect.animT = 1.0f;
            }

            s_removeDrawListFromDrawData(pMainDrawData, pWin->DrawList);
            s_removeChildDrawListsFromDrawData(pMainDrawData, pWin);
        }

        else if (effect.state == ImGenieEffect::State::MovingCapture) {
            const auto* pWin = ImGui::FindWindowByName(nameIt->second);
            if (pWin == nullptr || pWin->DrawList == nullptr || pWin->DrawList->CmdBuffer.Size == 0) {
                effect.state = ImGenieEffect::State::MovingSettle;
                continue;
            }
            effect.sourceRect = pWin->Rect();
            effect.capturedSize = pWin->Size;
            effect.capturedTex = s_captureWindow(pWin, pMainDrawData);
            if (effect.capturedTex._TexID != 0) {
                s_initSprings(effect, pWin->Rect(), ImGui::GetIO().MousePos);
                effect.state = ImGenieEffect::State::MovingActive;
            } else {
                effect.state = ImGenieEffect::State::MovingSettle;
            }
            continue;
        }

        else if (effect.state == ImGenieEffect::State::MovingActive || effect.state == ImGenieEffect::State::MovingSettle) {
            auto* pWin = ImGui::FindWindowByName(nameIt->second);
            if (pWin != nullptr && pWin->DrawList != nullptr) {
                s_removeDrawListFromDrawData(pMainDrawData, pWin->DrawList);
                s_removeChildDrawListsFromDrawData(pMainDrawData, pWin);
            }
        }

        else if (effect.state == ImGenieEffect::State::PendingCapture) {
            auto* pWin = ImGui::FindWindowByName(nameIt->second);
            if (pWin == nullptr || pWin->DrawList == nullptr || pWin->DrawList->CmdBuffer.Size == 0) {
                effect.state = ImGenieEffect::State::Animating;
                effect.animT = 1.0f;
                continue;
            }
            effect.sourceRect = pWin->Rect();
            effect.capturedSize = pWin->Size;
            effect.capturedTex = s_captureWindow(pWin, pMainDrawData);
            if (effect.capturedTex._TexID != 0) {
                effect.state = ImGenieEffect::State::Captured;
            } else {
                effect.state = ImGenieEffect::State::Animating;
                effect.animT = 1.0f;
            }
        }
    }
}

bool ImGenie::DebugCheckVersion(const char* aVersion, size_t aParamsSize, size_t aEffectSize, size_t aContextSize) {
    bool ok = true;
    if (strcmp(aVersion, IMGENIE_VERSION) != 0) {
        ok = false;
        IM_ASSERT(false && xv::StrStable(xv::sid::kAnImGenieVersionMismatch));
    }
    if (aParamsSize != sizeof(ImGenieParams)) {
        ok = false;
        IM_ASSERT(false && xv::StrStable(xv::sid::kAnImGenieParamsSizeMismatch));
    }
    if (aEffectSize != sizeof(ImGenieEffect)) {
        ok = false;
        IM_ASSERT(false && xv::StrStable(xv::sid::kAnImGenieEffectSizeMismatch));
    }
    if (aContextSize != sizeof(ImGenieContext)) {
        ok = false;
        IM_ASSERT(false && xv::StrStable(xv::sid::kAnImGenieContextSizeMismatch));
    }
    return ok;
}
