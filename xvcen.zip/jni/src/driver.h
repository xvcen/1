#pragma once

#include "xvseal.h"
#include "xvstrings.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <stdint.h>
#include <string>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/types.h>

class c_driver {
private:
    int fd;
    pid_t pid;
    int kind;

    typedef struct _COPY_MEMORY {
        uint32_t pid;
        uint32_t pad;
        uint64_t addr;
        void* buffer;
        uint64_t size;
    } COPY_MEMORY, *PCOPY_MEMORY;

    typedef struct _COPY_MEMORY_QX {
        uint32_t pid;
        uint32_t pad;
        uint64_t addr;
        void* buffer;
        uint64_t size;
        uint32_t flag;
        uint32_t pad2;
    } COPY_MEMORY_QX, *PCOPY_MEMORY_QX;

    typedef struct _MODULE_BASE {
        uint32_t pid;
        uint32_t pad;
        char* name;
        uint64_t base;
    } MODULE_BASE, *PMODULE_BASE;

    enum OPERATIONS {
        OP_READ_MEM = 0x801,
        OP_WRITE_MEM = 0x802,
        OP_MODULE_BASE = 0x803,
        OP_ACTIVATE = 0x6B00,
    };

    char* execCom(const char* shell)
    {
        FILE *fp = popen(shell, "r");
        if (fp == NULL) {
            return NULL;
        }
        std::string out;
        char buffer[256];
        while (fgets(buffer, sizeof(buffer), fp) != NULL) {
            out += buffer;
        }
        pclose(fp);
        size_t total = out.size() + 1;
        char *result = (char *)malloc(total);
        if (!result) {
            return NULL;
        }
        memcpy(result, out.c_str(), total);
        return result;
    }

    static bool rt_name_ok(const char* s) {
        if (!s || strlen(s) != 6) return false;
        for (int i = 0; i < 6; i++) {
            if (!strchr(xv::StrStable(xv::sid::kDrBYNACDEFG), s[i])) return false;
        }
        return true;
    }

    void detect_rt()
    {
        FILE* f = fopen(xv::StrStable(xv::sid::kDrProcDevices), "r");
        if (!f) return;
        char line[256];
        bool inchar = false;
        while (fgets(line, sizeof(line), f)) {
            if (strstr(line, xv::StrStable(xv::sid::kDrCharacterDevices))) {
                inchar = true;
                continue;
            }
            if (strstr(line, xv::StrStable(xv::sid::kDrBlockDevices))) {
                inchar = false;
                continue;
            }
            if (!inchar) continue;
            int major = 0;
            char nm[64];
            memset(nm, 0, sizeof(nm));
            if (sscanf(line, xv::StrStable(xv::sid::kDrD63s), &major, nm) != 2) continue;
            if (!rt_name_ok(nm)) continue;
            char node[80];
            snprintf(node, sizeof(node), xv::StrStable(xv::sid::kDrDevS), nm);
            int c = open(node, O_RDWR);
            if (c < 0) {
                char mk[160];
                snprintf(mk, sizeof(mk), xv::StrStable(xv::sid::kDrMknodSCD02DevNull), node, major);
                system(mk);
                c = open(node, O_RDWR);
            }
            if (c >= 0) {
                fd = c;
                COPY_MEMORY probe;
                memset(&probe, 0, sizeof(probe));
                probe.pid = 0x7FFFFFFFu;
                probe.addr = 1;
                probe.size = 4;
                ioctl(fd, OP_READ_MEM, &probe);
                fclose(f);
                return;
            }
        }
        fclose(f);
    }

    void detect_qx()
    {
        char *output = execCom(xv::StrStable(xv::sid::kDrLsLProcExe2DevNullGrepEDataAZ6Deleted));
        if (output == NULL) return;

        char pidstr[32];
        char name[16];
        memset(pidstr, 0, sizeof(pidstr));
        memset(name, 0, sizeof(name));

        char* proc = strstr(output, xv::StrStable(xv::sid::kDrProc));
        if (proc != NULL) {
            char* ps = proc + 6;
            char* pe = strchr(ps, '/');
            if (pe != NULL) {
                size_t plen = (size_t)(pe - ps);
                if (plen < sizeof(pidstr)) {
                    memcpy(pidstr, ps, plen);
                    pidstr[plen] = '\0';
                }
            }
        }
        char* dp = strstr(output, xv::StrStable(xv::sid::kDrData));
        if (dp != NULL) {
            for (int i = 0; i < 6; i++) {
                char c = dp[6 + i];
                if (c < 'a' || c > 'z') {
                    break;
                }
                name[i] = c;
            }
        }
        free(output);

        if (name[0] == '\0' || pidstr[0] == '\0') return;

        int act = ioctl(fd, OP_ACTIVATE, 0);

        if (act != 0) {
            char procPath[64];
            snprintf(procPath, sizeof(procPath), xv::StrStable(xv::sid::kDrProcS), name);
            int candidate = open(procPath, O_RDWR);
            if (candidate < 0) return;
            fd = candidate;

            void* map = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (map != MAP_FAILED) {
                const char magic[2] = { '1', '\0' };
                for (int i = 0; i < 3; i++) {
                    char* rec = (char*)map + (size_t)i * 0x88;
                    rec[0] = 0;
                    memcpy(rec + 0x18, magic, sizeof(magic));
                }
                char rbuf[4];
                ::read(fd, rbuf, 0);
                ::read(fd, rbuf, 1);
                ::read(fd, rbuf, 2);
                munmap(map, 0x1000);
            }

            act = ioctl(fd, OP_ACTIVATE, 0);
            if (act != 0) return;
        }

        char cmd[256];
        snprintf(cmd, sizeof(cmd), xv::StrStable(xv::sid::kDrLsAlLProcSFd3), pidstr);
        char* fdInfo = execCom(cmd);
        int major = 0;
        int minor = 0;
        if (fdInfo != NULL) {
            sscanf(fdInfo, xv::StrStable(xv::sid::kDrSDSSDD), &major, &minor);
            free(fdInfo);
        }

        char node[64];
        snprintf(node, sizeof(node), xv::StrStable(xv::sid::kDrDevS), name);
        if (major > 0) {
            char mk[160];
            snprintf(mk, sizeof(mk), xv::StrStable(xv::sid::kDrMknodSCDD2DevNull), node, major, minor);
            system(mk);
        }
        int c = open(node, O_RDWR);
        if (c < 0) return;
        fd = c;

        COPY_MEMORY_QX probe;
        memset(&probe, 0, sizeof(probe));
        probe.pid = 0x7FFFFFFFu;
        probe.addr = 1;
        probe.size = 4;
        probe.flag = 1;
        ioctl(fd, OP_READ_MEM, &probe);
    }

public:
    c_driver(int kind) : fd(-1), pid(-1), kind(kind) {
        if (kind == 1) {
            detect_rt();
        } else if (kind == 2) {
            detect_qx();
        }
    }

    ~c_driver() {
        if (fd > 0)
            close(fd);
    }

    bool available() const {
        return fd >= 0;
    }

    void initialize(pid_t pid) {
        this->pid = pid;
    }

    bool read(uintptr_t addr, void *buffer, size_t size) {
        int r = -1;
        if (kind == 2) {
            COPY_MEMORY_QX cm;
            memset(&cm, 0, sizeof(cm));
            cm.pid = (uint32_t)this->pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            cm.flag = 1;
            r = ioctl(fd, OP_READ_MEM, &cm);
        } else {
            COPY_MEMORY cm;
            memset(&cm, 0, sizeof(cm));
            cm.pid = (uint32_t)this->pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            r = ioctl(fd, OP_READ_MEM, &cm);
        }

        if (r != 0) return false;
        return true;
    }

    bool write(uintptr_t addr, void *buffer, size_t size) {
        int r = -1;
        if (kind == 2) {
            COPY_MEMORY_QX cm;
            memset(&cm, 0, sizeof(cm));
            cm.pid = (uint32_t)this->pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            cm.flag = 2;
            r = ioctl(fd, OP_WRITE_MEM, &cm);
        } else {
            COPY_MEMORY cm;
            memset(&cm, 0, sizeof(cm));
            cm.pid = (uint32_t)this->pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            r = ioctl(fd, OP_WRITE_MEM, &cm);
        }

        if (r != 0) return false;
        return true;
    }

    template <typename T>
    T read(uintptr_t addr) {
        T res;
        if (this->read(addr, &res, sizeof(T)))
            return res;
        return {};
    }

    template <typename T>
    bool write(uintptr_t addr, T value) {
        return this->write(addr, &value, sizeof(T));
    }

    uintptr_t get_module_base(char* name) {
        MODULE_BASE mb;
        char buf[0x100];
        memset(buf, 0, sizeof(buf));
        strcpy(buf, name);
        memset(&mb, 0, sizeof(mb));
        mb.pid = (uint32_t)this->pid;
        mb.name = buf;
        mb.base = 0;

        int r = ioctl(fd, OP_MODULE_BASE, &mb);
        if (r != 0) {
            return 0;
        }
        return mb.base;
    }
};
