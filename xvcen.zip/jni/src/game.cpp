#include "weapon.h"
#include "xvstrings.h"
#include "game.h"
#include "Android_touch/TouchHelperA.h"
#include "offsets.h"
#include "offsets_beta.h"
#include "auth.h"
#include "xvseal.h"
#include "integrity.h"
#include "driver.h"

#include <string.h>
#include <sys/uio.h>
#include <fcntl.h>
#include <stdio.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <string>
#include <time.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <mutex>
#include <atomic>
#include <unistd.h>
#include <sys/syscall.h>

struct Vec2 {
    float x, y;
};

struct Vec3 {
    float x, y, z;
};

struct Vec4 {
    float x, y, z, w;
};

struct Mat4 {
    float m[16];
};

struct Matrix34 {
    Vec4 translation, rotation, scale;
};

static ssize_t vm_readv(pid_t pid, const struct iovec* local_iov, unsigned long liovcnt, const struct iovec* remote_iov, unsigned long riovcnt, unsigned long flags) {
    return syscall(__NR_process_vm_readv, pid, local_iov, liovcnt, remote_iov, riovcnt, flags);
}

using namespace game_offsets;

static bool g_is_beta = false;
void game_set_beta(bool is_beta) { g_is_beta = is_beta; }

static inline uint64_t net_client_rva()        { return g_is_beta ? game_offsets_beta::NETWORK_CLIENT_TYPEINFO_RVA    : NETWORK_CLIENT_TYPEINFO_RVA; }
static inline uint64_t game_controller_rva()   { return g_is_beta ? game_offsets_beta::GAME_CONTROLLER_TYPEINFO_RVA   : GAME_CONTROLLER_TYPEINFO_RVA; }
static inline uint64_t mu_typeinfo_rva()       { return g_is_beta ? game_offsets_beta::MU_TYPEINFO_RVA                : MU_TYPEINFO_RVA; }
static inline uint64_t dtl_typeinfo_rva()      { return g_is_beta ? game_offsets_beta::DTL_TYPEINFO_RVA               : DTL_TYPEINFO_RVA; }
static inline uint64_t sp_typeinfo_rva()       { return g_is_beta ? game_offsets_beta::SP_TYPEINFO_RVA                : SP_TYPEINFO_RVA; }
static inline uint64_t player_manager_rva() {
    if (!g_is_beta) return AuthGetPlayerManagerRva();
    const uint64_t from_server = AuthGetPlayerManagerRvaBeta();
    return from_server ? from_server : game_offsets_beta::PLAYER_MANAGER_TYPEINFO_RVA;
}
static inline uint64_t event_aim_action_offset()   { return g_is_beta ? game_offsets_beta::EVENT_AIM_ACTION        : EVENT_AIM_ACTION; }
static inline uint64_t event_sleep_offset()        { return g_is_beta ? game_offsets_beta::EVENT_SLEEP             : EVENT_SLEEP; }
static inline uint64_t hitscan_dispersion_offset() { return g_is_beta ? game_offsets_beta::HITSCAN_CONFIG_DISPERSION : HITSCAN_CONFIG_DISPERSION; }
static inline uint64_t hitscan_recoil_offset()     { return g_is_beta ? game_offsets_beta::HITSCAN_CONFIG_RECOIL     : HITSCAN_CONFIG_RECOIL; }
static inline uint64_t player_weapon_piece_offset(){ return g_is_beta ? game_offsets_beta::PLAYER_WEAPON_PIECE      : PLAYER_WEAPON_PIECE; }

static pid_t     g_pid         = -1;
static uint64_t  g_il2cpp_base = 0;

static c_driver* g_driver = nullptr;
static bool      g_driver_mode = false;
static int       g_driver_kind = 0;

static c_driver* ensure_driver() {
    if (!g_driver) g_driver = new c_driver(g_driver_kind);
    return g_driver;
}

bool game_driver_attach(int kind) {
    g_driver_kind = kind;
    c_driver* d = ensure_driver();
    bool ok = d && d->available();
    if (!ok) {
        if (g_driver) { delete g_driver; g_driver = nullptr; }
        return false;
    }
    g_driver_mode = true;
    return true;
}

bool game_driver_mode() {
    return g_driver_mode && g_driver && g_driver->available();
}

static int       g_no_recoil_mem_fd = -1;
static uint64_t  g_player_manager_class = 0;
static uint64_t  g_player_manager_static_fields = 0;
static uint64_t  g_game_controller_class = 0;
static uint64_t  g_network_client_class = 0;
static uint64_t  g_sp_class = 0;
static uint64_t  g_local_player = 0;

static std::vector<uint64_t> g_player_snapshot;
static uint64_t g_runtime_player_list = 0;
static uint64_t g_runtime_local_player = 0;
static double g_last_snapshot_success = 0.0;
static double g_last_snapshot_refresh_attempt = 0.0;

struct CachedOreWorld {
    Vec3 position;
    OreKind kind;
    uint64_t key = 0;
    double last_seen = 0.0;
    uint64_t identity = 0;
    uint64_t ore_behaviour = 0;
    float max_health = -1.0f;
    bool farmable = true;
    bool farmable_known = false;
};
static std::unordered_map<uint64_t, CachedOreWorld> g_ore_world_cache;

struct CachedWorldEntity {
    Vec3 position{};
    WorldKind kind = WorldKind::Lootbox;
    uint64_t key = 0;
    uint64_t behaviour = 0;
    uint64_t entity = 0;
    std::string name;
    double last_seen = 0.0;

    float bounds_center_dy = 0.0F;
    float bounds_half_y = 0.0F;
    bool have_bounds = false;
    float head_offset = 1.5F;

    uint64_t head_transform = 0;

};
static std::unordered_map<uint64_t, CachedWorldEntity> g_world_cache;

enum BehaviourClassFlags : uint32_t {
    kBehavNone            = 0u,
    kBehavOre             = 1u << 0,
    kBehavMineable        = 1u << 1,
    kBehavDeathHandler    = 1u << 2,
    kBehavNpcHumanDeath   = 1u << 3,
    kBehavBotBrain        = 1u << 4,
    kBehavCannibalBrain   = 1u << 5,
    kBehavAnimalBrain     = 1u << 6,
    kBehavRandomSpawnLoot = 1u << 7,
    kBehavLootObject      = 1u << 9,
    kBehavLootOnDeath     = 1u << 11,
    kBehavPlayerDeath     = 1u << 13,
    kBehavFish            = 1u << 14,
    kBehavCupboard        = 1u << 15,
    kBehavTurret          = 1u << 16,
};
static std::unordered_map<uint64_t, uint32_t> g_behaviour_class_flags;
static std::unordered_map<uint64_t, int> g_loot_kind_by_class;
static uint64_t g_object_name_offset = 0;

static uint64_t g_network_identity_class = 0;

static std::unordered_set<uint64_t> g_death_containers;

static std::unordered_set<uint64_t> g_player_backpacks;

struct WorldScanner {
    std::vector<uint64_t> identities;
    size_t cursor = 0;
    double last_dictionary_read = 0.0;
    double last_prune = 0.0;
    double cycle_started = 0.0;
    double last_cycle_duration = 0.0;
    double last_identities_ok = 0.0;
};
static WorldScanner g_scanner;
static int g_world_stat_bots_alive = 0;
struct RecoilAmplitudeBlock {
    Vec2 min_recoil{};
    Vec2 max_recoil{};
    float min_side_delta = 0.0F;
    float max_side_delta = 0.0F;
    float aim_multiplier = 0.0F;
};
static_assert(sizeof(RecoilAmplitudeBlock) == 28,
              "unexpected RecoilConfig amplitude layout");
struct MemoryNoRecoilState {
    uint64_t config = 0;
    RecoilAmplitudeBlock original{};
    bool original_valid = false;
};
static MemoryNoRecoilState g_memory_no_recoil{};


struct DispersionBlock {
    float min_fire = 0.0F;
    float max_fire = 0.0F;
    float min_dispersion = 0.0F;
    float max_dispersion = 0.0F;
    float increase_per_shot = 0.0F;
    float decrease_rate = 0.0F;
    float move_scale = 0.0F;
    float base_aim_factor = 0.0F;
    float move_aim_factor = 0.0F;
    float fire_aim_factor = 0.0F;
};
static_assert(sizeof(DispersionBlock) == 40,
              "unexpected DispersionConfig layout");
struct MemoryNoSpreadState {
    uint64_t config = 0;
    DispersionBlock original{};
    bool original_valid = false;
};
static MemoryNoSpreadState g_memory_no_spread{};

struct SkyAtmosphereBlock {
    float rayleigh = 0.0F;
    float mie = 0.0F;
    float brightness = 0.0F;
    float contrast = 0.0F;
    float directionality = 0.0F;
    float fogginess = 0.0F;
};
static_assert(sizeof(SkyAtmosphereBlock) == 24,
              "unexpected TOD_AtmosphereParameters layout");
struct SkyCloudBlock {
    float size = 0.0F;
    float opacity = 0.0F;
    float coverage = 0.0F;
    float sharpness = 0.0F;
    float attenuation = 0.0F;
    float saturation = 0.0F;
    float scattering = 0.0F;
    float brightness = 0.0F;
};
static_assert(sizeof(SkyCloudBlock) == 32,
              "unexpected TOD_CloudParameters layout");
struct SkyStarBlock {
    float size = 0.0F;
    float brightness = 0.0F;
};
static_assert(sizeof(SkyStarBlock) == 8,
              "unexpected TOD_StarParameters layout");
struct SkyParamSnapshot {
    SkyAtmosphereBlock atmosphere{};
    SkyCloudBlock clouds{};
    SkyStarBlock stars{};
};
struct MemoryBlackSkyState {
    uint64_t sky = 0;
    uint64_t atmosphere = 0;
    uint64_t clouds = 0;
    uint64_t stars = 0;
    SkyParamSnapshot original{};
    bool original_valid = false;
};
static MemoryBlackSkyState g_memory_black_sky{};

struct CrosshairColorBlock {
    float normal_r = 0.0F, normal_g = 0.0F, normal_b = 0.0F, normal_a = 0.0F;
    float entity_r = 0.0F, entity_g = 0.0F, entity_b = 0.0F, entity_a = 0.0F;
};
static_assert(sizeof(CrosshairColorBlock) == 32,
              "unexpected CrosshairData color layout");
struct MemoryCrosshairState {
    uint64_t data = 0;
    CrosshairColorBlock original{};
    bool original_valid = false;
};
static MemoryCrosshairState g_memory_crosshair{};

struct OverlayProjectionSnapshot {
    Vec3 camera_position{};
    Vec4 camera_rotation{};
    Mat4 view{};
    Mat4 proj{};
    bool have_view_proj = false;
    float screen_width = 0.0F;
    float screen_height = 0.0F;
    uint64_t local_player = 0;
    bool valid = false;
};

static OverlayProjectionSnapshot g_overlay_projection_snapshot{};

static std::atomic<bool> g_aspect_active{false};
static std::atomic<float> g_aspect_active_value{0.0F};
static OverlayProjectionSnapshot g_last_good_projection{};
static double g_last_good_projection_time = 0.0;

struct CameraMatricesCache {
    Mat4 view{};
    Mat4 proj{};
    Vec3 pos{};
    Vec4 rot{};
    float fov_y = 0.0F;
    float aspect = 1.0F;
    double last_success = 0.0;
};
static CameraMatricesCache g_camera_mats;
static Vec3 g_prev_pair_pos;
static Vec4 g_prev_pair_rot;
static Mat4 g_prev_pair_proj;
static bool g_prev_pair_valid = false;

static std::mutex g_game_mutex;

static uint64_t g_aim_locked_target = 0;
static int g_aim_locked_selection = -1;
static float g_aim_hipfire_proj_y = 0.0F;

static void restore_memory_no_recoil_unlocked();
static void restore_memory_hands_fov_unlocked();
static void restore_memory_black_sky_unlocked();
static void restore_memory_crosshair_unlocked();
static void hierarchy_cache_reset();
static void anim_bone_path_cache_begin_frame();

struct FreecamSaved {
    bool valid = false;
    float zmm[2] = {0.f, 0.f};
    float limits[4] = {-89.f, 89.f, -89.f, 89.f};
    Matrix34 rig_local{};
    Matrix34 parent_local{};
    bool rig_saved = false;
    bool parent_saved = false;
    uint64_t rig_transform = 0;
    uint64_t mouse_look = 0;
    uint64_t transform_data = 0;
    int32_t index = -1;
    uint64_t motor = 0;
    float motor_rotation[4] = {0.f, 0.f, 0.f, 1.f};
    uint64_t wallclip = 0;
    int32_t wallclip_mask = -1;
    float wallclip_radius = -1.f;
    float wallclip_min = -1.f;
    float gyro_sens = -1.f;
};
static FreecamSaved g_freecam;

static void invalidate_world_state() {
    restore_memory_no_recoil_unlocked();
    restore_memory_hands_fov_unlocked();
    restore_memory_black_sky_unlocked();
    g_player_snapshot.clear();
    g_ore_world_cache.clear();
    g_world_cache.clear();
    g_scanner = {};
    g_behaviour_class_flags.clear();
    g_loot_kind_by_class.clear();
    g_object_name_offset = 0;
    g_network_identity_class = 0;
    g_death_containers.clear();
    g_player_backpacks.clear();
    hierarchy_cache_reset();
    anim_bone_path_cache_begin_frame();
    g_overlay_projection_snapshot = {};
    g_last_good_projection = {};
    g_last_good_projection_time = 0.0;
    g_prev_pair_valid = false;
    g_camera_mats = {};
    g_network_client_class = 0;
    g_sp_class = 0;
    g_freecam = {};
    g_aim_locked_target = 0;
    g_aim_locked_selection = -1;
    g_aim_hipfire_proj_y = 0.0F;
    esp_request_fast_scan();
}

static bool likely_native_pointer(uint64_t value);
static uint64_t read_relative_ptr(uint64_t field);
static bool rd_bulk(uint64_t addr, void* dst, size_t size);
static void world_scan_tick();
static bool read_human_bone_world(uint64_t player, int32_t human, Vec3& target,
                                  bool dead = false);
static void read_dump_skeleton(uint64_t player, bool dead, Vec3 worlds[55],
                               uint8_t ok[55], Vec3 rag[32], int& rag_n);
template<typename T>
static T rd(uint64_t addr) {
    T v{};
    if (rd_bulk(addr, &v, sizeof(T))) return v;
    T zero{};
    return zero;
}
template<typename T>
static bool rd_exact(uint64_t addr, T& value) {
    value = {};
    if (!addr) return false;
    return rd_bulk(addr, &value, sizeof(T));
}

static uint64_t rd_ptr(uint64_t a) { return rd<uint64_t>(a); }

static bool rd_bulk(uint64_t addr, void* dst, size_t size) {
    if (!addr || !dst || !size) return false;
    if (g_driver_mode && g_driver && g_driver->available())
        return g_driver->read(addr, dst, size);
    struct iovec local = { dst, size };
    struct iovec remote = { (void*)addr, size };
    for (int attempt = 0; attempt < 3; ++attempt) {
        if (vm_readv(g_pid, &local, 1, &remote, 1, 0) == (ssize_t)size)
            return true;
    }
    return false;
}

static void close_no_recoil_memory_unlocked() {
    if (g_no_recoil_mem_fd >= 0) close(g_no_recoil_mem_fd);
    g_no_recoil_mem_fd = -1;
}

static bool ensure_no_recoil_memory_unlocked() {
    if (g_no_recoil_mem_fd >= 0) return true;
    if (g_pid <= 0) return false;
    char path[64]{};
    snprintf(path, sizeof(path), xv::StrStable(xv::sid::kGsProcDMem), (int)g_pid);
    g_no_recoil_mem_fd = open(path, O_RDWR | O_CLOEXEC);
    return g_no_recoil_mem_fd >= 0;
}

static bool wr_bulk(uint64_t addr, const void* src, size_t size) {
    if (g_pid <= 0 || !addr || !src || !size ||
        !IntegrityCheckpoint(0xa8c35f7192de460bULL ^ addr ^ static_cast<std::uint64_t>(size)))
        return false;
    if (g_driver_mode && g_driver && g_driver->available())
        return g_driver->write(addr, (void*)src, size);
    if (!ensure_no_recoil_memory_unlocked()) return false;
    return pwrite(g_no_recoil_mem_fd, src, size, (off_t)addr) ==
           (ssize_t)size;
}

static bool memory_block_equals(uint64_t addr, const void* expected, size_t size) {
    unsigned char current[64]{};
    if (size > sizeof(current)) return false;
    if (!rd_bulk(addr, current, size)) return false;
    return memcmp(current, expected, size) == 0;
}

static double monotonic_seconds() {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static std::string read_remote_string(uint64_t address) {
    if (!address) return {};
    char buffer[96]{};
    if (!rd_bulk(address, buffer, sizeof(buffer) - 1)) return {};
    buffer[sizeof(buffer) - 1] = '\0';
    return std::string(buffer);
}

static bool remote_string_equals(uint64_t address, const char* expected) {
    if (!address || !expected) return false;
    return read_remote_string(address) == expected;
}

static void append_utf8(std::string& output, uint32_t codepoint) {
    if (codepoint == 0 || codepoint > 0x10FFFF || (codepoint >= 0xD800 && codepoint <= 0xDFFF))
        codepoint = 0xFFFD;
    if (codepoint <= 0x7F) {
        output.push_back((char)codepoint);
    } else if (codepoint <= 0x7FF) {
        output.push_back((char)(0xC0 | (codepoint >> 6)));
        output.push_back((char)(0x80 | (codepoint & 0x3F)));
    } else if (codepoint <= 0xFFFF) {
        output.push_back((char)(0xE0 | (codepoint >> 12)));
        output.push_back((char)(0x80 | ((codepoint >> 6) & 0x3F)));
        output.push_back((char)(0x80 | (codepoint & 0x3F)));
    } else {
        output.push_back((char)(0xF0 | (codepoint >> 18)));
        output.push_back((char)(0x80 | ((codepoint >> 12) & 0x3F)));
        output.push_back((char)(0x80 | ((codepoint >> 6) & 0x3F)));
        output.push_back((char)(0x80 | (codepoint & 0x3F)));
    }
}

static std::string sanitize_player_name(std::string value) {

    std::string clean;
    clean.reserve(value.size());
    bool in_tag = false;
    for (unsigned char ch : value) {
        if (ch == '<') { in_tag = true; continue; }
        if (in_tag) { if (ch == '>') in_tag = false; continue; }
        if (ch < 0x20 || ch == 0x7F) {
            if (ch == '\t' || ch == '\n' || ch == '\r') clean.push_back(' ');
            continue;
        }
        clean.push_back((char)ch);
    }
    size_t first = clean.find_first_not_of(' ');
    if (first == std::string::npos) return {};
    size_t last = clean.find_last_not_of(' ');
    clean = clean.substr(first, last - first + 1);
    if (clean.size() > 72) {
        size_t cut = 72;
        while (cut > 0 && ((unsigned char)clean[cut] & 0xC0) == 0x80) --cut;
        clean.resize(cut);
    }
    return clean;
}

static std::string read_il2cpp_string(uint64_t string_object) {
    if (!string_object || !likely_native_pointer(string_object)) return {};
    int32_t length = 0;
    if (!rd_exact(string_object + IL2CPP_STRING_LENGTH, length) || length <= 0 ||
        length > 4096)
        return {};

    if (length > 96) length = 96;
    std::vector<uint16_t> chars((size_t)length);
    if (!rd_bulk(string_object + IL2CPP_STRING_CHARS, chars.data(), chars.size() * sizeof(uint16_t)))
        return {};

    std::string utf8;
    utf8.reserve((size_t)length * 2);
    for (int32_t index = 0; index < length; ++index) {
        uint32_t codepoint = chars[(size_t)index];
        if (codepoint >= 0xD800 && codepoint <= 0xDBFF && index + 1 < length) {
            uint32_t low = chars[(size_t)index + 1];
            if (low >= 0xDC00 && low <= 0xDFFF) {
                codepoint = 0x10000 + ((codepoint - 0xD800) << 10) + (low - 0xDC00);
                ++index;
            }
        }
        append_utf8(utf8, codepoint);
    }
    return sanitize_player_name(std::move(utf8));
}

static bool managed_object_is(uint64_t object, const char* expected_name) {
    if (!object || !expected_name) return false;
    uint64_t klass = rd_ptr(object);
    return klass && remote_string_equals(rd_ptr(klass + 0x10), expected_name);
}

static bool recoil_block_within(const RecoilAmplitudeBlock& block, float limit) {
    const float values[] = {
        block.min_recoil.x, block.min_recoil.y,
        block.max_recoil.x, block.max_recoil.y,
        block.min_side_delta, block.max_side_delta, block.aim_multiplier
    };
    for (float value : values)
        if (!std::isfinite(value) || fabsf(value) > limit) return false;
    return true;
}

static bool recoil_block_is_zero(const RecoilAmplitudeBlock& block) {
    return recoil_block_within(block, 0.0001F);
}

static bool recoil_block_is_plausible(const RecoilAmplitudeBlock& block) {
    return recoil_block_within(block, 1000.0F);
}

static bool dispersion_block_within(const DispersionBlock& block, float limit) {
    const float values[] = {
        block.min_fire, block.max_fire,
        block.min_dispersion, block.max_dispersion,
        block.increase_per_shot, block.decrease_rate, block.move_scale,
        block.base_aim_factor, block.move_aim_factor, block.fire_aim_factor
    };
    for (float value : values)
        if (!std::isfinite(value) || fabsf(value) > limit) return false;
    return true;
}

static bool dispersion_block_is_zero(const DispersionBlock& block) {
    return dispersion_block_within(block, 0.0001F);
}

static bool dispersion_block_is_plausible(const DispersionBlock& block) {
    return dispersion_block_within(block, 1000.0F);
}

static void restore_memory_no_spread_unlocked() {
    if (g_memory_no_spread.original_valid && g_memory_no_spread.config && g_pid > 0) {
        DispersionBlock current{};
        if (rd_bulk(g_memory_no_spread.config + DISPERSION_BLOCK,
                    &current, sizeof(current)) &&
            dispersion_block_is_zero(current)) {
            wr_bulk(g_memory_no_spread.config + DISPERSION_BLOCK,
                    &g_memory_no_spread.original,
                    sizeof(g_memory_no_spread.original));
        }
    }
    g_memory_no_spread = {};
}

static void restore_memory_no_recoil_unlocked() {
    if (g_memory_no_recoil.original_valid && g_memory_no_recoil.config && g_pid > 0) {
        RecoilAmplitudeBlock current{};

        if (rd_bulk(g_memory_no_recoil.config + RECOIL_AMPLITUDE_BLOCK,
                    &current, sizeof(current)) && recoil_block_is_zero(current)) {
            wr_bulk(g_memory_no_recoil.config + RECOIL_AMPLITUDE_BLOCK,
                    &g_memory_no_recoil.original,
                    sizeof(g_memory_no_recoil.original));
        }
    }
    g_memory_no_recoil = {};
}

static bool is_real_player_name(const std::string& value) {
    return !value.empty() && value.size() <= 72;
}

static std::string read_player_name(uint64_t player) {
    if (!player) return {};

    uint64_t event_handler = rd_ptr(player + PLAYER_EVENT_HANDLER);
    if (!likely_native_pointer(event_handler)) {
        return {};
    }
    uint64_t string_object = rd_ptr(event_handler + ENTITY_DISPLAY_NAME);
    if (!likely_native_pointer(string_object)) {
        return {};
    }
    std::string name = read_il2cpp_string(string_object);
    if (is_real_player_name(name)) {
        return name;
    }

    uint64_t nicklabel = rd_ptr(player + PLAYER_NICKLABEL);
    if (likely_native_pointer(nicklabel) &&
        rd_ptr(nicklabel + NICKLABEL_PLAYER) == player) {

        const std::uint64_t candidates[] = {
            NICKLABEL_NAME, NICKLABEL_NAME_ALT1, NICKLABEL_NAME_ALT2
        };
        for (std::uint64_t field : candidates) {
            std::string value = read_il2cpp_string(rd_ptr(nicklabel + field));
            if (is_real_player_name(value)) {
                        return value;
            }
        }
        uint64_t text = rd_ptr(nicklabel + NICKLABEL_NICKNAME_TEXT);
        if (likely_native_pointer(text)) {
            std::string ui = read_il2cpp_string(rd_ptr(text + UI_TEXT_M_TEXT));
            if (is_real_player_name(ui)) {
                        return ui;
            }
        }
    }

    return {};
}

static std::string read_team_name(uint64_t player) {
    if (!player) return {};
    return read_il2cpp_string(rd_ptr(player + PLAYER_TEAM_NAME));
}

static std::unordered_map<std::string, uint64_t> g_name_hash_cache;
static time_t g_local_name_report_time = 0;

static uint64_t cached_name_hash(const std::string& name) {
    if (name.empty()) return 0;
    auto it = g_name_hash_cache.find(name);
    if (it != g_name_hash_cache.end()) return it->second;
    if (g_name_hash_cache.size() > 512) g_name_hash_cache.clear();
    uint64_t hash = AuthPresenceNameHash(name);
    g_name_hash_cache.emplace(name, hash);
    return hash;
}

static bool name_is_xvcen_peer(const std::string& name,
                               const std::vector<uint64_t>& peers) {
    if (peers.empty() || name.empty()) return false;
    uint64_t hash = cached_name_hash(name);
    if (!hash) return false;
    for (uint64_t peer : peers) {
        if (peer == hash) return true;
    }
    return false;
}

static void report_local_player_name(uint64_t local_ptr) {
    if (!local_ptr) return;
    time_t now = time(nullptr);
    if (now - g_local_name_report_time < 3) return;
    g_local_name_report_time = now;
    std::string name = read_player_name(local_ptr);
    if (!name.empty()) AuthPresenceSetLocalName(name);
}

struct PeerTagEntry {
    double checked = 0.0;
    bool is_peer = false;
};
static std::unordered_map<uint64_t, PeerTagEntry> g_peer_tag_cache;
static double g_peer_tag_frame_time = 0.0;
static int g_peer_tag_budget = 0;

static bool player_is_xvcen_peer_cached(uint64_t player,
                                        const std::vector<uint64_t>& peers,
                                        double now) {
    if (peers.empty()) return false;
    if (g_peer_tag_cache.size() > 256) g_peer_tag_cache.clear();
    auto it = g_peer_tag_cache.find(player);
    if (it != g_peer_tag_cache.end()) {
        const double ttl = it->second.is_peer ? 2.0 : 0.5;
        if (now - it->second.checked < ttl) return it->second.is_peer;
    }
    if (g_peer_tag_budget <= 0)
        return it != g_peer_tag_cache.end() ? it->second.is_peer : false;
    --g_peer_tag_budget;
    PeerTagEntry entry;
    entry.checked = now;
    entry.is_peer = name_is_xvcen_peer(read_player_name(player), peers);
    g_peer_tag_cache[player] = entry;
    return entry.is_peer;
}

static bool players_are_teammates(uint64_t a, uint64_t b) {
    if (!a || !b) return false;
    std::string ta = read_team_name(a);
    if (ta.empty()) return false;
    return ta == read_team_name(b);
}

static bool read_player_health(uint64_t player, float& health, float& maximum) {
    health = maximum = -1.0F;
    uint64_t event_handler = rd_ptr(player + PLAYER_EVENT_HANDLER);
    uint64_t health_value = event_handler ? rd_ptr(event_handler + ENTITY_HEALTH_VALUE) : 0;
    uint64_t vitals = rd_ptr(player + PLAYER_VITALS);
    if (!health_value || !vitals) return false;

    float max_value = rd<float>(vitals + GENERIC_VITALS_MAX_HEALTH);
    float current = rd<float>(health_value + REASONED_VALUE_CURRENT);
    if (!std::isfinite(max_value) || max_value <= 0.0F || max_value > 100000.0F) return false;
    if (!std::isfinite(current) || current < 0.0F || current > max_value * 1.25F) {
        current = rd<float>(health_value + REASONED_VALUE_PREVIOUS);
    }
    if (!std::isfinite(current) || current < 0.0F || current > max_value * 1.25F) return false;
    health = std::max(0.0F, std::min(current, max_value));
    maximum = max_value;
    return true;
}

static std::vector<uint64_t> get_bases(const char* lib) {

    std::vector<uint64_t> bases;
    uintptr_t drv_base = 0;
    if (g_driver_mode && g_driver && g_driver->available()) {
        drv_base = g_driver->get_module_base((char*)lib);
    }
    char path[64]{};
    snprintf(path, sizeof(path), xv::StrC(xv::sid::kProcMaps), g_pid);
    FILE* file = fopen(path, "r");
    if (file) {
        char line[1024]{};
        char needle[96]{};
        snprintf(needle, sizeof(needle), xv::StrStable(xv::sid::kGsS), lib);
        while (fgets(line, sizeof(line), file)) {
            if (!strstr(line, needle)) continue;
            uint64_t start = 0, end = 0, file_offset = 0;
            char permissions[5]{};
            if (sscanf(line, xv::StrStable(xv::sid::kGsLxLx4sLx), &start, &end,
                       permissions, &file_offset) != 4) continue;
            if (file_offset != 0 || !start || (start & 0xFFFULL) != 0) continue;
            if (std::find(bases.begin(), bases.end(), start) == bases.end())
                bases.push_back(start);
        }
        fclose(file);
    }
    if (drv_base && std::find(bases.begin(), bases.end(), drv_base) == bases.end()) {
        bases.clear();
        bases.push_back(drv_base);
    }
    return bases;
}

static bool validate_player_list(uint64_t list, uint64_t player_class) {
    if (!list || !player_class) return false;
    uint64_t items = rd_ptr(list + IL2CPP_LIST_ITEMS);
    int32_t count = rd<int32_t>(list + IL2CPP_LIST_SIZE);
    if (!items || count < 0 || count > 512) return false;
    if (count == 0) {
        uint64_t list_class = rd_ptr(list);
        return remote_string_equals(rd_ptr(list_class + 0x10), xv::StrStable(xv::sid::kGsList1)) &&
            remote_string_equals(rd_ptr(list_class + 0x18), xv::StrStable(xv::sid::kGsSystemCollectionsGeneric));
    }
    int32_t checked = 0;
    for (int32_t index = 0; index < count && checked < 4; ++index) {
        uint64_t player = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)index * sizeof(uint64_t));
        if (!player) continue;
        if (rd_ptr(player) != player_class) return false;
        ++checked;
    }
    return checked > 0;
}

static constexpr uint64_t IL2CPP_CLASS_STATIC_FIELDS = 0xB8;

static uint64_t get_class_static_fields(uint64_t klass) {
    if (!klass) return 0;
    return rd_ptr(klass + IL2CPP_CLASS_STATIC_FIELDS);
}

static bool class_matches(uint64_t candidate,
                          const char* expected_name,
                          const char* expected_namespace) {
    if (candidate < 0x1000000000ULL || (candidate & 7ULL) != 0)
        return false;
    return remote_string_equals(rd_ptr(candidate + 0x10), expected_name) &&
           remote_string_equals(rd_ptr(candidate + 0x18), expected_namespace);
}

static uint64_t resolve_network_client_class() {
    if (g_network_client_class) return g_network_client_class;
    if (!g_il2cpp_base) return 0;
    uint64_t candidate = rd_ptr(g_il2cpp_base + net_client_rva());
    if (!candidate) return 0;
    std::string name = read_remote_string(rd_ptr(candidate + 0x10));
    std::string ns = read_remote_string(rd_ptr(candidate + 0x18));
    if (name == xv::StrStable(xv::sid::kGsNetworkClient) && ns == xv::StrStable(xv::sid::kGsMirror))
        g_network_client_class = candidate;
    return g_network_client_class;
}

static uint64_t resolve_runtime_player_list() {
    uint64_t player_mgr_rva = player_manager_rva();
    if (!g_player_manager_class && player_mgr_rva != 0) {
        uint64_t candidate = rd_ptr(g_il2cpp_base + player_mgr_rva);
        if (candidate) {
            std::string name = read_remote_string(rd_ptr(candidate + 0x10));
            std::string ns   = read_remote_string(rd_ptr(candidate + 0x18));
            if (name == xv::StrStable(xv::sid::kGsPlayerManager) && ns == xv::StrStable(xv::sid::kGsOxide))
                g_player_manager_class = candidate;
        }
    }
    if (!g_player_manager_class) {
        return 0;
    }
    if (!g_player_manager_static_fields)
        g_player_manager_static_fields = get_class_static_fields(g_player_manager_class);
    if (!g_player_manager_static_fields) {
        return 0;
    }
    uint64_t list = rd_ptr(g_player_manager_static_fields + PLAYER_MANAGER_STATIC_FIELDS_LIST);
    if (!validate_player_list(list, g_player_manager_class)) {
        g_player_manager_static_fields = 0;
        return 0;
    }
    return list;
}

static uint64_t resolve_local_player_uncached() {
    if (!g_game_controller_class && game_controller_rva() != 0) {
        uint64_t candidate = rd_ptr(g_il2cpp_base + game_controller_rva());
        if (candidate) {
            std::string name = read_remote_string(rd_ptr(candidate + 0x10));
            std::string ns   = read_remote_string(rd_ptr(candidate + 0x18));
            if (name == xv::StrStable(xv::sid::kGsGameControllerBase) && ns == xv::StrStable(xv::sid::kGsOxide))
                g_game_controller_class = candidate;
        }
    }

    if (!g_game_controller_class || !g_player_manager_class) return g_local_player;

    uint64_t gcb_static_fields = get_class_static_fields(g_game_controller_class);
    if (!gcb_static_fields) return g_local_player;
    uint64_t local_player = rd_ptr(gcb_static_fields + GAME_CONTROLLER_LOCAL_PLAYER_FIELD);
    if (local_player && rd_ptr(local_player) == g_player_manager_class) {
        g_local_player = local_player;
        return local_player;
    }

    if (g_local_player && rd_ptr(g_local_player) == g_player_manager_class)
        return g_local_player;
    g_local_player = 0;
    return 0;
}

static uint64_t resolve_local_player() {
    static thread_local double cached_at = -1.0;
    static thread_local uint64_t cached_value = 0;
    const double now = monotonic_seconds();
    if (cached_at >= 0.0 && (now - cached_at) < 0.006) return cached_value;
    const uint64_t value = resolve_local_player_uncached();
    cached_at = now;
    cached_value = value;
    return value;
}

static std::string resolve_weapon_piece_id(int16_t weapon_number) {
    if (weapon_number < 0 || !g_il2cpp_base) return {};
    uint64_t mu_typeinfo = rd_ptr(g_il2cpp_base + mu_typeinfo_rva());
    if (!mu_typeinfo || !likely_native_pointer(mu_typeinfo)) return {};
    uint64_t static_fields = get_class_static_fields(mu_typeinfo);
    if (!static_fields || !likely_native_pointer(static_fields)) return {};
    uint64_t mu_instance = rd_ptr(static_fields);
    if (!mu_instance || !likely_native_pointer(mu_instance)) return {};
    uint64_t resources = rd_ptr(mu_instance + 0x28);
    if (!resources || !likely_native_pointer(resources)) return {};
    uint64_t weapons_arr = rd_ptr(resources + 0x20);
    if (!weapons_arr || !likely_native_pointer(weapons_arr)) return {};
    int32_t len = rd<int32_t>(weapons_arr + IL2CPP_ARRAY_LENGTH);
    if (weapon_number >= 0 && weapon_number < len) {
        uint64_t piece = rd_ptr(weapons_arr + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)weapon_number * sizeof(uint64_t));
        if (piece && likely_native_pointer(piece)) {
            std::string id = read_il2cpp_string(rd_ptr(piece + 0x18));
            if (!id.empty()) return id;
        }
    }
    return {};
}

static bool read_player_held_weapon(uint64_t player, std::string& out_en, std::string& out_ru) {
    out_en.clear();
    out_ru.clear();
    if (!player || !likely_native_pointer(player)) return false;

    uint64_t weapon_ref = rd_ptr(player + PLAYER_WEAPON_REF);
    if (!likely_native_pointer(weapon_ref)) return false;

    uint64_t pw = rd_ptr(weapon_ref + INTERFACE_REFERENCE_COMPONENT);
    if (!pw) pw = rd_ptr(weapon_ref + INTERFACE_REFERENCE_VALUE);
    if (!likely_native_pointer(pw)) return false;

    const uint64_t piece_off = player_weapon_piece_offset();
    uint8_t enabled = rd<uint8_t>(pw + piece_off);
    if (!enabled) return false;

    int16_t number = rd<int16_t>(pw + piece_off + 2);
    std::string id = resolve_weapon_piece_id(number);
    if (id.empty()) return false;

    auto p = format_weapon_name(id);
    if (p.first.empty() && p.second.empty()) return false;

    out_en = p.first;
    out_ru = p.second;
    return true;
}

struct MemoryHandsFovState {
    uint64_t address = 0;
    float original_value = 0.0F;
    uint8_t original_flag = 0;
    bool original_valid = false;
};
static MemoryHandsFovState g_memory_hands_fov{};
static std::atomic<bool> g_hands_fov_run{false};
static std::atomic<int> g_hands_fov_fd{-1};
static std::atomic<uint64_t> g_hands_fov_addr{0};
static std::atomic<float> g_hands_fov_want{70.0F};
static pthread_t g_hands_fov_thread{};
static bool g_hands_fov_started = false;

static void* hands_fov_worker(void*) {
    while (g_hands_fov_run.load(std::memory_order_acquire)) {
        const int fd = g_hands_fov_fd.load(std::memory_order_acquire);
        uint64_t addr = g_hands_fov_addr.load(std::memory_order_acquire);
        float want = g_hands_fov_want.load(std::memory_order_relaxed);
        const uint8_t one = 1;
        if (g_driver_mode && g_driver && g_driver->available()) {
            if (addr) {
                g_driver->write(addr + 4, (void*)&want, sizeof(want));
                g_driver->write(addr, (void*)&one, 1);
            }
        } else if (fd >= 0 && addr) {
            pwrite(fd, &want, sizeof(want), (off_t)(addr + 4));
            pwrite(fd, &one, 1, (off_t)addr);
        }
        usleep(700);
    }
    return nullptr;
}

static void hands_fov_stop_worker() {
    if (!g_hands_fov_started) return;
    g_hands_fov_run.store(false, std::memory_order_release);
    pthread_join(g_hands_fov_thread, nullptr);
    g_hands_fov_started = false;
    const int fd = g_hands_fov_fd.exchange(-1, std::memory_order_acq_rel);
    if (fd >= 0) close(fd);
}

static void restore_memory_hands_fov_unlocked() {
    hands_fov_stop_worker();
    g_hands_fov_addr.store(0, std::memory_order_release);
    if (g_pid > 0 && g_memory_hands_fov.original_valid &&
        g_memory_hands_fov.address) {
        wr_bulk(g_memory_hands_fov.address + 4,
                &g_memory_hands_fov.original_value, sizeof(float));
        wr_bulk(g_memory_hands_fov.address,
                &g_memory_hands_fov.original_flag, 1);
    }
    g_memory_hands_fov = {};
}

void memory_hands_fov_update(bool enabled, float fov) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_hands_fov_unlocked();
        return;
    }

    uint64_t dtl_class = rd_ptr(g_il2cpp_base + dtl_typeinfo_rva());
    uint64_t static_fields = dtl_class ? get_class_static_fields(dtl_class) : 0;
    uint64_t controller = static_fields
        ? rd_ptr(static_fields + DTL_STATIC_INSTANCE) : 0;
    if (!likely_native_pointer(controller)) {
        restore_memory_hands_fov_unlocked();
        return;
    }

    const uint64_t address = controller + DTL_FOV_HAS_VALUE;

    if (g_memory_hands_fov.address != address ||
        !g_memory_hands_fov.original_valid) {
        restore_memory_hands_fov_unlocked();
        float value = 0.0F;
        uint8_t flag = 0;
        if (!rd_bulk(address + 4, &value, sizeof(value)) ||
            !rd_bulk(address, &flag, 1))
            return;
        if (flag > 1 || !std::isfinite(value)) return;
        g_memory_hands_fov.address = address;
        g_memory_hands_fov.original_value = value;
        g_memory_hands_fov.original_flag = flag;
        g_memory_hands_fov.original_valid = true;
    }

    float want = fov;
    if (!std::isfinite(want)) return;
    if (want < 20.0F) want = 20.0F;
    if (want > 120.0F) want = 120.0F;

    g_hands_fov_want.store(want, std::memory_order_relaxed);
    g_hands_fov_addr.store(address, std::memory_order_release);

    if (!g_hands_fov_started) {
        if (g_driver_mode && g_driver && g_driver->available()) {
            g_hands_fov_fd.store(-1, std::memory_order_release);
            g_hands_fov_run.store(true, std::memory_order_release);
            if (pthread_create(&g_hands_fov_thread, nullptr, hands_fov_worker,
                               nullptr) == 0) {
                g_hands_fov_started = true;
            } else {
                g_hands_fov_run.store(false, std::memory_order_release);
            }
        } else {
            char path[64]{};
            snprintf(path, sizeof(path), xv::StrStable(xv::sid::kGsProcDMem), (int)g_pid);
            const int fd = open(path, O_RDWR | O_CLOEXEC);
            if (fd < 0) return;
            g_hands_fov_fd.store(fd, std::memory_order_release);
            g_hands_fov_run.store(true, std::memory_order_release);
            if (pthread_create(&g_hands_fov_thread, nullptr, hands_fov_worker,
                               nullptr) == 0) {
                g_hands_fov_started = true;
            } else {
                g_hands_fov_run.store(false, std::memory_order_release);
                const int stale = g_hands_fov_fd.exchange(-1,
                                                          std::memory_order_acq_rel);
                if (stale >= 0) close(stale);
            }
        }
    }
}

void memory_no_recoil_update(bool enabled) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_no_recoil_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }

    if (!g_player_manager_class) resolve_runtime_player_list();
    uint64_t local_player = resolve_local_player();
    uint64_t fp_manager = local_player
        ? rd_ptr(local_player + PLAYER_FP_MANAGER) : 0;
    uint64_t weapon = fp_manager
        ? rd_ptr(fp_manager + FP_MANAGER_CURRENT_WEAPON) : 0;
    uint64_t weapon_config = weapon
        ? rd_ptr(weapon + FP_HITSCAN_CONFIG) : 0;
    if (!managed_object_is(weapon_config, xv::StrStable(xv::sid::kGsHitscanWeaponConfig))) {
        restore_memory_no_recoil_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }
    uint64_t recoil_config = rd_ptr(weapon_config + hitscan_recoil_offset());
    if (!managed_object_is(recoil_config, xv::StrStable(xv::sid::kGsRecoilConfig))) {
        restore_memory_no_recoil_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }

    if (g_memory_no_recoil.config != recoil_config ||
        !g_memory_no_recoil.original_valid) {
        restore_memory_no_recoil_unlocked();
        RecoilAmplitudeBlock original{};
        if (!rd_bulk(recoil_config + RECOIL_AMPLITUDE_BLOCK,
                     &original, sizeof(original)) ||
            !recoil_block_is_plausible(original)) {
            if (!g_freecam.valid) close_no_recoil_memory_unlocked();
            return;
        }
        g_memory_no_recoil.config = recoil_config;
        g_memory_no_recoil.original = original;
        g_memory_no_recoil.original_valid = true;
    }

    const RecoilAmplitudeBlock zero{};

    RecoilAmplitudeBlock live{};
    if (rd_bulk(recoil_config + RECOIL_AMPLITUDE_BLOCK, &live, sizeof(live)) &&
        !recoil_block_is_zero(live)) {
        wr_bulk(recoil_config + RECOIL_AMPLITUDE_BLOCK, &zero, sizeof(zero));
    }

    uint64_t event_handler = rd_ptr(local_player + PLAYER_EVENT_HANDLER);
    uint64_t recoil_observable = event_handler
        ? rd_ptr(event_handler + EVENT_RECOIL_OBSERVABLE) : 0;
    if (recoil_observable) {
        
        Vec2 current_recoil{};
        if (rd_bulk(recoil_observable + OBSERVABLE_VALUE,
                    &current_recoil, sizeof(current_recoil)) &&
            (fabsf(current_recoil.x) > 0.0001F ||
             fabsf(current_recoil.y) > 0.0001F)) {
            const Vec2 cleared{};
            wr_bulk(recoil_observable + OBSERVABLE_VALUE,
                    &cleared, sizeof(cleared));
        }
    }
}

void memory_no_spread_update(bool enabled) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_no_spread_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }

    if (!g_player_manager_class) resolve_runtime_player_list();
    uint64_t local_player = resolve_local_player();
    uint64_t fp_manager = local_player
        ? rd_ptr(local_player + PLAYER_FP_MANAGER) : 0;
    uint64_t weapon = fp_manager
        ? rd_ptr(fp_manager + FP_MANAGER_CURRENT_WEAPON) : 0;
    uint64_t weapon_config = weapon
        ? rd_ptr(weapon + FP_HITSCAN_CONFIG) : 0;
    if (!managed_object_is(weapon_config, xv::StrStable(xv::sid::kGsHitscanWeaponConfig))) {
        restore_memory_no_spread_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }
    uint64_t dispersion_config = rd_ptr(weapon_config + hitscan_dispersion_offset());
    if (!managed_object_is(dispersion_config, xv::StrStable(xv::sid::kGsDispersionConfig))) {
        restore_memory_no_spread_unlocked();
        if (!g_freecam.valid) close_no_recoil_memory_unlocked();
        return;
    }

    if (g_memory_no_spread.config != dispersion_config ||
        !g_memory_no_spread.original_valid) {
        restore_memory_no_spread_unlocked();
        DispersionBlock original{};
        if (!rd_bulk(dispersion_config + DISPERSION_BLOCK,
                     &original, sizeof(original)) ||
            !dispersion_block_is_plausible(original)) {
            if (!g_freecam.valid) close_no_recoil_memory_unlocked();
            return;
        }
        g_memory_no_spread.config = dispersion_config;
        g_memory_no_spread.original = original;
        g_memory_no_spread.original_valid = true;
    }

    const DispersionBlock zero{};

    DispersionBlock live{};
    if (rd_bulk(dispersion_config + DISPERSION_BLOCK, &live, sizeof(live)) &&
        !dispersion_block_is_zero(live)) {
        wr_bulk(dispersion_config + DISPERSION_BLOCK, &zero, sizeof(zero));
    }
}

template<size_t N>
static bool sky_floats_within(const float (&values)[N], float limit) {
    for (float value : values)
        if (!std::isfinite(value) || fabsf(value) > limit) return false;
    return true;
}

template<size_t N>
static bool sky_floats_zero(const float (&values)[N]) {
    return sky_floats_within(values, 0.0001F);
}

template<size_t N>
static bool sky_floats_plausible(const float (&values)[N]) {
    return sky_floats_within(values, 10000.0F);
}

static bool sky_snapshot_is_zero(const SkyParamSnapshot& snap) {
    const float atmosphere[] = {
        snap.atmosphere.rayleigh, snap.atmosphere.mie,
        snap.atmosphere.brightness, snap.atmosphere.contrast,
        snap.atmosphere.directionality, snap.atmosphere.fogginess
    };
    const float clouds[] = {
        snap.clouds.size, snap.clouds.opacity, snap.clouds.coverage,
        snap.clouds.sharpness, snap.clouds.attenuation,
        snap.clouds.saturation, snap.clouds.scattering, snap.clouds.brightness
    };
    const float stars[] = { snap.stars.size, snap.stars.brightness };
    return sky_floats_zero(atmosphere) && sky_floats_zero(clouds) &&
           sky_floats_zero(stars);
}

static bool sky_snapshot_is_plausible(const SkyParamSnapshot& snap) {
    const float atmosphere[] = {
        snap.atmosphere.rayleigh, snap.atmosphere.mie,
        snap.atmosphere.brightness, snap.atmosphere.contrast,
        snap.atmosphere.directionality, snap.atmosphere.fogginess
    };
    const float clouds[] = {
        snap.clouds.size, snap.clouds.opacity, snap.clouds.coverage,
        snap.clouds.sharpness, snap.clouds.attenuation,
        snap.clouds.saturation, snap.clouds.scattering, snap.clouds.brightness
    };
    const float stars[] = { snap.stars.size, snap.stars.brightness };
    return sky_floats_plausible(atmosphere) && sky_floats_plausible(clouds) &&
           sky_floats_plausible(stars);
}

struct MemoryDayState {
    uint64_t cycle = 0;
    float original_hour = -1.0F;
    bool original_valid = false;
};
static MemoryDayState g_memory_day{};

static void restore_memory_day_unlocked() {
    MemoryDayState& st = g_memory_day;
    if (st.original_valid && st.cycle && st.original_hour >= 0.0F &&
        g_pid > 0) {
        float cur_hour = 0.0f;
        if (rd_exact(st.cycle + SP_CYCLE_HOUR, cur_hour) && fabsf(cur_hour - 12.0f) < 0.05f) {
            wr_bulk(st.cycle + SP_CYCLE_HOUR, &st.original_hour,
                    sizeof(st.original_hour));
        }
    }
    st = {};
}

static void restore_memory_black_sky_unlocked() {
    MemoryBlackSkyState& st = g_memory_black_sky;
    if (st.original_valid && st.sky && st.atmosphere && st.clouds &&
        st.stars && g_pid > 0) {
        SkyAtmosphereBlock cur_atm{};
        SkyCloudBlock cur_clouds{};
        SkyStarBlock cur_stars{};
        if (rd_bulk(st.atmosphere + SP_PARAM_FIELDS_START,
                    &cur_atm, sizeof(cur_atm)) &&
            rd_bulk(st.clouds + SP_PARAM_FIELDS_START,
                    &cur_clouds, sizeof(cur_clouds)) &&
            rd_bulk(st.stars + SP_PARAM_FIELDS_START,
                    &cur_stars, sizeof(cur_stars))) {
            SkyParamSnapshot current{cur_atm, cur_clouds, cur_stars};
            if (sky_snapshot_is_zero(current)) {
                wr_bulk(st.atmosphere + SP_PARAM_FIELDS_START,
                        &st.original.atmosphere,
                        sizeof(st.original.atmosphere));
                wr_bulk(st.clouds + SP_PARAM_FIELDS_START,
                        &st.original.clouds,
                        sizeof(st.original.clouds));
                wr_bulk(st.stars + SP_PARAM_FIELDS_START,
                        &st.original.stars,
                        sizeof(st.original.stars));
            }
        }
    }
    st = {};
}

static uint64_t resolve_sp_class() {
    if (g_sp_class) return g_sp_class;
    if (!g_il2cpp_base) return 0;
    uint64_t candidate = rd_ptr(g_il2cpp_base + sp_typeinfo_rva());
    if (candidate && class_matches(candidate, g_is_beta ? "kL" : "IY", ""))
        g_sp_class = candidate;
    return g_sp_class;
}

static uint64_t resolve_sp_instance() {
    uint64_t sp_class = resolve_sp_class();
    if (!sp_class) return 0;
    uint64_t static_fields = get_class_static_fields(sp_class);
    if (!static_fields) return 0;
    uint64_t list = rd_ptr(static_fields);
    if (!list) return 0;
    uint64_t items = rd_ptr(list + IL2CPP_LIST_ITEMS);
    int32_t count = rd<int32_t>(list + IL2CPP_LIST_SIZE);
    if (!items || count <= 0 || count > 64) return 0;
    for (int32_t index = 0; index < count; ++index) {
        uint64_t sky = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT +
                              (uint64_t)index * sizeof(uint64_t));
        if (sky && rd_ptr(sky) == sp_class) return sky;
    }
    return 0;
}

void memory_black_sky_update(bool enabled) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_black_sky_unlocked();
        return;
    }

    uint64_t sky = resolve_sp_instance();
    if (!sky) {
        restore_memory_black_sky_unlocked();
        return;
    }
    uint64_t atmosphere = rd_ptr(sky + SP_FIELD_ATMOSPHERE);
    uint64_t stars = rd_ptr(sky + SP_FIELD_STARS);
    uint64_t clouds = rd_ptr(sky + SP_FIELD_CLOUDS);
    if (!atmosphere || !stars || !clouds) {
        restore_memory_black_sky_unlocked();
        return;
    }

    if (g_memory_black_sky.sky != sky ||
        g_memory_black_sky.atmosphere != atmosphere ||
        g_memory_black_sky.stars != stars ||
        g_memory_black_sky.clouds != clouds ||
        !g_memory_black_sky.original_valid) {
        restore_memory_black_sky_unlocked();
        SkyAtmosphereBlock orig_atm{};
        SkyCloudBlock orig_clouds{};
        SkyStarBlock orig_stars{};
        if (!rd_bulk(atmosphere + SP_PARAM_FIELDS_START,
                     &orig_atm, sizeof(orig_atm)) ||
            !rd_bulk(clouds + SP_PARAM_FIELDS_START,
                     &orig_clouds, sizeof(orig_clouds)) ||
            !rd_bulk(stars + SP_PARAM_FIELDS_START,
                     &orig_stars, sizeof(orig_stars))) {
            return;
        }
        SkyParamSnapshot original{orig_atm, orig_clouds, orig_stars};
        if (!sky_snapshot_is_plausible(original)) {
            return;
        }
        g_memory_black_sky.sky = sky;
        g_memory_black_sky.atmosphere = atmosphere;
        g_memory_black_sky.clouds = clouds;
        g_memory_black_sky.stars = stars;
        g_memory_black_sky.original = original;
        g_memory_black_sky.original_valid = true;
    }

    const SkyAtmosphereBlock zero_atm{};
    const SkyCloudBlock zero_clouds{};
    const SkyStarBlock zero_stars{};
    if (!memory_block_equals(atmosphere + SP_PARAM_FIELDS_START,
                             &zero_atm, sizeof(zero_atm)))
        wr_bulk(atmosphere + SP_PARAM_FIELDS_START, &zero_atm,
                sizeof(zero_atm));
    if (!memory_block_equals(clouds + SP_PARAM_FIELDS_START,
                             &zero_clouds, sizeof(zero_clouds)))
        wr_bulk(clouds + SP_PARAM_FIELDS_START, &zero_clouds,
                sizeof(zero_clouds));
    if (!memory_block_equals(stars + SP_PARAM_FIELDS_START,
                             &zero_stars, sizeof(zero_stars)))
        wr_bulk(stars + SP_PARAM_FIELDS_START, &zero_stars,
                sizeof(zero_stars));
}

void memory_always_day_update(bool enabled) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_day_unlocked();
        return;
    }

    uint64_t sky = resolve_sp_instance();
    if (!sky) {
        restore_memory_day_unlocked();
        return;
    }
    uint64_t cycle = rd_ptr(sky + SP_FIELD_CYCLE);
    if (!cycle) {
        restore_memory_day_unlocked();
        return;
    }

    if (g_memory_day.cycle != cycle || !g_memory_day.original_valid) {
        restore_memory_day_unlocked();
        float orig_hour = -1.0F;
        if (!rd_exact(cycle + SP_CYCLE_HOUR, orig_hour) ||
            !std::isfinite(orig_hour)) {
            return;
        }
        g_memory_day.cycle = cycle;
        g_memory_day.original_hour = orig_hour;
        g_memory_day.original_valid = true;
    }

    const float noon = 12.0F;
    float current = 0.0F;
    if (!rd_exact(cycle + SP_CYCLE_HOUR, current) ||
        fabsf(current - noon) > 0.02F)
        wr_bulk(cycle + SP_CYCLE_HOUR, &noon, sizeof(noon));
}

static bool crosshair_colors_plausible(const CrosshairColorBlock& block) {
    const float values[] = {
        block.normal_r, block.normal_g, block.normal_b, block.normal_a,
        block.entity_r, block.entity_g, block.entity_b, block.entity_a
    };
    for (float value : values)
        if (!std::isfinite(value) || value < 0.0F || value > 2.0F) return false;
    return (block.normal_a > 0.05f || block.entity_a > 0.05f);
}

static bool crosshair_colors_zero_alpha(const CrosshairColorBlock& block) {
    return fabsf(block.normal_a) < 0.001F && fabsf(block.entity_a) < 0.001F;
}

static void restore_memory_crosshair_unlocked() {
    MemoryCrosshairState& st = g_memory_crosshair;
    if (st.original_valid && st.data && g_pid > 0) {
        CrosshairColorBlock current{};
        if (rd_bulk(st.data + CROSSHAIR_DATA_COLOR_BLOCK,
                    &current, sizeof(current)) &&
            crosshair_colors_zero_alpha(current)) {
            wr_bulk(st.data + CROSSHAIR_DATA_COLOR_BLOCK,
                    &st.original, sizeof(st.original));
        }
    } else if (st.data && g_pid > 0) {
        CrosshairColorBlock current{};
        if (rd_bulk(st.data + CROSSHAIR_DATA_COLOR_BLOCK,
                    &current, sizeof(current)) &&
            crosshair_colors_zero_alpha(current)) {
            CrosshairColorBlock def{1.f, 1.f, 1.f, 1.f, 1.f, 0.f, 0.f, 1.f};
            wr_bulk(st.data + CROSSHAIR_DATA_COLOR_BLOCK,
                    &def, sizeof(def));
        }
    }
    st = {};
}

static uint64_t resolve_crosshair_data() {
    if (!g_game_controller_class && game_controller_rva() != 0) {
        uint64_t candidate = rd_ptr(g_il2cpp_base + game_controller_rva());
        if (candidate) {
            std::string name = read_remote_string(rd_ptr(candidate + 0x10));
            std::string ns   = read_remote_string(rd_ptr(candidate + 0x18));
            if (name == xv::StrStable(xv::sid::kGsGameControllerBase) && ns == xv::StrStable(xv::sid::kGsOxide))
                g_game_controller_class = candidate;
        }
    }
    if (!g_game_controller_class) return 0;
    uint64_t static_fields = get_class_static_fields(g_game_controller_class);
    if (!static_fields) return 0;
    uint64_t controller = rd_ptr(
        static_fields + GAME_CONTROLLER_STATIC_INSTANCE_FIELD);
    if (!controller || rd_ptr(controller) != g_game_controller_class) return 0;
    uint64_t manager = rd_ptr(
        controller + GAME_CONTROLLER_CROSSHAIR_MANAGER_FIELD);
    if (!manager) return 0;
    uint64_t data = rd_ptr(manager + CROSSHAIR_MANAGER_ACTIVE_FIELD);
    if (!data)
        data = rd_ptr(manager + CROSSHAIR_MANAGER_DEFAULT_FIELD);
    if (!data ||
        !managed_object_is(data, xv::StrStable(xv::sid::kGsCrosshairData))) return 0;
    return data;
}

void memory_crosshair_update(bool enabled) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        restore_memory_crosshair_unlocked();
        return;
    }

    uint64_t data = resolve_crosshair_data();
    if (!data) {
        restore_memory_crosshair_unlocked();
        return;
    }

    if (g_memory_crosshair.data != data ||
        !g_memory_crosshair.original_valid) {
        restore_memory_crosshair_unlocked();
        CrosshairColorBlock original{};
        if (!rd_bulk(data + CROSSHAIR_DATA_COLOR_BLOCK,
                     &original, sizeof(original)) ||
            !crosshair_colors_plausible(original)) {
            return;
        }
        g_memory_crosshair.data = data;
        g_memory_crosshair.original = original;
        g_memory_crosshair.original_valid = true;
    }

    CrosshairColorBlock hidden = g_memory_crosshair.original;
    hidden.normal_a = 0.0F;
    hidden.entity_a = 0.0F;

    CrosshairColorBlock live{};
    if (!rd_bulk(data + CROSSHAIR_DATA_COLOR_BLOCK, &live, sizeof(live)) ||
        fabsf(live.normal_a) > 0.001F || fabsf(live.entity_a) > 0.001F) {
        wr_bulk(data + CROSSHAIR_DATA_COLOR_BLOCK, &hidden, sizeof(hidden));
    }
}

static uint64_t resolve_native_transform(uint64_t transform) {
    if (!transform) return 0;
    return rd_ptr(transform + MANAGED_CACHED_PTR);
}

static bool vec3_is_finite(const Vec3& value) {
    return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z) &&
        fabsf(value.x) < 1000000.0F && fabsf(value.y) < 1000000.0F && fabsf(value.z) < 1000000.0F;
}

static Vec3 cross_product(const Vec3& left, const Vec3& right) {
    return {left.y * right.z - left.z * right.y, left.z * right.x - left.x * right.z, left.x * right.y - left.y * right.x};
}

static Vec3 rotate_vector(const Vec4& quaternion, const Vec3& vector) {
    Vec3 q = {quaternion.x, quaternion.y, quaternion.z};
    Vec3 first_cross = cross_product(q, vector);
    Vec3 doubled = {first_cross.x * 2.0F, first_cross.y * 2.0F, first_cross.z * 2.0F};
    Vec3 second_cross = cross_product(q, doubled);
    return {vector.x + quaternion.w * doubled.x + second_cross.x, vector.y + quaternion.w * doubled.y + second_cross.y, vector.z + quaternion.w * doubled.z + second_cross.z};
}

static Vec4 multiply_quaternion(const Vec4& left, const Vec4& right) {
    return {
        left.w * right.x + left.x * right.w + left.y * right.z - left.z * right.y,
        left.w * right.y - left.x * right.z + left.y * right.w + left.z * right.x,
        left.w * right.z + left.x * right.y - left.y * right.x + left.z * right.w,
        left.w * right.w - left.x * right.x - left.y * right.y - left.z * right.z
    };
}

static bool normalize_quaternion(Vec4& quaternion) {
    float length_squared = quaternion.x * quaternion.x + quaternion.y * quaternion.y + quaternion.z * quaternion.z + quaternion.w * quaternion.w;
    if (!std::isfinite(length_squared) || length_squared < 0.000001F) return false;
    float inverse_length = 1.0F / sqrtf(length_squared);
    quaternion.x *= inverse_length; quaternion.y *= inverse_length; quaternion.z *= inverse_length; quaternion.w *= inverse_length;
    return true;
}

static bool matrix34_is_valid(const Matrix34& matrix) {

    const float values[] = {
        matrix.translation.x, matrix.translation.y, matrix.translation.z,
        matrix.rotation.x, matrix.rotation.y, matrix.rotation.z, matrix.rotation.w,
        matrix.scale.x, matrix.scale.y, matrix.scale.z
    };
    for (float value : values) {
        if (!std::isfinite(value) || fabsf(value) > 1000000.0F) return false;
    }

    float quaternion_length = matrix.rotation.x * matrix.rotation.x +
                              matrix.rotation.y * matrix.rotation.y +
                              matrix.rotation.z * matrix.rotation.z +
                              matrix.rotation.w * matrix.rotation.w;
    if (!(quaternion_length >= 0.50F && quaternion_length <= 1.60F)) return false;
    return fabsf(matrix.scale.x) <= 10000.0F &&
           fabsf(matrix.scale.y) <= 10000.0F &&
           fabsf(matrix.scale.z) <= 10000.0F;
}

struct HierarchySnapshot {
    std::vector<Matrix34> matrices;
    std::vector<int32_t>  parents;
    uint64_t data = 0;
    uint64_t matrices_addr = 0;
    uint64_t indices_addr = 0;
    double   taken = 0.0;
    bool     filled = false;
};
static std::unordered_map<uint64_t, HierarchySnapshot> g_hierarchy_cache;
static double g_hierarchy_epoch = 0.0;

static void hierarchy_cache_reset() {
    g_hierarchy_cache.clear();
}

static void hierarchy_cache_begin_frame() {
    const double now = monotonic_seconds();
    for (auto it = g_hierarchy_cache.begin(); it != g_hierarchy_cache.end();) {
        const bool stale = it->second.taken > 0.0 &&
                           now - it->second.taken > 2.0;
        if (stale || it->second.matrices.capacity() > 8192) {
            it = g_hierarchy_cache.erase(it);
        } else {
            it->second.filled = false;
            ++it;
        }
    }
    g_hierarchy_epoch = now;
}

struct AnimatorBonePath {
    uint64_t bone_table = 0;
    std::vector<int32_t> skeleton_bones;
    int32_t human_inline[25]{};
    int32_t human_left[15]{};
    int32_t human_right[15]{};
    bool have_left = false;
    bool have_right = false;
    uint8_t fast = 0;
    uint64_t fast_array = 0;
    std::vector<uint8_t> entries_block;
    bool valid = false;
    bool filled = false;
};
static std::unordered_map<uint64_t, AnimatorBonePath> g_anim_bone_path_cache;

static void anim_bone_path_cache_begin_frame() {
    if (g_anim_bone_path_cache.size() > 256) {
        g_anim_bone_path_cache.clear();
        return;
    }
    for (auto it = g_anim_bone_path_cache.begin();
         it != g_anim_bone_path_cache.end();) {
        if (it->second.entries_block.capacity() > 65536) {
            it = g_anim_bone_path_cache.erase(it);
        } else {
            it->second.filled = false;
            ++it;
        }
    }
}

static const AnimatorBonePath* animator_bone_path(uint64_t anim) {
    if (!likely_native_pointer(anim)) return nullptr;
    auto it = g_anim_bone_path_cache.find(anim);
    if (it != g_anim_bone_path_cache.end() && it->second.filled)
        return it->second.valid ? &it->second : nullptr;

    AnimatorBonePath& path = it != g_anim_bone_path_cache.end()
        ? it->second
        : g_anim_bone_path_cache[anim];
    path.filled = true;
    path.valid = false;
    path.have_left = false;
    path.have_right = false;
    path.fast = 0;
    path.fast_array = 0;
    path.bone_table = 0;
    do {

        if (rd<uint8_t>(anim + NATIVE_ANIMATOR_BONE_MAP_BUILT) == 0) break;
        uint64_t avatar = rd_ptr(anim + NATIVE_ANIMATOR_AVATAR);
        if (!likely_native_pointer(avatar)) break;
        uint64_t data = read_relative_ptr(avatar + NATIVE_AVATAR_DATA);
        if (!data) break;
        uint64_t count_base = read_relative_ptr(data + NATIVE_AVATAR_DATA_COUNT);
        int32_t human_count = count_base ? rd<int32_t>(count_base) : 0;
        if (human_count <= 0 || human_count > 4096) break;

        if (!rd_bulk(data + NATIVE_AVATAR_HUMAN_BONES, path.human_inline,
                     sizeof(path.human_inline)))
            break;
        uint64_t left = read_relative_ptr(data + NATIVE_AVATAR_HUMAN_BONES_LEFT);
        if (left) {
            path.have_left = rd_bulk(left, path.human_left, sizeof(path.human_left));
        }
        uint64_t right = read_relative_ptr(data + NATIVE_AVATAR_HUMAN_BONES_RIGHT);
        if (right) {
            path.have_right = rd_bulk(right, path.human_right, sizeof(path.human_right));
        }

        uint64_t table = read_relative_ptr(avatar + NATIVE_AVATAR_BONE_TABLE);
        if (!table) break;
        if (path.skeleton_bones.size() != (size_t)human_count)
            path.skeleton_bones.resize((size_t)human_count);
        if (!rd_bulk(table, path.skeleton_bones.data(),
                     path.skeleton_bones.size() * sizeof(int32_t)))
            break;
        path.bone_table = table;

        uint64_t map = rd_ptr(anim + NATIVE_ANIMATOR_TRANSFORM_MAP);
        if (!likely_native_pointer(map)) break;
        path.fast = rd<uint8_t>(anim + NATIVE_ANIMATOR_FAST_BONE_FLAG);
        if (path.fast) {
            path.fast_array = rd_ptr(map + NATIVE_TRANSFORM_MAP_ARRAY);
            if (!likely_native_pointer(path.fast_array)) break;
        } else {
            uint64_t count = rd_ptr(map + NATIVE_TRANSFORM_MAP_COUNT);
            uint64_t entries = rd_ptr(map + NATIVE_TRANSFORM_MAP_ENTRIES);
            if (!count || count > NATIVE_TRANSFORM_MAP_MAX_ENTRIES ||
                !likely_native_pointer(entries))
                break;
            const size_t block = (size_t)count * NATIVE_TRANSFORM_MAP_ENTRY_SIZE;
            if (path.entries_block.size() != block)
                path.entries_block.resize(block);
            if (!rd_bulk(entries, path.entries_block.data(), path.entries_block.size()))
                break;
        }
        path.valid = true;
    } while (false);

    return path.valid ? &path : nullptr;
}

static const HierarchySnapshot* hierarchy_snapshot(uint64_t transform_data) {
    if (!transform_data) return nullptr;
    auto cached = g_hierarchy_cache.find(transform_data);
    if (cached != g_hierarchy_cache.end() && cached->second.filled)
        return cached->second.matrices.empty() ? nullptr : &cached->second;

    HierarchySnapshot& snap = cached != g_hierarchy_cache.end()
        ? cached->second
        : g_hierarchy_cache[transform_data];
    snap.filled = true;
    snap.data = transform_data;
    snap.taken = g_hierarchy_epoch;

    int32_t capacity = rd<int32_t>(transform_data + NATIVE_TRANSFORM_HIERARCHY_CAPACITY);
    uint64_t count_ptr = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_COUNT_PTR);
    int32_t count = count_ptr ? rd<int32_t>(count_ptr) : 0;
    int32_t slots = capacity > 0 ? capacity : count;
    if (count > slots) slots = count;

    uint64_t matrices = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_MATRICES);
    uint64_t indices  = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_INDICES);
    if (slots <= 0 || slots > 65536 || !matrices || !indices) {
        snap.matrices.clear();
        snap.parents.clear();
        return nullptr;
    }

    snap.matrices_addr = matrices;
    snap.indices_addr = indices;
    if (snap.matrices.size() != (size_t)slots) snap.matrices.resize((size_t)slots);
    if (snap.parents.size() != (size_t)slots) snap.parents.resize((size_t)slots);
    if (!rd_bulk(matrices, snap.matrices.data(),
                 snap.matrices.size() * sizeof(Matrix34)) ||
        !rd_bulk(indices, snap.parents.data(),
                 snap.parents.size() * sizeof(int32_t))) {
        snap.matrices.clear();
        snap.parents.clear();
        return nullptr;
    }

    return &snap;
}

static bool hierarchy_matrix_at(const HierarchySnapshot& snap, int32_t index,
                                Matrix34& out) {
    out = snap.matrices[(size_t)index];
    if (matrix34_is_valid(out)) return true;
    if (!snap.matrices_addr) return false;
    for (int attempt = 0; attempt < 2; ++attempt) {
        Matrix34 live{};
        if (rd_exact(snap.matrices_addr + (uint64_t)index * sizeof(Matrix34), live) &&
            matrix34_is_valid(live)) {
            out = live;
            return true;
        }
    }
    return false;
}

static bool read_transform_hierarchy_snapshot(const HierarchySnapshot& snap,
                                              int32_t transform_index,
                                              Vec3& position,
                                              Vec4* world_rotation) {
    const int32_t count = (int32_t)snap.matrices.size();
    if (transform_index < 0 || transform_index >= count) {
        return false;
    }

    Matrix34 current{};
    if (!hierarchy_matrix_at(snap, transform_index, current)) {
        return false;
    }
    Vec3 result = {current.translation.x, current.translation.y, current.translation.z};
    Vec4 result_rotation = current.rotation;
    if (!vec3_is_finite(result)) return false;

    int32_t parent = snap.parents[(size_t)transform_index];
    int32_t previous_parent = transform_index;
    int depth = 0;
    while (parent >= 0 && depth++ < 256) {
        if (parent >= count || parent == previous_parent) {
            return false;
        }
        Matrix34 matrix{};
        if (!hierarchy_matrix_at(snap, parent, matrix)) {
            return false;
        }
        Vec3 scaled = {result.x * matrix.scale.x, result.y * matrix.scale.y, result.z * matrix.scale.z};
        Vec3 rotated = rotate_vector(matrix.rotation, scaled);
        result = {matrix.translation.x + rotated.x, matrix.translation.y + rotated.y, matrix.translation.z + rotated.z};
        result_rotation = multiply_quaternion(matrix.rotation, result_rotation);
        if (!vec3_is_finite(result)) return false;
        previous_parent = parent;
        parent = snap.parents[(size_t)parent];
    }

    if (parent != -1 || depth >= 256 || !vec3_is_finite(result)) {
        return false;
    }
    if (world_rotation) {
        if (!normalize_quaternion(result_rotation)) return false;
        *world_rotation = result_rotation;
    }
    position = result;
    return true;
}

static bool read_transform_hierarchy_direct(uint64_t matrices, uint64_t indices,
                                            int32_t transform_index,
                                            Vec3& position, Vec4* world_rotation) {
    if (!matrices || !indices || transform_index < 0 || transform_index > 100000)
        return false;
    Matrix34 current{};
    if (!rd_exact(matrices + (uint64_t)transform_index * sizeof(Matrix34), current) ||
        !matrix34_is_valid(current))
        return false;
    Vec3 result = {current.translation.x, current.translation.y, current.translation.z};
    Vec4 result_rotation = current.rotation;
    if (!vec3_is_finite(result)) return false;

    int32_t parent = -2;
    if (!rd_exact(indices + (uint64_t)transform_index * sizeof(int32_t), parent))
        return false;
    int32_t previous_parent = transform_index;
    int depth = 0;
    while (parent >= 0 && depth++ < 256) {
        if (parent > 100000 || parent == previous_parent) return false;
        Matrix34 matrix{};
        if (!rd_exact(matrices + (uint64_t)parent * sizeof(Matrix34), matrix) ||
            !matrix34_is_valid(matrix))
            return false;
        Vec3 scaled = {result.x * matrix.scale.x, result.y * matrix.scale.y, result.z * matrix.scale.z};
        Vec3 rotated = rotate_vector(matrix.rotation, scaled);
        result = {matrix.translation.x + rotated.x, matrix.translation.y + rotated.y, matrix.translation.z + rotated.z};
        result_rotation = multiply_quaternion(matrix.rotation, result_rotation);
        if (!vec3_is_finite(result)) return false;
        previous_parent = parent;
        if (!rd_exact(indices + (uint64_t)parent * sizeof(int32_t), parent)) return false;
    }
    if (parent != -1 || depth >= 256 || !vec3_is_finite(result)) return false;
    if (world_rotation) {
        if (!normalize_quaternion(result_rotation)) return false;
        *world_rotation = result_rotation;
    }
    position = result;
    return true;
}

static bool read_transform_hierarchy_layout(uint64_t native_transform, Vec3& position, Vec4* world_rotation = nullptr) {
    if (!native_transform) return false;
    uint64_t transform_data = rd_ptr(native_transform + NATIVE_TRANSFORM_HIERARCHY_DATA);
    int32_t transform_index = rd<int32_t>(native_transform + NATIVE_TRANSFORM_HIERARCHY_INDEX);
    if (!transform_data || transform_index < 0) return false;

    const HierarchySnapshot* snap = hierarchy_snapshot(transform_data);
    if (snap && read_transform_hierarchy_snapshot(*snap, transform_index,
                                                  position, world_rotation))
        return true;

    uint64_t matrices = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_MATRICES);
    uint64_t indices  = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_INDICES);
    return read_transform_hierarchy_direct(matrices, indices, transform_index,
                                           position, world_rotation);
}

static bool read_transform_hierarchy_position(uint64_t native_transform, Vec3& position) {
    return read_transform_hierarchy_layout(native_transform, position);
}

static uint64_t resolve_player_native_transform(uint64_t player) {
    if (!player) return 0;
    return resolve_native_transform(rd_ptr(player + PLAYER_TRANSFORM));
}

static bool likely_native_pointer(uint64_t value) {
    return value >= 0x10000 && value < 0x0001000000000000ULL && (value & 0x7) == 0;
}

static bool read_native_xform_pose(uint64_t native, Vec3& position, Vec4& rotation) {
    return read_transform_hierarchy_layout(native, position, &rotation);
}

static uint64_t resolve_managed_component_transform(uint64_t managed_component) {
    if (!managed_component) return 0;
    uint64_t native_component = rd_ptr(managed_component + MANAGED_CACHED_PTR);
    uint64_t game_object = native_component ? rd_ptr(native_component + NATIVE_COMPONENT_GAMEOBJECT) : 0;
    uint64_t component_table = game_object ? rd_ptr(game_object + NATIVE_GAMEOBJECT_COMPONENTS) : 0;
    uint64_t transform = component_table ? rd_ptr(component_table + NATIVE_GAMEOBJECT_TRANSFORM_SLOT) : 0;
    if (!likely_native_pointer(transform) ||
        rd_ptr(transform + NATIVE_COMPONENT_GAMEOBJECT) != game_object)
        return 0;
    return transform;
}

static uint64_t resolve_camera_manager() {
    if (!g_game_controller_class) return 0;
    uint64_t static_fields = get_class_static_fields(g_game_controller_class);
    if (!static_fields) return 0;
    return rd_ptr(static_fields + GAME_CONTROLLER_CAMERA_MANAGER_FIELD);
}

static uint64_t resolve_player_death_handler(uint64_t player) {
    if (!player) return 0;
    uint64_t reference = rd_ptr(player + PLAYER_DEATH_HANDLER_REF);
    if (reference < 0x10000) return 0;
    uint64_t handler = rd_ptr(reference + INTERFACE_REFERENCE_COMPONENT);
    if (handler < 0x10000) handler = rd_ptr(reference + INTERFACE_REFERENCE_VALUE);
    return handler >= 0x10000 ? handler : 0;
}

static uint64_t resolve_player_ragdoll(uint64_t player) {
    uint64_t handler = resolve_player_death_handler(player);
    if (!handler) return 0;
    uint64_t ragdoll = rd_ptr(handler + PLAYER_DEATH_RAGDOLL);
    return likely_native_pointer(ragdoll) ? ragdoll : 0;
}

static bool read_ragdoll_pelvis_world(uint64_t player, Vec3& position) {
    uint64_t ragdoll = resolve_player_ragdoll(player);
    if (!ragdoll) return false;
    uint64_t pelvis = rd_ptr(ragdoll + RAGDOLL_PELVIS);
    uint64_t xf = resolve_managed_component_transform(pelvis);
    return xf && read_transform_hierarchy_position(xf, position) && vec3_is_finite(position);
}

static bool player_is_dead_or_spectating(uint64_t player) {
    if (!player) return false;
    uint64_t handler = resolve_player_death_handler(player);
    if (handler && rd<uint8_t>(handler + PLAYER_DEATH_FLAG) != 0)
        return true;
    float health = -1.0F, maximum = -1.0F;
    if (read_player_health(player, health, maximum) && health <= 0.01F)
        return true;
    return false;
}

static bool read_render_camera_pose(uint64_t, Vec3& position, Vec4& rotation) {
    uint64_t cam_mgr = resolve_camera_manager();
    uint64_t managed_cam = cam_mgr ? rd_ptr(cam_mgr + CAMERA_MANAGER_CAMERA_FIELD) : 0;
    uint64_t cam_xform = resolve_managed_component_transform(managed_cam);
    return cam_xform && read_native_xform_pose(cam_xform, position, rotation);
}

static uint64_t resolve_player_kcc(uint64_t player) {
    if (!player) return 0;
    uint64_t reference = rd_ptr(player + PLAYER_KCC_REFERENCE);
    if (reference < 0x10000) return 0;
    const uint64_t candidates[] = {
        rd_ptr(reference + INTERFACE_REFERENCE_COMPONENT),
        rd_ptr(reference + INTERFACE_REFERENCE_VALUE)
    };
    for (uint64_t candidate : candidates) {
        if (candidate < 0x10000) continue;

        if (rd_ptr(candidate + KCC_PLAYER) == player) return candidate;
    }
    return 0;
}

static bool read_best_player_position(uint64_t player, Vec3& position) {
    uint64_t native = resolve_player_native_transform(player);
    Vec3 eye{};
    if (!native || !read_transform_hierarchy_position(native, eye)) return false;
    position = {eye.x, eye.y - 1.62F, eye.z};
    return vec3_is_finite(position);
}


static Vec4 mat4_mul_point(const Mat4& matrix, float x, float y, float z, float w) {

    Vec4 out{};
    out.x = matrix.m[0] * x + matrix.m[4] * y + matrix.m[8] * z + matrix.m[12] * w;
    out.y = matrix.m[1] * x + matrix.m[5] * y + matrix.m[9] * z + matrix.m[13] * w;
    out.z = matrix.m[2] * x + matrix.m[6] * y + matrix.m[10] * z + matrix.m[14] * w;
    out.w = matrix.m[3] * x + matrix.m[7] * y + matrix.m[11] * z + matrix.m[15] * w;
    return out;
}

static bool w2s_view_proj(const Mat4& view, const Mat4& proj,
                          const Vec3& world, float screen_width, float screen_height,
                          Vec2& output, bool clip_to_screen) {
    if (screen_width < 100.0F || screen_height < 100.0F) return false;
    Vec4 cam = mat4_mul_point(view, world.x, world.y, world.z, 1.0F);
    Vec4 clip = mat4_mul_point(proj, cam.x, cam.y, cam.z, cam.w);

    if (!std::isfinite(clip.x) || !std::isfinite(clip.y) ||
        !std::isfinite(clip.z) || !std::isfinite(clip.w) || clip.w <= 0.05F)
        return false;
    float inv_w = 1.0F / clip.w;
    float ndc_x = clip.x * inv_w;
    float ndc_y = clip.y * inv_w;
    if (!std::isfinite(ndc_x) || !std::isfinite(ndc_y)) return false;
    if (clip_to_screen && (fabsf(ndc_x) > 1.0F || fabsf(ndc_y) > 1.0F)) return false;
    output.x = (ndc_x + 1.0F) * 0.5F * screen_width;
    output.y = (1.0F - ndc_y) * 0.5F * screen_height;
    return std::isfinite(output.x) && std::isfinite(output.y);
}

static uint64_t resolve_native_camera();

static bool proj_matrix_is_valid(const Mat4& p) {
    for (int i = 0; i < 16; ++i)
        if (!std::isfinite(p.m[i]) || fabsf(p.m[i]) > 1.0e6F) return false;
    if (fabsf(p.m[3]) > 1.0e-3F || fabsf(p.m[7]) > 1.0e-3F ||
        fabsf(p.m[15]) > 1.0e-3F)
        return false;
    if (fabsf(p.m[0]) < 1.0e-4F || fabsf(p.m[5]) < 0.05F ||
        fabsf(p.m[5]) > 40.0F)
        return false;
    return true;
}

static float proj_aspect_of(const Mat4& p) {
    return fabsf(p.m[0] / p.m[5]);
}

static bool proj_aspect_matches_screen(const Mat4& p, float sw, float sh) {
    if (sw < 100.0F || sh < 100.0F) return true;
    const float aspect = proj_aspect_of(p);
    if (g_aspect_active.load(std::memory_order_acquire)) {
        const float want = g_aspect_active_value.load(
            std::memory_order_relaxed);
        if (std::isfinite(want) && want > 0.05F)
            return fabsf(aspect - want) <= want * 0.25F;
        return true;
    }
    const float screen_aspect = sw / sh;
    return fabsf(aspect - screen_aspect) <= screen_aspect * 0.08F;
}

static bool proj_aspect_close_to_last(const Mat4& p) {
    if (g_aspect_active.load(std::memory_order_acquire)) return true;
    if (!g_last_good_projection.valid) return true;
    const float aspect = proj_aspect_of(p);
    const float last_aspect = proj_aspect_of(g_last_good_projection.proj);
    if (last_aspect < 0.01F) return true;
    return fabsf(aspect - last_aspect) <= last_aspect * 0.05F;
}

static bool read_proj_matrix(uint64_t native_camera, Mat4& proj) {
    if (!native_camera) return false;
    Mat4 a{}, b{};
    for (int attempt = 0; attempt < 8; ++attempt) {
        if (!rd_bulk(native_camera + CAMERA_PROJECTION_MATRIX, &a, sizeof(Mat4)))
            return false;
        if (!rd_bulk(native_camera + CAMERA_PROJECTION_MATRIX, &b, sizeof(Mat4)))
            return false;
        if (memcmp(&a, &b, sizeof(Mat4)) == 0) {
            proj = a;
            return proj_matrix_is_valid(proj);
        }
        usleep(120);
    }
    return false;
}

static Mat4 view_from_pose(const Vec3& pos, const Vec4& q) {
    const float x = q.x, y = q.y, z = q.z, w = q.w;
    const float m00 = 1.0F - 2.0F * (y * y + z * z);
    const float m01 = 2.0F * (x * y - z * w);
    const float m02 = 2.0F * (x * z + y * w);
    const float m10 = 2.0F * (x * y + z * w);
    const float m11 = 1.0F - 2.0F * (x * x + z * z);
    const float m12 = 2.0F * (y * z - x * w);
    const float m20 = 2.0F * (x * z - y * w);
    const float m21 = 2.0F * (y * z + x * w);
    const float m22 = 1.0F - 2.0F * (x * x + y * y);
    Mat4 view{};
    view.m[0] = m00; view.m[4] = m10; view.m[8] = m20;
    view.m[1] = m01; view.m[5] = m11; view.m[9] = m21;
    view.m[2] = -m02; view.m[6] = -m12; view.m[10] = -m22;
    view.m[12] = -(m00 * pos.x + m10 * pos.y + m20 * pos.z);
    view.m[13] = -(m01 * pos.x + m11 * pos.y + m21 * pos.z);
    view.m[14] = m02 * pos.x + m12 * pos.y + m22 * pos.z;
    view.m[3] = 0.0F; view.m[7] = 0.0F; view.m[11] = 0.0F; view.m[15] = 1.0F;
    return view;
}

static bool read_camera_pose_fresh(uint64_t native_transform,
                                   Vec3& position, Vec4& rotation) {
    if (!native_transform) return false;
    uint64_t transform_data =
        rd_ptr(native_transform + NATIVE_TRANSFORM_HIERARCHY_DATA);
    int32_t transform_index =
        rd<int32_t>(native_transform + NATIVE_TRANSFORM_HIERARCHY_INDEX);
    if (!transform_data || transform_index < 0) return false;
    uint64_t matrices =
        rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_MATRICES);
    uint64_t indices =
        rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_INDICES);
    if (!matrices || !indices) return false;
    return read_transform_hierarchy_direct(matrices, indices, transform_index,
                                           position, &rotation);
}

static Mat4 build_proj_from_fov(float fov_y_deg, float aspect) {
    Mat4 p{};
    const float kDeg = 3.14159265F / 180.0F;
    const float t = tanf(fov_y_deg * 0.5F * kDeg);
    if (!std::isfinite(t) || t < 0.01F || t > 100.0F ||
        !std::isfinite(aspect) || aspect < 0.2F || aspect > 5.0F)
        return p;
    p.m[0] = 1.0F / (t * aspect);
    p.m[5] = 1.0F / t;
    p.m[10] = -1.0001F;
    p.m[11] = -1.0F;
    p.m[14] = -0.1F;
    return p;
}

static bool g_overlay_camera_sampled_this_frame = false;

static bool project_world(const OverlayProjectionSnapshot& snap, const Vec3& world,
                          float sw, float sh, Vec2& output, bool clip_to_screen) {
    if (!snap.have_view_proj) return false;
    return w2s_view_proj(snap.view, snap.proj, world, sw, sh, output,
                         clip_to_screen);
}

static bool sample_overlay_camera_now(uint64_t local_player, float sw, float sh) {
    OverlayProjectionSnapshot snap{};
    snap.screen_width = sw;
    snap.screen_height = sh;
    snap.local_player = local_player;

    uint64_t camera_managed = 0;
    uint64_t camera_transform = 0;
    auto resolve_camera_pose_sources = [&]() {
        uint64_t cam_mgr = resolve_camera_manager();
        camera_managed = cam_mgr
            ? rd_ptr(cam_mgr + CAMERA_MANAGER_CAMERA_FIELD) : 0;
        camera_transform =
            resolve_managed_component_transform(camera_managed);
    };
    resolve_camera_pose_sources();

    auto read_consistent_pair = [&](Vec3& pos, Vec4& rot, Mat4& proj_out) {
        Vec3 pos_a{}, pos_b{};
        Vec4 rot_a{}, rot_b{};
        Mat4 proj_a{}, proj_b{};
        uint64_t native_camera = camera_managed
            ? rd_ptr(camera_managed + MANAGED_CACHED_PTR) : 0;
        if (!(read_camera_pose_fresh(camera_transform, pos_a, rot_a) &&
              read_proj_matrix(native_camera, proj_a) &&
              read_proj_matrix(native_camera, proj_b) &&
              read_camera_pose_fresh(camera_transform, pos_b, rot_b) &&
              memcmp(&pos_a, &pos_b, sizeof(Vec3)) == 0 &&
              memcmp(&rot_a, &rot_b, sizeof(Vec4)) == 0 &&
              memcmp(&proj_a, &proj_b, sizeof(Mat4)) == 0))
            return false;
        pos = pos_b;
        rot = rot_b;
        proj_out = proj_b;
        return true;
    };

    Vec3 cam_pos{};
    Vec4 cam_rot{};
    Mat4 proj{};
    bool have_pair = false;
    for (int attempt = 0; attempt < 8 && !have_pair; ++attempt) {
        if (!read_consistent_pair(cam_pos, cam_rot, proj)) {
            usleep(120);
            resolve_camera_pose_sources();
            continue;
        }
        if (!g_prev_pair_valid ||
            memcmp(&cam_pos, &g_prev_pair_pos, sizeof(Vec3)) != 0 ||
            memcmp(&cam_rot, &g_prev_pair_rot, sizeof(Vec4)) != 0 ||
            memcmp(&proj, &g_prev_pair_proj, sizeof(Mat4)) != 0) {
            bool stable = false;
            for (int wait = 0; wait < 4 && !stable; ++wait) {
                Vec3 pos2{};
                Vec4 rot2{};
                Mat4 proj2{};
                usleep(4000);
                if (!read_consistent_pair(pos2, rot2, proj2)) break;
                if (memcmp(&pos2, &cam_pos, sizeof(Vec3)) == 0 &&
                    memcmp(&rot2, &cam_rot, sizeof(Vec4)) == 0 &&
                    memcmp(&proj2, &proj, sizeof(Mat4)) == 0) {
                    stable = true;
                } else {
                    cam_pos = pos2;
                    cam_rot = rot2;
                    proj = proj2;
                }
            }
            if (!stable && g_prev_pair_valid) {
                cam_pos = g_prev_pair_pos;
                cam_rot = g_prev_pair_rot;
                proj = g_prev_pair_proj;
            }
        }
        have_pair = true;
    }

    if (have_pair) {
        g_prev_pair_pos = cam_pos;
        g_prev_pair_rot = cam_rot;
        g_prev_pair_proj = proj;
        g_prev_pair_valid = true;
    }

    const double now = monotonic_seconds();
    const bool grace_pose = g_camera_mats.last_success > 0.0 &&
        now - g_camera_mats.last_success < CAMERA_STALE_GRACE_SECONDS;
    const bool have_fov = g_camera_mats.fov_y > 1.0F &&
        g_camera_mats.aspect > 0.2F && g_camera_mats.aspect < 5.0F;

    if (!have_pair) {
        if (!grace_pose || !have_fov) return false;
        proj = build_proj_from_fov(g_camera_mats.fov_y,
                                   g_camera_mats.aspect);
    } else if (!proj_aspect_matches_screen(proj, sw, sh) &&
               !proj_aspect_close_to_last(proj)) {
        if (!have_fov) return false;
        proj = build_proj_from_fov(g_camera_mats.fov_y,
                                   g_camera_mats.aspect);
    }

    if (have_pair) {
        g_camera_mats.proj = proj;
        g_camera_mats.fov_y = 2.0F * atanf(1.0F / proj.m[5]) *
                              (180.0F / 3.14159265F);
        g_camera_mats.aspect = fabsf(proj.m[5] / proj.m[0]);
    }
    g_camera_mats.last_success = now;

    if (have_pair) {
        snap.view = view_from_pose(cam_pos, cam_rot);
        g_camera_mats.view = snap.view;
        g_camera_mats.pos = cam_pos;
        g_camera_mats.rot = cam_rot;
        snap.camera_position = cam_pos;
        snap.camera_rotation = cam_rot;
    } else {
        snap.view = g_camera_mats.view;
        snap.camera_position = g_camera_mats.pos;
        snap.camera_rotation = g_camera_mats.rot;
    }
    snap.proj = proj;
    snap.have_view_proj = true;

    snap.valid = true;
    g_overlay_projection_snapshot = snap;
    g_last_good_projection = snap;
    g_last_good_projection_time = now;
    return true;
}

static bool sample_overlay_camera(uint64_t local_player, float sw, float sh) {
    if (g_overlay_camera_sampled_this_frame &&
        g_overlay_projection_snapshot.valid)
        return true;
    if (sample_overlay_camera_now(local_player, sw, sh)) {
        g_overlay_camera_sampled_this_frame = true;
        return true;
    }
    g_overlay_camera_sampled_this_frame = true;
    if (g_last_good_projection.valid &&
        monotonic_seconds() - g_last_good_projection_time <
            CAMERA_STALE_GRACE_SECONDS) {
        g_overlay_projection_snapshot = g_last_good_projection;
        return true;
    }
    return false;
}

static uint64_t resolve_native_camera() {
    uint64_t camera_manager = resolve_camera_manager();
    uint64_t managed_camera = camera_manager
        ? rd_ptr(camera_manager + CAMERA_MANAGER_CAMERA_FIELD) : 0;
    return managed_camera ? rd_ptr(managed_camera + MANAGED_CACHED_PTR) : 0;
}

static std::vector<uint64_t> read_configured_player_transforms() {
    std::vector<uint64_t> transforms;
    uint64_t list = g_runtime_player_list;
    if (list && g_player_manager_static_fields) {
        uint64_t live_list = rd_ptr(g_player_manager_static_fields + PLAYER_MANAGER_STATIC_FIELDS_LIST);
        if (live_list != list) list = 0;
    }
    if (list) {
        uint64_t items = rd_ptr(list + IL2CPP_LIST_ITEMS);
        int32_t count = rd<int32_t>(list + IL2CPP_LIST_SIZE);
        if (!items || count < 0 || count > 512) list = 0;
    }
    if (!list) list = resolve_runtime_player_list();
    if (!list) return transforms;

    uint64_t local_player = resolve_local_player();

    if (list && list != g_runtime_player_list)
        invalidate_world_state();
    if (list) g_runtime_player_list = list;
    if (local_player && g_runtime_local_player != local_player)
        invalidate_world_state();
    if (local_player) g_runtime_local_player = local_player;

    uint64_t items = rd_ptr(list + IL2CPP_LIST_ITEMS);
    int32_t count = rd<int32_t>(list + IL2CPP_LIST_SIZE);
    if (!items || count <= 0 || count > 512) return transforms;

    transforms.reserve((size_t)count + 1);
    if (local_player) transforms.push_back(local_player);
    for (int32_t index = 0; index < count; ++index) {
        uint64_t player = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)index * sizeof(uint64_t));
        if (!player || player == local_player) continue;
        if (g_player_manager_class && rd_ptr(player) != g_player_manager_class) continue;
        transforms.push_back(player);
    }
    return transforms;
}

static const std::vector<uint64_t>& refresh_player_snapshot() {
    double now = monotonic_seconds();

    if (now - g_last_snapshot_refresh_attempt < 0.002)
        return g_player_snapshot;
    g_last_snapshot_refresh_attempt = now;

    std::vector<uint64_t> refreshed = read_configured_player_transforms();
    if (!refreshed.empty()) {
        g_player_snapshot = std::move(refreshed);
        g_last_snapshot_success = now;
    } else if (g_last_snapshot_success <= 0.0 || now - g_last_snapshot_success > 0.05) {

        g_player_snapshot.clear();
    }
    return g_player_snapshot;
}

static void reset_all_state_unlocked() {
    restore_memory_no_recoil_unlocked();
    restore_memory_hands_fov_unlocked();
    restore_memory_black_sky_unlocked();
    restore_memory_day_unlocked();
    restore_memory_crosshair_unlocked();
    close_no_recoil_memory_unlocked();
    g_pid = -1;
    g_il2cpp_base = 0;
    g_player_manager_class = 0;
    g_player_manager_static_fields = 0;
    g_game_controller_class = 0;
    g_local_player = 0;
    g_runtime_player_list = 0;
    g_runtime_local_player = 0;
    g_last_snapshot_success = 0.0;
    g_last_snapshot_refresh_attempt = 0.0;
    invalidate_world_state();
}

bool esp_init(pid_t pid) {
    if (pid <= 0 || !IntegrityRevalidate(0x91d74b2e6ac8503fULL ^ static_cast<std::uint64_t>(pid))) return false;
    std::lock_guard<std::mutex> lock(g_game_mutex);
    reset_all_state_unlocked();
    g_pid = pid;
    if (g_driver_mode && g_driver) g_driver->initialize(pid);

    uint64_t player_mgr_rva = player_manager_rva();
    if (!player_mgr_rva) return false;

    std::vector<uint64_t> candidates = get_bases(xv::StrC(xv::sid::kModuleIl2cpp));
    for (uint64_t base : candidates) {
        uint32_t elf_magic = 0;
        bool rok = rd_exact(base, elf_magic);
        if (!rok || elf_magic != 0x464C457FU) continue;
        uint64_t player_class = rd_ptr(base + player_mgr_rva);
        if (!class_matches(player_class, xv::StrStable(xv::sid::kGsPlayerManager), xv::StrStable(xv::sid::kGsOxide))) continue;
        uint64_t controller_class = rd_ptr(base + game_controller_rva());
        if (!class_matches(controller_class, xv::StrStable(xv::sid::kGsGameControllerBase), xv::StrStable(xv::sid::kGsOxide))) continue;
        uint64_t player_static = get_class_static_fields(player_class);
        uint64_t controller_static = get_class_static_fields(controller_class);
        if (!player_static || !controller_static) continue;

        g_il2cpp_base = base;
        g_player_manager_class = player_class;
        g_player_manager_static_fields = player_static;
        g_game_controller_class = controller_class;
        break;
    }

    if (!g_il2cpp_base) {
        g_pid = -1;
        return false;
    }

    return true;
}

bool esp_local_is_dead(bool* out_valid) {
    static double s_checked = 0.0;
    static bool s_valid = false;
    static bool s_dead = false;

    const double now = monotonic_seconds();
    if (now - s_checked < 0.25) {
        if (out_valid) *out_valid = s_valid;
        return s_dead;
    }

    std::unique_lock<std::mutex> lock(g_game_mutex, std::try_to_lock);
    if (!lock.owns_lock()) {
        if (out_valid) *out_valid = s_valid;
        return s_dead;
    }

    s_checked = now;
    s_valid = false;
    s_dead = false;

    if (g_pid <= 0 || !g_il2cpp_base) {
        if (out_valid) *out_valid = false;
        return false;
    }
    uint64_t local_player = resolve_local_player();
    if (!local_player) {
        if (out_valid) *out_valid = false;
        return false;
    }
    float health = -1.0F, maximum = -1.0F;
    if (!read_player_health(local_player, health, maximum)) {
        if (out_valid) *out_valid = false;
        return false;
    }
    s_valid = true;
    s_dead = health <= 0.01F;
    if (out_valid) *out_valid = true;
    return s_dead;
}

void esp_reset() {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    reset_all_state_unlocked();
}

static float freecam_yaw_of(const Vec4& rotation) {
    Vec3 forward = rotate_vector(rotation, {0.0F, 0.0F, 1.0F});
    if (!std::isfinite(forward.x) || !std::isfinite(forward.z)) return 0.0F;
    float len = sqrtf(forward.x * forward.x + forward.z * forward.z);
    if (len < 1e-6F) return 0.0F;
    return atan2f(forward.x, forward.z) * (180.0F / 3.14159265F);
}

static float freecam_pitch_of(const Vec4& rotation) {
    Vec3 forward = rotate_vector(rotation, {0.0F, 0.0F, 1.0F});
    if (!std::isfinite(forward.y)) return 0.0F;
    float len = sqrtf(forward.x * forward.x + forward.y * forward.y + forward.z * forward.z);
    if (len < 1e-6F) return 0.0F;
    float sine = forward.y / len;
    if (sine > 1.0F) sine = 1.0F;
    if (sine < -1.0F) sine = -1.0F;
    return asinf(sine) * (180.0F / 3.14159265F);
}

static float freecam_wrap_degrees(float value) {
    while (value > 180.0F) value -= 360.0F;
    while (value < -180.0F) value += 360.0F;
    return value;
}

static Vec4 freecam_yaw_quaternion(float degrees) {
    float radians = degrees * (3.14159265F / 180.0F) * 0.5F;
    return {0.0F, sinf(radians), 0.0F, cosf(radians)};
}

static uint64_t freecam_find_wallclip(uint64_t native_camera) {
    if (!likely_native_pointer(native_camera)) return 0;
    uint64_t game_object = rd_ptr(native_camera + NATIVE_COMPONENT_GAMEOBJECT);
    if (!likely_native_pointer(game_object)) return 0;
    uint64_t table = rd_ptr(game_object + NATIVE_GAMEOBJECT_COMPONENTS);
    if (!likely_native_pointer(table)) return 0;
    for (int i = 0; i < 64; ++i) {
        uint64_t candidate = rd_ptr(table + (uint64_t)i * sizeof(uint64_t));
        if (candidate < 0x10000) continue;
        if (likely_native_pointer(candidate) &&
            managed_object_is(candidate, xv::StrStable(xv::sid::kGsPreventCameraWallClip)))
            return candidate;
    }
    return 0;
}

static uint64_t freecam_find_wallclip_any(uint64_t player,
                                         uint64_t rig_native) {
    uint64_t found = freecam_find_wallclip(resolve_native_camera());
    if (found) return found;
    found = freecam_find_wallclip(rig_native);
    if (found) return found;
    uint64_t player_transform = resolve_managed_component_transform(player);
    if (player_transform) found = freecam_find_wallclip(player_transform);
    return found;
}

static bool freecam_rig_layout(uint64_t rig_native, uint64_t& transform_data,
                               int32_t& index, uint64_t& matrices,
                               uint64_t& indices, int32_t& parent_index) {
    if (!likely_native_pointer(rig_native)) return false;
    transform_data = rd_ptr(rig_native + NATIVE_TRANSFORM_HIERARCHY_DATA);
    index = rd<int32_t>(rig_native + NATIVE_TRANSFORM_HIERARCHY_INDEX);
    if (!likely_native_pointer(transform_data) || index < 0 || index > 100000)
        return false;
    matrices = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_MATRICES);
    indices = rd_ptr(transform_data + NATIVE_TRANSFORM_HIERARCHY_INDICES);
    if (!likely_native_pointer(matrices) || !likely_native_pointer(indices))
        return false;
    parent_index = rd<int32_t>(indices + (uint64_t)index * sizeof(int32_t));
    if (parent_index < -1 || parent_index > 100000) return false;
    return true;
}

static void write_look_angles(uint64_t mouse_look, uint64_t matrices,
                              uint64_t indices, int32_t parent_index,
                              uint64_t motor, float yaw, float pitch,
                              bool widen_limits) {
    if (!mouse_look) return;
    if (!std::isfinite(pitch)) pitch = 0.0F;
    if (pitch > 89.0F) pitch = 89.0F;
    if (pitch < -89.0F) pitch = -89.0F;
    if (!std::isfinite(yaw)) yaw = 0.0F;

    float zmm[2] = {-pitch, yaw};
    wr_bulk(mouse_look + MOUSE_LOOK_ZMM, zmm, sizeof(zmm));
    if (widen_limits) {
        const float limits[4] = {-89.0F, 89.0F, -89.0F, 89.0F};
        wr_bulk(mouse_look + MOUSE_LOOK_LIMITS, limits, sizeof(limits));
    }

    if (parent_index < 0 || !likely_native_pointer(matrices) ||
        !likely_native_pointer(indices))
        return;

    Vec3 parent_world_position{};
    Vec4 parent_world_rotation{};
    if (!read_transform_hierarchy_direct(matrices, indices, parent_index,
                                         parent_world_position,
                                         &parent_world_rotation))
        return;

    Matrix34 parent_local{};
    if (!rd_bulk(matrices + (uint64_t)parent_index * sizeof(Matrix34),
                 &parent_local, sizeof(parent_local)) ||
        !matrix34_is_valid(parent_local))
        return;

    float parent_yaw = freecam_yaw_of(parent_world_rotation);
    float delta = freecam_wrap_degrees(yaw - parent_yaw);
    if (fabsf(delta) <= 0.01F) return;

    Vec4 yaw_rotation = freecam_yaw_quaternion(delta);
    Vec4 current = parent_local.rotation;
    if (!normalize_quaternion(current)) return;
    Vec4 updated = multiply_quaternion(yaw_rotation, current);
    if (!normalize_quaternion(updated)) return;

    Matrix34 rotated = parent_local;
    rotated.rotation = updated;
    wr_bulk(matrices + (uint64_t)parent_index * sizeof(Matrix34),
            &rotated, sizeof(Matrix34));

    if (!motor) return;
    Vec4 world_target = multiply_quaternion(yaw_rotation, parent_world_rotation);
    if (!normalize_quaternion(world_target)) return;
    float packed[4] = {world_target.x, world_target.y,
                       world_target.z, world_target.w};
    wr_bulk(motor + MOTOR_INTERNAL_ROTATION, packed, sizeof(packed));
}

static void freecam_restore_unlocked() {
    if (g_freecam.valid && g_pid > 0) {
        if (g_freecam.wallclip) {
            wr_bulk(g_freecam.wallclip + WALLCLIP_COLLISION_MASK,
                    &g_freecam.wallclip_mask, sizeof(g_freecam.wallclip_mask));
            if (g_freecam.wallclip_radius >= 0.f)
                wr_bulk(g_freecam.wallclip + WALLCLIP_SPHERE_RADIUS,
                        &g_freecam.wallclip_radius,
                        sizeof(g_freecam.wallclip_radius));
            if (g_freecam.wallclip_min >= 0.f)
                wr_bulk(g_freecam.wallclip + WALLCLIP_MIN_DISTANCE,
                        &g_freecam.wallclip_min,
                        sizeof(g_freecam.wallclip_min));
        }
        if (g_freecam.motor) {
            wr_bulk(g_freecam.motor + MOTOR_INTERNAL_ROTATION,
                    g_freecam.motor_rotation, sizeof(g_freecam.motor_rotation));
        }
        if (g_freecam.gyro_sens >= 0.f && g_freecam.mouse_look) {
            uint64_t player = resolve_local_player();
            uint64_t mouse_look = player
                ? rd_ptr(player + PLAYER_MOUSE_LOOK) : 0;
            if (mouse_look == g_freecam.mouse_look)
                wr_bulk(mouse_look + MOUSE_LOOK_GYRO_SENS,
                        &g_freecam.gyro_sens, sizeof(g_freecam.gyro_sens));
        }
    }
    if (g_freecam.valid && g_pid > 0 && g_freecam.transform_data &&
        g_freecam.index >= 0) {
        uint64_t transform_data = 0, matrices = 0, indices = 0;
        int32_t index = 0, parent_index = 0;
        if (freecam_rig_layout(g_freecam.rig_transform, transform_data,
                               index, matrices, indices, parent_index) &&
            transform_data == g_freecam.transform_data &&
            index == g_freecam.index) {
            if (g_freecam.rig_saved) {
                wr_bulk(matrices + (uint64_t)index * sizeof(Matrix34),
                        &g_freecam.rig_local, sizeof(Matrix34));
            }
            if (g_freecam.parent_saved && parent_index >= 0) {
                wr_bulk(matrices + (uint64_t)parent_index * sizeof(Matrix34),
                        &g_freecam.parent_local, sizeof(Matrix34));
            }
        }
        uint64_t player = resolve_local_player();
        uint64_t mouse_look = player
            ? rd_ptr(player + PLAYER_MOUSE_LOOK) : 0;
        if (mouse_look && mouse_look == g_freecam.mouse_look) {
            wr_bulk(mouse_look + MOUSE_LOOK_ZMM, g_freecam.zmm,
                    sizeof(g_freecam.zmm));
            wr_bulk(mouse_look + MOUSE_LOOK_LIMITS, g_freecam.limits,
                    sizeof(g_freecam.limits));
        }
    }
    g_freecam = {};
}

void memory_freecam_update(bool enabled, float* position, float* yaw,
                           float* pitch) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (!enabled) {
        if (g_freecam.valid) freecam_restore_unlocked();
        return;
    }
    if (g_pid <= 0 || !g_il2cpp_base || !position || !yaw || !pitch) {
        if (g_freecam.valid) freecam_restore_unlocked();
        return;
    }

    uint64_t player = resolve_local_player();
    if (!player || !likely_native_pointer(player)) {
        if (g_freecam.valid) freecam_restore_unlocked();
        return;
    }
    uint64_t mouse_look = rd_ptr(player + PLAYER_MOUSE_LOOK);
    if (!mouse_look) {
        if (g_freecam.valid) freecam_restore_unlocked();
        return;
    }

    if (g_freecam.valid &&
        (mouse_look != g_freecam.mouse_look ||
         !likely_native_pointer(g_freecam.rig_transform))) {
        freecam_restore_unlocked();
    }
    uint64_t rig_native = resolve_native_transform(
        rd_ptr(player + PLAYER_TRANSFORM));
    uint64_t transform_data = 0, matrices = 0, indices = 0;
    int32_t index = 0, parent_index = 0;
    if (!freecam_rig_layout(rig_native, transform_data, index, matrices,
                            indices, parent_index)) {
        if (g_freecam.valid) freecam_restore_unlocked();
        return;
    }

    if (!g_freecam.valid) {
        Vec3 camera_position{};
        Vec4 camera_rotation{};
        if (!read_render_camera_pose(player, camera_position, camera_rotation))
            return;
        g_freecam = {};
        g_freecam.valid = true;
        g_freecam.rig_transform = rig_native;
        g_freecam.mouse_look = mouse_look;
        g_freecam.transform_data = transform_data;
        g_freecam.index = index;
        rd_bulk(mouse_look + MOUSE_LOOK_ZMM, g_freecam.zmm,
                sizeof(g_freecam.zmm));
        rd_bulk(mouse_look + MOUSE_LOOK_LIMITS, g_freecam.limits,
                sizeof(g_freecam.limits));
        rd_bulk(matrices + (uint64_t)index * sizeof(Matrix34),
                &g_freecam.rig_local, sizeof(Matrix34));
        g_freecam.rig_saved = matrix34_is_valid(g_freecam.rig_local);
        if (parent_index >= 0) {
            rd_bulk(matrices + (uint64_t)parent_index * sizeof(Matrix34),
                    &g_freecam.parent_local, sizeof(Matrix34));
            g_freecam.parent_saved = matrix34_is_valid(g_freecam.parent_local);
        }
        uint64_t kcc = resolve_player_kcc(player);
        uint64_t motor = kcc ? rd_ptr(kcc + KCC_MOTOR) : 0;
        if (likely_native_pointer(motor)) {
            float rotation[4] = {0.f, 0.f, 0.f, 1.f};
            if (rd_bulk(motor + MOTOR_INTERNAL_ROTATION, rotation,
                        sizeof(rotation))) {
                g_freecam.motor = motor;
                memcpy(g_freecam.motor_rotation, rotation, sizeof(rotation));
            }
        }
        uint64_t wallclip = freecam_find_wallclip_any(player, rig_native);
        if (wallclip) {
            int32_t mask = 0;
            if (rd_bulk(wallclip + WALLCLIP_COLLISION_MASK, &mask,
                        sizeof(mask)) && mask != 0) {
                g_freecam.wallclip = wallclip;
                g_freecam.wallclip_mask = mask;
                const int32_t no_mask = 0;
                wr_bulk(wallclip + WALLCLIP_COLLISION_MASK, &no_mask,
                        sizeof(no_mask));
            }
            float radius = 0.f;
            if (rd_bulk(wallclip + WALLCLIP_SPHERE_RADIUS, &radius,
                        sizeof(radius)) && radius > 0.001f) {
                g_freecam.wallclip = wallclip;
                g_freecam.wallclip_radius = radius;
                const float no_radius = 0.f;
                wr_bulk(wallclip + WALLCLIP_SPHERE_RADIUS, &no_radius,
                        sizeof(no_radius));
            }
            float min_distance = 0.f;
            if (rd_bulk(wallclip + WALLCLIP_MIN_DISTANCE, &min_distance,
                        sizeof(min_distance)) && min_distance > 0.001f) {
                g_freecam.wallclip = wallclip;
                g_freecam.wallclip_min = min_distance;
                const float no_min = 0.f;
                wr_bulk(wallclip + WALLCLIP_MIN_DISTANCE, &no_min,
                        sizeof(no_min));
            }
        }
        float gyro_sens = 0.f;
        if (rd_bulk(mouse_look + MOUSE_LOOK_GYRO_SENS, &gyro_sens,
                    sizeof(gyro_sens)) && fabsf(gyro_sens) > 0.0001f) {
            g_freecam.gyro_sens = gyro_sens;
            const float no_sens = 0.f;
            wr_bulk(mouse_look + MOUSE_LOOK_GYRO_SENS, &no_sens,
                    sizeof(no_sens));
        }
        position[0] = camera_position.x;
        position[1] = camera_position.y;
        position[2] = camera_position.z;
        *yaw = freecam_yaw_of(camera_rotation);
        *pitch = freecam_pitch_of(camera_rotation);
        if (!std::isfinite(position[0]) || !std::isfinite(position[1]) ||
            !std::isfinite(position[2]) || !std::isfinite(*yaw) ||
            !std::isfinite(*pitch)) {
            freecam_restore_unlocked();
            return;
        }
    }

    if (!g_freecam.valid) return;

    float clamped_pitch = *pitch;
    if (!std::isfinite(clamped_pitch)) clamped_pitch = 0.0F;
    if (clamped_pitch > 89.0F) clamped_pitch = 89.0F;
    if (clamped_pitch < -89.0F) clamped_pitch = -89.0F;
    *pitch = clamped_pitch;
    if (!std::isfinite(*yaw)) *yaw = 0.0F;
    for (int i = 0; i < 3; ++i)
        if (!std::isfinite(position[i])) position[i] = 0.0F;

    write_look_angles(mouse_look, matrices, indices, parent_index,
                      g_freecam.motor, *yaw, clamped_pitch, true);
    if (parent_index < 0) return;

    Vec3 parent_world_position{};
    Vec4 parent_world_rotation{};
    if (!read_transform_hierarchy_direct(matrices, indices, parent_index,
                                         parent_world_position,
                                         &parent_world_rotation))
        return;

    Matrix34 parent_local{};
    if (!rd_bulk(matrices + (uint64_t)parent_index * sizeof(Matrix34),
                 &parent_local, sizeof(parent_local)) ||
        !matrix34_is_valid(parent_local))
        return;

    Vec3 desired = {position[0], position[1], position[2]};
    Vec3 rel = {desired.x - parent_world_position.x,
                desired.y - parent_world_position.y,
                desired.z - parent_world_position.z};
    Vec4 conj = {-parent_world_rotation.x, -parent_world_rotation.y,
                 -parent_world_rotation.z, parent_world_rotation.w};
    Vec3 local = rotate_vector(conj, rel);
    float scale_x = fabsf(parent_local.scale.x) > 0.01F ? parent_local.scale.x : 1.0F;
    float scale_y = fabsf(parent_local.scale.y) > 0.01F ? parent_local.scale.y : 1.0F;
    float scale_z = fabsf(parent_local.scale.z) > 0.01F ? parent_local.scale.z : 1.0F;
    if (fabsf(scale_x) > 0.01F) local.x /= scale_x;
    if (fabsf(scale_y) > 0.01F) local.y /= scale_y;
    if (fabsf(scale_z) > 0.01F) local.z /= scale_z;

    wr_bulk(matrices + (uint64_t)index * sizeof(Matrix34),
            &local, sizeof(Vec3));
}

void esp_begin_overlay_frame(int screen_width, int screen_height) {
    std::lock_guard<std::mutex> lock(g_game_mutex);

    hierarchy_cache_begin_frame();
    anim_bone_path_cache_begin_frame();

    g_overlay_projection_snapshot = {};
    g_overlay_camera_sampled_this_frame = false;
    if (g_pid <= 0 || !g_il2cpp_base) return;

    world_scan_tick();

    const std::vector<uint64_t>& players = refresh_player_snapshot();
    if (players.empty()) return;
    uint64_t local_player = resolve_local_player();
    if (!local_player) return;

    (void)screen_width;
    (void)screen_height;

}

static bool skeleton_draw_bone(int32_t bone) {
    switch (bone) {

    case HUMAN_BONE_HIPS:
    case HUMAN_BONE_SPINE:
    case HUMAN_BONE_CHEST:
    case HUMAN_BONE_UPPER_CHEST:
    case HUMAN_BONE_NECK:
    case HUMAN_BONE_HEAD:
    case HUMAN_BONE_LEFT_SHOULDER:
    case HUMAN_BONE_RIGHT_SHOULDER:

    case HUMAN_BONE_LEFT_UPPER_ARM:
    case HUMAN_BONE_RIGHT_UPPER_ARM:
    case HUMAN_BONE_LEFT_LOWER_ARM:
    case HUMAN_BONE_RIGHT_LOWER_ARM:
    case HUMAN_BONE_LEFT_HAND:
    case HUMAN_BONE_RIGHT_HAND:

    case HUMAN_BONE_LEFT_UPPER_LEG:
    case HUMAN_BONE_RIGHT_UPPER_LEG:
    case HUMAN_BONE_LEFT_LOWER_LEG:
    case HUMAN_BONE_RIGHT_LOWER_LEG:
    case HUMAN_BONE_LEFT_FOOT:
    case HUMAN_BONE_RIGHT_FOOT:
    case HUMAN_BONE_LEFT_TOES:
    case HUMAN_BONE_RIGHT_TOES:
        return true;

    default:
        return false;
    }
}

static float skeleton_direct_max_len(int32_t bone) {
    switch (bone) {

    case HUMAN_BONE_SPINE:           return 0.40F;
    case HUMAN_BONE_CHEST:           return 0.35F;
    case HUMAN_BONE_UPPER_CHEST:     return 0.30F;
    case HUMAN_BONE_NECK:            return 0.30F;
    case HUMAN_BONE_HEAD:            return 0.35F;

    case HUMAN_BONE_LEFT_SHOULDER:
    case HUMAN_BONE_RIGHT_SHOULDER:  return 0.35F;
    case HUMAN_BONE_LEFT_UPPER_ARM:
    case HUMAN_BONE_RIGHT_UPPER_ARM: return 0.40F;
    case HUMAN_BONE_LEFT_LOWER_ARM:
    case HUMAN_BONE_RIGHT_LOWER_ARM: return 0.45F;
    case HUMAN_BONE_LEFT_HAND:
    case HUMAN_BONE_RIGHT_HAND:      return 0.40F;

    case HUMAN_BONE_LEFT_UPPER_LEG:
    case HUMAN_BONE_RIGHT_UPPER_LEG: return 0.50F;
    case HUMAN_BONE_LEFT_LOWER_LEG:
    case HUMAN_BONE_RIGHT_LOWER_LEG: return 0.55F;
    case HUMAN_BONE_LEFT_FOOT:
    case HUMAN_BONE_RIGHT_FOOT:      return 0.45F;
    case HUMAN_BONE_LEFT_TOES:
    case HUMAN_BONE_RIGHT_TOES:      return 0.30F;
    default:                         return 0.90F;
    }
}

static int32_t skeleton_draw_parent(int32_t bone) {
    switch (bone) {

    case HUMAN_BONE_SPINE:
        return HUMAN_BONE_HIPS;
    case HUMAN_BONE_CHEST:
        return HUMAN_BONE_SPINE;
    case HUMAN_BONE_UPPER_CHEST:
        return HUMAN_BONE_CHEST;
    case HUMAN_BONE_NECK:
        return HUMAN_BONE_UPPER_CHEST;
    case HUMAN_BONE_HEAD:
        return HUMAN_BONE_NECK;

    case HUMAN_BONE_LEFT_SHOULDER:
    case HUMAN_BONE_RIGHT_SHOULDER:
        return HUMAN_BONE_UPPER_CHEST;
    case HUMAN_BONE_LEFT_UPPER_ARM:
        return HUMAN_BONE_LEFT_SHOULDER;
    case HUMAN_BONE_RIGHT_UPPER_ARM:
        return HUMAN_BONE_RIGHT_SHOULDER;
    case HUMAN_BONE_LEFT_LOWER_ARM:
        return HUMAN_BONE_LEFT_UPPER_ARM;
    case HUMAN_BONE_RIGHT_LOWER_ARM:
        return HUMAN_BONE_RIGHT_UPPER_ARM;
    case HUMAN_BONE_LEFT_HAND:
        return HUMAN_BONE_LEFT_LOWER_ARM;
    case HUMAN_BONE_RIGHT_HAND:
        return HUMAN_BONE_RIGHT_LOWER_ARM;

    case HUMAN_BONE_LEFT_UPPER_LEG:
    case HUMAN_BONE_RIGHT_UPPER_LEG:
        return HUMAN_BONE_HIPS;
    case HUMAN_BONE_LEFT_LOWER_LEG:
        return HUMAN_BONE_LEFT_UPPER_LEG;
    case HUMAN_BONE_RIGHT_LOWER_LEG:
        return HUMAN_BONE_RIGHT_UPPER_LEG;
    case HUMAN_BONE_LEFT_FOOT:
        return HUMAN_BONE_LEFT_LOWER_LEG;
    case HUMAN_BONE_RIGHT_FOOT:
        return HUMAN_BONE_RIGHT_LOWER_LEG;
    case HUMAN_BONE_LEFT_TOES:
        return HUMAN_BONE_LEFT_FOOT;
    case HUMAN_BONE_RIGHT_TOES:
        return HUMAN_BONE_RIGHT_FOOT;
    default:
        return -1;
    }
}

static bool player_is_sleeping(uint64_t player) {
    uint64_t events = rd_ptr(player + PLAYER_EVENT_HANDLER);
    if (!events) return false;
    uint64_t sleep = rd_ptr(events + event_sleep_offset());
    if (!likely_native_pointer(sleep)) return false;
    return rd<uint8_t>(sleep + UOA_ACTIVE) != 0;
}

static void lift_aim_points(Vec3 worlds[3], const bool have[3]);

std::vector<EspBox> esp_get_boxes(int overlay_width, int overlay_height,
                                  bool include_names, bool include_health,
                                  int* nearby_enemy_count,
                                  bool include_skeleton,
                                  bool ignore_teammates,
                                  int* nearby_teammate_count,
                                  int* nearby_bot_count,
                                  bool include_weapons) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    std::vector<EspBox> result;
    if (nearby_enemy_count) *nearby_enemy_count = 0;
    if (nearby_teammate_count) *nearby_teammate_count = 0;

    if (nearby_bot_count) *nearby_bot_count = g_world_stat_bots_alive;
    if (g_pid <= 0 || !g_il2cpp_base) return result;

    float sw = overlay_width >= 100 ? (float)overlay_width : 1080.0F;
    float sh = overlay_height >= 100 ? (float)overlay_height : 2400.0F;
    if (!std::isfinite(sw) || sw < 100.0F || sw > 10000.0F) sw = 1080.0F;
    if (!std::isfinite(sh) || sh < 100.0F || sh > 10000.0F) sh = 2400.0F;

    const std::vector<uint64_t>& s_transforms = refresh_player_snapshot();
    if (s_transforms.empty()) return result;
    result.reserve(s_transforms.size());

    uint64_t local_ptr = resolve_local_player();
    Vec3 cull_camera = g_overlay_projection_snapshot.valid
        ? g_overlay_projection_snapshot.camera_position : Vec3{};
    if (!g_overlay_projection_snapshot.valid) {
        Vec4 unused_rot{};
        read_render_camera_pose(local_ptr, cull_camera, unused_rot);
    }

    struct PlayerEspWork {
        uint64_t player = 0;
        Vec3 feet{};
        float health = -1.0F;
        float max_health = -1.0F;
        bool health_valid = false;
        std::string name;
        bool teammate = false;
        bool xvcen_user = false;
        bool dead = false;
        Vec3 bone_world[55]{};
        uint8_t bone_ok[55]{};
        Vec3 rag_world[32]{};
        int rag_n = 0;
        std::string weapon_name;
        std::string weapon_name_ru;
    };
    std::vector<PlayerEspWork> work;
    work.reserve(s_transforms.size());

    const std::string local_team = local_ptr ? read_team_name(local_ptr)
                                             : std::string();
    const std::vector<uint64_t> xvcen_peers = AuthPresenceGetPeerHashes();
    const double peer_now = monotonic_seconds();

    if (!sample_overlay_camera(local_ptr, sw, sh)) return result;

    if (peer_now - g_peer_tag_frame_time > 0.1) {
        g_peer_tag_frame_time = peer_now;
        g_peer_tag_budget = 3;
    }

    for (size_t i = 0; i < s_transforms.size(); ++i) {
        if (local_ptr && s_transforms[i] == local_ptr) continue;
        if (!s_transforms[i]) continue;
        if (g_player_manager_class &&
            rd_ptr(s_transforms[i]) != g_player_manager_class)
            continue;

        const bool player_is_xvcen =
            player_is_xvcen_peer_cached(s_transforms[i], xvcen_peers, peer_now);

        const bool is_teammate = local_ptr && !local_team.empty() &&
            local_team == read_team_name(s_transforms[i]);
        if (is_teammate) {
            if (ignore_teammates && !player_is_xvcen) continue;
        }

        float player_health = -1.0F;
        float player_max_health = -1.0F;
        bool player_health_valid = read_player_health(s_transforms[i],
                                                     player_health,
                                                     player_max_health);
        const bool player_is_dead = player_health_valid
            ? player_health <= 0.01F
            : player_is_dead_or_spectating(s_transforms[i]);

        if (player_is_dead && !include_skeleton) continue;

        PlayerEspWork item{};
        item.dead = player_is_dead;
        if (include_skeleton) {
            read_dump_skeleton(s_transforms[i], player_is_dead, item.bone_world,
                               item.bone_ok, item.rag_world, item.rag_n);
        } else {
            int32_t box_bones[3] = {HUMAN_BONE_HEAD, HUMAN_BONE_NECK, HUMAN_BONE_CHEST};
            for (int32_t human : box_bones) {
                Vec3 world{};
                if (!read_human_bone_world(s_transforms[i], human, world,
                                           player_is_dead)) continue;
                item.bone_world[human] = world;
                item.bone_ok[human] = 1;
            }
        }

        Vec3 feet{};
        bool have_feet = false;
        if (player_is_dead) {
            have_feet = read_ragdoll_pelvis_world(s_transforms[i], feet);
            if (!have_feet && item.bone_ok[HUMAN_BONE_HIPS]) {
                feet = item.bone_world[HUMAN_BONE_HIPS];
                have_feet = true;
            }
            if (!have_feet && item.rag_n > 0) {
                feet = item.rag_world[0];
                have_feet = true;
            }
        }
        if (!have_feet)
            have_feet = read_best_player_position(s_transforms[i], feet);
        if (!have_feet) continue;

        float dx = feet.x - cull_camera.x, dy = feet.y - cull_camera.y, dz = feet.z - cull_camera.z;
        float distance = sqrtf(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(distance) || distance < MIN_PLAYER_DISTANCE ||
            distance > MAX_PLAYER_ESP_DISTANCE) continue;

        if (!player_is_dead && !player_is_sleeping(s_transforms[i])) {
            if (is_teammate) {
                if (nearby_teammate_count && *nearby_teammate_count < 99)
                    ++(*nearby_teammate_count);
            } else if (nearby_enemy_count && *nearby_enemy_count < 999) {
                ++(*nearby_enemy_count);
            }
        }

        item.player = s_transforms[i];
        item.feet = feet;
        item.health = player_health;
        item.max_health = player_max_health;
        item.health_valid = player_health_valid;
        item.teammate = is_teammate;
        item.xvcen_user = player_is_xvcen;
        work.push_back(std::move(item));
    }

    report_local_player_name(local_ptr);

    for (PlayerEspWork& item : work) {
        if (include_names) item.name = read_player_name(item.player);
        if (include_weapons && !item.dead) {
            read_player_held_weapon(item.player, item.weapon_name,
                                    item.weapon_name_ru);
        }
    }

    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 local = snap.camera_position;

    for (const PlayerEspWork& item : work) {
        float dx = item.feet.x - local.x, dy = item.feet.y - local.y, dz = item.feet.z - local.z;
        float distance = sqrtf(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(distance)) continue;

        Vec3 body_bottom = {item.feet.x, item.feet.y, item.feet.z};
        Vec3 body_top = {item.feet.x, item.feet.y + PLAYER_HEIGHT, item.feet.z};
        if (item.bone_ok[HUMAN_BONE_HEAD]) {
            body_top = item.bone_world[HUMAN_BONE_HEAD];
            if (item.bone_ok[HUMAN_BONE_NECK]) {
                Vec3 axis = {body_top.x - item.bone_world[HUMAN_BONE_NECK].x,
                             body_top.y - item.bone_world[HUMAN_BONE_NECK].y,
                             body_top.z - item.bone_world[HUMAN_BONE_NECK].z};
                float len = sqrtf(axis.x * axis.x + axis.y * axis.y + axis.z * axis.z);
                if (len > 0.04F) {
                    float s = 0.14F / len;
                    body_top.x += axis.x * s;
                    body_top.y += axis.y * s;
                    body_top.z += axis.z * s;
                } else {
                    body_top.y += 0.14F;
                }
            } else {
                body_top.y += 0.14F;
            }
        }
        Vec2 sf{}, sh2{};
        if (!project_world(snap, body_bottom, sw, sh, sf, false)) {
            continue;
        }
        if (!project_world(snap, body_top, sw, sh, sh2, false)) {
            continue;
        }

        float height = fabsf(sh2.y - sf.y);

        if (!std::isfinite(height)) {
            continue;
        }
        if (height < 2.0F) height = 2.0F;
        float cx = (sf.x + sh2.x) * 0.5F;
        float cy = (sf.y + sh2.y) * 0.5F;
        float half_w = height * PLAYER_BOX_WIDTH_RATIO * 0.5F;
        float half_h = height * 0.5F;

        EspBox box{};
        box.x1 = cx - half_w; box.y1 = cy - half_h;
        box.x2 = cx + half_w; box.y2 = cy + half_h;
        box.distance = distance;
        box.name = item.name;
        box.teammate = item.teammate;
        box.xvcen_user = item.xvcen_user;
        box.weapon_name = item.weapon_name;
        box.weapon_name_ru = item.weapon_name_ru;
        box.id = (unsigned long long)item.player;
        {
            const float cam_yaw = freecam_yaw_of(snap.camera_rotation);
            const float cam_pitch = freecam_pitch_of(snap.camera_rotation);
            box.cam_yaw_at = cam_yaw;
            box.cam_pitch_at = cam_pitch;
            const int32_t aim_bones[3] = {HUMAN_BONE_HEAD, HUMAN_BONE_NECK,
                                          HUMAN_BONE_CHEST};
            Vec3 aim_w[3]{};
            bool aim_h[3]{};
            for (int bi = 0; bi < 3; ++bi) {
                aim_h[bi] = item.bone_ok[aim_bones[bi]];
                if (aim_h[bi]) aim_w[bi] = item.bone_world[aim_bones[bi]];
            }
            lift_aim_points(aim_w, aim_h);
            for (int bi = 0; bi < 3; ++bi) {
                if (!aim_h[bi]) continue;
                const Vec3& wpos = aim_w[bi];
                Vec2 scr{};
                if (!project_world(snap, wpos, sw, sh, scr, false)) continue;
                const Vec3 rel = {wpos.x - local.x, wpos.y - local.y,
                                  wpos.z - local.z};
                const float dh = sqrtf(rel.x * rel.x + rel.z * rel.z);
                if (!std::isfinite(dh) || dh < 0.05f) continue;
                float eyaw = atan2f(rel.x, rel.z) * (180.0f / 3.14159265f) -
                             cam_yaw;
                while (eyaw > 180.0f) eyaw -= 360.0f;
                while (eyaw < -180.0f) eyaw += 360.0f;
                const float epitch =
                    atan2f(rel.y, dh) * (180.0f / 3.14159265f) - cam_pitch;
                if (!std::isfinite(eyaw) || !std::isfinite(epitch)) continue;
                box.aim_valid[bi] = true;
                box.aim_yaw[bi] = eyaw;
                box.aim_pitch[bi] = epitch;
                box.aim_pts[bi][0] = scr.x;
                box.aim_pts[bi][1] = scr.y;
            }
        }
        if (include_health && item.health_valid) {
            box.health = item.health;
            box.max_health = item.max_health;
        }
        if (include_skeleton) {
            int player_segs = 0;
            Vec2 skel_s[55]{};
            uint8_t skel_ok[55]{};
            for (int32_t human = 0; human <= 54; ++human) {
                if (!skeleton_draw_bone(human)) continue;
                if (!item.bone_ok[human]) {
                    continue;
                }
                Vec2 screen{};
                if (!project_world(snap, item.bone_world[human], sw, sh, screen, false))
                    continue;
                skel_s[human] = screen;
                skel_ok[human] = 1;
            }

            if (skel_ok[HUMAN_BONE_HIPS] && skel_ok[HUMAN_BONE_HEAD] &&
                skel_ok[HUMAN_BONE_NECK]) {
                const Vec3& h0 = item.bone_world[HUMAN_BONE_HIPS];
                const Vec3& h1 = item.bone_world[HUMAN_BONE_HEAD];
                const Vec3 axis{h1.x - h0.x, h1.y - h0.y, h1.z - h0.z};
                const float axis_len2 =
                    axis.x * axis.x + axis.y * axis.y + axis.z * axis.z;
                if (std::isfinite(axis_len2) && axis_len2 > 0.10F) {
                    const Vec3& p = item.bone_world[HUMAN_BONE_NECK];
                    const Vec3 v{p.x - h0.x, p.y - h0.y, p.z - h0.z};
                    float t = (v.x * axis.x + v.y * axis.y + v.z * axis.z) /
                              axis_len2;
                    if (t < 0.0F) t = 0.0F;
                    if (t > 1.0F) t = 1.0F;
                    const float ex = v.x - axis.x * t;
                    const float ey = v.y - axis.y * t;
                    const float ez = v.z - axis.z * t;
                    const float dev2 = ex * ex + ey * ey + ez * ez;
                    if (!std::isfinite(dev2) || dev2 > 0.25F * 0.25F)
                        skel_ok[HUMAN_BONE_NECK] = 0;
                }
            }
            for (int32_t human = 0; human <= 54; ++human) {
                if (!skel_ok[human]) continue;
                int32_t parent = skeleton_draw_parent(human);
                while (parent >= 0 && (!skel_ok[parent] || !skeleton_draw_bone(parent)))
                    parent = skeleton_draw_parent(parent);
                if (parent < 0) continue;
                const Vec3& a = item.bone_world[human];
                const Vec3& b = item.bone_world[parent];
                float lx = a.x - b.x, ly = a.y - b.y, lz = a.z - b.z;
                float bone_len = sqrtf(lx * lx + ly * ly + lz * lz);

                const int32_t direct_parent = skeleton_draw_parent(human);
                const bool substituted = parent != direct_parent;
                float max_len = skeleton_direct_max_len(human);
                if (substituted) {

                    int32_t walk = direct_parent;
                    int guard = 0;
                    while (walk >= 0 && walk != parent && ++guard <= 8) {
                        max_len += skeleton_direct_max_len(walk);
                        walk = skeleton_draw_parent(walk);
                    }
                    if (walk != parent) max_len = 1.20F;
                }
                if (!std::isfinite(bone_len) || bone_len > max_len) continue;

                if (bone_len < 0.02F) continue;
                EspSkelSeg seg{};
                seg.x1 = skel_s[human].x; seg.y1 = skel_s[human].y;
                seg.x2 = skel_s[parent].x; seg.y2 = skel_s[parent].y;

                const float sdx = seg.x2 - seg.x1, sdy = seg.y2 - seg.y1;
                if (sdx * sdx + sdy * sdy < 1.0F) continue;
                box.bones.push_back(seg);
                ++player_segs;
            }

            if (item.dead && player_segs < 6 && item.rag_n >= 2) {
                struct RagEdge { int a; int b; float d; };
                RagEdge edges[32 * 31 / 2];
                int en = 0;
                for (int a = 0; a < item.rag_n; ++a) {
                    for (int b = a + 1; b < item.rag_n; ++b) {
                        float lx = item.rag_world[a].x - item.rag_world[b].x;
                        float ly = item.rag_world[a].y - item.rag_world[b].y;
                        float lz = item.rag_world[a].z - item.rag_world[b].z;
                        float d = sqrtf(lx * lx + ly * ly + lz * lz);
                        if (!std::isfinite(d) || d < 0.02F || d > 0.90F) continue;
                        edges[en++] = {a, b, d};
                    }
                }
                std::sort(edges, edges + en, [](const RagEdge& l, const RagEdge& r) {
                    return l.d < r.d;
                });
                int parent_of[32];
                for (int n = 0; n < item.rag_n; ++n) parent_of[n] = n;
                auto find = [&](int x) {
                    while (parent_of[x] != x) {
                        parent_of[x] = parent_of[parent_of[x]];
                        x = parent_of[x];
                    }
                    return x;
                };
                int linked = 0;
                for (int e = 0; e < en && linked < item.rag_n - 1; ++e) {
                    int a = find(edges[e].a);
                    int b = find(edges[e].b);
                    if (a == b) continue;
                    parent_of[a] = b;
                    ++linked;
                    Vec2 s1{}, s2{};
                    if (!project_world(snap, item.rag_world[edges[e].a], sw, sh, s1, false))
                        continue;
                    if (!project_world(snap, item.rag_world[edges[e].b], sw, sh, s2, false))
                        continue;
                    EspSkelSeg seg{};
                    seg.x1 = s1.x; seg.y1 = s1.y;
                    seg.x2 = s2.x; seg.y2 = s2.y;
                    box.bones.push_back(seg);
                    ++player_segs;
                }
            }
        }
        result.push_back(std::move(box));
    }

    return result;
}

struct DictionaryUIntPtrEntry {
    int32_t hash_code;
    int32_t next;
    uint32_t key;
    uint32_t padding;
    uint64_t value;
};
static_assert(sizeof(DictionaryUIntPtrEntry) == 24, "unexpected dictionary entry layout");
static_assert(offsetof(DictionaryUIntPtrEntry, key) == 8 &&
              offsetof(DictionaryUIntPtrEntry, value) == 16,
              "unexpected uint/NetworkIdentity dictionary offsets");

static bool read_identity_dictionary(uint64_t dictionary,
                                     std::vector<uint64_t>& identities) {
    if (!dictionary) return false;
    {
        uint64_t entries = rd_ptr(dictionary + DICTIONARY_ENTRIES);
        int32_t count = rd<int32_t>(dictionary + DICTIONARY_COUNT);
        int32_t free_count = rd<int32_t>(dictionary + DICTIONARY_FREE_COUNT);
        uint64_t capacity = entries ? rd<uint64_t>(entries + IL2CPP_ARRAY_LENGTH) : 0;
        if (!entries || count <= 0 || count > 131072 || free_count < 0 ||
            free_count > count || capacity == 0 || capacity > 131072 ||
            (uint64_t)count > capacity)
            return false;

        std::vector<DictionaryUIntPtrEntry> snapshot((size_t)count);
        if (!rd_bulk(entries + IL2CPP_ARRAY_FIRST_ELEMENT, snapshot.data(),
                     snapshot.size() * sizeof(DictionaryUIntPtrEntry)))
            return false;
        if (rd<int32_t>(dictionary + DICTIONARY_COUNT) != count)
            return false;

        std::vector<uint64_t> found;
        found.reserve(snapshot.size());
        for (const DictionaryUIntPtrEntry& entry : snapshot) {
            if (entry.hash_code < 0 || !entry.key ||
                !likely_native_pointer(entry.value)) continue;
            if (!g_network_identity_class) {
                uint64_t klass = rd_ptr(entry.value);
                if (!klass) continue;
                if (read_remote_string(rd_ptr(klass + 0x10)) != xv::StrStable(xv::sid::kGsNetworkIdentity))
                    continue;
                g_network_identity_class = klass;
            }
            found.push_back(entry.value);
        }
        if (!found.empty()) {
            identities.swap(found);
            return true;
        }
    }
    return false;
}

static bool read_spawned_network_identities(std::vector<uint64_t>& identities) {
    identities.clear();
    uint64_t network_client = resolve_network_client_class();
    uint64_t static_fields = get_class_static_fields(network_client);
    if (!static_fields) return false;

    uint64_t spawned = rd_ptr(static_fields + NETWORK_CLIENT_SPAWNED_FIELD);
    return read_identity_dictionary(spawned, identities);
}

static uint32_t classify_behaviour_flags(uint64_t behaviour) {
    uint64_t klass = behaviour ? rd_ptr(behaviour) : 0;
    if (!klass) return kBehavNone;
    auto it = g_behaviour_class_flags.find(klass);
    if (it != g_behaviour_class_flags.end()) return it->second;

    uint32_t flags = kBehavNone;
    uint64_t cursor = klass;
    for (int depth = 0; cursor && depth < IL2CPP_MAX_CLASS_DEPTH; ++depth) {
        std::string name = read_remote_string(rd_ptr(cursor + 0x10));
        if (name == xv::StrStable(xv::sid::kGsMineableStone) ||
            name == xv::StrStable(xv::sid::kGsMineableTree)) { flags |= kBehavOre; break; }
        if (name == xv::StrStable(xv::sid::kGsMineableObject)) flags |= kBehavMineable;
        else if (name == NPC_CLASS_RANDOM_SPAWN_LOOT) flags |= kBehavRandomSpawnLoot;
        else if (name == NPC_CLASS_LOOT_OBJECT) flags |= kBehavLootObject;
        else if (name == xv::StrStable(xv::sid::kGsLootOnDeath)) flags |= kBehavLootOnDeath;
        else if (name == xv::StrStable(xv::sid::kGsPlayerDeathHandler)) flags |= kBehavPlayerDeath;
        else if (name == xv::StrStable(xv::sid::kGsEntityDeathHandler)) flags |= kBehavDeathHandler;
        else if (name == NPC_CLASS_HUMANOID_DEATH) flags |= kBehavNpcHumanDeath;
        else if (name == NPC_CLASS_BOT_BRAIN) flags |= kBehavBotBrain;
        else if (name == NPC_CLASS_CANNIBAL_BRAIN) flags |= kBehavCannibalBrain;
        else if (name == NPC_CLASS_ANIMAL_BRAIN) flags |= kBehavAnimalBrain;
        else if (name == NPC_CLASS_FISH) { flags |= kBehavFish; break; }
        else if (name == NPC_CLASS_CUPBOARD) { flags |= kBehavCupboard; break; }
        else if (name == NPC_CLASS_TURRET) { flags |= kBehavTurret; break; }
        else if (name == NPC_CLASS_GUN_TRAP) { flags |= kBehavTurret; break; }
        else if (name == NPC_CLASS_SAM_TURRET) { flags |= kBehavTurret; break; }
        cursor = rd_ptr(cursor + IL2CPP_CLASS_PARENT);
        if (!likely_native_pointer(cursor)) break;
    }
    if (flags != kBehavNone && g_behaviour_class_flags.size() < 4096)
        g_behaviour_class_flags[klass] = flags;
    return flags;
}

static std::atomic<bool> g_tree_scan_enabled{false};
static std::atomic<int> g_scan_boost_frames{0};

void esp_request_fast_scan() {
    g_scan_boost_frames.store(90, std::memory_order_release);
}

void esp_set_tree_scan(bool enabled) {
    const bool previous = g_tree_scan_enabled.exchange(enabled);
    if (previous == enabled) return;
    if (!enabled) {
        std::lock_guard<std::mutex> lock(g_game_mutex);
        for (auto it = g_ore_world_cache.begin();
             it != g_ore_world_cache.end();) {
            if (it->second.kind == OreKind::Tree)
                it = g_ore_world_cache.erase(it);
            else
                ++it;
        }
    }
    esp_request_fast_scan();
}

static bool ore_kind_from_entity_type(int32_t type, OreKind& kind) {
    switch (type) {
    case ENTITY_TYPE_STONE:  kind = OreKind::Stone;  return true;
    case ENTITY_TYPE_IRON:   kind = OreKind::Iron;   return true;
    case ENTITY_TYPE_SULFUR: kind = OreKind::Sulfur; return true;
    case ENTITY_TYPE_TREE:   kind = OreKind::Tree;   return true;
    default: return false;
    }
}

static bool ore_kind_from_mineable(uint64_t ore, OreKind& kind,
                                   std::string& loot_name) {
    int32_t entity_type = 0;
    if (rd_exact(ore + MINEABLE_ENTITY_TYPE, entity_type) &&
        ore_kind_from_entity_type(entity_type, kind))
        return true;

    uint64_t loot = rd_ptr(ore + MINEABLE_LOOT);
    if (!likely_native_pointer(loot)) return false;
    uint64_t items = rd_ptr(loot + IL2CPP_LIST_ITEMS);
    int32_t size = 0;
    if (!likely_native_pointer(items) ||
        !rd_exact(loot + IL2CPP_LIST_SIZE, size) || size <= 0)
        return false;
    uint64_t first = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT);
    if (!likely_native_pointer(first)) return false;
    loot_name = read_il2cpp_string(rd_ptr(first + LOOT_ITEM_NAME));
    if (loot_name == xv::StrStable(xv::sid::kGsSulfurOre)) { kind = OreKind::Sulfur; return true; }
    if (loot_name == xv::StrStable(xv::sid::kGsMetalOre)) { kind = OreKind::Iron; return true; }
    if (loot_name == xv::StrStable(xv::sid::kGsStone)) { kind = OreKind::Stone; return true; }
    if (loot_name == xv::StrStable(xv::sid::kGsWood)) { kind = OreKind::Tree; return true; }
    return false;
}

static bool mineable_has_tree_hitstreaks(uint64_t mineable) {
    if (!likely_native_pointer(mineable)) return false;
    uint64_t lqa = rd_ptr(mineable + MINEABLE_EXTENSIONS);
    if (!likely_native_pointer(lqa)) return false;

    auto is_tree_ext = [](uint64_t ext) {
        if (!likely_native_pointer(ext)) return false;
        uint64_t klass = rd_ptr(ext);
        if (!likely_native_pointer(klass)) return false;
        std::string name = read_remote_string(rd_ptr(klass + 0x10));
        if (name.empty()) return false;
        return name == EXT_CLASS_TREE_HITSTREAKS ||
               name.find(xv::StrStable(xv::sid::kGsTreeHitstreak)) != std::string::npos;
    };

    uint64_t array_len = rd<uint64_t>(lqa + IL2CPP_ARRAY_LENGTH);
    if (array_len > 0 && array_len <= 32) {
        for (uint64_t i = 0; i < array_len; ++i) {
            if (is_tree_ext(rd_ptr(lqa + IL2CPP_ARRAY_FIRST_ELEMENT +
                                   i * sizeof(uint64_t))))
                return true;
        }
    }
    uint64_t items = rd_ptr(lqa + IL2CPP_LIST_ITEMS);
    int32_t list_size = rd<int32_t>(lqa + IL2CPP_LIST_SIZE);
    if (likely_native_pointer(items) && list_size > 0 && list_size <= 32) {
        for (int32_t i = 0; i < list_size; ++i) {
            if (is_tree_ext(rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT +
                                   (uint64_t)i * sizeof(uint64_t))))
                return true;
        }
    }
    return false;
}

static bool mineable_is_farmable_tree(uint64_t mineable, float max_health) {
    if (mineable_has_tree_hitstreaks(mineable)) return true;
    if (!std::isfinite(max_health) || max_health <= 0.0F) return true;
    return max_health >= MIN_FARMABLE_TREE_HEALTH;
}

static bool read_component_game_object_position(uint64_t managed_component,
                                                Vec3& position) {
    uint64_t transform = resolve_managed_component_transform(managed_component);
    return transform && read_transform_hierarchy_position(transform, position) &&
           vec3_is_finite(position);
}

static bool world_kind_from_entity_type(int32_t type, WorldKind& kind) {
    switch (type) {
    case ENTITY_TYPE_BEAR:     kind = WorldKind::Bear;     return true;
    case ENTITY_TYPE_BOAR:     kind = WorldKind::Boar;     return true;
    case ENTITY_TYPE_DEER:     kind = WorldKind::Deer;     return true;
    case ENTITY_TYPE_RABBIT:   kind = WorldKind::Rabbit;   return true;
    case ENTITY_TYPE_CHICKEN:  kind = WorldKind::Chicken;  return true;
    case ENTITY_TYPE_FISH:     kind = WorldKind::Fish;     return true;
    case ENTITY_TYPE_CANNIBAL: kind = WorldKind::Cannibal; return true;
    case ENTITY_TYPE_HARE:     kind = WorldKind::Hare;     return true;
    case ENTITY_TYPE_LOOTBOX:  kind = WorldKind::Lootbox;  return true;
    case ENTITY_TYPE_HUMAN:    kind = WorldKind::Bot;      return true;
    default: return false;
    }
}

static bool animal_kind_from_name(const std::string& name, WorldKind& kind) {
    if (name.empty()) return false;
    std::string lower;
    lower.reserve(name.size());
    for (unsigned char ch : name) lower.push_back((char)tolower(ch));

    struct Entry { const char* needle; WorldKind kind; };

    static const Entry entries[] = {
        {xv::StrStable(xv::sid::kGsChicken),  WorldKind::Chicken}, {xv::StrStable(xv::sid::kGsRu01),  WorldKind::Chicken},
        {xv::StrStable(xv::sid::kGsRabbit),   WorldKind::Rabbit},  {xv::StrStable(xv::sid::kGsRu02), WorldKind::Rabbit},
        {xv::StrStable(xv::sid::kGsHare),     WorldKind::Hare},    {xv::StrStable(xv::sid::kGsRu03),   WorldKind::Hare},
        {xv::StrStable(xv::sid::kGsWolf),     WorldKind::Wolf},    {xv::StrStable(xv::sid::kGsRu04),   WorldKind::Wolf},
        {xv::StrStable(xv::sid::kGsBoar),     WorldKind::Boar},    {xv::StrStable(xv::sid::kGsRu05),  WorldKind::Boar},
        {xv::StrStable(xv::sid::kGsBear),     WorldKind::Bear},    {xv::StrStable(xv::sid::kGsRu06), WorldKind::Bear},
        {xv::StrStable(xv::sid::kGsDeer),     WorldKind::Deer},    {xv::StrStable(xv::sid::kGsRu07),   WorldKind::Deer},
        {xv::StrStable(xv::sid::kGsStag),     WorldKind::Deer},    {xv::StrStable(xv::sid::kGsRu08),   WorldKind::Deer},
        {xv::StrStable(xv::sid::kGsFish),     WorldKind::Fish},    {xv::StrStable(xv::sid::kGsRu09),    WorldKind::Fish},
        {xv::StrStable(xv::sid::kGsRat),      WorldKind::Rabbit},  {xv::StrStable(xv::sid::kGsRu10),   WorldKind::Rabbit},
        {xv::StrStable(xv::sid::kGsMouse),    WorldKind::Rabbit},  {xv::StrStable(xv::sid::kGsRu11),   WorldKind::Rabbit},
        {xv::StrStable(xv::sid::kGsCannibal), WorldKind::Cannibal},{xv::StrStable(xv::sid::kGsRu12), WorldKind::Cannibal},
    };
    for (const Entry& e : entries) {
        if (lower.find(e.needle) != std::string::npos) {
            kind = e.kind;
            return true;
        }
    }
    return false;
}

static bool world_kind_is_humanoid(WorldKind kind) {
    return kind == WorldKind::Bot || kind == WorldKind::Cannibal;
}

static bool capture_humanoid_bounds(uint64_t behaviour, const Vec3& root,
                                    CachedWorldEntity& item) {
    if (!behaviour) return false;
    Vec3 center = rd<Vec3>(behaviour + UOH_BOUNDS_CENTER);
    Vec3 extents = rd<Vec3>(behaviour + UOH_BOUNDS_EXTENTS);
    if (!vec3_is_finite(center) || !vec3_is_finite(extents)) return false;
    if (extents.y < 0.25F || extents.y > 2.5F) return false;
    if (fabsf(extents.x) > 2.5F || fabsf(extents.z) > 2.5F) return false;
    if (fabsf(center.x - root.x) + fabsf(center.z - root.z) > 4.0F) return false;
    if (fabsf(center.y - root.y) > 4.0F) return false;
    item.bounds_center_dy = center.y - root.y;
    item.bounds_half_y = extents.y;
    item.have_bounds = true;

    item.head_offset = item.bounds_center_dy + extents.y - 0.12F;
    return true;
}

static bool read_managed_transform_world(uint64_t managed, Vec3& out) {
    if (!likely_native_pointer(managed)) return false;
    uint64_t native = rd_ptr(managed + MANAGED_CACHED_PTR);
    if (likely_native_pointer(native) &&
        read_transform_hierarchy_position(native, out) && vec3_is_finite(out))
        return true;
    return read_transform_hierarchy_position(managed, out) &&
           vec3_is_finite(out);
}

static bool read_loot_world_bounds(uint64_t loot_object, Vec3& center,
                                   Vec3& extents) {
    uint64_t list_obj = rd_ptr(loot_object + UGG_OUTLINE_RENDERERS);
    if (!likely_native_pointer(list_obj)) return false;
    uint64_t items = rd_ptr(list_obj + IL2CPP_LIST_ITEMS);
    int32_t count = rd<int32_t>(list_obj + IL2CPP_LIST_SIZE);
    if (!likely_native_pointer(items) || count <= 0 || count > 64) return false;
    uint64_t renderer = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT);
    if (!likely_native_pointer(renderer)) return false;
    uint64_t native = rd_ptr(renderer + MANAGED_CACHED_PTR);
    if (!likely_native_pointer(native)) return false;
    unsigned char block[24]{};
    if (!rd_bulk(native + RENDERER_WORLD_BOUNDS, block, sizeof(block)))
        return false;
    memcpy(&center, block, 12);
    memcpy(&extents, block + 12, 12);
    return vec3_is_finite(center) && vec3_is_finite(extents) &&
           fabsf(extents.x) < 30.0F && fabsf(extents.y) < 30.0F &&
           fabsf(extents.z) < 30.0F &&
           fabsf(extents.x) + fabsf(extents.y) + fabsf(extents.z) > 0.02F;
}

static uint64_t managed_component_game_object(uint64_t managed) {
    if (!likely_native_pointer(managed)) return 0;
    uint64_t native_component = rd_ptr(managed + MANAGED_CACHED_PTR);
    uint64_t game_object = native_component
        ? rd_ptr(native_component + NATIVE_COMPONENT_GAMEOBJECT) : 0;
    return likely_native_pointer(game_object) ? game_object : 0;
}

static bool plausible_object_name(const std::string& value) {
    if (value.size() < 3 || value.size() > 64) return false;
    int letters = 0;
    for (unsigned char ch : value) {
        if (ch < 0x20 || ch > 0x7E) return false;
        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) ++letters;
    }
    return letters >= 3;
}

static std::string read_object_name_at(uint64_t native_object, uint64_t off) {
    uint64_t name_ptr = rd_ptr(native_object + off);
    if (likely_native_pointer(name_ptr)) {
        std::string via_ptr = read_remote_string(name_ptr);
        if (plausible_object_name(via_ptr)) return via_ptr;
    }
    std::string inline_name = read_remote_string(native_object + off);
    if (plausible_object_name(inline_name)) return inline_name;
    return {};
}

static std::string read_native_object_name(uint64_t native_object) {
    if (!likely_native_pointer(native_object)) return {};

    if (g_object_name_offset) {
        std::string cached =
            read_object_name_at(native_object, g_object_name_offset);
        if (!cached.empty()) return cached;
    }

    static const uint64_t kNameOffsets[] = {0x60, 0x58, 0x68, 0x50, 0x38,
                                            0x30, 0x28, 0x70, 0x78};
    for (uint64_t off : kNameOffsets) {
        std::string value = read_object_name_at(native_object, off);
        if (value.empty()) continue;
        if (!g_object_name_offset) g_object_name_offset = off;
        return value;
    }
    return {};
}

static bool loot_kind_from_object_name(const std::string& raw, WorldKind& kind) {
    if (raw.empty()) return false;
    std::string n;
    n.reserve(raw.size());
    for (unsigned char ch : raw) {
        if (ch >= 'A' && ch <= 'Z') { n.push_back((char)(ch - 'A' + 'a')); continue; }
        if (ch >= 'a' && ch <= 'z') n.push_back((char)ch);
    }
    if (n.empty()) return false;

    if (n.find(xv::StrStable(xv::sid::kGsElite)) != std::string::npos) {
        kind = WorldKind::EliteBox;
        return true;
    }
    if (n.find(xv::StrStable(xv::sid::kGsMilitary)) != std::string::npos) {
        kind = WorldKind::MilitaryBox;
        return true;
    }
    if (n.find(xv::StrStable(xv::sid::kGsTool)) != std::string::npos) {
        kind = WorldKind::ToolBox;
        return true;
    }
    if (n.find(xv::StrStable(xv::sid::kGsWooden)) != std::string::npos ||
        n.find(xv::StrStable(xv::sid::kGsCrate)) != std::string::npos ||
        n.find(xv::StrStable(xv::sid::kGsBox)) != std::string::npos) {
        kind = WorldKind::Lootbox;
        return true;
    }
    return false;
}

static WorldKind resolve_loot_kind_cached(uint64_t loot_object,
                                          uint64_t game_object) {
    const uint64_t key = game_object ? game_object : loot_object;
    if (key) {
        auto it = g_loot_kind_by_class.find(key);
        if (it != g_loot_kind_by_class.end())
            return (WorldKind)it->second;
    }

    WorldKind kind = WorldKind::Lootbox;

    std::string name;
    if (game_object) name = read_native_object_name(game_object);
    if (name.empty()) return WorldKind::Lootbox;

    if (!loot_kind_from_object_name(name, kind))
        kind = WorldKind::Lootbox;

    if (key && g_loot_kind_by_class.size() < 8192)
        g_loot_kind_by_class[key] = (int)kind;

    return kind;
}

static bool world_kind_from_display_name(const std::string& name, WorldKind& kind) {
    if (name.empty()) return false;
    std::string lower;
    lower.reserve(name.size());
    for (unsigned char ch : name) lower.push_back((char)tolower(ch));
    return false;
}

static WorldKind refine_animal_kind(WorldKind kind, uint64_t uoh_a, uint64_t uoh_b) {
    if (!world_kind_is_animal(kind) && kind != WorldKind::Bot) return kind;
    const uint64_t sources[2] = {uoh_a, uoh_b};
    for (uint64_t source : sources) {
        if (!likely_native_pointer(source)) continue;
        uint64_t entity = rd_ptr(source + UOH_ENTITY);
        if (!likely_native_pointer(entity)) continue;
        std::string name = read_il2cpp_string(rd_ptr(entity + ENTITY_DISPLAY_NAME));
        if (name.empty()) continue;
        WorldKind refined{};
        if (animal_kind_from_name(name, refined)) return refined;
    }
    return kind;
}

static bool animal_kind_from_entity(uint64_t entity, WorldKind& kind) {
    if (!likely_native_pointer(entity)) return false;
    std::string name = read_il2cpp_string(rd_ptr(entity + ENTITY_DISPLAY_NAME));
    return animal_kind_from_name(name, kind);
}

static bool read_entity_health_checked(uint64_t entity, float& health) {
    health = -1.0F;
    if (!likely_native_pointer(entity)) return false;
    uint64_t value = rd_ptr(entity + ENTITY_HEALTH_VALUE);
    if (!likely_native_pointer(value)) return false;
    float current = 0.0F;
    if (!rd_exact(value + REASONED_VALUE_CURRENT, current)) return false;
    if (!std::isfinite(current) || current < 0.0F || current >= 100000.0F)
        return false;
    health = current;
    return true;
}

static void world_scan_process_identity(uint64_t identity, double now) {

    if (g_network_identity_class && rd_ptr(identity) != g_network_identity_class)
        return;

    unsigned char block[NPC_IDENTITY_BLOCK_SIZE]{};
    if (!rd_bulk(identity + NETWORK_IDENTITY_NET_ID, block, sizeof(block)))
        return;
    uint32_t net_id = 0;
    memcpy(&net_id, block, sizeof(net_id));
    uint8_t destroy_called =
        block[NETWORK_IDENTITY_DESTROY_CALLED - NETWORK_IDENTITY_NET_ID];
    uint64_t behaviours = 0;
    memcpy(&behaviours,
           block + (NETWORK_IDENTITY_BEHAVIOURS - NETWORK_IDENTITY_NET_ID),
           sizeof(behaviours));
    if (destroy_called != 0 || !net_id) {
        g_world_cache.erase((uint64_t)net_id);
        g_ore_world_cache.erase((uint64_t)net_id);
        return;
    }

    {
        auto world_it = g_world_cache.find((uint64_t)net_id);
        if (world_it != g_world_cache.end()) world_it->second.last_seen = now;
        auto ore_it = g_ore_world_cache.find((uint64_t)net_id);
        if (ore_it != g_ore_world_cache.end()) ore_it->second.last_seen = now;
    }
    uint64_t count = behaviours ? rd<uint64_t>(behaviours + IL2CPP_ARRAY_LENGTH) : 0;
    if (!behaviours || count == 0 || count > 64) return;
    std::vector<uint64_t> snapshot((size_t)count);
    if (!rd_bulk(behaviours + IL2CPP_ARRAY_FIRST_ELEMENT, snapshot.data(),
                 snapshot.size() * sizeof(uint64_t)))
        return;

    uint64_t ore = 0, mineable = 0, death_handler = 0, npc_death = 0;
    uint64_t bot_brain = 0, cannibal_brain = 0, animal_brain = 0;
    uint64_t random_loot = 0, loot_object = 0, loot_on_death = 0;
    uint64_t player_death = 0;
    uint64_t fish = 0, cupboard = 0, turret = 0;
    for (uint64_t behaviour : snapshot) {
        if (!behaviour || !likely_native_pointer(behaviour)) continue;
        uint64_t linked = rd_ptr(behaviour + NETWORK_BEHAVIOUR_IDENTITY);
        if (linked && linked != identity) continue;
        uint32_t flags = classify_behaviour_flags(behaviour);
        if ((flags & kBehavOre) && !ore) ore = behaviour;
        else if ((flags & kBehavBotBrain) && !bot_brain) bot_brain = behaviour;
        else if ((flags & kBehavCannibalBrain) && !cannibal_brain) cannibal_brain = behaviour;
        else if ((flags & kBehavNpcHumanDeath) && !npc_death) npc_death = behaviour;
        else if ((flags & kBehavRandomSpawnLoot) && !random_loot) random_loot = behaviour;
        else if ((flags & kBehavLootOnDeath) && !loot_on_death) loot_on_death = behaviour;
        else if ((flags & kBehavPlayerDeath) && !player_death) player_death = behaviour;
        else if ((flags & kBehavLootObject) && !loot_object) loot_object = behaviour;
        else if ((flags & kBehavDeathHandler) && !death_handler) death_handler = behaviour;
        else if ((flags & kBehavMineable) && !mineable) mineable = behaviour;
        else if ((flags & kBehavAnimalBrain) && !animal_brain) animal_brain = behaviour;
        else if ((flags & kBehavFish) && !fish) fish = behaviour;
        else if ((flags & kBehavCupboard) && !cupboard) cupboard = behaviour;
        else if ((flags & kBehavTurret) && !turret) turret = behaviour;
    }

    if (loot_on_death) {
        uint64_t container = rd_ptr(loot_on_death + LOOT_ON_DEATH_CONTAINER);
        if (likely_native_pointer(container) &&
            g_death_containers.size() < 4096)
            g_death_containers.insert(container);
    }

    if (player_death) {
        uint64_t backpack = rd_ptr(player_death + PLAYER_DEATH_BACKPACK);
        if (likely_native_pointer(backpack)) {
            uint64_t native_backpack = rd_ptr(backpack + MANAGED_CACHED_PTR);
            if (likely_native_pointer(native_backpack) &&
                g_player_backpacks.size() < 4096)
                g_player_backpacks.insert(native_backpack);
        }
    }

    uint64_t brain = bot_brain ? bot_brain : cannibal_brain;
    if (ore) {
        OreKind ore_kind{};
        std::string loot_name;
        bool classified = ore_kind_from_mineable(ore, ore_kind, loot_name);
        if (!classified) {
            return;
        }
        if (ore_kind == OreKind::Tree && !g_tree_scan_enabled.load()) {
            g_ore_world_cache.erase((uint64_t)net_id);
            return;
        }
        float fraction = rd<float>(ore + MINEABLE_FRACTION_REMAINING);
        float ore_current = rd<float>(ore + MINEABLE_CURRENT_HEALTH);
        float ore_maximum = rd<float>(ore + MINEABLE_MAX_HEALTH);
        bool depleted = (std::isfinite(fraction) && fraction <= 0.0001F) ||
            (std::isfinite(ore_current) && std::isfinite(ore_maximum) &&
             ore_maximum > 0.0F && ore_current <= 0.0001F);
        if (depleted) {
            g_ore_world_cache.erase((uint64_t)net_id);
            return;
        }
        auto existing = g_ore_world_cache.find((uint64_t)net_id);
        if (existing != g_ore_world_cache.end()) {
            existing->second.kind = ore_kind;
            existing->second.last_seen = now;
            existing->second.identity = identity;
            existing->second.ore_behaviour = ore;
            existing->second.max_health = ore_maximum;
            if (ore_kind == OreKind::Tree && !existing->second.farmable_known) {
                existing->second.farmable =
                    mineable_is_farmable_tree(ore, ore_maximum);
                existing->second.farmable_known = true;
            }
            return;
        }

        bool farmable = true;
        bool farmable_known = false;
        if (ore_kind == OreKind::Tree) {
            farmable = mineable_is_farmable_tree(ore, ore_maximum);
            farmable_known = true;
        }
        Vec3 ore_world{};
        bool have_pos = read_component_game_object_position(ore, ore_world) &&
            vec3_is_finite(ore_world) &&
            fabsf(ore_world.x) + fabsf(ore_world.y) + fabsf(ore_world.z) >= 0.01F;
        if (have_pos) {
            CachedOreWorld entry{};
            entry.position = ore_world;
            entry.kind = ore_kind;
            entry.key = (uint64_t)net_id;
            entry.last_seen = now;
            entry.identity = identity;
            entry.ore_behaviour = ore;
            entry.max_health = ore_maximum;
            entry.farmable = farmable;
            entry.farmable_known = farmable_known;
            g_ore_world_cache[(uint64_t)net_id] = entry;
        }
        return;
    }

    if (brain) {
        bool dead = false;
        if (npc_death &&
            rd<uint8_t>(npc_death + NPC_HUMANOID_DEATH_FLAG) != 0)
            dead = true;
        uint64_t entity = rd_ptr(brain + UOH_ENTITY);
        if (!likely_native_pointer(entity)) entity = 0;
        std::string name;
        float health = -1.0F;
        bool health_ok = read_entity_health_checked(entity, health);
        if (!dead && health_ok && health <= 0.01F) dead = true;
        if (dead) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }
        Vec3 world{};
        if (!read_component_game_object_position(brain, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        if (entity)
            name = read_il2cpp_string(rd_ptr(entity + ENTITY_DISPLAY_NAME));

        auto existing = g_world_cache.find((uint64_t)net_id);
        CachedWorldEntity item{};
        if (existing != g_world_cache.end()) {
            item.bounds_center_dy = existing->second.bounds_center_dy;
            item.bounds_half_y = existing->second.bounds_half_y;
            item.have_bounds = existing->second.have_bounds;
            item.head_offset = existing->second.head_offset;
            item.head_transform = existing->second.head_transform;
        }
        item.position = world;
        item.kind = bot_brain ? WorldKind::Bot : WorldKind::Cannibal;
        item.key = net_id;
        item.behaviour = brain;
        item.entity = entity;
        item.name = std::move(name);
        item.last_seen = now;

        uint64_t model_info = rd_ptr(brain + (bot_brain ? NPC_BOT_MODEL_INFO
                                                        : NPC_CANNIBAL_MODEL_INFO));
        if (likely_native_pointer(model_info)) {
            uint64_t head = rd_ptr(model_info + NPC_MODEL_HEAD_TRANSFORM);
            if (likely_native_pointer(head)) {
                item.head_transform = head;
                Vec3 head_pos{};
                if (read_managed_transform_world(head, head_pos) &&
                    vec3_is_finite(head_pos) &&
                    fabsf(head_pos.y - world.y) < 3.0F) {
                    item.head_offset = head_pos.y - world.y;
                }
            }
        }
        capture_humanoid_bounds(brain, world, item);
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    if (turret) {
        Vec3 world{};
        if (!read_component_game_object_position(turret, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        CachedWorldEntity item{};
        item.position = world;
        item.kind = WorldKind::Turret;
        item.key = net_id;
        item.behaviour = turret;
        item.last_seen = now;
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    

    if (cupboard) {
        Vec3 world{};
        if (!read_component_game_object_position(cupboard, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        CachedWorldEntity item{};
        item.position = world;
        item.kind = WorldKind::Cupboard;
        item.key = net_id;
        item.behaviour = cupboard;
        item.last_seen = now;
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    
    if (fish) {
        uint64_t fish_death = rd_ptr(fish + FISH_DEATH_HANDLER);
        uint64_t entity = fish_death
            ? rd_ptr(fish_death + UOH_ENTITY) : 0;
        if (!likely_native_pointer(entity)) entity = 0;
        if (fish_death &&
            rd<uint8_t>(fish_death + DEATH_HANDLER_DEATH_FLAG) != 0) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }
        std::string name;
        if (entity)
            name = read_il2cpp_string(rd_ptr(entity + ENTITY_DISPLAY_NAME));
        WorldKind kind = WorldKind::Fish;
        WorldKind refined{};
        if (animal_kind_from_entity(entity, refined)) kind = refined;
        else if (animal_kind_from_name(name, refined)) kind = refined;
        Vec3 world{};
        if (!read_component_game_object_position(fish, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        CachedWorldEntity item{};
        item.position = world;
        item.kind = kind;
        item.key = net_id;
        item.behaviour = fish;
        item.entity = entity;
        item.name = std::move(name);
        item.last_seen = now;
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    if (death_handler) {
        int32_t type = rd<int32_t>(death_handler + DEATH_HANDLER_ENTITY_TYPE);
        bool dead = rd<uint8_t>(death_handler + DEATH_HANDLER_DEATH_FLAG) != 0;
        if (dead) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }
        uint64_t entity = rd_ptr(death_handler + UOH_ENTITY);
        if (!likely_native_pointer(entity)) entity = 0;
        std::string name;
        if (entity)
            name = read_il2cpp_string(rd_ptr(entity + ENTITY_DISPLAY_NAME));

        WorldKind kind{};
        bool classified = world_kind_from_entity_type(type, kind);
        if (classified && kind == WorldKind::Lootbox) {
            uint64_t death_go = managed_component_game_object(death_handler);
            kind = resolve_loot_kind_cached(death_handler, death_go);
        }
        if (classified && world_kind_is_animal(kind)) {

            kind = refine_animal_kind(kind, death_handler, animal_brain);
        } else if (!classified) {

            
            WorldKind by_name{};
            if (animal_kind_from_entity(entity, by_name)) {
                kind = by_name;
                classified = true;
            } else {
                classified = world_kind_from_display_name(name, kind);
            }
        }
        if (classified) {
            Vec3 world{};
            if (read_component_game_object_position(death_handler, world) &&
                vec3_is_finite(world) &&
                fabsf(world.x) + fabsf(world.y) + fabsf(world.z) >= 0.01F) {
                CachedWorldEntity item{};
                item.position = world;
                item.kind = kind;
                item.key = net_id;
                item.behaviour = death_handler;
                item.entity = entity;
                item.name = std::move(name);
                item.last_seen = now;
                g_world_cache[(uint64_t)net_id] = std::move(item);
            }
            return;
        }

    }

    if (random_loot) {

        int32_t type = rd<int32_t>(random_loot + MINEABLE_ENTITY_TYPE);
        Vec3 world{};
        if (!read_component_game_object_position(random_loot, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        if (type == ENTITY_TYPE_BARREL) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }
        uint64_t spawn_go = managed_component_game_object(random_loot);
        WorldKind spawn_kind = resolve_loot_kind_cached(random_loot, spawn_go);

        CachedWorldEntity item{};
        item.position = world;
        item.kind = spawn_kind;
        item.key = net_id;
        item.behaviour = random_loot;
        item.last_seen = now;
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    if (mineable) {
        int32_t type = rd<int32_t>(mineable + MINEABLE_ENTITY_TYPE);
        WorldKind kind{};
        if (!world_kind_from_entity_type(type, kind)) return;
        if (kind == WorldKind::Lootbox) {
            uint64_t mineable_go = managed_component_game_object(mineable);
            kind = resolve_loot_kind_cached(mineable, mineable_go);
        }
        if (world_kind_is_animal(kind))
            kind = refine_animal_kind(kind, death_handler, animal_brain);
        float current = 0.0F, maximum = 0.0F;
        bool health_read = rd_exact(mineable + MINEABLE_CURRENT_HEALTH, current) &&
                           rd_exact(mineable + MINEABLE_MAX_HEALTH, maximum);

        if (health_read && std::isfinite(maximum) && maximum > 0.0F &&
            std::isfinite(current) && current <= 0.0001F) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }
        Vec3 world{};
        if (!read_component_game_object_position(mineable, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;
        CachedWorldEntity item{};
        item.position = world;
        item.kind = kind;
        item.key = net_id;
        item.behaviour = mineable;
        item.last_seen = now;
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

    if (loot_object && !loot_on_death &&
        g_death_containers.find(loot_object) == g_death_containers.end()) {
        if (rd_ptr(loot_object + LOOT_OBJECT_BUILDING_PIECE) != 0) return;

        uint64_t self_game_object = managed_component_game_object(loot_object);
        if (self_game_object &&
            g_player_backpacks.find(self_game_object) != g_player_backpacks.end())
            return;

        uint8_t is_lootable = rd<uint8_t>(loot_object + LOOT_OBJECT_IS_LOOTABLE);
        std::string panel = read_il2cpp_string(
            rd_ptr(loot_object + LOOT_OBJECT_PANEL_NAME));
        if (panel == xv::StrStable(xv::sid::kGsPlayerloot) || panel == xv::StrStable(xv::sid::kGsPlayerLoot))
            return;

        if (!is_lootable) {
            g_world_cache.erase((uint64_t)net_id);
            return;
        }

        Vec3 bounds_center{}, bounds_extents{};
        bool have_bounds =
            read_loot_world_bounds(loot_object, bounds_center, bounds_extents);

        Vec3 world{};
        if (!read_component_game_object_position(loot_object, world) ||
            !vec3_is_finite(world) ||
            fabsf(world.x) + fabsf(world.y) + fabsf(world.z) < 0.01F)
            return;

        if (have_bounds &&
            (fabsf(bounds_center.x - world.x) > 6.0F ||
             fabsf(bounds_center.z - world.z) > 6.0F))
            have_bounds = false;
        WorldKind loot_kind =
            resolve_loot_kind_cached(loot_object, self_game_object);

        CachedWorldEntity item{};
        item.position = world;
        item.kind = loot_kind;
        item.key = net_id;
        item.behaviour = loot_object;
        item.last_seen = now;
        if (have_bounds) {
            item.bounds_center_dy = bounds_center.y - world.y;
            item.bounds_half_y = fabsf(bounds_extents.y);
            item.have_bounds = true;
        }
        g_world_cache[(uint64_t)net_id] = std::move(item);
        return;
    }

}

static void world_scan_tick() {
    if (g_pid <= 0 || !g_il2cpp_base) return;
    const double now = monotonic_seconds();

    if (now - g_scanner.last_dictionary_read >= WORLD_SCAN_DICTIONARY_INTERVAL) {
        g_scanner.last_dictionary_read = now;
        std::vector<uint64_t> identities;
        bool dict_ok = read_spawned_network_identities(identities);
        if (dict_ok) {
            g_scanner.identities.swap(identities);
            if (g_scanner.cursor >= g_scanner.identities.size())
                g_scanner.cursor = 0;
            std::unordered_set<uint64_t> alive(g_scanner.identities.begin(),
                                               g_scanner.identities.end());
            for (auto it = g_ore_world_cache.begin();
                 it != g_ore_world_cache.end();) {
                if (it->second.identity && !alive.count(it->second.identity))
                    it = g_ore_world_cache.erase(it);
                else
                    ++it;
            }
            g_scanner.last_identities_ok = now;
        }
    }

    const size_t n = g_scanner.identities.size();
    if (n == 0) {
        if (g_scanner.last_identities_ok > 0.0 &&
            now - g_scanner.last_identities_ok > 3.0) {
            g_ore_world_cache.clear();
            g_world_cache.clear();
        }
        return;
    }

    double budget = WORLD_SCAN_FRAME_BUDGET_SECONDS;
    int boost = g_scan_boost_frames.load(std::memory_order_acquire);
    if (boost > 0) {
        g_scan_boost_frames.store(boost - 1, std::memory_order_release);
        budget = WORLD_SCAN_FRAME_BUDGET_SECONDS * 6.0;
    }
    const double deadline = monotonic_seconds() + budget;
    bool wrapped = false;
    for (size_t processed = 0; processed < n; ++processed) {
        if (g_scanner.cursor == 0) {
            if (!wrapped && g_scanner.cycle_started > 0.0) {
                g_scanner.last_cycle_duration = now - g_scanner.cycle_started;
            }
            g_scanner.cycle_started = now;
            wrapped = true;
        }
        if (processed > 0 && monotonic_seconds() >= deadline) break;
        uint64_t identity = g_scanner.identities[g_scanner.cursor];
        g_scanner.cursor = (g_scanner.cursor + 1) % n;
        if (identity) world_scan_process_identity(identity, now);
    }

    if (now - g_scanner.last_prune >= WORLD_SCAN_PRUNE_INTERVAL) {
        g_scanner.last_prune = now;
        double ttl = WORLD_SCAN_MIN_ENTRY_TTL_SECONDS;
        if (g_scanner.last_cycle_duration > 0.0)
            ttl = std::max(ttl, g_scanner.last_cycle_duration * 3.0);
        if (ttl > WORLD_SCAN_MAX_ENTRY_TTL_SECONDS)
            ttl = WORLD_SCAN_MAX_ENTRY_TTL_SECONDS;
        for (auto it = g_ore_world_cache.begin(); it != g_ore_world_cache.end();) {
            if (now - it->second.last_seen > ttl) it = g_ore_world_cache.erase(it);
            else ++it;
        }
        for (auto it = g_world_cache.begin(); it != g_world_cache.end();) {
            if (now - it->second.last_seen > ttl) it = g_world_cache.erase(it);
            else ++it;
        }
        g_death_containers.clear();
        g_player_backpacks.clear();
    }

    int bots = 0;
    for (const auto& pair : g_world_cache) {
        switch (pair.second.kind) {
        case WorldKind::Bot:
        case WorldKind::Cannibal: {
            bool dead = false;
            if (pair.second.entity) {
                float health = -1.0F;
                if (read_entity_health_checked(pair.second.entity, health) &&
                    health <= 0.01F)
                    dead = true;
            }
            if (!dead) ++bots;
            break;
        }
        default:
            break;
        }
    }
    g_world_stat_bots_alive = bots;
}

std::vector<OreEspPoint> esp_get_ores(int overlay_width, int overlay_height,
                                     bool sulfur, bool iron, bool stone,
                                     bool tree) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    std::vector<OreEspPoint> result;
    if ((!sulfur && !iron && !stone && !tree) || g_pid <= 0 || !g_il2cpp_base)
        return result;

    float sw = overlay_width >= 100 ? (float)overlay_width : 1920.0F;
    float sh = overlay_height >= 100 ? (float)overlay_height : 1080.0F;
    uint64_t local_player = resolve_local_player();

    if (!sample_overlay_camera(local_player, sw, sh)) return result;
    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 camera_position = snap.camera_position;

    result.reserve(g_ore_world_cache.size());
    for (const auto& pair : g_ore_world_cache) {
        const CachedOreWorld& ore = pair.second;
        if ((ore.kind == OreKind::Sulfur && !sulfur) ||
            (ore.kind == OreKind::Iron && !iron) ||
            (ore.kind == OreKind::Stone && !stone) ||
            (ore.kind == OreKind::Tree && !tree))
            continue;
        float dx = ore.position.x - camera_position.x;
        float dy = ore.position.y - camera_position.y;
        float dz = ore.position.z - camera_position.z;
        float distance = sqrtf(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(distance) || distance > MAX_ORE_ESP_DISTANCE) continue;
        if (ore.kind == OreKind::Tree && distance > MAX_TREE_ESP_DISTANCE) continue;
        Vec2 screen{};
        bool projected = project_world(snap, ore.position, sw, sh, screen, true);
        if (!projected) continue;

        result.push_back({screen.x, screen.y, distance, ore.kind});
    }
    return result;
}

bool world_kind_is_animal(WorldKind kind) {
    switch (kind) {
    case WorldKind::Bear:
    case WorldKind::Boar:
    case WorldKind::Deer:
    case WorldKind::Rabbit:
    case WorldKind::Chicken:
    case WorldKind::Cannibal:
    case WorldKind::Hare:
    case WorldKind::Wolf:
    case WorldKind::Fish:
        return true;
    default:
        return false;
    }
}

std::vector<WorldEspPoint> esp_get_world(int overlay_width, int overlay_height,
                                         bool animals, bool crates,
                                         bool humanoids) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    std::vector<WorldEspPoint> result;
    if ((!animals && !crates && !humanoids) || g_pid <= 0 || !g_il2cpp_base)
        return result;

    float sw = overlay_width >= 100 ? (float)overlay_width : 1920.0F;
    float sh = overlay_height >= 100 ? (float)overlay_height : 1080.0F;
    uint64_t local_player = resolve_local_player();

    if (!sample_overlay_camera(local_player, sw, sh)) return result;
    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 camera = snap.camera_position;

    result.reserve(g_world_cache.size());
    for (auto& pair : g_world_cache) {
        CachedWorldEntity& entity = pair.second;
        const bool humanoid = world_kind_is_humanoid(entity.kind);

        if (humanoid) {
            if (!humanoids) continue;
        } else if (world_kind_is_animal(entity.kind)) {
            if (!animals) continue;
        } else if (!crates) {
            continue;
        }

        if ((humanoid || world_kind_is_animal(entity.kind)) && entity.behaviour) {
            Vec3 live{};
            if (!read_component_game_object_position(entity.behaviour, live) ||
                !vec3_is_finite(live))
                continue;
            entity.position = live;
        }
        float dx = entity.position.x - camera.x;
        float dy = entity.position.y - camera.y;
        float dz = entity.position.z - camera.z;
        float distance = sqrtf(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(distance) || distance > MAX_ORE_ESP_DISTANCE) continue;

        Vec2 screen{};
        if (!project_world(snap, entity.position, sw, sh, screen, !humanoid))
            continue;

        float height_pixels = 0.0F;
        float top_offset_pixels = 0.0F;
        if (humanoid) {
            bool have_box = false;
            if (entity.head_transform) {
                Vec3 head{};
                if (read_managed_transform_world(entity.head_transform, head)) {
                    Vec3 bottom = {head.x, head.y - 1.55F, head.z};
                    Vec3 top = {head.x, head.y + 0.18F, head.z};
                    Vec2 bs{}, ts{};
                    if (project_world(snap, bottom, sw, sh, bs, false) &&
                        project_world(snap, top, sw, sh, ts, false)) {
                        float h = fabsf(bs.y - ts.y);
                        if (std::isfinite(h) && h >= 3.0F && h < sh * 4.0F) {
                            height_pixels = h;
                            top_offset_pixels = screen.y - ts.y;
                            if (top_offset_pixels < 0.0F) top_offset_pixels = 0.0F;
                            have_box = true;
                        }
                    }
                }
            }
            if (!have_box && entity.have_bounds) {
                Vec3 bottom = {entity.position.x,
                               entity.position.y + entity.bounds_center_dy -
                                   entity.bounds_half_y,
                               entity.position.z};
                Vec3 top = {entity.position.x,
                            entity.position.y + entity.bounds_center_dy +
                                entity.bounds_half_y,
                            entity.position.z};
                Vec2 bs{}, ts{};
                if (project_world(snap, bottom, sw, sh, bs, false) &&
                    project_world(snap, top, sw, sh, ts, false)) {
                    float h = fabsf(bs.y - ts.y);
                    if (std::isfinite(h) && h >= 3.0F && h < sh * 4.0F) {
                        height_pixels = h;
                        top_offset_pixels = screen.y - ts.y;
                        if (top_offset_pixels < 0.0F) top_offset_pixels = 0.0F;
                        have_box = true;
                    }
                }
            }
            if (!have_box) {

                Vec3 top = {entity.position.x, entity.position.y + 1.75F,
                            entity.position.z};
                Vec2 top_screen{};
                if (project_world(snap, top, sw, sh, top_screen, false)) {
                    float h = fabsf(top_screen.y - screen.y);
                    if (std::isfinite(h) && h >= 2.0F && h < sh * 4.0F) {
                        height_pixels = h;
                        top_offset_pixels = h * 0.5F;
                    }
                }
            }
        }

        float hp = -1.0F, hp_max = -1.0F;
        if (entity.entity) {
            float cur = -1.0F;
            if (read_entity_health_checked(entity.entity, cur)) {
                hp = cur;
                hp_max = cur > 100.0F ? cur : 100.0F;
            }
        }
        WorldEspPoint point{};
        point.x = screen.x;
        point.y = screen.y;
        point.distance = distance;
        point.kind = entity.kind;
        point.health = hp;
        point.max_health = hp_max;
        point.name = entity.name;
        point.height = height_pixels;
        point.top_offset = top_offset_pixels;
        result.push_back(std::move(point));
    }

    return result;
}



static uint64_t g_aim_locked_bot = 0;

static float s_aim_vel_yaw = 0.0f;
static float s_aim_vel_pitch = 0.0f;
static double s_aim_last_time = 0.0;
static uint64_t s_aim_last_target = 0;
static float s_aim_prev_tx = 0.0f;
static float s_aim_prev_ty = 0.0f;
static float s_aim_prev_tz = 0.0f;
static double s_aim_prev_t_time = 0.0;
static bool s_aim_has_prev_t = false;

static void memory_aim_reset() {
    s_aim_vel_yaw = 0.0f;
    s_aim_vel_pitch = 0.0f;
    s_aim_last_time = 0.0;
    s_aim_last_target = 0;
    s_aim_has_prev_t = false;
}

static void reset_aim_lock() {
    g_aim_locked_target = 0;
    g_aim_locked_bot = 0;
    g_aim_locked_selection = -1;
    memory_aim_reset();
}

static bool evaluate_bot_target(const CachedWorldEntity& bot,
                                const OverlayProjectionSnapshot& snap,
                                float sw, float sh, const Vec3& camera,
                                Vec2& screen, Vec3& world, float& out_dist) {
    out_dist = 0.0F;
    if (!world_kind_is_humanoid(bot.kind) || !bot.behaviour) return false;

    if (bot.entity) {
        float health = -1.0F;
        if (read_entity_health_checked(bot.entity, health) && health <= 0.01F)
            return false;
    }
    Vec3 position = bot.position;
    Vec3 live{};
    if (read_component_game_object_position(bot.behaviour, live) &&
        vec3_is_finite(live))
        position = live;
    float dx = position.x - camera.x;
    float dy = position.y - camera.y;
    float dz = position.z - camera.z;
    float distance2 = dx * dx + dy * dy + dz * dz;
    if (!std::isfinite(distance2) ||
        distance2 > MAX_AIM_DISTANCE * MAX_AIM_DISTANCE) return false;
    out_dist = sqrtf(distance2);

    Vec3 head{};
    if (!read_managed_transform_world(bot.head_transform, head)) {
        head = {position.x, position.y + bot.head_offset, position.z};
    }
    if (!project_world(snap, head, sw, sh, screen, false)) return false;
    world = head;
    return std::isfinite(screen.x) && std::isfinite(screen.y);
}

int esp_get_bot_aims(float sw, float sh, unsigned long long* ids,
                     float* sx, float* sy, float* dist, int maxn) {
    if (!ids || !sx || !sy || !dist || maxn <= 0) return 0;
    std::lock_guard<std::mutex> lock(g_game_mutex);
    int n = 0;
    if (g_pid <= 0 || !g_il2cpp_base) return 0;
    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 local = snap.camera_position;
    for (const auto& pair : g_world_cache) {
        if (n >= maxn) break;
        const CachedWorldEntity& bot = pair.second;
        Vec2 scr{};
        Vec3 world{};
        float d = 0.f;
        if (!evaluate_bot_target(bot, snap, sw, sh, local, scr, world, d)) continue;
        ids[n] = bot.key;
        sx[n] = scr.x;
        sy[n] = scr.y;
        dist[n] = d;
        ++n;
    }
    return n;
}

static bool read_bone_world_position(uint64_t bone, Vec3& target) {
    if (!bone) return false;

    if (read_transform_hierarchy_position(bone, target) && vec3_is_finite(target))
        return true;
    uint64_t cached = rd_ptr(bone + MANAGED_CACHED_PTR);
    return cached && cached != bone &&
        read_transform_hierarchy_position(cached, target) && vec3_is_finite(target);
}

static uint64_t read_relative_ptr(uint64_t field) {
    int64_t rel = 0;
    if (!field || !rd_exact(field, rel) || rel == 0) return 0;
    return field + (uint64_t)rel;
}

static uint64_t resolve_human_bone_transform_anim(uint64_t managed, int32_t human_bone) {
    if (!managed) return 0;
    uint64_t anim = rd_ptr(managed + MANAGED_CACHED_PTR);
    if (!likely_native_pointer(anim)) return 0;
    if (human_bone < 0 || human_bone > 54) return 0;

    const AnimatorBonePath* path = animator_bone_path(anim);
    if (!path) return 0;

    int32_t mapped = -1;
    if (human_bone <= 24) {
        mapped = path->human_inline[human_bone];
    } else if (human_bone <= 39) {
        mapped = path->have_left ? path->human_left[human_bone - 25] : -1;
    } else {
        mapped = path->have_right ? path->human_right[human_bone - 40] : -1;
    }
    if (mapped < 0) return 0;
    if ((size_t)mapped >= path->skeleton_bones.size()) return 0;

    int32_t skel = path->skeleton_bones[(size_t)mapped];
    if (skel < 0) return 0;

    uint64_t xform = 0;
    if (path->fast) {
        xform = rd_ptr(path->fast_array + (uint64_t)skel * 8);
    } else {
        const size_t count = path->entries_block.size() / NATIVE_TRANSFORM_MAP_ENTRY_SIZE;
        for (size_t i = 0; i < count; ++i) {
            const uint8_t* entry = path->entries_block.data() + i * NATIVE_TRANSFORM_MAP_ENTRY_SIZE;
            int32_t key = 0;
            memcpy(&key, entry + NATIVE_TRANSFORM_MAP_ENTRY_KEY, sizeof(key));
            if (key != skel) continue;
            memcpy(&xform, entry, sizeof(xform));
            break;
        }
        if (!xform) return 0;
    }
    if (!likely_native_pointer(xform)) return 0;
    return xform;
}

static void dump_skeleton_animators(uint64_t player, bool dead, uint64_t& live,
                                    uint64_t& ragdoll_anim, uint64_t& ragdoll) {
    live = ragdoll_anim = ragdoll = 0;
    uint64_t managed = rd_ptr(player + PLAYER_ANIMATOR);
    if (likely_native_pointer(managed)) live = managed;

    if (!dead) return;
    ragdoll = resolve_player_ragdoll(player);
    if (!ragdoll) return;
    uint64_t extra = rd_ptr(ragdoll + RAGDOLL_ANIMATOR);
    if (likely_native_pointer(extra) && extra != live) ragdoll_anim = extra;
    if (!live) live = ragdoll_anim;
}

static uint64_t resolve_bone_transform(uint64_t player, int32_t human,
                                       uint64_t live_anim, uint64_t ragdoll_anim) {
    (void)player;
    uint64_t xf = resolve_human_bone_transform_anim(live_anim, human);
    if (!xf && ragdoll_anim)
        xf = resolve_human_bone_transform_anim(ragdoll_anim, human);
    return xf;
}

static void read_dump_skeleton(uint64_t player, bool dead, Vec3 worlds[55],
                               uint8_t ok[55], Vec3 rag[32], int& rag_n) {
    for (int i = 0; i < 55; ++i) ok[i] = 0;
    rag_n = 0;
    if (!player) return;

    uint64_t anim = 0, ragdoll_anim = 0, ragdoll = 0;
    dump_skeleton_animators(player, dead, anim, ragdoll_anim, ragdoll);

    uint64_t human_xf[55]{};
    for (int32_t human = 0; human <= 54; ++human) {
        if (!skeleton_draw_bone(human)) continue;
        uint64_t xf = resolve_bone_transform(player, human, anim, ragdoll_anim);
        human_xf[human] = xf;
        if (!xf) continue;
        Vec3 pos{};
        if (read_bone_world_position(xf, pos)) {
            worlds[human] = pos;
            ok[human] = 1;
        }
        (void)0;

    }

    if (ok[HUMAN_BONE_HIPS]) {
        const Vec3& hips = worlds[HUMAN_BONE_HIPS];
        struct BoneLimit { int32_t bone; float max_dist; };
        static const BoneLimit kFromHips[] = {
            {HUMAN_BONE_SPINE,           0.55F},
            {HUMAN_BONE_CHEST,           0.85F},
            {HUMAN_BONE_UPPER_CHEST,     1.05F},
            {HUMAN_BONE_NECK,            1.25F},
            {HUMAN_BONE_HEAD,            1.50F},

            {HUMAN_BONE_LEFT_SHOULDER,   1.35F},
            {HUMAN_BONE_RIGHT_SHOULDER,  1.35F},
            {HUMAN_BONE_LEFT_UPPER_ARM,  1.55F},
            {HUMAN_BONE_RIGHT_UPPER_ARM, 1.55F},
            {HUMAN_BONE_LEFT_LOWER_ARM,  1.90F},
            {HUMAN_BONE_RIGHT_LOWER_ARM, 1.90F},
            {HUMAN_BONE_LEFT_HAND,       2.15F},
            {HUMAN_BONE_RIGHT_HAND,      2.15F},

            {HUMAN_BONE_LEFT_UPPER_LEG,  0.50F},
            {HUMAN_BONE_RIGHT_UPPER_LEG, 0.50F},
            {HUMAN_BONE_LEFT_LOWER_LEG,  1.05F},
            {HUMAN_BONE_RIGHT_LOWER_LEG, 1.05F},
            {HUMAN_BONE_LEFT_FOOT,       1.55F},
            {HUMAN_BONE_RIGHT_FOOT,      1.55F},
            {HUMAN_BONE_LEFT_TOES,       1.85F},
            {HUMAN_BONE_RIGHT_TOES,      1.85F},
        };
        for (const BoneLimit& limit : kFromHips) {
            if (!ok[limit.bone]) continue;
            const Vec3& b = worlds[limit.bone];
            float dx = b.x - hips.x, dy = b.y - hips.y, dz = b.z - hips.z;
            float d = sqrtf(dx * dx + dy * dy + dz * dz);
            if (!std::isfinite(d) || d > limit.max_dist) {
                ok[limit.bone] = 0;
            }
        }
    }

    if (!ragdoll) return;
    uint64_t array = rd_ptr(ragdoll + RAGDOLL_BONES);
    uint64_t len = array ? rd<uint64_t>(array + IL2CPP_ARRAY_LENGTH) : 0;
    if (len > 32) len = 32;

    uint64_t human_native[55]{};
    for (int32_t human = 0; human <= 54; ++human) {
        if (!human_xf[human]) continue;
        uint64_t cached = rd_ptr(human_xf[human] + MANAGED_CACHED_PTR);
        human_native[human] = likely_native_pointer(cached) ? cached : 0;
    }

    for (uint64_t i = 0; i < len; ++i) {
        uint64_t rb = rd_ptr(array + IL2CPP_ARRAY_FIRST_ELEMENT + i * 8);
        if (!likely_native_pointer(rb)) continue;
        uint64_t xf = resolve_managed_component_transform(rb);
        Vec3 pos{};
        if (!xf || !read_transform_hierarchy_position(xf, pos) || !vec3_is_finite(pos))
            continue;
        if (rag_n < 32) {
            rag[rag_n] = pos;
            ++rag_n;
        }
        for (int32_t human = 0; human <= 54; ++human) {
            if (!human_xf[human]) continue;
            if (human_xf[human] != xf && human_native[human] != xf) continue;
            worlds[human] = pos;
            ok[human] = 1;
        }
    }
    if (!ok[HUMAN_BONE_HIPS]) {
        uint64_t pelvis = rd_ptr(ragdoll + RAGDOLL_PELVIS);
        uint64_t xf = resolve_managed_component_transform(pelvis);
        Vec3 pos{};
        if (xf && read_transform_hierarchy_position(xf, pos) && vec3_is_finite(pos)) {
            worlds[HUMAN_BONE_HIPS] = pos;
            ok[HUMAN_BONE_HIPS] = 1;
        }
    }
}

static bool read_human_bone_world(uint64_t player, int32_t human, Vec3& target,
                                  bool dead) {
    if (!player || human < 0 || human > 54) return false;

    uint64_t live = 0, ragdoll_anim = 0, ragdoll = 0;
    dump_skeleton_animators(player, dead, live, ragdoll_anim, ragdoll);
    uint64_t bone = resolve_bone_transform(player, human, live, ragdoll_anim);
    if (!bone) return false;
    return read_bone_world_position(bone, target);
}

static void lift_aim_points(Vec3 worlds[3], const bool have[3]) {
    Vec3 axis{0.0F, 1.0F, 0.0F};
    if (have[0] && have[1]) {
        Vec3 d{worlds[0].x - worlds[1].x, worlds[0].y - worlds[1].y,
               worlds[0].z - worlds[1].z};
        float len = sqrtf(d.x * d.x + d.y * d.y + d.z * d.z);
        if (len > 0.04F) { axis.x = d.x / len; axis.y = d.y / len; axis.z = d.z / len; }
    } else if (have[1] && have[2]) {
        Vec3 d{worlds[1].x - worlds[2].x, worlds[1].y - worlds[2].y,
               worlds[1].z - worlds[2].z};
        float len = sqrtf(d.x * d.x + d.y * d.y + d.z * d.z);
        if (len > 0.04F) { axis.x = d.x / len; axis.y = d.y / len; axis.z = d.z / len; }
    }

    const float lift[3] = {0.12F, 0.05F, 0.06F};
    for (int i = 0; i < 3; ++i) {
        if (!have[i]) continue;
        worlds[i].x += axis.x * lift[i];
        worlds[i].y += axis.y * lift[i];
        worlds[i].z += axis.z * lift[i];
    }
}

static inline float normalize_angle_180(float angle) {
    while (angle > 180.0f) angle -= 360.0f;
    while (angle < -180.0f) angle += 360.0f;
    return angle;
}

static inline float delta_angle_deg(float current, float target) {
    float diff = target - current;
    while (diff > 180.0f) diff -= 360.0f;
    while (diff < -180.0f) diff += 360.0f;
    return diff;
}

static void memory_aim_actuate_unlocked(uint64_t player,
                                        const Vec3& target_world,
                                        float smooth,
                                        uint64_t target_id) {
    if (!player || !likely_native_pointer(player)) {
        memory_aim_reset();
        return;
    }

    uint64_t mouse_look = rd_ptr(player + PLAYER_MOUSE_LOOK);
    if (!mouse_look || !likely_native_pointer(mouse_look)) {
        memory_aim_reset();
        return;
    }

    Vec3 camera_pos{};
    Vec4 camera_rot{};
    if (!read_render_camera_pose(player, camera_pos, camera_rot) || !vec3_is_finite(camera_pos)) {
        memory_aim_reset();
        return;
    }

    const double now = monotonic_seconds();
    const float sm = std::max(0.35f, std::min(10.0f, smooth));
    const float divisor = 1.0f + sm * 0.8f;

    Vec3 aim_point = target_world;
    if (target_id != s_aim_last_target) s_aim_has_prev_t = false;
    if (s_aim_has_prev_t) {
        double tdelta = now - s_aim_prev_t_time;
        if (tdelta > 1.0 / 240.0 && tdelta < 0.25) {
            float inv = 1.0f / (float)tdelta;
            float vx = (target_world.x - s_aim_prev_tx) * inv;
            float vy = (target_world.y - s_aim_prev_ty) * inv;
            float vz = (target_world.z - s_aim_prev_tz) * inv;
            float speed2 = vx * vx + vy * vy + vz * vz;
            if (speed2 > 0.25f && speed2 < 1600.0f) {
                float lead = divisor / 75.0f;
                aim_point.x = target_world.x + vx * lead;
                aim_point.y = target_world.y + vy * lead;
                aim_point.z = target_world.z + vz * lead;
            }
        }
    }
    s_aim_prev_tx = target_world.x;
    s_aim_prev_ty = target_world.y;
    s_aim_prev_tz = target_world.z;
    s_aim_prev_t_time = now;
    s_aim_has_prev_t = true;
    s_aim_last_target = target_id;

    Vec3 rel = { aim_point.x - camera_pos.x,
                 aim_point.y - camera_pos.y,
                 aim_point.z - camera_pos.z };
    const float dist_xz = sqrtf(rel.x * rel.x + rel.z * rel.z);
    const float dist_total = sqrtf(rel.x * rel.x + rel.y * rel.y + rel.z * rel.z);
    if (!std::isfinite(dist_total) || dist_total < 0.05f) {
        memory_aim_reset();
        return;
    }

    const float kPi = 3.14159265358979323846f;
    const float kRad2Deg = 180.0f / kPi;
    float desired_yaw = atan2f(rel.x, rel.z) * kRad2Deg;
    float desired_pitch = atan2f(rel.y, dist_xz) * kRad2Deg;
    if (!std::isfinite(desired_yaw) || !std::isfinite(desired_pitch)) {
        memory_aim_reset();
        return;
    }

    float min_pitch = -88.0f;
    float max_pitch = 88.0f;
    float limits[2]{};
    if (rd_bulk(mouse_look + MOUSE_LOOK_LIMITS, limits, sizeof(limits))) {
        if (std::isfinite(limits[0]) && std::isfinite(limits[1]) && limits[0] < limits[1] &&
            limits[0] >= -89.5f && limits[1] <= 89.5f) {
            min_pitch = limits[0];
            max_pitch = limits[1];
        }
    }
    desired_pitch = std::max(min_pitch, std::min(max_pitch, desired_pitch));

    float current_zmm[2]{0.0f, 0.0f};
    if (!rd_bulk(mouse_look + MOUSE_LOOK_ZMM, current_zmm, sizeof(current_zmm)) ||
        !std::isfinite(current_zmm[0]) || !std::isfinite(current_zmm[1])) {
        current_zmm[0] = -freecam_pitch_of(camera_rot);
        current_zmm[1] = freecam_yaw_of(camera_rot);
    }
    float current_pitch = -current_zmm[0];
    float current_yaw = current_zmm[1];

    float err_yaw = delta_angle_deg(current_yaw, desired_yaw);
    float err_pitch = desired_pitch - current_pitch;
    float angular_error = sqrtf(err_yaw * err_yaw + err_pitch * err_pitch);

    float dt = 1.0f / 60.0f;
    if (s_aim_last_time > 0.0) {
        dt = (float)(now - s_aim_last_time);
    }
    s_aim_last_time = now;
    if (dt < 1.0f / 240.0f) dt = 1.0f / 240.0f;
    if (dt > 1.0f / 20.0f)  dt = 1.0f / 20.0f;

    if (angular_error < 0.02f) {
        return;
    }

    const float time_factor = dt / (1.0f / 60.0f);

    float ease = 1.0f;
    if (angular_error < 4.0f) {
        const float t = angular_error / 4.0f;
        ease = 0.70f + 0.30f * (3.0f * t * t - 2.0f * t * t * t);
    }

    float step_yaw = (err_yaw / divisor) * time_factor * ease;
    float step_pitch = (err_pitch / divisor) * time_factor * ease;

    if (angular_error > 1.0f && angular_error < 15.0f) {
        float perp_yaw = -step_pitch;
        float perp_pitch = step_yaw;
        float perp_len = sqrtf(perp_yaw * perp_yaw + perp_pitch * perp_pitch);
        if (perp_len > 1e-4f) {
            perp_yaw /= perp_len;
            perp_pitch /= perp_len;
            const float curve = sinf(std::min(kPi, angular_error * 0.35f)) * std::min(0.08f, angular_error * 0.012f);
            step_yaw += perp_yaw * curve;
            step_pitch += perp_pitch * curve;
        }
    }

    const float max_speed = 520.0f / (1.0f + 0.12f * sm);
    const float max_step = max_speed * dt;
    const float step_mag = sqrtf(step_yaw * step_yaw + step_pitch * step_pitch);
    if (step_mag > max_step && step_mag > 1e-5f) {
        const float scale = max_step / step_mag;
        step_yaw *= scale;
        step_pitch *= scale;
    }

    float next_yaw = current_yaw + step_yaw;
    float next_pitch = current_pitch + step_pitch;

    next_pitch = std::max(min_pitch, std::min(max_pitch, next_pitch));
    next_yaw = normalize_angle_180(next_yaw);

    float new_zmm[2] = { -next_pitch, next_yaw };
    wr_bulk(mouse_look + MOUSE_LOOK_ZMM, new_zmm, sizeof(new_zmm));
}

std::vector<OffscreenDir> esp_get_offscreen_dirs(int screen_width,
                                                 int screen_height,
                                                 bool ignore_teammates) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    std::vector<OffscreenDir> out;
    if (g_pid <= 0 || !g_il2cpp_base) return out;
    const float sw = screen_width >= 100 ? (float)screen_width : 1920.0F;
    const float sh = screen_height >= 100 ? (float)screen_height : 1080.0F;
    uint64_t local_player = resolve_local_player();
    if (!local_player) return out;
    if (!sample_overlay_camera(local_player, sw, sh)) return out;
    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const float cam_yaw = freecam_yaw_of(snap.camera_rotation);
    const float kPi = 3.14159265F;
    const std::vector<uint64_t>& players = refresh_player_snapshot();
    out.reserve(players.size());
    for (uint64_t player : players) {
        if (!player || player == local_player) continue;
        float hp = -1.0F, max_hp = -1.0F;
        const bool have_hp = read_player_health(player, hp, max_hp);
        if (have_hp && hp <= 0.01F) continue;
        const bool mate = players_are_teammates(local_player, player);
        if (ignore_teammates && mate) continue;
        Vec3 feet{};
        if (!read_best_player_position(player, feet)) continue;
        const float margin = std::max(24.0F, std::min(sw, sh) * 0.04F);
        Vec2 scr{};
        if (project_world(snap, feet, sw, sh, scr, false) &&
            scr.x >= -margin && scr.x <= sw + margin &&
            scr.y >= -margin && scr.y <= sh + margin)
            continue;
        const float dx = feet.x - snap.camera_position.x;
        const float dy = feet.y - snap.camera_position.y;
        const float dz = feet.z - snap.camera_position.z;
        const float dist = sqrtf(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(dist) || dist < 2.0F || dist > 500.0F) continue;
        float rel = freecam_wrap_degrees(atan2f(dx, dz) * (180.0F / kPi) -
                                         cam_yaw);
        OffscreenDir d{};
        d.player = player;
        d.radians = rel * (kPi / 180.0F);
        d.distance = dist;
        d.teammate = mate;
        d.health_fraction = (have_hp && max_hp > 0.0F) ? hp / max_hp : -1.0F;
        out.push_back(d);
    }
    std::sort(out.begin(), out.end(),
              [](const OffscreenDir& a, const OffscreenDir& b) {
                  return a.distance < b.distance;
              });
    if (out.size() > 14) out.resize(14);
    return out;
}

bool esp_camera_angles(float& yaw, float& pitch) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (g_pid <= 0 || !g_il2cpp_base) return false;
    uint64_t local_player = resolve_local_player();
    if (!local_player) return false;
    Vec3 pos{};
    Vec4 rot{};
    if (!read_render_camera_pose(local_player, pos, rot) || !vec3_is_finite(pos))
        return false;
    yaw = freecam_yaw_of(rot);
    pitch = freecam_pitch_of(rot);
    return std::isfinite(yaw) && std::isfinite(pitch);
}

float esp_camera_fov_deg() {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    const float fov = g_camera_mats.fov_y;
    return (fov > 1.0f && fov < 179.0f) ? fov : 60.0f;
}

bool esp_local_player_is_aiming() {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    if (g_pid <= 0 || !g_il2cpp_base) return false;
    uint64_t local_player = resolve_local_player();
    if (!local_player) return false;
    uint64_t local_kcc = resolve_player_kcc(local_player);
    uint64_t local_events = rd_ptr(local_player + PLAYER_EVENT_HANDLER);
    uint64_t aim_action = local_events ? rd_ptr(local_events + event_aim_action_offset()) : 0;
    bool action_ads = aim_action && rd<uint8_t>(aim_action + ACTION_ACTIVE) != 0;
    bool move_ads = local_kcc && rd<uint8_t>(local_kcc + KCC_MOVE + MOVE_AIM) != 0;
    return action_ads || move_ads;
}

AimFrame aim_update(int screen_width, int screen_height,
                    bool enabled, int bone,
                    bool allow_ads, bool allow_hipfire,
                    float fov_radius,
                    bool ignore_teammates, bool memory_mode,
                    float smooth, bool allow_bots) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    AimFrame frame{};
    auto aim_release = [&]() {
        reset_aim_lock();
    };
    if (!enabled || g_pid <= 0 || !g_il2cpp_base) {
        aim_release();
        return frame;
    }

    float sw = screen_width >= 100 ? (float)screen_width : 1920.0F;
    float sh = screen_height >= 100 ? (float)screen_height : 1080.0F;
    fov_radius = std::max(10.0F, std::min(360.0F, fov_radius));
    int selection = std::max(0, std::min(2, bone));
    if (g_aim_locked_selection != selection) aim_release();

    const std::vector<uint64_t>& players = refresh_player_snapshot();
    if (players.size() < 2 && g_world_stat_bots_alive <= 0) {
        aim_release();
        return frame;
    }

    uint64_t local_player = resolve_local_player();
    if (!local_player) {
        aim_release();
        return frame;
    }
    uint64_t local_kcc = resolve_player_kcc(local_player);
    uint64_t local_events = rd_ptr(local_player + PLAYER_EVENT_HANDLER);
    uint64_t aim_action = local_events ? rd_ptr(local_events + event_aim_action_offset()) : 0;
    bool action_ads = aim_action && rd<uint8_t>(aim_action + ACTION_ACTIVE) != 0;
    bool move_ads = local_kcc && rd<uint8_t>(local_kcc + KCC_MOVE + MOVE_AIM) != 0;
    bool is_ads = action_ads || move_ads;
    bool mode_allows_aim = (is_ads && allow_ads) || (!is_ads && allow_hipfire);

    if (!sample_overlay_camera(local_player, sw, sh)) {
        aim_release();
        return frame;
    }
    OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 camera_position = snap.camera_position;
    float ads_zoom = 1.0F;
    const float proj_y = fabsf(snap.proj.m[5]);
    if (proj_y > 0.01F) {
        if (!is_ads) g_aim_hipfire_proj_y = proj_y;
        if (g_aim_hipfire_proj_y > 0.01F)
            ads_zoom = std::max(1.0F, std::min(4.0F,
                proj_y / g_aim_hipfire_proj_y));
    }

    const double now = monotonic_seconds();

    float center_x = sw * 0.5F, center_y = sh * 0.5F;
    float radius2 = fov_radius * fov_radius;
    const float break2 = radius2 * 1.44f * ads_zoom * ads_zoom;

    auto screen_distance2 = [&](const Vec2& screen) {
        float dx = screen.x - center_x, dy = screen.y - center_y;
        return dx * dx + dy * dy;
    };

    const int32_t kAimBones[3] = {
        HUMAN_BONE_HEAD, HUMAN_BONE_NECK, HUMAN_BONE_CHEST
    };
    constexpr float kAimCloseMeters = 12.0F;
    constexpr float kAimCloseConeScale = 2.25F;
    const float max_cone = std::min(sw, sh) * 0.5F;
    const float max_cone2 = max_cone * max_cone;
    auto evaluate_target = [&](uint64_t player,
                               Vec3& world, Vec2& aim_s, Vec2& acq_s,
                               float& out_dist) -> bool {
        out_dist = 0.0F;
        if (!player || player == local_player) return false;
        Vec3 source{};
        if (!read_best_player_position(player, source)) return false;
        Vec3 feet = source;

        float dx_camera = feet.x - camera_position.x;
        float dy_camera = feet.y - camera_position.y;
        float dz_camera = feet.z - camera_position.z;
        float distance2 = dx_camera * dx_camera + dy_camera * dy_camera + dz_camera * dz_camera;
        if (!std::isfinite(distance2) ||
            distance2 > MAX_AIM_DISTANCE * MAX_AIM_DISTANCE) return false;
        out_dist = sqrtf(distance2);

        float health = -1.0F, maximum = -1.0F;
        if (read_player_health(player, health, maximum) && health <= 0.01F) return false;

        Vec3 worlds[3]{};
        Vec2 screens[3]{};
        bool have[3]{};
        bool have_pos[3]{};
        for (int i = 0; i < 3; ++i) {
            if (!read_human_bone_world(player, kAimBones[i], worlds[i])) continue;
            have_pos[i] = true;
        }
        lift_aim_points(worlds, have_pos);
        for (int i = 0; i < 3; ++i) {
            if (!have_pos[i]) continue;
            if (!project_world(snap, worlds[i], sw, sh, screens[i], false))
                continue;
            have[i] = true;
        }
        int aim_i = have[selection] ? selection : -1;
        if (aim_i < 0) {
            for (int i = 0; i < 3; ++i) if (have[i]) { aim_i = i; break; }
        }
        if (aim_i < 0) return false;
        world = worlds[aim_i];
        aim_s = screens[aim_i];
        acq_s = aim_s;
        float acq_d = screen_distance2(aim_s);
        for (int i = 0; i < 3; ++i) {
            if (!have[i]) continue;
            float d = screen_distance2(screens[i]);
            if (d < acq_d) { acq_d = d; acq_s = screens[i]; }
        }
        return true;
    };

    uint64_t best_player = 0, best_bot = 0;
    Vec2 best_screen{};
    Vec3 best_world{};
    bool have_best_world = false;

    auto use_target = [&](uint64_t player, uint64_t bot,
                          const Vec2& aim_s, Vec3& world) {
        best_player = player;
        best_bot = bot;
        best_screen = aim_s;
        best_world = world;
        have_best_world = true;
    };

    auto close_scale_for = [&](float world_dist) {
        if (!std::isfinite(world_dist) || world_dist >= kAimCloseMeters)
            return 1.0F;
        if (world_dist <= 0.0F) return kAimCloseConeScale;
        float t = world_dist / kAimCloseMeters;
        return 1.0F + (kAimCloseConeScale - 1.0F) * (1.0F - t) * (1.0F - t);
    };

    auto cone_for = [&](float world_dist) {
        return std::min(radius2 * close_scale_for(world_dist), max_cone2);
    };

    auto break_cone_for = [&](float world_dist) {
        return std::min(break2 * close_scale_for(world_dist), max_cone2);
    };

    if (g_aim_locked_target && g_aim_locked_target != local_player) {
        Vec3 world{};
        Vec2 aim_s{}, acq_s{};
        float locked_dist = 0.0F;
        if (evaluate_target(g_aim_locked_target, world, aim_s, acq_s,
                            locked_dist) &&
            screen_distance2(aim_s) <= break_cone_for(locked_dist)) {
            use_target(g_aim_locked_target, 0, aim_s, world);
        } else {
            g_aim_locked_target = 0;
        }
    }
    if (allow_bots && !best_player && !best_bot && g_aim_locked_bot) {
        auto it = g_world_cache.find(g_aim_locked_bot);
        if (it != g_world_cache.end()) {
            Vec2 bot_screen{};
            Vec3 bot_world{};
            float locked_dist = 0.0F;
            if (evaluate_bot_target(it->second, snap, sw, sh,
                                    camera_position, bot_screen, bot_world,
                                    locked_dist) &&
                screen_distance2(bot_screen) <= break_cone_for(locked_dist)) {
                use_target(0, g_aim_locked_bot, bot_screen, bot_world);
            } else {
                g_aim_locked_bot = 0;
            }
        } else {
            g_aim_locked_bot = 0;
        }
    }
    if (!best_player && !best_bot) {
        float nearest = 1.0e12F;
        for (uint64_t player : players) {
            if (!player || player == local_player) continue;
            if (ignore_teammates && players_are_teammates(local_player, player))
                continue;
            Vec3 world{};
            Vec2 aim_s{}, acq_s{};
            float world_dist = 0.0F;
            if (!evaluate_target(player, world, aim_s, acq_s, world_dist))
                continue;
            float distance2 = screen_distance2(acq_s);
            if (!std::isfinite(distance2) || distance2 > cone_for(world_dist))
                continue;
            if (distance2 > nearest) continue;
            nearest = distance2;
            use_target(player, 0, aim_s, world);
        }
    }
    if (allow_bots && !best_player && !best_bot) {
        float nearest = 1.0e12F;
        for (const auto& pair : g_world_cache) {
            const CachedWorldEntity& bot = pair.second;
            if (!world_kind_is_humanoid(bot.kind)) continue;
            Vec2 bot_screen{};
            Vec3 bot_world{};
            float world_dist = 0.0F;
            if (!evaluate_bot_target(bot, snap, sw, sh, camera_position,
                                     bot_screen, bot_world, world_dist))
                continue;
            float distance2 = screen_distance2(bot_screen);
            if (!std::isfinite(distance2) || distance2 > cone_for(world_dist))
                continue;
            if (distance2 > nearest) continue;
            nearest = distance2;
            use_target(0, pair.first, bot_screen, bot_world);
        }
    }

    if (!best_player && !best_bot) {
        aim_release();
        return frame;
    }
    const bool target_changed =
        (g_aim_locked_target != 0 && g_aim_locked_target != best_player) ||
        (g_aim_locked_bot != 0 && g_aim_locked_bot != best_bot) ||
        (best_bot != 0 && g_aim_locked_target != 0) ||
        (best_player != 0 && g_aim_locked_bot != 0);
    g_aim_locked_target = best_player;
    g_aim_locked_bot = best_bot;
    g_aim_locked_selection = selection;

    frame.has_target = true;
    frame.target_x = best_screen.x;
    frame.target_y = best_screen.y;

    if (!mode_allows_aim) {
        return frame;
    }
    if (memory_mode) {
        if (have_best_world)
            memory_aim_actuate_unlocked(local_player, best_world, smooth, best_player ? best_player : best_bot);
        return frame;
    }
    (void)target_changed;
    return frame;
}

static void tree_hitstreak_pin_marker(uint64_t ext) {
    if (!likely_native_pointer(ext)) return;

    int32_t method = 0;
    if (rd_exact(ext + TREE_HITSTREAK_MOVING_METHOD, method) &&
        method != TREE_MOVING_METHOD_RANDOM) {
        const int32_t want = TREE_MOVING_METHOD_RANDOM;
        wr_bulk(ext + TREE_HITSTREAK_MOVING_METHOD, &want, sizeof(want));
    }

    float amplitude[2]{};
    if (rd_bulk(ext + TREE_HITSTREAK_RANDOM_AMPLITUDE, amplitude,
                sizeof(amplitude)) &&
        (fabsf(amplitude[0]) > 0.0001F || fabsf(amplitude[1]) > 0.0001F)) {
        const float zero[2] = {0.0F, 0.0F};
        wr_bulk(ext + TREE_HITSTREAK_RANDOM_AMPLITUDE, zero, sizeof(zero));
    }

    float degrees = 0.0F;
    if (rd_bulk(ext + TREE_HITSTREAK_RANDOM_MIN_DEGREES, &degrees,
                sizeof(degrees)) &&
        fabsf(degrees) > 0.0001F) {
        const float zero = 0.0F;
        wr_bulk(ext + TREE_HITSTREAK_RANDOM_MIN_DEGREES, &zero, sizeof(zero));
    }
}

static std::atomic<bool> g_tree_pin_enabled{false};

void farm_set_tree_marker_pin(bool enabled) {
    g_tree_pin_enabled.store(enabled, std::memory_order_release);
}

static bool tree_marker_offset_ok(bool tree_only, float dx, float dy,
                                  float dz) {
    if (!tree_only) return true;
    if (!std::isfinite(dy)) return false;
    if (dy < FARM_TREE_MARKER_MIN_DY || dy > FARM_TREE_MARKER_MAX_DY)
        return false;
    float flat = sqrtf(dx * dx + dz * dz);
    return std::isfinite(flat) && flat <= FARM_TRUNK_RADIUS_MAX;
}

static bool marker_candidate_in_range(const Vec3& pos, const Vec3& ore_pos,
                                       float min_dist, float max_dist,
                                       Vec3& out_marker_pos,
                                       bool tree_only = false) {
    if (!vec3_is_finite(pos)) return false;
    const float dx = pos.x - ore_pos.x;
    const float dy = pos.y - ore_pos.y;
    const float dz = pos.z - ore_pos.z;
    const float dist = sqrtf(dx * dx + dy * dy + dz * dz);
    if (dist < min_dist || dist > max_dist) return false;
    if (!tree_marker_offset_ok(tree_only, dx, dy, dz)) return false;
    out_marker_pos = pos;
    return true;
}

static bool marker_candidate(uint64_t xf, const Vec3& ore_pos, float min_dist,
                             float max_dist, Vec3& out_marker_pos,
                             bool tree_only = false) {
    if (!xf) return false;
    Vec3 pos{};
    if (!read_transform_hierarchy_position(xf, pos)) return false;
    return marker_candidate_in_range(pos, ore_pos, min_dist, max_dist,
                                     out_marker_pos, tree_only);
}

static bool try_get_marker_position_from_extension(uint64_t ext, const Vec3& ore_pos, Vec3& out_marker_pos) {
    if (!likely_native_pointer(ext)) return false;
    uint64_t klass = rd_ptr(ext);
    if (!likely_native_pointer(klass)) return false;
    std::string class_name = read_remote_string(rd_ptr(klass + 0x10));
    if (class_name.empty()) return false;

    if (class_name == EXT_CLASS_ORE_HITSTREAKS ||
        class_name.find(xv::StrStable(xv::sid::kGsOreHitstreak)) != std::string::npos) {
        uint64_t marker_active = rd_ptr(ext + ORE_HITSTREAK_MARKER_ACTIVE);
        if (likely_native_pointer(marker_active)) {
            if (marker_candidate(resolve_managed_component_transform(marker_active), ore_pos,
                                 0.05f, 5.5f, out_marker_pos, false))
                return true;
        }
        uint64_t marker_prefab = rd_ptr(ext + ORE_HITSTREAK_MARKER_PREFAB);
        if (likely_native_pointer(marker_prefab)) {
            if (marker_candidate(resolve_managed_component_transform(marker_prefab), ore_pos,
                                 0.05f, 5.5f, out_marker_pos, false))
                return true;
        }
    }

    if (class_name == EXT_CLASS_ORE_MARKER ||
        class_name.find(xv::StrStable(xv::sid::kGsOreHitstreaksMarker)) != std::string::npos) {
        if (marker_candidate(resolve_managed_component_transform(ext), ore_pos,
                             0.05f, 5.5f, out_marker_pos, false))
            return true;
    }

    if (class_name == EXT_CLASS_HIT_MARKERS ||
        class_name.find(xv::StrStable(xv::sid::kGsHitMarker)) != std::string::npos) {
        uint64_t list = rd_ptr(ext + 0x30);
        if (likely_native_pointer(list)) {
            uint64_t items = rd_ptr(list + IL2CPP_LIST_ITEMS);
            int32_t size = rd<int32_t>(list + IL2CPP_LIST_SIZE);
            if (likely_native_pointer(items) && size > 0 && size <= 16) {
                uint64_t last_item = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)(size - 1) * sizeof(uint64_t));
                if (likely_native_pointer(last_item)) {
                    uint64_t mark_transform = rd_ptr(last_item + HITMARKER_ITEM_MARK_TRANSFORM);
                    if (likely_native_pointer(mark_transform) &&
                        marker_candidate(resolve_native_transform(mark_transform),
                                         ore_pos, 0.05f, 8.0f, out_marker_pos))
                        return true;
                    if (marker_candidate(resolve_managed_component_transform(last_item), ore_pos,
                                         0.05f, 8.0f, out_marker_pos, false))
                        return true;
                }
            }
        }
    }

    return false;
}

static bool read_hit_marker_item_world(uint64_t item, const Vec3& ore_pos,
                                       float max_range, Vec3& out_marker_pos,
                                       bool tree_only = false) {
    if (!likely_native_pointer(item)) return false;

    uint64_t mark_transform = rd_ptr(item + HITMARKER_ITEM_MARK_TRANSFORM);
    if (likely_native_pointer(mark_transform) &&
        marker_candidate(resolve_native_transform(mark_transform), ore_pos,
                         0.02f, max_range, out_marker_pos, tree_only))
        return true;

    return marker_candidate(resolve_managed_component_transform(item), ore_pos,
                            0.02f, max_range, out_marker_pos, tree_only);
}

static bool read_tree_axis_point(uint64_t ext, uint64_t field,
                                 const Vec3& ore_pos, float max_range,
                                 Vec3& out_pos) {
    Vec3 pos{};
    if (!rd_bulk(ext + field, &pos, sizeof(pos))) return false;
    return marker_candidate_in_range(pos, ore_pos, 0.02f, max_range, out_pos,
                                     true);
}

static bool try_get_tree_marker_from_extension(uint64_t ext, const Vec3& ore_pos,
                                               Vec3& out_marker_pos) {
    if (!likely_native_pointer(ext)) return false;
    uint64_t klass = rd_ptr(ext);
    if (!likely_native_pointer(klass)) return false;
    std::string class_name = read_remote_string(rd_ptr(klass + 0x10));
    if (class_name.empty()) return false;
    if (class_name != EXT_CLASS_TREE_HITSTREAKS &&
        class_name.find(xv::StrStable(xv::sid::kGsTreeHitstreak)) == std::string::npos)
        return false;

    if (g_tree_pin_enabled.load(std::memory_order_acquire))
        tree_hitstreak_pin_marker(ext);

    const float kTreeMarkerRange = 9.0f;

    uint64_t active_marker = rd_ptr(ext + TREE_HITSTREAK_MARKER_ACTIVE);
    if (read_hit_marker_item_world(active_marker, ore_pos, kTreeMarkerRange,
                                   out_marker_pos, true))
        return true;

    if (read_tree_axis_point(ext, TREE_HITSTREAK_HIT_POINT, ore_pos,
                             kTreeMarkerRange, out_marker_pos))
        return true;
    if (read_tree_axis_point(ext, TREE_HITSTREAK_AXIS_A, ore_pos,
                             kTreeMarkerRange, out_marker_pos))
        return true;
    if (read_tree_axis_point(ext, TREE_HITSTREAK_AXIS_C, ore_pos,
                             kTreeMarkerRange, out_marker_pos))
        return true;

    uint64_t axis_list = rd_ptr(ext + TREE_HITSTREAK_AXIS_POINTS);
    if (likely_native_pointer(axis_list)) {
        uint64_t items = rd_ptr(axis_list + IL2CPP_LIST_ITEMS);
        int32_t size = rd<int32_t>(axis_list + IL2CPP_LIST_SIZE);
        int32_t index = rd<int32_t>(ext + TREE_HITSTREAK_AXIS_INDEX);
        if (likely_native_pointer(items) && size > 0 && size <= 64) {
            if (index < 0 || index >= size) index = 0;
            uint64_t base = items + IL2CPP_ARRAY_FIRST_ELEMENT;
            Vec3 local{};
            if (rd_bulk(base + (uint64_t)index * sizeof(Vec3), &local,
                        sizeof(local)) && vec3_is_finite(local)) {
                uint64_t xf = resolve_managed_component_transform(ext);
                Vec3 root{};
                Vec4 rot{};
                if (xf && read_native_xform_pose(xf, root, rot)) {
                    Vec3 world = rotate_vector(rot, local);
                    world.x += root.x;
                    world.y += root.y;
                    world.z += root.z;
                    if (marker_candidate_in_range(world, ore_pos, 0.02f,
                                                  kTreeMarkerRange,
                                                  out_marker_pos, true))
                        return true;
                }
            }
        }
    }

    return false;
}

static bool read_mineable_tree_marker_world(uint64_t mineable, const Vec3& ore_pos,
                                            Vec3& out_marker_pos) {
    if (!likely_native_pointer(mineable)) return false;

    uint64_t lqa = rd_ptr(mineable + MINEABLE_EXTENSIONS);
    if (likely_native_pointer(lqa)) {
        uint64_t array_len = rd<uint64_t>(lqa + IL2CPP_ARRAY_LENGTH);
        if (array_len > 0 && array_len <= 32) {
            for (uint64_t i = 0; i < array_len; ++i) {
                uint64_t ext = rd_ptr(lqa + IL2CPP_ARRAY_FIRST_ELEMENT +
                                      i * sizeof(uint64_t));
                if (try_get_tree_marker_from_extension(ext, ore_pos, out_marker_pos))
                    return true;
            }
        }
        uint64_t items = rd_ptr(lqa + IL2CPP_LIST_ITEMS);
        int32_t list_size = rd<int32_t>(lqa + IL2CPP_LIST_SIZE);
        if (likely_native_pointer(items) && list_size > 0 && list_size <= 32) {
            for (int32_t i = 0; i < list_size; ++i) {
                uint64_t ext = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT +
                                      (uint64_t)i * sizeof(uint64_t));
                if (try_get_tree_marker_from_extension(ext, ore_pos, out_marker_pos))
                    return true;
            }
        }
    }

    uint64_t go = managed_component_game_object(mineable);
    if (go) {
        uint64_t table = rd_ptr(go + NATIVE_GAMEOBJECT_COMPONENTS);
        if (likely_native_pointer(table)) {
            for (int i = 0; i < 32; ++i) {
                uint64_t cand = rd_ptr(table + (uint64_t)i * sizeof(uint64_t));
                if (cand < 0x10000) continue;
                if (try_get_tree_marker_from_extension(cand, ore_pos, out_marker_pos))
                    return true;
            }
        }
    }

    return false;
}

static bool read_mineable_hit_marker_world(uint64_t mineable, const Vec3& ore_pos, Vec3& out_marker_pos) {
    if (!likely_native_pointer(mineable)) return false;

    uint64_t lqa = rd_ptr(mineable + MINEABLE_EXTENSIONS);
    if (likely_native_pointer(lqa)) {
        uint64_t array_len = rd<uint64_t>(lqa + IL2CPP_ARRAY_LENGTH);
        if (array_len > 0 && array_len <= 32) {
            for (uint64_t i = 0; i < array_len; ++i) {
                uint64_t ext = rd_ptr(lqa + IL2CPP_ARRAY_FIRST_ELEMENT + i * sizeof(uint64_t));
                if (try_get_marker_position_from_extension(ext, ore_pos, out_marker_pos))
                    return true;
            }
        }
        uint64_t items = rd_ptr(lqa + IL2CPP_LIST_ITEMS);
        int32_t list_size = rd<int32_t>(lqa + IL2CPP_LIST_SIZE);
        if (likely_native_pointer(items) && list_size > 0 && list_size <= 32) {
            for (int32_t i = 0; i < list_size; ++i) {
                uint64_t ext = rd_ptr(items + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)i * sizeof(uint64_t));
                if (try_get_marker_position_from_extension(ext, ore_pos, out_marker_pos))
                    return true;
            }
        }
    }

    uint64_t go = managed_component_game_object(mineable);
    if (go) {
        uint64_t table = rd_ptr(go + NATIVE_GAMEOBJECT_COMPONENTS);
        if (likely_native_pointer(table)) {
            for (int i = 0; i < 32; ++i) {
                uint64_t cand = rd_ptr(table + (uint64_t)i * sizeof(uint64_t));
                if (cand < 0x10000) continue;
                if (try_get_marker_position_from_extension(cand, ore_pos, out_marker_pos))
                    return true;
            }
        }
    }

    return false;
}

float esp_max_distance() {
    return MAX_ESP_DISTANCE;
}

std::vector<OreTargetPoint> esp_get_ore_targets(int overlay_width,
                                                int overlay_height,
                                                float max_distance,
                                                bool sulfur, bool iron,
                                                bool stone, bool tree) {
    std::lock_guard<std::mutex> lock(g_game_mutex);
    std::vector<OreTargetPoint> result;
    if ((!sulfur && !iron && !stone && !tree) || g_pid <= 0 || !g_il2cpp_base)
        return result;

    float sw = overlay_width >= 100 ? (float)overlay_width : 1920.0F;
    float sh = overlay_height >= 100 ? (float)overlay_height : 1080.0F;
    uint64_t local_player = resolve_local_player();
    if (!local_player) return result;
    if (!sample_overlay_camera(local_player, sw, sh)) return result;
    const OverlayProjectionSnapshot snap = g_overlay_projection_snapshot;
    const Vec3 camera = snap.camera_position;
    const float cam_yaw = freecam_yaw_of(snap.camera_rotation);
    const float kPi = 3.14159265F;

    result.reserve(g_ore_world_cache.size());
    for (const auto& pair : g_ore_world_cache) {
        const CachedOreWorld& ore = pair.second;
        if ((ore.kind == OreKind::Sulfur && !sulfur) ||
            (ore.kind == OreKind::Iron && !iron) ||
            (ore.kind == OreKind::Stone && !stone) ||
            (ore.kind == OreKind::Tree && !tree))
            continue;
        float dx = ore.position.x - camera.x;
        float dz = ore.position.z - camera.z;
        float hdist = sqrtf(dx * dx + dz * dz);
        if (!std::isfinite(hdist) || hdist > max_distance) continue;
        if (ore.kind == OreKind::Tree) {
            if (hdist > MAX_TREE_FARM_DISTANCE) continue;
            if (!ore.farmable) continue;
            const float drop = camera.y - ore.position.y;
            if (std::isfinite(drop) && drop > MAX_FARM_TREE_DROP) continue;
        }

        OreTargetPoint pt;
        pt.x = ore.position.x;
        pt.y = ore.position.y;
        pt.z = ore.position.z;
        pt.hdist = hdist;
        pt.kind = ore.kind;
        pt.key = ore.key;
        pt.rel_yaw = freecam_wrap_degrees(atan2f(dx, dz) * (180.0F / kPi) -
                                          cam_yaw);

        if (ore.ore_behaviour) {
            float remaining = rd<float>(ore.ore_behaviour +
                                        MINEABLE_FRACTION_REMAINING);
            if (std::isfinite(remaining) && remaining >= 0.0F &&
                remaining <= 1.0F)
                pt.fraction = remaining;
        }

        Vec3 marker_pos{};
        bool have_marker = false;
        if (ore.ore_behaviour && hdist <= 12.0f) {
            if (ore.kind == OreKind::Tree) {
                have_marker = read_mineable_tree_marker_world(
                    ore.ore_behaviour, ore.position, marker_pos);
                if (!have_marker) {
                    have_marker = read_mineable_hit_marker_world(
                        ore.ore_behaviour, ore.position, marker_pos);
                    if (have_marker &&
                        !tree_marker_offset_ok(
                            true, marker_pos.x - ore.position.x,
                            marker_pos.y - ore.position.y,
                            marker_pos.z - ore.position.z))
                        have_marker = false;
                }
            } else if (hdist <= 8.0f) {
                have_marker = read_mineable_hit_marker_world(
                    ore.ore_behaviour, ore.position, marker_pos);
            }
        }

        if (have_marker) {
            Vec2 marker_screen{};
            if (project_world(snap, marker_pos, sw, sh, marker_screen, false) &&
                std::isfinite(marker_screen.x) && std::isfinite(marker_screen.y)) {
                pt.has_marker = true;
                pt.look_x = marker_screen.x;
                pt.look_y = marker_screen.y;
                pt.look_valid = true;
            }
        }

        if (!pt.look_valid) {
            float look_up = 1.0F;
            if (ore.kind == OreKind::Tree) look_up = FARM_TREE_AIM_HEIGHT;
            Vec3 look{ore.position.x, ore.position.y + look_up, ore.position.z};
            Vec2 look_screen{};
            bool ok = project_world(snap, look, sw, sh, look_screen, false) &&
                      std::isfinite(look_screen.x) &&
                      std::isfinite(look_screen.y);
            if (ok) {
                pt.look_x = look_screen.x;
                pt.look_y = look_screen.y;
                pt.look_valid = true;
                if (ore.kind == OreKind::Tree) pt.trunk_aim = true;
            }
        }

        result.push_back(pt);
    }
    return result;
}

static int      g_xray_near_off = -1;
static float    g_xray_orig_near = 0.f;
static bool     g_xray_applied = false;
static float    g_xray_applied_near = 0.f;
static double   g_xray_last_write_ms = 0.0;
static int      g_xray_proj_off = -2;
static int      g_xray_view_off = -2;

static double xray_now_ms() {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec * 1e-6;
}

static bool xray_looks_like_view_matrix(const Mat4& M) {
    for (int i = 0; i < 16; i++)
        if (!std::isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    if (fabsf(M.m[3])  > 1e-4f) return false;
    if (fabsf(M.m[7])  > 1e-4f) return false;
    if (fabsf(M.m[11]) > 1e-4f) return false;
    if (fabsf(M.m[15] - 1.0f) > 1e-4f) return false;
    float l0 = sqrtf(M.m[0]*M.m[0] + M.m[1]*M.m[1] + M.m[2]*M.m[2]);
    float l1 = sqrtf(M.m[4]*M.m[4] + M.m[5]*M.m[5] + M.m[6]*M.m[6]);
    float l2 = sqrtf(M.m[8]*M.m[8] + M.m[9]*M.m[9] + M.m[10]*M.m[10]);
    if (fabsf(l0 - 1.f) > 2e-3f || fabsf(l1 - 1.f) > 2e-3f || fabsf(l2 - 1.f) > 2e-3f)
        return false;
    float d01 = M.m[0]*M.m[4] + M.m[1]*M.m[5] + M.m[2]*M.m[6];
    float d02 = M.m[0]*M.m[8] + M.m[1]*M.m[9] + M.m[2]*M.m[10];
    if (fabsf(d01) > 3e-3f || fabsf(d02) > 3e-3f) return false;
    if (fabsf(M.m[12]) + fabsf(M.m[13]) + fabsf(M.m[14]) < 1e-4f) return false;
    return true;
}

static bool xray_looks_like_proj_matrix(const Mat4& M) {
    for (int i = 0; i < 16; i++)
        if (!std::isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    if (M.m[0] < 0.15f || M.m[0] > 12.f) return false;
    if (M.m[5] < 0.15f || M.m[5] > 12.f) return false;
    if (fabsf(M.m[11] + 1.0f) > 1e-3f) return false;
    if (fabsf(M.m[15]) > 1e-4f) return false;
    const int zeros[] = {1, 2, 3, 4, 6, 7, 12, 13};
    for (int z : zeros) if (fabsf(M.m[z]) > 1e-4f) return false;
    if (M.m[10] > 0.f || M.m[14] > 0.f) return false;
    return true;
}

static void xray_find_camera_matrices(uint64_t native_cam) {
    if (!likely_native_pointer(native_cam)) return;
    if (g_xray_view_off != -2 || g_xray_proj_off != -2) return;
    const int WINDOW = 0x600, STEP = 4;
    for (int off = 0; off + (int)sizeof(Mat4) <= WINDOW; off += STEP) {
        Mat4 M;
        if (!rd_bulk(native_cam + off, &M, sizeof(M))) continue;
        if (g_xray_view_off == -2 && xray_looks_like_view_matrix(M)) {
            g_xray_view_off = off;
        }
        if (g_xray_proj_off == -2 && xray_looks_like_proj_matrix(M)) {
            g_xray_proj_off = off;
        }
        if (g_xray_view_off >= 0 && g_xray_proj_off >= 0) break;
    }
}

static bool xray_proj_near_far(const Mat4& P, float* outNear, float* outFar) {
    float A = P.m[10], B = P.m[14];
    float dn = A - 1.f, df = A + 1.f;
    if (fabsf(dn) < 1e-6f || fabsf(df) < 1e-6f) return false;
    float n = B / dn, f = B / df;
    if (!std::isfinite(n) || !std::isfinite(f)) return false;
    if (n <= 0.0005f || n > 10.f) return false;
    if (f <= n || f > 200000.f) return false;
    *outNear = n; *outFar = f;
    return true;
}

static bool xray_find_near_clip(uint64_t native_cam) {
    if (g_xray_near_off >= 0) return true;
    if (!likely_native_pointer(native_cam)) return false;
    
    xray_find_camera_matrices(native_cam);
    if (g_xray_proj_off < 0) return false;
    
    Mat4 P;
    if (!rd_bulk(native_cam + g_xray_proj_off, &P, sizeof(P))) return false;
    float wantNear = 0.f, wantFar = 0.f;
    if (!xray_proj_near_far(P, &wantNear, &wantFar)) return false;

    const int WINDOW = 0x600;
    unsigned char buf[0x600];
    if (!rd_bulk(native_cam, buf, WINDOW)) return false;

    for (int off = 0; off + 8 <= WINDOW; off += 4) {
        float a = 0.f, b = 0.f;
        memcpy(&a, buf + off, 4);
        memcpy(&b, buf + off + 4, 4);
        if (!std::isfinite(a) || !std::isfinite(b)) continue;
        if (fabsf(a - wantNear) > wantNear * 0.02f + 1e-4f) continue;
        if (fabsf(b - wantFar)  > wantFar  * 0.02f + 1e-2f) continue;
        g_xray_near_off = off;
        g_xray_orig_near = a;
        return true;
    }
    return false;
}

static constexpr int ASPECT_MAX_SLOTS = 12;
static constexpr int ASPECT_WINDOW = 0x1000;

struct AspectSlot {
    int off = -1;
    float orig = 0.f;
};
static AspectSlot g_aspect_slots[ASPECT_MAX_SLOTS];
static int   g_aspect_slot_count = 0;
static int   g_aspect_flag_off = -1;
static uint8_t g_aspect_flag_orig = 0;
static bool  g_aspect_applied = false;
static float g_aspect_orig_m0 = 0.f;
static bool  g_aspect_orig_m0_valid = false;
static uint64_t g_aspect_cam_cached = 0;

static std::atomic<bool> g_aspect_run{false};
static std::atomic<int> g_aspect_fd{-1};
static std::atomic<uint64_t> g_aspect_cam{0};
static std::atomic<int> g_aspect_proj_off{-1};
static std::atomic<int> g_aspect_flag_pub{-1};
static std::atomic<float> g_aspect_want{2.00f};
static std::atomic<int> g_aspect_slots_pub[ASPECT_MAX_SLOTS];
static std::atomic<int> g_aspect_slots_n{0};
static pthread_t g_aspect_thread{};
static bool g_aspect_started = false;

static void* aspect_worker(void*) {
    while (g_aspect_run.load(std::memory_order_acquire)) {
        const int fd = g_aspect_fd.load(std::memory_order_acquire);
        const uint64_t cam = g_aspect_cam.load(std::memory_order_acquire);
        const float want = g_aspect_want.load(std::memory_order_relaxed);
        const bool drv = g_driver_mode && g_driver && g_driver->available();
        if ((drv || fd >= 0) && cam && std::isfinite(want) && want > 0.05f) {
            const int n = g_aspect_slots_n.load(std::memory_order_acquire);
            for (int i = 0; i < n && i < ASPECT_MAX_SLOTS; ++i) {
                const int off = g_aspect_slots_pub[i].load(
                    std::memory_order_relaxed);
                if (off >= 0) {
                    if (drv) g_driver->write(cam + off, (void*)&want, sizeof(want));
                    else pwrite(fd, &want, sizeof(want), (off_t)(cam + off));
                }
            }
            const int flag = g_aspect_flag_pub.load(std::memory_order_acquire);
            if (flag >= 0) {
                const uint8_t one = 1;
                if (drv) g_driver->write(cam + flag, (void*)&one, 1);
                else pwrite(fd, &one, 1, (off_t)(cam + flag));
            }
            const int poff = g_aspect_proj_off.load(std::memory_order_acquire);
            if (poff >= 0) {
                float m5 = 0.f;
                bool ok = drv
                    ? g_driver->read(cam + poff + 5 * sizeof(float), &m5, sizeof(m5))
                    : pread(fd, &m5, sizeof(m5),
                            (off_t)(cam + poff + 5 * sizeof(float))) ==
                          (ssize_t)sizeof(m5);
                if (ok && std::isfinite(m5) && fabsf(m5) > 1e-6f) {
                    float m0 = m5 / want;
                    if (std::isfinite(m0) && fabsf(m0) > 1e-6f) {
                        if (drv) g_driver->write(cam + poff, (void*)&m0, sizeof(m0));
                        else pwrite(fd, &m0, sizeof(m0), (off_t)(cam + poff));
                    }
                }
            }
        }
        usleep(500);
    }
    return nullptr;
}

static void aspect_stop_worker() {
    if (!g_aspect_started) return;
    g_aspect_run.store(false, std::memory_order_release);
    pthread_join(g_aspect_thread, nullptr);
    g_aspect_started = false;
    const int fd = g_aspect_fd.exchange(-1, std::memory_order_acq_rel);
    if (fd >= 0) close(fd);
}

static void aspect_reset_discovery() {
    g_aspect_slot_count = 0;
    for (auto& s : g_aspect_slots) s = {};
    g_aspect_flag_off = -1;
    g_aspect_flag_orig = 0;
    g_aspect_orig_m0_valid = false;
    g_aspect_slots_n.store(0, std::memory_order_release);
    g_aspect_flag_pub.store(-1, std::memory_order_release);
}

static bool aspect_find_slots(uint64_t native_cam, float screen_aspect) {
    if (g_aspect_slot_count > 0 && g_aspect_cam_cached == native_cam)
        return true;
    if (!likely_native_pointer(native_cam)) return false;

    aspect_reset_discovery();
    g_aspect_cam_cached = native_cam;

    xray_find_camera_matrices(native_cam);

    float want = screen_aspect;
    if (g_xray_proj_off >= 0) {
        Mat4 P;
        if (rd_bulk(native_cam + g_xray_proj_off, &P, sizeof(P)) &&
            std::isfinite(P.m[0]) && std::isfinite(P.m[5]) &&
            fabsf(P.m[0]) > 1e-6f) {
            const float a = P.m[5] / P.m[0];
            if (std::isfinite(a) && a > 0.2f && a < 6.0f) want = a;
            g_aspect_orig_m0 = P.m[0];
            g_aspect_orig_m0_valid = true;
        }
    }
    if (!std::isfinite(want) || want < 0.2f || want > 6.0f) return false;

    std::vector<unsigned char> buf(ASPECT_WINDOW);
    if (!rd_bulk(native_cam, buf.data(), ASPECT_WINDOW)) return false;

    for (int off = 0; off + 4 <= ASPECT_WINDOW &&
                      g_aspect_slot_count < ASPECT_MAX_SLOTS; off += 4) {
        if (off == g_xray_near_off) continue;
        if (g_xray_proj_off >= 0 && off >= g_xray_proj_off &&
            off < g_xray_proj_off + (int)sizeof(Mat4))
            continue;
        if (g_xray_view_off >= 0 && off >= g_xray_view_off &&
            off < g_xray_view_off + (int)sizeof(Mat4))
            continue;
        float a = 0.f;
        memcpy(&a, buf.data() + off, 4);
        if (!std::isfinite(a)) continue;
        if (fabsf(a - want) > want * 0.004f + 1e-5f) continue;
        g_aspect_slots[g_aspect_slot_count].off = off;
        g_aspect_slots[g_aspect_slot_count].orig = a;
        ++g_aspect_slot_count;
    }

    if (g_aspect_slot_count > 0) {
        const int first = g_aspect_slots[0].off;
        for (int probe = first + 4; probe <= first + 32 &&
                                    probe < ASPECT_WINDOW; ++probe) {
            const uint8_t b = buf[probe];
            if (b == 0) { g_aspect_flag_off = probe; break; }
            if (b == 1) break;
        }
        if (g_aspect_flag_off >= 0)
            g_aspect_flag_orig = buf[g_aspect_flag_off];
    }

    for (int i = 0; i < g_aspect_slot_count; ++i)
        g_aspect_slots_pub[i].store(g_aspect_slots[i].off,
                                    std::memory_order_release);
    g_aspect_slots_n.store(g_aspect_slot_count, std::memory_order_release);
    g_aspect_flag_pub.store(g_aspect_flag_off, std::memory_order_release);

    return g_aspect_slot_count > 0 || g_xray_proj_off >= 0;
}

void memory_aspect_update(bool enabled, float ratio) {
    if (!enabled) {
        aspect_stop_worker();
        g_aspect_active.store(false, std::memory_order_release);
        g_aspect_cam.store(0, std::memory_order_release);
        if (g_aspect_applied) {
            uint64_t cam = resolve_native_camera();
            if (cam && likely_native_pointer(cam)) {
                for (int i = 0; i < g_aspect_slot_count; ++i) {
                    if (g_aspect_slots[i].off >= 0 &&
                        g_aspect_slots[i].orig > 0.f)
                        wr_bulk(cam + g_aspect_slots[i].off,
                                &g_aspect_slots[i].orig, 4);
                }
                if (g_aspect_flag_off >= 0)
                    wr_bulk(cam + g_aspect_flag_off, &g_aspect_flag_orig, 1);
                if (g_xray_proj_off >= 0 && g_aspect_orig_m0_valid)
                    wr_bulk(cam + g_xray_proj_off, &g_aspect_orig_m0, 4);
            }
            g_aspect_applied = false;
        }
        return;
    }
    if (g_pid <= 0 || !g_il2cpp_base) {
        g_aspect_active.store(false, std::memory_order_release);
        return;
    }

    uint64_t cam = resolve_native_camera();
    if (!cam || !likely_native_pointer(cam)) {
        g_aspect_active.store(false, std::memory_order_release);
        g_aspect_cam.store(0, std::memory_order_release);
        g_aspect_slots_n.store(0, std::memory_order_release);
        g_aspect_flag_pub.store(-1, std::memory_order_release);
        g_aspect_proj_off.store(-1, std::memory_order_release);
        g_aspect_cam_cached = 0;
        g_aspect_slot_count = 0;
        return;
    }

    if (g_aspect_cam_cached != 0 && g_aspect_cam_cached != cam) {
        g_aspect_cam.store(0, std::memory_order_release);
        g_aspect_slots_n.store(0, std::memory_order_release);
        g_aspect_flag_pub.store(-1, std::memory_order_release);
        g_aspect_proj_off.store(-1, std::memory_order_release);
        g_aspect_applied = false;
    }

    float screen_aspect = 2.00f;
    {
        Mat4 P{};
        if (g_last_good_projection.valid) {
            P = g_last_good_projection.proj;
            if (std::isfinite(P.m[0]) && fabsf(P.m[0]) > 1e-6f) {
                const float a = P.m[5] / P.m[0];
                if (std::isfinite(a) && a > 0.2f && a < 6.0f)
                    screen_aspect = a;
            }
        }
    }

    if (!aspect_find_slots(cam, screen_aspect)) return;

    float v = ratio;
    if (!std::isfinite(v)) return;
    if (v < 0.30f) v = 0.30f;
    else if (v > 5.00f) v = 5.00f;

    g_aspect_want.store(v, std::memory_order_relaxed);
    g_aspect_active_value.store(v, std::memory_order_relaxed);
    g_aspect_active.store(true, std::memory_order_release);
    g_aspect_proj_off.store(g_xray_proj_off, std::memory_order_release);
    g_aspect_cam.store(cam, std::memory_order_release);
    g_aspect_applied = true;

    if (!g_aspect_started) {
        if (g_driver_mode && g_driver && g_driver->available()) {
            g_aspect_fd.store(-1, std::memory_order_release);
            g_aspect_run.store(true, std::memory_order_release);
            if (pthread_create(&g_aspect_thread, nullptr, aspect_worker,
                               nullptr) == 0) {
                g_aspect_started = true;
            } else {
                g_aspect_run.store(false, std::memory_order_release);
            }
        } else {
            char path[64]{};
            snprintf(path, sizeof(path), xv::StrStable(xv::sid::kGsProcDMem), (int)g_pid);
            const int fd = open(path, O_RDWR | O_CLOEXEC);
            if (fd < 0) return;
            g_aspect_fd.store(fd, std::memory_order_release);
            g_aspect_run.store(true, std::memory_order_release);
            if (pthread_create(&g_aspect_thread, nullptr, aspect_worker,
                               nullptr) == 0) {
                g_aspect_started = true;
            } else {
                g_aspect_run.store(false, std::memory_order_release);
                const int stale = g_aspect_fd.exchange(-1,
                                                       std::memory_order_acq_rel);
                if (stale >= 0) close(stale);
            }
        }
    }
}

void memory_xray_update(bool enabled, float distance) {
    if (!enabled) {
        if (g_xray_applied && g_xray_near_off >= 0) {
            uint64_t cam = resolve_native_camera();
            if (cam && likely_native_pointer(cam))
                wr_bulk(cam + g_xray_near_off, &g_xray_orig_near, 4);
            g_xray_applied = false;
            g_xray_applied_near = 0.f;
        }
        return;
    }
    if (g_pid <= 0 || !g_il2cpp_base) return;

    uint64_t cam = resolve_native_camera();
    if (!cam || !likely_native_pointer(cam)) return;
    if (!xray_find_near_clip(cam)) return;

    float d = distance;
    if (d < 0.1f) d = 0.1f;
    else if (d > 100.f) d = 100.f;

    double now = xray_now_ms();
    const bool changed = fabsf(d - g_xray_applied_near) > 1e-4f;
    if (g_xray_applied && !changed &&
        now - g_xray_last_write_ms < 200.0) return;
    g_xray_last_write_ms = now;

    wr_bulk(cam + g_xray_near_off, &d, 4);
    g_xray_applied_near = d;
    g_xray_applied = true;
}
