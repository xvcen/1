#include "main.h"
#include "xvstrings.h"
#include "game.h"
#include "xvseal.h"
#include "integrity.h"
#include "statefile.h"

struct LangStrings {
    const char* tab_main;
    const char* tab_aim;
    const char* tab_visuals;
    const char* tab_memory;
    const char* tab_other;
    const char* tab_settings;
    const char* on;
    const char* off;
    const char* cancel;
    const char* exit_btn;
    const char* exit_question;
    const char* exit_body;
    const char* done;
    const char* delete_btn;
    const char* delete_cfg_question;
    const char* delete_cfg_body;
    const char* create_config;
    const char* configs;
    const char* no_configs;
    const char* loaded_badge;
    const char* load;
    const char* save;
    const char* config_name;
    const char* toast_cfg_limit;
    const char* toast_cfg_created;
    const char* toast_cfg_saved;
    const char* toast_cfg_not_found;
    const char* toast_cfg_bad;
    const char* toast_cfg_loaded;
    const char* toast_cfg_deleted;
    const char* about;
    const char* tg_channel;
    const char* tg_open;
    const char* tg_opening;
    const char* aim_mode_hdr;
    const char* bone;
    const char* appearance;
    const char* thickness;
    const char* bone_head;
    const char* bone_neck;
    const char* bone_chest;
    const char* in_ads;
    const char* hipfire;
    const char* enable_aimbot;
    const char* aimbot_mode_hdr;
    const char* mode_native;
    const char* mode_memory;
    const char* toast_native;
    const char* toast_memory;
    const char* fov_hdr;
    const char* fov_radius;
    const char* smooth_hdr;
    const char* smoothness;
    const char* custom_crosshair;
    const char* crosshair_size;
    const char* advanced;
    const char* esp_hdr;
    const char* box;
    const char* names;
    const char* weapon;
    const char* skeleton;
    const char* health;
    const char* tracers;
    const char* distance;
    const char* target_arrow;
    const char* ignore_teammates;
    const char* ore_hdr;
    const char* sulfur_ore;
    const char* iron_ore;
    const char* stone_ore;
    const char* world_hdr;
    const char* bots;
    const char* crates;
    const char* animals;
    const char* warning;
    const char* warn_memory;
    const char* warn_risk;
    const char* warn_use;
    const char* memory_hdr;
    const char* no_recoil;
    const char* no_spread;
    const char* hands_fov_hdr;
    const char* hands_fov;
    const char* hands_fov_value;
    const char* aspect_hdr;
    const char* aspect_toggle;
    const char* aspect_value;
    const char* black_sky;
    const char* freecam;
    const char* freecam_settings_hdr;
    const char* speed;
    const char* controls;
    const char* interface_hdr;
    const char* dark_theme;
    const char* row_separators;
    const char* show_fps;
    const char* system_hdr;
    const char* exit_app;
    const char* enemies;
    const char* bots_label;
    const char* dist_fmt;
    const char* fc_move;
    const char* fc_look;
    const char* ore_stone_name;
    const char* ore_sulfur_name;
    const char* ore_iron_name;
    const char* w_bear;
    const char* w_boar;
    const char* w_deer;
    const char* w_rabbit;
    const char* w_chicken;
    const char* w_cannibal;
    const char* w_hare;
    const char* w_wolf;
    const char* w_bot;
    const char* w_box;
    const char* w_elite_box;
    const char* w_military_box;
    const char* w_tool_box;
    const char* zone_hint;
    const char* zone_saved_toast;
    const char* offscreen_arrows;
    const char* auth_title;
    const char* auth_subtitle;
    const char* auth_key_hint;
    const char* auth_net_error;
    const char* auth_success;
    const char* auth_fail;
    const char* af_hdr;
    const char* af_start;
    const char* af_stop;
    const char* af_ores;
    const char* af_btns_hdr;
    const char* af_sulfur;
    const char* af_iron;
    const char* af_stone;
    const char* af_joy_hdr;
    const char* af_joy_set;
    const char* af_joy_hint;
    const char* af_joy_saved;
    const char* af_fire_hdr;
    const char* af_fire_set;
    const char* af_pick_type;
    const char* af_started;
    const char* af_stopped;
    const char* w_fish;
    const char* w_cupboard;
    const char* w_turret;
    const char* always_day;
    const char* xray_toggle;
    const char* xray_settings_hdr;
    const char* xray_radius;
    const char* freecam_bind;
    const char* online_label;
    const char* af_respawn;
    const char* af_rs_hdr;
    const char* af_rs_set;
    const char* af_rs_hint;
    const char* af_rs_saved;
    const char* tree_label;
    const char* ore_tree_name;
    const char* turrets_label;
    const char* accent_color;
    const char* version_title;
    const char* version_release;
    const char* version_beta;
    const char* mode_title;
    const char* mode_direct;
    const char* mode_rt;
    const char* mode_qx;
    const char* driver_not_found;
    const char* aim_zone_hdr;
    const char* aim_zone_show;
    const char* aim_zone_lr;
    const char* aim_zone_ud;
    const char* aim_zone_w;
    const char* aim_zone_h;
};

#include "en.h"
#include "ru.h"
#include <cmath>
#include <atomic>
#include <chrono>
#include <string>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sys/inotify.h>
#include <sys/syscall.h>
#include <poll.h>
#include <signal.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdarg>
#include <cstdlib>
#include <cstdio>
#include <thread>
#include <unordered_set>
#include <time.h>

#include "media/anime.h"
#include "media/icons.h"

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#include "stb_image/stb_image.h"
#include "Blur/Blur.h"
#include "animations.h"
#include "auth.h"

#include "media/audio.h"
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

enum SoundId { SND_CLICK = 0, SND_SUCCESS, SND_COUNT };

static const struct { const uint8_t* data; size_t len; } kSoundSrc[SND_COUNT] = {
    { click_wav,   click_wav_len   },
    { success_wav, success_wav_len },
};

struct AudioState {
    SLObjectItf engineObj  = nullptr;
    SLEngineItf engineItf  = nullptr;
    SLObjectItf outputMix  = nullptr;
    struct Player {
        SLObjectItf                   obj  = nullptr;
        SLPlayItf                     play = nullptr;
        SLAndroidSimpleBufferQueueItf bq   = nullptr;
    } players[SND_COUNT];
};
static AudioState g_audio;

static void AudioInit() {
    SLEngineOption opt[] = {{ SL_ENGINEOPTION_THREADSAFE, SL_BOOLEAN_TRUE }};
    if (slCreateEngine(&g_audio.engineObj, 1, opt, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) return;
    if ((*g_audio.engineObj)->Realize(g_audio.engineObj, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) return;
    if ((*g_audio.engineObj)->GetInterface(g_audio.engineObj, SL_IID_ENGINE, &g_audio.engineItf) != SL_RESULT_SUCCESS) return;
    if ((*g_audio.engineItf)->CreateOutputMix(g_audio.engineItf, &g_audio.outputMix, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) return;
    if ((*g_audio.outputMix)->Realize(g_audio.outputMix, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) return;

    for (int i = 0; i < SND_COUNT; i++) {
        const uint8_t* wav = kSoundSrc[i].data;
        uint16_t channels = 0; uint32_t sampleRate = 0; uint16_t bps = 0;
        memcpy(&channels,   wav + 22, 2);
        memcpy(&sampleRate, wav + 24, 4);
        memcpy(&bps,        wav + 34, 2);

        SLDataLocator_AndroidSimpleBufferQueue loc = { SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 1 };
        SLDataFormat_PCM fmt = {
            SL_DATAFORMAT_PCM, (SLuint32)channels, (SLuint32)sampleRate * 1000,
            (SLuint32)bps, (SLuint32)bps,
            channels == 2 ? SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT : SL_SPEAKER_FRONT_CENTER,
            SL_BYTEORDER_LITTLEENDIAN
        };
        SLDataSource src  = { &loc, &fmt };
        SLDataLocator_OutputMix outLoc = { SL_DATALOCATOR_OUTPUTMIX, g_audio.outputMix };
        SLDataSink   sink = { &outLoc, nullptr };

        const SLInterfaceID ids[] = { SL_IID_BUFFERQUEUE };
        const SLboolean     req[] = { SL_BOOLEAN_TRUE };
        if ((*g_audio.engineItf)->CreateAudioPlayer(g_audio.engineItf, &g_audio.players[i].obj, &src, &sink, 1, ids, req) != SL_RESULT_SUCCESS) continue;
        if ((*g_audio.players[i].obj)->Realize(g_audio.players[i].obj, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) continue;
        (*g_audio.players[i].obj)->GetInterface(g_audio.players[i].obj, SL_IID_PLAY,        &g_audio.players[i].play);
        (*g_audio.players[i].obj)->GetInterface(g_audio.players[i].obj, SL_IID_BUFFERQUEUE, &g_audio.players[i].bq);
        (*g_audio.players[i].play)->SetPlayState(g_audio.players[i].play, SL_PLAYSTATE_PLAYING);
    }
}

static void PlaySound(SoundId id) {
    auto& p = g_audio.players[id];
    if (!p.bq || !p.play) return;
    (*p.play)->SetPlayState(p.play, SL_PLAYSTATE_STOPPED);
    (*p.bq)->Clear(p.bq);
    (*p.bq)->Enqueue(p.bq, (void*)(kSoundSrc[id].data + 44),
                   (SLuint32)(kSoundSrc[id].len - 44));
    (*p.play)->SetPlayState(p.play, SL_PLAYSTATE_PLAYING);
}

static void AudioFree() {
    for (int i = 0; i < SND_COUNT; i++) {
        if (g_audio.players[i].obj) { (*g_audio.players[i].obj)->Destroy(g_audio.players[i].obj); g_audio.players[i].obj = nullptr; }
    }
    if (g_audio.outputMix) { (*g_audio.outputMix)->Destroy(g_audio.outputMix); g_audio.outputMix = nullptr; }
    if (g_audio.engineObj) { (*g_audio.engineObj)->Destroy(g_audio.engineObj); g_audio.engineObj = nullptr; }
}

static void VisibleScreen(float& w, float& h);

namespace cfg { namespace esp {
    inline ImVec4 box_col         = {1.00f, 1.00f, 1.00f, 1.f};
    inline ImVec4 name_col        = {1.00f, 1.00f, 1.00f, 1.f};
    inline ImVec4 weapon_col      = {1.00f, 1.00f, 1.00f, 1.f};
    inline ImVec4 distance_col    = {1.00f, 1.00f, 1.00f, 1.f};
    inline ImVec4 tracer_col      = {1.00f, 1.00f, 1.00f, 1.f};
    inline ImVec4 skeleton_col    = {1.00f, 1.00f, 1.00f, 1.f};
    inline float tracer_thickness = 1.0f;
    inline ImVec4 hp_min_col      = {1.00f, 0.20f, 0.10f, 1.f};
    inline ImVec4 hp_max_col      = {0.20f, 0.85f, 0.35f, 1.f};
}}

namespace cfg { namespace aim {
    inline float fov_color[4]      = {1.0f, 1.0f, 1.0f, 1.0f};
}}


std::atomic<bool> main_thread_flag{true};
std::atomic<bool> g_frame_done{true};

static const char* TargetPackage() { return xv::StrStable(xv::sid::kTargetPackage); }

static pid_t g_target_pid = -1;
static std::atomic<bool> g_esp_attached{false};
static std::thread g_attach_thread;
static std::atomic<bool> g_attach_running{false};

static bool  g_modeChosen = false;
static int   g_mode = 0;
static float g_modeSelT = -1.f, g_modeSelVel = 0.f;
static bool  g_modeFailed = false;

static pid_t find_pid(const char* pkg) {
    DIR* directory = opendir(xv::StrC(xv::sid::kProcRoot));
    if (!directory) return -1;
    struct dirent* entry;
    char path[256], command[256];
    pid_t child_fallback = -1;
    while ((entry = readdir(directory))) {
        pid_t pid = (pid_t)atoi(entry->d_name);
        if (pid <= 0) continue;
        snprintf(path, sizeof(path), xv::StrC(xv::sid::kProcCmdline), pid);
        FILE* file = fopen(path, "r");
        if (!file) continue;
        memset(command, 0, sizeof(command));
        size_t count = fread(command, 1, sizeof(command) - 1, file);
        fclose(file);
        if (count == 0) continue;
        if (strcmp(command, pkg) == 0) { closedir(directory); return pid; }
        size_t pkg_len = strlen(pkg);
        if (child_fallback <= 0 && strncmp(command, pkg, pkg_len) == 0 && command[pkg_len] == ':')
            child_fallback = pid;
    }
    closedir(directory);
    return child_fallback;
}

static int open_process_wait_fd(pid_t pid) {
#if defined(__NR_pidfd_open)
    return (int)syscall(__NR_pidfd_open, pid, 0);
#elif defined(__aarch64__)

    return (int)syscall(434, pid, 0);
#else
    (void)pid;
    return -1;
#endif
}

static bool wait_process_exit(pid_t pid, int pidfd, int timeout_ms) {
    if (pidfd >= 0) {
        pollfd descriptor{pidfd, POLLIN, 0};
        int result;
        do { result = poll(&descriptor, 1, timeout_ms); }
        while (result < 0 && errno == EINTR);
        return result > 0 && (descriptor.revents & (POLLIN | POLLHUP | POLLERR));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(timeout_ms));
    return kill(pid, 0) != 0 && errno == ESRCH;
}

static void InstallAltStack();

static void start_attach_thread() {
    if (!IntegrityRevalidate(0x5c18a2e79f346db1ULL)) _exit(173);
    g_attach_running.store(true);
    g_attach_thread = std::thread([]() {
        InstallAltStack();
        int process_wait_fd = -1;
        while (g_attach_running.load()) {
            if (!g_modeChosen) {
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
                continue;
            }
            if (!g_esp_attached.load()) {

                pid_t current = find_pid(TargetPackage());
                if (current > 0 && esp_init(current)) {
                    g_target_pid = current;
                    process_wait_fd = open_process_wait_fd(current);
                    g_esp_attached.store(true);
                                continue;
                }

                std::this_thread::sleep_for(std::chrono::milliseconds(50));
                continue;
            }

            if (!wait_process_exit(g_target_pid, process_wait_fd, 250))
                continue;

            g_esp_attached.store(false);
            if (process_wait_fd >= 0) close(process_wait_fd);
            process_wait_fd = -1;
            esp_reset();
            g_target_pid = -1;
        }
        if (process_wait_fd >= 0) close(process_wait_fd);
    });
}

static void stop_attach_thread() {
    g_attach_running.store(false);
    if (g_attach_thread.joinable()) g_attach_thread.join();
}

struct ToastState {
    char  msg[128]     = {};
    char  nextMsg[128] = {};
    bool  hasNext      = false;
    float slidePos = 0.f, slideVel = 0.f;
    float life = 0.f;
    float textA = 0.f, textAVel = 0.f;
    float barW = 0.f, barVel = 0.f;
    float widthAnim = 200.f, widthVel = 0.f;
    bool  visible = false, closing = false;
};
static ToastState g_toast;

static void ShowToast(const char* msg) {
    if (!g_toast.visible || g_toast.closing) {
        snprintf(g_toast.msg, sizeof(g_toast.msg), "%s", msg);
        g_toast.life = 0.f; g_toast.closing = false; g_toast.visible = true;
        g_toast.slidePos = 0.f; g_toast.slideVel = 0.f;
        g_toast.textA = 0.f; g_toast.textAVel = 0.f;
        g_toast.barW = 1.f; g_toast.barVel = 0.f;
        g_toast.widthVel = 0.f;
        g_toast.hasNext = false;
    } else {
        snprintf(g_toast.nextMsg, sizeof(g_toast.nextMsg), "%s", msg);
        g_toast.hasNext = true; g_toast.life = 0.f;
    }
}

struct SpriteState {
    ImTextureID texture = (ImTextureID)0;
    static constexpr int   Cols  = 8;
    static constexpr int   Rows  = 10;
    static constexpr int   Total = 74;
    static constexpr float FPS   = 30.f;
    float timer = 0.f;
    int   frame = 0;
};
static SpriteState g_sprite;
static ImTextureID g_tabIcons[6] = {};

static ImTextureID LoadTexFromMemory(const unsigned char* data, int len) {
    int w, h, ch;
    unsigned char* px = stbi_load_from_memory(data, len, &w, &h, &ch, 4);
    if (!px) return (ImTextureID)0;
    ImTextureID tex = VkTex_UploadRGBA(px, w, h);
    stbi_image_free(px);
    return tex;
}

void LoadTabIcons() {
    g_tabIcons[0] = LoadTexFromMemory(main_tab_png, (int)main_tab_png_len);
    g_tabIcons[1] = LoadTexFromMemory(aimbot_png,   (int)aimbot_png_len);
    g_tabIcons[2] = LoadTexFromMemory(visuals_png,  (int)visuals_png_len);
    g_tabIcons[3] = LoadTexFromMemory(memory_png,   (int)memory_png_len);
    g_tabIcons[4] = LoadTexFromMemory(misc_png,     (int)misc_png_len);
    g_tabIcons[5] = LoadTexFromMemory(settings_png, (int)settings_png_len);
}

void LoadAnimeImage() {
    int w, h, ch;
    unsigned char* px = stbi_load_from_memory(anime_png, (int)anime_png_len, &w, &h, &ch, 4);
    if (!px) return;
    g_sprite.texture = VkTex_UploadRGBA(px, w, h);
    stbi_image_free(px);
}

static inline float Lerpf(float a, float b, float t)   { return a + (b - a) * t; }
static inline float Clamp01(float t)                    { return t < 0.f ? 0.f : t > 1.f ? 1.f : t; }
static inline float EaseOut3(float t)                   { float i = 1 - t; return 1 - i * i * i; }
static inline float EaseInOut(float t)                  { return t * t * (3 - 2 * t); }

static const float WW_MIN = 840.f;
static const float WH_MIN = 720.f;

struct WindowState {
    ImVec2 pos              = {-1.f, -1.f};
    float  w                = WW_MIN;
    float  h                = WH_MIN;
    bool   dragging         = false;
    ImVec2 touchStart       = {0, 0};
    ImVec2 posStart         = {0, 0};
    bool   resizing         = false;
    ImVec2 resizeTouchStart = {0, 0};
    ImVec2 sizeStart        = {WW_MIN, WH_MIN};
};
static WindowState g_win;

static bool  menu_open    = true;
static float g_menuFadeIn = 0.f;

enum LoginPhase { LP_FORM = 0, LP_CHECKING, LP_SUCCESS, LP_FAIL };

struct LoginAnim {
    int   phase = LP_FORM;
    float t = 0.f;
    float cardA = 0.f;
    float playedOk = false;
};
static LoginAnim g_login;

static bool        g_loginReady = false;
static std::string g_keyInput;
static float       g_netRetry = 0.f;
static bool        g_netToast = false;

static bool        g_versionChosen = false;
static int         g_version = 0;
static float       g_versionCardA = 0.f;
static float       g_versionSelT = 0.f, g_versionSelVel = 0.f;
static float       g_versionConfirmT = 0.f;
static bool        g_versionPicked = false;

static const char* kMenuWinName = xv::StrStable(xv::sid::kMiMenu);

static void EndWinDrag() {
    if (!g_win.dragging) return;
    ImGenie::SetExternalDragging(kMenuWinName, false);
    g_win.dragging = false;
}

static void BeginWinDrag(const ImVec2& anchor) {
    ImGenie::SetExternalDragging(kMenuWinName, true);
    g_win.dragging = true;
    g_win.touchStart = anchor;
    g_win.posStart = g_win.pos;
}

struct WmRect { float x0 = 16.f, y0 = 16.f, x1 = 36.f, y1 = 36.f; };

static WmRect g_genieTargetRect;

static void CloseMenuOverlays();

static inline bool InVisibleClip(ImVec2 p) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 cmin = dl->GetClipRectMin();
    ImVec2 cmax = dl->GetClipRectMax();
    return p.x >= cmin.x && p.x <= cmax.x && p.y >= cmin.y && p.y <= cmax.y;
}

static inline bool WasTappedHere() {
    const auto& io = ImGui::GetIO();
    if (!io.MouseReleased[0]) return false;
    if (!menu_open) return false;
    if (g_menuFadeIn < 1.f) return false;
    auto cp0 = io.MouseClickedPos[0];
    if (cp0.x < g_win.pos.x || cp0.x > g_win.pos.x + g_win.w ||
        cp0.y < g_win.pos.y || cp0.y > g_win.pos.y + g_win.h) return false;
    if (!InVisibleClip(cp0)) return false;
    auto min = ImGui::GetItemRectMin();
    auto max = ImGui::GetItemRectMax();
    auto cp  = io.MouseClickedPos[0];
    auto mp  = io.MousePos;
    bool started = cp.x >= min.x && cp.x <= max.x && cp.y >= min.y && cp.y <= max.y;
    bool ended   = mp.x >= min.x - 12.f && mp.x <= max.x + 12.f && mp.y >= min.y - 12.f && mp.y <= max.y + 12.f;
    float dx = mp.x - cp.x, dy = mp.y - cp.y;
    return started && ended && (dx * dx + dy * dy) <= 30.f * 30.f;
}







struct AppState {
    struct SliderAnim { float pos = -1.f; float vel = 0.f; };

    int   cur_tab = 0;
    bool  aim_touch = false;
    bool  aim_mode_test = false;
    bool  aim_zone_enabled = false;
    float aim_zone_x = 0.72f, aim_zone_y = 0.45f;
    float aim_zone_w = 0.04f, aim_zone_h = 0.07f;
    bool  fire_zone_set = false;
    float fire_zone_x = 0.82f, fire_zone_y = 0.60f;
    bool  aim_ads = true, aim_hipfire = true;
    int   aim_bone = 0;
    bool  esp_box = false, esp_name = false, esp_hp = false, esp_wall = false;
    bool  esp_weapon = false;
    bool  esp_tracer = false, esp_skeleton = false, esp_aim_arrow = false;
    bool  esp_arrows = false;
    bool  esp_animals = false, esp_crates = false, esp_bots = false;
    bool  esp_cupboard = false;
    bool  esp_turret = false;
    bool  memory_always_day = false;
    bool  ignore_teammates = false;
    bool  ore_tree = false;
    bool  ore_sulfur = false, ore_iron = false, ore_stone = false;
    bool  memory_no_recoil = false;
    bool  memory_no_spread = false;
    bool  memory_hands_fov = false;
    float hands_fov_value = 70.f;
    bool  memory_aspect = false;
    float aspect_value = 2.00f;
    bool  memory_black_sky = false;
    bool  memory_freecam = false;
    bool  memory_xray = false;
    bool  freecam_bind = true;
    float fc_bind_x = 0.90f, fc_bind_y = 0.40f;
    float freecam_speed = 12.f;
    float xray_distance = 0.1f;
    float esp_thick = 1.5f;
    float gun_fov = 60.f;
    float aim_smooth = 5.f;
    bool  crosshair_custom = false;
    float crosshair_size = 14.f;
    bool  ui_fps = false, ui_dark_mode = false, ui_show_sep = false;
    int   ui_lang = 0;

    bool  ui_accent_custom = false;
    ImVec4 ui_custom_accent_col = {0.039f, 0.518f, 1.000f, 1.0f};

    bool  autofarm_on = false;
    bool  af_tree = true;
    bool  af_sulfur = true, af_iron = true, af_stone = true;
    float af_range = 150.f;
    float af_swing_ms = 350.f;
    bool  joy_zone_set = false;
    float joy_zone_x = 0.13f, joy_zone_y = 0.84f;
    bool  rs_zone_set = false;
    float rs_zone_x = 0.50f, rs_zone_y = 0.73f;

    float tab_alpha = 1.f, tab_slide = 0.f, tab_slide_vel = 0.f;
    float a_aim_touch = 0;
    float a_aim_zone = 0;
    float a_aim_zone_show = 0;
    float a_aim_ads = 1, a_aim_hipfire = 1;
    float a_aim_head  = 1, a_aim_chest = 0, a_aim_pelvis = 0;
    float a_esp_box = 0, a_esp_name = 0, a_esp_hp = 0, a_esp_wall = 0;
    float a_esp_weapon = 0;
    float a_esp_tracer = 0, a_esp_skeleton = 0, a_esp_aim_arrow = 0;
    float a_esp_arrows = 0;
    float a_ore_tree = 0;
    float a_ore_sulfur = 0, a_ore_iron = 0, a_ore_stone = 0;
    float a_esp_animals = 0, a_esp_crates = 0, a_esp_bots = 0;
    float a_ignore_teammates = 0;
    float a_memory_no_recoil = 0;
    float a_memory_no_spread = 0;
    float a_memory_hands_fov = 0;
    float a_memory_aspect = 0;
    float a_memory_black_sky = 0;
    float a_memory_always_day = 0;
    float a_esp_cupboard = 0;
    float a_esp_turret = 0;
    float a_crosshair_custom = 0;
    float a_memory_freecam = 0;
    float a_memory_xray = 0;
    float a_freecam_bind = 0;
    float a_ui_fps = 0, a_ui_dark = 0, a_ui_sep = 0;
    float a_af_tree = 1;
    float a_af_sulfur = 0, a_af_iron = 0, a_af_stone = 0;

    SliderAnim sl_gun_fov, sl_aim_smooth, sl_esp_thick, sl_freecam_speed, sl_xray_dist;
    SliderAnim sl_hands_fov;
    SliderAnim sl_aspect;
    SliderAnim sl_crosshair_size;
    SliderAnim sl_aim_zone_x, sl_aim_zone_y, sl_aim_zone_w, sl_aim_zone_h;
};
static AppState g_state;

static void SpringTick(float& pos, float& vel, float target, float dt) {
    static constexpr float kStiffness = 180.f;
    static constexpr float kDamping   = 26.f;
    static constexpr float kPosTol    = 0.001f;
    static constexpr float kVelTol    = 0.01f;
    float force = kStiffness * (target - pos) - kDamping * vel;
    vel += force * dt;
    pos += vel * dt;
    if (fabsf(target - pos) < kPosTol && fabsf(vel) < kVelTol) { pos = target; vel = 0.f; }
}

static void Tick(float& a, bool v, float dt, float spd = 12.f) {
    if (dt <= 0.f) dt = 0.0005f;
    if (dt > 0.05f) dt = 0.05f;
    const float target = v ? 1.f : 0.f;
    const float d = target - a;
    if (fabsf(d) < 1e-4f) { a = target; return; }
    float k = 1.f - expf(-spd * dt);
    const float cap = ImMax(dt * 6.f, 0.085f);
    if (k > cap) k = cap;
    a += d * k;
    if (fabsf(target - a) < 0.002f) a = target;
}

static bool  g_darkTheme = false;
static float g_themeT    = 0.f;

namespace C {
    namespace Light {
        static constexpr ImVec4 Bg     = {0.949f, 0.949f, 0.969f, 1};
        static constexpr ImVec4 LeftBg = {0.969f, 0.969f, 0.980f, 1};
        static constexpr ImVec4 Card   = {1.000f, 1.000f, 1.000f, 1};
        static constexpr ImVec4 Acc    = {0.000f, 0.478f, 1.000f, 1};
        static constexpr ImVec4 AccDk  = {0.000f, 0.380f, 0.850f, 1};
        static constexpr ImVec4 Red    = {1.000f, 0.231f, 0.188f, 1};
        static constexpr ImVec4 Txt    = {0.000f, 0.000f, 0.000f, 1};
        static constexpr ImVec4 Dim    = {0.557f, 0.557f, 0.576f, 1};
        static constexpr ImVec4 TrkOff = {0.776f, 0.776f, 0.800f, 1};
        static constexpr ImVec4 Sep    = {0.740f, 0.740f, 0.760f, 1};
    }
    namespace Dark {
        static constexpr ImVec4 Bg     = {0.15f, 0.15f, 0.16f, 1};
        static constexpr ImVec4 LeftBg = {0.137f, 0.137f, 0.145f, 1};
        static constexpr ImVec4 Card   = {0.173f, 0.173f, 0.180f, 1};
        static constexpr ImVec4 Acc    = {0.039f, 0.518f, 1.000f, 1};
        static constexpr ImVec4 AccDk  = {0.000f, 0.400f, 0.870f, 1};
        static constexpr ImVec4 Red    = {1.000f, 0.271f, 0.227f, 1};
        static constexpr ImVec4 Txt    = {1.000f, 1.000f, 1.000f, 1};
        static constexpr ImVec4 Dim    = {0.557f, 0.557f, 0.576f, 1};
        static constexpr ImVec4 TrkOff = {0.231f, 0.231f, 0.251f, 1};
        static constexpr ImVec4 Sep    = {0.340f, 0.340f, 0.380f, 1};
    }

    static inline ImVec4 Lerp4(ImVec4 a, ImVec4 b) {
        float t = EaseInOut(g_themeT);
        return {Lerpf(a.x,b.x,t), Lerpf(a.y,b.y,t), Lerpf(a.z,b.z,t), 1.f};
    }

    static inline ImVec4 Bg()     { return Lerp4(Light::Bg,     Dark::Bg);     }
    static inline ImVec4 LeftBg() { return Lerp4(Light::LeftBg, Dark::LeftBg); }
    static inline ImVec4 Card()   { return Lerp4(Light::Card,   Dark::Card);   }
    static inline ImVec4 Acc()    {
        if (g_state.ui_accent_custom) return g_state.ui_custom_accent_col;
        return Lerp4(Light::Acc, Dark::Acc);
    }
    static inline ImVec4 AccDk()  {
        ImVec4 a = Acc();
        return {a.x * 0.8f, a.y * 0.8f, a.z * 0.8f, 1.0f};
    }
    static inline ImVec4 Red()    { return Lerp4(Light::Red,    Dark::Red);    }
    static inline ImVec4 Txt()    { return Lerp4(Light::Txt,    Dark::Txt);    }
    static inline ImVec4 Dim()    { return Lerp4(Light::Dim,    Dark::Dim);    }
    static inline ImVec4 TrkOff() { return Lerp4(Light::TrkOff, Dark::TrkOff); }
    static inline ImVec4 Sep()    { return Lerp4(Light::Sep,    Dark::Sep);    }

    static ImU32 Mix(ImVec4 a, ImVec4 b, float t) {
        return IM_COL32(
            int(Lerpf(a.x, b.x, t) * 255), int(Lerpf(a.y, b.y, t) * 255),
            int(Lerpf(a.z, b.z, t) * 255), int(Lerpf(a.w, b.w, t) * 255));
    }
    static ImU32 U(ImVec4 v)               { return ImGui::ColorConvertFloat4ToU32(v); }
    static ImU32 UA(ImVec4 v, float alpha) { v.w = alpha; return ImGui::ColorConvertFloat4ToU32(v); }
}

namespace R {
    static constexpr float Card  = 32.f;
    static constexpr float Pill  = 16.f;
    static constexpr float Sheet = 32.f;
    static constexpr float Btn   = 20.f;
}

void ApplyTheme() {
    ImGui::GetIO().ConfigDebugHighlightIdConflicts = false;
    auto& s = ImGui::GetStyle();
    s.WindowRounding = 32;
    s.ChildRounding  = 28;
    s.FrameRounding  = 20;
    s.GrabRounding   = 20;
    s.PopupRounding  = 24;
    s.TabRounding    = 20;
    s.WindowBorderSize = 0;
    s.FrameBorderSize  = 0;
    s.ItemSpacing  = {10, 0};
    s.FramePadding = {14, 12};
    s.WindowPadding = {0, 0};
    s.ScrollbarSize = 0;
    s.GrabMinSize   = 20;
    auto* c = s.Colors;
    c[ImGuiCol_WindowBg]              = C::Bg();
    c[ImGuiCol_ChildBg]               = {0, 0, 0, 0};
    c[ImGuiCol_Border]                = C::Sep();
    c[ImGuiCol_BorderShadow]          = {0, 0, 0, 0};
    c[ImGuiCol_Text]                  = C::Txt();
    c[ImGuiCol_TextDisabled]          = C::Dim();
    c[ImGuiCol_ScrollbarBg]           = {0, 0, 0, 0};
    c[ImGuiCol_ScrollbarGrab]         = {0, 0, 0, 0};
    c[ImGuiCol_ScrollbarGrabHovered]  = {0, 0, 0, 0};
    c[ImGuiCol_ScrollbarGrabActive]   = {0, 0, 0, 0};
    c[ImGuiCol_SliderGrab]            = {0, 0, 0, 0};
    c[ImGuiCol_SliderGrabActive]      = {0, 0, 0, 0};
    c[ImGuiCol_FrameBg]               = {0, 0, 0, 0};
    c[ImGuiCol_FrameBgHovered]        = {0, 0, 0, 0};
    c[ImGuiCol_FrameBgActive]         = {0, 0, 0, 0};
    c[ImGuiCol_Button]                = {0, 0, 0, 0};
    c[ImGuiCol_ButtonHovered]         = {0, 0, 0, 0};
    c[ImGuiCol_ButtonActive]          = {0, 0, 0, 0};
    c[ImGuiCol_Header]                = {0, 0, 0, 0};
    c[ImGuiCol_HeaderHovered]         = {0, 0, 0, 0};
    c[ImGuiCol_HeaderActive]          = {0, 0, 0, 0};
    c[ImGuiCol_NavHighlight]          = {0, 0, 0, 0};
    c[ImGuiCol_NavWindowingHighlight] = {0, 0, 0, 0};
    c[ImGuiCol_Separator]             = C::Sep();
}

#include "keyboard.h"

namespace Layout {
    static constexpr float RowH      = 78.f;
    static constexpr float SliderH   = 108.f;
    static constexpr float HeaderH   = 66.f;
    static constexpr float Inset     = 16.f;
    static constexpr float PadX      = 20.f;
    static constexpr float TabH      = 70.f;
    static constexpr float TabPad    = 6.f;
}

struct InputState {
    bool touchConsumed = false;
};
static InputState g_input;



const LangStrings* g_Lang = &LANG_EN;

const char* world_kind_label(WorldKind kind) {
    switch (kind) {
    case WorldKind::Bear:     return g_Lang->w_bear;
    case WorldKind::Boar:     return g_Lang->w_boar;
    case WorldKind::Deer:     return g_Lang->w_deer;
    case WorldKind::Rabbit:   return g_Lang->w_rabbit;
    case WorldKind::Chicken:  return g_Lang->w_chicken;
    case WorldKind::Cannibal: return g_Lang->w_cannibal;
    case WorldKind::Hare:     return g_Lang->w_hare;
    case WorldKind::Wolf:     return g_Lang->w_wolf;
    case WorldKind::Bot:      return g_Lang->w_bot;
    case WorldKind::Lootbox:  return g_Lang->w_box;
    case WorldKind::EliteBox: return g_Lang->w_elite_box;
    case WorldKind::MilitaryBox: return g_Lang->w_military_box;
    case WorldKind::ToolBox:  return g_Lang->w_tool_box;
    case WorldKind::Fish:       return g_Lang->w_fish;
    case WorldKind::Cupboard:   return g_Lang->w_cupboard;
    case WorldKind::Turret:     return g_Lang->w_turret;
    }
    return "?";
}

static float g_pillPulse = 0.f, g_pillPulseVel = 0.f;

static void LangPopTrigger() {
    g_state.tab_alpha = 0.f;
    g_state.tab_slide = 24.f;
    g_state.tab_slide_vel = 0.f;
    g_pillPulse = 1.f;
    g_pillPulseVel = 0.f;
}

static ImU32 ColU32(const ImVec4& c) {
    return IM_COL32((int)(c.x * 255), (int)(c.y * 255), (int)(c.z * 255), (int)(c.w * 255));
}

static AimFrame g_aim_frame{};

static bool g_fire_zone_armed = false;
static bool g_fire_click_block = false;

static float FireZoneRadius(float sw, float sh) {
    return ImClamp(ImMin(sw, sh) * 0.115f, 56.f, 220.f);
}

static float RespawnZoneRadius(float sw, float sh) {
    return ImClamp(ImMin(sw, sh) * 0.115f, 56.f, 220.f);
}

static void FireZoneTick(float sw, float sh) {
    int ids[16]{};
    float xs[16]{}, ys[16]{};
    const int count = Touch_GetPointers(ids, xs, ys, 16);

    static int prev_ids[16]{};
    static int prev_count = 0;

    if (g_fire_zone_armed) {
        for (int i = 0; i < count; ++i) {
            bool is_new = true;
            for (int p = 0; p < prev_count; ++p)
                if (prev_ids[p] == ids[i]) { is_new = false; break; }
            if (!is_new) continue;
            g_state.fire_zone_x = ImClamp(xs[i] / sw, 0.02f, 0.98f);
            g_state.fire_zone_y = ImClamp(ys[i] / sh, 0.02f, 0.98f);
            g_state.fire_zone_set = true;
            g_fire_zone_armed = false;
            g_fire_click_block = true;
            ShowToast(g_Lang->zone_saved_toast);
            PlaySound(SND_SUCCESS);
            break;
        }
    }

    if (g_fire_click_block && count == 0) g_fire_click_block = false;

    for (int i = 0; i < count; ++i) prev_ids[i] = ids[i];
    prev_count = count;
}

static double AfNowSeconds() {
    return std::chrono::duration<double>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

static bool  g_af_joy_armed = false;
static bool  g_af_joy_click_block = false;
static bool  g_af_rs_armed = false;
static bool  g_af_rs_click_block = false;

static void RespawnZoneTick(float sw, float sh) {
    int ids[16]{};
    float xs[16]{}, ys[16]{};
    const int count = Touch_GetPointers(ids, xs, ys, 16);

    static int prev_ids[16]{};
    static int prev_count = 0;

    if (g_af_rs_armed) {
        for (int i = 0; i < count; ++i) {
            bool is_new = true;
            for (int p = 0; p < prev_count; ++p)
                if (prev_ids[p] == ids[i]) { is_new = false; break; }
            if (!is_new) continue;
            g_state.rs_zone_x = ImClamp(xs[i] / sw, 0.02f, 0.98f);
            g_state.rs_zone_y = ImClamp(ys[i] / sh, 0.02f, 0.98f);
            g_state.rs_zone_set = true;
            g_af_rs_armed = false;
            g_af_rs_click_block = true;
            ShowToast(g_Lang->af_rs_saved);
            PlaySound(SND_SUCCESS);
            break;
        }
    }

    if (g_af_rs_click_block && count == 0) g_af_rs_click_block = false;

    for (int i = 0; i < count; ++i) prev_ids[i] = ids[i];
    prev_count = count;
}

static void JoyZoneTick(float sw, float sh) {
    int ids[16]{};
    float xs[16]{}, ys[16]{};
    const int count = Touch_GetPointers(ids, xs, ys, 16);

    static int prev_ids[16]{};
    static int prev_count = 0;

    if (g_af_joy_armed) {
        for (int i = 0; i < count; ++i) {
            bool is_new = true;
            for (int p = 0; p < prev_count; ++p)
                if (prev_ids[p] == ids[i]) { is_new = false; break; }
            if (!is_new) continue;
            const float nx = xs[i] / sw, ny = ys[i] / sh;

            
            if (nx > 0.48f) continue;
            if (g_state.fire_zone_set) {
                const float fx = g_state.fire_zone_x * sw;
                const float fy = g_state.fire_zone_y * sh;
                const float fr = FireZoneRadius(sw, sh) * 1.6f;
                const float dx = xs[i] - fx, dy = ys[i] - fy;
                if (dx * dx + dy * dy <= fr * fr) continue;
            }
            g_state.joy_zone_x = ImClamp(nx, 0.02f, 0.46f);
            g_state.joy_zone_y = ImClamp(ny, 0.02f, 0.98f);
            g_state.joy_zone_set = true;
            g_af_joy_armed = false;
            g_af_joy_click_block = true;
            ShowToast(g_Lang->af_joy_saved);
            PlaySound(SND_SUCCESS);
            break;
        }
    }

    if (g_af_joy_click_block && count == 0) g_af_joy_click_block = false;

    for (int i = 0; i < count; ++i) prev_ids[i] = ids[i];
    prev_count = count;
}

static constexpr float kAfMineRange      = 1.70f;
static constexpr float kAfArriveRange    = 2.20f;
static constexpr float kAfArriveStallSec = 0.30f;
static constexpr float kAfMineExitRange  = 2.90f;
static constexpr float kAfXrayDistance      = 0.5f;
static constexpr float kAfTreeMineRange     = 2.20f;
static constexpr float kAfTreeArriveRange   = 2.60f;
static constexpr float kAfTreeExitRange     = 3.50f;
static constexpr float kAfNoDamageSec       = 15.0f;
static constexpr float kAfStuckSec       = 1.20f;
static constexpr float kAfBackSec        = 0.45f;
static constexpr float kAfSkipSec        = 8.0f;
static constexpr float kAfJoyRadius      = 0.24f;
static constexpr float kAfLookAnchorX    = 0.72f;
static constexpr float kAfLookAnchorY    = 0.45f;
struct AfSkipEntry { uint64_t key = 0; double until = 0.0; };
static AfSkipEntry g_af_skip[8];
static uint64_t    g_af_target_key = 0;
static uint64_t    g_af_last_target_key = 0;
static int         g_af_mode = 0;
static float       g_af_last_dist = 0.0f;
static double      g_af_last_progress = 0.0;
static double      g_af_back_since = 0.0;
static bool        g_af_joy_down = false;
static int         g_af_joy_dir = 1;
static bool        g_af_fire_down = false;
static double      g_af_align_since = 0.0;
static int         g_af_fire_jitter = 0;
static double      g_af_mine_since = 0.0;
static float       g_af_mine_fraction = -1.0f;
static double      g_af_damage_since = 0.0;
static uint64_t    g_af_damage_key = 0;
static std::unordered_set<uint64_t> g_af_banned;

static void AfBlacklist(uint64_t key) {
    const double now = AfNowSeconds();
    for (auto& s : g_af_skip) {
        if (s.key == key || s.until < now) {
            s.key = key;
            s.until = now + kAfSkipSec;
            return;
        }
    }
    g_af_skip[0] = {key, now + kAfSkipSec};
}

static void AfBanForever(uint64_t key) {
    if (!key) return;
    if (g_af_banned.size() < 4096) g_af_banned.insert(key);
}

static bool AfIsBanned(uint64_t key) {
    return g_af_banned.find(key) != g_af_banned.end();
}

static bool   g_af_look_down = false;
static float  g_af_look_x = 0.0f, g_af_look_y = 0.0f;
static float  g_af_look_sx = 0.0f, g_af_look_sy = 0.0f;
static float  g_af_look_prev_ex = 0.0f, g_af_look_prev_ey = 0.0f;
static bool   g_af_look_err_valid = false;
static int    g_af_look_pin_count = 0;

static void AfLookReset() {
    if (g_af_look_down) { Touch_Up_N(2); g_af_look_down = false; }
    g_af_look_sx = 0.0f;
    g_af_look_sy = 0.0f;
    g_af_look_err_valid = false;
    g_af_look_pin_count = 0;
}

static void AfLookTo(float tx, float ty, float sw, float sh, float dt, bool precise = false) {
    const float cx = sw * 0.5f, cy = sh * 0.5f;
    const float anchor_x = sw * kAfLookAnchorX, anchor_y = sh * kAfLookAnchorY;
    const float ex = tx - cx, ey = ty - cy;
    if (!std::isfinite(ex) || !std::isfinite(ey)) { AfLookReset(); return; }
    const float dist = sqrtf(ex * ex + ey * ey);
    const float dead = precise ? std::max(4.0f, sh * 0.006f) : std::max(8.0f, sh * 0.012f);

    if (!g_af_look_down) {
        Touch_Down_N(2, anchor_x, anchor_y);
        g_af_look_x = anchor_x;
        g_af_look_y = anchor_y;
        g_af_look_down = true;
        g_af_look_sx = 0.0f;
        g_af_look_sy = 0.0f;
        g_af_look_err_valid = false;
        g_af_look_pin_count = 0;
    }

    if (dist < dead) {
        g_af_look_sx = 0.0f;
        g_af_look_sy = 0.0f;
        g_af_look_err_valid = false;
        g_af_look_pin_count = 0;
        Touch_Down_N(2, g_af_look_x, g_af_look_y);
        return;
    }

    float cmd_x = ex * (precise ? 0.08f : 0.09f);
    float cmd_y = ey * (precise ? 0.08f : 0.09f);
    const float max_step = std::max(16.0f, sh * (precise ? 0.024f : 0.028f));
    const float cl = sqrtf(cmd_x * cmd_x + cmd_y * cmd_y);
    if (cl > max_step && cl > 0.0f) {
        const float s = max_step / cl;
        cmd_x *= s;
        cmd_y *= s;
    }

    if (dt <= 0.0f) dt = 0.016f;
    if (dt > 0.05f) dt = 0.05f;
    const float alpha = 1.0f - expf(-dt * (precise ? 20.0f : 16.0f));
    g_af_look_sx += (cmd_x - g_af_look_sx) * alpha;
    g_af_look_sy += (cmd_y - g_af_look_sy) * alpha;
    float step_x = g_af_look_sx, step_y = g_af_look_sy;
    const float sl = sqrtf(step_x * step_x + step_y * step_y);
    if (sl > max_step && sl > 0.0f) {
        const float s = max_step / sl;
        step_x *= s;
        step_y *= s;
    }
    if (g_af_look_err_valid) {
        if (ex * g_af_look_prev_ex < 0.0f) step_x *= 0.35f;
        if (ey * g_af_look_prev_ey < 0.0f) step_y *= 0.35f;
    }
    g_af_look_prev_ex = ex;
    g_af_look_prev_ey = ey;
    g_af_look_err_valid = true;

    float next_x = g_af_look_x + step_x;
    float next_y = g_af_look_y + step_y;
    bool pinned = false;
    if (next_x < sw * 0.52f)      { next_x = sw * 0.52f; pinned = true; }
    else if (next_x > sw * 0.96f) { next_x = sw * 0.96f; pinned = true; }
    if (next_y < sh * 0.08f)      { next_y = sh * 0.08f; pinned = true; }
    else if (next_y > sh * 0.92f) { next_y = sh * 0.92f; pinned = true; }

    if (pinned) {
        ++g_af_look_pin_count;
        if (g_af_look_pin_count >= 4 && dist > dead * 2.0f) {
            Touch_Up_N(2);
            g_af_look_down = false;
            g_af_look_x = anchor_x;
            g_af_look_y = anchor_y;
            g_af_look_sx = 0.0f;
            g_af_look_sy = 0.0f;
            g_af_look_err_valid = false;
            g_af_look_pin_count = 0;
            return;
        }
        g_af_look_x = next_x;
        g_af_look_y = next_y;
        Touch_Down_N(2, g_af_look_x, g_af_look_y);
        return;
    }

    g_af_look_pin_count = 0;
    g_af_look_x = next_x;
    g_af_look_y = next_y;
    Touch_Down_N(2, g_af_look_x, g_af_look_y);
}

static void AfReleaseFingers() {
    if (g_af_fire_down) { Touch_Up_N(1); g_af_fire_down = false; }
    if (g_af_joy_down)  { Touch_Up_N(0); g_af_joy_down  = false; }
    AfLookReset();
}

static bool   g_af_dead = false;
static double g_af_hp_ok_at = 0.0;
static double g_af_dead_since = 0.0;
static double g_af_tap_at = 0.0;
static bool   g_af_tap_down = false;
static int    g_af_tap_slot = 0;
static double g_af_alive_since = 0.0;

static constexpr float kAfRespawnPoints[][2] = {
    {0.500f, 0.735f},
    {0.500f, 0.640f},
    {0.500f, 0.825f},
    {0.500f, 0.560f},
    {0.320f, 0.735f},
    {0.680f, 0.735f},
};
static constexpr int kAfRespawnCount =
    (int)(sizeof(kAfRespawnPoints) / sizeof(kAfRespawnPoints[0]));

static void AfRespawnReset() {
    if (g_af_tap_down) { Touch_Up_N(0); g_af_tap_down = false; }
    g_af_tap_at = 0.0;
    g_af_tap_slot = 0;
}

static bool AfRespawnTick(float sw, float sh, double now) {
    bool hp_valid = false;
    const bool dead = esp_local_is_dead(&hp_valid);

    if (hp_valid && !dead) g_af_hp_ok_at = now;
    if (g_af_hp_ok_at <= 0.0) g_af_hp_ok_at = now;

    const bool stale = !hp_valid && now - g_af_hp_ok_at > 3.0;
    const bool down = (hp_valid && dead) || stale;

    if (!down && !g_af_dead) return false;

    if (hp_valid && !dead) {
        if (g_af_dead) {
            g_af_dead = false;
            AfRespawnReset();
            g_af_target_key = 0;
            g_af_last_target_key = 0;
            g_af_mode = 0;
            g_af_alive_since = now;
            AfLookReset();
            ShowToast(g_Lang->af_respawn);
        }
        if (g_af_alive_since > 0.0 && now - g_af_alive_since < 1.5) {
            AfReleaseFingers();
            return true;
        }
        return false;
    }

    if (!g_af_dead) {
        g_af_dead = true;
        g_af_dead_since = now;
        g_af_tap_at = now + 1.2;
        g_af_tap_slot = 0;
        AfReleaseFingers();
    }

    if (g_af_look_down || g_af_joy_down) AfReleaseFingers();

    if (g_af_tap_down) {
        if (now - g_af_tap_at >= 0.16) {
            Touch_Up_N(0);
            g_af_tap_down = false;
            g_af_tap_at = now + 0.9;
            g_af_tap_slot = (g_af_tap_slot + 1) % kAfRespawnCount;
        }
        return true;
    }

    if (now >= g_af_tap_at) {
        float tx, ty;
        if (g_state.rs_zone_set) {
            const float r = RespawnZoneRadius(sw, sh) * 0.55f;
            const float ring[][2] = {
                {0.0f, 0.0f}, {0.0f, -1.0f}, {0.0f, 1.0f},
                {-1.0f, 0.0f}, {1.0f, 0.0f}, {0.0f, 0.0f},
            };
            const int slot = g_af_tap_slot % 6;
            tx = ImClamp(g_state.rs_zone_x * sw + ring[slot][0] * r,
                         2.0f, sw - 2.0f);
            ty = ImClamp(g_state.rs_zone_y * sh + ring[slot][1] * r,
                         2.0f, sh - 2.0f);
        } else {
            tx = kAfRespawnPoints[g_af_tap_slot][0] * sw;
            ty = kAfRespawnPoints[g_af_tap_slot][1] * sh;
        }
        Touch_Down_N(0, tx, ty);
        g_af_tap_down = true;
        g_af_tap_at = now;
    }
    return true;
}

static void AutoFarmTick(float sw, float sh, float dt) {
    const double now = AfNowSeconds();

    const bool paused = !g_state.autofarm_on || !g_esp_attached.load() ||
                        menu_open || g_state.memory_freecam;

    if (paused) {
        AfReleaseFingers();
        AfRespawnReset();
        if (!g_state.autofarm_on) {
            g_af_target_key = 0;
            g_af_last_target_key = 0;
            g_af_mode = 0;
            g_af_dead = false;
            g_af_alive_since = 0.0;
            g_af_align_since = 0.0;
            g_af_banned.clear();
        }
        return;
    }

    if (AfRespawnTick(sw, sh, now)) return;

    
    
    const bool joy_zone_ok = g_state.joy_zone_set &&
                             g_state.joy_zone_x >= 0.02f &&
                             g_state.joy_zone_x <= 0.46f;
    const float jx = joy_zone_ok ? g_state.joy_zone_x * sw : sw * 0.13f;
    const float jy = joy_zone_ok ? g_state.joy_zone_y * sh : sh * 0.84f;
    const float R = ImClamp(sh * kAfJoyRadius, 160.f, 420.f);

    const float fx = (g_state.fire_zone_set ? g_state.fire_zone_x : 0.82f)
                     * sw;
    const float fy = (g_state.fire_zone_set ? g_state.fire_zone_y : 0.60f)
                     * sh;

    if (g_af_mode == 3) {
        if (now - g_af_back_since < kAfBackSec) {
            if (g_af_fire_down) { Touch_Up_N(1); g_af_fire_down = false; }
            if (!g_af_joy_down) { Touch_Down_N(0, jx, jy); g_af_joy_down = true; }
            float jy_back = ImClamp(jy + R * 0.85f, sh * 0.04f, sh * 0.96f);
            Touch_Down_N(0, jx, jy_back);
            return;
        }
        if (g_af_target_key) AfBlacklist(g_af_target_key);
        AfReleaseFingers();
        g_af_target_key = 0;
        g_af_last_target_key = 0;
        g_af_mode = 0;
        g_af_align_since = 0.0;
    }

    std::vector<OreTargetPoint> ores = esp_get_ore_targets(
        (int)sw, (int)sh, esp_max_distance(),
        g_state.af_sulfur, g_state.af_iron, g_state.af_stone,
        g_state.af_tree);

    OreTargetPoint* target = nullptr;
    if (g_af_target_key && !AfIsBanned(g_af_target_key)) {
        for (auto& o : ores) {
            if (o.key == g_af_target_key) { target = &o; break; }
        }
    }
    if (!target) {
        for (auto& o : ores) {
            if (AfIsBanned(o.key)) continue;
            bool blocked = false;
            for (const auto& s : g_af_skip)
                if (s.key == o.key && now < s.until) { blocked = true; break; }
            if (blocked) continue;
            if (!target || o.hdist < target->hdist) target = &o;
        }
    }

    if (!target) {
        AfReleaseFingers();
        g_af_mode = 0;
        return;
    }

    g_af_target_key = target->key;

    if (g_af_mode == 0 || g_af_last_target_key != target->key) {
        g_af_last_target_key = target->key;
        g_af_last_dist = target->hdist;
        g_af_last_progress = now;
        g_af_joy_dir = 1;
        g_af_mode = 1;
        g_af_align_since = 0.0;
    }

    const bool tree_target = target->kind == OreKind::Tree;
    const bool use_marker = target->has_marker;

    float ltx, lty;
    if (target->look_valid) {
        ltx = target->look_x;
        lty = target->look_y;
        ltx = ImClamp(ltx, sw * 0.05f, sw * 0.95f);
        const float lty_min = (use_marker || target->trunk_aim) ? sh * 0.08f
                                                                : sh * 0.30f;
        const float lty_max = (use_marker || target->trunk_aim) ? sh * 0.92f
                                                                : sh * 0.88f;
        lty = ImClamp(lty, lty_min, lty_max);
    } else {
        ltx = sw * 0.5f + (target->rel_yaw >= 0.0f ? sw * 0.5f : -sw * 0.5f);
        lty = sh * 0.5f;
    }

    const bool is_tree = tree_target;
    const float mine_range   = is_tree ? kAfTreeMineRange : kAfMineRange;
    const float arrive_range = is_tree ? kAfTreeArriveRange : kAfArriveRange;
    const float exit_range   = is_tree ? kAfTreeExitRange : kAfMineExitRange;

    const float approach_dist = target->hdist;

    const bool aim_marker = use_marker;

    const bool mining_this_target = (g_af_mode == 2 &&
                                     g_af_last_target_key == target->key);
    bool want_mine = false;
    if (mining_this_target) {
        want_mine = approach_dist <= exit_range;
    } else if (approach_dist <= mine_range) {
        want_mine = true;
    } else if (approach_dist <= arrive_range &&
               now - g_af_last_progress > kAfArriveStallSec) {
        want_mine = true;
    }

    if (!want_mine) {
        if (g_af_mode != 1) {
            g_af_mode = 1;
            g_af_last_dist = approach_dist;
            g_af_last_progress = now;
            g_af_joy_dir = 1;
        }
        if (g_af_fire_down) { Touch_Up_N(1); g_af_fire_down = false; }

        float jy_fwd = ImClamp(jy - R, sh * 0.04f, sh * 0.96f);

        if (!g_af_joy_down) {
            Touch_Down_N(0, jx, jy);
            g_af_joy_down = true;
        }
        Touch_Down_N(0, jx, jy_fwd);

        AfLookTo(ltx, lty, sw, sh, dt, false);

        if (approach_dist < g_af_last_dist - 0.3f) {
            g_af_last_dist = approach_dist;
            g_af_last_progress = now;
        } else if (approach_dist > arrive_range &&
                   now - g_af_last_progress > kAfStuckSec) {
            g_af_mode = 3;
            g_af_back_since = now;
            return;
        }
    } else {
        if (g_af_mode != 2 || g_af_mine_since <= 0.0) {
            g_af_mode = 2;
            g_af_mine_since = now;
            g_af_align_since = 0.0;
        }
        if (g_af_damage_key != g_af_target_key) {
            g_af_damage_key = g_af_target_key;
            g_af_mine_fraction = target->fraction;
            g_af_damage_since = now;
        } else if (target->fraction < g_af_mine_fraction - 0.0005f) {
            g_af_mine_fraction = target->fraction;
            g_af_damage_since = now;
        } else if (g_af_fire_down &&
                   now - g_af_damage_since > kAfNoDamageSec) {
            AfBanForever(g_af_target_key);
            AfBlacklist(g_af_target_key);
            AfReleaseFingers();
            g_af_target_key = 0;
            g_af_last_target_key = 0;
            g_af_damage_key = 0;
            g_af_mode = 0;
            g_af_align_since = 0.0;
            return;
        }
        g_af_last_progress = now;
        if (g_af_joy_down) {
            Touch_Down_N(0, jx, jy);
            Touch_Up_N(0);
            g_af_joy_down = false;
        }
        AfLookTo(ltx, lty, sw, sh, dt, aim_marker || target->trunk_aim);

        const float aim_dx = ltx - sw * 0.5f;
        const float aim_dy = lty - sh * 0.5f;
        const float aim_err = sqrtf(aim_dx * aim_dx + aim_dy * aim_dy);
        float aim_tol = 0.09f;
        if (aim_marker) aim_tol = 0.05f;
        else if (is_tree) aim_tol = target->trunk_aim ? 0.06f : 0.11f;
        const float aim_ok = std::max(24.0f, sh * aim_tol);
        bool aligned = target->look_valid && aim_err <= aim_ok;
        if (!aligned && target->look_valid) {
            if (g_af_align_since <= 0.0) g_af_align_since = now;
            else if (now - g_af_align_since > 1.6f &&
                     aim_err <= aim_ok * 2.2f)
                aligned = true;
        }

        if (aligned) {
            g_af_align_since = 0.0;
            if (!g_af_fire_down) {
                Touch_Down_N(1, fx, fy);
                g_af_fire_down = true;
                g_af_fire_jitter = 0;
            }
            g_af_fire_jitter ^= 1;
            Touch_Down_N(1, fx + (g_af_fire_jitter ? 1.0f : -1.0f),
                       fy + (g_af_fire_jitter ? -1.0f : 1.0f));
        } else {
            if (g_af_fire_down) {
                Touch_Up_N(1);
                g_af_fire_down = false;
            }
        }

        if ((aim_marker || target->trunk_aim) && target->look_valid && !menu_open) {
            ImDrawList* dl = ImGui::GetBackgroundDrawList();
            const ImVec2 c(ltx, lty);
            const float s = 9.0f;
            dl->AddCircle(c, s + 3.0f, IM_COL32(0, 0, 0, 180), 16, 2.5f);
            dl->AddCircle(c, s + 3.0f, IM_COL32(255, 60, 60, 220), 16, 1.5f);
            dl->AddLine({c.x - s, c.y}, {c.x + s, c.y}, IM_COL32(255, 255, 255, 240), 2.0f);
            dl->AddLine({c.x, c.y - s}, {c.x, c.y + s}, IM_COL32(255, 255, 255, 240), 2.0f);
        }
    }
}

static float g_freecam_pos[3] = {0.f, 0.f, 0.f};
static float g_freecam_yaw = 0.f;
static float g_freecam_pitch = 0.f;

static int g_nearby_enemy_count = 0;
static int g_nearby_teammate_count = 0;
static int g_nearby_bot_count = 0;

static void OverlayScreenSize(float& sw, float& sh) {
    sw = (float)native_window_screen_x;
    sh = (float)native_window_screen_y;
    if (displayInfo.width > displayInfo.height && displayInfo.width >= 100 && displayInfo.height >= 100) {
        sw = (float)displayInfo.width;
        sh = (float)displayInfo.height;
    } else if (displayInfo.height > displayInfo.width && displayInfo.height >= 100 && displayInfo.width >= 100) {
        sw = (float)displayInfo.height;
        sh = (float)displayInfo.width;
    }
}

static void DrawTracerArrow(ImDrawList* dl, const ImVec2& from, const ImVec2& tip,
                            ImU32 color, ImU32 shadow, float thickness) {
    const float dx = tip.x - from.x, dy = tip.y - from.y;
    const float length = sqrtf(dx * dx + dy * dy);
    if (!std::isfinite(length) || length < 8.0f) return;
    const float ux = dx / length, uy = dy / length;
    const float arrow_len = 7.0f, arrow_half = 3.2f;
    const ImVec2 base(tip.x - ux * arrow_len, tip.y - uy * arrow_len);
    const ImVec2 left(base.x - uy * arrow_half, base.y + ux * arrow_half);
    const ImVec2 right(base.x + uy * arrow_half, base.y - ux * arrow_half);
    dl->AddLine(from, base, shadow, thickness + 1.2f);
    dl->AddLine(from, base, color, thickness);
    dl->AddTriangleFilled(ImVec2(tip.x, tip.y + 0.6f), left, right, shadow);
    const float inset = 0.9f;
    const ImVec2 inner_tip(tip.x - ux * inset, tip.y - uy * inset);
    const ImVec2 inner_left(base.x - uy * (arrow_half - inset),
                            base.y + ux * (arrow_half - inset));
    const ImVec2 inner_right(base.x + uy * (arrow_half - inset),
                             base.y - ux * (arrow_half - inset));
    dl->AddTriangleFilled(inner_tip, inner_left, inner_right, color);
}

static void DrawTextShadowed(ImDrawList* dl, ImFont* font, float font_size,
                             float x, float y, ImU32 color, ImU32 shadow,
                             const char* text) {
    dl->AddText(font, font_size, ImVec2(x + 1.0f, y + 1.0f), shadow, text);
    const float bold = std::max(0.34f, font_size * 0.024f);
    dl->AddText(font, font_size, ImVec2(x - bold * 0.5f, y), color, text);
    dl->AddText(font, font_size, ImVec2(x + bold * 0.5f, y), color, text);
}

static void DrawCornerBox(ImDrawList* dl, const ImVec2& a, const ImVec2& b,
                          ImU32 color, float thickness, ImU32 shadowColor) {
    const float w = b.x - a.x, h = b.y - a.y;

    if (w < 2.0f || h < 2.0f) return;
    const float len = ImClamp(ImMin(w, h) * 0.28f, 2.0f, 30.0f);
    const float t = ImClamp(thickness, 0.5f, 4.0f);

    const ImVec2 c[4] = { {a.x, a.y}, {b.x, a.y}, {a.x, b.y}, {b.x, b.y} };
    const float hx[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
    const float vy[4] = { 1.0f, 1.0f, -1.0f, -1.0f };

    auto H = [&](const ImVec2& o, float dir, ImU32 col, float tw) {
        dl->AddLine(o, ImVec2(o.x + dir * len, o.y), col, tw);
    };
    auto V = [&](const ImVec2& o, float dir, ImU32 col, float tw) {
        dl->AddLine(o, ImVec2(o.x, o.y + dir * len), col, tw);
    };

    for (int i = 0; i < 4; ++i) { H(c[i], hx[i], shadowColor, t + 2.0f); V(c[i], vy[i], shadowColor, t + 2.0f); }
    const ImU32 glow = (color & 0x00FFFFFFu) | (0x4Du << 24);
    for (int i = 0; i < 4; ++i) { H(c[i], hx[i], glow, t + 1.2f); V(c[i], vy[i], glow, t + 1.2f); }
    for (int i = 0; i < 4; ++i) { H(c[i], hx[i], color, t); V(c[i], vy[i], color, t); }
    for (int i = 0; i < 4; ++i) dl->AddCircleFilled(c[i], t * 0.6f, color, 16);
}

static void AimZoneRect(float sw, float sh, float& x0, float& y0,
                        float& x1, float& y1) {
    const float cx = ImClamp(g_state.aim_zone_x, 0.05f, 0.95f) * sw;
    const float cy = ImClamp(g_state.aim_zone_y, 0.05f, 0.95f) * sh;
    float hw = ImClamp(g_state.aim_zone_w, 0.02f, 0.15f) * sw * 0.5f;
    float hh = ImClamp(g_state.aim_zone_h, 0.02f, 0.20f) * sh * 0.5f;
    hw = std::min(hw, sw * 0.5f - 4.f);
    hh = std::min(hh, sh * 0.5f - 4.f);
    x0 = ImClamp(cx - hw, 2.f, sw - 10.f);
    x1 = ImClamp(cx + hw, x0 + 8.f, sw - 2.f);
    y0 = ImClamp(cy - hh, 2.f, sh - 10.f);
    y1 = ImClamp(cy + hh, y0 + 8.f, sh - 2.f);
}


static std::vector<EspBox>& FrameBoxes(float sw, float sh,
                                       int* n_enemy = nullptr,
                                       int* n_mate = nullptr,
                                       int* n_bot = nullptr) {
    static std::vector<EspBox> cache;
    static int frame = -1, name_c = -1, skel_c = -1, weap_c = -1, ign_c = -1;
    static float sw_c = -1.f, sh_c = -1.f;
    static int e_c = 0, m_c = 0, b_c = 0;
    const int f = ImGui::GetFrameCount();
    const int nm = g_state.esp_name ? 1 : 0;
    const int sk = g_state.esp_skeleton ? 1 : 0;
    const int wp = g_state.esp_weapon ? 1 : 0;
    const int ig = g_state.ignore_teammates ? 1 : 0;
    if (frame != f || sw_c != sw || sh_c != sh ||
        nm != name_c || sk != skel_c || wp != weap_c || ig != ign_c) {
        frame = f;
        sw_c = sw; sh_c = sh;
        name_c = nm; skel_c = sk; weap_c = wp; ign_c = ig;
        cache = esp_get_boxes((int)sw, (int)sh, g_state.esp_name, true, &e_c,
                              g_state.esp_skeleton, g_state.ignore_teammates,
                              &m_c, &b_c, g_state.esp_weapon);
    }
    if (n_enemy) *n_enemy = e_c;
    if (n_mate)  *n_mate  = m_c;
    if (n_bot)   *n_bot   = b_c;
    return cache;
}

struct TouchAimTarget {
    bool  valid = false;
    unsigned long long id = 0;
    float yaw = 0.f, pitch = 0.f;
    float sx = 0.f, sy = 0.f;
    float dist = 0.f;
    float world_dist = 0.f;
    float cy_at = 0.f, cp_at = 0.f;
};

static bool  s_aim_finger_down = false;
static bool  s_aim_fingerB = false;
static float s_aim_finger_x = 0.f, s_aim_finger_y = 0.f;

static void AimTouchRelease() {
    if (!s_aim_finger_down) return;
    if (s_aim_fingerB) Touch_Up_B();
    else Touch_Up();
    s_aim_finger_down = false;
}

static bool AimPopBlocking();

static void UpdateAim(float dt) {
    static bool  s_inHold = false;
    static double s_nextPlace = 0.0;
    static unsigned long long s_lastId = 0;
    static int   s_lostFrames = 0;
    static int   s_holdFrames = 0;
    static float s_iY[2] = {0.f, 0.f};
    static float s_iP[2] = {0.f, 0.f};
    static float s_remX = 0.f, s_remY = 0.f;

    const bool menuOpen = menu_open || AimPopBlocking();
    const bool afRunning = g_state.autofarm_on && !g_state.memory_freecam && !menuOpen;
    bool active = g_state.aim_touch && g_state.aim_mode_test &&
                  g_esp_attached.load() && !menuOpen && !afRunning;
    const bool adsNow = esp_local_player_is_aiming();
    const int gm = adsNow ? 1 : 0;

    if (active) {
        const bool ads = adsNow;
        if (!(ads ? g_state.aim_ads : g_state.aim_hipfire)) active = false;
    }

    if (dt <= 0.f || !std::isfinite(dt)) dt = 1.f / 60.f;
    if (dt > 0.1f) dt = 0.1f;
    const double now = AfNowSeconds();

    if (!active) {
        AimTouchRelease();
        s_lastId = 0; s_lostFrames = 0;
        s_remX = 0.f; s_remY = 0.f;
        s_iY[0] = s_iY[1] = 0.f;
        s_iP[0] = s_iP[1] = 0.f;
        return;
    }

    float sw, sh;
    OverlayScreenSize(sw, sh);
    if (sw < 100.f || sh < 100.f) { AimTouchRelease(); return; }

    std::vector<EspBox>& boxes = FrameBoxes(sw, sh);

    const float crossX = sw * 0.5f, crossY = sh * 0.5f;
    const float fovR = std::max(10.f, std::min(360.f, g_state.gun_fov));
    float camFov = esp_camera_fov_deg();
    if (!(camFov > 1.f && camFov < 179.f)) camFov = 60.f;
    const float degPerPx = camFov / sh;

    const int wantBone = (g_state.aim_bone < 0 || g_state.aim_bone > 2) ? 0 : g_state.aim_bone;

    TouchAimTarget best;
    float bestScore = 1e18f;
    auto consider = [&](TouchAimTarget& t, unsigned long long bid) {
        if (!t.valid) return;
        t.id = bid;
        const bool sticky = (s_lastId != 0 && bid == s_lastId);
        if (t.sx < -sw || t.sx > sw * 2.f || t.sy < -sh || t.sy > sh * 2.f) return;
        float dxp = t.sx - crossX, dyp = t.sy - crossY;
        t.dist = sqrtf(dxp * dxp + dyp * dyp);
        float cone = fovR;
        if (t.world_dist >= 0.f && std::isfinite(t.world_dist) && t.world_dist < 12.f) {
            const float tt = t.world_dist <= 0.f ? 0.f : t.world_dist / 12.f;
            cone = fminf(fovR * (1.f + 1.25f * (1.f - tt) * (1.f - tt)),
                         fminf(sw, sh) * 0.5f);
        }
        if (!sticky && t.dist > cone) return;
        if (sticky && t.dist > cone * 1.44f) return;
        float score = t.dist;
        if (sticky) score *= 0.35f;
        if (score < bestScore) { bestScore = score; best = t; }
    };
    for (const EspBox& b : boxes) {
        if (g_state.ignore_teammates && b.teammate) continue;
        TouchAimTarget t;
        static const int order[3][3] = {{0, 1, 2}, {1, 0, 2}, {2, 0, 1}};
        int usedBone = -1;
        for (int k = 0; k < 3; ++k) {
            int bi = order[wantBone][k];
            if (b.aim_valid[bi]) { usedBone = bi; break; }
        }
        if (usedBone >= 0) {
            t.yaw = b.aim_yaw[usedBone];
            t.pitch = b.aim_pitch[usedBone];
            t.sx = b.aim_pts[usedBone][0];
            t.sy = b.aim_pts[usedBone][1];
            t.cy_at = b.cam_yaw_at;
            t.cp_at = b.cam_pitch_at;
            t.valid = std::isfinite(t.yaw) && std::isfinite(t.pitch) &&
                      std::isfinite(t.sx) && std::isfinite(t.sy);
        } else {
            if (!std::isfinite(b.x1) || !std::isfinite(b.y1) ||
                !std::isfinite(b.x2) || !std::isfinite(b.y2)) continue;
            float h = b.y2 - b.y1;
            if (h < 4.f || h > sh * 4.f) continue;
            const float frac = (wantBone == 0) ? 0.07f : (wantBone == 1) ? 0.15f : 0.30f;
            t.sx = (b.x1 + b.x2) * 0.5f;
            t.sy = b.y1 + frac * h;
            float ex = t.sx - crossX, ey = t.sy - crossY;
            t.yaw = atanf(ex / (sh * 0.5f) * tanf(camFov * 0.5f * (float)M_PI / 180.f)) * 180.f / (float)M_PI;
            t.pitch = -atanf(ey / (sh * 0.5f) * tanf(camFov * 0.5f * (float)M_PI / 180.f)) * 180.f / (float)M_PI;
            t.valid = true;
            t.cy_at = b.cam_yaw_at;
            t.cp_at = b.cam_pitch_at;
        }
        if (b.health >= 0.f && b.health <= 0.01f) continue;
        t.world_dist = b.distance;
        consider(t, b.id);
    }

    float liveYb = 0.f, livePb = 0.f;
    const bool haveLiveB = esp_camera_angles(liveYb, livePb);
    unsigned long long bids[24];
    float bx[24], by[24], bd[24];
    const int nBots = haveLiveB ? esp_get_bot_aims(sw, sh, bids, bx, by, bd, 24) : 0;
    for (int bi = 0; bi < nBots; ++bi) {
        TouchAimTarget t;
        t.sx = bx[bi];
        t.sy = by[bi];
        t.world_dist = bd[bi];
        float ex = t.sx - crossX, ey = t.sy - crossY;
        t.yaw = atanf(ex / (sh * 0.5f) * tanf(camFov * 0.5f * (float)M_PI / 180.f)) * 180.f / (float)M_PI;
        t.pitch = -atanf(ey / (sh * 0.5f) * tanf(camFov * 0.5f * (float)M_PI / 180.f)) * 180.f / (float)M_PI;
        t.cy_at = liveYb;
        t.cp_at = livePb;
        t.valid = std::isfinite(t.yaw) && std::isfinite(t.pitch) &&
                  std::isfinite(t.sx) && std::isfinite(t.sy);
        consider(t, bids[bi]);
    }

    if (!best.valid) {
        if (++s_lostFrames > 30) {
            AimTouchRelease();
            s_lastId = 0;
            s_remX = 0.f; s_remY = 0.f;
            s_iY[gm] *= 0.2f;
            s_iP[gm] *= 0.2f;
        }
        return;
    }
    s_lostFrames = 0;
    if (best.id != s_lastId) {
        s_iY[gm] *= 0.3f;
        s_iP[gm] *= 0.3f;
        s_remX = 0.f;
        s_remY = 0.f;
    }

    float liveYaw0 = 0.f, livePitch0 = 0.f;
    float corrY = 0.f, corrP = 0.f;
    const bool haveLive = esp_camera_angles(liveYaw0, livePitch0);
    if (haveLive) {
        corrY = best.cy_at - liveYaw0;
        corrP = best.cp_at - livePitch0;
        best.yaw += corrY;
        best.pitch += corrP;
    }
    s_lastId = best.id;

    float unitsPerPx = Touch_DeviceUnitsPerPixel();
    if (!(unitsPerPx >= 0.25f && unitsPerPx <= 16.f)) unitsPerPx = 1.f;

    float deadBase = degPerPx * 1.5f;
    if (best.world_dist > 1.f && std::isfinite(best.world_dist)) {
        float d = atanf(0.03f / best.world_dist) * 180.f / (float)M_PI;
        if (d < deadBase) deadBase = d;
    }
    const float deadYaw = deadBase, deadPitch = deadBase;

    const float exPx = best.yaw / degPerPx;
    const float epPx = -best.pitch / degPerPx;

    if (fabsf(best.yaw) < deadYaw && fabsf(best.pitch) < deadPitch) {
        s_remX = 0.f;
        s_remY = 0.f;
        s_iY[gm] *= 0.85f;
        s_iP[gm] *= 0.85f;
        s_inHold = true;
        if (s_aim_finger_down) {
            if (s_aim_fingerB) Touch_Move_B(s_aim_finger_x, s_aim_finger_y);
            else Touch_Move(s_aim_finger_x, s_aim_finger_y);
        }
        return;
    }
    s_inHold = false;

    auto snapGrid = [&](float v) { return roundf(v * unitsPerPx) / unitsPerPx; };

    float zx0, zy0, zx1, zy1;
    AimZoneRect(sw, sh, zx0, zy0, zx1, zy1);
    const float anchorX = (zx0 + zx1) * 0.5f;
    const float anchorY = (zy0 + zy1) * 0.5f;
    const float minX = zx0, maxX = zx1, minY = zy0, maxY = zy1;

    if (!s_aim_finger_down) {
        if (now < s_nextPlace) return;
        s_aim_finger_x = snapGrid(anchorX);
        s_aim_finger_y = snapGrid(anchorY);
        if (s_aim_fingerB) Touch_Down_B(s_aim_finger_x, s_aim_finger_y);
        else Touch_Down(s_aim_finger_x, s_aim_finger_y);
        s_aim_finger_down = true;
        s_remX = 0.f;
        s_remY = 0.f;
        s_holdFrames = 0;
        return;
    }
    if (s_holdFrames < 1) {
        ++s_holdFrames;
        if (s_aim_fingerB) Touch_Move_B(s_aim_finger_x, s_aim_finger_y);
        else Touch_Move(s_aim_finger_x, s_aim_finger_y);
        return;
    }

    const float mdt = std::min(std::max(dt, 1.0f / 240.0f), 1.0f / 20.0f);
    const float smClamp = std::max(0.35f, std::min(10.0f, g_state.aim_smooth));
    const float divisor = 1.0f + smClamp * 0.8f;
    const float kpPx = 4.0f;
    const float kiRaw = 45.0f / divisor;
    const float kiPx = kiRaw < 9.0f ? kiRaw : 9.0f;
    const float iThr = sh * 0.04f;
    const float iMax = sh * 0.45f;
    static float s_peY[2] = {0.f, 0.f};
    static float s_peP[2] = {0.f, 0.f};
    if (exPx * s_peY[gm] < 0.f) s_iY[gm] = 0.f;
    if (epPx * s_peP[gm] < 0.f) s_iP[gm] = 0.f;
    s_peY[gm] = exPx;
    s_peP[gm] = epPx;
    const float leak = expf(-mdt / 4.0f);
    s_iY[gm] *= leak;
    s_iP[gm] *= leak;
    const float vpx = kpPx * exPx;
    const float vpy = kpPx * epPx;
    const float vmax = sh * 3.0f;
    if (fabsf(exPx) < iThr && fabsf(epPx) < iThr &&
        fabsf(vpx) < vmax * 0.85f && fabsf(vpy) < vmax * 0.85f) {
        s_iY[gm] += kiPx * exPx * mdt;
        s_iP[gm] += kiPx * epPx * mdt;
        if (s_iY[gm] >  iMax) s_iY[gm] =  iMax;
        if (s_iY[gm] < -iMax) s_iY[gm] = -iMax;
        if (s_iP[gm] >  iMax) s_iP[gm] =  iMax;
        if (s_iP[gm] < -iMax) s_iP[gm] = -iMax;
    }
    float vx = vpx + s_iY[gm];
    float vy = vpy + s_iP[gm];
    if (vx >  vmax) vx =  vmax;
    if (vx < -vmax) vx = -vmax;
    if (vy >  vmax) vy =  vmax;
    if (vy < -vmax) vy = -vmax;

    s_remX += vx * mdt;
    s_remY += vy * mdt;
    float dx = snapGrid(s_remX);
    float dy = snapGrid(s_remY);
    s_remX -= dx;
    s_remY -= dy;
    const float maxStep = sh * 0.05f;
    if (dx >  maxStep) { dx =  maxStep; s_remX = 0.f; }
    if (dx < -maxStep) { dx = -maxStep; s_remX = 0.f; }
    if (dy >  maxStep) { dy =  maxStep; s_remY = 0.f; }
    if (dy < -maxStep) { dy = -maxStep; s_remY = 0.f; }

    if (dx == 0.f && dy == 0.f) {
        if (s_aim_fingerB) Touch_Move_B(s_aim_finger_x, s_aim_finger_y);
        else Touch_Move(s_aim_finger_x, s_aim_finger_y);
        return;
    }

    float gx = s_aim_finger_x + dx, gyp = s_aim_finger_y + dy;
    gx = fminf(fmaxf(gx, minX + 8.f), maxX - 8.f);
    gyp = fminf(fmaxf(gyp, minY + 8.f), maxY - 8.f);
    const bool pinX = fabsf(dx) >= 0.75f && fabsf(gx - s_aim_finger_x) < 0.5f;
    const bool pinY = fabsf(dy) >= 0.75f && fabsf(gyp - s_aim_finger_y) < 0.5f;
    if (pinX || pinY) {
        if (s_aim_fingerB) Touch_Up_B();
        else Touch_Up();
        s_aim_fingerB = !s_aim_fingerB;
        s_aim_finger_x = snapGrid(anchorX);
        s_aim_finger_y = snapGrid(anchorY);
        if (s_aim_fingerB) Touch_Down_B(s_aim_finger_x, s_aim_finger_y);
        else Touch_Down(s_aim_finger_x, s_aim_finger_y);
        s_remX = 0.f;
        s_remY = 0.f;
        return;
    }
    s_aim_finger_x = snapGrid(gx);
    s_aim_finger_y = snapGrid(gyp);
    if (s_aim_fingerB) Touch_Move_B(s_aim_finger_x, s_aim_finger_y);
    else Touch_Move(s_aim_finger_x, s_aim_finger_y);

    g_aim_frame.has_target = true;
    g_aim_frame.target_x = best.sx;
    g_aim_frame.target_y = best.sy;
}

static void DrawAimOverlay() {
    float sw, sh;
    OverlayScreenSize(sw, sh);

    FireZoneTick(sw, sh);
    JoyZoneTick(sw, sh);
    RespawnZoneTick(sw, sh);

    float radius = std::max(10.0f, std::min(360.0f, g_state.gun_fov));
    if (g_state.aim_touch) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        ImVec2 center(sw * 0.5f, sh * 0.5f);
        const float draw_r = radius;
        ImU32 color = IM_COL32(
            (int)(cfg::aim::fov_color[0] * 255.0f),
            (int)(cfg::aim::fov_color[1] * 255.0f),
            (int)(cfg::aim::fov_color[2] * 255.0f),
            (int)(cfg::aim::fov_color[3] * 255.0f));
        dl->AddCircle(center, draw_r, IM_COL32(0, 0, 0, 150), 128, 2.0f);
        dl->AddCircle(center, draw_r, color, 128, 1.0f);
    }

    if (g_state.aim_zone_enabled && g_state.aim_touch && g_state.aim_mode_test &&
        !g_state.memory_freecam) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        float zx0, zy0, zx1, zy1;
        AimZoneRect(sw, sh, zx0, zy0, zx1, zy1);
        const float zcx = (zx0 + zx1) * 0.5f;
        const float zcy = (zy0 + zy1) * 0.5f;
        const ImU32 zcol = g_darkTheme ? IM_COL32(120, 255, 150, 80)
                                       : IM_COL32(20, 130, 60, 90);
        const ImU32 zfill = g_darkTheme ? IM_COL32(120, 255, 150, 12)
                                        : IM_COL32(20, 130, 60, 16);
        dl->AddRectFilled({zx0, zy0}, {zx1, zy1}, zfill, 10.f);
        dl->AddRect({zx0, zy0}, {zx1, zy1}, IM_COL32(0, 0, 0, 110), 10.f, 0, 3.2f);
        dl->AddRect({zx0, zy0}, {zx1, zy1}, zcol, 10.f, 0, 1.6f);
        dl->AddLine({zcx - 9.f, zcy}, {zcx + 9.f, zcy}, zcol, 1.6f);
        dl->AddLine({zcx, zcy - 9.f}, {zcx, zcy + 9.f}, zcol, 1.6f);
        if (s_aim_finger_down) {
            dl->AddCircleFilled({s_aim_finger_x, s_aim_finger_y}, 5.5f, IM_COL32(255, 255, 255, 210), 20);
            dl->AddCircle({s_aim_finger_x, s_aim_finger_y}, 8.5f, zcol, 20, 2.0f);
        }
    }

    if (g_state.aim_touch && !Touch_CanInject()) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        ImFont* fn = ImGui::GetFont();
        const float fs2 = ImGui::GetFontSize() * 1.1f;
        const char* msg = xv::StrStable(xv::sid::kMiTOUCHINJECTOFF);
        ImVec2 tsz = fn->CalcTextSizeA(fs2, FLT_MAX, 0.f, msg);
        fg->AddText(fn, fs2, {(sw - tsz.x) * 0.5f, sh * 0.06f},
                    IM_COL32(255, 70, 70, 235), msg);
    }

    if (g_state.crosshair_custom && g_esp_attached.load()) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const ImVec2 c(sw * 0.5f, sh * 0.5f);
        const float s = g_state.crosshair_size * 2.15f;
        const double t = ImGui::GetTime();
        const float ang = (float)fmod(t * 7.5, 6.2831853);
        const float thick = std::max(5.0f, s * 0.26f);
        const ImU32 outline = IM_COL32(0, 0, 0, 235);
        const float kTau = 6.2831853f;

        auto flow = [&](float phase) {
            float h = (float)fmod(t * 0.5 + phase, 1.0);
            if (h < 0.0f) h += 1.0f;
            float r, g, b;
            ImGui::ColorConvertHSVtoRGB(h, 1.0f, 1.0f, r, g, b);
            return IM_COL32((int)(r * 255.f), (int)(g * 255.f),
                            (int)(b * 255.f), 255);
        };

        const float ring = s * 0.72f;
        const float arc = kTau / 3.0f;
        const float sweep = arc * 0.52f;
        const int kSteps = 26;

        for (int a = 0; a < 3; a++) {
            const float base = ang + arc * (float)a;
            for (int i = 0; i < kSteps; i++) {
                const float a0 = base + sweep * ((float)i / (float)kSteps);
                const float a1 = base + sweep * ((float)(i + 1) / (float)kSteps) + 0.008f;
                dl->PathArcTo(c, ring, a0, a1, 2);
                dl->PathStroke(outline, 0, thick + 4.0f);
            }
            for (int i = 0; i < kSteps; i++) {
                const float f0 = (float)i / (float)kSteps;
                const float a0 = base + sweep * f0;
                const float a1 = base + sweep * ((float)(i + 1) / (float)kSteps) + 0.008f;
                dl->PathArcTo(c, ring, a0, a1, 2);
                dl->PathStroke(flow((float)a / 3.0f + f0 * 0.33f), 0, thick);
            }
        }

        const float tip = s * 1.02f;
        const float tail = s * 0.44f;
        const float half = thick * 0.92f;
        for (int i = 0; i < 3; i++) {
            const float a = -ang * 1.25f + kTau * ((float)i / 3.0f);
            const float ca = cosf(a), sa = sinf(a);
            const ImVec2 apex(c.x + ca * tip, c.y + sa * tip);
            const ImVec2 lf(c.x + ca * tail - sa * half,
                            c.y + sa * tail + ca * half);
            const ImVec2 rt(c.x + ca * tail + sa * half,
                            c.y + sa * tail - ca * half);
            dl->AddTriangleFilled(apex, lf, rt, outline);
            const ImVec2 apex2(c.x + ca * (tip - 3.0f), c.y + sa * (tip - 3.0f));
            const ImVec2 lf2(c.x + ca * (tail + 3.0f) - sa * (half - 2.2f),
                             c.y + sa * (tail + 3.0f) + ca * (half - 2.2f));
            const ImVec2 rt2(c.x + ca * (tail + 3.0f) + sa * (half - 2.2f),
                             c.y + sa * (tail + 3.0f) - ca * (half - 2.2f));
            dl->AddTriangleFilled(apex2, lf2, rt2, flow((float)i / 3.0f + 0.5f));
        }
    }

    if (g_state.fire_zone_set && g_state.autofarm_on &&
        g_esp_attached.load() && !g_state.memory_freecam && !menu_open) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const float cx = g_state.fire_zone_x * sw;
        const float cy = g_state.fire_zone_y * sh;
        const float r = FireZoneRadius(sw, sh);
        const ImU32 col = g_darkTheme ? IM_COL32(255, 255, 255, 60)
                                      : IM_COL32(20, 40, 60, 70);
        dl->AddCircle({cx, cy}, r, IM_COL32(0, 0, 0, 110), 48, 3.2f);
        dl->AddCircle({cx, cy}, r, col, 48, 1.4f);
    }

    if (g_state.joy_zone_set && g_state.autofarm_on &&
        g_esp_attached.load() && !g_state.memory_freecam && !menu_open) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const float cx = g_state.joy_zone_x * sw;
        const float cy = g_state.joy_zone_y * sh;
        const float r = FireZoneRadius(sw, sh);
        const ImU32 col = g_darkTheme ? IM_COL32(120, 220, 255, 60)
                                      : IM_COL32(10, 100, 160, 70);
        dl->AddCircle({cx, cy}, r, IM_COL32(0, 0, 0, 110), 48, 3.2f);
        dl->AddCircle({cx, cy}, r, col, 48, 1.4f);
    }

    if (g_state.rs_zone_set && g_state.autofarm_on &&
        g_esp_attached.load() && !g_state.memory_freecam && !menu_open) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const float cx = g_state.rs_zone_x * sw;
        const float cy = g_state.rs_zone_y * sh;
        const float r = RespawnZoneRadius(sw, sh);
        const ImU32 col = g_darkTheme ? IM_COL32(120, 255, 150, 65)
                                      : IM_COL32(20, 130, 60, 75);
        dl->AddCircle({cx, cy}, r, IM_COL32(0, 0, 0, 110), 64, 3.6f);
        dl->AddCircle({cx, cy}, r, col, 64, 1.8f);
        dl->AddLine({cx - r * 0.22f, cy}, {cx + r * 0.22f, cy}, col, 2.0f);
        dl->AddLine({cx, cy - r * 0.22f}, {cx, cy + r * 0.22f}, col, 2.0f);
    }

    if (g_fire_zone_armed) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        fg->AddRectFilled({0.f, 0.f}, {sw, sh}, IM_COL32(0, 0, 0, 90));
        ImFont* fn = ImGui::GetFont();
        const float fs2 = ImGui::GetFontSize() * 1.15f;
        ImVec2 tsz = fn->CalcTextSizeA(fs2, FLT_MAX, 0.f, g_Lang->zone_hint);
        fg->AddText(fn, fs2, {(sw - tsz.x) * 0.5f, sh * 0.40f},
                    IM_COL32(255, 255, 255, 235), g_Lang->zone_hint);
    }

    if (g_af_rs_armed) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        fg->AddRectFilled({0.f, 0.f}, {sw, sh}, IM_COL32(0, 0, 0, 90));
        ImFont* fn = ImGui::GetFont();
        const float fs2 = ImGui::GetFontSize() * 1.15f;
        ImVec2 tsz = fn->CalcTextSizeA(fs2, FLT_MAX, 0.f, g_Lang->af_rs_hint);
        fg->AddText(fn, fs2, {(sw - tsz.x) * 0.5f, sh * 0.40f},
                    IM_COL32(255, 255, 255, 235), g_Lang->af_rs_hint);
    }

    if (g_af_joy_armed) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        fg->AddRectFilled({0.f, 0.f}, {sw, sh}, IM_COL32(0, 0, 0, 90));
        ImFont* fn = ImGui::GetFont();
        const float fs2 = ImGui::GetFontSize() * 1.15f;
        ImVec2 tsz = fn->CalcTextSizeA(fs2, FLT_MAX, 0.f, g_Lang->af_joy_hint);
        fg->AddText(fn, fs2, {(sw - tsz.x) * 0.5f, sh * 0.40f},
                    IM_COL32(255, 255, 255, 235), g_Lang->af_joy_hint);
    }

    const bool af_running = g_state.autofarm_on && g_esp_attached.load() &&
                            !g_state.memory_freecam && !menu_open;

    AutoFarmTick(sw, sh, ImGui::GetIO().DeltaTime);

    if (g_esp_attached.load()) {
        if (!g_state.aim_mode_test) {
            g_aim_frame = aim_update((int)sw, (int)sh,
                                     !af_running && g_state.aim_touch &&
                                         !g_state.memory_freecam,
                                     g_state.aim_bone,
                                     g_state.aim_ads, g_state.aim_hipfire,
                                     radius,
                                     g_state.ignore_teammates,
                                     true,
                                     g_state.aim_smooth,
                                     g_state.esp_bots);
        }
    } else {
        g_aim_frame = {};
    }

}

static void DrawEspOverlay() {
    float sw, sh;
    OverlayScreenSize(sw, sh);

    if (!g_esp_attached.load()) {
        g_nearby_enemy_count = 0;
        g_nearby_teammate_count = 0;
        g_nearby_bot_count = 0;
        return;
    }
    const bool any_skel = g_state.esp_skeleton;
    const bool any_player_esp = g_state.esp_box || g_state.esp_wall ||
                                g_state.esp_name || g_state.esp_hp ||
                                g_state.esp_tracer || g_state.esp_weapon ||
                                any_skel;

    int nearby_enemy_count = 0;
    int nearby_teammate_count = 0;
    int nearby_bot_count = 0;
    std::vector<EspBox>& boxes = FrameBoxes(sw, sh,
                                            &nearby_enemy_count,
                                            &nearby_teammate_count,
                                            &nearby_bot_count);
    g_nearby_enemy_count = std::max(0, std::min(999, nearby_enemy_count));
    g_nearby_teammate_count = std::max(0, std::min(99, nearby_teammate_count));
    g_nearby_bot_count = std::max(0, std::min(99, nearby_bot_count));

    bool any_xvcen = false;
    for (const EspBox& box : boxes) {
        if (box.xvcen_user) { any_xvcen = true; break; }
    }

    if (!any_player_esp && !any_xvcen && !g_state.esp_aim_arrow && !g_state.esp_arrows)
        return;

    std::stable_sort(boxes.begin(), boxes.end(), [](const EspBox& a, const EspBox& b) {
        return a.distance > b.distance;
    });

    auto valid_box = [](const EspBox& box) {
        return std::isfinite(box.x1) && std::isfinite(box.y1) &&
               std::isfinite(box.x2) && std::isfinite(box.y2) &&
               box.x2 > box.x1 && box.y2 > box.y1;
    };

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const ImU32 shadow = IM_COL32(3, 5, 8, 190);
    const float thick = std::max(0.5f, std::min(4.0f, g_state.esp_thick));
    const float edge_margin = ImMax(18.0f, ImMin(sw, sh) * 0.03f);

    AimFrame arrow_target = g_aim_frame;
    if (g_state.esp_aim_arrow && !arrow_target.has_target) {
        const float center_x = sw * 0.5f;
        const float center_y = sh * 0.5f;
        float nearest_to_center = FLT_MAX;
        for (const EspBox& box : boxes) {
            if (!valid_box(box)) continue;
            if (box.health >= 0.0f && box.health <= 0.01f) continue;
            float target_x = (box.x1 + box.x2) * 0.5f;
            float target_y = box.y1;
            float dx = target_x - center_x;
            float dy = target_y - center_y;
            float screen_distance = dx * dx + dy * dy;
            if (!std::isfinite(screen_distance) || screen_distance >= nearest_to_center) continue;
            nearest_to_center = screen_distance;
            arrow_target.has_target = true;
            arrow_target.target_x = target_x;
            arrow_target.target_y = target_y;
        }
    }

    if (g_state.esp_aim_arrow && arrow_target.has_target) {
        ImVec2 from(sw * 0.5f, sh * 0.5f);
        ImVec2 tip(std::max(14.0f, std::min(sw - 14.0f, arrow_target.target_x)),
                   std::max(14.0f, std::min(sh - 14.0f, arrow_target.target_y)));
        float dx = tip.x - from.x, dy = tip.y - from.y;
        float length = sqrtf(dx * dx + dy * dy);
        if (std::isfinite(length)) {
            if (length > 10.0f) {
                float ux = dx / length, uy = dy / length;
                float arrow_len = 9.0f, arrow_half = 4.0f;
                ImVec2 base(tip.x - ux * arrow_len, tip.y - uy * arrow_len);
                ImVec2 left(base.x - uy * arrow_half, base.y + ux * arrow_half);
                ImVec2 right(base.x + uy * arrow_half, base.y - ux * arrow_half);
                dl->AddLine(from, base, shadow, 2.2f);
                dl->AddLine(from, base, IM_COL32(255,255,255,245), 1.0f);
                dl->AddTriangleFilled(tip, left, right, IM_COL32(255,255,255,245));
            } else {
                dl->AddTriangleFilled({tip.x, tip.y - 7.0f},
                                      {tip.x - 5.0f, tip.y + 2.0f},
                                      {tip.x + 5.0f, tip.y + 2.0f},
                                      IM_COL32(255,255,255,245));
            }
        }
    }

    struct ArrowAnim { uint64_t key; float ang; float alpha; };
    static std::vector<ArrowAnim> arrow_anims;
    if (g_state.esp_arrows || g_state.a_esp_arrows > 0.01f) {
        std::vector<OffscreenDir> dirs =
            esp_get_offscreen_dirs((int)sw, (int)sh, g_state.ignore_teammates);
        const float kDt = ImClamp(ImGui::GetIO().DeltaTime, 0.001f, 0.05f);
        const auto smooth = [kDt](float& v, float target, float spd) {
            v += (target - v) * (1.f - expf(-spd * kDt));
        };

        for (const OffscreenDir& d : dirs) {
            if (!std::isfinite(d.radians)) continue;
            ArrowAnim* st = nullptr;
            for (ArrowAnim& a : arrow_anims)
                if (a.key == d.player) { st = &a; break; }
            if (!st) {
                arrow_anims.push_back({d.player, d.radians, 0.0f});
                st = &arrow_anims.back();
            }

            float diff = d.radians - st->ang;
            while (diff >  3.14159265f) diff -= 6.2831853f;
            while (diff < -3.14159265f) diff += 6.2831853f;
            float t = st->ang;
            smooth(t, st->ang + diff, 11.f);
            st->ang = t;
            smooth(st->alpha, 1.f, 9.f);
        }
        const ImVec4 acc = C::Acc();
        const float cx = sw * 0.5f, cy = sh * 0.5f;
        const float ring_r = ImMin(sw, sh) * 0.335f;
        const float base_len = ImMin(sw, sh) * 0.0105f;
        const float master_a = g_state.a_esp_arrows;
        for (size_t i = 0; i < arrow_anims.size();) {
            const OffscreenDir* dir = nullptr;
            for (const OffscreenDir& d : dirs)
                if (d.player == arrow_anims[i].key) { dir = &d; break; }
            if (!dir) {
                smooth(arrow_anims[i].alpha, 0.f, 9.f);
                if (arrow_anims[i].alpha < 0.02f) {
                    arrow_anims[i] = arrow_anims.back();
                    arrow_anims.pop_back();
                } else { ++i; }
                continue;
            }
            const ArrowAnim& an = arrow_anims[i];
            const float ux = sinf(an.ang), uy = -cosf(an.ang);
            const float px2 = -uy, py2 = ux;
            const float a = an.alpha * master_a;
            if (a <= 0.01f) { ++i; continue; }
            const float len = base_len;
            const float bx = cx + ux * ring_r, by = cy + uy * ring_r;
            const bool close_enemy = !dir->teammate && dir->distance <= 50.0f;
            const ImVec4 base = dir->teammate
                ? ImVec4(0.42f, 0.88f, 0.55f, 1.f)
                : (close_enemy ? ImVec4(1.00f, 0.18f, 0.18f, 1.f) : acc);
            const float thick = ImMax(1.6f, len * 0.62f);

            const ImVec2 vtip(bx + ux * len, by + uy * len);
            const ImVec2 vback(bx - ux * len * 0.35f, by - uy * len * 0.35f);
            const ImVec2 wing1(vback.x + px2 * len * 0.85f,
                               vback.y + py2 * len * 0.85f);
            const ImVec2 wing2(vback.x - px2 * len * 0.85f,
                               vback.y - py2 * len * 0.85f);

            const ImU32 halo = IM_COL32((int)(base.x * 255),
                                        (int)(base.y * 255),
                                        (int)(base.z * 255),
                                        (int)(70.f * a));
            dl->AddLine(wing1, vtip, halo, thick * 1.9f);
            dl->AddLine(wing2, vtip, halo, thick * 1.9f);
            dl->AddCircleFilled(vtip, thick * 0.95f, halo, 12);

            const ImU32 col = IM_COL32((int)(base.x * 255),
                                       (int)(base.y * 255),
                                       (int)(base.z * 255),
                                       (int)(255.f * a));
            dl->AddLine(wing1, vtip, col, thick);
            dl->AddLine(wing2, vtip, col, thick);
            dl->AddCircleFilled(vtip, thick * 0.5f, col, 12);
            dl->AddCircleFilled(wing1, thick * 0.5f, col, 12);
            dl->AddCircleFilled(wing2, thick * 0.5f, col, 12);

            {
                ImFont* afn = ImGui::GetFont();
                const float afs = ImClamp(len * 1.35f, 11.0f, 15.0f);
                char dbuf[16];
                snprintf(dbuf, sizeof(dbuf), xv::StrStable(xv::sid::kMi0fm), dir->distance);
                const ImVec2 dtsz = afn->CalcTextSizeA(afs, FLT_MAX, 0.f, dbuf);
                const float gap = dtsz.x * 0.5f + len * 0.35f;
                const float lcx = vtip.x + ux * gap;
                const float lcy = vtip.y + uy * gap;
                const float tx = lcx - dtsz.x * 0.5f;
                const float ty = lcy - dtsz.y * 0.5f;
                const ImU32 tcol = IM_COL32((int)(base.x * 255),
                                           (int)(base.y * 255),
                                           (int)(base.z * 255),
                                           (int)(255.f * a));
                const ImU32 tsh  = IM_COL32(0, 0, 0, (int)(210.f * a));
                DrawTextShadowed(dl, afn, afs, tx, ty, tcol, tsh, dbuf);
            }
            ++i;
        }
    } else if (!arrow_anims.empty()) {
        arrow_anims.clear();
    }

    if (!any_player_esp && !any_xvcen) return;

    if (g_state.esp_tracer) {
        const float tracer_thickness = std::max(0.65f, std::min(2.0f, cfg::esp::tracer_thickness));
        const ImU32 tracer_color = ColU32(cfg::esp::tracer_col);
        for (const EspBox& box : boxes) {
            if (!valid_box(box)) continue;
            if (box.x2 < -edge_margin || box.x1 > sw + edge_margin ||
                box.y2 < -edge_margin || box.y1 > sh + edge_margin)
                continue;
            DrawTracerArrow(dl, {sw * 0.5f, 1.0f},
                            {(box.x1 + box.x2) * 0.5f, box.y1},
                            tracer_color, shadow, tracer_thickness);
        }
    }

    auto draw_centered_text = [&](const char* text, float center_x, float top_y,
                                  ImU32 color, float font_size) {
        if (!text || !*text) return;
        ImFont* font = ImGui::GetFont();
        ImVec2 size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
        float x = center_x - size.x * 0.5f;
        x = std::max(2.0f, std::min(x, sw - size.x - 2.0f));
        float y = std::max(2.0f, std::min(top_y, sh - size.y - 2.0f));
        DrawTextShadowed(dl, font, font_size, x, y, color, shadow, text);
    };

    for (const EspBox& box : boxes) {
        if (!valid_box(box)) continue;
        if (box.x2 < -edge_margin || box.x1 > sw + edge_margin ||
            box.y2 < -edge_margin || box.y1 > sh + edge_margin)
            continue;
        const float center_x = (box.x1 + box.x2) * 0.5f;

        if (any_skel && !box.bones.empty()) {
            const ImU32 skel = ColU32(cfg::esp::skeleton_col);
            const float bone_t = std::max(0.7f, std::min(3.2f, thick));
            for (const EspSkelSeg& seg : box.bones) {
                if (!std::isfinite(seg.x1) || !std::isfinite(seg.y1) ||
                    !std::isfinite(seg.x2) || !std::isfinite(seg.y2)) continue;
                ImVec2 a(seg.x1, seg.y1), b(seg.x2, seg.y2);
                dl->AddLine(a, b, shadow, bone_t + 1.4f);
                dl->AddLine(a, b, skel, bone_t);
            }
        }

        if (g_state.esp_box) {

            const ImU32 box_col = box.teammate
                ? IM_COL32(96, 214, 128, 255) : ColU32(cfg::esp::box_col);
            DrawCornerBox(dl, ImVec2(box.x1, box.y1), ImVec2(box.x2, box.y2),
                          box_col, thick, shadow);
        }

        if (g_state.esp_hp && box.health >= 0.0f && box.max_health > 0.0f) {
            float ratio = std::max(0.0f, std::min(1.0f, box.health / box.max_health));
            const float bar_width = 3.0f;
            float x1 = box.x1 - 7.0f;
            float y1 = box.y1;
            float y2 = box.y2;
            dl->AddRectFilled(ImVec2(x1 - 1.0f, y1 - 1.0f),
                              ImVec2(x1 + bar_width + 1.0f, y2 + 1.0f),
                              IM_COL32(2, 4, 7, 205), 1.0f);
            float fill_y = y2 - (y2 - y1) * ratio;
            ImVec4 low = cfg::esp::hp_min_col;
            ImVec4 high = cfg::esp::hp_max_col;
            ImVec4 hp_color = {
                low.x + (high.x - low.x) * ratio,
                low.y + (high.y - low.y) * ratio,
                low.z + (high.z - low.z) * ratio,
                1.0f
            };
            dl->AddRectFilled(ImVec2(x1, fill_y), ImVec2(x1 + bar_width, y2),
                              ColU32(hp_color), 0.8f);
        }

        const float base_font_size = ImGui::GetFontSize() * 0.62f;
        const float dist = (box.distance > 0.0f) ? box.distance : 20.0f;
        const float dist_scale = ImClamp(1.0f - (dist - 15.0f) * 0.0035f, 0.72f, 1.05f);
        const float name_size = std::max(12.0f, std::min(19.5f, base_font_size * dist_scale));
        const float distance_size = std::max(11.0f, name_size - 1.25f);

        const bool show_name = g_state.esp_name && !box.name.empty();
        if (show_name || box.xvcen_user) {
            ImFont* font = ImGui::GetFont();
            const char* tag_text = xv::StrStable(xv::sid::kMiXvcen);
            const float tag_size = std::max(11.0f, name_size - 1.0f);
            const float tag_gap = 5.0f;
            ImVec2 name_dim = show_name
                ? font->CalcTextSizeA(name_size, FLT_MAX, 0.0f, box.name.c_str())
                : ImVec2(0.0f, 0.0f);
            ImVec2 tag_dim = box.xvcen_user
                ? font->CalcTextSizeA(tag_size, FLT_MAX, 0.0f, tag_text)
                : ImVec2(0.0f, 0.0f);
            const float line_h = std::max(name_dim.y, tag_dim.y);
            const float total_w = name_dim.x + (show_name && box.xvcen_user ? tag_gap : 0.0f) + tag_dim.x;
            float x = center_x - total_w * 0.5f;
            x = std::max(2.0f, std::min(x, sw - total_w - 2.0f));
            const float top_y = std::max(2.0f, std::min(box.y1 - line_h - 3.5f, sh - line_h - 2.0f));
            if (show_name) {
                const ImU32 name_col = box.teammate
                    ? IM_COL32(96, 214, 128, 255) : ColU32(cfg::esp::name_col);
                DrawTextShadowed(dl, font, name_size, x, top_y + (line_h - name_dim.y) * 0.5f,
                                 name_col, shadow, box.name.c_str());
                x += name_dim.x + tag_gap;
            }
            if (box.xvcen_user) {
                const float pulse = 0.82f + 0.18f * sinf((float)ImGui::GetTime() * 4.0f);
                const ImVec4 acc = C::Acc();
                const ImU32 tag_col = IM_COL32((int)(acc.x * 255.f), (int)(acc.y * 255.f),
                                               (int)(acc.z * 255.f), (int)(255.f * pulse));
                const float ty = top_y + (line_h - tag_dim.y) * 0.5f;
                dl->AddText(font, tag_size, ImVec2(x + 0.5f, ty + 0.5f),
                            IM_COL32(0, 120, 255, (int)(60.f * pulse)), tag_text);
                DrawTextShadowed(dl, font, tag_size, x, ty, tag_col, shadow, tag_text);
            }
        }

        float bottom_y = box.y2 + 3.0f;
        if (g_state.esp_wall) {
            char distance_label[32]{};
            if (box.distance >= 0.0f) snprintf(distance_label, sizeof(distance_label), xv::StrStable(xv::sid::kMi0fm), box.distance);
            else snprintf(distance_label, sizeof(distance_label), xv::StrStable(xv::sid::kMiM));
            draw_centered_text(distance_label, center_x, bottom_y,
                               ColU32(cfg::esp::distance_col), distance_size);
            bottom_y += distance_size + 2.0f;
        }

        if (g_state.esp_weapon) {
            const std::string& weapon_text = (g_state.ui_lang != 0 && !box.weapon_name_ru.empty())
                ? box.weapon_name_ru : box.weapon_name;
            if (!weapon_text.empty()) {
                const float weapon_size = std::max(11.0f, name_size - 1.8f);
                draw_centered_text(weapon_text.c_str(), center_x, bottom_y,
                                   ColU32(cfg::esp::weapon_col), weapon_size);
            }
        }
    }
}

static void DrawWorldOverlay() {
    const bool want_bots = g_state.esp_bots;
    const bool want_crates = g_state.esp_crates ||
                             g_state.esp_cupboard || g_state.esp_turret;
    if (!g_esp_attached.load() ||
        (!g_state.esp_animals && !want_crates && !want_bots))
        return;

    float sw, sh;
    OverlayScreenSize(sw, sh);
    std::vector<WorldEspPoint> items = esp_get_world(
        (int)sw, (int)sh, g_state.esp_animals, want_crates, want_bots);


    items.erase(std::remove_if(items.begin(), items.end(),
        [](const WorldEspPoint& it) {
            if (it.kind == WorldKind::Cupboard) return !g_state.esp_cupboard;
            if (it.kind == WorldKind::Turret)   return !g_state.esp_turret;
            if (it.kind == WorldKind::Lootbox ||
                it.kind == WorldKind::EliteBox ||
                it.kind == WorldKind::MilitaryBox ||
                it.kind == WorldKind::ToolBox)
                return !g_state.esp_crates;
            return false;
        }), items.end());
    std::stable_sort(items.begin(), items.end(),
                     [](const WorldEspPoint& a, const WorldEspPoint& b) {
                         return a.distance > b.distance;
                     });

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImFont* font = ImGui::GetFont();
    const float font_size = std::max(15.5f, std::min(18.5f, ImGui::GetFontSize() * 0.61f));

    const float name_size = std::max(16.0f, std::min(19.5f, ImGui::GetFontSize() * 0.62f));
    const ImU32 shadow = IM_COL32(2, 4, 7, 210);
    const ImU32 player_shadow = IM_COL32(3, 5, 8, 190);
    const float thick = std::max(0.5f, std::min(4.0f, g_state.esp_thick));

    auto draw_centered_text = [&](const char* text, float center_x, float top_y,
                                  ImU32 color, float size) {
        if (!text || !*text) return;
        ImVec2 ts = font->CalcTextSizeA(size, FLT_MAX, 0.0f, text);
        float x = center_x - ts.x * 0.5f;
        x = std::max(2.0f, std::min(x, sw - ts.x - 2.0f));
        float y = std::max(2.0f, std::min(top_y, sh - ts.y - 2.0f));
        dl->AddText(font, size, ImVec2(x + 1.0f, y + 1.0f), player_shadow, text);
        const float bold = std::max(0.34f, size * 0.024f);
        dl->AddText(font, size, ImVec2(x - bold * 0.5f, y), color, text);
        dl->AddText(font, size, ImVec2(x + bold * 0.5f, y), color, text);
    };

    for (const WorldEspPoint& item : items) {
        if (!std::isfinite(item.x) || !std::isfinite(item.y) ||
            !std::isfinite(item.distance)) continue;

        const bool is_humanoid = item.kind == WorldKind::Cannibal ||
                                 item.kind == WorldKind::Bot;

        if (is_humanoid) {
            const float margin = ImMax(18.0f, ImMin(sw, sh) * 0.03f);
            if (item.x < -margin || item.x > sw + margin ||
                item.y < -margin || item.y > sh + margin)
                continue;
        }

        const bool is_sized_crate =
            (item.kind == WorldKind::Lootbox ||
             item.kind == WorldKind::EliteBox ||
             item.kind == WorldKind::MilitaryBox ||
             item.kind == WorldKind::ToolBox) &&
            item.height >= 4.0f && item.top_offset >= 0.0f;

        if (is_humanoid || is_sized_crate) {

            const ImU32 humanoid_col = IM_COL32(0, 122, 255, 255);
            float h = 0.0F;
            float top_off = 0.0F;
            if (item.height >= 4.0f && item.top_offset >= 0.0f) {
                h = item.height;
                top_off = item.top_offset;
            } else {
                h = ImClamp(1100.0f / ImMax(item.distance, 1.0f), 18.0f, 260.0f);
                top_off = h * 0.5f;
            }
            h = ImClamp(h, 12.0f, sh * 1.2f);
            const float w = ImMax(2.5f, h * 0.40f);
            const float box_top = item.y - ImClamp(top_off, 0.0f, h);
            const float box_bottom = box_top + h;
            const float box_x1 = item.x - w * 0.5f;
            const float box_x2 = item.x + w * 0.5f;
            const ImU32 kind_col = is_humanoid ? humanoid_col
                                               : ColU32(cfg::esp::box_col);
            DrawCornerBox(dl, {box_x1, box_top}, {box_x2, box_bottom},
                          kind_col, thick, player_shadow);

            const float wdist = (item.distance > 0.0f) ? item.distance : 20.0f;
            const float wscale = ImClamp(1.0f - (wdist - 15.0f) * 0.0035f, 0.72f, 1.05f);
            const float scaled_name_size = std::max(12.0f, name_size * wscale);
            const float scaled_dist_size = std::max(11.0f, scaled_name_size - 1.25f);

            char label[128]{};
            snprintf(label, sizeof(label), "%s", world_kind_label(item.kind));
            draw_centered_text(label, (box_x1 + box_x2) * 0.5f,
                               box_top - scaled_name_size - 3.5f,
                               is_humanoid ? kind_col : ColU32(cfg::esp::name_col),
                               scaled_name_size);
            char meters[32]{};
            snprintf(meters, sizeof(meters), xv::StrStable(xv::sid::kMi0fm), item.distance);
            draw_centered_text(meters, (box_x1 + box_x2) * 0.5f,
                               box_bottom + 3.0f,
                               is_humanoid ? kind_col : ColU32(cfg::esp::distance_col),
                               scaled_dist_size);
            continue;
        }

        ImU32 color;
        switch (item.kind) {
        case WorldKind::Bear:     color = IM_COL32(214,  92,  62, 255); break;
        case WorldKind::Boar:     color = IM_COL32(198, 126,  84, 255); break;
        case WorldKind::Wolf:     color = IM_COL32(178, 186, 199, 255); break;
        case WorldKind::Deer:     color = IM_COL32(226, 170, 106, 255); break;
        case WorldKind::Cannibal:
        case WorldKind::Bot:      color = IM_COL32(  0, 122, 255, 255); break;
        case WorldKind::Rabbit:
        case WorldKind::Hare:     color = IM_COL32(222, 206, 182, 255); break;
        case WorldKind::Chicken:  color = IM_COL32(240, 226, 150, 255); break;
        case WorldKind::Fish:     color = IM_COL32(110, 200, 255, 255); break;
        case WorldKind::Lootbox:  color = IM_COL32(120, 224, 176, 255); break;
        case WorldKind::EliteBox:   color = IM_COL32(196, 122, 255, 255); break;
        case WorldKind::MilitaryBox: color = IM_COL32(120, 190, 100, 255); break;
        case WorldKind::ToolBox:    color = IM_COL32(240, 96, 84, 255); break;
        case WorldKind::Cupboard: color = IM_COL32(255, 150,  60, 255); break;
        case WorldKind::Turret:   color = IM_COL32(255,  70,  70, 255); break;
        default:                  color = IM_COL32(200, 200, 200, 255); break;
        }

        ImVec2 c(item.x, item.y);
        if (world_kind_is_animal(item.kind)) {

            dl->AddCircleFilled(c, 5.4f, shadow, 14);
            dl->AddCircleFilled(c, 4.2f, color, 14);
        } else {

            const float r = 4.4f;
            dl->AddRectFilled({c.x - r - 1.f, c.y - r - 1.f},
                              {c.x + r + 1.f, c.y + r + 1.f}, shadow, 1.5f);
            dl->AddRectFilled({c.x - r, c.y - r}, {c.x + r, c.y + r}, color, 1.5f);
        }

        char label[128]{};

        snprintf(label, sizeof(label), g_Lang->dist_fmt,
                 world_kind_label(item.kind), item.distance);
        ImVec2 size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, label);
        float x = std::max(2.0f, std::min(c.x - size.x * 0.5f, sw - size.x - 2.0f));
        float y = std::max(2.0f, std::min(c.y + 8.0f, sh - size.y - 2.0f));
        DrawTextShadowed(dl, font, font_size, x, y, color, shadow, label);

    }
}

static void DrawOreOverlay() {
    if (!g_esp_attached.load() ||
        (!g_state.ore_sulfur && !g_state.ore_iron &&
         !g_state.ore_stone && !g_state.ore_tree))
        return;

    float sw, sh;
    OverlayScreenSize(sw, sh);
    std::vector<OreEspPoint> ores = esp_get_ores(
        (int)sw, (int)sh,
        g_state.ore_sulfur, g_state.ore_iron, g_state.ore_stone,
        g_state.ore_tree);
    std::stable_sort(ores.begin(), ores.end(), [](const OreEspPoint& a, const OreEspPoint& b) {
        return a.distance > b.distance;
    });
    if (ores.size() > 220) ores.erase(ores.begin(), ores.end() - 220);

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImFont* font = ImGui::GetFont();
    const float font_size = std::max(15.5f, std::min(18.5f, ImGui::GetFontSize() * 0.61f));
    const ImU32 shadow = IM_COL32(2, 4, 7, 210);

    for (const OreEspPoint& ore : ores) {
        if (!std::isfinite(ore.x) || !std::isfinite(ore.y) ||
            !std::isfinite(ore.distance)) continue;
        const char* name = g_Lang->ore_stone_name;
        ImU32 color = IM_COL32(158, 164, 171, 255);
        if (ore.kind == OreKind::Sulfur) {
            name = g_Lang->ore_sulfur_name;
            color = IM_COL32(255, 188, 28, 255);
        } else if (ore.kind == OreKind::Iron) {
            name = g_Lang->ore_iron_name;
            color = IM_COL32(190, 108, 72, 255);
        } else if (ore.kind == OreKind::Tree) {
            name = g_Lang->ore_tree_name;
            color = IM_COL32(96, 200, 106, 255);
        }

        ImVec2 center(ore.x, ore.y);
        const float r = 5.0f;
        dl->AddQuadFilled({center.x, center.y - r - 1.0f},
                          {center.x + r + 1.0f, center.y},
                          {center.x, center.y + r + 1.0f},
                          {center.x - r - 1.0f, center.y}, shadow);
        dl->AddQuadFilled({center.x, center.y - r},
                          {center.x + r, center.y},
                          {center.x, center.y + r},
                          {center.x - r, center.y}, color);

        char label[64]{};
        snprintf(label, sizeof(label), g_Lang->dist_fmt, name, ore.distance);
        ImVec2 size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, label);
        float x = std::max(2.0f, std::min(center.x - size.x * 0.5f, sw - size.x - 2.0f));
        float y = std::max(2.0f, std::min(center.y + 8.0f, sh - size.y - 2.0f));
        DrawTextShadowed(dl, font, font_size, x, y, color, shadow, label);
    }
}

static constexpr int  kMaxConfigs  = 64;
static constexpr int  kMaxSavedConfigs = 12;
static constexpr uint8_t kXorKey   = 0xA7;

#define kCfgDir xv::StrStable(xv::sid::kCfgDir)

struct ConfigEntry { char name[64] = {}; };
static ConfigEntry g_configs[kMaxConfigs] = {};
static int         g_configCount    = 0;
static int         g_configToDelete = -1;
static char        g_loadedConfigName[64] = {};
static float       g_cfgLoadAnim[kMaxConfigs] = {};
static int         g_cfgLoadedIdx = -1;

static std::string CfgPath(const char* name) {
    if (!name || !name[0]) return std::string();
    return std::string(kCfgDir) + name + xv::StrStable(xv::sid::kMiCfg);
}

static void ConfigLoad(int idx);

static void CfgRememberLast(const char* name) {
    if (!name || !name[0]) return;
    xvstate::Write(xvstate::kLastCfg, reinterpret_cast<const unsigned char*>(name), std::strlen(name));
}

static void CfgRestoreLast() {
    std::vector<unsigned char> blob;
    if (!xvstate::Read(xvstate::kLastCfg, blob) || blob.empty()) return;
    std::string name(reinterpret_cast<const char*>(blob.data()), blob.size());
    if (name.empty()) return;
    for (int i = 0; i < g_configCount; i++) {
        if (name == g_configs[i].name) { ConfigLoad(i); return; }
    }
    xvstate::Erase(xvstate::kLastCfg);
}

static void XorBuf(uint8_t* buf, size_t sz) {
    for (size_t i = 0; i < sz; i++) buf[i] ^= (kXorKey ^ (uint8_t)(i * 0x1D + 0x3B));
}

static void CfgScanDir() {
    mkdir(kCfgDir, 0777);
    g_configCount = 0;
    DIR* d = opendir(kCfgDir);
    if (!d) return;
    struct dirent* e;
    std::vector<std::string> names;
    while ((e = readdir(d)) != nullptr) {
        std::string fn = e->d_name;
        if (fn.size() <= 4 || fn.substr(fn.size() - 4) != xv::StrStable(xv::sid::kMiCfg))
            continue;
        if (fn[0] == '.') continue;
        if (fn.size() >= 64) continue;
        std::string full = std::string(kCfgDir) + fn;
        struct stat st{};
        if (stat(full.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) continue;
        if (st.st_size < (off_t)(sizeof(uint32_t) * 2)) continue;
        names.push_back(fn.substr(0, fn.size() - 4));
    }
    closedir(d);

    std::sort(names.begin(), names.end(), [](const std::string& a, const std::string& b) {
        auto num = [](const std::string& s) -> long {
            size_t p = s.find_last_not_of(xv::StrStable(xv::sid::kMi0123456789));
            if (p == std::string::npos || p + 1 >= s.size()) return -1;
            return strtol(s.c_str() + p + 1, nullptr, 10);
        };
        long na = num(a), nb = num(b);
        if (na != nb) return na < nb;
        return a < b;
    });
    for (auto& n : names) {
        if (g_configCount >= kMaxConfigs) break;
        snprintf(g_configs[g_configCount++].name, 64, "%s", n.c_str());
    }
}

static int g_inotifyFd  = -1;
static int g_inotifyWd  = -1;

static void CfgWatchInit() {
    g_inotifyFd = inotify_init1(IN_NONBLOCK);
    if (g_inotifyFd < 0) return;
    mkdir(kCfgDir, 0777);
    g_inotifyWd = inotify_add_watch(g_inotifyFd, kCfgDir,
        IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO | IN_MODIFY);
}

static void CfgWatchFree() {
    if (g_inotifyFd >= 0) {
        if (g_inotifyWd >= 0) inotify_rm_watch(g_inotifyFd, g_inotifyWd);
        close(g_inotifyFd);
        g_inotifyFd = -1;
        g_inotifyWd = -1;
    }
}

static void CfgWatchTick() {
    if (g_inotifyFd < 0) return;
    char buf[512];
    ssize_t n = read(g_inotifyFd, buf, sizeof(buf));
    if (n > 0) CfgScanDir();
}

struct CfgBlob {
    bool  aim_touch, aim_mode_test;
    int   aim_bone;
    bool  aim_ads, aim_hipfire;
    bool  esp_box, esp_name, esp_hp, esp_wall;
    bool  esp_tracer, esp_skeleton, esp_aim_arrow;
    float esp_thick;
    float gun_str, gun_fov;
    bool  ui_fps, ui_dark_mode, ui_show_sep, ui_lang;
    ImVec4 esp_box_col, esp_name_col, esp_distance_col;
    ImVec4 esp_tracer_col, skeleton_col;
    bool ore_sulfur, ore_iron, ore_stone;
    bool memory_no_recoil, memory_no_spread, memory_hands_fov, memory_black_sky;
    bool memory_aspect;
    bool esp_animals, esp_crates, ignore_teammates, esp_bots;
    bool  fire_zone_set;
    float fire_zone_x, fire_zone_y;
    bool  esp_arrows;
    bool  af_sulfur, af_iron, af_stone;
    float af_range, af_swing_ms;
    bool  joy_zone_set;
    float joy_zone_x, joy_zone_y;
    bool  crosshair_custom;
    float crosshair_size;
    bool  esp_weapon;
    ImVec4 esp_weapon_col;
    bool  esp_cupboard;
    bool  esp_turret;
    bool  memory_always_day;
    bool  ore_tree;
    bool  af_tree;
    bool  memory_xray;
    float xray_distance;
    bool  freecam_bind;
    float freecam_pos_x, freecam_pos_y;
    bool  rs_zone_set;
    float rs_zone_x, rs_zone_y;
    float hands_fov_value;
    float aspect_value;
    bool   ui_accent_custom;
    ImVec4 ui_custom_accent_col;
    float  freecam_speed;
    bool  aim_zone_enabled;
    float aim_zone_x, aim_zone_y, aim_zone_w, aim_zone_h;
};

static constexpr uint32_t kCfgMagic       = 0x32564358U;
static constexpr uint32_t kCfgLegacyMagic = 0x58564345U;
static constexpr size_t   kCfgLegacySize  = 288;

enum CfgType : uint8_t {
    CFG_BOOL, CFG_INT, CFG_FLOAT, CFG_COLOR, CFG_SKIP1, CFG_SKIP16
};

struct CfgFieldSpec {
    const char* name;
    size_t      offset;
    uint8_t     type;
};

struct CfgLegacyField {
    uint16_t offset;
    uint8_t  type;
};

#define CFG_B(nm) { #nm, offsetof(CfgBlob, nm), CFG_BOOL }
#define CFG_I(nm) { #nm, offsetof(CfgBlob, nm), CFG_INT }
#define CFG_F(nm) { #nm, offsetof(CfgBlob, nm), CFG_FLOAT }
#define CFG_C(nm) { #nm, offsetof(CfgBlob, nm), CFG_COLOR }

static const CfgFieldSpec kCfgFields[] = {
    CFG_B(aim_touch), CFG_B(aim_mode_test), CFG_I(aim_bone), CFG_B(aim_ads),
    CFG_B(aim_hipfire), CFG_B(esp_box), CFG_B(esp_name), CFG_B(esp_hp),
    CFG_B(esp_wall), CFG_B(esp_tracer), CFG_B(esp_skeleton), CFG_B(esp_aim_arrow),
    CFG_F(esp_thick), CFG_F(gun_str), CFG_F(gun_fov), CFG_B(ui_fps),
    CFG_B(ui_dark_mode), CFG_B(ui_show_sep), CFG_B(ui_lang), CFG_C(esp_box_col),
    CFG_C(esp_name_col), CFG_C(esp_distance_col), CFG_C(esp_tracer_col), CFG_C(skeleton_col),
    CFG_B(ore_sulfur), CFG_B(ore_iron), CFG_B(ore_stone), CFG_B(memory_no_recoil),
    CFG_B(memory_no_spread), CFG_B(memory_hands_fov), CFG_B(memory_black_sky), CFG_B(esp_animals),
    CFG_B(esp_crates), CFG_B(ignore_teammates), CFG_B(esp_bots), CFG_B(fire_zone_set),
    CFG_F(fire_zone_x), CFG_F(fire_zone_y), CFG_B(esp_arrows), CFG_B(af_sulfur),
    CFG_B(af_iron), CFG_B(af_stone), CFG_F(af_range), CFG_F(af_swing_ms),
    CFG_B(joy_zone_set), CFG_F(joy_zone_x), CFG_F(joy_zone_y), CFG_B(crosshair_custom),
    CFG_F(crosshair_size), CFG_B(esp_weapon), CFG_C(esp_weapon_col), CFG_B(esp_cupboard),
    CFG_B(esp_turret), CFG_B(memory_always_day), CFG_B(ore_tree), CFG_B(af_tree),
    CFG_B(memory_xray), CFG_F(xray_distance), CFG_B(freecam_bind), CFG_F(freecam_pos_x),
    CFG_F(freecam_pos_y), CFG_B(rs_zone_set), CFG_F(rs_zone_x), CFG_F(rs_zone_y),
    CFG_F(hands_fov_value), CFG_B(memory_aspect), CFG_F(aspect_value), CFG_B(ui_accent_custom),
    CFG_C(ui_custom_accent_col), CFG_F(freecam_speed),
    CFG_B(aim_zone_enabled), CFG_F(aim_zone_x), CFG_F(aim_zone_y),
    CFG_F(aim_zone_w), CFG_F(aim_zone_h),
};
static constexpr size_t kCfgFieldCount = sizeof(kCfgFields) / sizeof(kCfgFields[0]);

static const CfgLegacyField kCfgLegacy[] = {
    {8, CFG_BOOL}, {9, CFG_BOOL}, {12, CFG_INT}, {16, CFG_BOOL}, {17, CFG_BOOL}, {18, CFG_BOOL},
    {19, CFG_BOOL}, {20, CFG_BOOL}, {21, CFG_BOOL}, {22, CFG_BOOL}, {23, CFG_BOOL}, {24, CFG_BOOL},
    {28, CFG_FLOAT}, {32, CFG_FLOAT}, {36, CFG_FLOAT}, {40, CFG_BOOL}, {41, CFG_BOOL}, {42, CFG_BOOL},
    {43, CFG_BOOL}, {44, CFG_COLOR}, {60, CFG_COLOR}, {76, CFG_COLOR}, {92, CFG_COLOR}, {108, CFG_COLOR},
    {124, CFG_BOOL}, {125, CFG_BOOL}, {126, CFG_BOOL}, {127, CFG_SKIP1}, {128, CFG_BOOL}, {129, CFG_BOOL},
    {130, CFG_BOOL}, {131, CFG_BOOL}, {133, CFG_BOOL}, {134, CFG_BOOL}, {135, CFG_BOOL}, {136, CFG_BOOL},
    {137, CFG_SKIP1}, {138, CFG_BOOL}, {140, CFG_FLOAT}, {144, CFG_FLOAT}, {148, CFG_SKIP1}, {149, CFG_BOOL},
    {150, CFG_SKIP1}, {152, CFG_SKIP16}, {168, CFG_BOOL}, {169, CFG_BOOL}, {170, CFG_BOOL}, {172, CFG_FLOAT},
    {176, CFG_FLOAT}, {180, CFG_BOOL}, {184, CFG_FLOAT}, {188, CFG_FLOAT}, {192, CFG_BOOL}, {196, CFG_FLOAT},
    {200, CFG_BOOL}, {204, CFG_COLOR}, {220, CFG_BOOL}, {221, CFG_BOOL}, {222, CFG_BOOL}, {223, CFG_BOOL},
    {224, CFG_BOOL}, {225, CFG_BOOL}, {228, CFG_FLOAT}, {232, CFG_BOOL}, {236, CFG_FLOAT}, {240, CFG_FLOAT},
    {244, CFG_BOOL}, {248, CFG_FLOAT}, {252, CFG_FLOAT}, {256, CFG_FLOAT}, {132, CFG_BOOL}, {260, CFG_FLOAT},
    {264, CFG_BOOL}, {268, CFG_COLOR}, {284, CFG_FLOAT},
};
static constexpr size_t kCfgLegacyFieldCount = sizeof(kCfgLegacy) / sizeof(kCfgLegacy[0]);

#undef CFG_B
#undef CFG_I
#undef CFG_F
#undef CFG_C

static size_t CfgTypeSize(uint8_t type) {
    switch (type) {
        case CFG_BOOL:   return 1;
        case CFG_INT:
        case CFG_FLOAT:  return 4;
        case CFG_COLOR:  return sizeof(ImVec4);
        case CFG_SKIP1:  return 1;
        case CFG_SKIP16: return sizeof(ImVec4);
    }
    return 0;
}

static const CfgFieldSpec* CfgFindField(const char* name, size_t len) {
    for (const CfgFieldSpec& f : kCfgFields) {
        if (strlen(f.name) == len && memcmp(f.name, name, len) == 0) return &f;
    }
    return nullptr;
}

static void CfgEncode(const CfgBlob& s, std::vector<uint8_t>& out) {
    out.clear();
    out.reserve(kCfgFieldCount * 12 + 4);
    const uint8_t* magic = (const uint8_t*)&kCfgMagic;
    out.insert(out.end(), magic, magic + sizeof(kCfgMagic));
    for (const CfgFieldSpec& f : kCfgFields) {
        const uint8_t name_len = (uint8_t)strlen(f.name);
        out.push_back(name_len);
        out.insert(out.end(), f.name, f.name + name_len);
        out.push_back(f.type);
        const uint8_t* value = (const uint8_t*)&s + f.offset;
        out.insert(out.end(), value, value + CfgTypeSize(f.type));
    }
}

static void CfgFillDefaults(CfgBlob& s) {
    s = {};
    s.aim_ads = true;
    s.aim_hipfire = true;
    s.esp_thick = 1.5f;
    s.gun_fov = 60.f;
    s.gun_str = 5.f;
    s.ui_fps = false;
    s.freecam_bind = true;
    s.freecam_pos_x = 0.90f;
    s.freecam_pos_y = 0.40f;
    s.crosshair_size = 14.f;
    s.esp_box_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.esp_name_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.esp_distance_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.esp_tracer_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.skeleton_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.esp_weapon_col = {1.00f, 1.00f, 1.00f, 1.f};
    s.af_sulfur = true;
    s.af_iron = true;
    s.af_stone = true;
    s.af_range = 150.f;
    s.af_swing_ms = 350.f;
    s.fire_zone_x = 0.82f;
    s.fire_zone_y = 0.60f;
    s.joy_zone_x = 0.13f;
    s.joy_zone_y = 0.84f;
    s.af_tree = true;
    s.xray_distance = 0.1f;
    s.memory_hands_fov = false;
    s.hands_fov_value = 70.f;
    s.memory_aspect = false;
    s.aspect_value = 2.00f;
    s.rs_zone_x = 0.50f;
    s.rs_zone_y = 0.73f;
    s.ui_accent_custom = false;
    s.ui_custom_accent_col = {0.039f, 0.518f, 1.000f, 1.0f};
    s.freecam_speed = 12.f;
    s.aim_zone_x = 0.72f;
    s.aim_zone_y = 0.45f;
    s.aim_zone_w = 0.04f;
    s.aim_zone_h = 0.07f;
}

static bool CfgDecodeLegacy(const uint8_t* raw, size_t raw_len, CfgBlob& out) {
    if (raw_len < kCfgLegacySize) return false;
    size_t field = 0;
    for (const CfgLegacyField& lf : kCfgLegacy) {
        const size_t sz = CfgTypeSize(lf.type);
        if (!sz || (size_t)lf.offset + sz > raw_len) return false;
        if (lf.type == CFG_SKIP1 || lf.type == CFG_SKIP16) continue;
        if (field >= kCfgFieldCount || CfgTypeSize(kCfgFields[field].type) != sz)
            return false;
        memcpy((uint8_t*)&out + kCfgFields[field].offset, raw + lf.offset, sz);
        ++field;
    }
    return field == kCfgLegacyFieldCount;
}

static bool CfgDecode(const uint8_t* raw, size_t raw_len, CfgBlob& out) {
    CfgFillDefaults(out);
    if (raw_len < sizeof(uint32_t)) return false;
    uint32_t magic = 0;
    memcpy(&magic, raw, sizeof(magic));
    if (magic == kCfgLegacyMagic) return CfgDecodeLegacy(raw, raw_len, out);
    if (magic != kCfgMagic) return false;
    size_t pos = sizeof(magic);
    while (pos < raw_len) {
        const uint8_t name_len = raw[pos++];
        if (!name_len || pos + name_len + 1 > raw_len) return false;
        const CfgFieldSpec* f = CfgFindField((const char*)raw + pos, name_len);
        pos += name_len;
        const uint8_t type = raw[pos++];
        const size_t sz = CfgTypeSize(type);
        if (!sz || pos + sz > raw_len) return false;
        if (f && f->type == type) memcpy((uint8_t*)&out + f->offset, raw + pos, sz);
        pos += sz;
    }
    return true;
}

static ImVec4 CfgColorOr(const ImVec4& c, const ImVec4& fallback) {
    if (!std::isfinite(c.x) || !std::isfinite(c.y) || !std::isfinite(c.z) || !std::isfinite(c.w))
        return fallback;
    if (c.w <= 0.01f) return fallback;
    return {
        ImClamp(c.x, 0.f, 1.f),
        ImClamp(c.y, 0.f, 1.f),
        ImClamp(c.z, 0.f, 1.f),
        ImClamp(c.w, 0.f, 1.f)
    };
}

static bool ConfigSaveToPath(const std::string& path) {
    CfgBlob s;
    CfgFillDefaults(s);
    s.aim_touch = g_state.aim_touch;
    s.aim_mode_test = g_state.aim_mode_test;
    s.aim_bone    = g_state.aim_bone;
    s.aim_ads     = g_state.aim_ads;
    s.aim_hipfire = g_state.aim_hipfire;
    s.esp_box       = g_state.esp_box;       s.esp_name      = g_state.esp_name;
    s.esp_hp        = g_state.esp_hp;        s.esp_wall      = g_state.esp_wall;
    s.esp_tracer    = g_state.esp_tracer;
    s.esp_skeleton = g_state.esp_skeleton;
    s.memory_black_sky = g_state.memory_black_sky;
    s.esp_aim_arrow = g_state.esp_aim_arrow;
    s.esp_thick     = g_state.esp_thick;
    s.gun_fov     = g_state.gun_fov;
    s.gun_str     = g_state.aim_smooth;
    s.ui_fps      = g_state.ui_fps;      s.ui_dark_mode= g_state.ui_dark_mode;
    s.ui_show_sep = g_state.ui_show_sep; s.ui_lang = g_state.ui_lang == 1;
    s.esp_box_col          = cfg::esp::box_col;
    s.esp_name_col         = cfg::esp::name_col;
    s.esp_distance_col     = cfg::esp::distance_col;
    s.esp_tracer_col       = cfg::esp::tracer_col;
    s.skeleton_col = cfg::esp::skeleton_col;
    s.ore_sulfur = g_state.ore_sulfur;
    s.ore_iron   = g_state.ore_iron;
    s.ore_stone  = g_state.ore_stone;
    s.memory_no_recoil = g_state.memory_no_recoil;
    s.memory_no_spread = g_state.memory_no_spread;
    s.memory_hands_fov = g_state.memory_hands_fov;
    s.hands_fov_value  = g_state.hands_fov_value;
    s.memory_aspect    = g_state.memory_aspect;
    s.aspect_value     = g_state.aspect_value;
    s.esp_animals      = g_state.esp_animals;
    s.esp_crates       = g_state.esp_crates;
    s.ignore_teammates = g_state.ignore_teammates;
    s.esp_bots         = g_state.esp_bots;
    s.fire_zone_set    = g_state.fire_zone_set;
    s.fire_zone_x      = g_state.fire_zone_x;
    s.fire_zone_y      = g_state.fire_zone_y;
    s.esp_arrows       = g_state.esp_arrows;
    s.af_sulfur   = g_state.af_sulfur;
    s.af_iron     = g_state.af_iron;
    s.af_stone    = g_state.af_stone;
    s.af_range    = g_state.af_range;
    s.af_swing_ms = g_state.af_swing_ms;
    s.joy_zone_set = g_state.joy_zone_set;
    s.joy_zone_x   = g_state.joy_zone_x;
    s.joy_zone_y   = g_state.joy_zone_y;
    s.crosshair_custom = g_state.crosshair_custom;
    s.crosshair_size   = g_state.crosshair_size;
    s.esp_weapon       = g_state.esp_weapon;
    s.esp_weapon_col   = cfg::esp::weapon_col;
    s.esp_cupboard     = g_state.esp_cupboard;
    s.esp_turret       = g_state.esp_turret;
    s.memory_always_day = g_state.memory_always_day;
    s.ore_tree = g_state.ore_tree;
    s.af_tree  = g_state.af_tree;
    s.memory_xray = g_state.memory_xray;
    s.xray_distance = g_state.xray_distance;
    s.freecam_bind = g_state.freecam_bind;
    s.freecam_pos_x = g_state.fc_bind_x;
    s.freecam_pos_y = g_state.fc_bind_y;
    s.freecam_speed = g_state.freecam_speed;
    s.rs_zone_set = g_state.rs_zone_set;
    s.rs_zone_x   = g_state.rs_zone_x;
    s.rs_zone_y   = g_state.rs_zone_y;
    s.ui_accent_custom = g_state.ui_accent_custom;
    s.ui_custom_accent_col = g_state.ui_custom_accent_col;
    s.aim_zone_enabled = g_state.aim_zone_enabled;
    s.aim_zone_x = g_state.aim_zone_x;
    s.aim_zone_y = g_state.aim_zone_y;
    s.aim_zone_w = g_state.aim_zone_w;
    s.aim_zone_h = g_state.aim_zone_h;
    std::vector<uint8_t> buf;
    CfgEncode(s, buf);
    XorBuf(buf.data(), buf.size());
    mkdir(kCfgDir, 0777);
    std::string tmp = path + xv::StrStable(xv::sid::kMiTmp);
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write((char*)buf.data(), (std::streamsize)buf.size());
    f.flush();
    bool ok = f.good();
    f.close();
    if (!ok) {
        remove(tmp.c_str());
        return false;
    }
    if (rename(tmp.c_str(), path.c_str()) != 0) {
        remove(path.c_str());
        if (rename(tmp.c_str(), path.c_str()) != 0) {
            remove(tmp.c_str());
            return false;
        }
    }
    return true;
}

static void ConfigSave() {
    mkdir(kCfgDir, 0777);

    if (g_configCount >= kMaxSavedConfigs) {
        ShowToast(g_Lang->toast_cfg_limit);
        PlaySound(SND_CLICK);
        return;
    }

    int idx = 1;
    char baseName[64];
    std::string cfgpath;
    do {
        snprintf(baseName, sizeof(baseName), xv::StrStable(xv::sid::kMiConfigD), idx++);
        cfgpath = CfgPath(baseName);
    } while (access(cfgpath.c_str(), F_OK) == 0);
    if (!ConfigSaveToPath(cfgpath)) {
        ShowToast(g_Lang->toast_cfg_bad);
        PlaySound(SND_CLICK);
        return;
    }
    CfgScanDir();
    ShowToast(g_Lang->toast_cfg_created);
    PlaySound(SND_SUCCESS);
}

static void ConfigUpdate(int idx) {
    if (idx < 0 || idx >= g_configCount) return;
    std::string path = CfgPath(g_configs[idx].name);
    if (!ConfigSaveToPath(path)) {
        ShowToast(g_Lang->toast_cfg_bad);
        PlaySound(SND_CLICK);
        return;
    }
    ShowToast(g_Lang->toast_cfg_saved);
    PlaySound(SND_SUCCESS);
}

static void ConfigLoad(int idx) {
    if (idx < 0 || idx >= g_configCount) return;
    std::string path = CfgPath(g_configs[idx].name);
    std::ifstream f(path, std::ios::binary);
    if (!f) { ShowToast(g_Lang->toast_cfg_not_found); return; }
    std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    f.close();
    size_t got = raw.size();
    if (got < sizeof(uint32_t) * 2) { ShowToast(g_Lang->toast_cfg_bad); return; }
    XorBuf(raw.data(), got);
    CfgBlob s;
    if (!CfgDecode(raw.data(), got, s)) { ShowToast(g_Lang->toast_cfg_bad); return; }
    g_state.aim_touch = s.aim_touch;
    g_state.aim_mode_test = s.aim_mode_test;
    g_state.aim_bone = std::max(0, std::min(2, s.aim_bone));
    g_state.aim_ads     = s.aim_ads;
    g_state.aim_hipfire = s.aim_hipfire;
    if (!g_state.aim_ads && !g_state.aim_hipfire) g_state.aim_hipfire = true;
    g_state.esp_box       = s.esp_box;       g_state.esp_name      = s.esp_name;
    g_state.esp_hp        = s.esp_hp;        g_state.esp_wall      = s.esp_wall;
    g_state.esp_tracer    = s.esp_tracer;
    g_state.esp_skeleton  = s.esp_skeleton;
    g_state.esp_aim_arrow = s.esp_aim_arrow;
    g_state.ore_sulfur = s.ore_sulfur;
    g_state.ore_iron   = s.ore_iron;
    g_state.ore_stone  = s.ore_stone;
    g_state.memory_no_recoil = s.memory_no_recoil;
    g_state.memory_no_spread = s.memory_no_spread;
    g_state.memory_hands_fov = s.memory_hands_fov;
    g_state.hands_fov_value = std::isfinite(s.hands_fov_value)
        ? ImClamp(roundf(s.hands_fov_value), 20.f, 120.f) : 70.f;
    g_state.memory_aspect = s.memory_aspect;
    g_state.aspect_value = std::isfinite(s.aspect_value)
        ? ImClamp(s.aspect_value, 0.30f, 5.00f) : 2.00f;
    g_state.memory_black_sky = s.memory_black_sky;
    g_state.esp_animals      = s.esp_animals;
    g_state.esp_crates       = s.esp_crates;
    g_state.ignore_teammates = s.ignore_teammates;
    g_state.esp_bots         = s.esp_bots;
    {
        const bool zone_ok = s.fire_zone_set &&
            std::isfinite(s.fire_zone_x) && std::isfinite(s.fire_zone_y) &&
            s.fire_zone_x >= 0.02f && s.fire_zone_x <= 0.98f &&
            s.fire_zone_y >= 0.02f && s.fire_zone_y <= 0.98f;
        g_state.fire_zone_set = zone_ok;
        if (zone_ok) {
            g_state.fire_zone_x = s.fire_zone_x;
            g_state.fire_zone_y = s.fire_zone_y;
        }
    }
    g_state.esp_arrows    = s.esp_arrows;
    g_state.af_sulfur = s.af_sulfur;
    g_state.af_iron   = s.af_iron;
    g_state.af_stone  = s.af_stone;
    g_state.af_range  = std::isfinite(s.af_range)
        ? ImClamp(roundf(s.af_range), 25.f, 300.f) : 150.f;
    g_state.af_swing_ms = std::isfinite(s.af_swing_ms)
        ? ImClamp(roundf(s.af_swing_ms), 150.f, 900.f) : 350.f;
    {
        const bool joy_ok = s.joy_zone_set &&
            std::isfinite(s.joy_zone_x) && std::isfinite(s.joy_zone_y) &&
            s.joy_zone_x >= 0.02f && s.joy_zone_x <= 0.98f &&
            s.joy_zone_y >= 0.02f && s.joy_zone_y <= 0.98f;
        const bool rs_ok = s.rs_zone_set &&
            std::isfinite(s.rs_zone_x) && std::isfinite(s.rs_zone_y) &&
            s.rs_zone_x >= 0.02f && s.rs_zone_x <= 0.98f &&
            s.rs_zone_y >= 0.02f && s.rs_zone_y <= 0.98f;
        g_state.rs_zone_set = rs_ok;
        if (rs_ok) {
            g_state.rs_zone_x = s.rs_zone_x;
            g_state.rs_zone_y = s.rs_zone_y;
        }
        g_state.joy_zone_set = joy_ok;
        if (joy_ok) {
            g_state.joy_zone_x = s.joy_zone_x;
            g_state.joy_zone_y = s.joy_zone_y;
        }
    }
    g_state.esp_thick     = std::isfinite(s.esp_thick)
        ? ImClamp(s.esp_thick, 0.5f, 4.f) : 1.5f;
    g_state.gun_fov = std::isfinite(s.gun_fov)
        ? ImClamp(roundf(s.gun_fov), 10.f, 360.f) : 60.f;
    g_state.aim_smooth = std::isfinite(s.gun_str)
        ? ImClamp(roundf(s.gun_str), 0.f, 10.f) : 5.f;
    g_state.crosshair_custom = s.crosshair_custom;
    g_state.crosshair_size = std::isfinite(s.crosshair_size)
        ? ImClamp(roundf(s.crosshair_size), 6.f, 48.f) : 14.f;
    g_state.esp_weapon = s.esp_weapon;
    g_state.ui_fps      = s.ui_fps;      g_state.ui_dark_mode= s.ui_dark_mode;
    g_state.ui_show_sep = s.ui_show_sep;
    g_state.ui_lang = s.ui_lang ? 1 : 0;
    g_Lang = g_state.ui_lang ? &LANG_RU : &LANG_EN;
    cfg::esp::box_col      = CfgColorOr(s.esp_box_col, {1.00f, 1.00f, 1.00f, 1.f});
    cfg::esp::name_col     = CfgColorOr(s.esp_name_col, {1.00f, 1.00f, 1.00f, 1.f});
    cfg::esp::distance_col = CfgColorOr(s.esp_distance_col, {1.00f, 1.00f, 1.00f, 1.f});
    cfg::esp::tracer_col   = CfgColorOr(s.esp_tracer_col, {1.00f, 1.00f, 1.00f, 1.f});
    cfg::esp::skeleton_col = CfgColorOr(s.skeleton_col, {1.00f, 1.00f, 1.00f, 1.f});
    cfg::esp::weapon_col   = CfgColorOr(s.esp_weapon_col, {1.00f, 1.00f, 1.00f, 1.f});
    g_state.esp_cupboard    = s.esp_cupboard;
    g_state.esp_turret      = s.esp_turret;
    g_state.memory_always_day = s.memory_always_day;
    g_state.ore_tree = s.ore_tree;
    g_state.af_tree  = s.af_tree;
    g_state.memory_xray = s.memory_xray;
    g_state.xray_distance = std::isfinite(s.xray_distance)
        ? std::clamp(s.xray_distance, 0.1f, 100.f) : 0.1f;
    g_state.fc_bind_x = std::isfinite(s.freecam_pos_x)
        ? std::clamp(s.freecam_pos_x, 0.02f, 0.98f) : 0.90f;
    g_state.fc_bind_y = std::isfinite(s.freecam_pos_y)
        ? std::clamp(s.freecam_pos_y, 0.02f, 0.98f) : 0.40f;
    g_state.freecam_bind = s.freecam_bind;
    g_state.freecam_speed = std::isfinite(s.freecam_speed)
        ? ImClamp(roundf(s.freecam_speed), 1.f, 40.f) : 12.f;
    g_state.ui_accent_custom = s.ui_accent_custom;
    g_state.ui_custom_accent_col = CfgColorOr(s.ui_custom_accent_col, {0.039f, 0.518f, 1.000f, 1.0f});
    g_state.aim_zone_enabled = s.aim_zone_enabled;
    g_state.aim_zone_x = std::isfinite(s.aim_zone_x)
        ? std::clamp(s.aim_zone_x, 0.05f, 0.95f) : 0.72f;
    g_state.aim_zone_y = std::isfinite(s.aim_zone_y)
        ? std::clamp(s.aim_zone_y, 0.05f, 0.95f) : 0.45f;
    g_state.aim_zone_w = std::isfinite(s.aim_zone_w)
        ? std::clamp(s.aim_zone_w, 0.02f, 0.15f) : 0.05f;
    g_state.aim_zone_h = std::isfinite(s.aim_zone_h)
        ? std::clamp(s.aim_zone_h, 0.02f, 0.20f) : 0.07f;
    g_darkTheme = g_state.ui_dark_mode;
    g_state.a_aim_touch = g_state.aim_touch ? 1.f : 0.f;
    g_state.a_aim_zone = g_state.aim_zone_enabled ? 1.f : 0.f;
    g_state.a_aim_zone_show = g_state.a_aim_zone;
    g_state.a_aim_ads = g_state.aim_ads ? 1.f : 0.f;
    g_state.a_aim_hipfire = g_state.aim_hipfire ? 1.f : 0.f;
    g_state.a_aim_head = (g_state.aim_bone == 0) ? 1.f : 0.f;
    g_state.a_aim_chest = (g_state.aim_bone == 1) ? 1.f : 0.f;
    g_state.a_aim_pelvis = (g_state.aim_bone == 2) ? 1.f : 0.f;
    g_state.a_esp_box = g_state.esp_box ? 1.f : 0.f;
    g_state.a_esp_name = g_state.esp_name ? 1.f : 0.f;
    g_state.a_esp_weapon = g_state.esp_weapon ? 1.f : 0.f;
    g_state.a_esp_hp = g_state.esp_hp ? 1.f : 0.f;
    g_state.a_esp_wall = g_state.esp_wall ? 1.f : 0.f;
    g_state.a_esp_tracer = g_state.esp_tracer ? 1.f : 0.f;
    g_state.a_esp_skeleton = g_state.esp_skeleton ? 1.f : 0.f;
    g_state.a_esp_aim_arrow = g_state.esp_aim_arrow ? 1.f : 0.f;
    g_state.a_esp_arrows = g_state.esp_arrows ? 1.f : 0.f;
    g_state.a_esp_animals = g_state.esp_animals ? 1.f : 0.f;
    g_state.a_esp_crates = g_state.esp_crates ? 1.f : 0.f;
    g_state.a_esp_bots = g_state.esp_bots ? 1.f : 0.f;
    g_state.a_esp_cupboard = g_state.esp_cupboard ? 1.f : 0.f;
    g_state.a_esp_turret = g_state.esp_turret ? 1.f : 0.f;
    g_state.a_memory_always_day = g_state.memory_always_day ? 1.f : 0.f;
    g_state.a_ignore_teammates = g_state.ignore_teammates ? 1.f : 0.f;
    g_state.a_ore_tree = g_state.ore_tree ? 1.f : 0.f;
    g_state.a_af_tree = g_state.af_tree ? 1.f : 0.f;
    g_state.a_ore_sulfur = g_state.ore_sulfur ? 1.f : 0.f;
    g_state.a_ore_iron = g_state.ore_iron ? 1.f : 0.f;
    g_state.a_ore_stone = g_state.ore_stone ? 1.f : 0.f;
    g_state.a_memory_no_recoil = g_state.memory_no_recoil ? 1.f : 0.f;
    g_state.a_memory_no_spread = g_state.memory_no_spread ? 1.f : 0.f;
    g_state.a_memory_hands_fov = g_state.memory_hands_fov ? 1.f : 0.f;
    g_state.a_memory_aspect = g_state.memory_aspect ? 1.f : 0.f;
    g_state.a_memory_black_sky = g_state.memory_black_sky ? 1.f : 0.f;
    g_state.a_crosshair_custom = g_state.crosshair_custom ? 1.f : 0.f;
    g_state.a_memory_freecam = g_state.memory_freecam ? 1.f : 0.f;
    g_state.a_freecam_bind = g_state.freecam_bind ? 1.f : 0.f;
    g_state.a_memory_xray = g_state.memory_xray ? 1.f : 0.f;
    g_state.a_af_sulfur = g_state.af_sulfur ? 1.f : 0.f;
    g_state.a_af_iron = g_state.af_iron ? 1.f : 0.f;
    g_state.a_af_stone = g_state.af_stone ? 1.f : 0.f;
    g_state.a_ui_fps = g_state.ui_fps ? 1.f : 0.f;
    g_state.a_ui_dark = g_state.ui_dark_mode ? 1.f : 0.f;
    g_state.a_ui_sep = g_state.ui_show_sep ? 1.f : 0.f;
    snprintf(g_loadedConfigName, sizeof(g_loadedConfigName), "%s", g_configs[idx].name);
    g_cfgLoadedIdx = idx;
    for (int i = 0; i < kMaxConfigs; i++) g_cfgLoadAnim[i] = 0.f;
    CfgRememberLast(g_configs[idx].name);
    ConfigSaveToPath(path);
    ShowToast(g_Lang->toast_cfg_loaded);
    PlaySound(SND_SUCCESS);
}

static void ConfigDelete(int idx) {
    if (idx < 0 || idx >= g_configCount) return;
    std::string path = CfgPath(g_configs[idx].name);
    if (strcmp(g_configs[idx].name, g_loadedConfigName) == 0) {
        g_loadedConfigName[0] = '\0';
        g_cfgLoadedIdx = -1;
        for (int i = 0; i < kMaxConfigs; i++) g_cfgLoadAnim[i] = 0.f;
    }
    remove(path.c_str());
    CfgScanDir();
    ShowToast(g_Lang->toast_cfg_deleted);
    PlaySound(SND_CLICK);
}

struct ScrollState {
    float off      = 0.f;
    float vel      = 0.f;
    float lastTy   = 0.f;
    bool  drag     = false;
    bool  dragging = false;
    int   axis     = 0;
    float sb_alpha = 0.f;
    float sb_idle  = 0.f;
    float sb_w     = 3.f;
    float sb_y     = 0.f;
    float sb_h     = 48.f;
};

static float pill_y   = -1.f;
static float pill_vel =  0.f;

struct TabRect { float sy; };
static TabRect tab_rects[6];

static void ScrollTick(ScrollState& s, bool mIn, bool blocked, float& maxScroll, float dt) {
    auto& io = ImGui::GetIO();

    if (!io.MouseDown[0]) {
        s.drag     = false;
        s.dragging = false;
        s.axis     = 0;
    }

    if (!blocked && mIn && io.MouseDown[0]) {
        if (io.MouseClicked[0]) {
            s.lastTy = io.MousePos.y;
            s.vel    = 0.f;
            s.axis   = 0;
        }

        if (s.axis == 0) {
            float dx = fabsf(io.MousePos.x - io.MouseClickedPos[0].x);
            float dy = fabsf(io.MousePos.y - io.MouseClickedPos[0].y);
            if (dx > 22.f || dy > 22.f)
                s.axis = (dy >= dx) ? 1 : 2;
            s.lastTy = io.MousePos.y;
        }

        if (s.axis == 1) {
            if (!s.drag) {
                s.drag     = true;
                s.dragging = true;
                s.lastTy   = io.MousePos.y;
                s.vel      = 0.f;
            }
            float dy = io.MousePos.y - s.lastTy;
            s.lastTy = io.MousePos.y;
            s.off    = ImClamp(s.off - dy, 0.f, maxScroll);
            float targetV = -dy * 18.f;
            s.vel = s.vel * 0.8f + targetV * 0.2f;
        }

        if (s.axis == 2) {
            s.lastTy = io.MousePos.y;
            s.vel    = 0.f;
        }
    }

    if (mIn && !blocked && io.MouseWheel != 0.f) {
        s.vel = 0.f;
        s.off = ImClamp(s.off - io.MouseWheel * 50.f, 0.f, maxScroll);
    }

    if (!s.drag && fabsf(s.vel) > 0.3f) {
        s.off += s.vel * dt;
        s.vel *= 0.88f;
    }

    s.off = ImClamp(s.off, 0.f, maxScroll);
    if (s.off <= 0.f || s.off >= maxScroll) s.vel = 0.f;

    bool isScrolling = s.drag || fabsf(s.vel) > 0.5f;
    if (isScrolling) s.sb_idle = 0.f;
    else s.sb_idle += dt;
    float sbTarget = (isScrolling || s.sb_idle < 0.8f) ? 1.f : 0.f;
    float sbSpd = sbTarget > s.sb_alpha ? 6.f : 3.5f;
    s.sb_alpha += (sbTarget - s.sb_alpha) * sbSpd * dt;
    s.sb_alpha = ImClamp(s.sb_alpha, 0.f, 1.f);
}

static ScrollState g_scrollMain;
static ScrollState g_scrollPop;

static inline bool IsScrollDragging() { return g_scrollMain.dragging || g_scrollPop.dragging; }

static ImVec2 g_popOpenClickPos = {-9999.f, -9999.f};

struct Popover {
    bool  visible    = false;
    bool  closing    = false;
    float anim       = 0.f;
    float vel        = 0.f;
    int   openFrames = 0;
    int   sectionId  = 0;
    char  title[64]  = {};
};
static Popover g_pop;

static bool AimPopBlocking() {
    return g_pop.visible && !g_pop.closing;
}

static void PopoverReset() {
    g_pop.visible = false; g_pop.closing = false;
    g_pop.anim = 0.f; g_pop.vel = 0.f;
    g_scrollPop = {};
    Blur::Unfreeze();
}

static void CloseMenuOverlays() {
    if (g_pop.visible) PopoverReset();
}

static ImVec4* g_colP = nullptr;
static bool    g_palSelReset = false;

static const ImVec4 kColorPalette[] = {
    {1.00f, 0.20f, 0.20f, 1.f}, {1.00f, 0.50f, 0.50f, 1.f}, {0.80f, 0.05f, 0.05f, 1.f},
    {1.00f, 0.60f, 0.10f, 1.f}, {1.00f, 0.75f, 0.30f, 1.f}, {0.90f, 0.40f, 0.00f, 1.f},
    {1.00f, 0.95f, 0.10f, 1.f}, {1.00f, 0.85f, 0.50f, 1.f}, {0.85f, 0.75f, 0.00f, 1.f},
    {0.20f, 0.85f, 0.35f, 1.f}, {0.50f, 1.00f, 0.50f, 1.f}, {0.05f, 0.55f, 0.15f, 1.f},
    {0.10f, 0.90f, 0.90f, 1.f}, {0.40f, 0.85f, 1.00f, 1.f}, {0.00f, 0.60f, 0.70f, 1.f},
    {0.10f, 0.50f, 1.00f, 1.f}, {0.50f, 0.70f, 1.00f, 1.f}, {0.00f, 0.25f, 0.75f, 1.f},
    {0.65f, 0.20f, 1.00f, 1.f}, {0.80f, 0.55f, 1.00f, 1.f}, {0.45f, 0.05f, 0.70f, 1.f},
    {1.00f, 0.30f, 0.80f, 1.f}, {1.00f, 0.60f, 0.90f, 1.f}, {0.80f, 0.05f, 0.50f, 1.f},
    {1.00f, 1.00f, 1.00f, 1.f}, {0.70f, 0.70f, 0.70f, 1.f}, {0.35f, 0.35f, 0.35f, 1.f},
    {0.12f, 0.12f, 0.12f, 1.f},
};
static constexpr int kPaletteCount = (int)(sizeof(kColorPalette)/sizeof(kColorPalette[0]));

void PopoverOpenColor(const char* title, ImVec4* cp) {
    if (g_pop.visible) return;
    snprintf(g_pop.title, sizeof(g_pop.title), "%s", title);
    g_pop.sectionId  = 4;
    g_pop.visible    = true;
    g_pop.closing    = false;
    g_pop.anim       = 0.f;
    g_pop.vel        = 0.f;
    g_pop.openFrames = 0;
    g_scrollPop      = {};
    g_colP = cp;
    g_palSelReset = true;
    g_popOpenClickPos = ImGui::GetIO().MousePos;
    auto& _io = ImGui::GetIO();
    Blur::Freeze((int)_io.DisplaySize.x, (int)_io.DisplaySize.y,
                 (int)g_win.pos.x, (int)g_win.pos.y,
                 (int)g_win.w,     (int)g_win.h);
}

void PopoverOpen(const char* title, int sid) {
    if (g_pop.visible) return;
    snprintf(g_pop.title, sizeof(g_pop.title), "%s", title);
    g_pop.sectionId  = sid;
    g_pop.visible    = true;
    g_pop.closing    = false;
    g_pop.anim       = 0.f;
    g_pop.vel        = 0.f;
    g_pop.openFrames = 0;
    g_scrollPop      = {};
    auto& _io = ImGui::GetIO();
    Blur::Freeze((int)_io.DisplaySize.x, (int)_io.DisplaySize.y,
                 (int)g_win.pos.x, (int)g_win.pos.y,
                 (int)g_win.w,     (int)g_win.h);
}

void PopoverClose() {
    if (!g_pop.visible || g_pop.closing) return;
    if (g_pop.openFrames < 1) return;
    g_pop.closing = true;
    g_input.touchConsumed = true;
}

static void DrawToggle(ImDrawList* dl, float ax, float cy, float t) {
    const float tW = 72.f, tH = 42.f, tR = tH * 0.5f;
    float tx = ax, ty = cy - tH * 0.5f;
    ImU32 trkCol = C::Mix(C::TrkOff(), C::Acc(), t);
    dl->AddRectFilled({tx, ty}, {tx + tW, ty + tH}, trkCol, tR);
    if (t < 0.95f) {
        ImU32 borderCol = C::UA(C::Sep(), (1.f - t) * 0.95f);
        dl->AddRect({tx, ty}, {tx + tW, ty + tH}, borderCol, tR, 0, 2.0f);
    }

    float kR = Lerpf(12.5f, 16.0f, t);
    float kx = Lerpf(tx + tR, tx + tW - tR, t);
    float ky = cy;

    ImVec4 thumbOffCol = {0.92f, 0.92f, 0.94f, 1.0f};
    if (g_darkTheme) thumbOffCol = {0.30f, 0.30f, 0.33f, 1.0f};
    ImVec4 thumbOnCol = {1.0f, 1.0f, 1.0f, 1.0f};
    ImU32 thumbCol = C::Mix(thumbOffCol, thumbOnCol, t);

    dl->AddCircleFilled({kx, ky}, kR, thumbCol, 32);

    if (t > 0.05f) {
        float sc = ImClamp((t - 0.1f) / 0.9f, 0.f, 1.f);
        ImU32 colCheck = C::UA(C::Acc(), t);
        ImVec2 pts[3] = {
            {kx - 5.4f * sc, ky + 0.2f * sc},
            {kx - 1.8f * sc, ky + 3.8f * sc},
            {kx + 5.4f * sc, ky - 3.4f * sc}
        };
        dl->AddPolyline(pts, 3, colCheck, ImDrawFlags_None, 2.9f * sc);
    }
    if (t < 0.95f) {
        float sc = ImClamp((0.9f - t) / 0.9f, 0.f, 1.f);
        float alphaCross = (1.f - t);
        ImVec4 crossBase = g_darkTheme ? ImVec4(0.70f, 0.70f, 0.75f, 1.0f) : ImVec4(0.35f, 0.35f, 0.40f, 1.0f);
        ImU32 colCross = C::UA(crossBase, alphaCross);
        float rCross = 4.4f * sc;
        dl->AddLine({kx - rCross, ky - rCross}, {kx + rCross, ky + rCross}, colCross, 2.7f * sc);
        dl->AddLine({kx + rCross, ky - rCross}, {kx - rCross, ky + rCross}, colCross, 2.7f * sc);
    }
}

void RenderToggleRowVisuals(ImDrawList* dl, ImFont* fn, float fs,
                            float rowX, float rowY, float rowW,
                            const char* lbl, float animT, float alpha,
                            bool showSep, bool last) {
    const float inset = Layout::Inset, padX = Layout::PadX;
    float cX = rowX + inset, cW = rowW - inset * 2.f;
    const float rowH = Layout::RowH;
    float textX    = cX + padX;
    float textMaxX = cX + cW - 72.f - padX - 16.f;
    float textY    = rowY + (rowH - fs * 1.15f) * 0.5f;

    dl->PushClipRect({textX, rowY}, {textMaxX, rowY + rowH}, true);
    dl->AddText(fn, fs * 1.15f, {textX, textY}, C::UA(C::Txt(), alpha), lbl);
    dl->PopClipRect();

    DrawToggle(dl, cX + cW - 72.f - padX, rowY + rowH * 0.5f, EaseInOut(animT));

    if (!last && showSep)
        dl->AddLine({cX + padX, rowY + rowH - 0.5f},
                    {cX + cW - padX, rowY + rowH - 0.5f}, C::UA(C::Sep(), alpha), 0.8f);
}

static void RenderSliderVisuals(ImDrawList* dl, ImFont* fn, float fs,
                                 float rowX, float rowY, float rowW, float rowH,
                                 const char* lbl, const char* fmt, float v, float animPos,
                                 bool active, float alpha, bool showSep, bool last) {
    const float inset = Layout::Inset, padX = Layout::PadX;
    const float tH = 11.f, kR = 22.f, padH = 38.f;
    float cX = rowX + inset, cW = rowW - inset * 2.f;

    char valBuf[24]; snprintf(valBuf, 24, fmt, v);
    auto vsz   = fn->CalcTextSizeA(fs, FLT_MAX, 0, valBuf);
    float textY = rowY + padH * 0.5f;

    float sX = cX + padX + kR, sW = cW - padX * 2.f - kR * 2.f;
    float tY = rowY + rowH - padH;
    float kx = sX + animPos * sW;

    dl->PushClipRect({cX + padX, rowY}, {cX + cW - vsz.x - padX * 2.f, rowY + rowH * 0.55f}, true);
    dl->AddText(fn, fs * 1.15f, {cX + padX, textY}, C::UA(C::Txt(), alpha), lbl);
    dl->PopClipRect();
    dl->AddText(fn, fs * 1.15f, {cX + cW - vsz.x - padX, textY}, C::UA(C::Acc(), alpha), valBuf);

    dl->AddRectFilled({sX, tY - tH * 0.5f}, {sX + sW, tY + tH * 0.5f}, C::UA(C::TrkOff(), alpha), tH);
    dl->AddRectFilled({sX, tY - tH * 0.5f}, {kx,      tY + tH * 0.5f}, C::UA(C::Acc(),    alpha), tH);

    const float knobR = 16.f;
    dl->AddCircleFilled({kx + 0.5f, tY + 1.5f}, knobR + 1.f, IM_COL32(0, 0, 0, int(30 * alpha)));
    dl->AddCircleFilled({kx, tY}, knobR, IM_COL32(255, 255, 255, int(255 * alpha)));
    if (active)
        dl->AddCircle({kx, tY}, knobR + 4.f, C::UA(C::Acc(), 0.85f * alpha), 48, 3.f);

    if (!last && showSep)
        dl->AddLine({cX + padX, rowY + rowH - 0.5f},
                    {cX + cW - padX, rowY + rowH - 0.5f}, C::UA(C::Sep(), alpha), 0.8f);
}

bool ToggleRow(const char* id, const char* lbl, bool* v, float& anim,
               bool last = false) {
    auto* dl  = ImGui::GetWindowDrawList();
    float avW = ImGui::GetContentRegionAvail().x;
    const float rowH = Layout::RowH;
    auto pos = ImGui::GetCursorScreenPos();

    ImGui::InvisibleButton(id, {avW, rowH});
    bool popBlocking = (g_pop.visible && !g_pop.closing);

    bool triggered = WasTappedHere() && !popBlocking && !IsScrollDragging() && !g_input.touchConsumed;
    if (triggered) { *v=!*v; char _b[160]; snprintf(_b,sizeof(_b),xv::StrStable(xv::sid::kMiSS),lbl,*v?"ON":xv::StrStable(xv::sid::kMiOFF)); ShowToast(_b); PlaySound(SND_CLICK); }

    RenderToggleRowVisuals(dl, ImGui::GetFont(), ImGui::GetFontSize(),
                           pos.x, pos.y, avW, lbl, anim, 1.f,
                           g_state.ui_show_sep, last);
    return triggered;
}

static void TickSliderAnim(AppState::SliderAnim& anim, float target, bool act, float dt) {
    if (anim.pos < 0.f) { anim.pos = target; anim.vel = 0.f; }
    const float stiff = act ? 900.f : 280.f;
    const float damp  = act ?  60.f :  28.f;
    float force = stiff * (target - anim.pos) - damp * anim.vel;
    anim.vel += force * dt;
    anim.pos += anim.vel * dt;
    anim.pos  = ImClamp(anim.pos, 0.f, 1.f);
    if (fabsf(target - anim.pos) < 0.0002f && fabsf(anim.vel) < 0.001f) {
        anim.pos = target; anim.vel = 0.f;
    }
}

bool SliderRow(const char* id, const char* lbl, float* v, float mn, float mx,
               const char* fmt, bool last,
               AppState::SliderAnim& anim, float dt, float step = 0.f,
               float fade = 1.f) {
    auto* dl  = ImGui::GetWindowDrawList();
    auto& io  = ImGui::GetIO();
    float avW = ImGui::GetContentRegionAvail().x;
    const float rowH = Layout::SliderH, kR = 22.f;
    const float inset = Layout::Inset, padX = Layout::PadX;
    auto pos = ImGui::GetCursorScreenPos();

    ImGui::InvisibleButton(id, {avW, rowH});
    bool itemActive = ImGui::IsItemActive();

    bool popBlocking = (g_pop.visible && !g_pop.closing);
    int scrollAxis = g_scrollMain.axis;
    bool scrollVertical = g_scrollMain.dragging || (itemActive && scrollAxis == 1);
    bool axisUndecided  = itemActive && scrollAxis == 0 && io.MouseDown[0];

    bool act = itemActive && !scrollVertical && !axisUndecided && !popBlocking && !g_input.touchConsumed
               && fabsf(io.MousePos.y - (pos.y + rowH * 0.5f)) <= rowH * 1.5f;

    if (act) {
        *v = mn + Clamp01((io.MousePos.x - (pos.x + inset + padX + kR)) /
                          (avW - inset * 2.f - padX * 2.f - kR * 2.f)) *
                  (mx - mn);
    }
    *v = ImClamp(*v, mn, mx);
    if (step > 0.f)
        *v = ImClamp(mn + roundf((*v - mn) / step) * step, mn, mx);

    float target = Clamp01((*v - mn) / (mx - mn));

    TickSliderAnim(anim, target, act, dt);

    RenderSliderVisuals(dl, ImGui::GetFont(), ImGui::GetFontSize(),
                        pos.x, pos.y, avW, rowH,
                        lbl, fmt, *v, anim.pos, act, fade,
                        g_state.ui_show_sep, last);
    return act;
}

void CardBg(float h, ImDrawFlags flags = ImDrawFlags_RoundCornersAll) {
    auto* dl  = ImGui::GetWindowDrawList();
    auto  p0  = ImGui::GetCursorScreenPos();
    float w   = ImGui::GetContentRegionAvail().x;
    const float inset = Layout::Inset;
    ImVec2 bMin = {p0.x + inset, p0.y};
    ImVec2 bMax = {p0.x + w - inset, p0.y + h};
    dl->AddRectFilled(bMin, bMax, C::U(C::Card()), R::Card, flags);
    if (g_state.ui_show_sep)
        dl->AddRect(bMin, bMax, C::U(C::Sep()), R::Card, 1.2f, flags);
}

static bool TickSlideAnim(float& anim, float& vel, bool closing, float dt);

void SHdr(const char* t, float top = 18.f, float alpha = 1.f) {
    ImGui::Dummy({1.f, top});
    if (t && t[0]) {
        auto*  dl  = ImGui::GetWindowDrawList();
        auto*  fn  = ImGui::GetFont();
        float  fs  = ImGui::GetFontSize() * 1.15f;
        auto   pos = ImGui::GetCursorScreenPos();
        auto   tsz = fn->CalcTextSizeA(fs, FLT_MAX, 0, t);
        ImVec4 dc = C::Dim();
        dc.w = ImClamp(dc.w * alpha, 0.f, 1.f);
        dl->AddText(fn, fs, {pos.x + 32.f, pos.y},
                    ImGui::ColorConvertFloat4ToU32(dc), t);
        ImGui::Dummy({1.f, tsz.y});
    }
    ImGui::Dummy({1.f, 8.f});
}

static void AfZoneRow(const char* id, const char* label, const char* unset_label,
                      bool set, bool& armed, const char* hint, bool toggle,
                      bool separator) {
    auto* dl = ImGui::GetWindowDrawList();
    auto* fn = ImGui::GetFont();
    const float fs = ImGui::GetFontSize();
    const float avW = ImGui::GetContentRegionAvail().x;
    const float rowH = Layout::RowH;
    const ImVec2 pos = ImGui::GetCursorScreenPos();

    ImGui::InvisibleButton(id, {avW, rowH});
    const bool popBlocking = (g_pop.visible && !g_pop.closing);
    if (WasTappedHere() && !popBlocking && !IsScrollDragging() &&
        !g_input.touchConsumed) {
        if (toggle) armed = !armed;
        else armed = true;
        if (armed) ShowToast(hint);
        PlaySound(SND_CLICK);
    }

    const float cy = pos.y + rowH * 0.5f;
    const float textX = pos.x + Layout::Inset + Layout::PadX;
    dl->AddText(fn, fs * 1.05f, {textX, cy - fs * 0.52f}, C::U(C::Txt()), label);

    const char* pillTxt = set ? g_Lang->done : unset_label;
    const ImVec4 pill = set ? ImVec4(0.14f, 0.62f, 0.30f, 1.f)
                            : ImVec4(0.64f, 0.36f, 0.10f, 1.f);
    const ImVec2 psz = fn->CalcTextSizeA(fs * 0.95f, FLT_MAX, 0, pillTxt);
    const float pW = psz.x + 24.f, pH = 44.f;
    const float pX = pos.x + avW - Layout::Inset - pW - Layout::PadX;
    const float pY = cy - pH * 0.5f;
    dl->AddRectFilled({pX, pY}, {pX + pW, pY + pH}, C::U(pill), pH * 0.5f);
    dl->AddText(fn, fs * 0.95f,
                {pX + (pW - psz.x) * 0.5f, pY + (pH - psz.y) * 0.5f},
                IM_COL32(255, 255, 255, 255), pillTxt);

    if (separator && g_state.ui_show_sep)
        dl->AddLine({textX, pos.y + rowH - 0.5f},
                    {pos.x + avW - Layout::Inset - Layout::PadX, pos.y + rowH - 0.5f},
                    C::UA(C::Sep(), 0.35f), 0.8f);
}

static void DrawToast(float dt) {
    if (!g_toast.visible) return;
    g_toast.life += dt;

    if (g_toast.hasNext && g_toast.textA < 0.04f) {
        snprintf(g_toast.msg, sizeof(g_toast.msg), "%s", g_toast.nextMsg);
        g_toast.hasNext = false;
        g_toast.barW = 1.f; g_toast.barVel = 0.f;
    }

    if (g_toast.life > 2.6f && !g_toast.closing && !g_toast.hasNext) g_toast.closing = true;

    if (!TickSlideAnim(g_toast.slidePos, g_toast.slideVel, g_toast.closing, dt)) {
        g_toast.slidePos = 0.f; g_toast.slideVel = 0.f; g_toast.visible = false; return;
    }

    float textTgt = (g_toast.hasNext ? 0.f : 1.f);
    g_toast.textA += (textTgt - g_toast.textA) * 14.f * dt;
    g_toast.textA = ImClamp(g_toast.textA, 0.f, 1.f);

    { float bt = g_toast.hasNext ? 1.f : ImMax(0.f, 1.f - g_toast.life / 2.6f);
      float f = 220.f * (bt - g_toast.barW) - 30.f * g_toast.barVel;
      g_toast.barVel += f * dt; g_toast.barW += g_toast.barVel * dt;
      g_toast.barW = ImClamp(g_toast.barW, 0.f, 1.f); }

    auto* fg = ImGui::GetForegroundDrawList();
    auto* fn = ImGui::GetFont();
    float fs  = ImGui::GetFontSize() * 1.55f;
    float scrW = 0.f, scrH = 0.f;
    VisibleScreen(scrW, scrH);

    const char* sep = strchr(g_toast.msg, 124);
    char np[128] = {}, sp[8] = {}; bool isOn = false;
    if (sep) {
        snprintf(np, sizeof(np), xv::StrStable(xv::sid::kMiS), (int)(sep - g_toast.msg), g_toast.msg);
        snprintf(sp, sizeof(sp), "%s", sep + 1);
        isOn = (sp[0] == 'O' && sp[1] == 'N' && sp[2] == 0);
    } else {
        snprintf(np, sizeof(np), "%s", g_toast.msg);
    }

    auto nsz = fn->CalcTextSizeA(fs, FLT_MAX, 0, np);
    auto ssz = fn->CalcTextSizeA(fs, FLT_MAX, 0, xv::StrStable(xv::sid::kMiX));
    auto asz = fn->CalcTextSizeA(fs, FLT_MAX, 0, sp);

    float padH = 28.f, padV = 20.f;
    float tWTarget = padH + nsz.x + (sep ? ssz.x + asz.x : 0.f) + padH;
    float tH = nsz.y + padV * 2.f + 10.f;

    if (g_toast.widthAnim < 8.f) { g_toast.widthAnim = tWTarget; g_toast.widthVel = 0.f; }
    {
        float dw = tWTarget - g_toast.widthAnim;
        g_toast.widthVel += (dw * 220.f - g_toast.widthVel * 28.f) * dt;
        g_toast.widthAnim += g_toast.widthVel * dt;
        if (fabsf(dw) < 0.6f && fabsf(g_toast.widthVel) < 4.f) {
            g_toast.widthAnim = tWTarget; g_toast.widthVel = 0.f;
        }
    }
    float tW = g_toast.widthAnim;

    float ease  = EaseInOut(ImClamp(g_toast.slidePos, 0.f, 1.f));
    float offY  = (1.f - ease) * (-(tH + 20.f));
    float alpha = ease;

    float tx = scrW - tW - 16.f;
    float ty = 16.f + offY;

    ImVec4 card = C::Card(), txt = C::Txt(), dim = C::Dim(), acc = C::Acc();

    fg->AddRectFilled({tx + 2.f, ty + 4.f}, {tx + tW + 2.f, ty + tH + 4.f},
        IM_COL32(0, 0, 0, int(26 * alpha)), 26.f);
    fg->AddRectFilled({tx, ty}, {tx + tW, ty + tH},
        IM_COL32(int(card.x*255), int(card.y*255), int(card.z*255), int(alpha * 245)), 26.f);
    fg->AddRect({tx, ty}, {tx + tW, ty + tH},
        C::UA(acc, 0.32f * alpha), 26.f, 1.3f);

    fg->PushClipRect({tx + 1.f, ty + 1.f}, {tx + tW - 1.f, ty + tH - 1.f}, true);

    float cx0 = tx + padH;
    float textY = ty + padV;
    float ta = g_toast.textA * alpha;

    fg->AddText(fn, fs, {cx0, textY},
        IM_COL32(int(txt.x*255), int(txt.y*255), int(txt.z*255), int(ta*255)), np);
    cx0 += nsz.x;

    if (sep) {
        fg->AddText(fn, fs, {cx0, textY},
            IM_COL32(int(dim.x*255), int(dim.y*255), int(dim.z*255), int(ta*170)), xv::StrStable(xv::sid::kMiX));
        cx0 += ssz.x;
        ImVec4 stCol = isOn ? ImVec4{0.196f, 0.843f, 0.294f, 1.f} : ImVec4{1.f, 0.231f, 0.188f, 1.f};
        fg->AddText(fn, fs, {cx0, textY},
            IM_COL32(int(stCol.x*255), int(stCol.y*255), int(stCol.z*255), int(ta*255)), sp);
    }

    {
        float bH  = 10.f, bR = 5.f;
        float bY  = ty + tH - 8.f - bH;
        float bx0 = tx + 22.f, bx1 = tx + tW - 22.f;
        float fx1 = bx0 + g_toast.barW * (bx1 - bx0);
        int ar = int(acc.x*255), ag = int(acc.y*255), ab = int(acc.z*255);
        if (fx1 > bx0 + bR * 2.f)
            fg->AddRectFilled({bx0, bY}, {fx1, bY + bH},
                IM_COL32(ar, ag, ab, int(alpha * 215)), bR);
    }

    fg->PopClipRect();
}

static float wm_ring   = 2.f;
static float wm_fps_sm = 0.f;
static float wm_w      = 0.f;

struct RollingCounterState {
    int   candidate      = 0;
    int   target         = 0;
    float candidate_time = 0.f;
    float value          = 0.f;
    float velocity       = 0.f;
};
static RollingCounterState wm_enemy_counter;
static RollingCounterState wm_bot_counter;
static RollingCounterState wm_online_counter;

static void TickRollingCounter(RollingCounterState& c, int raw_count, float dt) {
    raw_count = std::max(0, std::min(999, raw_count));
    dt = ImClamp(dt, 0.f, 0.05f);

    if (raw_count != c.candidate) {
        c.candidate = raw_count;
        c.candidate_time = 0.f;
    } else {
        c.candidate_time += dt;
        if (c.candidate_time >= 0.05f)
            c.target = c.candidate;
    }

    const float target = (float)c.target;
    const float omega = 11.f;
    const float displacement = c.value - target;
    const float spring_term = c.velocity + omega * displacement;
    const float decay = expf(-omega * dt);
    c.value = target + (displacement + spring_term * dt) * decay;
    c.velocity = (c.velocity - omega * spring_term * dt) * decay;

    if (fabsf(c.value - target) < 0.001f && fabsf(c.velocity) < 0.01f) {
        c.value = target;
        c.velocity = 0.f;
    }
    c.value = ImClamp(c.value, 0.f, 999.f);
}

static void DrawRollingCount(ImDrawList* dl, ImFont* font, float font_size,
                             float value, const ImVec2& center,
                             float slot_width, const ImVec4& color) {
    if (value < 0.f) value = 0.f;
    const int lower = (int)floorf(value);
    const int upper = lower + 1;
    const float fraction = value - (float)lower;
    const float line_height = font_size * 1.05f;
    const float travel = line_height * 0.95f;
    const float base_y = center.y - line_height * 0.5f;

    auto draw_number = [&](int num, float y, float alpha) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d", num);
        const ImVec2 num_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.f, buf);
        const float x = center.x - num_size.x * 0.5f;
        const float bold = std::max(0.38f, font_size * 0.020f);
        dl->AddText(font, font_size, {x - bold * 0.5f, y}, C::UA(color, alpha * color.w), buf);
        dl->AddText(font, font_size, {x + bold * 0.5f, y}, C::UA(color, alpha * color.w), buf);
    };

    dl->PushClipRect({center.x - slot_width * 0.5f, center.y - line_height * 0.62f},
                     {center.x + slot_width * 0.5f, center.y + line_height * 0.62f}, true);
    if (fraction <= 0.001f) {
        draw_number(lower, base_y, 1.f);
    } else {
        draw_number(lower, base_y - fraction * travel, 1.f - fraction);
        draw_number(upper, base_y + (1.f - fraction) * travel, fraction);
    }
    dl->PopClipRect();
}

void DrawWatermark(float dt) {
    auto& io = ImGui::GetIO();
    auto* fn = ImGui::GetFont();
    auto* fg = ImGui::GetForegroundDrawList();

    TickRollingCounter(wm_enemy_counter, g_nearby_enemy_count, dt);
    TickRollingCounter(wm_bot_counter, g_nearby_bot_count, dt);

    float raw_fps = overlay_fps();
    if (raw_fps < 1.f) raw_fps = io.Framerate;
    const float rates[] = {60.f, 90.f, 120.f, 144.f, 165.f, 180.f, 240.f};
    float nearest = raw_fps, nearest_delta = 1e9f;
    for (float rate : rates) {
        float delta = fabsf(raw_fps - rate);
        if (delta < nearest_delta) { nearest_delta = delta; nearest = rate; }
    }
    if (nearest_delta <= 8.f) raw_fps = nearest;
    wm_fps_sm += (raw_fps - wm_fps_sm) * 8.f * ImClamp(dt, 0.f, 0.05f);
    if (wm_fps_sm < 1.f) wm_fps_sm = raw_fps;
    wm_ring += dt * 3.5f;

    float screen_w = 0.f, screen_h = 0.f;
    VisibleScreen(screen_w, screen_h);

    const float width_scale = screen_w / 1920.f;
    const float height_scale = screen_h / 1080.f;
    const float fit_scale = screen_w / 720.f;
    const float scale = ImClamp(ImMin(ImMin(width_scale, height_scale), fit_scale),
                                0.55f, 1.08f);

    const float label_fs = 27.f * scale;
    const float count_fs = 33.f * scale;
    const float separator_fs = 27.f * scale;
    const float fps_fs = 19.f * scale;
    const float horizontal_pad = 18.f * scale;
    const float value_gap = 6.f * scale;
    const float separator_gap = 12.f * scale;

    const char* enemy_label = g_Lang->enemies;

    const char* teammate_label = g_Lang->bots_label;
    const char* separator_text = "|";
    const ImVec2 enemy_size = fn->CalcTextSizeA(label_fs, FLT_MAX, 0.f, enemy_label);
    const ImVec2 teammate_size = fn->CalcTextSizeA(label_fs, FLT_MAX, 0.f, teammate_label);
    const ImVec2 separator_size = fn->CalcTextSizeA(separator_fs, FLT_MAX, 0.f, separator_text);

    const ImVec2 count_slot_size = fn->CalcTextSizeA(count_fs, FLT_MAX, 0.f, "99");
    const float enemy_slot_w = count_slot_size.x + 4.f * scale;
    const float teammate_slot_w = count_slot_size.x + 4.f * scale;
    const float enemy_content_w = enemy_size.x + value_gap + enemy_slot_w;
    const float teammate_content_w = teammate_size.x + value_gap + teammate_slot_w;

    const float card_w = horizontal_pad * 2.f + enemy_content_w +
                         separator_gap + separator_size.x + separator_gap +
                         teammate_content_w;
    const float card_h = 66.f * scale;
    const float radius = card_h * 0.5f;
    const float card_x = (screen_w - card_w) * 0.5f;
    const float card_y = ImClamp(screen_h * 0.035f, 26.f, 42.f);
    const float center_y = card_y + card_h * 0.5f;

    const float target_half = ImMin(card_h, screen_h * 0.12f);
    const float target_size = target_half * 2.f;
    const float target_center_x = screen_w * 0.5f;
    g_genieTargetRect = {target_center_x - target_half,
                         screen_h,
                         target_center_x + target_half,
                         screen_h + target_size};

    const bool hovered = io.MousePos.x >= card_x && io.MousePos.x <= card_x + card_w &&
                         io.MousePos.y >= card_y && io.MousePos.y <= card_y + card_h;
    if (hovered && io.MouseClicked[0]) {
        menu_open = !menu_open;
        if (!menu_open) CloseMenuOverlays();
        wm_ring = 0.f;
    }

    const ImVec4 accent = C::Acc();
    const ImVec4 enemy_color = C::Red();
    const ImVec4 bot_color = {0.00f, 0.478f, 1.00f, 1.f};

    fg->AddRectFilled({card_x, card_y}, {card_x + card_w, card_y + card_h},
                      C::U(C::Card()), radius);
    fg->AddRect({card_x - 1.5f, card_y - 1.5f},
                {card_x + card_w + 1.5f, card_y + card_h + 1.5f},
                C::UA(accent, 0.20f), radius + 1.5f, 0, 1.5f);
    fg->AddRect({card_x, card_y}, {card_x + card_w, card_y + card_h},
                C::UA(accent, 0.85f), radius, 0, 2.0f);
    fg->AddLine({card_x + radius * 0.72f, card_y + 1.f},
                {card_x + card_w - radius * 0.72f, card_y + 1.f},
                C::UA(C::Txt(), g_darkTheme ? 0.09f : 0.18f), 1.f);

    if (wm_ring < 1.f) {
        const float pulse = EaseOut3(wm_ring);
        const float expand = pulse * 20.f * scale;
        fg->AddRect({card_x - expand, card_y - expand},
                    {card_x + card_w + expand, card_y + card_h + expand},
                    C::UA(accent, 0.35f * (1.f - pulse)), radius + expand, 0, 2.f);
    }

    auto draw_text = [&](const char* text, float font_size, float x,
                         const ImVec4& color, float alpha = 1.f) {
        const ImVec2 size = fn->CalcTextSizeA(font_size, FLT_MAX, 0.f, text);
        const float y = center_y - size.y * 0.5f;

        const float edge = std::max(0.28f, font_size * 0.012f);
        fg->AddText(fn, font_size, {x, y}, C::UA(color, alpha), text);
        fg->AddText(fn, font_size, {x + edge, y},
                    C::UA(color, alpha * 0.34f), text);
    };

    float x = card_x + horizontal_pad;
    draw_text(enemy_label, label_fs, x, C::Txt());
    x += enemy_size.x + value_gap;
    DrawRollingCount(fg, fn, count_fs, wm_enemy_counter.value,
                     {x + enemy_slot_w * 0.5f, center_y}, enemy_slot_w,
                     enemy_color);
    x += enemy_slot_w + separator_gap;

    draw_text(separator_text, separator_fs, x, C::Dim(), 0.72f);
    x += separator_size.x + separator_gap;

    draw_text(teammate_label, label_fs, x, C::Txt());
    x += teammate_size.x + value_gap;
    DrawRollingCount(fg, fn, count_fs, wm_bot_counter.value,
                     {x + teammate_slot_w * 0.5f, center_y}, teammate_slot_w,
                     bot_color);

    {
        const float anim_dt = ImClamp(dt, 0.f, 0.032f);
        const float speed = 3.6f;
        wm_w += (g_state.ui_fps ? 1.f : -1.f) * speed * anim_dt;
        wm_w = ImClamp(wm_w, 0.f, 1.f);
    }
    if (wm_w > 0.004f) {
        char fps_text[12]{};
        snprintf(fps_text, sizeof(fps_text), xv::StrStable(xv::sid::kMi0f), wm_fps_sm);
        const ImVec2 fps_label_size = fn->CalcTextSizeA(fps_fs, FLT_MAX, 0.f, xv::StrStable(xv::sid::kMiFPS));
        const ImVec2 fps_value_size = fn->CalcTextSizeA(label_fs, FLT_MAX, 0.f, xv::StrStable(xv::sid::kMi240));
        const float fps_gap = 8.f * scale;
        const float fps_pad = 14.f * scale;
        const float fps_full_w = fps_pad * 2.f + fps_label_size.x + fps_gap + fps_value_size.x;
        const float fps_x = card_x + card_w + 11.f * scale;

        const float open_t = ImClamp(wm_w, 0.f, 1.f);
        const float back_i = open_t - 1.f;
        const float back_t = 1.f + 2.2f * back_i * back_i * back_i + 1.2f * back_i * back_i;
        const float pill_w = fps_full_w * back_t;

        if (pill_w > 1.f) {
            const float label_a = ImClamp(open_t / 0.42f, 0.f, 1.f);
            const float num_t = ImClamp((open_t - 0.30f) / 0.42f, 0.f, 1.f);
            const float num_a = EaseOut3(num_t);
            const float num_slide = (1.f - num_a) * 16.f;
            const float fpsAlpha = EaseOut3(open_t);

            fg->PushClipRect({fps_x - 1.f, card_y - 6.f},
                             {fps_x + pill_w + 2.f, card_y + card_h + 6.f}, true);
            fg->AddRectFilled({fps_x, card_y}, {fps_x + pill_w, card_y + card_h},
                              C::U(C::Card()), radius);
            fg->AddRect({fps_x - 1.5f, card_y - 1.5f},
                        {fps_x + pill_w + 1.5f, card_y + card_h + 1.5f},
                        C::UA(accent, 0.20f * fpsAlpha), radius + 1.5f, 0, 1.5f);
            fg->AddRect({fps_x, card_y}, {fps_x + pill_w, card_y + card_h},
                        C::UA(accent, 0.85f * fpsAlpha), radius, 0, 2.0f);
            draw_text(xv::StrStable(xv::sid::kMiFPS), fps_fs, fps_x + fps_pad, C::Dim(), label_a);
            const ImVec2 actual_value_size = fn->CalcTextSizeA(label_fs, FLT_MAX, 0.f, fps_text);
            const float value_x = fps_x + fps_pad + fps_label_size.x + fps_gap +
                                  (fps_value_size.x - actual_value_size.x) * 0.5f - num_slide;
            draw_text(fps_text, label_fs, value_x, accent, num_a);
            fg->PopClipRect();
        }
    }
}

struct FreecamStick {
    int finger = -1;
    ImVec2 center = {0.f, 0.f};
    ImVec2 offset = {0.f, 0.f};
};
static FreecamStick g_fc_move;
static FreecamStick g_fc_look;

static void FreecamSticksReset() {
    g_fc_move = {};
    g_fc_look = {};
}

static ImVec2 FreecamStickClampCenter(const ImVec2& point, float stick_r,
                                      float sw, float sh) {
    ImVec2 center = point;
    const float minX = stick_r * 0.6f;
    const float maxX = sw - stick_r * 0.6f;
    const float minY = sh * 0.30f + stick_r * 0.35f;
    const float maxY = sh - stick_r * 0.35f;
    center.x = ImClamp(center.x, minX, maxX);
    center.y = ImClamp(center.y, minY, maxY);
    return center;
}

static void FreecamStickChevron(ImDrawList* fg, const ImVec2& center,
                                float angle, float size, ImU32 color) {
    const float ca = cosf(angle), sa = sinf(angle);
    const ImVec2 tip{center.x + ca * size, center.y + sa * size};
    const ImVec2 left{center.x - ca * size * 0.45f + sa * size * 0.62f,
                      center.y - sa * size * 0.45f - ca * size * 0.62f};
    const ImVec2 right{center.x - ca * size * 0.45f - sa * size * 0.62f,
                       center.y - sa * size * 0.45f + ca * size * 0.62f};
    fg->AddTriangleFilled(tip, left, right, color);
}

static void FreecamDrawStick(ImDrawList* fg, const ImVec2& center,
                             float stick_r, float knob_r, const ImVec2& offset,
                             bool active) {
    const float base_a = active ? 1.f : 0.42f;
    fg->AddCircleFilled({center.x + 2.f, center.y + 4.f}, stick_r,
                        IM_COL32(0, 0, 0, (int)(60 * base_a)), 48);
    fg->AddCircleFilled(center, stick_r,
                        C::UA(C::Card(), 0.62f * base_a), 48);
    fg->AddCircle(center, stick_r, C::UA(C::Sep(), 0.9f * base_a), 48, 1.6f);
    fg->AddCircle(center, stick_r * 0.66f,
                  C::UA(C::Acc(), 0.25f * base_a), 48, 1.2f);
    const float chev = stick_r * 0.09f;
    const float chev_r = stick_r - chev * 2.1f;
    FreecamStickChevron(fg, {center.x, center.y - chev_r}, -IM_PI * 0.5f, chev,
                        C::UA(C::Txt(), 0.34f * base_a));
    FreecamStickChevron(fg, {center.x, center.y + chev_r}, IM_PI * 0.5f, chev,
                        C::UA(C::Txt(), 0.34f * base_a));
    FreecamStickChevron(fg, {center.x - chev_r, center.y}, IM_PI, chev,
                        C::UA(C::Txt(), 0.34f * base_a));
    FreecamStickChevron(fg, {center.x + chev_r, center.y}, 0.f, chev,
                        C::UA(C::Txt(), 0.34f * base_a));

    const ImVec2 knob{center.x + offset.x, center.y + offset.y};
    fg->AddCircleFilled({knob.x + 1.f, knob.y + 3.f}, knob_r,
                        IM_COL32(0, 0, 0, (int)(80 * base_a)), 40);
    fg->AddCircleFilled(knob, knob_r,
                        active ? C::U(C::Acc())
                               : C::UA(C::Card(), 0.95f * base_a), 40);
    fg->AddCircle(knob, knob_r,
                  C::UA(C::Txt(), active ? 0.85f : 0.30f * base_a), 40, 2.f);
    fg->AddCircleFilled(knob, knob_r * 0.34f,
                        C::UA(C::Txt(), 0.28f), 24);
}

struct FreecamBind {
    int finger = -1;
    ImVec2 down_pos = {0.f, 0.f};
    ImVec2 grab_off = {0.f, 0.f};
    double down_time = 0.0;
    float drift2 = 0.f;
    bool dragging = false;
    float press = 0.f;
    float pulse = 0.f;
};
static FreecamBind g_fc_bind;

static void FreecamBindTick(float dt) {
    if (g_fc_bind.pulse > 0.f) {
        g_fc_bind.pulse -= dt * 2.6f;
        if (g_fc_bind.pulse < 0.f) g_fc_bind.pulse = 0.f;
    }
    if (!g_esp_attached.load() || menu_open || !g_state.freecam_bind) {
        g_fc_bind = {};
        return;
    }

    float sw, sh;
    OverlayScreenSize(sw, sh);
    const float r = ImClamp(sh * 0.062f, 56.f, 92.f);
    const float mx = r + 6.f;
    const float my = r * 0.98f + 6.f;
    const ImVec2 c{ImClamp(g_state.fc_bind_x * sw, mx, sw - mx),
                   ImClamp(g_state.fc_bind_y * sh, my, sh - my)};

    int ids[16]{};
    float xs[16]{}, ys[16]{};
    const int count = Touch_GetPointers(ids, xs, ys, 16);

    if (g_fc_bind.finger >= 0) {
        ImVec2 p{};
        bool down = false;
        for (int i = 0; i < count; ++i) {
            if (ids[i] == g_fc_bind.finger) {
                p = {xs[i], ys[i]};
                down = true;
                break;
            }
        }
        if (down) {
            const float dx = p.x - g_fc_bind.down_pos.x;
            const float dy = p.y - g_fc_bind.down_pos.y;
            const float d2 = dx * dx + dy * dy;
            if (d2 > g_fc_bind.drift2) g_fc_bind.drift2 = d2;
            if (!g_fc_bind.dragging && d2 > 24.f * 24.f) {
                g_fc_bind.dragging = true;
                g_fc_bind.grab_off = ImVec2{g_fc_bind.down_pos.x - c.x,
                                            g_fc_bind.down_pos.y - c.y};
            }
            if (g_fc_bind.dragging) {
                g_state.fc_bind_x =
                    ImClamp(p.x - g_fc_bind.grab_off.x, mx, sw - mx) / sw;
                g_state.fc_bind_y =
                    ImClamp(p.y - g_fc_bind.grab_off.y, my, sh - my) / sh;
            }
        } else {
            const double now = ImGui::GetTime();
            const bool tap = !g_fc_bind.dragging &&
                             g_fc_bind.drift2 <= 24.f * 24.f &&
                             now - g_fc_bind.down_time < 0.45;
            const bool moved = g_fc_bind.drift2 > 24.f * 24.f;
            g_fc_bind.finger = -1;
            g_fc_bind.dragging = false;
            if (tap) {
                g_state.memory_freecam = !g_state.memory_freecam;
                char buf[160]{};
                snprintf(buf, sizeof(buf), xv::StrStable(xv::sid::kMiSS), g_Lang->freecam,
                         g_state.memory_freecam ? "ON"
                                                : xv::StrStable(xv::sid::kMiOFF));
                ShowToast(buf);
                PlaySound(SND_CLICK);
                g_fc_bind.pulse = 1.f;
            } else if (moved) {
                g_fc_bind.pulse = 0.4f;
            }
        }
    } else {
        const float hx = r * 1.15f;
        const float hy = r * 1.05f;
        for (int i = 0; i < count; ++i) {
            const float dx = xs[i] - c.x;
            const float dy = ys[i] - c.y;
            if (dx * dx / (hx * hx) + dy * dy / (hy * hy) <= 1.f) {
                g_fc_bind.finger = ids[i];
                g_fc_bind.down_pos = {xs[i], ys[i]};
                g_fc_bind.down_time = ImGui::GetTime();
                g_fc_bind.drift2 = 0.f;
                break;
            }
        }
    }
    Tick(g_fc_bind.press, g_fc_bind.finger >= 0, dt, 16.f);

    const bool on = g_state.memory_freecam;
    auto* fg = ImGui::GetForegroundDrawList();
    const float s = (1.f - 0.08f * g_fc_bind.press +
                     (g_fc_bind.dragging ? 0.05f : 0.f)) *
                    (1.f + 0.06f * g_fc_bind.pulse);
    const float hw = r * 0.90f * s;
    const float hh = r * 0.82f * s;
    const float rnd = r * 0.30f * s;
    const ImVec2 bmin{c.x - hw, c.y - hh};
    const ImVec2 bmax{c.x + hw, c.y + hh};

    fg->AddRectFilled({bmin.x + 3.f, bmin.y + 5.f}, {bmax.x + 3.f, bmax.y + 5.f},
                      IM_COL32(0, 0, 0, 100), rnd + 2.f);
    if (on) {
        fg->AddRectFilled({bmin.x - 4.f, bmin.y - 4.f}, {bmax.x + 4.f, bmax.y + 4.f},
                          C::UA(C::Acc(), 0.32f), rnd + 5.f);
        fg->AddRect({bmin.x - 8.f, bmin.y - 8.f}, {bmax.x + 8.f, bmax.y + 8.f},
                    C::UA(C::Acc(), 0.50f), rnd + 8.f, 0, 2.6f);
    }
    fg->AddRectFilled(bmin, bmax, C::UA(C::Card(), 0.92f), rnd);
    if (on)
        fg->AddRect(bmin, bmax, C::UA(C::Acc(), 0.95f), rnd, 0, 3.0f);
    else
        fg->AddRect(bmin, bmax, C::UA(C::Sep(), 0.95f), rnd, 0, 1.6f);

    const float er = r * 0.54f * s;
    const float ey = er * 0.50f;
    const float alp = asinf(0.50f);
    const float thk = 3.0f;
    const ImU32 ew = C::UA(C::Txt(), 0.90f);
    fg->PathArcTo(ImVec2{c.x, c.y + ey}, er, IM_PI + alp, 2.f * IM_PI - alp, 28);
    fg->PathStroke(ew, thk);
    fg->PathArcTo(ImVec2{c.x, c.y - ey}, er, alp, IM_PI - alp, 28);
    fg->PathStroke(ew, thk);
    const float tip_x = 0.8352f * er;
    fg->AddCircleFilled(ImVec2{c.x - tip_x, c.y}, thk * 0.5f, ew, 16);
    fg->AddCircleFilled(ImVec2{c.x + tip_x, c.y}, thk * 0.5f, ew, 16);
    fg->AddCircle(c, er * 0.42f, ew, 40, thk * 0.85f);
    fg->AddCircleFilled(c, er * 0.22f, ew, 24);
}

static void FreecamControls(float dt) {
    static float yaw_target = 0.f;
    static float pitch_target = 0.f;
    static bool look_synced = false;

    if (!g_state.memory_freecam) {
        Touch_SetGamePassthrough(true);
        memory_freecam_update(false, nullptr, nullptr, nullptr);
        FreecamSticksReset();
        look_synced = false;
        return;
    }

    const bool attached = g_esp_attached.load();
    Touch_SetGamePassthrough(!attached);
    if (!attached) {
        FreecamSticksReset();
        return;
    }

    memory_freecam_update(true, g_freecam_pos, &g_freecam_yaw,
                          &g_freecam_pitch);

    if (dt > 0.05f) dt = 0.05f;
    if (menu_open) {
        FreecamSticksReset();
        return;
    }

    if (!look_synced) {
        yaw_target = g_freecam_yaw;
        pitch_target = g_freecam_pitch;
        look_synced = true;
    }

    float sw, sh;
    OverlayScreenSize(sw, sh);
    const float stick_r = ImClamp(sh * 0.115f, 62.f, 150.f);
    const float knob_r = stick_r * 0.44f;
    const float travel = stick_r * 0.60f;
    const float edge = ImClamp(sh * 0.12f, 46.f, 170.f);
    const ImVec2 move_home{edge + stick_r, sh - edge - stick_r};
    const ImVec2 look_home{sw - edge - stick_r, sh - edge - stick_r};

    int ids[16]{};
    float xs[16]{}, ys[16]{};
    const int count = Touch_GetPointers(ids, xs, ys, 16);

    static int prev_ids[16] = {-1};
    static float prev_xs[16]{}, prev_ys[16]{};
    static int prev_count = 0;

    auto finger_pos = [&](int id, ImVec2& out) {
        for (int i = 0; i < count; ++i) {
            if (ids[i] == id) {
                out = ImVec2{xs[i], ys[i]};
                return true;
            }
        }
        return false;
    };

    auto prev_pos = [&](int id, ImVec2& out) {
        for (int i = 0; i < prev_count; ++i) {
            if (prev_ids[i] == id) {
                out = ImVec2{prev_xs[i], prev_ys[i]};
                return true;
            }
        }
        return false;
    };

    auto bound = [&](int id) {
        return g_fc_move.finger == id || g_fc_look.finger == id ||
               g_fc_bind.finger == id;
    };

    {
        ImVec2 pos{};
        if (g_fc_move.finger >= 0 && !finger_pos(g_fc_move.finger, pos))
            g_fc_move.finger = -1;
        if (g_fc_look.finger >= 0 && !finger_pos(g_fc_look.finger, pos))
            g_fc_look.finger = -1;
    }

    for (int i = 0; i < count; ++i) {
        if (bound(ids[i])) continue;
        const ImVec2 p{xs[i], ys[i]};
        if (g_fc_move.finger < 0 && p.x <= sw * 0.46f && p.y >= sh * 0.28f) {
            g_fc_move.finger = ids[i];
            g_fc_move.center = FreecamStickClampCenter(p, stick_r, sw, sh);
            g_fc_move.offset = ImVec2{0.f, 0.f};
        } else if (g_fc_look.finger < 0 && p.x >= sw * 0.54f &&
                   p.y >= sh * 0.28f) {
            g_fc_look.finger = ids[i];
            g_fc_look.center = FreecamStickClampCenter(p, stick_r, sw, sh);
            g_fc_look.offset = ImVec2{0.f, 0.f};
        }
    }

    auto stick_axis = [&](const ImVec2& offset) {
        auto dz = [](float v) {
            const float dead = 0.13f;
            if (fabsf(v) < dead) return 0.f;
            const float sign = v > 0.f ? 1.f : -1.f;
            return (v - sign * dead) / (1.f - dead);
        };
        return ImVec2{dz(offset.x / travel), dz(offset.y / travel)};
    };

    if (g_fc_move.finger >= 0) {
        ImVec2 pos{};
        if (finger_pos(g_fc_move.finger, pos)) {
            ImVec2 delta{pos.x - g_fc_move.center.x,
                         pos.y - g_fc_move.center.y};
            const float len = sqrtf(delta.x * delta.x + delta.y * delta.y);
            if (len > travel) {
                delta.x *= travel / len;
                delta.y *= travel / len;
            }
            g_fc_move.offset = delta;
        } else {
            g_fc_move.finger = -1;
        }
    }
    if (g_fc_move.finger < 0) {
        const float k = ImMin(1.f, 16.f * dt);
        g_fc_move.offset.x -= g_fc_move.offset.x * k;
        g_fc_move.offset.y -= g_fc_move.offset.y * k;
        if (fabsf(g_fc_move.offset.x) < 0.3f) g_fc_move.offset.x = 0.f;
        if (fabsf(g_fc_move.offset.y) < 0.3f) g_fc_move.offset.y = 0.f;
    }

    if (g_fc_look.finger >= 0) {
        ImVec2 pos{};
        if (finger_pos(g_fc_look.finger, pos)) {
            ImVec2 was{};
            if (prev_pos(g_fc_look.finger, was)) {
                const float dx = pos.x - was.x;
                const float dy = pos.y - was.y;
                if (std::isfinite(dx) && std::isfinite(dy)) {
                    yaw_target += dx * 0.24f;
                    pitch_target -= dy * 0.24f;
                }
            }
            ImVec2 delta{pos.x - g_fc_look.center.x,
                         pos.y - g_fc_look.center.y};
            const float len = sqrtf(delta.x * delta.x + delta.y * delta.y);
            if (len > travel) {
                g_fc_look.center.x = pos.x - (delta.x / len) * travel;
                g_fc_look.center.y = pos.y - (delta.y / len) * travel;
                g_fc_look.center = FreecamStickClampCenter(
                    g_fc_look.center, stick_r, sw, sh);
                delta.x = pos.x - g_fc_look.center.x;
                delta.y = pos.y - g_fc_look.center.y;
            }
            g_fc_look.offset = delta;
        } else {
            g_fc_look.finger = -1;
        }
    }
    if (g_fc_look.finger < 0) {
        const float k = ImMin(1.f, 22.f * dt);
        g_fc_look.offset.x -= g_fc_look.offset.x * k;
        g_fc_look.offset.y -= g_fc_look.offset.y * k;
        if (fabsf(g_fc_look.offset.x) < 0.3f) g_fc_look.offset.x = 0.f;
        if (fabsf(g_fc_look.offset.y) < 0.3f) g_fc_look.offset.y = 0.f;
    }

    for (int i = 0; i < count; ++i) {
        if (bound(ids[i])) continue;
        const ImVec2 p{xs[i], ys[i]};
        ImVec2 was{};
        if (!prev_pos(ids[i], was)) continue;
        const float dx = p.x - was.x;
        const float dy = p.y - was.y;
        if (std::isfinite(dx) && std::isfinite(dy)) {
            yaw_target += dx * 0.24f;
            pitch_target -= dy * 0.24f;
        }
    }

    if (pitch_target > 89.f) pitch_target = 89.f;
    if (pitch_target < -89.f) pitch_target = -89.f;
    if (!std::isfinite(yaw_target)) yaw_target = 0.f;
    if (!std::isfinite(pitch_target)) pitch_target = 0.f;

    {
        const float k = 1.f - expf(-40.f * dt);
        g_freecam_yaw += (yaw_target - g_freecam_yaw) * k;
        g_freecam_pitch += (pitch_target - g_freecam_pitch) * k;
    }
    if (g_freecam_pitch > 89.f) g_freecam_pitch = 89.f;
    if (g_freecam_pitch < -89.f) g_freecam_pitch = -89.f;
    if (!std::isfinite(g_freecam_yaw)) g_freecam_yaw = 0.f;

    const ImVec2 move_axis = stick_axis(g_fc_move.offset);
    float mf = -move_axis.y;
    float ms = move_axis.x;
    const float hl = sqrtf(mf * mf + ms * ms);
    if (hl > 1.f) { mf /= hl; ms /= hl; }

    if (mf != 0.f || ms != 0.f) {
        const float speed = std::max(1.f, std::min(60.f, g_state.freecam_speed));
        const float k = 3.14159265f / 180.f;
        const float yaw = g_freecam_yaw * k;
        const float pitch = g_freecam_pitch * k;
        const float cp = cosf(pitch);
        const float fwd[3] = {cp * sinf(yaw), sinf(pitch), cp * cosf(yaw)};
        const float right[3] = {cosf(yaw), 0.f, -sinf(yaw)};
        const float step = speed * dt;
        g_freecam_pos[0] += (fwd[0] * mf + right[0] * ms) * step;
        g_freecam_pos[1] += fwd[1] * mf * step;
        g_freecam_pos[2] += (fwd[2] * mf + right[2] * ms) * step;
    }

    prev_count = ImMin(count, 16);
    for (int i = 0; i < prev_count; ++i) {
        prev_ids[i] = ids[i];
        prev_xs[i] = xs[i];
        prev_ys[i] = ys[i];
    }

    auto* fg = ImGui::GetForegroundDrawList();
    FreecamDrawStick(fg, g_fc_move.finger >= 0 ? g_fc_move.center : move_home,
                     stick_r, knob_r, g_fc_move.offset,
                     g_fc_move.finger >= 0);
    FreecamDrawStick(fg, g_fc_look.finger >= 0 ? g_fc_look.center : look_home,
                     stick_r, knob_r, g_fc_look.offset,
                     g_fc_look.finger >= 0);

    ImFont* fn = ImGui::GetFont();
    const float label_fs = ImClamp(sh * 0.026f, 17.f, 26.f);
    auto label = [&](const char* text, const ImVec2& anchor) {
        ImVec2 ts = fn->CalcTextSizeA(label_fs, FLT_MAX, 0.f, text);
        const float lx = anchor.x - ts.x * 0.5f;
        const float ly = anchor.y - ts.y * 0.5f;
        fg->AddText(fn, label_fs, {lx + 1.f, ly + 1.f},
                    IM_COL32(0, 0, 0, 130), text);
        fg->AddText(fn, label_fs, {lx, ly}, C::UA(C::Txt(), 0.68f), text);
    };
    if (g_fc_move.finger < 0) label(g_Lang->fc_move, move_home);
    if (g_fc_look.finger < 0) label(g_Lang->fc_look, look_home);
}
bool CollapsibleHeader(const char* id, const char* lbl, int secId = 0) {
    auto* dl  = ImGui::GetWindowDrawList();
    float avW = ImGui::GetContentRegionAvail().x;
    const float rowH = Layout::RowH, inset = Layout::Inset, padX = Layout::PadX;
    auto pos = ImGui::GetCursorScreenPos();

    dl->AddRectFilled({pos.x + inset, pos.y}, {pos.x + avW - inset, pos.y + rowH}, C::U(C::Card()), R::Card);
    if (g_state.ui_show_sep)
        dl->AddRect({pos.x + inset, pos.y}, {pos.x + avW - inset, pos.y + rowH}, C::U(C::Sep()), R::Card, 1.2f);

    ImGui::InvisibleButton(id, {avW, rowH});
    bool clicked = WasTappedHere() && !IsScrollDragging() && !g_input.touchConsumed;

    float fs    = ImGui::GetFontSize() * 1.15f;
    float textY = pos.y + (rowH - fs) * 0.5f;
    dl->AddText(ImGui::GetFont(), fs, {pos.x + inset + padX, textY}, C::U(C::Txt()), lbl);

    const float cBtnR = 22.f;
    float cx2 = pos.x + avW - inset - cBtnR - padX * 0.5f, cy2 = pos.y + rowH * 0.5f;
    dl->AddCircleFilled({cx2, cy2}, cBtnR, C::U(C::Acc()), 48);
    {
        float t = EaseInOut(g_themeT);
        ImU32 ringCol = IM_COL32(
            int(Lerpf(0,   255, t)),
            int(Lerpf(50,  255, t)),
            int(Lerpf(170, 255, t)),
            int(Lerpf(130,  60, t))
        );
        dl->AddCircle({cx2, cy2}, cBtnR + 2.5f, ringCol, 48, 1.5f);
    }

    float chs = 10.f, thk = 3.f;
    dl->AddLine({cx2 - chs * 0.45f, cy2 - chs * 0.8f}, {cx2 + chs * 0.55f, cy2}, IM_COL32(255, 255, 255, 250), thk);
    dl->AddLine({cx2 + chs * 0.55f, cy2}, {cx2 - chs * 0.45f, cy2 + chs * 0.8f}, IM_COL32(255, 255, 255, 250), thk);

    if (clicked && !(g_pop.visible && !g_pop.closing)) {
        PopoverOpen(lbl, secId);
        g_popOpenClickPos = ImGui::GetIO().MousePos;
        PlaySound(SND_CLICK);
    }
    return clicked;
}

static bool TickSlideAnim(float& anim, float& vel, bool closing, float dt) {
    if (dt > 0.032f) dt = 0.032f;
    const float stiff = 120.f, damp = 22.f;
    if (!closing) {
        float acc = (1.f - anim) * stiff - vel * damp;
        vel  += acc * dt;
        anim += vel * dt;
        if (anim >= 0.9998f) { anim = 1.f; vel = 0.f; }
        anim = ImClamp(anim, 0.f, 1.f);
        return true;
    } else {
        float acc = (0.f - anim) * stiff - vel * damp;
        vel  += acc * dt;
        anim += vel * dt;
        if (anim <= 0.001f) { anim = 0.f; vel = 0.f; return false; }
        anim = ImClamp(anim, 0.f, 1.f);
        return true;
    }
}

static void RequestExit() {
    PopoverReset();
    main_thread_flag = false;
}

static void DrawExitButtons(ImDrawList* fg, ImFont* fn, float fs, float alpha,
                             float b1X, float b2X, float bW, float bY, float btnH,
                             bool blocked,
                             const ImVec2& mousePos, const ImVec2& clickedPos,
                             bool mouseReleased) {
    fg->AddRectFilled({b1X, bY}, {b1X + bW, bY + btnH}, C::UA(C::Txt(), 0.08f * alpha), R::Btn);
    fg->AddRectFilled({b2X, bY}, {b2X + bW, bY + btnH}, C::UA(C::Red(), alpha), R::Btn);
    if (g_state.ui_show_sep) {
        fg->AddRect({b1X, bY}, {b1X + bW, bY + btnH}, C::UA(C::Txt(), 0.22f * alpha), R::Btn, 1.2f);
        fg->AddRect({b2X, bY}, {b2X + bW, bY + btnH}, C::UA(C::Txt(), 0.22f * alpha), R::Btn, 1.2f);
    }
    auto c1Sz = fn->CalcTextSizeA(fs * 1.15f, FLT_MAX, 0, g_Lang->cancel);
    auto c2Sz = fn->CalcTextSizeA(fs * 1.15f, FLT_MAX, 0, g_Lang->exit_btn);
    fg->AddText(fn, fs * 1.15f, {b1X + bW * 0.5f - c1Sz.x * 0.5f, bY + (btnH - fs * 1.15f) * 0.5f},
        C::UA(C::Txt(), alpha), g_Lang->cancel);
    fg->AddText(fn, fs * 1.15f, {b2X + bW * 0.5f - c2Sz.x * 0.5f, bY + (btnH - fs * 1.15f) * 0.5f},
        IM_COL32(255, 255, 255, int(255 * alpha)), g_Lang->exit_btn);
    if (!blocked && mouseReleased) {
        bool dH1 = clickedPos.x >= b1X && clickedPos.x <= b1X+bW && clickedPos.y >= bY && clickedPos.y <= bY+btnH;
        bool dH2 = clickedPos.x >= b2X && clickedPos.x <= b2X+bW && clickedPos.y >= bY && clickedPos.y <= bY+btnH;
        bool uH1 = mousePos.x >= b1X && mousePos.x <= b1X+bW && mousePos.y >= bY && mousePos.y <= bY+btnH;
        bool uH2 = mousePos.x >= b2X && mousePos.x <= b2X+bW && mousePos.y >= bY && mousePos.y <= bY+btnH;
        if (uH1 && dH1) PopoverClose();
        if (uH2 && dH2) RequestExit();
    }
}

static float DrawPopoverContentFG(ImDrawList* fg, ImFont* fn, float fs, int secId, float dt,
                                   float cX, float cW, float curY, float alpha,
                                   bool blocked, const ImVec2& mousePos, const ImVec2& clickedPos,
                                   bool mouseReleased, bool mouseDown)
{
    const float inset = Layout::Inset, padX = Layout::PadX;
    const float rH = Layout::RowH;

    auto FgSHdr = [&](const char* t, float topPad = 18.f) {
        curY += topPad;
        if (t && t[0]) {
            auto tsz = fn->CalcTextSizeA(fs * 1.15f, FLT_MAX, 0, t);
            fg->AddText(fn, fs * 1.15f, {cX + 32.f, curY}, C::UA(C::Dim(), alpha), t);
            curY += tsz.y + 8.f;
        } else {
            curY += 8.f;
        }
    };

    auto FgCardBg = [&](float h, ImDrawFlags flags = ImDrawFlags_RoundCornersAll) {
        fg->AddRectFilled({cX + inset, curY}, {cX + cW - inset, curY + h}, C::UA(C::Card(), alpha), R::Card, flags);
        if (g_state.ui_show_sep)
            fg->AddRect({cX + inset, curY}, {cX + cW - inset, curY + h}, C::UA(C::Sep(), alpha), R::Card, 1.2f, flags);
    };

    auto FgRadioRow = [&](int idx, int* current, float* fillAnim,
                           const char* label, bool last) {
        const bool selected = (*current == idx);
        const float fill = EaseInOut(ImClamp(*fillAnim, 0.f, 1.f));
        const float rowX0 = cX + inset;
        const float rowX1 = cX + cW - inset;

        if (!blocked && !g_scrollPop.dragging && mouseReleased
            && mousePos.x >= rowX0 && mousePos.x <= rowX1
            && mousePos.y >= curY && mousePos.y <= curY + rH
            && clickedPos.x >= rowX0 && clickedPos.x <= rowX1
            && clickedPos.y >= curY && clickedPos.y <= curY + rH
            && !selected) {
            *current = idx;
            PlaySound(SND_CLICK);
            g_input.touchConsumed = true;
        }

        if (fill > 0.001f) {
            fg->AddRectFilled({rowX0 + 5.f, curY + 5.f},
                              {rowX1 - 5.f, curY + rH - 5.f},
                              C::UA(C::Acc(), 0.075f * fill * alpha), R::Pill);
            fg->AddRectFilled({rowX0 + 5.f, curY + 20.f},
                              {rowX0 + 9.f, curY + rH - 20.f},
                              C::UA(C::Acc(), fill * alpha), 2.f);
        }

        const float textX = cX + inset + padX;
        const float textY = curY + (rH - fs * 1.15f) * 0.5f;
        const float radioR = 19.f;
        const float radioX = cX + cW - inset - radioR - padX;
        const float radioY = curY + rH * 0.5f;
        const float textMaxX = radioX - radioR - 16.f;
        fg->PushClipRect({textX, curY}, {textMaxX, curY + rH}, true);
        ImVec4 textColor = {
            Lerpf(C::Txt().x, C::Acc().x, fill * 0.55f),
            Lerpf(C::Txt().y, C::Acc().y, fill * 0.55f),
            Lerpf(C::Txt().z, C::Acc().z, fill * 0.55f),
            alpha
        };
        fg->AddText(fn, fs * 1.15f, {textX, textY}, C::U(textColor), label);
        fg->PopClipRect();

        ImVec4 outer = {
            Lerpf(C::TrkOff().x, C::Acc().x, fill),
            Lerpf(C::TrkOff().y, C::Acc().y, fill),
            Lerpf(C::TrkOff().z, C::Acc().z, fill),
            alpha
        };
        fg->AddCircleFilled({radioX, radioY}, radioR, C::U(outer), 40);
        fg->AddCircle({radioX, radioY}, radioR,
                      C::UA(C::Sep(), (1.f - fill) * alpha), 40, 1.5f);
        if (fill > 0.001f)
            fg->AddCircleFilled({radioX, radioY}, 7.5f * fill,
                                IM_COL32(255, 255, 255, int(255.f * fill * alpha)), 32);

        if (!last && g_state.ui_show_sep)
            fg->AddLine({cX + inset + padX, curY + rH - 0.5f},
                        {cX + cW - inset - padX, curY + rH - 0.5f},
                        C::UA(C::Sep(), alpha), 0.8f);
        curY += rH;
    };

    auto FgSliderRow = [&](const char* lbl, float* v, float mn, float mx, const char* fmt,
                            bool last, AppState::SliderAnim& anim) {
        const float rowH = Layout::SliderH;
        float cX2 = cX + inset, cW2 = cW - inset * 2.f;

        bool act = !blocked && mouseDown && !g_scrollPop.dragging
            && clickedPos.x >= cX2 && clickedPos.x <= cX2 + cW2
            && clickedPos.y >= curY && clickedPos.y <= curY + rowH
            && mousePos.y >= curY - 20.f && mousePos.y <= curY + rowH + 20.f;

        if (act)
            *v = mn + Clamp01((mousePos.x - (cX2 + padX + 22.f)) / (cW2 - padX * 2.f - 44.f)) * (mx - mn);

        float target = Clamp01((*v - mn) / (mx - mn));
        TickSliderAnim(anim, target, act, dt);

        RenderSliderVisuals(fg, fn, fs, cX, curY, cW, rowH,
                            lbl, fmt, *v, anim.pos, act, alpha,
                            g_state.ui_show_sep, last);
        curY += rowH;
    };

    if (secId == 0) {
        FgSHdr(g_Lang->aim_mode_hdr);
        FgCardBg(rH);
        {
            float cardX = cX + inset;
            float cardW = cW - inset * 2.0f;
            float gap = 10.0f;
            float pad = 10.0f;
            float buttonW = (cardW - pad * 2.0f - gap) * 0.5f;
            float buttonH = rH - pad * 2.0f;
            float buttonY = curY + pad;

            auto AimModeButton = [&](float x, const char* label, bool* value,
                                     bool other_enabled, float anim) {
                float t = EaseInOut(anim);
                ImVec4 base = C::Sep();
                ImVec4 accent = C::Acc();
                ImVec4 fill = {
                    Lerpf(base.x, accent.x, t), Lerpf(base.y, accent.y, t),
                    Lerpf(base.z, accent.z, t), Lerpf(0.32f, 1.0f, t) * alpha
                };
                fg->AddRectFilled({x, buttonY}, {x + buttonW, buttonY + buttonH},
                                  C::U(fill), R::Btn);
                if (g_state.ui_show_sep)
                    fg->AddRect({x, buttonY}, {x + buttonW, buttonY + buttonH},
                                C::UA(C::Sep(), alpha), R::Btn, 1.0f);
                ImVec2 textSize = fn->CalcTextSizeA(fs * 1.02f, FLT_MAX, 0, label);
                ImVec4 textColor = t > 0.5f ? ImVec4(1,1,1,1) : C::Dim();
                fg->AddText(fn, fs * 1.02f,
                    {x + (buttonW - textSize.x) * 0.5f,
                     buttonY + (buttonH - textSize.y) * 0.5f},
                    C::UA(textColor, alpha), label);

                bool clicked = !blocked && !g_scrollPop.dragging && mouseReleased &&
                    mousePos.x >= x && mousePos.x <= x + buttonW &&
                    mousePos.y >= buttonY && mousePos.y <= buttonY + buttonH &&
                    clickedPos.x >= x && clickedPos.x <= x + buttonW &&
                    clickedPos.y >= buttonY && clickedPos.y <= buttonY + buttonH;
                if (clicked) {
                    if (!*value || other_enabled) {
                        *value = !*value;
                        PlaySound(SND_CLICK);
                        g_input.touchConsumed = true;
                    }
                }
            };

            float leftX = cardX + pad;
            float rightX = leftX + buttonW + gap;
            AimModeButton(leftX, g_Lang->in_ads, &g_state.aim_ads,
                          g_state.aim_hipfire, g_state.a_aim_ads);
            AimModeButton(rightX, g_Lang->hipfire, &g_state.aim_hipfire,
                          g_state.aim_ads, g_state.a_aim_hipfire);
        }
        curY += rH;

        FgSHdr(g_Lang->bone);
        FgCardBg(rH * 3);
        FgRadioRow(0, &g_state.aim_bone, &g_state.a_aim_head,   g_Lang->bone_head, false);
        FgRadioRow(1, &g_state.aim_bone, &g_state.a_aim_chest,  g_Lang->bone_neck, false);
        FgRadioRow(2, &g_state.aim_bone, &g_state.a_aim_pelvis, g_Lang->bone_chest, true);

    } else if (secId == 1) {
        FgSHdr(g_Lang->appearance);
        FgCardBg(Layout::SliderH);
        FgSliderRow(g_Lang->thickness,   &g_state.esp_thick, 0.5f, 4.f,   xv::StrStable(xv::sid::kMi1f),     true, g_state.sl_esp_thick);

    } else if (secId == 2) {
        FgSHdr(nullptr, 12.f);
        auto dSz = fn->CalcTextSizeA(fs * 1.15f, FLT_MAX, 0, g_Lang->exit_body);
        fg->AddText(fn, fs * 1.15f,
            {cX + (cW - dSz.x) * 0.5f, curY},
            C::UA(C::Dim(), alpha), g_Lang->exit_body);
        curY += dSz.y + 28.f;

        const float btnH = 62.f, bPad = 28.f;
        float bW  = (cW - inset * 2.f - bPad * 2.f - 12.f) * 0.5f;
        float b1X = cX + inset + bPad, b2X = b1X + bW + 12.f;
        DrawExitButtons(fg, fn, fs, alpha,
            b1X, b2X, bW, curY, btnH,
            blocked, mousePos, clickedPos,
            mouseReleased);
        curY += btnH;
    } else if (secId == 3) {
        const char* cfgName = (g_configToDelete >= 0 && g_configToDelete < g_configCount)
            ? g_configs[g_configToDelete].name : g_Lang->config_name;

        FgSHdr(nullptr, 40.f);

        {
            char nameBuf[96];
            snprintf(nameBuf, sizeof(nameBuf), xv::StrStable(xv::sid::kMiU18), cfgName);
            float nameFS = fs * 1.55f;
            auto  nameSz = fn->CalcTextSizeA(nameFS, FLT_MAX, 0, nameBuf);
            fg->AddText(fn, nameFS,
                {cX + (cW - nameSz.x) * 0.5f, curY},
                C::UA(C::Txt(), alpha), nameBuf);
            curY += nameSz.y + 12.f;
        }

        {
            const char* sub = g_Lang->delete_cfg_body;
            auto sSz = fn->CalcTextSizeA(fs * 1.05f, FLT_MAX, 0, sub);
            fg->AddText(fn, fs * 1.05f,
                {cX + (cW - sSz.x) * 0.5f, curY},
                C::UA(C::Red(), alpha * 0.85f), sub);
            curY += sSz.y + 36.f;
        }

        {
            const float btnH = 58.f, bPad = 28.f, gap = 12.f;
            float bW  = (cW - inset * 2.f - bPad * 2.f - gap) * 0.5f;
            float b1X = cX + inset + bPad;
            float b2X = b1X + bW + gap;

            fg->AddRectFilled({b1X, curY}, {b1X + bW, curY + btnH}, C::UA(C::Card(), alpha), R::Btn);
            fg->AddRect({b1X, curY}, {b1X + bW, curY + btnH}, C::UA(C::Sep(), alpha), R::Btn, 1.5f);
            {
                const char* ct = g_Lang->cancel;
                auto ctsz = fn->CalcTextSizeA(fs * 1.1f, FLT_MAX, 0, ct);
                fg->AddText(fn, fs * 1.1f,
                    {b1X + bW * 0.5f - ctsz.x * 0.5f, curY + (btnH - fs * 1.1f) * 0.5f},
                    C::UA(C::Txt(), alpha), ct);
            }

            fg->AddRectFilled({b2X, curY}, {b2X + bW, curY + btnH}, C::UA(C::Red(), alpha * 0.9f), R::Btn);
            fg->AddRect({b2X, curY}, {b2X + bW, curY + btnH}, C::UA(C::Red(), alpha), R::Btn, 1.5f);
            {
                const char* dt2 = g_Lang->delete_btn;
                auto dtsz = fn->CalcTextSizeA(fs * 1.1f, FLT_MAX, 0, dt2);
                fg->AddText(fn, fs * 1.1f,
                    {b2X + bW * 0.5f - dtsz.x * 0.5f, curY + (btnH - fs * 1.1f) * 0.5f},
                    IM_COL32(255, 255, 255, int(255 * alpha)), dt2);
            }

            if (!blocked && mouseReleased) {
                if (mousePos.x >= b1X && mousePos.x <= b1X + bW
                 && mousePos.y >= curY && mousePos.y <= curY + btnH
                 && clickedPos.x >= b1X && clickedPos.x <= b1X + bW
                 && clickedPos.y >= curY && clickedPos.y <= curY + btnH)
                    PopoverClose();

                if (mousePos.x >= b2X && mousePos.x <= b2X + bW
                 && mousePos.y >= curY && mousePos.y <= curY + btnH
                 && clickedPos.x >= b2X && clickedPos.x <= b2X + bW
                 && clickedPos.y >= curY && clickedPos.y <= curY + btnH) {
                    ConfigDelete(g_configToDelete);
                    g_configToDelete = -1;
                    PopoverClose();
                }
            }
            curY += btnH;
        }
    }

    curY += 12.f;
    return curY;
}

void DrawPopover(float dt, ImVec2 menuPos, float WW, float WH) {
    if (!g_pop.visible) return;

    g_pop.openFrames++;

    if (!TickSlideAnim(g_pop.anim, g_pop.vel, g_pop.closing, dt)) {
        PopoverReset();
        g_popOpenClickPos = {-9999.f, -9999.f};
        return;
    }

    auto& io    = ImGui::GetIO();
    float easeT = EaseInOut(g_pop.anim);
    auto* fn    = ImGui::GetFont();
    float fs    = ImGui::GetFontSize();

    float titleFS  = fs * 1.45f;
    float headerH  = 28.f + titleFS + 16.f + 8.f;

    float popW = WW * 0.92f, popH = WH * 0.88f;

    float sX     = menuPos.x + (WW - popW) * 0.5f;
    float sYFull = menuPos.y + (WH - popH) * 0.5f;
    float sY     = Lerpf(menuPos.y + WH, sYFull, easeT);
    float sW = popW, sH = popH;

    float contentY = sY + headerH;
    float areaH    = sH - headerH;
    float lineY    = sY + 28.f + titleFS + 16.f;

    auto* fg = ImGui::GetWindowDrawList();

    Blur::Draw(fg, g_win.pos, {g_win.pos.x+g_win.w, g_win.pos.y+g_win.h}, easeT, R::Card);

    fg->PushClipRect({menuPos.x, menuPos.y}, {menuPos.x + WW, menuPos.y + WH}, true);

    fg->AddRectFilled({sX, sY}, {sX + sW, sY + sH}, C::U(C::Bg()), R::Sheet);

    {
        float dhW = 72.f, dhH = 7.f;
        float dhX = sX + sW * 0.5f - dhW * 0.5f, dhY = sY + 14.f;
        fg->AddRectFilled({dhX, dhY}, {dhX + dhW, dhY + dhH},
            C::UA(C::Dim(), 0.45f * easeT), dhH * 0.5f);
        if (io.MouseClicked[0]
            && io.MousePos.x >= sX && io.MousePos.x <= sX + sW
            && io.MousePos.y >= sY && io.MousePos.y <= sY + 44.f) {
            BeginWinDrag(io.MousePos);
        }
    }

    bool inPop = io.MousePos.x >= sX && io.MousePos.x <= sX + sW
              && io.MousePos.y >= contentY && io.MousePos.y <= sY + sH - 4.f;
    bool clickInPop = io.MouseClickedPos[0].x >= sX && io.MouseClickedPos[0].x <= sX + sW
                   && io.MouseClickedPos[0].y >= contentY && io.MouseClickedPos[0].y <= sY + sH - 4.f;
    bool mIn = inPop && clickInPop;

    static float s_popMaxScroll = 0.f;
    bool colorPop = (g_pop.sectionId == 4);
    if (!colorPop) ScrollTick(g_scrollPop, mIn, g_pop.closing, s_popMaxScroll, dt);
    else { g_scrollPop.off = 0.f; g_scrollPop.vel = 0.f; s_popMaxScroll = 0.f; }

    if (colorPop && g_colP) {

        const float PAD   = 16.f;
        const float btnH  = 62.f, btnMar = 10.f;
        float X  = sX + PAD, W = sW - PAD * 2.f;
        float bY = sY + sH - btnH - btnMar;

        const int   COLS     = 7;
        const float CELL_GAP = 10.f;
        int   ROWS   = (kPaletteCount + COLS - 1) / COLS;
        float availH = bY - contentY - 16.f;
        float cellW = (W - CELL_GAP * (COLS - 1)) / (float)COLS;
        float cellH = (availH - CELL_GAP * (ROWS - 1)) / (float)ROWS;
        float cellSz = cellW < cellH ? cellW : cellH;
        if (cellSz < 22.f) cellSz = 22.f;
        float gridW  = COLS * cellSz + (COLS - 1) * CELL_GAP;
        float gridH  = ROWS * cellSz + (ROWS - 1) * CELL_GAP;
        float gridX  = X + (W - gridW) * 0.5f;
        float gridY  = contentY + (bY - contentY - gridH) * 0.5f;
        if (gridY + gridH > bY - 8.f) gridY = bY - 8.f - gridH;
        if (gridY < contentY + 8.f) gridY = contentY + 8.f;
        fg->PushClipRect({sX + 8.f, contentY}, {sX + sW - 8.f, bY - 6.f}, true);

        const float CELL_R = 10.f;

        static int   s_palSel  = -1;
        static float s_selOffX = 0.f, s_selOffY = 0.f;
        static float s_selVelX = 0.f, s_selVelY = 0.f;
        static float s_selSz   = 0.f, s_selVelSz = 0.f;
        if (g_colP) {
            float bestDist = 1e9f;
            int   bestIdx  = -1;
            for (int pi = 0; pi < kPaletteCount; pi++) {
                float dr = kColorPalette[pi].x - g_colP->x;
                float dg = kColorPalette[pi].y - g_colP->y;
                float db = kColorPalette[pi].z - g_colP->z;
                float d  = dr*dr + dg*dg + db*db;
                if (d < bestDist) { bestDist = d; bestIdx = pi; }
            }
            if (bestDist < 0.02f) s_palSel = bestIdx; else s_palSel = -1;
        }

        auto cellCenter = [&](int pi) -> ImVec2 {
            int r = pi / COLS, c = pi % COLS;
            return { c * (cellSz + CELL_GAP) + cellSz * 0.5f,
                     r * (cellSz + CELL_GAP) + cellSz * 0.5f };
        };

        if (s_palSel >= 0) {
            ImVec2 tc = cellCenter(s_palSel);
            if (s_selSz < 0.001f || g_palSelReset) {
                s_selOffX = tc.x; s_selOffY = tc.y;
                s_selVelX = 0.f;  s_selVelY = 0.f;
                if (g_palSelReset) { s_selSz = 1.f; s_selVelSz = 0.f; }
            }
            SpringTick(s_selOffX, s_selVelX, tc.x, dt);
            SpringTick(s_selOffY, s_selVelY, tc.y, dt);
            SpringTick(s_selSz, s_selVelSz, 1.f, dt);
        } else {
            SpringTick(s_selSz, s_selVelSz, 0.f, dt);
        }
        g_palSelReset = false;

        for (int pi = 0; pi < kPaletteCount; pi++) {
            int row = pi / COLS, col = pi % COLS;
            float cx0 = gridX + col * (cellSz + CELL_GAP);
            float cy0 = gridY + row * (cellSz + CELL_GAP);
            float cx1 = cx0 + cellSz, cy1 = cy0 + cellSz;

            ImVec4 cv = kColorPalette[pi];
            ImU32  fill = IM_COL32(int(cv.x*255), int(cv.y*255), int(cv.z*255), 255);

            fg->AddRectFilled({cx0+1.5f, cy0+1.5f}, {cx1+1.5f, cy1+1.5f},
                IM_COL32(0,0,0, int(18*easeT)), CELL_R);
            fg->AddRectFilled({cx0, cy0}, {cx1, cy1}, fill, CELL_R);

            if (!g_pop.closing && io.MouseReleased[0]) {
                ImVec2 mp = io.MousePos, cp = io.MouseClickedPos[0];
                bool hit = mp.x >= cx0 && mp.x <= cx1 && mp.y >= cy0 && mp.y <= cy1
                        && cp.x >= cx0 && cp.x <= cx1 && cp.y >= cy0 && cp.y <= cy1;
                if (hit) {
                    *g_colP = kColorPalette[pi];
                    s_palSel = pi;
                    g_input.touchConsumed = true;
                }
            }
        }

        if (s_selSz > 0.001f) {
            float ax = gridX + s_selOffX, ay = gridY + s_selOffY;
            float r = (cellSz * 0.5f + 5.f) * s_selSz;
            fg->AddRect({ax - r, ay - r}, {ax + r, ay + r},
                IM_COL32(0,0,0, int(220*easeT*s_selSz)), CELL_R + 5.f * s_selSz, 4.f);
            fg->AddRect({ax - r + 2.5f, ay - r + 2.5f}, {ax + r - 2.5f, ay + r - 2.5f},
                IM_COL32(255,255,255, int(255*easeT*s_selSz)), CELL_R + 2.5f * s_selSz, 1.5f);
        }
        fg->PopClipRect();

        fg->AddRectFilled({X, bY}, {X+W, bY+btnH}, C::UA(C::Acc(), easeT), R::Btn);
        auto bsz = fn->CalcTextSizeA(fs*1.2f, FLT_MAX, 0, g_Lang->done);
        fg->AddText(fn, fs*1.2f,
            {X + W*0.5f - bsz.x*0.5f, bY + (btnH-bsz.y)*0.5f},
            IM_COL32(255,255,255,int(255*easeT)), g_Lang->done);

        if (io.MouseDown[0] || io.MouseReleased[0])
            g_input.touchConsumed = true;

        if (!g_pop.closing && io.MouseReleased[0]) {
            ImVec2 mp = io.MousePos, cp = io.MouseClickedPos[0];
            bool doneTap = mp.x >= X && mp.x <= X+W && mp.y >= bY && mp.y <= bY+btnH
                        && cp.x >= X && cp.x <= X+W && cp.y >= bY && cp.y <= bY+btnH;
            if (doneTap) PopoverClose();
        }

    } else {
        fg->PushClipRect({sX, contentY}, {sX + sW, sY + sH - 4.f}, true);

        float drawY = contentY - g_scrollPop.off;
        ImVec2 cp0 = io.MouseClickedPos[0];
        bool cpInMenu = cp0.x >= g_win.pos.x && cp0.x <= g_win.pos.x + g_win.w
                     && cp0.y >= g_win.pos.y && cp0.y <= g_win.pos.y + g_win.h;
        bool touchOnHeader = cp0.y < contentY || io.MousePos.y < contentY;
        bool popBlocked = g_pop.closing || !cpInMenu || touchOnHeader;
        float endY  = DrawPopoverContentFG(fg, fn, fs, g_pop.sectionId, dt,
                                            sX, sW, drawY, easeT,
                                            popBlocked,
                                            io.MousePos, cp0,
                                            io.MouseReleased[0] && !g_scrollPop.dragging,
                                            io.MouseDown[0] && cpInMenu && !touchOnHeader);

        float contentTotalH = endY - drawY;
        s_popMaxScroll = ImMax(0.f, contentTotalH - (areaH - 4.f));

        fg->PopClipRect();
    }

    {
        auto tsz = fn->CalcTextSizeA(titleFS, FLT_MAX, 0, g_pop.title);
        fg->AddText(fn, titleFS,
            {sX + sW * 0.5f - tsz.x * 0.5f, sY + 28.f},
            C::UA(C::Txt(), easeT), g_pop.title);
    }
    {
        float cR = 26.f, bcx = sX + sW - cR - 16.f, bcy = sY + 28.f + titleFS * 0.5f;
        fg->AddCircleFilled({bcx, bcy}, cR, C::UA(C::Sep(), easeT), 32);
        float cs = 9.f;
        fg->AddLine({bcx-cs, bcy-cs}, {bcx+cs, bcy+cs}, C::UA(C::Dim(), easeT), 3.2f);
        fg->AddLine({bcx+cs, bcy-cs}, {bcx-cs, bcy+cs}, C::UA(C::Dim(), easeT), 3.2f);

        if (!g_pop.closing && (io.MouseClicked[0] || io.MouseReleased[0])
            && fabsf(io.MousePos.x - bcx) < cR + 14.f
            && fabsf(io.MousePos.y - bcy) < cR + 14.f) {
            if (io.MouseReleased[0]) PopoverClose();
            g_input.touchConsumed = true;
        }
    }
    fg->AddLine({sX + 18.f, lineY}, {sX + sW - 18.f, lineY}, C::UA(C::Sep(), easeT), 2.5f);

    fg->PopClipRect();
}

float TabContent(int tab, float dt, float) {
    float sY = ImGui::GetCursorPosY();

    if (tab == 0) {

        SHdr(g_Lang->tab_main);
        {
            auto* dl  = ImGui::GetWindowDrawList();
            auto* fn  = ImGui::GetFont();
            float avW = ImGui::GetContentRegionAvail().x;
            const float inset = Layout::Inset, padX = Layout::PadX;
            const float fs = ImGui::GetFontSize();
            const float cardH = 168.f;
            auto pos = ImGui::GetCursorScreenPos();
            float cx0 = pos.x + inset, cx1 = pos.x + avW - inset;

            ImVec4 ac = C::Acc();
            ImVec4 bg = C::Card();
            float mix = g_darkTheme ? 0.10f : 0.05f;
            ImU32 fill = IM_COL32(
                int(bg.x*255*(1.f-mix) + ac.x*255*mix),
                int(bg.y*255*(1.f-mix) + ac.y*255*mix),
                int(bg.z*255*(1.f-mix) + ac.z*255*mix), 255);
            dl->AddRectFilled({cx0, pos.y}, {cx1, pos.y + cardH}, fill, R::Card);
            dl->AddRect({cx0, pos.y}, {cx1, pos.y + cardH},
                        C::UA(ac, 0.45f), R::Card, 1.6f);

            float nameFS = fs * 1.18f;
            float subFS  = fs * 0.86f;
            float blockH = nameFS + 6.f + subFS;
            float tY = pos.y + (cardH - 70.f - blockH) * 0.5f;
            dl->AddText(fn, nameFS, {cx0 + padX, tY}, C::U(C::Txt()), xv::StrStable(xv::sid::kMiAceCrack));
            dl->AddText(fn, subFS, {cx0 + padX, tY + nameFS + 6.f},
                        C::U(C::Dim()), g_Lang->tg_channel);

            const float btnH = 54.f;
            float bY = pos.y + cardH - btnH - 16.f;
            float bX0 = cx0 + padX, bX1 = cx1 - padX;
            dl->AddRectFilled({bX0, bY}, {bX1, bY + btnH}, C::U(ac), R::Btn);
            const char* btnTxt = g_Lang->tg_open;
            float btnFS = fs * 1.05f;
            auto bts = fn->CalcTextSizeA(btnFS, FLT_MAX, 0, btnTxt);
            dl->AddText(fn, btnFS,
                        {(bX0 + bX1 - bts.x) * 0.5f, bY + (btnH - bts.y) * 0.5f},
                        IM_COL32(255,255,255,255), btnTxt);

            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiTgOpen), {avW, cardH});
            if (WasTappedHere() && !IsScrollDragging() && !g_input.touchConsumed) {
                ImVec2 mp = ImGui::GetIO().MousePos;
                if (mp.x >= bX0 && mp.x <= bX1 && mp.y >= bY && mp.y <= bY + btnH) {
                    system(xv::StrC(xv::sid::kTelegramCmd));
                    ShowToast(g_Lang->tg_opening);
                    PlaySound(SND_SUCCESS);
                }
            }
        }

        SHdr(g_Lang->about);
        {
            auto* dl  = ImGui::GetWindowDrawList();
            auto* fn  = ImGui::GetFont();
            float avW = ImGui::GetContentRegionAvail().x;
            const float inset = Layout::Inset, padX = Layout::PadX;
            const float fs = ImGui::GetFontSize();
            const float rowH = 64.f;
            struct InfoRow { const char* k; const char* v; };
            InfoRow rows[] = {
                {g_Lang->online_label, nullptr},
            };
            const int n = (int)(sizeof(rows) / sizeof(rows[0]));
            auto pos = ImGui::GetCursorScreenPos();
            float cx0 = pos.x + inset, cx1 = pos.x + avW - inset;
            dl->AddRectFilled({cx0, pos.y}, {cx1, pos.y + rowH * n},
                              C::U(C::Card()), R::Card);
            if (g_state.ui_show_sep)
                dl->AddRect({cx0, pos.y}, {cx1, pos.y + rowH * n},
                            C::U(C::Sep()), R::Card, 1.2f);
            float kFS = fs * 1.02f;
            const int online_raw = AuthGetOnlineCount();
            const bool online_known = online_raw >= 0;
            static float online_known_t = 0.f;
            static float online_pulse = 0.f;
            static int online_prev = -1;
            static float online_flash = 0.f;
            static float online_flash_dir = 0.f;
            const float adt = ImClamp(dt, 0.f, 0.05f);
            online_known_t += ((online_known ? 1.f : 0.f) - online_known_t) * 10.f * adt;
            online_pulse += adt * 2.2f;
            if (online_pulse > 1.f) online_pulse -= 1.f;
            if (online_known) {
                if (online_prev >= 0 && online_raw != online_prev) {
                    online_flash = 1.f;
                    online_flash_dir = online_raw > online_prev ? 1.f : -1.f;
                }
                online_prev = online_raw;
                TickRollingCounter(wm_online_counter, online_raw, dt);
            } else {
                online_prev = -1;
            }
            online_flash = ImMax(0.f, online_flash - adt * 1.6f);
            for (int i = 0; i < n; ++i) {
                float ry = pos.y + rowH * i;
                float ty = ry + (rowH - kFS) * 0.5f;
                dl->AddText(fn, kFS, {cx0 + padX, ty}, C::U(C::Dim()), rows[i].k);
                if (rows[i].v) {
                    auto vs = fn->CalcTextSizeA(kFS, FLT_MAX, 0, rows[i].v);
                    ImU32 vc = C::U(C::Txt());
                    dl->AddText(fn, kFS, {cx1 - padX - vs.x, ty}, vc, rows[i].v);
                } else {
                    const float cy = ry + rowH * 0.5f;
                    const float slot_w = fn->CalcTextSizeA(kFS, FLT_MAX, 0, xv::StrStable(xv::sid::kMi999)).x + 6.f;
                    const float slot_cx = cx1 - padX - slot_w * 0.5f;
                    const ImVec4 dot_accent = C::Acc();
                    const ImVec4 up_col = dot_accent;
                    const ImVec4 down_col = C::Red();
                    ImVec4 value_col = C::Txt();
                    if (online_flash > 0.001f) {
                        const float ft = EaseOut3(online_flash);
                        const ImVec4 tint = online_flash_dir > 0.f ? up_col : down_col;
                        value_col = {Lerpf(value_col.x, tint.x, ft), Lerpf(value_col.y, tint.y, ft),
                                     Lerpf(value_col.z, tint.z, ft), 1.f};
                    }
                    const float dot_r = 5.f;
                    const float dot_x = slot_cx - slot_w * 0.5f - 14.f;
                    const float ring_t = EaseOut3(online_pulse);
                    const ImVec4 dot_col = online_known ? dot_accent : C::Dim();
                    if (online_known)
                        dl->AddCircle({dot_x, cy}, dot_r + ring_t * 9.f,
                                      C::UA(dot_accent, 0.55f * (1.f - ring_t) * online_known_t), 24, 1.6f);
                    dl->AddCircleFilled({dot_x, cy}, dot_r, C::U(dot_col), 20);
                    if (online_known_t > 0.01f)
                        DrawRollingCount(dl, fn, kFS, wm_online_counter.value,
                                         {slot_cx, cy}, slot_w,
                                         {value_col.x, value_col.y, value_col.z, online_known_t});
                    if (online_known_t < 0.99f) {
                        const char* dash = "--";
                        auto ds = fn->CalcTextSizeA(kFS, FLT_MAX, 0, dash);
                        dl->AddText(fn, kFS, {slot_cx - ds.x * 0.5f, ty},
                                    C::UA(C::Dim(), 1.f - online_known_t), dash);
                    }
                }
                if (i + 1 < n && g_state.ui_show_sep)
                    dl->AddLine({cx0 + padX, ry + rowH - 0.5f},
                                {cx1 - padX, ry + rowH - 0.5f},
                                C::UA(C::Sep(), 0.35f), 0.8f);
            }
            ImGui::Dummy({1.f, rowH * n});
        }

        ImGui::Dummy({1.f, 12.f});

    } else if (tab == 1) {

        SHdr(g_Lang->tab_aim);
        CardBg(Layout::RowH * 2);
        ToggleRow(xv::StrStable(xv::sid::kMiTa1), g_Lang->enable_aimbot, &g_state.aim_touch, g_state.a_aim_touch, false);
        ToggleRow(xv::StrStable(xv::sid::kMiXcrs), g_Lang->custom_crosshair,
                  &g_state.crosshair_custom, g_state.a_crosshair_custom, true);

        SHdr(g_Lang->aimbot_mode_hdr);
        {
            auto* dl  = ImGui::GetWindowDrawList();
            auto* fn  = ImGui::GetFont();
            float avW = ImGui::GetContentRegionAvail().x;
            const float inset = Layout::Inset;
            const float fs = ImGui::GetFontSize();
            const float rowH = 52.f;
            auto pos = ImGui::GetCursorScreenPos();
            float cx0 = pos.x + inset, cx1 = pos.x + avW - inset;
            const float gap = 12.f;
            const int kSegments = 2;
            const float plate_w = (cx1 - cx0 - gap * (kSegments - 1)) / kSegments;
            const float tfs = fs * 0.96f;
            const char* names[2] = {g_Lang->mode_native, g_Lang->mode_memory};
            ImVec2 tsz[2];
            for (int i = 0; i < kSegments; ++i)
                tsz[i] = fn->CalcTextSizeA(tfs, FLT_MAX, 0.f, names[i]);

            const int sel_idx = g_state.aim_mode_test ? 0 : 1;
            static float sel_t = -1.f, sel_vel = 0.f;
            const float target_t = (float)sel_idx;
            if (sel_t < 0.f) { sel_t = target_t; sel_vel = 0.f; }
            sel_t = ImClamp(sel_t, 0.f, (float)(kSegments - 1));
            SpringTick(sel_t, sel_vel, target_t, dt);

            for (int i = 0; i < kSegments; ++i) {
                const float px0 = cx0 + (float)i * (plate_w + gap);
                const float px1 = px0 + plate_w;
                dl->AddRectFilled({px0, pos.y}, {px1, pos.y + rowH},
                                  C::U(C::Card()), R::Pill);
                if (g_state.ui_show_sep)
                    dl->AddRect({px0, pos.y}, {px1, pos.y + rowH},
                                C::U(C::Sep()), R::Pill, 1.8f);
            }

            {
                const float hx0 = cx0 + sel_t * (plate_w + gap);
                const float hx1 = hx0 + plate_w;
                const float hy0 = pos.y;
                const float hy1 = pos.y + rowH;
                dl->AddRectFilled({hx0, hy0}, {hx1, hy1}, C::U(C::Acc()), R::Pill);
                if (g_state.ui_show_sep)
                    dl->AddRect({hx0, hy0}, {hx1, hy1}, C::U(C::Sep()), R::Pill, 1.8f);
            }

            for (int i = 0; i < kSegments; ++i) {
                const float proximity = 1.f - ImClamp(
                    fabsf(sel_t - (float)i), 0.f, 1.f);
                const float px0 = cx0 + (float)i * (plate_w + gap);
                const float px1 = px0 + plate_w;
                ImU32 textCol = proximity > 0.5f ? IM_COL32(255, 255, 255, 255) : C::U(C::Txt());
                dl->AddText(fn, tfs,
                            {(px0 + px1 - tsz[i].x) * 0.5f,
                             pos.y + (rowH - tsz[i].y) * 0.5f},
                            textCol, names[i]);
            }

            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiAimmode), {avW, rowH});
            bool popBlocking = (g_pop.visible && !g_pop.closing);
            if (WasTappedHere() && !popBlocking && !IsScrollDragging() &&
                !g_input.touchConsumed) {
                ImVec2 mp = ImGui::GetIO().MousePos;
                int idx = (int)floorf((mp.x - cx0) / (plate_w + gap));
                idx = ImClamp(idx, 0, kSegments - 1);
                if (idx != sel_idx) {
                    g_state.aim_mode_test = (idx == 0);
                    ShowToast(idx == 0 ? g_Lang->toast_native
                                       : g_Lang->toast_memory);
                    PlaySound(SND_CLICK);
                }
            }
        }

        SHdr(g_Lang->fov_hdr);
        CardBg(Layout::SliderH);
        SliderRow(xv::StrStable(xv::sid::kMiAfov), g_Lang->fov_radius, &g_state.gun_fov, 10.f, 360.f,
                  xv::StrStable(xv::sid::kMi0f), true, g_state.sl_gun_fov, dt, 1.f);
        ImGui::Dummy({1.f, 6.f});
        SHdr(g_Lang->smooth_hdr);
        CardBg(Layout::SliderH);
        SliderRow(xv::StrStable(xv::sid::kMiAsmth), g_Lang->smoothness, &g_state.aim_smooth, 0.f, 10.f,
                  xv::StrStable(xv::sid::kMi0f), true, g_state.sl_aim_smooth, dt, 1.f);
        ImGui::Dummy({1.f, 6.f});

        SHdr(g_Lang->aim_zone_hdr);
        CardBg(Layout::RowH);
        ToggleRow(xv::StrStable(xv::sid::kMiAzn0), g_Lang->aim_zone_show,
                  &g_state.aim_zone_enabled, g_state.a_aim_zone, true);
        {
            const float zr = g_state.a_aim_zone;
            if (zr > 0.01f) {
                const float fsHdr = ImGui::GetFontSize() * 1.15f;
                const float segH = 18.f + fsHdr + 8.f + Layout::SliderH + 6.f;
                const ImVec2 segStart = ImGui::GetCursorScreenPos();
                const float avWz = ImGui::GetContentRegionAvail().x;
                ImGui::PushClipRect({segStart.x - 120.f, segStart.y},
                                    {segStart.x + avWz + 120.f,
                                     segStart.y + segH * 4.f * zr}, true);
                SHdr(g_Lang->aim_zone_lr, 18.f, zr);
                CardBg(Layout::SliderH);
                SliderRow(xv::StrStable(xv::sid::kMiAznx), g_Lang->aim_zone_lr, &g_state.aim_zone_x,
                          0.05f, 0.95f, xv::StrStable(xv::sid::kMi2f), false,
                          g_state.sl_aim_zone_x, dt, 0.f, zr);
                ImGui::Dummy({1.f, 6.f});
                SHdr(g_Lang->aim_zone_ud, 18.f, zr);
                CardBg(Layout::SliderH);
                SliderRow(xv::StrStable(xv::sid::kMiAzny), g_Lang->aim_zone_ud, &g_state.aim_zone_y,
                          0.05f, 0.95f, xv::StrStable(xv::sid::kMi2f), false,
                          g_state.sl_aim_zone_y, dt, 0.f, zr);
                ImGui::Dummy({1.f, 6.f});
                ImGui::PopClipRect();
                ImGui::SetCursorScreenPos({segStart.x, segStart.y + segH * 2.f * zr});
            }
        }

        {
            const float r = g_state.a_crosshair_custom;
            if (g_state.crosshair_custom || r > 0.01f) {
                const float fsHdr = ImGui::GetFontSize() * 1.15f;
                const float fullH = 18.f + fsHdr + 8.f + Layout::SliderH;
                const ImVec2 segStart = ImGui::GetCursorScreenPos();
                const float avWz = ImGui::GetContentRegionAvail().x;
                ImGui::PushClipRect({segStart.x - 120.f, segStart.y},
                                    {segStart.x + avWz + 120.f,
                                     segStart.y + fullH * r}, true);
                SHdr(g_Lang->crosshair_size, 18.f, r);
                CardBg(Layout::SliderH);
                SliderRow(xv::StrStable(xv::sid::kMiCrsz), g_Lang->crosshair_size,
                          &g_state.crosshair_size, 6.f, 48.f, xv::StrStable(xv::sid::kMi0f),
                          true, g_state.sl_crosshair_size, dt, 1.f, r);
                ImGui::PopClipRect();
                ImGui::SetCursorScreenPos({segStart.x,
                                           segStart.y + fullH * r});
            }
        }
        ImGui::Dummy({1.f, 8.f});

        CollapsibleHeader(xv::StrStable(xv::sid::kMiCah1), g_Lang->advanced, 0);

        ImGui::Dummy({1.f, 12.f});

} else if (tab == 2) {
        auto* dl  = ImGui::GetWindowDrawList();
        auto* fn  = ImGui::GetFont();
        float avW = ImGui::GetContentRegionAvail().x;
        float fs  = ImGui::GetFontSize();
        const float inset = Layout::Inset, padX = Layout::PadX, rowH = Layout::RowH;
        bool popBlk = (g_pop.visible && !g_pop.closing);

        static const char* s_colorHoldId = nullptr;

        auto EspToggleColorRow = [&](const char* id, const char* lbl, bool* v, float* a, ImVec4* col, bool last) {
            auto pos = ImGui::GetCursorScreenPos();
            float cX = pos.x + inset;
            float cW2 = avW - inset * 2.f;
            float cy = pos.y + rowH * 0.5f;
            auto& io2 = ImGui::GetIO();

            ImGui::InvisibleButton(id, {avW, rowH});

            float dotR = 13.f;
            float dotX = 0.f;
            if (col) {
                auto lblSz = fn->CalcTextSizeA(fs*1.15f, FLT_MAX, 0, lbl);
                dotX = cX + padX + lblSz.x + 14.f + dotR;
            }
            bool openedColor = false;
            if (col && !popBlk && !g_pop.visible) {
                float cx0 = io2.MouseClickedPos[0].x, cy0 = io2.MouseClickedPos[0].y;
                float dx = io2.MousePos.x - cx0, dy = io2.MousePos.y - cy0;
                float moved = dx*dx + dy*dy;
                bool onDot = (cx0 - dotX)*(cx0 - dotX) + (cy0 - cy)*(cy0 - cy) <= (dotR + 18.f)*(dotR + 18.f);
                if (io2.MouseReleased[0] && onDot && moved < 28.f*28.f && s_colorHoldId != id && InVisibleClip({cx0, cy0})) {
                    s_colorHoldId = id;
                    PopoverOpenColor(lbl, col);
                    PlaySound(SND_CLICK);
                    g_input.touchConsumed = true;
                    openedColor = true;
                }
            }
            if (!io2.MouseDown[0] && s_colorHoldId == id) s_colorHoldId = nullptr;

            bool tapped = !openedColor && WasTappedHere() && !popBlk && !IsScrollDragging() && !g_input.touchConsumed;
            if (tapped) { *v = !*v; char b[160]; snprintf(b,sizeof(b),xv::StrStable(xv::sid::kMiSS),lbl,*v?"ON":xv::StrStable(xv::sid::kMiOFF)); ShowToast(b); PlaySound(SND_CLICK); }
            if (col) {
                ImVec4& c = *col;
                dl->AddCircleFilled({dotX, cy}, dotR, IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255),255), 32);
                dl->AddCircle({dotX, cy}, dotR + 2.f, IM_COL32(0,0,0,80), 32, 2.f);
                dl->AddCircle({dotX, cy}, dotR + 1.f, IM_COL32(255,255,255,180), 32, 1.2f);
            }
            float textY = cy - fs * 1.15f * 0.5f;
            dl->AddText(fn, fs * 1.15f, {cX + padX, textY}, C::U(C::Txt()), lbl);
            DrawToggle(dl, cX + cW2 - 72.f - padX, cy, EaseInOut(*a));
            if (!last && g_state.ui_show_sep)
                dl->AddLine({cX+padX, pos.y+rowH-0.5f},{cX+cW2-padX, pos.y+rowH-0.5f}, C::UA(C::Sep(),0.35f), 0.8f);
        };

        SHdr(g_Lang->esp_hdr);
        {
            struct ERow { const char* id; const char* lbl; bool* v; float* a; ImVec4* col; };

            ERow rows[] = {
                {xv::StrStable(xv::sid::kMiVb),   g_Lang->box,              &g_state.esp_box,          &g_state.a_esp_box,          &cfg::esp::box_col},
                {xv::StrStable(xv::sid::kMiVn),   g_Lang->names,            &g_state.esp_name,         &g_state.a_esp_name,         &cfg::esp::name_col},
                {xv::StrStable(xv::sid::kMiVw),   g_Lang->weapon,           &g_state.esp_weapon,       &g_state.a_esp_weapon,       &cfg::esp::weapon_col},
                {xv::StrStable(xv::sid::kMiVsk),  g_Lang->skeleton,         &g_state.esp_skeleton,     &g_state.a_esp_skeleton,     &cfg::esp::skeleton_col},
                {xv::StrStable(xv::sid::kMiVarr), g_Lang->offscreen_arrows, &g_state.esp_arrows,       &g_state.a_esp_arrows,       nullptr},
                {xv::StrStable(xv::sid::kMiVh),   g_Lang->health,           &g_state.esp_hp,           &g_state.a_esp_hp,           nullptr},
                {xv::StrStable(xv::sid::kMiVtr),  g_Lang->tracers,          &g_state.esp_tracer,       &g_state.a_esp_tracer,       &cfg::esp::tracer_col},
                {xv::StrStable(xv::sid::kMiVd),   g_Lang->distance,         &g_state.esp_wall,         &g_state.a_esp_wall,         &cfg::esp::distance_col},
                {xv::StrStable(xv::sid::kMiVat),  g_Lang->target_arrow,     &g_state.esp_aim_arrow,    &g_state.a_esp_aim_arrow,    nullptr},
                {xv::StrStable(xv::sid::kMiVit),  g_Lang->ignore_teammates, &g_state.ignore_teammates, &g_state.a_ignore_teammates, nullptr},
            };
            constexpr int N = 10;
            CardBg(rowH * N);
            for (int i = 0; i < N; i++) {
                EspToggleColorRow(rows[i].id, rows[i].lbl, rows[i].v, rows[i].a, rows[i].col, i == N-1);
            }
        }

        ImGui::Dummy({1.f, 8.f});
        CollapsibleHeader(xv::StrStable(xv::sid::kMiVeh1), g_Lang->advanced, 1);

        SHdr(g_Lang->ore_hdr);
        {
            struct ORow { const char* id; const char* lbl; bool* v; float* a; };
            ORow orows[4] = {
                {xv::StrStable(xv::sid::kMiOs4), g_Lang->tree_label, &g_state.ore_tree,   &g_state.a_ore_tree},
                {xv::StrStable(xv::sid::kMiOs1), g_Lang->sulfur_ore, &g_state.ore_sulfur, &g_state.a_ore_sulfur},
                {xv::StrStable(xv::sid::kMiOs2), g_Lang->iron_ore,   &g_state.ore_iron,   &g_state.a_ore_iron},
                {xv::StrStable(xv::sid::kMiOs3), g_Lang->stone_ore,  &g_state.ore_stone,  &g_state.a_ore_stone},
            };
            CardBg(rowH * 4);
            for (int i = 0; i < 4; i++)
                EspToggleColorRow(orows[i].id, orows[i].lbl, orows[i].v, orows[i].a, nullptr, i == 3);
        }

        SHdr(g_Lang->world_hdr);
        {
            struct WRow { const char* id; const char* lbl; bool* v; float* a; ImVec4* col; };

            
            WRow wrows[7] = {
                {xv::StrStable(xv::sid::kMiWs0), g_Lang->bots,       &g_state.esp_bots,           &g_state.a_esp_bots,           nullptr},
                {xv::StrStable(xv::sid::kMiWs4), g_Lang->w_cupboard, &g_state.esp_cupboard,       &g_state.a_esp_cupboard,       nullptr},
                {xv::StrStable(xv::sid::kMiWs2), g_Lang->crates,     &g_state.esp_crates,         &g_state.a_esp_crates,         nullptr},
                {xv::StrStable(xv::sid::kMiWs5), g_Lang->turrets_label, &g_state.esp_turret,         &g_state.a_esp_turret,         nullptr},
                {xv::StrStable(xv::sid::kMiWs1), g_Lang->animals,    &g_state.esp_animals,        &g_state.a_esp_animals,        nullptr},
                {xv::StrStable(xv::sid::kMiMad1), g_Lang->always_day, &g_state.memory_always_day, &g_state.a_memory_always_day,  nullptr},
                {xv::StrStable(xv::sid::kMiWs3), g_Lang->black_sky,  &g_state.memory_black_sky,   &g_state.a_memory_black_sky,   nullptr},
            };
            CardBg(rowH * 7);
            for (int i = 0; i < 7; i++)
                EspToggleColorRow(wrows[i].id, wrows[i].lbl, wrows[i].v, wrows[i].a, wrows[i].col, i == 6);
        }

        ImGui::Dummy({1.f, 12.f});

    } else if (tab == 3) {

        SHdr(g_Lang->warning);
        {
            auto* dl  = ImGui::GetWindowDrawList();
            auto* fn  = ImGui::GetFont();
            float avW = ImGui::GetContentRegionAvail().x;
            const float inset = Layout::Inset, padX = Layout::PadX;
            const float fs = ImGui::GetFontSize();
            const float cardH = 118.f;
            auto pos = ImGui::GetCursorScreenPos();
            float cx0 = pos.x + inset, cx1 = pos.x + avW - inset;

            ImVec4 warn = {1.0f, 0.62f, 0.04f, 1.f};
            ImVec4 bg = C::Card();
            float mix = g_darkTheme ? 0.12f : 0.07f;
            ImU32 fill = IM_COL32(
                int(bg.x*255*(1.f-mix) + warn.x*255*mix),
                int(bg.y*255*(1.f-mix) + warn.y*255*mix),
                int(bg.z*255*(1.f-mix) + warn.z*255*mix), 255);
            dl->AddRectFilled({cx0, pos.y}, {cx1, pos.y + cardH}, fill, R::Card);
            dl->AddRect({cx0, pos.y}, {cx1, pos.y + cardH},
                        C::UA(warn, 0.55f), R::Card, 1.6f);

            const float icSz = 40.f;
            float icX = cx0 + padX, icCY = pos.y + cardH * 0.5f;
            float icCX = icX + icSz * 0.5f;
            ImVec2 t0 = {icCX, icCY - icSz * 0.48f};
            ImVec2 t1 = {icCX - icSz * 0.52f, icCY + icSz * 0.42f};
            ImVec2 t2 = {icCX + icSz * 0.52f, icCY + icSz * 0.42f};
            dl->AddTriangleFilled(t0, t1, t2, C::U(warn));
            dl->AddLine({icCX, icCY - icSz * 0.16f}, {icCX, icCY + icSz * 0.14f},
                        IM_COL32(255,255,255,255), 3.4f);
            dl->AddCircleFilled({icCX, icCY + icSz * 0.28f}, 2.2f,
                                IM_COL32(255,255,255,255));

            float txX = icX + icSz + 16.f;
            float tFS = fs * 1.02f;
            float sFS = fs * 0.84f;
            float blockH = tFS + 6.f + sFS * 2.f + 4.f;
            float tY = icCY - blockH * 0.5f;
            dl->AddText(fn, tFS, {txX, tY}, C::U(C::Txt()),
                        g_Lang->warn_memory);
            dl->AddText(fn, sFS, {txX, tY + tFS + 6.f}, C::U(C::Dim()),
                        g_Lang->warn_risk);
            dl->AddText(fn, sFS, {txX, tY + tFS + 6.f + sFS + 4.f}, C::U(C::Dim()),
                        g_Lang->warn_use);
            ImGui::Dummy({1.f, cardH});
        }

        SHdr(g_Lang->memory_hdr);
        CardBg(Layout::RowH * 2);
        ToggleRow(xv::StrStable(xv::sid::kMiMnr1), g_Lang->no_recoil, &g_state.memory_no_recoil,
                  g_state.a_memory_no_recoil, false);
        ToggleRow(xv::StrStable(xv::sid::kMiMns1), g_Lang->no_spread, &g_state.memory_no_spread,
                  g_state.a_memory_no_spread, true);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->hands_fov_hdr);
        CardBg(Layout::RowH + Layout::SliderH);
        ToggleRow(xv::StrStable(xv::sid::kMiMhf1), g_Lang->hands_fov, &g_state.memory_hands_fov,
                  g_state.a_memory_hands_fov, false);
        SliderRow(xv::StrStable(xv::sid::kMiMhfv), g_Lang->hands_fov_value,
                  &g_state.hands_fov_value, 20.f, 120.f,
                  xv::StrStable(xv::sid::kMi0f), true, g_state.sl_hands_fov, dt, 1.f);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->aspect_hdr);
        CardBg(Layout::RowH + Layout::SliderH);
        ToggleRow(xv::StrStable(xv::sid::kMiMasp1), g_Lang->aspect_toggle,
                  &g_state.memory_aspect, g_state.a_memory_aspect, false);
        SliderRow(xv::StrStable(xv::sid::kMiMaspv), g_Lang->aspect_value,
                  &g_state.aspect_value, 0.30f, 5.00f,
                  xv::StrStable(xv::sid::kMi2f), true, g_state.sl_aspect, dt, 0.01f);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->freecam_settings_hdr);
        CardBg(Layout::RowH * 2 + Layout::SliderH);
        ToggleRow(xv::StrStable(xv::sid::kMiMfc1), g_Lang->freecam, &g_state.memory_freecam,
                  g_state.a_memory_freecam, false);
        ToggleRow(xv::StrStable(xv::sid::kMiMfcb), g_Lang->freecam_bind, &g_state.freecam_bind,
                  g_state.a_freecam_bind, false);
        SliderRow(xv::StrStable(xv::sid::kMiMfcs), g_Lang->speed, &g_state.freecam_speed, 1.f, 40.f,
                  xv::StrStable(xv::sid::kMi0f), true, g_state.sl_freecam_speed, dt, 1.f);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->xray_settings_hdr);
        CardBg(Layout::RowH + Layout::SliderH);
        ToggleRow(xv::StrStable(xv::sid::kMiMxr1), g_Lang->xray_toggle, &g_state.memory_xray,
                  g_state.a_memory_xray, false);
        SliderRow(xv::StrStable(xv::sid::kMiMxrd), g_Lang->xray_radius, &g_state.xray_distance, 0.1f, 100.f,
                  xv::StrStable(xv::sid::kMi1fM), true, g_state.sl_xray_dist, dt, 0.1f);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->af_hdr);
        {
            auto* dl2  = ImGui::GetWindowDrawList();
            auto* fn2  = ImGui::GetFont();
            float avW2 = ImGui::GetContentRegionAvail().x;
            float fs2  = ImGui::GetFontSize();
            const float inset2 = Layout::Inset;
            const float btnH = 78.f;
            auto pos = ImGui::GetCursorScreenPos();
            float cardX0 = pos.x + inset2, cardX1 = pos.x + avW2 - inset2;
            const bool running = g_state.autofarm_on;

            ImVec4 col = running ? ImVec4(0.80f, 0.17f, 0.17f, 1.f)
                                 : ImVec4(0.10f, 0.56f, 0.27f, 1.f);
            dl2->AddRectFilled({cardX0, pos.y}, {cardX1, pos.y + btnH},
                               C::U(col), R::Btn);
            if (g_state.ui_show_sep)
                dl2->AddRect({cardX0, pos.y}, {cardX1, pos.y + btnH},
                             C::UA(C::Sep(), 0.9f), R::Btn, 1.2f);
            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiAfstart), {avW2, btnH});
            bool popBlk3 = (g_pop.visible && !g_pop.closing);
            if (WasTappedHere() && !popBlk3 && !IsScrollDragging() &&
                !g_input.touchConsumed) {
                if (!running && !g_state.af_sulfur &&
                    !g_state.af_iron && !g_state.af_stone &&
                    !g_state.af_tree) {
                    ShowToast(g_Lang->af_pick_type);
                    PlaySound(SND_CLICK);
                } else {
                    g_state.autofarm_on = !running;
                    if (g_state.autofarm_on) {
                        esp_request_fast_scan();
                        g_af_target_key = 0;
                        g_af_mode = 0;
                        g_af_dead = false;
                        g_af_alive_since = 0.0;
                        AfRespawnReset();
                        AfLookReset();
                        ShowToast(g_Lang->af_started);
                        PlaySound(SND_SUCCESS);
                    } else {
                        AfReleaseFingers();
                        AfRespawnReset();
                        g_af_dead = false;
                        ShowToast(g_Lang->af_stopped);
                        PlaySound(SND_CLICK);
                    }
                }
            }
            float cy2 = pos.y + btnH * 0.5f;
            float icX = cardX0 + 34.f;
            dl2->AddCircleFilled({icX, cy2}, 21.f,
                                 IM_COL32(255, 255, 255, 40), 32);
            const char* btnTxt = running ? g_Lang->af_stop : g_Lang->af_start;
            if (running) {
                dl2->AddRectFilled({icX - 8.f, cy2 - 8.f},
                                   {icX + 8.f, cy2 + 8.f},
                                   IM_COL32(255, 255, 255, 245), 3.f);
            } else {
                dl2->AddTriangleFilled({icX - 7.f, cy2 - 10.f},
                                       {icX - 7.f, cy2 + 10.f},
                                       {icX + 12.f, cy2},
                                       IM_COL32(255, 255, 255, 245));
            }
            float btnFS = fs2 * 1.3f;
            auto bts = fn2->CalcTextSizeA(btnFS, FLT_MAX, 0, btnTxt);
            dl2->AddText(fn2, btnFS, {icX + 38.f, cy2 - bts.y * 0.5f},
                         IM_COL32(255, 255, 255, 255), btnTxt);
        }

        ImGui::Dummy({1.f, 8.f});
        SHdr(g_Lang->af_ores);
        CardBg(Layout::RowH * 4);
        ToggleRow(xv::StrStable(xv::sid::kMiAfs4), g_Lang->tree_label, &g_state.af_tree,
                  g_state.a_af_tree, false);
        ToggleRow(xv::StrStable(xv::sid::kMiAfs1), g_Lang->af_sulfur, &g_state.af_sulfur,
                  g_state.a_af_sulfur, false);
        ToggleRow(xv::StrStable(xv::sid::kMiAfs2), g_Lang->af_iron, &g_state.af_iron,
                  g_state.a_af_iron, false);
        ToggleRow(xv::StrStable(xv::sid::kMiAfs3), g_Lang->af_stone, &g_state.af_stone,
                  g_state.a_af_stone, true);
        ImGui::Dummy({1.f, 8.f});

        SHdr(g_Lang->af_btns_hdr);
        CardBg(Layout::RowH * 3);
        AfZoneRow(xv::StrStable(xv::sid::kMiAffire), g_Lang->af_fire_hdr, g_Lang->af_fire_set,
                  g_state.fire_zone_set, g_fire_zone_armed, g_Lang->zone_hint,
                  false, true);
        AfZoneRow(xv::StrStable(xv::sid::kMiAfjoy), g_Lang->af_joy_hdr, g_Lang->af_joy_set,
                  g_state.joy_zone_set, g_af_joy_armed, g_Lang->af_joy_hint,
                  true, true);
        AfZoneRow(xv::StrStable(xv::sid::kMiAfrs), g_Lang->af_rs_hdr, g_Lang->af_rs_set,
                  g_state.rs_zone_set, g_af_rs_armed, g_Lang->af_rs_hint,
                  true, false);
        ImGui::Dummy({1.f, 8.f});

    } else if (tab == 4) {

        auto* dl  = ImGui::GetWindowDrawList();
        auto* fn  = ImGui::GetFont();
        float avW = ImGui::GetContentRegionAvail().x;
        const float inset = Layout::Inset;
        const float fs = ImGui::GetFontSize();

        SHdr(g_Lang->controls);
        {
            const float btnH = 72.f;
            auto pos = ImGui::GetCursorScreenPos();
            float cardX0 = pos.x + inset, cardX1 = pos.x + avW - inset;

            dl->AddRectFilled({cardX0, pos.y}, {cardX1, pos.y + btnH},
                C::U(C::Card()), R::Btn);
            if (g_state.ui_show_sep)
                dl->AddRect({cardX0, pos.y}, {cardX1, pos.y + btnH},
                    C::UA(C::Sep(), 0.9f), R::Btn, 1.2f);

            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiCfgcreate), {avW, btnH});
            bool popBlocking2 = (g_pop.visible && !g_pop.closing);
            bool tapped = WasTappedHere() && !popBlocking2 && !IsScrollDragging() && !g_input.touchConsumed;
            if (tapped) ConfigSave();

            float cy2 = pos.y + btnH * 0.5f;
            float icX = cardX0 + 28.f + 20.f;
            dl->AddCircleFilled({icX, cy2}, 20.f, C::UA(C::Acc(), 0.15f), 32);
            dl->AddCircle({icX, cy2}, 20.f, C::UA(C::Acc(), 0.7f), 32, 1.5f);
            dl->AddLine({icX - 9.f, cy2}, {icX + 9.f, cy2}, C::U(C::Acc()), 3.f);
            dl->AddLine({icX, cy2 - 9.f}, {icX, cy2 + 9.f}, C::U(C::Acc()), 3.f);

            const char* createTxt = g_Lang->create_config;
            float textY = pos.y + (btnH - fs * 1.25f) * 0.5f;
            dl->AddText(fn, fs * 1.25f, {icX + 32.f, textY}, C::U(C::Acc()), createTxt);
        }

        SHdr(g_Lang->configs);

        if (g_configCount == 0) {
            const float emptyH = 120.f;
            auto ep = ImGui::GetCursorScreenPos();
            dl->AddRectFilled({ep.x + inset, ep.y}, {ep.x + avW - inset, ep.y + emptyH},
                C::U(C::Card()), R::Card);
            if (g_state.ui_show_sep)
                dl->AddRect({ep.x + inset, ep.y}, {ep.x + avW - inset, ep.y + emptyH},
                    C::UA(C::Sep(), 0.9f), R::Card, 1.2f);
            ImGui::Dummy({avW, emptyH});
            const char* emptyTxt = g_Lang->no_configs;
            auto eSz = fn->CalcTextSizeA(fs * 1.05f, FLT_MAX, 0, emptyTxt);
            dl->AddText(fn, fs * 1.05f,
                {ep.x + (avW - eSz.x) * 0.5f, ep.y + (emptyH - fs * 1.05f) * 0.5f},
                C::U(C::Dim()), emptyTxt);
        } else {
            auto& io2 = ImGui::GetIO();
            bool popBlocking2 = (g_pop.visible && !g_pop.closing);

            const float padH    = 12.f;
            const float padTop  = 14.f;
            const float padBot  = 14.f;
            const float icSz    = 62.f;
            const float nameGap = 12.f;
            const float midGap  = 10.f;
            const float btnH2   = 46.f;
            const float btnGapX =  6.f;
            const float cardGap = 10.f;

            float nameFS = fs * 1.15f;
            float subFS  = fs * 0.78f;
            float textH  = fn->CalcTextSizeA(nameFS, FLT_MAX, 0, "A").y;
            float subH   = fn->CalcTextSizeA(subFS,  FLT_MAX, 0, "A").y;
            float topH   = ImMax(icSz, textH + 6.f + subH);
            float cardH  = padTop + topH + midGap + btnH2 + padBot;

            for (int ci = 0; ci < g_configCount; ci++) {
                float loadA = (ci < kMaxConfigs) ? g_cfgLoadAnim[ci] : 0.f;
                float easedA = loadA * loadA * (3.f - 2.f * loadA);

                auto pos = ImGui::GetCursorScreenPos();
                float cx0 = pos.x + inset, cx1 = pos.x + avW - inset;
                float cw  = cx1 - cx0;

                {
                    ImVec4 bg = C::Card(), ac = C::Acc();
                    float mix = (g_darkTheme ? 0.14f : 0.06f) * easedA;
                    ImU32 cardFill = IM_COL32(
                        int(bg.x*255*(1.f-mix) + ac.x*255*mix),
                        int(bg.y*255*(1.f-mix) + ac.y*255*mix),
                        int(bg.z*255*(1.f-mix) + ac.z*255*mix), 255);
                    dl->AddRectFilled({cx0, pos.y}, {cx1, pos.y + cardH}, cardFill, R::Card);

                    float borderA = Lerpf(g_state.ui_show_sep ? 0.9f : 0.f, 0.65f, easedA);
                    ImVec4 borderCol = g_state.ui_show_sep
                        ? ImVec4{Lerpf(C::Sep().x, ac.x, easedA), Lerpf(C::Sep().y, ac.y, easedA), Lerpf(C::Sep().z, ac.z, easedA), borderA}
                        : ImVec4{ac.x, ac.y, ac.z, borderA};
                    if (borderA > 0.01f)
                        dl->AddRect({cx0, pos.y}, {cx1, pos.y + cardH}, C::U(borderCol), R::Card, Lerpf(1.2f, 2.2f, easedA));
                }

                float rowCY = pos.y + padTop + topH * 0.5f;
                float icX  = cx0 + padH;
                float icY  = rowCY - icSz * 0.5f;
                float icCX = icX + icSz * 0.5f;

                if (g_tabIcons[4]) {
                    dl->AddImageRounded(g_tabIcons[4],
                        {icX, icY}, {icX + icSz, icY + icSz},
                        {0,0}, {1,1}, IM_COL32(255,255,255,255), 12.f);
                } else {
                    float icR = 14.f;
                    ImU32 icBg = g_darkTheme
                        ? IM_COL32(55, 120, 220, 255)
                        : IM_COL32(10, 122, 255, 255);
                    dl->AddRectFilled({icX, icY}, {icX + icSz, icY + icSz}, icBg, icR);
                    float lh = icSz * 0.20f;
                    float lx = icCX - lh * 0.45f, ly = rowCY + lh * 0.42f;
                    dl->AddLine({icCX - lh, rowCY}, {lx, ly},      IM_COL32(255,255,255,245), 3.2f);
                    dl->AddLine({lx, ly}, {icCX + lh, rowCY - lh}, IM_COL32(255,255,255,245), 3.2f);
                }

                const char* badgeTxt = g_Lang->loaded_badge;
                auto btsz    = fn->CalcTextSizeA(subFS, FLT_MAX, 0, badgeTxt);
                float dotR   = 3.5f;
                float bPadX  = 8.f, bPadY = 5.f;
                float bW     = dotR*2.f + 5.f + btsz.x + bPadX * 2.f;
                float bH     = btsz.y + bPadY * 2.f;

                float nameAreaR = easedA > 0.01f ? (cx1 - bW * easedA - 10.f) : (cx1 - padH);
                float nameX = icX + icSz + nameGap;
                float nameY = rowCY - (textH + 6.f + subH) * 0.5f;

                dl->PushClipRect({nameX, pos.y}, {nameAreaR, pos.y + cardH}, true);
                dl->AddText(fn, nameFS, {nameX, nameY}, C::U(C::Txt()), g_configs[ci].name);
                dl->AddText(fn, subFS, {nameX, nameY + textH + 6.f}, C::UA(C::Dim(), 0.7f), xv::StrStable(xv::sid::kMiConfig));
                dl->PopClipRect();

                if (easedA > 0.01f) {
                    ImVec4 ac = C::Acc();
                    float bX  = cx1 - bW - 10.f;
                    float bY2 = rowCY - bH * 0.5f;
                    float a   = easedA;

                    dl->AddRectFilled({bX, bY2}, {bX + bW, bY2 + bH},
                        C::UA(ac, (g_darkTheme ? 0.20f : 0.10f) * a), bH * 0.5f);
                    dl->AddRect({bX, bY2}, {bX + bW, bY2 + bH},
                        C::UA(ac, 0.55f * a), bH * 0.5f, 1.3f);
                    dl->AddCircleFilled({bX + bPadX + dotR, bY2 + bH*0.5f}, dotR, C::UA(ac, 0.95f * a), 16);
                    dl->AddText(fn, subFS,
                        {bX + bPadX + dotR*2.f + 5.f, bY2 + bPadY},
                        C::UA(ac, 0.95f * a), badgeTxt);
                }

                float bY  = pos.y + padTop + topH + midGap;
                float totalBtnW = cw - padH * 2.f;
                float bw3 = (totalBtnW - btnGapX * 2.f) / 3.f;
                float b1X = cx0 + padH;
                float b2X = b1X + bw3 + btnGapX;
                float b3X = b2X + bw3 + btnGapX;

                auto DrawBtn = [&](float bx, float bw, ImU32 fillL, ImU32 fillD, ImU32 txtCol, const char* label) {
                    ImU32 fill = g_darkTheme ? fillD : fillL;
                    dl->AddRectFilled({bx, bY}, {bx + bw, bY + btnH2}, fill, R::Btn);
                    auto lsz = fn->CalcTextSizeA(fs * 0.93f, FLT_MAX, 0, label);
                    dl->PushClipRect({bx+3.f, bY}, {bx+bw-3.f, bY+btnH2}, true);
                    dl->AddText(fn, fs * 0.93f,
                        {bx + bw*0.5f - lsz.x*0.5f, bY + (btnH2 - lsz.y)*0.5f},
                        txtCol, label);
                    dl->PopClipRect();
                };

                DrawBtn(b1X, bw3,
                    IM_COL32(235, 242, 255, 255),
                    IM_COL32(30,  80,  180, 255),
                    g_darkTheme ? IM_COL32(120, 175, 255, 255) : IM_COL32(10, 100, 220, 255),
                    g_Lang->load);

                DrawBtn(b2X, bw3,
                    IM_COL32(232, 248, 237, 255),
                    IM_COL32(20,  80,  40,  255),
                    g_darkTheme ? IM_COL32(80, 210, 120, 255) : IM_COL32(25, 140, 60, 255),
                    g_Lang->save);

                DrawBtn(b3X, bw3,
                    IM_COL32(255, 237, 236, 255),
                    IM_COL32(100, 20,  20,  255),
                    g_darkTheme ? IM_COL32(255, 100, 90, 255) : IM_COL32(210, 30, 20, 255),
                    g_Lang->delete_btn);

                ImGui::InvisibleButton((xv::StrStable(xv::sid::kMiCfg_2) + std::to_string(ci)).c_str(), {avW, cardH});

                if (!popBlocking2 && !IsScrollDragging() && !g_input.touchConsumed && io2.MouseReleased[0]) {
                    auto mp  = io2.MousePos;
                    auto cp2 = io2.MouseClickedPos[0];
                    if (!InVisibleClip(cp2)) goto cfg_click_skip;
                    if (mp.x  >= b1X && mp.x  <= b1X+bw3 && mp.y  >= bY && mp.y  <= bY+btnH2
                     && cp2.x >= b1X && cp2.x <= b1X+bw3 && cp2.y >= bY && cp2.y <= bY+btnH2)
                        ConfigLoad(ci);
                    else if (mp.x  >= b2X && mp.x  <= b2X+bw3 && mp.y  >= bY && mp.y  <= bY+btnH2
                     && cp2.x >= b2X && cp2.x <= b2X+bw3 && cp2.y >= bY && cp2.y <= bY+btnH2)
                        ConfigUpdate(ci);
                    else if (mp.x  >= b3X && mp.x  <= b3X+bw3 && mp.y  >= bY && mp.y  <= bY+btnH2
                     && cp2.x >= b3X && cp2.x <= b3X+bw3 && cp2.y >= bY && cp2.y <= bY+btnH2) {
                        g_configToDelete = ci;
                        PopoverOpen(g_Lang->delete_cfg_question, 3);
                    }
                    cfg_click_skip:;
                }

                if (ci < g_configCount - 1)
                    ImGui::Dummy({1.f, cardGap});
            }
        }

    } else if (tab == 5) {
        SHdr(g_Lang->interface_hdr);
        CardBg(Layout::RowH * 3);
        if (ToggleRow(xv::StrStable(xv::sid::kMiUd2), g_Lang->dark_theme, &g_state.ui_dark_mode, g_state.a_ui_dark, false))
            g_darkTheme = g_state.ui_dark_mode;
        ToggleRow(xv::StrStable(xv::sid::kMiUsep), g_Lang->row_separators, &g_state.ui_show_sep, g_state.a_ui_sep, false);
        ToggleRow(xv::StrStable(xv::sid::kMiUf2), g_Lang->show_fps, &g_state.ui_fps, g_state.a_ui_fps, true);

        SHdr(g_Lang->accent_color);
        CardBg(Layout::RowH);
        {
            auto* dl = ImGui::GetWindowDrawList();
            auto* fn = ImGui::GetFont();
            float avW = ImGui::GetContentRegionAvail().x;
            const float inset = Layout::Inset, padX = Layout::PadX, rowH = Layout::RowH;
            const float fs = ImGui::GetFontSize();
            auto pos = ImGui::GetCursorScreenPos();
            float cX = pos.x + inset;
            float cy = pos.y + rowH * 0.5f;

            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiUiColRow), {avW, rowH});
            bool popBlk = (g_pop.visible && !g_pop.closing);

            float dotR = 13.f;
            auto lblSz = fn->CalcTextSizeA(fs * 1.15f, FLT_MAX, 0, g_Lang->accent_color);
            float dotX = cX + padX + lblSz.x + 16.f + dotR;

            if (WasTappedHere() && !popBlk && !IsScrollDragging() && !g_input.touchConsumed) {
                g_state.ui_accent_custom = true;
                PopoverOpenColor(g_Lang->accent_color, &g_state.ui_custom_accent_col);
                PlaySound(SND_CLICK);
            }

            float textY = cy - fs * 1.15f * 0.5f;
            dl->AddText(fn, fs * 1.15f, {cX + padX, textY}, C::U(C::Txt()), g_Lang->accent_color);

            ImVec4 curCol = C::Acc();
            dl->AddCircleFilled({dotX, cy}, dotR, IM_COL32((int)(curCol.x * 255.f), (int)(curCol.y * 255.f), (int)(curCol.z * 255.f), 255), 32);
            dl->AddCircle({dotX, cy}, dotR + 2.f, IM_COL32(0, 0, 0, 80), 32, 2.f);
            dl->AddCircle({dotX, cy}, dotR + 1.f, IM_COL32(255, 255, 255, 180), 32, 1.2f);
        }

        SHdr(g_Lang->system_hdr);
        {
            auto* dl  = ImGui::GetWindowDrawList();
            float avW = ImGui::GetContentRegionAvail().x;
            const float rowH = Layout::RowH, inset = Layout::Inset;
            auto pos = ImGui::GetCursorScreenPos();
            dl->AddRectFilled({pos.x + inset, pos.y}, {pos.x + avW - inset, pos.y + rowH}, C::U(C::Card()), R::Card);

            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiExit), {avW, rowH});
            if (WasTappedHere() && !IsScrollDragging())
                PopoverOpen(g_Lang->exit_question, 2);
            const char* exitTxt = g_Lang->exit_app;
            float exitFS = ImGui::GetFontSize() * 1.15f;
            auto  tsz = ImGui::GetFont()->CalcTextSizeA(exitFS, FLT_MAX, 0, exitTxt);
            float tx  = pos.x + (avW - tsz.x) * 0.5f;
            float ty  = pos.y + (rowH - exitFS) * 0.5f;
            dl->AddText(ImGui::GetFont(), exitFS, {tx, ty}, C::U(C::Red()), exitTxt);
        }
    }

    ImGui::Dummy({1.f, 12.f});
    return ImGui::GetCursorPosY() - sY;
}

static uint32_t g_menu_orient = 0xFFFFFFFFu;
static int g_menu_dw = 0, g_menu_dh = 0;

static void VisibleScreen(float& w, float& h) {
    float dw = (float)displayInfo.width;
    float dh = (float)displayInfo.height;
    if (dw < 100.f) dw = (float)native_window_screen_x;
    if (dh < 100.f) dh = (float)native_window_screen_y;
    float mx = dw > dh ? dw : dh;
    float mn = dw < dh ? dw : dh;
    if (mx < 100.f) mx = 1080.f;
    if (mn < 100.f) mn = mx;
    bool land = (displayInfo.orientation == 1 || displayInfo.orientation == 3);
    if (dw > dh) land = true;
    else if (dh > dw && (displayInfo.orientation == 0 || displayInfo.orientation == 2)) land = false;
    w = land ? mx : mn;
    h = land ? mn : mx;
}

static void CenterMenuOnDisplay() {
    float dw = 0.f, dh = 0.f;
    VisibleScreen(dw, dh);
    if (dw < 100.f || dh < 100.f) return;
    if (g_win.w > dw - 16.f) g_win.w = ImMax(160.f, dw - 16.f);
    if (g_win.h > dh - 16.f) g_win.h = ImMax(160.f, dh - 16.f);
    g_win.pos.x = (dw - g_win.w) * 0.5f;
    g_win.pos.y = (dh - g_win.h) * 0.5f;
    EndWinDrag();
    g_win.resizing = false;
}

static bool LoginCircleTap(float cx, float cy, float r, bool enabled = true) {
    if (!enabled) return false;
    const auto& io = ImGui::GetIO();
    if (!io.MouseReleased[0]) return false;
    ImVec2 cp = io.MouseClickedPos[0];
    ImVec2 mp = io.MousePos;
    auto inside = [&](ImVec2 p){ return (p.x-cx)*(p.x-cx) + (p.y-cy)*(p.y-cy) <= (r+10.f)*(r+10.f); };
    float dx = mp.x - cp.x, dy = mp.y - cp.y;
    return inside(cp) && inside(mp) && (dx*dx + dy*dy) <= 34.f*34.f;
}

static void DrawSuccessAnim(ImDrawList* dl, ImFont* fn, float fs, float WW, float WH, float p) {
    ImVec2 w0 = g_win.pos;
    ImVec2 c{ w0.x + WW * 0.5f, w0.y + WH * 0.46f };

    ImVec4 acc = C::Acc();
    ImU32 ringCol = C::U(acc);

    for (int k = 0; k < 3; k++) {
        float rp = p - k * 0.22f;
        if (rp > 0.f && rp < 1.f) {
            float rr = 40.f + rp * 130.f;
            int al = (int)(120.f * (1.f - rp));
            dl->AddCircle(c, rr, IM_COL32((int)(acc.x*255),(int)(acc.y*255),(int)(acc.z*255),al), 64, 3.f);
        }
    }

    float pop = EaseOut3(Clamp01(p / 0.5f));
    float R = 64.f * pop;
    if (R > 1.f) {
        dl->AddCircleFilled({c.x, c.y + 3.f}, R, IM_COL32(0,0,0,40), 64);
        dl->AddCircleFilled(c, R, ringCol, 64);
    }

    float draw = Clamp01((p - 0.24f) / 0.44f);
    if (draw > 0.0005f && R > 1.f) {
        ImU32 white = IM_COL32(255,255,255,255);
        float th = R * 0.12f, cap = th * 0.5f;
        ImVec2 a1{ c.x - R*0.40f, c.y + R*0.04f };
        ImVec2 a2{ c.x - R*0.13f, c.y + R*0.32f };
        ImVec2 a3{ c.x + R*0.44f, c.y - R*0.34f };
        auto lerp = [](ImVec2 a, ImVec2 b, float f){
            return ImVec2(a.x + (b.x-a.x)*f, a.y + (b.y-a.y)*f);
        };
        float d1 = sqrtf((a2.x-a1.x)*(a2.x-a1.x) + (a2.y-a1.y)*(a2.y-a1.y));
        float d2 = sqrtf((a3.x-a2.x)*(a3.x-a2.x) + (a3.y-a2.y)*(a3.y-a2.y));
        float e = EaseInOut(draw);
        float dist = e * (d1 + d2);

        ImVec2 pts[3]; int np = 0;
        ImVec2 tip;
        if (dist <= d1) {
            float f1 = d1 > 0.f ? dist/d1 : 0.f;
            pts[np++] = a1; tip = lerp(a1, a2, f1); pts[np++] = tip;
        } else {
            float f2 = d2 > 0.f ? (dist-d1)/d2 : 0.f;
            pts[np++] = a1; pts[np++] = a2; tip = lerp(a2, a3, f2); pts[np++] = tip;
        }
        dl->PathClear();
        for (int i = 0; i < np; i++) dl->PathLineTo(pts[i]);
        dl->PathStroke(white, ImDrawFlags_None, th);

        auto capAt = [&](ImVec2 pt, float r){ if (r > 0.6f) dl->AddCircleFilled(pt, r, white, 16); };
        capAt(a1, cap);
        capAt(tip, cap);
        if (dist > d1 + 0.001f) capAt(a2, cap);
        if (dist >= d1 + d2 - 0.001f) capAt(a3, cap);
    }

    float textA = Clamp01((p - 0.45f) / 0.35f);
    if (textA > 0.f) {
        const char* msg = g_Lang->auth_success;
        float tfs = fs * 1.5f;
        ImVec2 ts = fn->CalcTextSizeA(tfs, FLT_MAX, 0.f, msg);
        float ty = c.y + R + 26.f - (1.f - textA) * 14.f;
        ImVec4 tc = C::Txt();
        dl->AddText(fn, tfs, { w0.x + (WW - ts.x)*0.5f, ty },
            IM_COL32((int)(tc.x*255),(int)(tc.y*255),(int)(tc.z*255),(int)(255*textA)), msg);
    }
}

static void DrawFailAnim(ImDrawList* dl, ImFont* fn, float fs, float WW, float WH, float p) {
    ImVec2 w0 = g_win.pos;
    ImVec2 c{ w0.x + WW * 0.5f, w0.y + WH * 0.46f };

    float shakeA = sinf(p * IM_PI * 6.f) * (1.f - p) * 16.f;
    c.x += shakeA;

    ImVec4 red = C::Red();
    ImU32 redCol = C::U(red);

    float pop = EaseOut3(Clamp01(p / 0.4f));
    float R = 64.f * pop;
    if (R > 1.f) {
        dl->AddCircleFilled({c.x, c.y + 3.f}, R, IM_COL32(0,0,0,40), 64);
        dl->AddCircleFilled(c, R, redCol, 64);
    }

    float draw = Clamp01((p - 0.28f) / 0.4f);
    if (draw > 0.f && R > 1.f) {
        ImU32 white = IM_COL32(255,255,255,255);
        float th = R * 0.12f, cap = th * 0.5f;
        float s = R * 0.36f;
        float e1 = EaseInOut(Clamp01(draw * 2.f));
        float e2 = EaseInOut(Clamp01(draw * 2.f - 1.f));
        ImVec2 ctr{ c.x, c.y };
        ImVec2 d1 { s, -s }, d2 { s,  s };
        ImVec2 e1p{ ctr.x + d1.x*e1, ctr.y + d1.y*e1 };
        ImVec2 f1p{ ctr.x - d1.x*e1, ctr.y - d1.y*e1 };
        ImVec2 e2p{ ctr.x + d2.x*e2, ctr.y + d2.y*e2 };
        ImVec2 f2p{ ctr.x - d2.x*e2, ctr.y - d2.y*e2 };
        if (e1 > 0.001f) {
            dl->AddLine(f1p, e1p, white, th);
            dl->AddCircleFilled(e1p, cap, white, 16);
            dl->AddCircleFilled(f1p, cap, white, 16);
        }
        if (e2 > 0.001f) {
            dl->AddLine(f2p, e2p, white, th);
            dl->AddCircleFilled(e2p, cap, white, 16);
            dl->AddCircleFilled(f2p, cap, white, 16);
        }
        if (e1 > 0.001f || e2 > 0.001f) dl->AddCircleFilled(ctr, cap, white, 16);
    }

    float textA = Clamp01((p - 0.35f) / 0.35f);
    if (textA > 0.f) {
        const char* msg = g_Lang->auth_fail;
        float tfs = fs * 1.5f;
        ImVec2 ts = fn->CalcTextSizeA(tfs, FLT_MAX, 0.f, msg);
        float ty = c.y + R + 26.f;
        ImVec4 tc = C::Red();
        dl->AddText(fn, tfs, { w0.x + (WW - ts.x)*0.5f, ty },
            IM_COL32((int)(tc.x*255),(int)(tc.y*255),(int)(tc.z*255),(int)(255*textA)), msg);
    }
}

static void CardExitButton(ImDrawList* dl, ImVec2 w0, float WW, float cardA,
                           const char* id) {
    auto& io = ImGui::GetIO();
    const bool popOpen = g_pop.visible;
    const float r = 18.f;
    const float ex = w0.x + WW - 22.f - r;
    const float ey = w0.y + 22.f + r;
    const bool held = !popOpen && io.MouseDown[0] &&
        (io.MousePos.x - ex) * (io.MousePos.x - ex) +
        (io.MousePos.y - ey) * (io.MousePos.y - ey) <= (r + 6.f) * (r + 6.f);
    dl->AddCircleFilled({ex, ey + 2.f}, r, IM_COL32(0, 0, 0, 28), 32);
    dl->AddCircleFilled({ex, ey}, r, C::UA(C::Card(), cardA), 32);
    if (held) dl->AddCircleFilled({ex, ey}, r, IM_COL32(255, 255, 255, 26), 32);
    dl->AddCircle({ex, ey}, r, C::UA(C::Sep(), 0.9f * cardA), 32, 1.3f);
    const float cs = 7.f;
    dl->AddLine({ex - cs, ey - cs}, {ex + cs, ey + cs}, C::UA(C::Dim(), cardA), 2.4f);
    dl->AddLine({ex + cs, ey - cs}, {ex - cs, ey + cs}, C::UA(C::Dim(), cardA), 2.4f);
    ImGui::SetCursorScreenPos({ex - r, ey - r});
    ImGui::InvisibleButton(id, {r * 2.f, r * 2.f});
    if (LoginCircleTap(ex, ey, r, !popOpen)) {
        PopoverOpen(g_Lang->exit_question, 2);
        g_popOpenClickPos = io.MousePos;
        PlaySound(SND_CLICK);
    }
}

static float CardAvatarTitle(ImDrawList* dl, ImFont* fn, float fs, ImVec2 w0, float WW,
                             float WH, float cardA, const char* title) {
    const float avR = 64.f;
    const float gapAvTitle = 28.f;
    const float gapTitleBtn = 32.f;
    const float tfs = fs * 1.1f;
    const float segH = 60.f;

    const float blockH = avR * 2.f + gapAvTitle + tfs + gapTitleBtn + segH;
    const float groupTop = w0.y + ImMax(26.f, (WH - blockH) * 0.5f);
    const float avCx = w0.x + WW * 0.5f;
    const float avCy = groupTop + avR;

    dl->AddCircleFilled({avCx + 2.f, avCy + 3.f}, avR,
                        IM_COL32(0, 0, 0, int(30 * cardA)), 64);
    dl->AddCircleFilled({avCx, avCy}, avR, C::UA(C::Card(), cardA), 64);
    if (g_sprite.texture) {
        const int col = g_sprite.frame % SpriteState::Cols;
        const int row = g_sprite.frame / SpriteState::Cols;
        const float u0 = col / (float)SpriteState::Cols;
        const float u1 = (col + 1) / (float)SpriteState::Cols;
        const float v0 = row / (float)SpriteState::Rows;
        const float v1 = (row + 1) / (float)SpriteState::Rows;
        dl->AddImageRounded(g_sprite.texture,
            {avCx - avR, avCy - avR}, {avCx + avR, avCy + avR},
            {u0, v0}, {u1, v1}, IM_COL32(255, 255, 255, (int)(255 * cardA)), avR);
    }
    dl->AddCircle({avCx, avCy}, avR + 3.f, C::UA(C::Acc(), 0.9f * cardA), 64, 2.0f);

    const ImVec2 ts = fn->CalcTextSizeA(tfs, FLT_MAX, 0.f, title);
    const float y = avCy + avR + gapAvTitle;
    dl->AddText(fn, tfs, {w0.x + (WW - ts.x) * 0.5f, y}, C::UA(C::Txt(), cardA), title);
    return y + tfs + gapTitleBtn;
}

static float SegmentedControl(ImDrawList* dl, ImFont* fn, float fs, float x0, float top,
                              float cw, const char* const* names, int count,
                              float selT, float cardA) {
    const float segH = 60.f;
    const float segFS = fs * 1.1f;
    const float gap = 12.f;
    const float segW = (cw - gap * (count - 1)) / count;

    for (int i = 0; i < count; ++i) {
        const float px0 = x0 + (float)i * (segW + gap);
        dl->AddRectFilled({px0, top}, {px0 + segW, top + segH},
                          C::UA(C::Card(), cardA), R::Btn);
        if (g_state.ui_show_sep)
            dl->AddRect({px0, top}, {px0 + segW, top + segH},
                        C::UA(C::Sep(), 0.9f * cardA), R::Btn, 1.3f);
    }

    const float hx0 = x0 + selT * (segW + gap);
    dl->AddRectFilled({hx0, top}, {hx0 + segW, top + segH},
                      C::UA(C::Acc(), cardA), R::Btn);
    if (g_state.ui_show_sep)
        dl->AddRect({hx0, top}, {hx0 + segW, top + segH},
                    C::UA(C::Sep(), 0.9f * cardA), R::Btn, 1.3f);

    for (int i = 0; i < count; ++i) {
        const float px0 = x0 + (float)i * (segW + gap);
        const ImVec2 tsz = fn->CalcTextSizeA(segFS, FLT_MAX, 0.f, names[i]);
        const float proximity = 1.f - ImClamp(fabsf(selT - (float)i), 0.f, 1.f);
        const ImU32 textCol = proximity > 0.5f ? IM_COL32(255, 255, 255, 255)
                                               : C::UA(C::Txt(), cardA);
        dl->AddText(fn, segFS,
                    {px0 + (segW - tsz.x) * 0.5f, top + (segH - tsz.y) * 0.5f},
                    textCol, names[i]);
    }
    return segH;
}

static void RenderVersionContent(ImDrawList* dl, float WW, float WH) {
    auto& io = ImGui::GetIO();
    const float dt = ImClamp(io.DeltaTime, 0.0005f, 0.05f);
    ImFont* fn = ImGui::GetFont();
    const float fs = ImGui::GetFontSize();

    Tick(g_versionCardA, true, dt, 9.f);
    const float cardA = g_versionCardA;
    const ImVec2 w0 = g_win.pos;

    CardExitButton(dl, w0, WW, cardA, xv::StrStable(xv::sid::kMiVersionExit));

    const float padX = 46.f;
    const float cx = w0.x + padX;
    const float cw = WW - padX * 2.f;

    const float y = CardAvatarTitle(dl, fn, fs, w0, WW, WH, cardA,
                                    g_Lang->version_title);

    const int kSeg = 2;
    const char* names[kSeg] = {g_Lang->version_release, g_Lang->version_beta};
    const float gap = 12.f;
    const float segW = (cw - gap * (kSeg - 1)) / kSeg;

    const int target_sel = g_versionPicked ? g_version : (g_versionChosen ? g_version : 0);
    const float targetT = (float)target_sel;
    if (g_versionSelT < 0.f) { g_versionSelT = targetT; g_versionSelVel = 0.f; }
    SpringTick(g_versionSelT, g_versionSelVel, targetT, dt);

    const float segH = SegmentedControl(dl, fn, fs, cx, y, cw, names, kSeg,
                                        g_versionSelT, cardA);

    ImGui::SetCursorScreenPos({cx, y});
    ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiVersionSel), {cw, segH});
    const bool popBlocking = (g_pop.visible && !g_pop.closing);
    if (WasTappedHere() && !popBlocking && !IsScrollDragging() &&
        !g_input.touchConsumed && !g_versionChosen) {
        const ImVec2 mp = io.MousePos;
        int idx = (int)floorf((mp.x - cx) / (segW + gap));
        idx = ImClamp(idx, 0, kSeg - 1);
        g_version = idx;
        g_versionPicked = true;
        g_versionConfirmT = 0.f;
        game_set_beta(idx == 1);
        PlaySound(SND_CLICK);
    }

    if (g_versionPicked && !g_versionChosen) {
        g_versionConfirmT += dt;
        if (g_versionConfirmT >= 0.45f) g_versionChosen = true;
    }

    DrawPopover(dt, g_win.pos, WW, WH);
}

static void RenderModeContent(ImDrawList* dl, float WW, float WH) {
    auto& io = ImGui::GetIO();
    const float dt = ImClamp(io.DeltaTime, 0.0005f, 0.05f);
    ImFont* fn = ImGui::GetFont();
    const float fs = ImGui::GetFontSize();

    Tick(g_versionCardA, true, dt, 9.f);
    const float cardA = g_versionCardA;
    const ImVec2 w0 = g_win.pos;

    CardExitButton(dl, w0, WW, cardA, xv::StrStable(xv::sid::kMiModeExit));

    const float padX = 46.f;
    const float cx = w0.x + padX;
    const float cw = WW - padX * 2.f;

    const float y = CardAvatarTitle(dl, fn, fs, w0, WW, WH, cardA,
                                    g_Lang->mode_title);

    const int kSeg = 3;
    const char* names[kSeg] = {g_Lang->mode_direct, g_Lang->mode_rt,
                               g_Lang->mode_qx};
    const float gap = 12.f;
    const float segW = (cw - gap * (kSeg - 1)) / kSeg;

    const float targetT = (float)g_mode;
    if (g_modeSelT < 0.f) { g_modeSelT = targetT; g_modeSelVel = 0.f; }
    SpringTick(g_modeSelT, g_modeSelVel, targetT, dt);

    const float segH = SegmentedControl(dl, fn, fs, cx, y, cw, names, kSeg,
                                        g_modeSelT, cardA);

    if (g_modeFailed) {
        const char* err = g_Lang->driver_not_found;
        const ImVec2 es = fn->CalcTextSizeA(fs, FLT_MAX, 0.f, err);
        dl->AddText(fn, fs, {w0.x + (WW - es.x) * 0.5f, y + segH + 18.f},
                    IM_COL32(255, 90, 90, (int)(255 * cardA)), err);
    }

    ImGui::SetCursorScreenPos({cx, y});
    ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiModeSel), {cw, segH});
    const bool popBlocking = (g_pop.visible && !g_pop.closing);
    if (WasTappedHere() && !popBlocking && !IsScrollDragging() &&
        !g_input.touchConsumed && !g_modeChosen) {
        const ImVec2 mp = io.MousePos;
        int idx = (int)floorf((mp.x - cx) / (segW + gap));
        idx = ImClamp(idx, 0, kSeg - 1);
        g_mode = idx;
        if (idx == 0) {
            g_modeChosen = true;
            g_modeFailed = false;
            PlaySound(SND_CLICK);
        } else if (game_driver_attach(idx)) {
            g_modeChosen = true;
            g_modeFailed = false;
            PlaySound(SND_CLICK);
        } else {
            g_modeFailed = true;
            PlaySound(SND_CLICK);
            ShowToast(g_Lang->driver_not_found);
        }
    }

    DrawPopover(dt, g_win.pos, WW, WH);
}

static void RenderLoginContent(ImDrawList* dl, float WW, float WH) {
    auto& io = ImGui::GetIO();
    float dt = ImClamp(io.DeltaTime, 0.0005f, 0.05f);
    ImFont* fn = ImGui::GetFont();
    const float fs = ImGui::GetFontSize();

    static bool s_init = false;
    if (!s_init) {
        s_init = true;
        std::string saved = AuthGetSavedKey();
        if (!saved.empty()) g_keyInput = saved;
    }

    AuthState st = AuthGetState();

    if (g_login.phase != LP_CHECKING && st == AUTH_CHECKING) {
        g_login.phase = LP_CHECKING; g_login.t = 0.f;
    }
    if (st == AUTH_OK && g_login.phase != LP_SUCCESS) {
        g_login.phase = LP_SUCCESS; g_login.t = 0.f; g_login.playedOk = false;
        g_netRetry = 0.f; g_netToast = false;
    }
    if ((st == AUTH_FAIL || st == AUTH_NET_ERROR) &&
        g_login.phase == LP_CHECKING) {
        g_login.phase = LP_FAIL; g_login.t = 0.f;
        PlaySound(SND_CLICK);
        if (st == AUTH_FAIL) {
            g_keyInput.clear();
            g_netRetry = 0.f;
        } else if (g_netRetry <= 0.f) {
            g_netRetry = 3.f;
            if (!g_netToast) { g_netToast = true; ShowToast(g_Lang->auth_net_error); }
        }
    }

    if (g_netRetry > 0.f && g_login.phase != LP_CHECKING && g_login.phase != LP_SUCCESS) {
        g_netRetry -= dt;
        if (g_netRetry <= 0.f) {
            g_netRetry = 0.f;
            if (!g_keyInput.empty()) AuthCheck(g_keyInput);
        }
    }

    g_login.t += dt;
    Tick(g_login.cardA, g_login.phase == LP_FORM ? 1.f : 0.f, dt, 9.f);

    ImVec2 w0 = g_win.pos;
    bool popOpen = g_pop.visible;

    if (g_login.phase == LP_SUCCESS) {
        if (!g_login.playedOk) { g_login.playedOk = true; PlaySound(SND_SUCCESS); }
        float p = Clamp01(g_login.t / 1.5f);
        DrawSuccessAnim(dl, fn, fs, WW, WH, p);
        if (g_login.t >= 1.5f) { g_loginReady = true; g_login.phase = LP_FORM; }
        DrawPopover(dt, g_win.pos, WW, WH);
        return;
    }

    if (g_login.phase == LP_FAIL) {
        float p = Clamp01(g_login.t / 1.1f);
        DrawFailAnim(dl, fn, fs, WW, WH, p);
        if (g_login.t >= 1.1f) {
            g_login.phase = LP_FORM; g_login.t = 0.f;
        }
        DrawPopover(dt, g_win.pos, WW, WH);
        return;
    }

    float cardA = g_login.cardA;

    {
        const float r = 22.f;
        float ex = w0.x + WW - 24.f - r;
        float ey = w0.y + 24.f + r;
        bool held = !popOpen && io.MouseDown[0]
                 && (io.MousePos.x-ex)*(io.MousePos.x-ex) + (io.MousePos.y-ey)*(io.MousePos.y-ey) <= (r+6.f)*(r+6.f);
        dl->AddCircleFilled({ex, ey + 2.f}, r, IM_COL32(0,0,0,28), 32);
        dl->AddCircleFilled({ex, ey}, r, C::UA(C::Card(),cardA), 32);
        if (held) dl->AddCircleFilled({ex, ey}, r, IM_COL32(255,255,255,26), 32);
        dl->AddCircle({ex, ey}, r, C::UA(C::Sep(),0.9f*cardA), 32, 1.4f);
        float cs = 9.f;
        dl->AddLine({ex-cs, ey-cs}, {ex+cs, ey+cs}, C::UA(C::Dim(),cardA), 3.f);
        dl->AddLine({ex+cs, ey-cs}, {ex-cs, ey+cs}, C::UA(C::Dim(),cardA), 3.f);
        ImGui::SetCursorScreenPos({ex-r, ey-r});
        ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiAuthExit), {r*2.f, r*2.f});
        if (LoginCircleTap(ex, ey, r, !popOpen)) {
            PopoverOpen(g_Lang->exit_question, 2);
            g_popOpenClickPos = io.MousePos;
            PlaySound(SND_CLICK);
        }
    }

    const float padX = 44.f;
    float cx = w0.x + padX;
    float cw = WW - padX * 2.f;

    float y = w0.y + 26.f;

    const float avR = 40.f;
    float avCx = w0.x + WW * 0.5f, avCy = y + avR;
    dl->AddCircleFilled({avCx + 2.f, avCy + 3.f}, avR, IM_COL32(0,0,0,int(26*cardA)), 64);
    dl->AddCircleFilled({avCx, avCy}, avR, C::UA(C::Card(),cardA), 64);
    if (g_sprite.texture) {
        int col = g_sprite.frame % SpriteState::Cols;
        int row = g_sprite.frame / SpriteState::Cols;
        float u0 = col/(float)SpriteState::Cols, u1 = (col+1)/(float)SpriteState::Cols;
        float v0 = row/(float)SpriteState::Rows, v1 = (row+1)/(float)SpriteState::Rows;
        dl->AddImageRounded(g_sprite.texture,
            {avCx-avR, avCy-avR}, {avCx+avR, avCy+avR},
            {u0,v0},{u1,v1}, IM_COL32(255,255,255,(int)(255*cardA)), avR);
    }
    dl->AddCircle({avCx, avCy}, avR+2.5f, C::UA(C::Acc(),0.9f*cardA), 64, 2.f);
    y = avCy + avR + 12.f;

    {
        const char* t = g_Lang->auth_title;
        float tfs = fs * 1.18f;
        ImVec2 ts = fn->CalcTextSizeA(tfs, FLT_MAX, 0.f, t);
        dl->AddText(fn, tfs, {w0.x + (WW-ts.x)*0.5f, y}, C::UA(C::Txt(),cardA), t);
        y += tfs + 5.f;
        const char* sub = g_Lang->auth_subtitle;
        float sfs = fs * 0.74f;
        ImVec2 ss = fn->CalcTextSizeA(sfs, FLT_MAX, 0.f, sub);
        dl->AddText(fn, sfs, {w0.x + (WW-ss.x)*0.5f, y}, C::UA(C::Dim(),cardA), sub);
        y += sfs + 14.f;
    }

    {
        const float boxH = 58.f;
        ImVec2 b0 = {cx, y}, b1 = {cx+cw, y+boxH};
        dl->AddRectFilled(b0, b1, C::UA(C::Card(),cardA), R::Btn);
        dl->AddRect(b0, b1, C::UA(C::Acc(),0.55f*cardA), R::Btn, 1.6f);
        float midY = y + boxH*0.5f;
        float ifs = fs*0.9f;
        if (g_keyInput.empty()) {
            ImVec2 ph = fn->CalcTextSizeA(ifs, FLT_MAX, 0.f, g_Lang->auth_key_hint);
            dl->AddText(fn, ifs, {cx+22.f, midY-ph.y*0.5f}, C::UA(C::Dim(),0.55f*cardA), g_Lang->auth_key_hint);
        } else {
            const char* ktxt = g_keyInput.c_str();
            ImVec2 ts = fn->CalcTextSizeA(ifs, cw-44.f, 0.f, ktxt);
            float dx = cx+22.f;
            if (ts.x > cw-44.f) dx = b1.x-22.f-ts.x;
            dl->AddText(fn, ifs, {dx, midY-ts.y*0.5f}, C::UA(C::Txt(),cardA), ktxt);
        }
        if (g_login.phase == LP_CHECKING) {
            float spR = 11.f;
            float spCx = b1.x - 24.f - spR, spCy = midY;
            float t0 = (float)ImGui::GetTime()*5.f;
            for (int k=0;k<8;k++) {
                float a = t0 + k*0.785398f;
                float px = spCx + cosf(a)*spR, py = spCy + sinf(a)*spR;
                int al = (int)(cardA*(80+160*(0.5f+0.5f*sinf(t0*1.6f+k*0.9f))));
                ImVec4 ac = C::Acc();
                dl->AddCircleFilled({px,py},2.6f, IM_COL32((int)(ac.x*255),(int)(ac.y*255),(int)(ac.z*255),al),12);
            }
        }
        y += boxH + 14.f;
    }

    bool busy = (g_login.phase == LP_CHECKING);
    bool popBlocking = g_pop.visible && !g_pop.closing;
    bool keyTap = false, enterTap = false;
    if (!busy && !popBlocking) {
        float kbW = cw;
        float kbH = Keyboard::Height(kbW);
        float kbX = cx;
        float kbY = w0.y + WH - kbH - 18.f;
        Keyboard::Render(dl, fn, fs, kbX, kbY, kbW, g_keyInput, keyTap, enterTap);
    }
    if (keyTap) PlaySound(SND_CLICK);
    if (enterTap) {
        PlaySound(SND_CLICK);
        g_netToast = false; g_netRetry = 0.f;
        AuthCheck(g_keyInput);
    }

    DrawPopover(dt, g_win.pos, WW, WH);
}

void RenderMenu() {
    auto& io = ImGui::GetIO();
    float dt = io.DeltaTime;
    if (dt > 0.1f) dt = 0.1f;

    if (g_fire_zone_armed || g_fire_click_block) {
        io.MouseClicked[0] = false;
        io.MouseReleased[0] = false;
        io.MouseDown[0] = false;
    }

    if (g_menu_orient != displayInfo.orientation || g_menu_dw != (int)displayInfo.width || g_menu_dh != (int)displayInfo.height) {
        g_menu_orient = displayInfo.orientation;
        g_menu_dw = (int)displayInfo.width;
        g_menu_dh = (int)displayInfo.height;
        CenterMenuOnDisplay();
    }

    g_menuFadeIn += dt * 1.2f;
    if (g_menuFadeIn > 1.f) g_menuFadeIn = 1.f;

    CfgWatchTick();
    g_Lang = g_state.ui_lang ? &LANG_RU : &LANG_EN;
    Tick(g_themeT, g_darkTheme, dt, 6.f);
    Tick(g_state.a_aim_touch,  g_state.aim_touch,          dt);
    Tick(g_state.a_aim_zone,   g_state.aim_zone_enabled,   dt);
    Tick(g_state.a_aim_zone_show, g_state.aim_zone_enabled, dt);
    Tick(g_state.a_aim_ads,    g_state.aim_ads,            dt);
    Tick(g_state.a_aim_hipfire,g_state.aim_hipfire,        dt);
    Tick(g_state.a_aim_head,   g_state.aim_bone == 0,      dt);
    Tick(g_state.a_aim_chest,  g_state.aim_bone == 1,      dt);
    Tick(g_state.a_aim_pelvis, g_state.aim_bone == 2,      dt);
    Tick(g_state.a_esp_box,    g_state.esp_box,            dt);
    Tick(g_state.a_esp_name,   g_state.esp_name,           dt);
    Tick(g_state.a_esp_weapon, g_state.esp_weapon,         dt);
    Tick(g_state.a_esp_hp,     g_state.esp_hp,             dt);
    Tick(g_state.a_esp_wall,   g_state.esp_wall,           dt);
    Tick(g_state.a_esp_tracer, g_state.esp_tracer,         dt);
    Tick(g_state.a_esp_skeleton, g_state.esp_skeleton,     dt);
    Tick(g_state.a_esp_aim_arrow, g_state.esp_aim_arrow,   dt);
    Tick(g_state.a_esp_arrows,  g_state.esp_arrows,        dt);
    Tick(g_state.a_esp_animals, g_state.esp_animals,       dt);
    Tick(g_state.a_esp_crates,  g_state.esp_crates,        dt);
    Tick(g_state.a_esp_bots,    g_state.esp_bots,          dt);
    Tick(g_state.a_esp_cupboard, g_state.esp_cupboard,     dt);
    Tick(g_state.a_esp_turret,  g_state.esp_turret,        dt);
    Tick(g_state.a_memory_always_day, g_state.memory_always_day, dt);
    Tick(g_state.a_ignore_teammates, g_state.ignore_teammates, dt);
    Tick(g_state.a_ore_tree,   g_state.ore_tree,           dt);
    Tick(g_state.a_af_tree,    g_state.af_tree,            dt);
    Tick(g_state.a_ore_sulfur, g_state.ore_sulfur,         dt);
    Tick(g_state.a_ore_iron,   g_state.ore_iron,           dt);
    Tick(g_state.a_ore_stone,  g_state.ore_stone,          dt);
    Tick(g_state.a_memory_no_recoil, g_state.memory_no_recoil, dt);
    Tick(g_state.a_memory_no_spread, g_state.memory_no_spread, dt);
    Tick(g_state.a_memory_hands_fov, g_state.memory_hands_fov, dt);
    Tick(g_state.a_memory_aspect, g_state.memory_aspect, dt);
    Tick(g_state.a_memory_black_sky, g_state.memory_black_sky, dt);
    Tick(g_state.a_crosshair_custom, g_state.crosshair_custom, dt);
    Tick(g_state.a_memory_freecam, g_state.memory_freecam, dt);
    Tick(g_state.a_freecam_bind, g_state.freecam_bind, dt);
    Tick(g_state.a_memory_xray, g_state.memory_xray, dt);
    Tick(g_state.a_af_sulfur, g_state.af_sulfur, dt);
    Tick(g_state.a_af_iron,   g_state.af_iron,   dt);
    Tick(g_state.a_af_stone,  g_state.af_stone,  dt);
    Tick(g_state.a_ui_fps,     g_state.ui_fps,             dt);
    Tick(g_state.a_ui_dark,    g_state.ui_dark_mode,       dt);
    Tick(g_state.a_ui_sep,     g_state.ui_show_sep,        dt);
    ApplyTheme();

    if (g_cfgLoadedIdx >= 0 && g_cfgLoadedIdx < kMaxConfigs)
        g_cfgLoadAnim[g_cfgLoadedIdx] += (1.f - g_cfgLoadAnim[g_cfgLoadedIdx]) * 10.f * dt;

    if (g_sprite.texture && SpriteState::Total > 1) {
        g_sprite.timer += dt;
        if (g_sprite.timer >= 1.f / SpriteState::FPS) {
            g_sprite.timer -= 1.f / SpriteState::FPS;
            g_sprite.frame = (g_sprite.frame + 1) % SpriteState::Total;
        }
    }

    bool anyOverlayOpen = g_pop.visible && !g_pop.closing;

    if (io.MouseClicked[0] && anyOverlayOpen) g_input.touchConsumed = true;
    if (io.MouseClicked[0] && !menu_open) g_input.touchConsumed = true;

    bool anyOverlayVisible = g_pop.visible;
    if (!io.MouseDown[0] && !anyOverlayVisible) g_input.touchConsumed = false;

    DrawWatermark(dt);
    DrawToast(dt);

    ImGenieParams genieParams;
    genieParams.transitions.animDuration = 0.4f;
    genieParams.transitions.genie.cellsV = 24;
    genieParams.transitions.genie.cellsH = 8;

    genieParams.transitions.genie.side = ImGenieSide_Top;
    genieParams.transitions.genie.destRect = {
        g_genieTargetRect.x0, g_genieTargetRect.y0,
        g_genieTargetRect.x1, g_genieTargetRect.y1
    };
    genieParams.effects.wobbly.spring.stiffness = 120.f;
    genieParams.effects.wobbly.spring.damping = 8.f;
    genieParams.effects.wobbly.spring.substeps = 8;
    genieParams.effects.wobbly.spring.cellsH = 20;
    genieParams.effects.wobbly.spring.cellsV = 20;
    genieParams.effects.wobbly.maxStiffness = 200.f;
    genieParams.effects.wobbly.settleDuration = 0.15f;

    static bool s_genieReady = false;
    if (!s_genieReady) {
        s_genieReady = true;
        CenterMenuOnDisplay();
    }

    const bool genieAllowed = ImGenie::Allow(kMenuWinName, &menu_open, &genieParams);
    const bool genieActive  = ImGenie::IsEffectActive(kMenuWinName);

    if (!genieAllowed) return;
    if (!menu_open) return;

    {
        static constexpr float kStiffness = 220.f;
        static constexpr float kDamping   = 24.f;
        static constexpr float kPosTol    = 0.002f;
        static constexpr float kVelTol    = 0.01f;
        float force = -kStiffness * g_pillPulse - kDamping * g_pillPulseVel;
        g_pillPulseVel += force * dt;
        g_pillPulse += g_pillPulseVel * dt;
        if (fabsf(g_pillPulse) < kPosTol && fabsf(g_pillPulseVel) < kVelTol) {
            g_pillPulse = 0.f;
            g_pillPulseVel = 0.f;
        }
    }

    const float WW = g_win.w, WH = g_win.h;
    const float lW_ = 265, hH_ = 66;

    static bool s_wasLoggedOut = false;
    if (!g_loginReady) {
        if (!s_wasLoggedOut) {
            s_wasLoggedOut = true;
            g_win.w = WW_MIN;
            g_win.h = WH_MIN;
            CenterMenuOnDisplay();
        }
        g_win.resizing = false;
        EndWinDrag();
    } else if (s_wasLoggedOut) {
        s_wasLoggedOut = false;
        CenterMenuOnDisplay();
    }

    if (g_loginReady) {
        bool inResize = io.MousePos.x >= g_win.pos.x + g_win.w - R::Card - 14.f
                     && io.MousePos.x <= g_win.pos.x + g_win.w + 14.f
                     && io.MousePos.y >= g_win.pos.y + g_win.h - R::Card - 14.f
                     && io.MousePos.y <= g_win.pos.y + g_win.h + 14.f;

        if (!io.MouseDown[0]) g_win.resizing = false;

        bool anyOverlay = g_pop.visible && !g_pop.closing;
        if (!anyOverlay && io.MouseClicked[0] && inResize) {
            g_win.resizing         = true;
            g_win.resizeTouchStart = io.MousePos;
            g_win.sizeStart        = {g_win.w, g_win.h};
        }

        if (g_win.resizing && io.MouseDown[0]) {
            float dx = io.MousePos.x - g_win.resizeTouchStart.x;
            float dy = io.MousePos.y - g_win.resizeTouchStart.y;
            g_win.w = ImMax(WW_MIN, g_win.sizeStart.x + dx);
            g_win.h = ImMax(WH_MIN, g_win.sizeStart.y + dy);
        }

    {
        if (!io.MouseDown[0]) EndWinDrag();

        const float tabsStartY = g_win.pos.y + 120.f;
        if (!g_win.dragging && io.MouseDown[0]
            && !(g_pop.visible && !g_pop.closing)
            && !g_win.resizing && !genieActive) {
            float tx = io.MouseClickedPos[0].x, ty = io.MouseClickedPos[0].y;
            bool inLeftHeader = tx >= g_win.pos.x && tx < g_win.pos.x + lW_
                             && ty >= g_win.pos.y && ty < tabsStartY;
            bool inRHdr = tx >= g_win.pos.x + lW_ && tx < g_win.pos.x + g_win.w
                       && ty >= g_win.pos.y && ty < g_win.pos.y + hH_;
            if (inLeftHeader || inRHdr) {
                float dx = io.MousePos.x - io.MouseClickedPos[0].x;
                float dy = io.MousePos.y - io.MouseClickedPos[0].y;
                if (fabsf(dx) + fabsf(dy) > 8.f) {
                    BeginWinDrag(io.MouseClickedPos[0]);
                }
            }
        }

        if (g_win.dragging && io.MouseDown[0]) {
            float dx = io.MousePos.x - g_win.touchStart.x;
            float dy = io.MousePos.y - g_win.touchStart.y;
            g_win.pos.x = g_win.posStart.x + dx;
            g_win.pos.y = g_win.posStart.y + dy;
        }

        float dw = 0.f, dh = 0.f;
        VisibleScreen(dw, dh);
        if (dw > 100.f && dh > 100.f) {
            g_win.pos.x = ImClamp(g_win.pos.x, 0.f, ImMax(0.f, dw - g_win.w));
            g_win.pos.y = ImClamp(g_win.pos.y, 0.f, ImMax(0.f, dh - g_win.h));
        }
    }
    }

    ImGui::SetNextWindowSize({g_win.w, g_win.h}, ImGuiCond_Always);
    ImGui::SetNextWindowPos(g_win.pos, ImGuiCond_Always);

    ImGuiWindowFlags wf = ImGuiWindowFlags_NoResize    | ImGuiWindowFlags_NoCollapse
                        | ImGuiWindowFlags_NoTitleBar  | ImGuiWindowFlags_NoScrollbar
                        | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBackground
                        | ImGuiWindowFlags_NoMove      | ImGuiWindowFlags_NoNav;

    ImGui::Begin(xv::StrStable(xv::sid::kMiMenu), nullptr, wf);
    {
        auto  bgP  = g_win.pos;
        auto* bgDL = ImGui::GetWindowDrawList();
        bgDL->AddRectFilled(bgP, {bgP.x + WW, bgP.y + WH}, C::U(C::Bg()), R::Card);
    }

    if (!g_loginReady) {
        if (!g_versionChosen)
            RenderVersionContent(ImGui::GetWindowDrawList(), WW, WH);
        else
            RenderLoginContent(ImGui::GetWindowDrawList(), WW, WH);
        ImGui::End();
        return;
    }

    if (!g_modeChosen) {
        RenderModeContent(ImGui::GetWindowDrawList(), WW, WH);
        ImGui::End();
        return;
    }

    ImVec2 wp = g_win.pos;
    const float lW = 265, cH = g_win.h, cW = g_win.w - lW;

    g_state.tab_alpha += (1.f - g_state.tab_alpha) * 5.f * dt;
    if (g_state.tab_alpha > .999f) g_state.tab_alpha = 1.f;
    SpringTick(g_state.tab_slide, g_state.tab_slide_vel, 0.f, dt);

    ImGui::SetCursorPos({0, 0});
    ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));
    ImGui::BeginChild(xv::StrStable(xv::sid::kMiLp), {lW, cH}, false, ImGuiWindowFlags_NoScrollbar);
    auto  lpPos = ImGui::GetWindowPos();
    auto* ldl   = ImGui::GetWindowDrawList();
    ldl->AddRectFilled(lpPos, {lpPos.x + lW, lpPos.y + cH}, C::U(C::LeftBg()), R::Card);

    {

        float t = EaseInOut(g_themeT);
        ImU32 fill[3] = {IM_COL32(255, 95, 87, 255), IM_COL32(255, 189, 46, 255), IM_COL32(40, 200, 64, 255)};

        const ImVec2 dcp = io.MouseClickedPos[0];
        const ImVec2 dmp = io.MousePos;
        const float dmovedSq = (dmp.x - dcp.x) * (dmp.x - dcp.x) + (dmp.y - dcp.y) * (dmp.y - dcp.y);

        const bool dotsBlocked = IsScrollDragging() || genieActive
                              || g_menuFadeIn < 1.f;

        for (int i = 0; i < 3; i++) {
            float cx2 = lpPos.x + 28.f + i * 34.f, cy2 = lpPos.y + 32.f;
            const float hitR = 20.f;

            auto inside = [&](const ImVec2& p) {
                return (p.x - cx2) * (p.x - cx2) + (p.y - cy2) * (p.y - cy2) <= hitR * hitR;
            };
            bool tapped = !dotsBlocked && io.MouseReleased[0] && dmovedSq < 25.f * 25.f
                       && inside(dcp) && inside(dmp);

            const float r = 13.f;
            ldl->AddCircleFilled({cx2, cy2}, r, fill[i], 48);
            ImU32 bordCol = IM_COL32(
                int(Lerpf(0,   255, t)),
                int(Lerpf(0,   255, t)),
                int(Lerpf(0,   255, t)),
                int(Lerpf(180, 210, t))
            );
            ldl->AddCircle({cx2, cy2}, r + 1.2f, bordCol, 48, 1.5f);

            if (tapped) {
                g_input.touchConsumed = true;
                menu_open = false;
                CloseMenuOverlays();
                PlaySound(SND_CLICK);
            }
        }
    }

    {
        const float Rad = lW * 0.28f;
        float cx = lpPos.x + lW * 0.5f, cy = lpPos.y + 30.f + 20.f + Rad + 10.f;
        ldl->AddCircleFilled({cx + 2.f, cy + 3.f}, Rad, IM_COL32(0, 0, 0, 20), 64);
        ldl->AddCircleFilled({cx, cy}, Rad, C::U(C::Card()), 64);
        if (g_sprite.texture) {
            int col = g_sprite.frame % SpriteState::Cols;
            int row = g_sprite.frame / SpriteState::Cols;
            float u0 = col       / (float)SpriteState::Cols;
            float u1 = (col + 1) / (float)SpriteState::Cols;
            float v0 = row       / (float)SpriteState::Rows;
            float v1 = (row + 1) / (float)SpriteState::Rows;
            ldl->AddImageRounded(g_sprite.texture,
                {cx - Rad, cy - Rad}, {cx + Rad, cy + Rad}, {u0, v0}, {u1, v1}, IM_COL32(255, 255, 255, 255), Rad);
        } else {
            ImU32 avatarBg   = g_darkTheme ? IM_COL32(40, 60, 90, 255)   : IM_COL32(200, 218, 240, 255);
            ImU32 avatarFig  = g_darkTheme ? IM_COL32(70, 100, 145, 255)  : IM_COL32(120, 148, 185, 255);
            ldl->AddCircleFilled({cx, cy}, Rad, avatarBg, 64);
            float hR = Rad * 0.30f;
            ldl->AddCircleFilled({cx, cy - Rad * 0.22f}, hR, avatarFig, 32);
            ldl->AddRectFilled({cx - Rad * 0.42f, cy + Rad * 0.08f}, {cx + Rad * 0.42f, cy + Rad * 0.82f}, avatarFig, Rad * 0.22f);
        }
        {
            float t = EaseInOut(g_themeT);
            float ringAlpha = Lerpf(0.72f, 0.90f, t);
            ldl->AddCircle({cx, cy}, Rad + 2.5f, C::UA(C::Acc(), ringAlpha), 64, 2.f);
        }
        ImGui::SetCursorPosY(30.f + 20.f + Rad * 2.f + 10.f + 18.f);
    }

    {
        float y = ImGui::GetCursorScreenPos().y;
        ldl->AddLine({lpPos.x + 20.f, y}, {lpPos.x + lW - 20.f, y}, C::U(C::Sep()), 0.8f);
        ImGui::Dummy({1.f, 2.f});
    }

    const char* tabNames[6] = {
        g_Lang->tab_main, g_Lang->tab_aim, g_Lang->tab_visuals, g_Lang->tab_memory, g_Lang->tab_other, g_Lang->tab_settings
    };
    const float tabH = Layout::TabH, tabPad = Layout::TabPad;

    ImGui::Dummy({1.f, 6.f});
    for (int i = 0; i < 6; i++) {
        auto pos2 = ImGui::GetCursorScreenPos();
        tab_rects[i] = {pos2.y};
        char tabId[16];
        snprintf(tabId, sizeof(tabId), xv::StrStable(xv::sid::kMiTabD), i);
        ImGui::InvisibleButton(tabId, {lW, tabH});
        if (WasTappedHere() && !IsScrollDragging() && !g_input.touchConsumed && g_state.cur_tab != i) {
            g_state.cur_tab       = i;
            g_state.tab_alpha     = 0.f;
            g_state.tab_slide     = 50.f;
            g_state.tab_slide_vel = 0.f;
            g_scrollMain          = {};
        }
    }

    {
        float targetRelY = tab_rects[g_state.cur_tab].sy - wp.y;
        if (pill_y < 0.f) { pill_y = targetRelY; pill_vel = 0.f; }
        SpringTick(pill_y, pill_vel, targetRelY, dt);
    }
    float pill_screen_y = wp.y + pill_y;

    {

        auto*       fdl = ldl;
        const float pad = 8.f, pR = R::Pill;
        float px0 = wp.x + pad, px1 = wp.x + lW - pad;
        float py   = pill_screen_y, ph = tabH;
        float py0  = py + tabPad - 4.f, py1 = py + ph - tabPad + 4.f;
        fdl->AddRectFilled({px0, py0}, {px1, py1}, C::U(C::Card()), pR);
        fdl->AddRect({px0, py0}, {px1, py1}, C::U(C::Acc()), pR, 4.f);
    }

    {
        auto* fdl = ldl;
        const float iconSize = 52.f;
        const float gap      = 16.f;
        const float leftPad  = 18.f;
        const float startX   = wp.x + leftPad;
        for (int i = 0; i < 6; i++) {
            float    py  = tab_rects[i].sy;
            ImVec4   col = (i == g_state.cur_tab) ? C::Acc() : C::Dim();
            const float tfs = ImGui::GetFontSize() * 1.15f;
            auto tsz = ImGui::GetFont()->CalcTextSizeA(tfs, FLT_MAX, 0, tabNames[i]);
            float centerY = py + tabH * 0.5f;
            if (g_tabIcons[i]) {
                ImVec2 iMin = {startX, centerY - iconSize * 0.5f};
                ImVec2 iMax = {startX + iconSize, centerY + iconSize * 0.5f};
                fdl->AddImageRounded(g_tabIcons[i], iMin, iMax, {0,0}, {1,1}, IM_COL32(255,255,255,255), 10.f);
            }
            fdl->AddText(ImGui::GetFont(), tfs,
                {startX + iconSize + gap, centerY - tsz.y * 0.5f}, C::U(col), tabNames[i]);
        }
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();

    ImGui::SetCursorPos({lW, 0});
    ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));
    ImGui::BeginChild(xv::StrStable(xv::sid::kMiCp), {cW, cH}, false,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

    {
        const char* titles[6] = {g_Lang->tab_main, g_Lang->tab_aim, g_Lang->tab_visuals, g_Lang->tab_memory, g_Lang->tab_other, g_Lang->tab_settings};
        auto*  cdl = ImGui::GetWindowDrawList();
        auto   hp  = ImGui::GetWindowPos();
        const float hH = Layout::HeaderH;
        const float titleFS = ImGui::GetFontSize() * 1.45f;
        auto tsz = ImGui::GetFont()->CalcTextSizeA(titleFS, FLT_MAX, 0, titles[g_state.cur_tab]);
        cdl->AddText(ImGui::GetFont(), titleFS,
            {hp.x + (cW - tsz.x) * 0.5f, hp.y + (hH - tsz.y) * 0.5f}, C::U(C::Txt()), titles[g_state.cur_tab]);

        if (g_state.cur_tab == 5) {
            auto* fn = ImGui::GetFont();
            const float fs = ImGui::GetFontSize();
            const float inset = Layout::Inset;
            const float panelH = hH * 0.74f;
            const float lfs = fs * 1.2f;
            auto rSz = fn->CalcTextSizeA(lfs, FLT_MAX, 0, "Ru");
            auto eSz = fn->CalcTextSizeA(lfs, FLT_MAX, 0, "En");
            const float segW = std::max(rSz.x, eSz.x) + fs * 1.9f;
            const float total = segW * 2.0f;
            const float py = hp.y + hH - panelH - 2.f;
            const float px = hp.x + cW - inset - total;

            static float lang_sel_t = -1.f, lang_sel_vel = 0.f;
            const float target_t = g_state.ui_lang ? 0.f : 1.f;
            if (lang_sel_t < 0.f) { lang_sel_t = target_t; lang_sel_vel = 0.f; }
            SpringTick(lang_sel_t, lang_sel_vel, target_t, dt);

            cdl->AddRectFilled({px, py}, {px + total, py + panelH},
                               C::U(C::Card()), R::Pill);
            if (g_state.ui_show_sep)
                cdl->AddRect({px, py}, {px + total, py + panelH},
                             C::U(C::Sep()), R::Pill, 1.4f);

            const float m = 3.0f;
            const float lang_cx = px + segW * (lang_sel_t + 0.5f);
            float hx0 = lang_cx - segW * 0.5f + m;
            float hx1 = lang_cx + segW * 0.5f - m;
            float hy0 = py + m;
            float hy1 = py + panelH - m;
            if (g_pillPulse > 0.001f) {
                const float cxm = (hx0 + hx1) * 0.5f;
                const float cym = (hy0 + hy1) * 0.5f;
                const float pw = (hx1 - hx0) * (1.f + 0.10f * g_pillPulse);
                const float ph = (hy1 - hy0) * (1.f - 0.06f * g_pillPulse);
                hx0 = cxm - pw * 0.5f; hx1 = cxm + pw * 0.5f;
                hy0 = cym - ph * 0.5f; hy1 = cym + ph * 0.5f;
            }
            cdl->AddRectFilled({hx0, hy0}, {hx1, hy1}, C::U(C::Acc()), R::Pill);
            if (g_state.ui_show_sep)
                cdl->AddRect({hx0, hy0}, {hx1, hy1}, C::U(C::Sep()), R::Pill, 1.5f);

            const char* labels[2] = {"Ru", "En"};
            for (int i = 0; i < 2; ++i) {
                auto tsz = fn->CalcTextSizeA(lfs, FLT_MAX, 0, labels[i]);
                const float lcx = px + segW * (i + 0.5f);
                const float proximity = 1.f - ImClamp(
                    fabsf(lang_sel_t - i), 0.f, 1.f);
                ImU32 textCol = proximity > 0.5f ? IM_COL32(255, 255, 255, 255) : C::U(C::Txt());
                cdl->AddText(fn, lfs,
                             {lcx - tsz.x * 0.5f, py + (panelH - tsz.y) * 0.5f},
                             textCol, labels[i]);
            }

            ImGui::SetCursorScreenPos({px, py});
            ImGui::InvisibleButton(xv::StrStable(xv::sid::kMiLangsel), {total, panelH});
            if (WasTappedHere() && !IsScrollDragging() && !g_input.touchConsumed) {
                ImVec2 mp = ImGui::GetIO().MousePos;
                int want = (mp.x < px + segW) ? 1 : 0;
                if (want != g_state.ui_lang) {
                    g_state.ui_lang = want;
                    LangPopTrigger();
                    PlaySound(SND_CLICK);
                }
            }
            ImGui::SetCursorPos({0.0f, 0.0f});
        }ImGui::Dummy({cW, hH});
    }

    {
        const float areaH = cH - Layout::HeaderH;
        auto cpPos  = ImGui::GetWindowPos(); cpPos.y += Layout::HeaderH;
        const float cpRight = cpPos.x + cW;

        bool overlayBlocking = g_pop.visible && !g_pop.closing;
        static float s_maxScroll = 0.f;

        bool clickInRight = (io.MouseClickedPos[0].x >= cpPos.x)
                         && (io.MouseClickedPos[0].x <= cpRight)
                         && (io.MouseClickedPos[0].y >= cpPos.y)
                         && (io.MouseClickedPos[0].y <= cpPos.y + areaH);
        bool mIn = clickInRight
            && io.MousePos.x >= cpPos.x  && io.MousePos.x <= cpRight
            && io.MousePos.y >= cpPos.y  && io.MousePos.y <= cpPos.y + areaH;

        auto* cdl = ImGui::GetWindowDrawList();
        cdl->PushClipRect(cpPos, {cpRight, cpPos.y + areaH - 4.f}, true);

        float slideOffset = g_state.tab_slide;
        ImGui::SetCursorPosY(Layout::HeaderH - g_scrollMain.off + slideOffset);
        ImGui::SetCursorPosX(12.f);

        if (overlayBlocking) ImGui::BeginDisabled(true);
        float contentH = TabContent(g_state.cur_tab, dt, cW);
        if (overlayBlocking) ImGui::EndDisabled();

        if (g_state.tab_alpha < 0.999f) {
            float fadeA = 1.f - g_state.tab_alpha;
            cdl->AddRectFilled(cpPos, {cpRight, cpPos.y + areaH},
                C::UA(C::Bg(), fadeA), R::Card, ImDrawFlags_RoundCornersBottomRight);
        }

        s_maxScroll = ImMax(0.f, contentH - (areaH - 4.f));
        ScrollTick(g_scrollMain, mIn, overlayBlocking, s_maxScroll, dt);

        if (s_maxScroll > 0.f && !genieActive) {
            const float sbPad  = 5.f;
            const float sbVPad = 8.f;
            const float sbMinH = 36.f;
            const float sbW    = 8.f;

            float ratio     = (areaH * 0.28f) / (areaH + s_maxScroll);
            float sbHTarget = ImMax(sbMinH, areaH * ratio);
            float sbTrack   = areaH - sbHTarget - sbVPad * 2.f;
            float sbTTarget = (s_maxScroll > 0.f) ? (g_scrollMain.off / s_maxScroll) * sbTrack : 0.f;

            g_scrollMain.sb_w  = sbW;
            g_scrollMain.sb_y += (sbTTarget - g_scrollMain.sb_y) * 10.f * dt;
            g_scrollMain.sb_h += (sbHTarget - g_scrollMain.sb_h) * 10.f * dt;

            float sbX0 = cpRight - sbPad - sbW;
            float sbX1 = sbX0 + sbW;
            float sbY0 = cpPos.y + sbVPad + g_scrollMain.sb_y;
            float sbY1 = sbY0 + g_scrollMain.sb_h;

            ImU32 thumbCol = C::UA(C::Dim(), 0.55f);

            auto* fdl = ImGui::GetForegroundDrawList();
            fdl->PushClipRect(cpPos, {cpRight, cpPos.y + areaH}, true);
            fdl->AddRectFilled({sbX0, sbY0}, {sbX1, sbY1}, thumbCol, sbW * 0.5f);
            fdl->PopClipRect();
        }

        cdl->PopClipRect();
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();

    if (!genieActive)
    {
        static constexpr float kResizePad       = 22.f;
        static constexpr float kResizeStroke     = 10.f;
        static constexpr float kResizeGlowStroke = 6.f;
        static constexpr float kResizeGlowAlpha  = 0.13f;
        static constexpr float kArcStroke        = 14.f;
        static constexpr float kArcA0            = -0.25f;
        static constexpr float kArcA1            = IM_PI * 0.5f + 0.25f;
        static constexpr float kCornerOffset     = 10.f;

        auto* rdl = ImGui::GetForegroundDrawList();

        if (g_win.resizing) {
            const float pad = kResizePad, rr = R::Card + pad;
            float t = EaseInOut(g_themeT);
            ImVec4 bc = {Lerpf(1.f, C::Dark::Acc.x, t), Lerpf(1.f, C::Dark::Acc.y, t), Lerpf(1.f, C::Dark::Acc.z, t), Lerpf(0.9f, 0.8f, t)};
            rdl->AddRect({wp.x - pad,       wp.y - pad},
                         {wp.x + g_win.w + pad, wp.y + g_win.h + pad},
                         C::U(bc), rr, kResizeStroke);
            rdl->AddRect({wp.x - pad - 8.f,       wp.y - pad - 8.f},
                         {wp.x + g_win.w + pad + 8.f, wp.y + g_win.h + pad + 8.f},
                         C::UA(bc, kResizeGlowAlpha), rr + 8.f, kResizeGlowStroke);
        }

        float cx = wp.x + g_win.w - R::Card - kCornerOffset;
        float cy = wp.y + g_win.h - R::Card - kCornerOffset;

        ImU32       col   = g_darkTheme ? IM_COL32(200, 200, 210, 255) : IM_COL32(22, 22, 24, 255);
        const float r     = R::Card;
        const float thick = kArcStroke;
        const float a0    = kArcA0;
        const float a1    = kArcA1;

        rdl->PathArcTo({cx, cy}, r, a0, a1, 48);
        rdl->PathStroke(col, thick);

        float capR = thick * 0.5f;
        rdl->AddCircleFilled({cx + r * cosf(a0), cy + r * sinf(a0)}, capR, col, 24);
        rdl->AddCircleFilled({cx + r * cosf(a1), cy + r * sinf(a1)}, capR, col, 24);
    }

    if (g_pop.visible) {
        ImGui::SetCursorScreenPos(wp);
        ImGui::BeginChild(xv::StrStable(xv::sid::kMiModalCaptureLayer), {WW, WH}, false,
                          ImGuiWindowFlags_NoBackground |
                          ImGuiWindowFlags_NoInputs |
                          ImGuiWindowFlags_NoScrollbar |
                          ImGuiWindowFlags_NoScrollWithMouse);
        DrawPopover(dt, wp, WW, WH);
        ImGui::EndChild();
    }
    ImGui::End();

}

static void OverlaySignalHandler(int) {
    main_thread_flag.store(false);
}

static void InstallAltStack() {
    static unsigned char g_sigStack[128 * 1024];
    stack_t ss;
    memset(&ss, 0, sizeof(ss));
    ss.ss_sp = g_sigStack;
    ss.ss_size = sizeof(g_sigStack);
    ss.ss_flags = 0;
    sigaltstack(&ss, nullptr);
}

int main() {
    if (!IntegrityVerifyInitial()) _exit(173);
    if (!IntegrityCheckpoint(0xe2b7491c65ad803fULL)) _exit(173);
    signal(SIGHUP, SIG_IGN);
    {
        pid_t detached = fork();
        if (detached == 0) {
            setsid();
            signal(SIGHUP, SIG_IGN);
            int oomFd = open(xv::StrStable(xv::sid::kFileOomScore), O_WRONLY);
            if (oomFd >= 0) {
                char oomValue[8];
                int oomLen = snprintf(oomValue, sizeof(oomValue), "%d", -1000);
                if (oomLen > 0) {
                    std::size_t ignored = (std::size_t)write(oomFd, oomValue, (std::size_t)oomLen);
                    (void)ignored;
                }
                close(oomFd);
            }
        } else if (detached > 0) {
            _exit(0);
        }
    }
    signal(SIGTERM, OverlaySignalHandler);
    signal(SIGINT, OverlaySignalHandler);
    screen_config();
    int abs_ScreenX = displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width;
    int abs_ScreenY = displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width;

    native_window_screen_x = abs_ScreenX;
    native_window_screen_y = abs_ScreenY;
    ImGenie::CreateContext();
    if (!initGUI_draw(native_window_screen_x, native_window_screen_x)) return -1;
    IMGENIE_CHECKVERSION();
    Blur::Init();
    CfgWatchInit();
    AudioInit();
    AuthInit();
    mkdir(xv::StrC(xv::sid::kDownloadDir), 0777);
    Touch_Init(displayInfo.width, displayInfo.height, displayInfo.orientation, false);

    start_attach_thread();
    LoadAnimeImage();
    LoadTabIcons();
    ApplyTheme();
    CfgScanDir();
    CfgRestoreLast();
    CenterMenuOnDisplay();
    g_menuFadeIn = 0.f;
    std::uint64_t integrityFrame = 0;

    while (main_thread_flag) {
        integrityFrame++;
        if (!IntegrityCheckpoint(0x38f6c1a95d274be0ULL ^ integrityFrame)) _exit(173);
        g_frame_done.store(false);
        drawBegin();

        const bool active = g_loginReady && g_modeChosen;
        const bool af_xray = active && g_state.autofarm_on;

        if (menu_open || (integrityFrame % 4ULL) == 0ULL) {
            memory_no_recoil_update(active && g_state.memory_no_recoil);
            memory_no_spread_update(active && g_state.memory_no_spread);
            memory_hands_fov_update(active && g_state.memory_hands_fov,
                                    g_state.hands_fov_value);
            memory_black_sky_update(active && g_state.memory_black_sky);
            memory_always_day_update(active && g_state.memory_always_day);
            memory_crosshair_update(active && g_state.crosshair_custom);
            memory_xray_update(af_xray || (active && g_state.memory_xray),
                               af_xray ? kAfXrayDistance : g_state.xray_distance);
            memory_aspect_update(active && g_state.memory_aspect,
                                 g_state.aspect_value);
            farm_set_tree_marker_pin(af_xray);
        }

        float projection_width, projection_height;
        OverlayScreenSize(projection_width, projection_height);
        if (active) {
            esp_set_tree_scan(g_state.ore_tree ||
                              (g_state.autofarm_on && g_state.af_tree));
            esp_begin_overlay_frame((int)projection_width, (int)projection_height);
            DrawAimOverlay();
            UpdateAim(ImGui::GetIO().DeltaTime);
            DrawEspOverlay();
            DrawOreOverlay();
            DrawWorldOverlay();
            const float frame_dt = ImGui::GetIO().DeltaTime;
            FreecamBindTick(frame_dt);
            FreecamControls(frame_dt);
        }
        RenderMenu();
        drawEnd();
        g_frame_done.store(true);
    }
    while (!g_frame_done.load()) {}
    AuthPresenceStop();
    stop_attach_thread();
    Touch_SetGamePassthrough(true);
    memory_no_recoil_update(false);
    memory_no_spread_update(false);
    memory_hands_fov_update(false, 0.f);
    memory_black_sky_update(false);
    memory_always_day_update(false);
    memory_crosshair_update(false);
    memory_xray_update(false, 0.f);
    memory_aspect_update(false, 0.f);
    farm_set_tree_marker_pin(false);
    memory_freecam_update(false, nullptr, nullptr, nullptr);
    if (g_esp_attached.exchange(false)) {
        esp_reset();
    }
    Blur::Free();
    CfgWatchFree();
    AudioFree();
    shutdown(); Touch_Close(); return 0;
}
