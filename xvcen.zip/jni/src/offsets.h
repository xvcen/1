#pragma once
#include <cstdint>
#include "xvprotect.h"

namespace game_offsets {

inline const std::uint64_t NETWORK_CLIENT_TYPEINFO_RVA                      = XV_OFFSET(0xD8DAB08);
inline const std::uint64_t GAME_CONTROLLER_TYPEINFO_RVA                     = XV_OFFSET(0xD8D61E8);
inline const std::uint64_t MU_TYPEINFO_RVA                                  = XV_OFFSET(0xD8E11C0);
inline const std::uint64_t MANAGED_CACHED_PTR                               = XV_OFFSET(0x10);
inline const std::uint64_t IL2CPP_CLASS_PARENT                              = XV_OFFSET(0x58);
inline constexpr int           IL2CPP_MAX_CLASS_DEPTH            = 8;
inline const std::uint64_t IL2CPP_STRING_LENGTH                             = XV_OFFSET(0x10);
inline const std::uint64_t IL2CPP_STRING_CHARS                              = XV_OFFSET(0x14);
inline const std::uint64_t IL2CPP_LIST_ITEMS                                = XV_OFFSET(0x10);
inline const std::uint64_t IL2CPP_LIST_SIZE                                 = XV_OFFSET(0x18);
inline const std::uint64_t IL2CPP_ARRAY_LENGTH                              = XV_OFFSET(0x18);
inline const std::uint64_t IL2CPP_ARRAY_FIRST_ELEMENT                       = XV_OFFSET(0x20);

inline const std::uint64_t PLAYER_MANAGER_STATIC_FIELDS_LIST                = XV_OFFSET(0x10);
inline const std::uint64_t GAME_CONTROLLER_LOCAL_PLAYER_FIELD               = XV_OFFSET(0x10);
inline const std::uint64_t GAME_CONTROLLER_CAMERA_MANAGER_FIELD             = XV_OFFSET(0x38);
inline const std::uint64_t CAMERA_MANAGER_CAMERA_FIELD                      = XV_OFFSET(0x20);
inline const std::uint64_t NETWORK_CLIENT_SPAWNED_FIELD                     = XV_OFFSET(0x28);

inline const std::uint64_t DICTIONARY_ENTRIES                               = XV_OFFSET(0x18);
inline const std::uint64_t DICTIONARY_COUNT                                 = XV_OFFSET(0x20);
inline const std::uint64_t DICTIONARY_FREE_COUNT                            = XV_OFFSET(0x28);
inline const std::uint64_t NETWORK_IDENTITY_NET_ID                          = XV_OFFSET(0x58);
inline const std::uint64_t NETWORK_IDENTITY_DESTROY_CALLED                  = XV_OFFSET(0x6D);
inline const std::uint64_t NETWORK_IDENTITY_BEHAVIOURS                      = XV_OFFSET(0x80);
inline constexpr std::size_t NPC_IDENTITY_BLOCK_SIZE         = 0x30;
inline const std::uint64_t NETWORK_BEHAVIOUR_IDENTITY                       = XV_OFFSET(0x40);

inline const std::uint64_t PLAYER_TRANSFORM                                 = XV_OFFSET(0x68);
inline const std::uint64_t PLAYER_MOUSE_LOOK                                = XV_OFFSET(0x70);
inline const std::uint64_t PLAYER_EVENT_HANDLER                             = XV_OFFSET(0x78);
inline const std::uint64_t PLAYER_DEATH_HANDLER_REF                         = XV_OFFSET(0x80);
inline const std::uint64_t PLAYER_FP_MANAGER                                = XV_OFFSET(0x90);
inline const std::uint64_t PLAYER_KCC_REFERENCE                             = XV_OFFSET(0xB0);
inline const std::uint64_t PLAYER_VITALS                                    = XV_OFFSET(0xC8);
inline const std::uint64_t PLAYER_DEATH_RAGDOLL                             = XV_OFFSET(0xE0);
inline const std::uint64_t PLAYER_WEAPON_REF                                = XV_OFFSET(0xF0);
inline const std::uint64_t PLAYER_DEATH_FLAG                                = XV_OFFSET(0xF0);
inline const std::uint64_t PLAYER_ANIMATOR                                  = XV_OFFSET(0x190);
inline const std::uint64_t PLAYER_NICKLABEL                                 = XV_OFFSET(0x130);
inline const std::uint64_t PLAYER_TEAM_NAME                                 = XV_OFFSET(0x280);
inline const std::uint64_t PLAYER_DEATH_BACKPACK                            = XV_OFFSET(0x70);

inline const std::uint64_t PLAYER_WEAPON_PIECE                              = XV_OFFSET(0x110);

inline constexpr float PLAYER_HEIGHT                              = 1.8F;
inline constexpr float PLAYER_BOX_WIDTH_RATIO                     = 0.40F;
inline constexpr float MIN_PLAYER_DISTANCE                        = 0.0F;
inline constexpr float MAX_ESP_DISTANCE                           = 250.0F;
inline constexpr float MAX_PLAYER_ESP_DISTANCE                    = MAX_ESP_DISTANCE;
inline constexpr float MAX_AIM_DISTANCE                           = MAX_ESP_DISTANCE;
inline constexpr float MAX_ORE_ESP_DISTANCE                       = MAX_ESP_DISTANCE;
inline constexpr float MAX_TREE_ESP_DISTANCE                      = MAX_ESP_DISTANCE;
inline constexpr float MAX_TREE_FARM_DISTANCE                     = MAX_ESP_DISTANCE;

inline const std::uint64_t CAMERA_PROJECTION_MATRIX                         = XV_OFFSET(0xB0);
inline constexpr double CAMERA_STALE_GRACE_SECONDS                = 1.50;

inline const std::uint64_t MOUSE_LOOK_ZMM                                   = XV_OFFSET(0x4C);
inline const std::uint64_t MOUSE_LOOK_GYRO_SENS                             = XV_OFFSET(0x48);
inline const std::uint64_t MOUSE_LOOK_LIMITS                                = XV_OFFSET(0x38);

inline const std::uint64_t KCC_MOTOR                                        = XV_OFFSET(0x68);
inline const std::uint64_t MOTOR_INTERNAL_ROTATION                          = XV_OFFSET(0x15C);
inline const std::uint64_t KCC_PLAYER                                       = XV_OFFSET(0x78);
inline const std::uint64_t KCC_MOVE                                         = XV_OFFSET(0x16C);
inline const std::uint64_t MOVE_AIM                                         = XV_OFFSET(0x08);
inline const std::uint64_t WALLCLIP_COLLISION_MASK                          = XV_OFFSET(0x30);
inline const std::uint64_t WALLCLIP_SPHERE_RADIUS                           = XV_OFFSET(0x28);
inline const std::uint64_t WALLCLIP_MIN_DISTANCE                            = XV_OFFSET(0x2C);

inline const std::uint64_t OBSERVABLE_VALUE                                 = XV_OFFSET(0x20);
inline const std::uint64_t EVENT_AIM_ACTION                                 = XV_OFFSET(0x270);
inline const std::uint64_t EVENT_SLEEP                                      = XV_OFFSET(0x1D0);
inline const std::uint64_t EVENT_RECOIL_OBSERVABLE                          = XV_OFFSET(0x138);
inline const std::uint64_t UOA_ACTIVE                                       = XV_OFFSET(0x10);
inline const std::uint64_t ACTION_ACTIVE                                    = XV_OFFSET(0x10);

inline const std::uint64_t ENTITY_HEALTH_VALUE                              = XV_OFFSET(0x98);
inline const std::uint64_t REASONED_VALUE_CURRENT                           = XV_OFFSET(0x20);
inline const std::uint64_t REASONED_VALUE_PREVIOUS                          = XV_OFFSET(0x24);
inline const std::uint64_t GENERIC_VITALS_MAX_HEALTH                        = XV_OFFSET(0x88);
inline const std::uint64_t DEATH_HANDLER_ENTITY_TYPE                        = XV_OFFSET(0x14C);
inline const std::uint64_t DEATH_HANDLER_DEATH_FLAG                         = XV_OFFSET(0x150);

inline const std::uint64_t ENTITY_DISPLAY_NAME                              = XV_OFFSET(0x88);
inline const std::uint64_t NICKLABEL_PLAYER                                 = XV_OFFSET(0x20);
inline const std::uint64_t NICKLABEL_NAME                                   = XV_OFFSET(0xB0);
inline const std::uint64_t NICKLABEL_NAME_ALT1                              = XV_OFFSET(0xB8);
inline const std::uint64_t NICKLABEL_NAME_ALT2                              = XV_OFFSET(0xA8);
inline const std::uint64_t NICKLABEL_NICKNAME_TEXT                          = XV_OFFSET(0x38);
inline const std::uint64_t UI_TEXT_M_TEXT                                   = XV_OFFSET(0xE0);

inline const std::uint64_t RAGDOLL_PELVIS                                   = XV_OFFSET(0x20);
inline const std::uint64_t RAGDOLL_ANIMATOR                                 = XV_OFFSET(0x28);
inline const std::uint64_t RAGDOLL_BONES                                    = XV_OFFSET(0x88);

inline const std::uint64_t NATIVE_ANIMATOR_AVATAR                           = XV_OFFSET(0x1A8);
inline const std::uint64_t NATIVE_ANIMATOR_TRANSFORM_MAP                    = XV_OFFSET(0x1D0);
inline const std::uint64_t NATIVE_ANIMATOR_BONE_MAP_BUILT                   = XV_OFFSET(0x1E1);
inline const std::uint64_t NATIVE_ANIMATOR_FAST_BONE_FLAG                   = XV_OFFSET(0x5D5);
inline const std::uint64_t NATIVE_AVATAR_DATA                               = XV_OFFSET(0x28);
inline const std::uint64_t NATIVE_AVATAR_BONE_TABLE                         = XV_OFFSET(0x38);
inline const std::uint64_t NATIVE_AVATAR_DATA_COUNT                         = XV_OFFSET(0x30);
inline const std::uint64_t NATIVE_AVATAR_HUMAN_BONES                        = XV_OFFSET(0x50);
inline const std::uint64_t NATIVE_AVATAR_HUMAN_BONES_LEFT                   = XV_OFFSET(0x40);
inline const std::uint64_t NATIVE_AVATAR_HUMAN_BONES_RIGHT                  = XV_OFFSET(0x48);
inline const std::uint64_t NATIVE_TRANSFORM_MAP_ARRAY                       = XV_OFFSET(0x08);
inline const std::uint64_t NATIVE_TRANSFORM_MAP_COUNT                       = XV_OFFSET(0x18);
inline const std::uint64_t NATIVE_TRANSFORM_MAP_ENTRIES                     = XV_OFFSET(0x20);
inline constexpr std::uint64_t NATIVE_TRANSFORM_MAP_MAX_ENTRIES   = 8192;
inline const std::uint64_t NATIVE_TRANSFORM_MAP_ENTRY_SIZE                  = XV_OFFSET(0x10);
inline const std::uint64_t NATIVE_TRANSFORM_MAP_ENTRY_KEY                   = XV_OFFSET(0x08);

inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_DATA                  = XV_OFFSET(0x28);
inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_INDEX                 = XV_OFFSET(0x30);
inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_CAPACITY              = XV_OFFSET(0x10);
inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_MATRICES              = XV_OFFSET(0x18);
inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_INDICES               = XV_OFFSET(0x20);
inline const std::uint64_t NATIVE_TRANSFORM_HIERARCHY_COUNT_PTR             = XV_OFFSET(0x28);
inline const std::uint64_t NATIVE_COMPONENT_GAMEOBJECT                      = XV_OFFSET(0x20);
inline const std::uint64_t NATIVE_GAMEOBJECT_COMPONENTS                     = XV_OFFSET(0x20);
inline const std::uint64_t NATIVE_GAMEOBJECT_TRANSFORM_SLOT                 = XV_OFFSET(0x08);
inline const std::uint64_t INTERFACE_REFERENCE_COMPONENT                    = XV_OFFSET(0x10);
inline const std::uint64_t INTERFACE_REFERENCE_VALUE                        = XV_OFFSET(0x18);
inline const std::uint64_t UOH_ENTITY                                       = XV_OFFSET(0x68);
inline const std::uint64_t UOH_BOUNDS_CENTER                                = XV_OFFSET(0x70);
inline const std::uint64_t UOH_BOUNDS_EXTENTS                               = XV_OFFSET(0x7C);

inline constexpr std::int32_t HUMAN_BONE_HIPS            = 0;
inline constexpr std::int32_t HUMAN_BONE_LEFT_UPPER_LEG  = 1;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_UPPER_LEG = 2;
inline constexpr std::int32_t HUMAN_BONE_LEFT_LOWER_LEG  = 3;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_LOWER_LEG = 4;
inline constexpr std::int32_t HUMAN_BONE_LEFT_FOOT       = 5;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_FOOT      = 6;
inline constexpr std::int32_t HUMAN_BONE_SPINE           = 7;
inline constexpr std::int32_t HUMAN_BONE_CHEST           = 8;
inline constexpr std::int32_t HUMAN_BONE_UPPER_CHEST     = 9;
inline constexpr std::int32_t HUMAN_BONE_NECK            = 10;
inline constexpr std::int32_t HUMAN_BONE_HEAD            = 11;
inline constexpr std::int32_t HUMAN_BONE_LEFT_SHOULDER   = 12;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_SHOULDER  = 13;
inline constexpr std::int32_t HUMAN_BONE_LEFT_UPPER_ARM  = 14;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_UPPER_ARM = 15;
inline constexpr std::int32_t HUMAN_BONE_LEFT_LOWER_ARM  = 16;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_LOWER_ARM = 17;
inline constexpr std::int32_t HUMAN_BONE_LEFT_HAND       = 18;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_HAND      = 19;
inline constexpr std::int32_t HUMAN_BONE_LEFT_TOES       = 20;
inline constexpr std::int32_t HUMAN_BONE_RIGHT_TOES      = 21;

inline const std::uint64_t FP_MANAGER_CURRENT_WEAPON                        = XV_OFFSET(0x58);
inline const std::uint64_t DTL_TYPEINFO_RVA                                 = XV_OFFSET(0xD8D6400);
inline const std::uint64_t DTL_STATIC_INSTANCE                              = XV_OFFSET(0x0);
inline const std::uint64_t DTL_FOV_HAS_VALUE                                = XV_OFFSET(0x20);
inline const std::uint64_t FP_HITSCAN_CONFIG                                = XV_OFFSET(0x128);
inline const std::uint64_t HITSCAN_CONFIG_DISPERSION                        = XV_OFFSET(0x60);
inline const std::uint64_t HITSCAN_CONFIG_RECOIL                            = XV_OFFSET(0x68);
inline const std::uint64_t RECOIL_AMPLITUDE_BLOCK                           = XV_OFFSET(0x18);
inline const std::uint64_t DISPERSION_BLOCK                                 = XV_OFFSET(0x18);

inline const std::uint64_t SP_TYPEINFO_RVA                                  = XV_OFFSET(0xD8DF4C8);
inline const std::uint64_t SP_FIELD_CYCLE                                   = XV_OFFSET(0x40);
inline const std::uint64_t SP_FIELD_ATMOSPHERE                              = XV_OFFSET(0x50);
inline const std::uint64_t SP_FIELD_CLOUDS                                  = XV_OFFSET(0x80);
inline const std::uint64_t SP_FIELD_STARS                                   = XV_OFFSET(0x78);
inline const std::uint64_t SP_PARAM_FIELDS_START                            = XV_OFFSET(0x10);
inline const std::uint64_t SP_CYCLE_HOUR                                    = XV_OFFSET(0x10);
inline const std::uint64_t GAME_CONTROLLER_STATIC_INSTANCE_FIELD           = XV_OFFSET(0x60);
inline const std::uint64_t GAME_CONTROLLER_CROSSHAIR_MANAGER_FIELD         = XV_OFFSET(0x148);
inline const std::uint64_t CROSSHAIR_MANAGER_DEFAULT_FIELD                 = XV_OFFSET(0x48);
inline const std::uint64_t CROSSHAIR_MANAGER_ACTIVE_FIELD                  = XV_OFFSET(0x80);
inline const std::uint64_t CROSSHAIR_DATA_COLOR_BLOCK                      = XV_OFFSET(0x1C);

inline const std::uint64_t MINEABLE_CURRENT_HEALTH                          = XV_OFFSET(0x78);
inline const std::uint64_t MINEABLE_MAX_HEALTH                              = XV_OFFSET(0xC0);
inline const std::uint64_t MINEABLE_FRACTION_REMAINING                      = XV_OFFSET(0xD0);
inline const std::uint64_t MINEABLE_ENTITY_TYPE                             = XV_OFFSET(0xD8);
inline const std::uint64_t MINEABLE_LOOT                                    = XV_OFFSET(0xA0);
inline const std::uint64_t LOOT_ITEM_NAME                                   = XV_OFFSET(0x10);
inline const std::uint64_t MINEABLE_EXTENSIONS                              = XV_OFFSET(0xE8);
inline const std::uint64_t ORE_HITSTREAK_MARKER_PREFAB                      = XV_OFFSET(0x28);
inline const std::uint64_t ORE_HITSTREAK_MARKER_ACTIVE                      = XV_OFFSET(0x30);
inline const std::uint64_t HITMARKER_ITEM_MARK_TRANSFORM                    = XV_OFFSET(0x38);
inline const std::uint64_t TREE_HITSTREAK_MOVING_METHOD                     = XV_OFFSET(0x20);
inline const std::uint64_t TREE_HITSTREAK_RANDOM_AMPLITUDE                  = XV_OFFSET(0x30);
inline const std::uint64_t TREE_HITSTREAK_RANDOM_MIN_DEGREES                = XV_OFFSET(0x38);
inline const std::uint64_t TREE_HITSTREAK_AXIS_POINTS                       = XV_OFFSET(0x40);
inline const std::uint64_t TREE_HITSTREAK_AXIS_INDEX                        = XV_OFFSET(0x48);
inline const std::uint64_t TREE_HITSTREAK_MARKER_ACTIVE                     = XV_OFFSET(0x50);
inline const std::uint64_t TREE_HITSTREAK_AXIS_A                            = XV_OFFSET(0x58);
inline const std::uint64_t TREE_HITSTREAK_AXIS_C                            = XV_OFFSET(0x70);
inline const std::uint64_t TREE_HITSTREAK_HIT_POINT                         = XV_OFFSET(0x88);

inline constexpr float         FARM_TRUNK_RADIUS_MAX             = 1.20F;
inline constexpr std::int32_t  TREE_MOVING_METHOD_RANDOM         = 1;
inline constexpr float         FARM_TREE_AIM_HEIGHT              = 1.85F;
inline constexpr float         FARM_TREE_MARKER_MIN_DY           = 0.60F;
inline constexpr float         FARM_TREE_MARKER_MAX_DY           = 6.00F;
inline constexpr float         MIN_FARMABLE_TREE_HEALTH          = 45.0F;
inline constexpr float         MAX_FARM_TREE_DROP                = 6.50F;
inline constexpr std::int32_t  ENTITY_TYPE_BEAR                  = 1;
inline constexpr std::int32_t  ENTITY_TYPE_BOAR                  = 2;
inline constexpr std::int32_t  ENTITY_TYPE_DEER                  = 3;
inline constexpr std::int32_t  ENTITY_TYPE_RABBIT                = 4;
inline constexpr std::int32_t  ENTITY_TYPE_CHICKEN               = 5;
inline constexpr std::int32_t  ENTITY_TYPE_FISH                  = 6;
inline constexpr std::int32_t  ENTITY_TYPE_CANNIBAL              = 7;
inline constexpr std::int32_t  ENTITY_TYPE_TREE                  = 8;
inline constexpr std::int32_t  ENTITY_TYPE_STONE                 = 9;
inline constexpr std::int32_t  ENTITY_TYPE_IRON                  = 10;
inline constexpr std::int32_t  ENTITY_TYPE_SULFUR                = 11;
inline constexpr std::int32_t  ENTITY_TYPE_BARREL                = 13;
inline constexpr std::int32_t  ENTITY_TYPE_LOOTBOX               = 14;
inline constexpr std::int32_t  ENTITY_TYPE_HUMAN                 = 19;
inline constexpr std::int32_t  ENTITY_TYPE_HARE                  = 22;

inline constexpr const char*   NPC_CLASS_BOT_BRAIN               = "NPCBrainCombat";
inline constexpr const char*   NPC_CLASS_CANNIBAL_BRAIN          = "NPCBrainHumanoid";
inline constexpr const char*   NPC_CLASS_HUMANOID_DEATH          = "NPCHumanoidDeathHandler";
inline constexpr const char*   NPC_CLASS_ANIMAL_BRAIN            = "NPCBrainAnimal";
inline constexpr const char*   NPC_CLASS_RANDOM_SPAWN_LOOT       = "MineableObjectWithRandomSpawn";
inline constexpr const char*   NPC_CLASS_LOOT_OBJECT             = "LootObject";
inline constexpr const char*   NPC_CLASS_FISH                    = "Fish";
inline constexpr const char*   NPC_CLASS_CUPBOARD                = "Cupboard";
inline constexpr const char*   NPC_CLASS_TURRET                  = "AutoTurretBase";
inline constexpr const char*   NPC_CLASS_GUN_TRAP                = "GunTrap";
inline constexpr const char*   NPC_CLASS_SAM_TURRET              = "AutoSamTurret";
inline constexpr const char*   EXT_CLASS_ORE_HITSTREAKS          = "MineableObjectExtension_OreHitstreaks";
inline constexpr const char*   EXT_CLASS_ORE_MARKER              = "MineableObjectExtension_OreHitstreaksMarker";
inline constexpr const char*   EXT_CLASS_HIT_MARKERS             = "MineableObjectExtension_HitMarkers";
inline constexpr const char*   EXT_CLASS_TREE_HITSTREAKS         = "MineableObjectExtension_TreeHitstreaks";
inline constexpr const char*   EXT_CLASS_HIT_MARKER_ITEM         = "MineableObjectExtension_HitMarkerItem";

inline const std::uint64_t FISH_DEATH_HANDLER                              = XV_OFFSET(0x78);
inline const std::uint64_t NPC_HUMANOID_DEATH_FLAG                          = XV_OFFSET(0xE8);
inline const std::uint64_t NPC_BOT_MODEL_INFO                               = XV_OFFSET(0xA0);
inline const std::uint64_t NPC_CANNIBAL_MODEL_INFO                          = XV_OFFSET(0x158);
inline const std::uint64_t NPC_MODEL_HEAD_TRANSFORM                         = XV_OFFSET(0x20);

inline const std::uint64_t LOOT_OBJECT_BUILDING_PIECE                       = XV_OFFSET(0xF8);
inline const std::uint64_t LOOT_OBJECT_PANEL_NAME                           = XV_OFFSET(0xE0);
inline const std::uint64_t LOOT_OBJECT_IS_LOOTABLE                          = XV_OFFSET(0xA8);
inline const std::uint64_t LOOT_ON_DEATH_CONTAINER                          = XV_OFFSET(0x88);


inline const std::uint64_t UGG_OUTLINE_RENDERERS                            = XV_OFFSET(0x88);
inline const std::uint64_t RENDERER_WORLD_BOUNDS                            = XV_OFFSET(0xB0);

inline constexpr double WORLD_SCAN_FRAME_BUDGET_SECONDS          = 0.0025;
inline constexpr double WORLD_SCAN_DICTIONARY_INTERVAL           = 0.35;
inline constexpr double WORLD_SCAN_PRUNE_INTERVAL                = 0.25;
inline constexpr double WORLD_SCAN_MIN_ENTRY_TTL_SECONDS         = 2.00;
inline constexpr double WORLD_SCAN_MAX_ENTRY_TTL_SECONDS         = 6.00;


}
