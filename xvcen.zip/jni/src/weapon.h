#pragma once

#include "xvseal.h"
#include "xvstrings.h"
#include <string>
#include <utility>


namespace weapon_detail {

struct WeaponEntry {
    const char* id;
    const char* en;
    const char* ru;
};

inline std::string normalize_id(const std::string& raw) {
    std::string out;
    out.reserve(raw.size());
    for (char c : raw) {
        if (c >= 'A' && c <= 'Z') out.push_back((char)(c + 32));
        else if (c == '_' || c == '-' || c == ' ' || c == '/') out.push_back('.');
        else out.push_back(c);
    }
    return out;
}

inline std::pair<std::string, std::string> lookup(const std::string& id) {
    static const WeaponEntry table[] = {
        {xv::StrStable(xv::sid::kWpnWoodenSpearId), xv::StrStable(xv::sid::kWpnWoodenSpearEn), xv::StrStable(xv::sid::kWpnWoodenSpearRu)},
        {xv::StrStable(xv::sid::kWpnIronSpearId), xv::StrStable(xv::sid::kWpnIronSpearEn), xv::StrStable(xv::sid::kWpnIronSpearRu)},
        {xv::StrStable(xv::sid::kWpnIceSpearId), xv::StrStable(xv::sid::kWpnIceSpearEn), xv::StrStable(xv::sid::kWpnIceSpearRu)},
        {xv::StrStable(xv::sid::kWpnBoneClubId), xv::StrStable(xv::sid::kWpnBoneClubEn), xv::StrStable(xv::sid::kWpnBoneClubRu)},
        {xv::StrStable(xv::sid::kWpnMacheteId), xv::StrStable(xv::sid::kWpnMacheteEn), xv::StrStable(xv::sid::kWpnMacheteRu)},
        {xv::StrStable(xv::sid::kWpnMaceId), xv::StrStable(xv::sid::kWpnMaceEn), xv::StrStable(xv::sid::kWpnMaceRu)},
        {xv::StrStable(xv::sid::kWpnWoodenSpikedClubId), xv::StrStable(xv::sid::kWpnWoodenSpikedClubEn), xv::StrStable(xv::sid::kWpnWoodenSpikedClubRu)},
        {xv::StrStable(xv::sid::kWpnWoodenBowId), xv::StrStable(xv::sid::kWpnWoodenBowEn), xv::StrStable(xv::sid::kWpnWoodenBowRu)},
        {xv::StrStable(xv::sid::kWpnCrossbowId), xv::StrStable(xv::sid::kWpnCrossbowEn), xv::StrStable(xv::sid::kWpnCrossbowRu)},
        {xv::StrStable(xv::sid::kWpnHandmadePistolId), xv::StrStable(xv::sid::kWpnHandmadePistolEn), xv::StrStable(xv::sid::kWpnHandmadePistolRu)},
        {xv::StrStable(xv::sid::kWpnSteelBallGunId), xv::StrStable(xv::sid::kWpnSteelBallGunEn), xv::StrStable(xv::sid::kWpnSteelBallGunRu)},
        {xv::StrStable(xv::sid::kWpnFlareGunId), xv::StrStable(xv::sid::kWpnFlareGunEn), xv::StrStable(xv::sid::kWpnFlareGunRu)},
        {xv::StrStable(xv::sid::kWpnRevolverId), xv::StrStable(xv::sid::kWpnRevolverEn), xv::StrStable(xv::sid::kWpnRevolverRu)},
        {xv::StrStable(xv::sid::kWpnDesertEagleId), xv::StrStable(xv::sid::kWpnDesertEagleEn), xv::StrStable(xv::sid::kWpnDesertEagleEn)},
        {xv::StrStable(xv::sid::kWpnSubmachineGunId), xv::StrStable(xv::sid::kWpnSubmachineGunEn), xv::StrStable(xv::sid::kWpnSubmachineGunRu)},
        {xv::StrStable(xv::sid::kWpnThompsonId), xv::StrStable(xv::sid::kWpnThompsonEn), xv::StrStable(xv::sid::kWpnThompsonRu)},
        {xv::StrStable(xv::sid::kWpnWinchesterId), xv::StrStable(xv::sid::kWpnWinchesterEn), xv::StrStable(xv::sid::kWpnWinchesterEn)},
        {xv::StrStable(xv::sid::kWpnDoubleBarrelId), xv::StrStable(xv::sid::kWpnDoubleBarrelEn), xv::StrStable(xv::sid::kWpnDoubleBarrelRu)},
        {xv::StrStable(xv::sid::kWpnShotgunId), xv::StrStable(xv::sid::kWpnShotgunEn), xv::StrStable(xv::sid::kWpnShotgunRu)},
        {xv::StrStable(xv::sid::kWpnHuntingRifleId), xv::StrStable(xv::sid::kWpnHuntingRifleEn), xv::StrStable(xv::sid::kWpnHuntingRifleRu)},
        {xv::StrStable(xv::sid::kWpnFnFalId), xv::StrStable(xv::sid::kWpnFnFalEn), xv::StrStable(xv::sid::kWpnFnFalRu)},
        {xv::StrStable(xv::sid::kWpnAssaultRifleId), xv::StrStable(xv::sid::kWpnAssaultRifleEn), xv::StrStable(xv::sid::kWpnAssaultRifleRu)},
        {xv::StrStable(xv::sid::kWpnDmrId), xv::StrStable(xv::sid::kWpnDmrEn), xv::StrStable(xv::sid::kWpnDmrEn)},
        {xv::StrStable(xv::sid::kWpnDvlId), xv::StrStable(xv::sid::kWpnDvlEn), xv::StrStable(xv::sid::kWpnDvlEn)},
        {xv::StrStable(xv::sid::kWpnKrissVectorId), xv::StrStable(xv::sid::kWpnKrissVectorEn), xv::StrStable(xv::sid::kWpnKrissVectorRu)},
        {xv::StrStable(xv::sid::kWpnRocketLauncherId), xv::StrStable(xv::sid::kWpnRocketLauncherEn), xv::StrStable(xv::sid::kWpnRocketLauncherRu)},
        {xv::StrStable(xv::sid::kWpnExplosiveChargeId), xv::StrStable(xv::sid::kWpnExplosiveChargeEn), xv::StrStable(xv::sid::kWpnExplosiveChargeRu)},
        {xv::StrStable(xv::sid::kWpnGrenadeMilitaryId), xv::StrStable(xv::sid::kWpnGrenadeMilitaryEn), xv::StrStable(xv::sid::kWpnGrenadeMilitaryRu)},
        {xv::StrStable(xv::sid::kWpnEventGrenadeMakeshiftId), xv::StrStable(xv::sid::kWpnEventGrenadeMakeshiftEn), xv::StrStable(xv::sid::kWpnEventGrenadeMakeshiftRu)},
        {xv::StrStable(xv::sid::kWpnPickaxehammerId), xv::StrStable(xv::sid::kWpnPickaxehammerEn), xv::StrStable(xv::sid::kWpnPickaxehammerRu)},
    };
    for (const WeaponEntry& entry : table) {
        if (id == entry.id) return {entry.en, entry.ru};
    }
    return {};
}

}

inline std::pair<std::string, std::string> format_weapon_name(const std::string& raw_id) {
    if (raw_id.empty()) return {"", ""};
    return weapon_detail::lookup(weapon_detail::normalize_id(raw_id));
}
