import json
import os
import re
import struct
import sys
from pathlib import Path

OFFSET_LINE = re.compile(
    r"^(?P<indent>\s*)inline const std::uint64_t\s+(?P<name>\w+)\s*=\s*"
    r"(?:XV_OFFSET\()?\s*(?P<value>0[xX][0-9a-fA-F]+|\d+)\s*\)?\s*;\s*$"
)

STR_LINE = re.compile(
    r"^(?P<indent>\s*)inline (?:constexpr\s+)?const char\*\s+(?P<name>\w+)\s*=\s*"
    r"(?:XV_CSTR\()?\s*\"(?P<value>(?:[^\"\\]|\\.)*)\"\s*\)?\s*;\s*$"
)


def unescape(value):
    out = bytearray()
    index = 0
    while index < len(value):
        char = value[index]
        if char != "\\" or index + 1 >= len(value):
            out.extend(char.encode("utf-8"))
            index += 1
            continue
        escape = value[index + 1]
        if escape == "x" and index + 3 < len(value) + 1:
            out.append(int(value[index + 2 : index + 4], 16))
            index += 4
            continue
        mapping = {"n": 10, "r": 13, "t": 9, "\\": 92, '"': 34, "'": 39, "0": 0, "a": 7, "b": 8, "f": 12, "v": 11}
        if escape not in mapping:
            raise SystemExit("unsupported escape in table value: %r" % value)
        out.append(mapping[escape])
        index += 2
    return bytes(out)


def load_table(path):
    entries = []
    if not path.exists():
        return entries
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if "\t" not in line:
            raise SystemExit("bad table line in %s: %r" % (path, raw))
        name, value = line.split("\t", 1)
        entries.append((name.strip(), value))
    return entries


def resolve_secret(value):
    import secrets as secret_source

    value = value.strip()
    random_match = re.fullmatch(r"@random(\d+)", value)
    if random_match:
        return secret_source.token_bytes(int(random_match.group(1)))
    as_text = value.startswith("text:")
    if as_text:
        value = value[len("text:"):].strip()
    match = re.fullmatch(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", value)
    if match:
        name = match.group(1)
        if name not in os.environ or not os.environ[name].strip():
            raise SystemExit("missing environment value for %s" % name)
        value = os.environ[name].strip()
    if as_text:
        data = value.encode("utf-8")
        if not data or len(data) > 64:
            raise SystemExit("text secret must be 1..64 bytes")
        return data
    return bytes.fromhex(value.replace("0x", "").replace(":", "").replace(" ", ""))


def transform_offsets(source, generated, values, names, extra, extra_names, string_base):
    out = []
    for raw in source.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip("\n")
        if "xvprotect.h" in line:
            out.append(line.replace('#include "xvprotect.h"', '#include "xvseal.h"'))
            continue
        match = STR_LINE.match(line)
        if match:
            text = unescape(match.group("value")).decode("utf-8")
            if text not in extra:
                extra[text] = len(extra_names)
                extra_names.append((match.group("name"), text))
            out.append(
                "%sinline const char* const %s = ::xv::StrStable(%du);"
                % (match.group("indent"), match.group("name"), string_base + extra[text])
            )
            continue
        match = OFFSET_LINE.match(line)
        if not match:
            if "XV_OFFSET" in line or "XV_STR" in line or "XV_CSTR" in line:
                raise SystemExit("unsupported protected literal in %s: %r" % (source, raw))
            out.append(line)
            continue
        index = len(values)
        values.append(int(match.group("value"), 0))
        names.append(match.group("name"))
        out.append(
            "%sinline const std::uint64_t %s = ::xv::Offset(%du);"
            % (match.group("indent"), match.group("name"), index)
        )
    generated.parent.mkdir(parents=True, exist_ok=True)
    generated.write_text("\n".join(out) + "\n", encoding="utf-8")
    return len(values)


def build_values(values):
    blob = struct.pack("<I", len(values))
    for value in values:
        blob += struct.pack("<Q", value & 0xFFFFFFFFFFFFFFFF)
    return blob


def build_blobs(entries):
    blob = struct.pack("<I", len(entries))
    data = bytearray()
    for _, payload in entries:
        offset = len(data)
        blob += struct.pack("<II", offset, len(payload))
        data.extend(payload)
        while len(data) % 64 != 0:
            data.append(0)
    return blob + bytes(data)


def enum_header(namespace, names):
    lines = ["#pragma once", "", "namespace xv {", "namespace %s {" % namespace, "", "enum : unsigned int {"]
    for index, name in enumerate(names):
        lines.append("    k%s = %du," % (name, index))
    lines.append("};")
    lines.append("")
    lines.append("}")
    lines.append("}")
    lines.append("")
    return "\n".join(lines)


def main():
    jni = Path(sys.argv[1]).resolve()
    tables = jni / "tools" / "gen"
    generated = jni / "gen"
    payload = generated / "payload"
    payload.mkdir(parents=True, exist_ok=True)

    strings = [(name, unescape(value)) for name, value in load_table(tables / "strings.txt")]
    if not strings:
        raise SystemExit("empty string table")
    taken = set(name for name, _ in strings)

    values = []
    names = []
    extra = {}
    extra_names = []
    for source_name in ("offsets.h", "offsets_beta.h"):
        source = jni / "src" / source_name
        if not source.exists():
            raise SystemExit("missing %s" % source)
        transform_offsets(source, generated / source_name, values, names, extra, extra_names, len(strings))
    for constant, text in extra_names:
        label = "Off" + constant
        if label in taken:
            raise SystemExit("string name collision: %s" % label)
        taken.add(label)
        strings.append((label, bytearray(text.encode("utf-8"))))
    keys = [(name, resolve_secret(value)) for name, value in load_table(tables / "keys.txt")]
    if not keys:
        raise SystemExit("empty key table")
    policy = []
    for name, value in load_table(tables / "policy.txt"):
        text = value.strip()
        policy.append((name, int(text, 0)))
    if not policy:
        raise SystemExit("empty policy table")

    (payload / "region0.bin").write_bytes(build_values(values))
    (payload / "region1.bin").write_bytes(build_blobs(strings))
    (payload / "region2.bin").write_bytes(build_blobs(keys))
    (payload / "region3.bin").write_bytes(build_values([value for _, value in policy]))

    (generated / "xvstrings.h").write_text(enum_header("sid", [name for name, _ in strings]), encoding="utf-8")
    (generated / "xvkeys.h").write_text(enum_header("kid", [name for name, _ in keys]), encoding="utf-8")
    (generated / "xvpolicy.h").write_text(enum_header("pid", [name for name, _ in policy]), encoding="utf-8")

    literal_map = {}
    for name, data in strings:
        literal_map.setdefault(data.decode("utf-8"), "k%s" % name)

    manifest = {
        "offsets": {"count": len(values), "names": names},
        "strings": [{"name": name, "value": data.decode("utf-8"), "id": index} for index, (name, data) in enumerate(strings)],
        "keys": [{"name": name, "len": len(data), "id": index} for index, (name, data) in enumerate(keys)],
        "policy": [{"name": name, "value": value, "id": index} for index, (name, value) in enumerate(policy)],
        "literal_map": literal_map,
    }
    (payload / "manifest.json").write_text(json.dumps(manifest, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print(
        "payload: offsets=%d strings=%d keys=%d policy=%d"
        % (len(values), len(strings), len(keys), len(policy))
    )


if __name__ == "__main__":
    main()
