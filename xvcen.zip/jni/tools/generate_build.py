import json
import secrets
import sys
from pathlib import Path


def master_from(seed_a, seed_b, seed_c, mix):
    out = bytearray(32)
    for i in range(32):
        part = (mix >> ((i & 7) * 8)) & 0xFF
        out[i] = (
            seed_a[i & 15]
            ^ seed_b[(i * 5 + 3) & 15]
            ^ seed_c[(i * 7 + 11) & 15]
            ^ part
            ^ ((i * 0x9E + 0x3B) & 0xFF)
        )
    return bytes(out)


def c_array(data):
    return "{ " + ", ".join("0x%02x" % value for value in data) + " }"


def main():
    header = Path(sys.argv[1])
    if len(sys.argv) > 2:
        secret = Path(sys.argv[2])
    else:
        secret = header.parent.parent.parent / "gen" / "build_secret.json"

    seed_a = secrets.token_bytes(16)
    seed_b = secrets.token_bytes(16)
    seed_c = secrets.token_bytes(16)
    mix = secrets.randbits(64)
    build_id = secrets.randbits(31) | 1
    magic = secrets.token_bytes(32)
    master = master_from(seed_a, seed_b, seed_c, mix)

    lines = [
        "#pragma once",
        "",
        "#define XV_BUILD_ID 0x%08xu" % build_id,
        "#define XV_SEED_MIX 0x%016xULL" % mix,
        "#define XV_SEAL_MAGIC_INIT %s" % c_array(magic),
        "#define XV_SEED_A_INIT %s" % c_array(seed_a),
        "#define XV_SEED_B_INIT %s" % c_array(seed_b),
        "#define XV_SEED_C_INIT %s" % c_array(seed_c),
        "",
    ]

    header.parent.mkdir(parents=True, exist_ok=True)
    header.write_text("\n".join(lines))

    secret.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "build_id": build_id,
        "master": master.hex(),
        "magic": magic.hex(),
    }
    secret.write_text(json.dumps(payload, indent=1) + "\n")


if __name__ == "__main__":
    main()
