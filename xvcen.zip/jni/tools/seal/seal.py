import hashlib
import hmac
import json
import os
import re
import struct
import sys
from pathlib import Path

PT_LOAD = 1
PF_X = 1
PF_W = 2

MASK32 = 0xFFFFFFFF
MASK128 = (1 << 128) - 1
POLY_PRIME = (1 << 130) - 5
POLY_CLAMP = 0x0FFFFFFC0FFFFFFC0FFFFFFC0FFFFFFF
AEAD_TAG_BYTES = 16
AEAD_NONCE_BYTES = 24
KDF_KEY_BYTES = 32


def parse_elf(data):
    if data[:4] != b"\x7fELF":
        raise SystemExit("not an elf file")
    if data[4] != 2:
        raise SystemExit("only elf64 is supported")
    if data[5] != 1:
        raise SystemExit("only little endian is supported")
    e_phoff = struct.unpack_from("<Q", data, 0x20)[0]
    e_phentsize = struct.unpack_from("<H", data, 0x36)[0]
    e_phnum = struct.unpack_from("<H", data, 0x38)[0]
    segments = []
    for index in range(e_phnum):
        off = e_phoff + index * e_phentsize
        p_type, p_flags = struct.unpack_from("<II", data, off)
        p_offset, p_vaddr, _, p_filesz, p_memsz = struct.unpack_from("<QQQQQ", data, off + 8)
        segments.append(
            {
                "type": p_type,
                "flags": p_flags,
                "offset": p_offset,
                "vaddr": p_vaddr,
                "filesz": p_filesz,
                "memsz": p_memsz,
            }
        )
    return segments


def pick_rx(segments):
    for seg in segments:
        if seg["type"] == PT_LOAD and (seg["flags"] & PF_X) and not (seg["flags"] & PF_W):
            return seg
    raise SystemExit("no executable load segment found")


def header_constants(path):
    text = path.read_text()
    values = {}
    for name, value in re.findall(r"#define\s+(XV_SEAL_[A-Z_0-9]+)\s+(0[xX][0-9a-fA-F]+|\d+)u?", text):
        values[name] = int(value, 0)
    required = (
        "XV_SEAL_MAGIC",
        "XV_SEAL_VERSION",
        "XV_SEAL_SLOT_SIZE",
        "XV_SEAL_REGIONS",
        "XV_SEAL_WINDOWS",
        "XV_SEAL_WINDOW_BYTES",
        "XV_SEAL_REGION_TABLE_OFF",
        "XV_SEAL_WINDOW_TABLE_OFF",
        "XV_SEAL_DATA_OFF",
        "XV_SEAL_REGION_ENTRY_BYTES",
        "XV_SEAL_WINDOW_ENTRY_BYTES",
        "XV_SEAL_WINDOW_ITEM_BYTES",
        "XV_SEAL_WINDOW_CT_BYTES",
    )
    missing = [name for name in required if name not in values or values[name] == 0]
    if missing:
        raise SystemExit("missing constants: %s" % ", ".join(missing))
    return values


def align_down(value, align):
    return value - (value % align)


def region_ranges(rx_len, count):
    ranges = []
    for index in range(count):
        start = align_down((rx_len * index) // count, 64)
        stop = align_down((rx_len * (index + 1)) // count, 64)
        if stop <= start:
            stop = min(rx_len, start + 64)
        if start >= rx_len:
            start = align_down(max(rx_len - 64, 0), 64)
            stop = rx_len
        ranges.append((start, stop - start))
    return ranges


def window_ranges(rx_len, count, window_bytes):
    ranges = []
    for index in range(count):
        start = align_down((rx_len * index) // count, 64)
        length = min(window_bytes, rx_len - start)
        if length <= 0:
            start = align_down(max(rx_len - window_bytes, 0), 64)
            length = min(window_bytes, rx_len - start)
        if length <= 0:
            raise SystemExit("executable segment is too small to seal")
        ranges.append((start, length))
    return ranges


def find_slot(data, magic, slot_size, rx):
    hits = []
    start = 0
    while True:
        index = data.find(magic, start)
        if index < 0:
            break
        hits.append(index)
        start = index + 1
    if len(hits) != 1:
        raise SystemExit("expected exactly one seal slot marker, found %d" % len(hits))
    slot_off = hits[0]
    if slot_off + slot_size > len(data):
        raise SystemExit("seal slot does not fit in the file")
    if rx["offset"] <= slot_off < rx["offset"] + rx["filesz"]:
        raise SystemExit("seal slot must not live in the executable segment")
    tail = data[slot_off + len(magic) : slot_off + slot_size]
    if tail.count(0) != len(tail):
        raise SystemExit("seal slot is not empty")
    return slot_off


def rotl32(value, bits):
    return ((value << bits) | (value >> (32 - bits))) & MASK32


def quarter_round(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & MASK32
    x[d] = rotl32(x[d] ^ x[a], 16)
    x[c] = (x[c] + x[d]) & MASK32
    x[b] = rotl32(x[b] ^ x[c], 12)
    x[a] = (x[a] + x[b]) & MASK32
    x[d] = rotl32(x[d] ^ x[a], 8)
    x[c] = (x[c] + x[d]) & MASK32
    x[b] = rotl32(x[b] ^ x[c], 7)


def double_round(x):
    quarter_round(x, 0, 4, 8, 12)
    quarter_round(x, 1, 5, 9, 13)
    quarter_round(x, 2, 6, 10, 14)
    quarter_round(x, 3, 7, 11, 15)
    quarter_round(x, 0, 5, 10, 15)
    quarter_round(x, 1, 6, 11, 12)
    quarter_round(x, 2, 7, 8, 13)
    quarter_round(x, 3, 4, 9, 14)


def hchacha20(key, input16):
    state = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    state.extend(struct.unpack("<8I", key))
    state.extend(struct.unpack("<4I", input16))
    for _ in range(10):
        double_round(state)
    return struct.pack("<4I", *state[0:4]) + struct.pack("<4I", *state[12:16])


def chacha_block(key, nonce12, counter):
    state = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    state.extend(struct.unpack("<8I", key))
    state.append(counter & MASK32)
    state.extend(struct.unpack("<3I", nonce12))
    working = list(state)
    for _ in range(10):
        double_round(working)
    return struct.pack("<16I", *[((working[i] + state[i]) & MASK32) for i in range(16)])


def chacha_xor(key, nonce12, counter, data):
    out = bytearray(data)
    offset = 0
    while offset < len(out):
        stream = chacha_block(key, nonce12, counter)
        stop = min(offset + 64, len(out))
        for index in range(offset, stop):
            out[index] ^= stream[index - offset]
        offset = stop
        counter = (counter + 1) & MASK32
    return bytes(out)


def poly1305(message, key):
    r = int.from_bytes(key[0:16], "little") & POLY_CLAMP
    s = int.from_bytes(key[16:32], "little")
    acc = 0
    for offset in range(0, len(message), 16):
        block = message[offset : offset + 16]
        acc = ((acc + int.from_bytes(block, "little") + (1 << (8 * len(block)))) * r) % POLY_PRIME
    return ((acc + s) & MASK128).to_bytes(16, "little")


def pad16(data):
    rest = len(data) % 16
    return data if rest == 0 else data + bytes(16 - rest)


def aead_keys(key, nonce24):
    subkey = hchacha20(key, nonce24[0:16])
    nonce12 = bytes(4) + nonce24[16:24]
    return subkey, nonce12, chacha_block(subkey, nonce12, 0)[0:32]


def aead_encrypt(key, nonce24, message, ad):
    subkey, nonce12, poly_key = aead_keys(key, nonce24)
    sealed = chacha_xor(subkey, nonce12, 1, message)
    mac = pad16(ad) + pad16(sealed) + struct.pack("<QQ", len(ad), len(sealed))
    return sealed + poly1305(mac, poly_key)


def aead_decrypt(key, nonce24, sealed, ad):
    if len(sealed) < AEAD_TAG_BYTES:
        return None
    subkey, nonce12, poly_key = aead_keys(key, nonce24)
    body, tag = sealed[:-AEAD_TAG_BYTES], sealed[-AEAD_TAG_BYTES:]
    mac = pad16(ad) + pad16(body) + struct.pack("<QQ", len(ad), len(body))
    if not hmac.compare_digest(poly1305(mac, poly_key), tag):
        return None
    return chacha_xor(subkey, nonce12, 1, body)


def kdf(out_len, subkey_id, ctx, key):
    salt = struct.pack("<Q", subkey_id) + bytes(8)
    personal = ctx.encode() + bytes(16 - len(ctx))
    return hashlib.blake2b(bytes(), digest_size=out_len, key=key, salt=salt, person=personal).digest()


def keyed_hash(message, key):
    return hashlib.blake2b(message, digest_size=32, key=key).digest()


def seal_ad(kind, index, build_id):
    return ("xvcen-v4-seal-%s-%u-%u" % (kind, index, build_id)).encode()


def region_keys(master, code, index, off, length):
    mac_key = kdf(KDF_KEY_BYTES, 0x10 + index, "XVMAC%u__" % index, master)
    code_mac = keyed_hash(code[off : off + length], mac_key)
    return kdf(KDF_KEY_BYTES, 0x40 + index, "XVREG%u__" % index, code_mac)


def window_keys(master, code, index, off, length):
    mac_key = kdf(KDF_KEY_BYTES, 0x200 + index, "XVWINKEY", master)
    code_mac = keyed_hash(code[off : off + length], mac_key)
    return kdf(KDF_KEY_BYTES, 0x60 + index, "XVWSEL__", code_mac)


def seal_blob(data, rx, consts, secret, plains, regions, windows):
    build_id = secret["build_id"]
    master = bytes.fromhex(secret["master"])
    code = data[rx["offset"] : rx["offset"] + rx["filesz"]]
    slot = bytearray(consts["XV_SEAL_SLOT_SIZE"])
    region_entry_bytes = consts["XV_SEAL_REGION_ENTRY_BYTES"]
    window_entry_bytes = consts["XV_SEAL_WINDOW_ENTRY_BYTES"]
    window_item_bytes = consts["XV_SEAL_WINDOW_ITEM_BYTES"]
    window_ct_bytes = consts["XV_SEAL_WINDOW_CT_BYTES"]

    cursor = consts["XV_SEAL_DATA_OFF"]
    for index, ((off, length), plain) in enumerate(zip(regions, plains)):
        if length == 0 or off + length > len(code):
            raise SystemExit("region %u out of range" % index)
        sub_key = region_keys(master, code, index, off, length)
        nonce = os.urandom(AEAD_NONCE_BYTES)
        sealed = aead_encrypt(sub_key, nonce, plain, seal_ad("region", index, build_id))
        cursor = (cursor + 15) & ~15
        entry = bytearray(region_entry_bytes)
        struct.pack_into("<IIII", entry, 0, len(sealed), off, length, cursor)
        entry[16 : 16 + AEAD_NONCE_BYTES] = nonce
        entry_off = consts["XV_SEAL_REGION_TABLE_OFF"] + index * region_entry_bytes
        slot[entry_off : entry_off + region_entry_bytes] = entry
        slot[cursor : cursor + len(sealed)] = sealed
        cursor += len(sealed)

    for index, (off, length) in enumerate(windows):
        if length == 0 or off + length > len(code):
            raise SystemExit("window %u out of range" % index)
        sub_key = window_keys(master, code, index, off, length)
        nonce = os.urandom(AEAD_NONCE_BYTES)
        item = os.urandom(window_item_bytes)
        sealed = aead_encrypt(sub_key, nonce, item, seal_ad("window", index, build_id))
        if len(sealed) != window_ct_bytes:
            raise SystemExit("window ciphertext has unexpected size %d" % len(sealed))
        entry = bytearray(window_entry_bytes)
        struct.pack_into("<II", entry, 0, off, length)
        entry[8 : 8 + AEAD_NONCE_BYTES] = nonce
        entry[8 + AEAD_NONCE_BYTES : 8 + AEAD_NONCE_BYTES + window_ct_bytes] = sealed
        entry_off = consts["XV_SEAL_WINDOW_TABLE_OFF"] + index * window_entry_bytes
        slot[entry_off : entry_off + window_entry_bytes] = entry

    if cursor > consts["XV_SEAL_SLOT_SIZE"]:
        raise SystemExit("sealed payload does not fit the slot: %u > %u" % (cursor, consts["XV_SEAL_SLOT_SIZE"]))

    struct.pack_into(
        "<IIIIIIII",
        slot,
        0,
        consts["XV_SEAL_MAGIC"],
        consts["XV_SEAL_VERSION"],
        build_id,
        rx["filesz"],
        len(regions),
        len(windows),
        consts["XV_SEAL_WINDOW_BYTES"],
        cursor,
    )
    return cursor, bytes(slot[0:cursor])


def verify_blob(data, rx, slot_off, consts, secret, plains, regions, windows):
    build_id = secret["build_id"]
    master = bytes.fromhex(secret["master"])
    code = data[rx["offset"] : rx["offset"] + rx["filesz"]]
    slot = data[slot_off : slot_off + consts["XV_SEAL_SLOT_SIZE"]]
    region_entry_bytes = consts["XV_SEAL_REGION_ENTRY_BYTES"]
    window_entry_bytes = consts["XV_SEAL_WINDOW_ENTRY_BYTES"]
    window_item_bytes = consts["XV_SEAL_WINDOW_ITEM_BYTES"]
    window_ct_bytes = consts["XV_SEAL_WINDOW_CT_BYTES"]
    mask = 0

    for index, ((off, length), plain) in enumerate(zip(regions, plains)):
        entry = slot[consts["XV_SEAL_REGION_TABLE_OFF"] + index * region_entry_bytes :][:region_entry_bytes]
        stored_len, stored_off, stored_len_rx, stored_data = struct.unpack_from("<IIII", entry, 0)
        if stored_off != off or stored_len_rx != length or stored_len < AEAD_TAG_BYTES:
            continue
        sub_key = region_keys(master, code, index, off, length)
        opened = aead_decrypt(sub_key, bytes(entry[16 : 16 + AEAD_NONCE_BYTES]), slot[stored_data : stored_data + stored_len], seal_ad("region", index, build_id))
        if opened is not None and opened == plain:
            mask |= 1 << index

    for index, (off, length) in enumerate(windows):
        entry = slot[consts["XV_SEAL_WINDOW_TABLE_OFF"] + index * window_entry_bytes :][:window_entry_bytes]
        if struct.unpack_from("<II", entry, 0) != (off, length):
            return 1, mask
        sub_key = window_keys(master, code, index, off, length)
        opened = aead_decrypt(
            sub_key,
            bytes(entry[8 : 8 + AEAD_NONCE_BYTES]),
            bytes(entry[8 + AEAD_NONCE_BYTES : 8 + AEAD_NONCE_BYTES + window_ct_bytes]),
            seal_ad("window", index, build_id),
        )
        if opened is None or len(opened) != window_item_bytes:
            return 1, mask

    return (0 if mask == (1 << len(regions)) - 1 else 1), mask

def main():
    if len(sys.argv) < 3:
        raise SystemExit("usage: seal.py <elf> <jni-dir>")
    elf = Path(sys.argv[1]).resolve()
    jni = Path(sys.argv[2]).resolve()

    consts = header_constants(jni / "include" / "Auth" / "xvseal.h")
    secret = json.loads((jni / "gen" / "build_secret.json").read_text())
    plains = []
    for index in range(consts["XV_SEAL_REGIONS"]):
        path = jni / "gen" / "payload" / ("region%d.bin" % index)
        plains.append(path.read_bytes())

    data = elf.read_bytes()
    segments = parse_elf(data)
    rx = pick_rx(segments)
    if rx["filesz"] != rx["memsz"]:
        raise SystemExit("executable segment has bss tail, refusing to seal")
    slot_off = find_slot(data, bytes.fromhex(secret["magic"]), consts["XV_SEAL_SLOT_SIZE"], rx)

    regions = region_ranges(rx["filesz"], consts["XV_SEAL_REGIONS"])
    windows = window_ranges(rx["filesz"], consts["XV_SEAL_WINDOWS"], consts["XV_SEAL_WINDOW_BYTES"])

    total_len, blob = seal_blob(data, rx, consts, secret, plains, regions, windows)
    if total_len > consts["XV_SEAL_SLOT_SIZE"] or total_len <= consts["XV_SEAL_DATA_OFF"]:
        raise SystemExit("sealed blob has invalid size %d" % total_len)
    blob = blob + bytes(consts["XV_SEAL_SLOT_SIZE"] - len(blob))

    patched = bytearray(data)
    patched[slot_off : slot_off + consts["XV_SEAL_SLOT_SIZE"]] = blob
    elf.write_bytes(bytes(patched))

    sealed = elf.read_bytes()
    status, mask = verify_blob(sealed, rx, slot_off, consts, secret, plains, regions, windows)
    if status != 0 or mask != (1 << consts["XV_SEAL_REGIONS"]) - 1:
        raise SystemExit("seal verification failed status=%d mask=0x%x" % (status, mask))
    print(
        "sealed %s: slot=0x%x bytes=%d rx=%d regions=%d windows=%d"
        % (elf.name, slot_off, total_len, rx["filesz"], len(regions), len(windows))
    )


if __name__ == "__main__":
    main()
