#include <cstdio>
#include <cstring>
#include <string>

#include "xvseal.h"
#include "xvstrings.h"
#include "xvkeys.h"
#include "xvpolicy.h"
#include "offsets.h"
#include "offsets_beta.h"

int main() {
    bool ready = xv::Init();
    printf("ready=%d\n", ready ? 1 : 0);
    if (!ready) return 1;
    printf("build=%u\n", xv::BuildId());
    printf("token=%llu\n", static_cast<unsigned long long>(xv::Token()));
    printf("offsets=%zu strings=%zu policy=%zu\n", xv::OffsetCount(), xv::StrCount(), xv::PolicyCount());
    printf("player_transform=%llx\n", static_cast<unsigned long long>(game_offsets::PLAYER_TRANSFORM));
    printf("network_client=%llx\n", static_cast<unsigned long long>(game_offsets::NETWORK_CLIENT_TYPEINFO_RVA));
    printf("beta_network_client=%llx\n", static_cast<unsigned long long>(game_offsets_beta::NETWORK_CLIENT_TYPEINFO_RVA));
    printf("player_height=%f\n", static_cast<double>(game_offsets::PLAYER_HEIGHT));
    std::string url = xv::Str(xv::sid::kUrlBase);
    printf("url=%s\n", url.c_str());
    printf("cstr=%s\n", xv::StrC(xv::sid::kTargetPackage));
    printf("stable=%s\n", xv::StrStable(xv::sid::kProcMaps));
    printf("menu_en=%s\n", xv::StrStable(xv::sid::kEnTabAim));
    printf("menu_ru=%s\n", xv::StrStable(xv::sid::kRuTabAim));
    printf("menu_long=%s\n", xv::StrStable(xv::sid::kEnAimZoneH));
    unsigned char key[32];
    printf("key=%d\n", xv::Key(xv::kid::kStreamDomain, key, sizeof(key)) ? 1 : 0);
    printf("policy=%llu\n", static_cast<unsigned long long>(xv::Policy(xv::pid::kProtocolVersion)));
    printf("ttl=%llu\n", static_cast<unsigned long long>(xv::Policy(xv::pid::kTokenTtlSeconds)));
    printf("checkpoint=%d\n", xv::Checkpoint(0x38f6c1a95d274be0ULL) ? 1 : 0);
    printf("revalidate=%d\n", xv::Revalidate(0xc13a5e709b2486dfULL) ? 1 : 0);
    printf("checkpoint_after=%d\n", xv::Checkpoint(7) ? 1 : 0);
    sodium_memzero(key, sizeof(key));
    return 0;
}
