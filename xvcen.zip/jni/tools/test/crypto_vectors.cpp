#include <sodium.h>

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace {

std::string Hex(const unsigned char* data, std::size_t len) {
    static const char* digits = "0123456789abcdef";
    std::string out;
    out.resize(len * 2);
    for (std::size_t i = 0; i < len; ++i) {
        out[2 * i] = digits[(data[i] >> 4) & 0xF];
        out[2 * i + 1] = digits[data[i] & 0xF];
    }
    return out;
}

std::string Hex(const std::vector<unsigned char>& data) {
    return Hex(data.data(), data.size());
}

std::vector<unsigned char> Pattern(std::size_t len, unsigned char seed) {
    std::vector<unsigned char> out(len);
    for (std::size_t i = 0; i < len; ++i) {
        out[i] = static_cast<unsigned char>((seed + i * 7 + (i >> 3)) & 0xFF);
    }
    return out;
}

void Store64(unsigned char* out, std::uint64_t value) {
    for (int i = 0; i < 8; ++i) out[i] = static_cast<unsigned char>((value >> (8 * i)) & 0xFF);
}

void Store32(unsigned char* out, std::uint32_t value) {
    for (int i = 0; i < 4; ++i) out[i] = static_cast<unsigned char>((value >> (8 * i)) & 0xFF);
}

class Json {
public:
    void Str(const char* name, const std::string& value) {
        Sep();
        out_ += "\"";
        out_ += name;
        out_ += "\": \"";
        out_ += value;
        out_ += "\"";
    }
    void Hex(const char* name, const std::string& value) { Str(name, value); }
    void Num(const char* name, std::uint64_t value) {
        Sep();
        out_ += "\"";
        out_ += name;
        out_ += "\": ";
        out_ += std::to_string(value);
    }
    void Bytes(const char* name, const unsigned char* data, std::size_t len) {
        Hex(name, ::Hex(data, len));
    }
    void Bytes(const char* name, const std::vector<unsigned char>& data) {
        Hex(name, ::Hex(data));
    }
    const std::string& text() const { return out_; }

private:
    void Sep() {
        if (!out_.empty()) out_ += ",\n";
    }
    std::string out_;
};

void FrameAppend(std::vector<unsigned char>& out, const unsigned char* data, std::size_t len) {
    out.push_back(static_cast<unsigned char>(len & 0xFF));
    out.push_back(static_cast<unsigned char>((len >> 8) & 0xFF));
    out.insert(out.end(), data, data + len);
}

}  // namespace

int main(int argc, char** argv) {
    if (sodium_init() != 0) return 1;

    Json json;

    const std::vector<unsigned char> key32 = Pattern(32, 0x11);
    const std::vector<unsigned char> salt16 = Pattern(16, 0x5a);
    const std::vector<unsigned char> personal16 = Pattern(16, 0xa3);
    const std::vector<unsigned char> msgEmpty;
    const std::vector<unsigned char> msgShort(reinterpret_cast<const unsigned char*>("xvcen"),
                                              reinterpret_cast<const unsigned char*>("xvcen") + 5);
    const std::vector<unsigned char> msgLong = Pattern(300, 0x2b);

    json.Bytes("key32", key32);
    json.Bytes("salt16", salt16);
    json.Bytes("personal16", personal16);
    json.Bytes("msgShort", msgShort);
    json.Bytes("msgLong", msgLong);

    unsigned char digest[64];
    crypto_generichash(digest, 64, msgLong.data(), msgLong.size(), nullptr, 0);
    json.Bytes("blake2b_plain64", digest, 64);
    crypto_generichash(digest, 32, msgLong.data(), msgLong.size(), nullptr, 0);
    json.Bytes("blake2b_plain32", digest, 32);
    crypto_generichash(digest, 32, msgLong.data(), msgLong.size(), key32.data(), key32.size());
    json.Bytes("blake2b_keyed32", digest, 32);
    crypto_generichash(digest, 48, msgShort.data(), msgShort.size(), key32.data(), key32.size());
    json.Bytes("blake2b_keyed48", digest, 48);
    crypto_generichash(digest, 32, msgEmpty.data(), 0, key32.data(), key32.size());
    json.Bytes("blake2b_keyed_empty", digest, 32);

    crypto_generichash_blake2b_salt_personal(digest, 32, msgLong.data(), msgLong.size(),
                                             key32.data(), key32.size(), salt16.data(),
                                             personal16.data());
    json.Bytes("blake2b_salt_personal", digest, 32);

    unsigned char subkey[32];
    const char* ctxMask = "XVMASK__";
    crypto_kdf_derive_from_key(subkey, sizeof(subkey), 0x300ULL, ctxMask, key32.data());
    json.Bytes("kdf_mask_0x300", subkey, 32);
    crypto_kdf_derive_from_key(subkey, sizeof(subkey), 1ULL, "XVDEVWRP", key32.data());
    json.Bytes("kdf_devwrap_1", subkey, 32);
    json.Str("kdf_ctx_mask", ctxMask);
    json.Str("kdf_ctx_devwrap", "XVDEVWRP");

    unsigned char hchachaOut[32];
    const std::vector<unsigned char> hchachaIn = Pattern(16, 0x77);
    json.Bytes("hchacha_in", hchachaIn);
    crypto_core_hchacha20(hchachaOut, hchachaIn.data(), key32.data(), nullptr);
    json.Bytes("hchacha_out", hchachaOut, 32);

    const std::vector<unsigned char> chachaNonce = Pattern(12, 0x3c);
    json.Bytes("chacha_nonce", chachaNonce);
    std::vector<unsigned char> stream(200);
    crypto_stream_chacha20_ietf(stream.data(), stream.size(), chachaNonce.data(), key32.data());
    json.Bytes("chacha_stream200", stream);

    std::vector<unsigned char> block(64, 0);
    std::vector<unsigned char> xored(256);
    crypto_stream_chacha20_ietf_xor_ic(xored.data(), block.data(), block.size(), chachaNonce.data(),
                                       1U, key32.data());
    json.Bytes("chacha_xor_ic1_zeros", xored.data(), block.size());
    crypto_stream_chacha20_ietf_xor_ic(xored.data(), msgLong.data(), 137, chachaNonce.data(), 2U,
                                       key32.data());
    json.Num("chacha_xor_ic2_len", 137);
    json.Bytes("chacha_xor_ic2", xored.data(), 137);

    unsigned char mac[16];
    crypto_onetimeauth_poly1305(mac, msgLong.data(), msgLong.size(), key32.data());
    json.Bytes("poly1305_mac", mac, 16);
    const std::vector<unsigned char> polyMsg = Pattern(77, 0x91);
    crypto_onetimeauth_poly1305(mac, polyMsg.data(), polyMsg.size(), key32.data());
    json.Bytes("poly1305_msg", polyMsg);
    json.Bytes("poly1305_mac77", mac, 16);

    const std::vector<unsigned char> streamKey = Pattern(32, 0x4d);
    const std::vector<unsigned char> streamHeader = Pattern(24, 0x6e);
    json.Bytes("stream_key", streamKey);
    json.Bytes("stream_header", streamHeader);

    crypto_secretstream_xchacha20poly1305_state pushState;
    crypto_secretstream_xchacha20poly1305_init_pull(&pushState, streamHeader.data(),
                                                    streamKey.data());

    const std::vector<unsigned char> ad = Pattern(29, 0xb1);
    json.Bytes("stream_ad", ad);

    struct Chunk {
        std::vector<unsigned char> plain;
        unsigned char tag;
        bool withAd;
    };
    const std::vector<Chunk> chunks = {
        {Pattern(0, 0), crypto_secretstream_xchacha20poly1305_TAG_MESSAGE, false},
        {std::vector<unsigned char>(reinterpret_cast<const unsigned char*>("i:abc123:1700000000"),
                                    reinterpret_cast<const unsigned char*>("i:abc123:1700000000") + 19),
         crypto_secretstream_xchacha20poly1305_TAG_MESSAGE, true},
        {Pattern(100, 0x1f), crypto_secretstream_xchacha20poly1305_TAG_PUSH, true},
        {Pattern(0, 0), crypto_secretstream_xchacha20poly1305_TAG_REKEY, false},
        {Pattern(17, 0x88), crypto_secretstream_xchacha20poly1305_TAG_MESSAGE, true},
        {Pattern(1, 0x01), crypto_secretstream_xchacha20poly1305_TAG_FINAL, true},
        {Pattern(33, 0x5e), crypto_secretstream_xchacha20poly1305_TAG_MESSAGE, false},
    };

    std::vector<std::string> chunkHex;
    std::vector<std::string> chunkPlainHex;
    std::string chunkAdFlags;
    std::vector<unsigned char> ct(chunks[2].plain.size() + crypto_secretstream_xchacha20poly1305_ABYTES + 8);
    for (const Chunk& chunk : chunks) {
        ct.resize(chunk.plain.size() + crypto_secretstream_xchacha20poly1305_ABYTES);
        unsigned long long ctLen = 0;
        if (crypto_secretstream_xchacha20poly1305_push(
                &pushState, ct.data(), &ctLen, chunk.plain.data(), chunk.plain.size(),
                chunk.withAd ? ad.data() : nullptr, chunk.withAd ? ad.size() : 0, chunk.tag) != 0) {
            return 1;
        }
        chunkHex.push_back(Hex(ct.data(), static_cast<std::size_t>(ctLen)));
        chunkPlainHex.push_back(Hex(chunk.plain));
        chunkAdFlags += chunk.withAd ? "1" : "0";
    }
    std::string joined;
    for (std::size_t i = 0; i < chunkHex.size(); ++i) {
        if (i) joined += " ";
        joined += chunkHex[i];
    }
    json.Str("stream_chunks", joined);
    std::string joinedPlains;
    for (std::size_t i = 0; i < chunkPlainHex.size(); ++i) {
        if (i) joinedPlains += " ";
        joinedPlains += chunkPlainHex[i];
    }
    json.Str("stream_chunk_plains", joinedPlains);
    json.Str("stream_chunk_ad", chunkAdFlags);

    crypto_secretstream_xchacha20poly1305_state pullState;
    crypto_secretstream_xchacha20poly1305_init_pull(&pullState, streamHeader.data(),
                                                    streamKey.data());
    std::vector<unsigned char> plainOut(256);
    std::string pulledHex;
    for (std::size_t i = 0; i < chunkHex.size(); ++i) {
        std::vector<unsigned char> raw;
        for (std::size_t j = 0; j < chunkHex[i].size(); j += 2) {
            raw.push_back(static_cast<unsigned char>(std::stoi(chunkHex[i].substr(j, 2), nullptr, 16)));
        }
        unsigned long long plainLen = 0;
        unsigned char tag = 0;
        bool withAd = chunks[i].withAd;
        if (crypto_secretstream_xchacha20poly1305_pull(
                &pullState, plainOut.data(), &plainLen, &tag, raw.data(), raw.size(),
                withAd ? ad.data() : nullptr, withAd ? ad.size() : 0) != 0) {
            return 1;
        }
        if (plainLen != chunks[i].plain.size() || tag != chunks[i].tag) return 1;
        if (std::memcmp(plainOut.data(), chunks[i].plain.data(), plainLen) != 0) return 1;
        if (i) pulledHex += " ";
        pulledHex += std::to_string(tag);
    }
    json.Str("stream_tags", pulledHex);

    const std::vector<unsigned char> clientSeed = Pattern(32, 0x21);
    const std::vector<unsigned char> serverSeed = Pattern(32, 0xc4);
    json.Bytes("kx_client_seed", clientSeed);
    json.Bytes("kx_server_seed", serverSeed);

    unsigned char clientPk[32];
    unsigned char clientSk[32];
    unsigned char serverPk[32];
    unsigned char serverSk[32];
    crypto_kx_seed_keypair(clientPk, clientSk, clientSeed.data());
    crypto_kx_seed_keypair(serverPk, serverSk, serverSeed.data());
    json.Bytes("kx_client_pk", clientPk, 32);
    json.Bytes("kx_client_sk", clientSk, 32);
    json.Bytes("kx_server_pk", serverPk, 32);
    json.Bytes("kx_server_sk", serverSk, 32);

    unsigned char clientRx[32];
    unsigned char clientTx[32];
    unsigned char serverRx[32];
    unsigned char serverTx[32];
    if (crypto_kx_client_session_keys(clientRx, clientTx, clientPk, clientSk, serverPk) != 0) return 1;
    if (crypto_kx_server_session_keys(serverRx, serverTx, serverPk, serverSk, clientPk) != 0) return 1;
    json.Bytes("kx_client_rx", clientRx, 32);
    json.Bytes("kx_client_tx", clientTx, 32);
    json.Bytes("kx_server_rx", serverRx, 32);
    json.Bytes("kx_server_tx", serverTx, 32);

    const std::vector<unsigned char> signSeed = Pattern(32, 0x0f);
    json.Bytes("sign_seed", signSeed);
    unsigned char signPk[crypto_sign_PUBLICKEYBYTES];
    unsigned char signSk[crypto_sign_SECRETKEYBYTES];
    crypto_sign_seed_keypair(signPk, signSk, signSeed.data());
    json.Bytes("sign_pk", signPk, crypto_sign_PUBLICKEYBYTES);
    const std::vector<unsigned char> signMsg = Pattern(96, 0x44);
    json.Bytes("sign_msg", signMsg);
    unsigned char sig[crypto_sign_BYTES];
    unsigned long long sigLen = 0;
    crypto_sign_detached(sig, &sigLen, signMsg.data(), signMsg.size(), signSk);
    json.Bytes("sign_sig", sig, static_cast<std::size_t>(sigLen));

    const std::vector<unsigned char> authMsg = Pattern(64, 0x19);
    json.Bytes("auth_msg", authMsg);
    unsigned char authTag[crypto_auth_BYTES];
    crypto_auth(authTag, authMsg.data(), authMsg.size(), key32.data());
    json.Bytes("auth_tag", authTag, crypto_auth_BYTES);

    const std::string license = "XVCEN-TEST-LICENSE-0001";
    const std::vector<unsigned char> licenseDomain = Pattern(32, 0x7d);
    const std::vector<unsigned char> tokenKey = Pattern(32, 0x36);
    const std::vector<unsigned char> sessionId = Pattern(16, 0x08);
    const std::vector<unsigned char> challenge = Pattern(32, 0x9c);
    const std::vector<unsigned char> tokenNonce = Pattern(12, 0x55);
    json.Str("license", license);
    json.Bytes("license_domain", licenseDomain);
    json.Bytes("token_key", tokenKey);
    json.Bytes("session_id", sessionId);
    json.Bytes("challenge", challenge);
    json.Bytes("token_nonce", tokenNonce);

    unsigned char licKey[32];
    crypto_generichash(licKey, sizeof(licKey),
                       reinterpret_cast<const unsigned char*>(license.data()), license.size(),
                       licenseDomain.data(), licenseDomain.size());
    json.Bytes("lic_key", licKey, 32);

    const std::string nonceHex = Hex(sessionId);
    const std::string challengeHex = Hex(challenge);
    const std::string clientPubHex = Hex(clientPk, 32);
    const std::string devicePubHex = Hex(signPk, crypto_sign_PUBLICKEYBYTES);

    const std::string sigPayload = "xvcen-v4-sig:" + nonceHex + ":" + challengeHex + ":" +
                                   clientPubHex + ":" + devicePubHex;
    json.Str("sig_payload", sigPayload);
    unsigned char deviceSig[crypto_sign_BYTES];
    unsigned long long deviceSigLen = 0;
    crypto_sign_detached(deviceSig, &deviceSigLen,
                         reinterpret_cast<const unsigned char*>(sigPayload.data()),
                         sigPayload.size(), signSk);
    json.Bytes("device_sig", deviceSig, static_cast<std::size_t>(deviceSigLen));

    const std::string licPayload = "xvcen-v4-lic:" + nonceHex + ":" + challengeHex + ":" +
                                   clientPubHex + ":" + devicePubHex;
    json.Str("lic_payload", licPayload);
    unsigned char licTag[crypto_auth_BYTES];
    crypto_auth(licTag, reinterpret_cast<const unsigned char*>(licPayload.data()), licPayload.size(),
                licKey);
    json.Bytes("lic_tag", licTag, crypto_auth_BYTES);

    const std::uint64_t issued = 1760000000ULL;
    const std::uint64_t expires = issued + 86400ULL;
    const std::uint32_t licenseId = 7u;
    const std::uint64_t rva = 0xD8DAB08ULL;
    json.Num("issued", issued);
    json.Num("expires", expires);
    json.Num("license_id", licenseId);
    json.Num("rva", rva);

    std::vector<unsigned char> tokenBody(64);
    std::memcpy(tokenBody.data(), signPk, 32);
    Store64(tokenBody.data() + 32, issued);
    Store64(tokenBody.data() + 40, expires);
    Store32(tokenBody.data() + 48, licenseId);
    std::memcpy(tokenBody.data() + 52, tokenNonce.data(), 12);
    unsigned char tokenTag[crypto_auth_BYTES];
    crypto_auth(tokenTag, tokenBody.data(), tokenBody.size(), tokenKey.data());
    std::vector<unsigned char> tokenRaw = tokenBody;
    tokenRaw.insert(tokenRaw.end(), tokenTag, tokenTag + crypto_auth_BYTES);
    const std::string tokenHex = Hex(tokenRaw);
    json.Bytes("token_body", tokenBody);
    json.Bytes("token_tag", tokenTag, crypto_auth_BYTES);
    json.Str("token_hex", tokenHex);

    const std::string streamAd = "xvcen-v4-stream" + nonceHex + ":" + challengeHex + ":" + clientPubHex;
    json.Str("stream_ad_handshake", streamAd);

    const std::vector<unsigned char> grantHeader = Pattern(24, 0xe7);
    json.Bytes("grant_header", grantHeader);

    crypto_secretstream_xchacha20poly1305_state grantState;
    crypto_secretstream_xchacha20poly1305_init_pull(&grantState, grantHeader.data(), serverTx);

    std::vector<unsigned char> grantPlain(16 + 8 + 8 + 8 + 4 + 96);
    std::memcpy(grantPlain.data(), sessionId.data(), 16);
    Store64(grantPlain.data() + 16, 1);
    Store64(grantPlain.data() + 24, issued);
    Store64(grantPlain.data() + 32, expires);
    Store32(grantPlain.data() + 40, licenseId);
    std::memcpy(grantPlain.data() + 44, tokenRaw.data(), tokenRaw.size());

    std::vector<unsigned char> rvaPlain(16 + 8 + 8 + 4);
    std::memcpy(rvaPlain.data(), sessionId.data(), 16);
    Store64(rvaPlain.data() + 16, 2);
    Store64(rvaPlain.data() + 24, rva);
    Store32(rvaPlain.data() + 32, 1u);

    std::vector<unsigned char> finalPlain(16 + 8 + 1);
    std::memcpy(finalPlain.data(), sessionId.data(), 16);
    Store64(finalPlain.data() + 16, 3);
    finalPlain[24] = 1;

    std::vector<unsigned char> blob = grantHeader;
    std::vector<unsigned char> chunkCt(256);
    const std::vector<unsigned char>* parts[3] = {&grantPlain, &rvaPlain, &finalPlain};
    const unsigned char tags[3] = {crypto_secretstream_xchacha20poly1305_TAG_MESSAGE,
                                   crypto_secretstream_xchacha20poly1305_TAG_PUSH,
                                   crypto_secretstream_xchacha20poly1305_TAG_FINAL};
    for (int i = 0; i < 3; ++i) {
        unsigned long long ctLen = 0;
        if (crypto_secretstream_xchacha20poly1305_push(
                &grantState, chunkCt.data(), &ctLen, parts[i]->data(), parts[i]->size(),
                reinterpret_cast<const unsigned char*>(streamAd.data()), streamAd.size(),
                tags[i]) != 0) {
            return 1;
        }
        FrameAppend(blob, chunkCt.data(), static_cast<std::size_t>(ctLen));
    }
    json.Bytes("grant_blob", blob);

    crypto_secretstream_xchacha20poly1305_state clientState;
    if (crypto_secretstream_xchacha20poly1305_init_pull(&clientState, blob.data(), clientRx) != 0) {
        return 1;
    }
    std::size_t pos = 24;
    std::string clientTags;
    while (pos + 2 <= blob.size()) {
        std::size_t len = static_cast<std::size_t>(blob[pos]) |
                          (static_cast<std::size_t>(blob[pos + 1]) << 8);
        pos += 2;
        std::vector<unsigned char> out(256);
        unsigned long long outLen = 0;
        unsigned char tag = 0;
        if (crypto_secretstream_xchacha20poly1305_pull(
                &clientState, out.data(), &outLen, &tag, blob.data() + pos, len,
                reinterpret_cast<const unsigned char*>(streamAd.data()), streamAd.size()) != 0) {
            return 1;
        }
        pos += len;
        if (!clientTags.empty()) clientTags += " ";
        clientTags += std::to_string(tag) + ":" + std::to_string(outLen);
        if (outLen >= 24) {
            if (std::memcmp(out.data(), sessionId.data(), 16) != 0) return 1;
        }
    }
    json.Str("client_chunk_tags", clientTags);

    unsigned char nameDigest[32];
    const std::string nameMessage = "xvcen-v4-name:player_one";
    json.Str("name_message", nameMessage);
    crypto_generichash(nameDigest, sizeof(nameDigest),
                       reinterpret_cast<const unsigned char*>(nameMessage.data()),
                       nameMessage.size(), licenseDomain.data(), licenseDomain.size());
    json.Bytes("name_digest", nameDigest, 32);
    json.Str("name_hash", Hex(nameDigest, 8));

    const std::string wsPayload = "xvcen-v4-ws:" + nonceHex + ":" + std::to_string(issued) + ":" +
                                  devicePubHex + ":" + clientPubHex;
    json.Str("ws_payload", wsPayload);
    unsigned char wsSig[crypto_sign_BYTES];
    unsigned long long wsSigLen = 0;
    crypto_sign_detached(wsSig, &wsSigLen,
                         reinterpret_cast<const unsigned char*>(wsPayload.data()), wsPayload.size(),
                         signSk);
    json.Bytes("ws_sig", wsSig, static_cast<std::size_t>(wsSigLen));

    const std::string wsHello = "i:" + nonceHex + ":" + std::to_string(issued);
    json.Str("ws_hello", wsHello);

    const std::vector<unsigned char> wsHeader = Pattern(24, 0x13);
    json.Bytes("ws_server_header", wsHeader);
    json.Bytes("ws_client_header", Pattern(24, 0x29));

    crypto_secretstream_xchacha20poly1305_state wsServerPush;
    crypto_secretstream_xchacha20poly1305_init_pull(&wsServerPush, wsHeader.data(), serverTx);
    crypto_secretstream_xchacha20poly1305_state wsClientPush;
    const std::vector<unsigned char> wsClientHeader = Pattern(24, 0x29);
    crypto_secretstream_xchacha20poly1305_init_pull(&wsClientPush, wsClientHeader.data(), clientTx);

    const char* snapshotText = "f:3:aabbccddeeff0011,1122334455667788,99aabbccddeeff00";
    const std::vector<unsigned char> snapshot(
        reinterpret_cast<const unsigned char*>(snapshotText),
        reinterpret_cast<const unsigned char*>(snapshotText) + std::strlen(snapshotText));
    std::vector<unsigned char> wsCt(256);
    unsigned long long wsCtLen = 0;
    if (crypto_secretstream_xchacha20poly1305_push(&wsServerPush, wsCt.data(), &wsCtLen,
                                                   snapshot.data(), snapshot.size(), nullptr, 0,
                                                   crypto_secretstream_xchacha20poly1305_TAG_MESSAGE) != 0) {
        return 1;
    }
    std::vector<unsigned char> wsFrame;
    FrameAppend(wsFrame, wsCt.data(), static_cast<std::size_t>(wsCtLen));
    json.Bytes("ws_server_frame", wsFrame);
    json.Str("ws_snapshot", std::string(snapshotText));

    if (crypto_secretstream_xchacha20poly1305_push(&wsClientPush, wsCt.data(), &wsCtLen,
                                                   reinterpret_cast<const unsigned char*>(wsHello.data()),
                                                   wsHello.size(), nullptr, 0,
                                                   crypto_secretstream_xchacha20poly1305_TAG_MESSAGE) != 0) {
        return 1;
    }
    wsFrame.clear();
    FrameAppend(wsFrame, wsCt.data(), static_cast<std::size_t>(wsCtLen));
    json.Bytes("ws_client_frame", wsFrame);

    if (crypto_secretstream_xchacha20poly1305_push(&wsClientPush, wsCt.data(), &wsCtLen, nullptr, 0,
                                                   nullptr, 0,
                                                   crypto_secretstream_xchacha20poly1305_TAG_REKEY) != 0) {
        return 1;
    }
    wsFrame.clear();
    FrameAppend(wsFrame, wsCt.data(), static_cast<std::size_t>(wsCtLen));
    json.Bytes("ws_client_rekey_frame", wsFrame);

    json.Num("protocol_version", 4);
    json.Num("stream_abytes", crypto_secretstream_xchacha20poly1305_ABYTES);
    json.Num("stream_header_bytes", crypto_secretstream_xchacha20poly1305_HEADERBYTES);
    json.Num("auth_bytes", crypto_auth_BYTES);
    json.Num("session_id_bytes", 16);

    std::string text = "{\n" + json.text() + "\n}\n";
    if (argc > 1) {
        std::FILE* out = std::fopen(argv[1], "wb");
        if (!out) return 1;
        std::fwrite(text.data(), 1, text.size(), out);
        std::fclose(out);
    } else {
        std::fwrite(text.data(), 1, text.size(), stdout);
    }
    return 0;
}
